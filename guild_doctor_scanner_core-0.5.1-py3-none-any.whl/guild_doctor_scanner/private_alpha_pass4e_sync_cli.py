"""Bounded Pass4E pre-live validation synchronization command."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path

from .discord_live_runtime import DiscordPyTransport
from .private_alpha_configuration import check_secret_presence, load_configuration
from .private_alpha_live_interaction_preflight import READY_STATE, run_live_interaction_preflight
from .private_alpha_live_validation_configuration import load_live_configuration
from .private_alpha_pass4e_session_artifacts import SessionArtifactPaths
from .private_alpha_pass4e_validation_surface import (
    ValidationSurfaceMode,
    serialized_validation_schema_fingerprint,
    validation_manifest_fingerprint,
)
from .private_alpha_pass4e_validation_sync import (
    DiscordValidationSyncTransport,
    SyncOperationBudget,
    SyncProofStore,
    execute_typed_guild_sync,
)


def main() -> int:
    p = argparse.ArgumentParser(description="Perform the single bounded Pass4E validation sync.")
    p.add_argument("--project-root", type=Path, required=True)
    p.add_argument("--active-config", type=Path, required=True)
    p.add_argument("--live-config", type=Path, required=True)
    p.add_argument("--snapshot", type=Path, required=True)
    args = p.parse_args()
    return asyncio.run(_run(args))


async def _run(args: argparse.Namespace) -> int:
    root = args.project_root.resolve()
    active = load_configuration(args.active_config)
    load_live_configuration(args.live_config, project_root=root)
    preflight = run_live_interaction_preflight(
        root=root,
        active_configuration_path=args.active_config,
        live_configuration_path=args.live_config,
        snapshot_path=args.snapshot,
        secret_presence=check_secret_presence(os.environ),
    )
    if preflight.overall_state != READY_STATE:
        print(json.dumps({"state": "BLOCKED", "reason": "PREFLIGHT_NOT_READY"}))
        return 2
    artifacts = SessionArtifactPaths.generate()
    proof_path = artifacts.authority_path.with_name(artifacts.authority_path.stem + "_validation_sync_proof.json")
    budget = SyncOperationBudget()
    transport = DiscordValidationSyncTransport(base=DiscordPyTransport())
    try:
        await transport.initialize(os.environ["GUILD_DOCTOR_DISCORD_TOKEN"], ValidationSurfaceMode.PASS4E_VALIDATION)
        proof = await execute_typed_guild_sync(
            transport=transport,
            configuration=active,
            mode=ValidationSurfaceMode.PASS4E_VALIDATION,
            budget=budget,
            proof_store=SyncProofStore(proof_path),
            expected_manifest_fingerprint=validation_manifest_fingerprint(ValidationSurfaceMode.PASS4E_VALIDATION),
            expected_schema_fingerprint=serialized_validation_schema_fingerprint(ValidationSurfaceMode.PASS4E_VALIDATION),
        )
    finally:
        await transport.close()
    print(json.dumps({"state": "PASS", "proof_fingerprint": proof.proof_fingerprint, "total_writes": budget.total_write_count, "global_writes": budget.global_write_count, "other_guild_writes": budget.other_guild_write_count}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
