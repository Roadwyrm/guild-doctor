"""Immutable Stage 5 Pass 2 enumeration-case output."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .canonical import canonical_json
from .doctor_aggregation import ENUMERATION_CASE_CONTRACT_VERSION, ENUMERATION_GOLDEN_VERSION, ENUMERATION_RULES_VERSION
from .doctor_enumeration_query import ENUMERATION_QUERY_CONTRACT_VERSION, STAGE5_PASS2_CONTRACT_VERSION, DoctorEnumerationQuery


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(k): _freeze(v) for k, v in sorted(value.items(), key=lambda item: str(item[0]))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(v) for v in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(v) for v in sorted(value, key=str))
    return deepcopy(value)


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _thaw(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_thaw(v) for v in value]
    return deepcopy(value)


def _safe(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _safe(method())
    if isinstance(value, Mapping):
        return {str(k): _safe(v) for k, v in sorted(value.items(), key=lambda item: str(item[0]))}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_safe(v) for v in value]
    return value


def _fingerprint(value: Mapping[str, Any]) -> str:
    payload = dict(value)
    payload.pop("enumeration_case_fingerprint", None)
    query = payload.get("query")
    if isinstance(query, Mapping) and isinstance(query.get("candidates"), list):
        query = dict(query)
        query["candidates"] = sorted(query["candidates"], key=lambda item: int(item.get("id", item.get("member_id", "0"))) if isinstance(item, Mapping) and str(item.get("id", item.get("member_id", "0"))).isdecimal() else 0)
        payload["query"] = query
    population = payload.get("population")
    if isinstance(population, Mapping) and isinstance(population.get("candidate_dispositions"), list):
        population = dict(population)
        dispositions = []
        for item in population["candidate_dispositions"]:
            if isinstance(item, Mapping):
                item = dict(item)
                item.pop("original_indexes", None)
                item.pop("display_label", None)
            dispositions.append(item)
        population["candidate_dispositions"] = sorted(dispositions, key=lambda item: int(item.get("candidate_id", "0")) if isinstance(item, Mapping) and str(item.get("candidate_id", "0")).isdecimal() else 0)
        payload["population"] = population
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class DoctorEnumerationCase:
    stage5_pass2_contract_version: str
    enumeration_query_contract_version: str
    enumeration_case_contract_version: str
    enumeration_rules_version: str
    enumeration_golden_version: str
    stage5_pass1_contract_version: str
    doctor_query_contract_version: str
    query: Mapping[str, Any]
    query_id: str | None
    enumeration_intent: str | None
    target_kind: str | None
    target_key: str | None
    scope: Mapping[str, Any]
    population: Mapping[str, Any]
    result_buckets: Mapping[str, Any]
    intent_result: Mapping[str, Any]
    aggregation: Mapping[str, Any]
    presentation: Mapping[str, Any]
    provenance: Mapping[str, Any]
    integrity: Mapping[str, Any]
    status: str
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    enumeration_case_fingerprint: str = ""

    def __post_init__(self) -> None:
        for field_name in (
            "query",
            "scope",
            "population",
            "result_buckets",
            "intent_result",
            "aggregation",
            "presentation",
            "provenance",
            "integrity",
        ):
            object.__setattr__(self, field_name, _freeze(getattr(self, field_name)))

    def as_dict(self) -> dict[str, Any]:
        return {
            "stage5_pass2_contract_version": self.stage5_pass2_contract_version,
            "enumeration_query_contract_version": self.enumeration_query_contract_version,
            "enumeration_case_contract_version": self.enumeration_case_contract_version,
            "enumeration_rules_version": self.enumeration_rules_version,
            "enumeration_golden_version": self.enumeration_golden_version,
            "stage5_pass1_contract_version": self.stage5_pass1_contract_version,
            "doctor_query_contract_version": self.doctor_query_contract_version,
            "query": _safe(self.query),
            "query_id": self.query_id,
            "enumeration_intent": self.enumeration_intent,
            "target_kind": self.target_kind,
            "target_key": self.target_key,
            "scope": _safe(self.scope),
            "population": _safe(self.population),
            "result_buckets": _safe(self.result_buckets),
            "intent_result": _safe(self.intent_result),
            "aggregation": _safe(self.aggregation),
            "presentation": _safe(self.presentation),
            "provenance": _safe(self.provenance),
            "integrity": _safe(self.integrity),
            "status": self.status,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "enumeration_case_fingerprint": self.enumeration_case_fingerprint,
        }


def build_enumeration_case(
    query: DoctorEnumerationQuery,
    *,
    aggregation: Mapping[str, Any],
    provenance: Mapping[str, Any],
    integrity: Mapping[str, Any],
    status: str = "PASS",
    errors: tuple[str, ...] = (),
    warnings: tuple[str, ...] = (),
) -> DoctorEnumerationCase:
    aggregation = dict(aggregation)
    scope = aggregation.get("scope", {})
    query_payload = query.as_dict(include_source=True)
    if isinstance(query_payload.get("candidates"), list):
        query_payload["candidates"] = sorted(
            query_payload["candidates"],
            key=lambda item: int(item.get("id", item.get("member_id", "0")))
            if isinstance(item, Mapping) and str(item.get("id", item.get("member_id", "0"))).isdecimal()
            else 0,
        )
    population_meta = aggregation.get("population", {})
    if isinstance(population_meta, Mapping):
        population_meta = dict(population_meta)
        population_meta.pop("candidate_dispositions", None)
    population = {
        key: aggregation.get(key)
        for key in (
            "population_status_counts",
            "supplied_member_count",
            "normalized_candidate_count",
            "evaluated_candidate_count",
            "excluded_count",
            "duplicate_count",
            "invalid_count",
            "missing_material_data_count",
            "population",
            "candidate_dispositions",
        )
        if key in aggregation
    }
    population["population"] = population_meta
    if isinstance(aggregation.get("population"), Mapping):
        population["candidate_dispositions"] = aggregation["population"].get("candidate_dispositions", [])
    draft = DoctorEnumerationCase(
        stage5_pass2_contract_version=STAGE5_PASS2_CONTRACT_VERSION,
        enumeration_query_contract_version=ENUMERATION_QUERY_CONTRACT_VERSION,
        enumeration_case_contract_version=ENUMERATION_CASE_CONTRACT_VERSION,
        enumeration_rules_version=ENUMERATION_RULES_VERSION,
        enumeration_golden_version=ENUMERATION_GOLDEN_VERSION,
        stage5_pass1_contract_version=query.expected_stage5_pass1_contract,
        doctor_query_contract_version=query.expected_doctor_query_contract,
        query=query_payload,
        query_id=query.query_id,
        enumeration_intent=query.enumeration_intent,
        target_kind=query.target_kind,
        target_key=query.target_key,
        scope=scope,
        population=population,
        result_buckets=aggregation.get("result_buckets", {}),
        intent_result=aggregation.get("intent_result", {}),
        aggregation=aggregation.get("aggregation", {}),
        presentation=aggregation.get("presentation", {}),
        provenance=provenance,
        integrity=integrity,
        status=status,
        errors=tuple(errors),
        warnings=tuple(warnings),
    )
    fingerprint = _fingerprint(draft.as_dict())
    return DoctorEnumerationCase(
        stage5_pass2_contract_version=draft.stage5_pass2_contract_version,
        enumeration_query_contract_version=draft.enumeration_query_contract_version,
        enumeration_case_contract_version=draft.enumeration_case_contract_version,
        enumeration_rules_version=draft.enumeration_rules_version,
        enumeration_golden_version=draft.enumeration_golden_version,
        stage5_pass1_contract_version=draft.stage5_pass1_contract_version,
        doctor_query_contract_version=draft.doctor_query_contract_version,
        query=draft.query,
        query_id=draft.query_id,
        enumeration_intent=draft.enumeration_intent,
        target_kind=draft.target_kind,
        target_key=draft.target_key,
        scope=draft.scope,
        population=draft.population,
        result_buckets=draft.result_buckets,
        intent_result=draft.intent_result,
        aggregation=draft.aggregation,
        presentation=draft.presentation,
        provenance=draft.provenance,
        integrity=draft.integrity,
        status=draft.status,
        errors=draft.errors,
        warnings=draft.warnings,
        enumeration_case_fingerprint=fingerprint,
    )


__all__ = ["DoctorEnumerationCase", "build_enumeration_case"]
