"""Direct Pass 2 routing declarations only; no Discord/network imports."""
from .discord_engine_routing_contract import ROUTES
QUERY_ADAPTER_CONTRACT='GUILD-DOCTOR-DISCORD-QUERY-ADAPTER-0.1'
DIRECT_COMMANDS=tuple(key for key in ROUTES if key!='diagnose')+("server-report",)
def adapt(command_key:str, engine_result:dict, correlation_id:str)->dict:
    if command_key not in DIRECT_COMMANDS: return {'status':'ERROR','stable_error':'STAGE6_ADAPTER_ROUTE_NOT_FOUND','no_write':True}
    if command_key == "server-report": return {'status':'ERROR','stable_error':'REPORT_UNAVAILABLE','no_write':True}
    return {'status':'PASS','request_correlation_id':correlation_id,'command_key':command_key,'engine_route':ROUTES[command_key],'result_state':engine_result.get('result_state'),'primary_reason':engine_result.get('primary_reason'),'source_chain':engine_result.get('source_chain',()),'material_uncertainties':engine_result.get('material_uncertainties',()),'snapshot_warnings':engine_result.get('snapshot_warnings',()),'population_completeness':engine_result.get('population_completeness'),'no_action_attempted':True,'no_write':True,'network_contacted':False}
