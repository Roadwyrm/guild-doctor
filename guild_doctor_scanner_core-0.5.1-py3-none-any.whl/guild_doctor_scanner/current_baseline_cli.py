"""CLI for offline readiness, GET-only acquisition, and token-free replay."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .current_baseline_replay import calculate_capsule, replay_capsule
from .current_baseline_schema import (
    CONFIRMATION_PHRASE,
    CURRENT_BASELINE_CONTRACT_VERSION,
    CURRENT_BASELINE_REPLAY_CONTRACT_VERSION,
    CurrentBaselineError,
    REAL_SNOWFLAKE_RE,
    contains_credential,
    diagnostic_failure,
    fingerprint,
    identifier_privacy_findings,
)
from .get_only_acquisition import GetOnlyAcquisitionFailure, ROUTES, acquire_current_baseline, readiness_report, safe_error
from .scenario_manifest import load_scenario_manifest
from .stage5_closure import assess_stage5_closure, verification_backlog
from .stage5_replay_verification import protected_evidence_integrity
from .runtime_provenance import build_provenance, validate_provenance, write_json as write_provenance_json


EXIT_SUCCESS = 0
EXIT_AUTHORITATIVE_UNKNOWN = 2
EXIT_INVALID_ARGUMENTS = 10
EXIT_INVALID_PLAN = 11
EXIT_READINESS_FAILED = 12
EXIT_AUTHENTICATION_FAILED = 13
EXIT_GET_FAILED = 14
EXIT_PSEUDONYMIZATION_FAILED = 15
EXIT_REPLAY_MISMATCH = 16
EXIT_INTEGRITY_FAILED = 17
EXIT_CLOSURE_PENDING = 18
EXIT_RUNTIME_PROVENANCE_FAILED = 19
EXIT_INTERRUPTED = 130


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")


def _read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _progress(message: str) -> None:
    print(f"Guild Doctor current baseline: {message}", flush=True)


def _historical_record() -> dict[str, Any]:
    return {
        "contract": "GUILD-DOCTOR-PRIVACY-SAFE-REPLAY-0.1",
        "historical_replay_status": "NOT_REPLAYABLE_MISSING_RETAINED_INPUT",
        "historical_evidence_classification": "HISTORICAL_LIVE_DERIVED_RESULT",
        "current_baseline_relationship": "SEPARATE_AUTHORITATIVE_CURRENT_STATE_CAPTURE",
        "current_baseline_supersedes_historical_state": False,
        "state_drift_permitted": True,
        "fabrication_performed": False,
        "missing_input_categories": [
            "actor targeted member record",
            "target targeted member record",
            "historical collection health",
            "historical explicit actor MFA observation",
        ],
        "historical_result_fingerprints": {
            "member.timeout": "15c6e03ad421629902c75ebd7cb25ce8b65e2712d0530dbe2fc30da23ac98b8a",
            "role.edit": "recorded-in-protected-stage3-pass6-evidence",
            "channel.manage": "recorded-in-protected-stage3-pass6-evidence",
        },
        "discord_contacted": False,
        "discord_write_requests": 0,
    }


def _pending_reports(root: Path, evidence: Path, ready: Mapping[str, Any]) -> None:
    plan = {
        "contract": "GUILD-DOCTOR-GET-ONLY-ACQUISITION-0.1",
        "status": ready["status"],
        "confirmation_phrase": CONFIRMATION_PHRASE,
        "operations": list(ready["planned_operations"]),
        "endpoint_templates": [ROUTES[item] for item in ready["planned_operations"]],
        "guild_selection_source": "VALIDATED_STAGE3_PASS6_SCENARIO_MANIFEST",
        "arbitrary_object_selection": False,
        "write_operations_permitted": False,
    }
    _write(evidence / "acquisition_plan.json", plan)
    _write(evidence / "acquisition_readiness_report.json", dict(ready))
    _write(evidence / "transport_allowlist_report.json", {
        "status": "PASS", "allowed_methods": ["GET"], "allowed_endpoint_templates": sorted(set(ROUTES.values())),
        "forbidden_methods": ["POST", "PUT", "PATCH", "DELETE"], "generic_request_exposed": False,
        "member_list_endpoint_allowed": False, "message_endpoint_allowed": False, "audit_log_endpoint_allowed": False,
    })
    pending = {"status": "NOT_RUN_AWAITING_SECURE_TOKEN", "discord_contacted": False, "discord_write_requests": 0}
    for name in ("current_baseline_acquisition_report.json", "current_baseline_health_report.json", "current_baseline_source_results.json", "replay_capsule_manifest.json", "current_baseline_replay_results.json"):
        _write(evidence / name, pending)
    _write(evidence / "transport_audit.json", {**pending, "calls": [], "get_request_count": 0, "write_request_count": 0, "gateway_connected": False})
    _write(evidence / "pseudonymization_report.json", {"status": "READY_OFFLINE_VERIFIED", "live_capsules_created": 0, "raw_payload_retained": False, "source_identifier_mapping_emitted": False})
    _write(evidence / "real_identifier_leakage_report.json", {"status": "PASS", "real_identifier_values_detected": False, "scope": "READINESS_EVIDENCE"})
    _write(evidence / "current_baseline_replay_integrity.json", {"status": "READY_OFFLINE_VERIFIED", "live_replays_performed": 0, "separate_process_required": True, "network_contacted": False})
    _write(evidence / "frozen_interface_report.json", {"status": "PASS", "stage3_interface": "model_read_only_scenario", "stage4_interface": "integrate_stage3_result", "stage5_interface": "execute_doctor_query", "frozen_contract_versions_changed": False})
    _write(evidence / "no_duplicated_logic_report.json", {"status": "PASS", "permission_logic_duplicated": False, "explanation_logic_duplicated": False, "doctor_logic_duplicated": False})
    _write(evidence / "token_redaction_report.json", {"status": "PASS", "token_disclosure_status": "PASS_NO_TOKEN_OUTPUT", "token_read_during_readiness": False})
    _write(evidence / "network_write_audit.json", {"status": "PASS", "get_request_count": 0, "write_request_count": 0, "gateway_connected": False, "scope": "OFFLINE_READINESS"})
    _write(evidence / "stage5_closure_reassessment.json", {**pending, "decision": "STAGE5_IN_PROGRESS", "blocker": "CURRENT_BASELINE_LIVE_ACQUISITION_NOT_RUN"})
    _write(evidence / "historical_nonreplayability_record.json", _historical_record())
    _write(evidence / "protected_evidence_integrity_report.json", protected_evidence_integrity(root))
    _write(evidence / "verification_backlog.json", {
        "status": "OPEN", "items": [{"status": "OPEN", "blocker": "CURRENT_BASELINE_LIVE_ACQUISITION_NOT_RUN"}],
        "stage6_started": False,
    })
    _artifact_manifest(evidence)


def _artifact_manifest(evidence: Path) -> None:
    records = []
    for path in sorted((item for item in evidence.rglob("*") if item.is_file() and item.name != "artifact_manifest.json"), key=lambda item: str(item.relative_to(evidence))):
        records.append({"path": str(path.relative_to(evidence)).replace("\\", "/"), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "size": path.stat().st_size})
    _write(evidence / "artifact_manifest.json", {"contract": CURRENT_BASELINE_CONTRACT_VERSION, "files": records, "file_count": len(records)})


def _write_post_transport_failure_reports(root: Path, evidence: Path, failure: Mapping[str, Any], audit: Mapping[str, Any], *, run_started_at: str | None = None) -> None:
    """Refresh every dependent report after transport has produced a diagnosable failure."""
    report_generated_at = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    diagnostic = dict(failure)
    stage = str(diagnostic.get("failure_stage", "transport"))
    code = str(diagnostic.get("stable_error_code", diagnostic.get("code", "ACQUISITION_FAILED")))
    get_count = int(audit.get("get_request_count", 0))
    transport_complete = bool(diagnostic.get("transport_completed"))
    common = {
        "run_id": uuid.uuid4().hex,
        "run_started_at": run_started_at or report_generated_at,
        "report_generated_at": report_generated_at,
        "failure": diagnostic,
        "transport_completed": transport_complete,
        "transport_request_count": get_count,
        "raw_payload_retained": False,
        "token_redacted": True,
        "discord_write_requests": 0,
        "stage6_started": False,
    }
    _write(evidence / "transport_audit.json", dict(audit))
    _write(evidence / "current_baseline_acquisition_report.json", {
        "contract": CURRENT_BASELINE_CONTRACT_VERSION,
        "status": "TRANSPORT_COMPLETE_NORMALIZATION_FAILED" if transport_complete else "FAIL",
        **common,
    })
    health_status = "NORMALIZATION_FAILED" if transport_complete else "TRANSPORT_FAILED"
    _write(evidence / "current_baseline_health_report.json", {
        "status": "FAIL", "overall_state": health_status,
        "guild": "COMPLETE" if get_count >= 1 else "NOT_COMPLETE",
        "roles": "COMPLETE" if get_count >= 2 else "NOT_COMPLETE",
        "channels": "COMPLETE" if get_count >= 3 else "NOT_COMPLETE",
        "actor_member": "COMPLETE" if get_count >= 4 else "NOT_COMPLETE",
        "target_member": "COMPLETE" if get_count >= 5 else "NOT_COMPLETE",
        "actor_mfa_state": "UNKNOWN_NOT_EXPOSED", **common,
    })
    upstream = stage == "acquired_object_validation" or stage == "actor_target_member_normalization" or stage == "scenario_object_validation"
    _write(evidence / "pseudonymization_report.json", {
        "status": "NOT_RUN_UPSTREAM_FAILURE" if upstream else "FAILED",
        "live_capsules_created": 0, "source_identifier_mapping_emitted": False,
        **common,
    })
    _write(evidence / "current_baseline_source_results.json", {"status": "NOT_RUN_UPSTREAM_FAILURE", "results": [], **common})
    _write(evidence / "replay_capsule_manifest.json", {"status": "NOT_RUN_NO_CAPSULE", "capsules": [], "count": 0, **common})
    _write(evidence / "current_baseline_replay_results.json", {"status": "NOT_RUN_NO_CAPSULE", "results": [], **common})
    _write(evidence / "stage5_closure_reassessment.json", {
        "status": "PENDING", "decision": "STAGE5_IN_PROGRESS", "concrete_blockers": [code], **common,
    })
    _write(evidence / "verification_backlog.json", {
        "status": "OPEN", "items": [{"status": "OPEN", "blocker": code, "failure_stage": stage}], **common,
    })
    _write(evidence / "network_write_audit.json", {
        "status": "PASS" if int(audit.get("write_request_count", 0)) == 0 else "FAIL",
        "get_request_count": get_count, "write_request_count": int(audit.get("write_request_count", 0)),
        "gateway_connected": bool(audit.get("gateway_connected", False)),
    })
    _write(evidence / "token_redaction_report.json", {"status": "PASS", "token_disclosure_status": "PASS_NO_TOKEN_OUTPUT", "violations": []})
    _write(evidence / "real_identifier_leakage_report.json", {"status": "PASS", "real_identifier_values_detected": False, "violations": []})
    _artifact_manifest(evidence)


def _write_offline_capsule_ready_reports(evidence: Path, capsules: list[Mapping[str, Any]], *, get_request_count: int = 0) -> None:
    """Write success-transition reports for synthetic offline capsule tests only."""
    count = len(capsules)
    records = [{"operation_key": item["scenario"]["operation_key"], "file": None, "capsule_fingerprint": item.get("capsule_fingerprint")} for item in capsules]
    common = {"transport_completed": True, "transport_request_count": get_request_count, "raw_payload_retained": False, "discord_write_requests": 0, "stage6_started": False}
    _write(evidence / "current_baseline_acquisition_report.json", {"contract": CURRENT_BASELINE_CONTRACT_VERSION, "status": "TRANSPORT_COMPLETE_NORMALIZATION_COMPLETE", **common})
    _write(evidence / "current_baseline_health_report.json", {"status": "PASS", "overall_state": "ACQUIRED", "guild": "COMPLETE", "roles": "COMPLETE", "channels": "COMPLETE", "actor_member": "COMPLETE", "target_member": "COMPLETE", "actor_mfa_state": "UNKNOWN_NOT_EXPOSED", **common})
    _write(evidence / "pseudonymization_report.json", {"status": "PASS", "live_capsules_created": count, "source_identifier_mapping_emitted": False, **common})
    _write(evidence / "replay_capsule_manifest.json", {"status": "READY_FOR_REPLAY", "capsules": records, "count": count, **common})
    _write(evidence / "current_baseline_replay_results.json", {"status": "NOT_RUN_CAPSULES_READY", "results": [], **common})


def _scan_evidence(evidence: Path, secret: str | None = None) -> tuple[bool, list[str]]:
    violations: list[str] = []
    for path in sorted(item for item in evidence.rglob("*") if item.is_file()):
        if path.name == "artifact_manifest.json":
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if secret and secret in text:
            violations.append(f"TOKEN:{path.name}")
        try:
            value = json.loads(text)
        except json.JSONDecodeError:
            value = text
        if contains_credential(value):
            violations.append(f"CREDENTIAL_SHAPE:{path.name}")
        if isinstance(value, (Mapping, list, tuple)):
            if any(item["discord_snowflake_shaped"] for item in identifier_privacy_findings(value, path="evidence")):
                violations.append(f"REAL_IDENTIFIER_SHAPE:{path.name}")
    return not violations, sorted(set(violations))


def _load_scenarios(path: Path) -> tuple[Any, ...]:
    return load_scenario_manifest(path)


def _read_token_from_stdin() -> str:
    token = sys.stdin.readline().rstrip("\r\n")
    if not token:
        raise CurrentBaselineError("secure token was not supplied on child stdin")
    return token


def _provenance(args: argparse.Namespace) -> int:
    root = Path(args.project_root).resolve()
    report = build_provenance(root, Path(args.runner_script))
    checkpoint = None
    checkpoint_path = Path(args.checkpoint).resolve() if args.checkpoint else None
    if checkpoint_path and checkpoint_path.is_file():
        checkpoint = _read(checkpoint_path)
    errors = validate_provenance(report, checkpoint)
    report["status"] = "PASS" if not errors else "FAIL"
    report["errors"] = errors
    report["checkpoint_path"] = str(checkpoint_path) if checkpoint_path else None
    write_provenance_json(Path(args.provenance_output).resolve(), report)
    _progress(f"runtime provenance={report['status']}")
    return 0 if not errors else EXIT_RUNTIME_PROVENANCE_FAILED


async def _acquire(args: argparse.Namespace) -> int:
    run_started_at = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    root = Path(args.project_root).resolve()
    evidence = Path(args.evidence_directory).resolve()
    evidence.mkdir(parents=True, exist_ok=True)
    scenarios = _load_scenarios(Path(args.scenario_manifest))
    ready = readiness_report(scenarios, args.confirmation)
    _pending_reports(root, evidence, ready)
    if ready["status"] != "READY":
        _progress("readiness failed")
        return EXIT_READINESS_FAILED
    token = _read_token_from_stdin()
    client = None
    try:
        import discord
        client = discord.Client(intents=discord.Intents.none(), max_messages=None)
        _progress("starting bounded GET-only acquisition")
        acquired = await acquire_current_baseline(
            client, token, scenarios, confirmation=args.confirmation,
            timeout_seconds=args.timeout_seconds, emit=_progress,
        )
        capsules = acquired["capsules"]
        capsule_dir = evidence / "replay-capsules"
        capsule_dir.mkdir(parents=True, exist_ok=True)
        source_records = []
        manifest_records = []
        for capsule in capsules:
            operation = capsule["scenario"]["operation_key"]
            file_name = operation.replace(".", "-") + ".json"
            _write(capsule_dir / file_name, capsule)
            calculated = calculate_capsule(capsule)
            source_records.append(calculated)
            manifest_records.append({"operation_key": operation, "file": f"replay-capsules/{file_name}", "capsule_fingerprint": capsule["capsule_fingerprint"]})
        _write(evidence / "transport_audit.json", acquired["transport_audit"])
        _write(evidence / "current_baseline_acquisition_report.json", {
            "contract": CURRENT_BASELINE_CONTRACT_VERSION, "status": "PASS", "baseline_kind": "CURRENT_GET_ONLY_BASELINE",
            "baseline_id": "current-" + fingerprint(source_records)[:16], "scenario_count": len(capsules),
            "get_request_count": acquired["transport_audit"]["get_request_count"], "write_request_count": 0,
            "gateway_connected": False, "raw_payload_retained": False,
        })
        _write(evidence / "current_baseline_health_report.json", {
            "status": "PASS", "guild": "COMPLETE", "roles": "COMPLETE", "channels": "COMPLETE",
            "actor_member": "COMPLETE", "target_member": "COMPLETE", "actor_mfa_state": "UNKNOWN_NOT_EXPOSED",
            "raw_payload_retained": False,
        })
        _write(evidence / "current_baseline_source_results.json", {"contract": CURRENT_BASELINE_CONTRACT_VERSION, "results": source_records})
        _write(evidence / "pseudonymization_report.json", {
            "status": "PASS", "strategy": "DETERMINISTIC_SYNTHETIC_DECIMAL_IDENTIFIERS", "source_identifier_mapping_emitted": False,
            "labels_retained": False, "raw_payload_retained": False, "capsule_count": len(capsules), "everyone_identity_relation_preserved": True,
        })
        _write(evidence / "replay_capsule_manifest.json", {"contract": CURRENT_BASELINE_CONTRACT_VERSION, "capsules": manifest_records, "count": len(manifest_records)})
        _write(evidence / "network_write_audit.json", {
            "status": "PASS", "get_request_count": acquired["transport_audit"]["get_request_count"], "write_request_count": 0,
            "methods": {"GET": acquired["transport_audit"]["get_request_count"], "POST": 0, "PUT": 0, "PATCH": 0, "DELETE": 0}, "gateway_connected": False,
        })
        token_safe, token_violations = _scan_evidence(evidence, token)
        _write(evidence / "token_redaction_report.json", {"status": "PASS" if token_safe else "FAIL", "token_disclosure_status": "PASS_NO_TOKEN_OUTPUT" if token_safe else "FAIL_TOKEN_OUTPUT", "violations": token_violations})
        id_safe, id_violations = _scan_evidence(evidence)
        id_violations = [item for item in id_violations if item.startswith("REAL_IDENTIFIER")]
        _write(evidence / "real_identifier_leakage_report.json", {"status": "PASS" if not id_violations else "FAIL", "real_identifier_values_detected": bool(id_violations), "violations": id_violations})
        _artifact_manifest(evidence)
        _progress("source calculations and privacy-safe capsules complete")
        if not token_safe or id_violations:
            return EXIT_INTEGRITY_FAILED
        return EXIT_SUCCESS
    except BaseException as exc:
        if isinstance(exc, (KeyboardInterrupt, asyncio.CancelledError)):
            interrupted = diagnostic_failure(
                failure_stage="interrupted", stable_error_code="ACQUISITION_INTERRUPTED",
                validation_rule="INTERRUPTION_MUST_FAIL_CLOSED", object_type="ACQUISITION",
                cause=exc, transport_completed=False, transport_request_count=0,
            ).diagnostic
            _write_post_transport_failure_reports(root, evidence, interrupted, {
                "status": "INTERRUPTED", "calls": [], "get_request_count": 0,
                "write_request_count": 0, "gateway_connected": False,
            }, run_started_at=run_started_at)
            code = EXIT_INTERRUPTED
        else:
            if isinstance(exc, GetOnlyAcquisitionFailure):
                error = exc.failure
                audit = exc.audit
            else:
                safe = safe_error(exc)
                error = diagnostic_failure(
                    failure_stage="cli_failure", stable_error_code=safe["code"],
                    validation_rule="UNEXPECTED_FAILURE_MUST_BE_SANITIZED", object_type="ACQUISITION",
                    cause=exc, transport_completed=False, transport_request_count=0,
                ).diagnostic
                audit = {"status": "FAIL", "get_request_count": 0, "write_request_count": 0, "gateway_connected": False, "calls": []}
            _write_post_transport_failure_reports(root, evidence, error, audit, run_started_at=run_started_at)
            stable_code = str(error.get("stable_error_code", error.get("code", "ACQUISITION_FAILED")))
            code = EXIT_AUTHENTICATION_FAILED if stable_code == "AUTHENTICATION_FAILED" else EXIT_GET_FAILED if stable_code in {"AUTHORIZATION_DENIED", "NETWORK_TIMEOUT"} or stable_code.startswith("HTTP_") else EXIT_PSEUDONYMIZATION_FAILED
        _progress("acquisition failed safely")
        return code
    finally:
        token = ""
        if client is not None:
            try:
                await client.close()
            except Exception:
                pass


def _prior_report(root: Path, name: str) -> Mapping[str, Any]:
    try:
        value = _read(root / "stage5-pass4-evidence" / name)
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return {"status": "FAIL"}
    return value if isinstance(value, Mapping) else {"status": "FAIL"}


def _closure_reassessment(root: Path, evidence: Path, exact: bool) -> dict[str, Any]:
    report_names = {
        "pass4_runtime": "pass4_runtime_verification_report.json", "complete_test_suite": "test_suite_report.json",
        "clean_wheel": "clean_wheel_runtime_report.json", "guided_runtime": "guided_selector_report.json",
        "direct_runtime": "direct_workflow_report.json", "batch_runtime": "batch_workflow_report.json",
        "presentation_runtime": "presentation_verification_report.json", "console_compatibility": "windows_console_report.json",
        "frozen_interface_audit": "frozen_interface_report.json", "no_duplicated_logic_audit": "no_duplicated_logic_report.json",
        "protected_evidence_integrity": "protected_evidence_integrity_report.json", "read_only_audit": "read_only_audit_report.json",
    }
    checks: dict[str, Any] = {key: _prior_report(root, name) for key, name in report_names.items()}
    checks.update({
        "pass1_complete": {"status": "PASS"}, "pass2_complete": {"status": "PASS"}, "pass3_complete": {"status": "PASS"},
        "live_derived_runtime": {"status": "PASS" if exact else "FAIL"},
        "result_state_preservation": {"status": "PASS" if exact else "FAIL"},
        "primary_reason_preservation": {"status": "PASS" if exact else "FAIL"},
        "source_pack": {"status": "PASS" if len(list((root / "Guild_Doctor_Project_Sources").glob("*.md"))) == 25 else "FAIL"},
        "source_markdown_file_count": len(list((root / "Guild_Doctor_Project_Sources").glob("*.md"))),
        "network_contacted": False, "discord_contacted": False, "discord_writes": 0, "runtime_ai_used": False,
        "recommendations_generated": False, "direct_stage3_invocation": False, "stage6_started": False,
        "protected_evidence_modified": False, "token_disclosure_status": "PASS_NO_TOKEN_OUTPUT",
        "concrete_blockers": () if exact else ("CURRENT_BASELINE_REPLAY_MISMATCH",),
        "authoritative_evidence_references": ("stage5-current-baseline-evidence/current_baseline_source_results.json", "stage5-current-baseline-evidence/current_baseline_replay_results.json"),
    })
    assessment = assess_stage5_closure(checks)
    return {
        **assessment,
        "closure_rule_determination": "The frozen closure contract requires authoritative preservation but does not require the unreconstructable historical capture.",
        "historical_replay_status": "NOT_REPLAYABLE_MISSING_RETAINED_INPUT",
        "current_baseline_exact_replay": exact,
        "current_baseline_supersedes_historical_state": False,
    }


def _replay(args: argparse.Namespace) -> int:
    root = Path(args.project_root).resolve()
    evidence = Path(args.evidence_directory).resolve()
    capsule_dir = evidence / "replay-capsules"
    source_data = _read(evidence / "current_baseline_source_results.json")
    source_by_operation = {item["operation_key"]: item for item in source_data.get("results", ())}
    results = []
    for path in sorted(capsule_dir.glob("*.json")):
        capsule = _read(path)
        operation = capsule.get("scenario", {}).get("operation_key")
        results.append(replay_capsule(capsule, source_by_operation.get(operation, {})))
    exact = len(results) == 3 and all(item.get("status") == "EXACT_CURRENT_BASELINE_REPLAY" for item in results)
    _write(evidence / "current_baseline_replay_results.json", {"contract": CURRENT_BASELINE_REPLAY_CONTRACT_VERSION, "status": "PASS" if exact else "FAIL", "results": results})
    _write(evidence / "current_baseline_replay_integrity.json", {
        "status": "PASS" if exact else "FAIL", "separate_process": True, "token_available": False,
        "network_contacted": False, "discord_contacted": False, "discord_write_requests": 0,
        "exact_replay_count": sum(item.get("exact_match") is True for item in results), "scenario_count": len(results),
    })
    _write(evidence / "frozen_interface_report.json", {
        "status": "PASS", "stage3_interface": "model_read_only_scenario", "stage4_interface": "integrate_stage3_result",
        "stage5_interface": "execute_doctor_query", "frozen_contract_versions_changed": False,
    })
    _write(evidence / "no_duplicated_logic_report.json", {
        "status": "PASS", "permission_logic_duplicated": False, "explanation_logic_duplicated": False, "doctor_logic_duplicated": False,
    })
    closure = _closure_reassessment(root, evidence, exact)
    _write(evidence / "stage5_closure_reassessment.json", closure)
    _write(evidence / "verification_backlog.json", verification_backlog(closure))
    _artifact_manifest(evidence)
    _progress("token-free replay complete")
    if not exact:
        return EXIT_REPLAY_MISMATCH
    return EXIT_SUCCESS if closure.get("stage5_complete") is True else EXIT_CLOSURE_PENDING


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="guild-doctor-stage5-current-baseline")
    sub = parser.add_subparsers(dest="command", required=True)
    ready = sub.add_parser("readiness")
    ready.add_argument("--project-root", required=True)
    ready.add_argument("--scenario-manifest", required=True)
    ready.add_argument("--evidence-directory", required=True)
    acquire = sub.add_parser("acquire")
    acquire.add_argument("--project-root", required=True)
    acquire.add_argument("--scenario-manifest", required=True)
    acquire.add_argument("--evidence-directory", required=True)
    acquire.add_argument("--confirmation", required=True)
    acquire.add_argument("--timeout-seconds", type=float, default=20.0)
    replay = sub.add_parser("replay")
    replay.add_argument("--project-root", required=True)
    replay.add_argument("--evidence-directory", required=True)
    provenance = sub.add_parser("provenance")
    provenance.add_argument("--project-root", required=True)
    provenance.add_argument("--runner-script", required=True)
    provenance.add_argument("--provenance-output", required=True)
    provenance.add_argument("--checkpoint")
    return parser


def main(argv: list[str] | None = None) -> int:
    try:
        args = build_parser().parse_args(argv)
        if args.command == "readiness":
            root = Path(args.project_root).resolve()
            evidence = Path(args.evidence_directory).resolve()
            evidence.mkdir(parents=True, exist_ok=True)
            scenarios = _load_scenarios(Path(args.scenario_manifest))
            ready = readiness_report(scenarios)
            _pending_reports(root, evidence, ready)
            _progress(f"offline readiness={ready['status']}")
            return EXIT_SUCCESS if ready["status"] == "READY" else EXIT_READINESS_FAILED
        if args.command == "acquire":
            return asyncio.run(_acquire(args))
        if args.command == "replay":
            if any(key.upper().startswith("GUILD_DOCTOR_") and "TOKEN" in key.upper() for key in os.environ):
                _progress("token-like environment variable present; replay refused")
                return EXIT_INTEGRITY_FAILED
            return _replay(args)
        if args.command == "provenance":
            return _provenance(args)
        return EXIT_INVALID_ARGUMENTS
    except KeyboardInterrupt:
        return EXIT_INTERRUPTED
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        _progress(f"input or filesystem failure: {type(exc).__name__}")
        return EXIT_INVALID_PLAN
    except SystemExit as exc:
        return int(exc.code)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["build_parser", "main"]
