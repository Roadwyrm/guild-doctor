"""Immediate deterministic minimization for a GET-only current baseline."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from .current_baseline_schema import (
    CURRENT_BASELINE_CONTRACT_VERSION,
    PRIVACY_SAFE_BASELINE_CONTRACT_VERSION,
    SYNTHETIC_ID_NAMESPACE,
    SYNTHETIC_ID_VERSION,
    CurrentBaselineError,
    CurrentBaselineFailure,
    contains_credential,
    diagnostic_failure,
    fingerprint,
    validate_capsule,
)
from .scenario_manifest import LiveScenario


_FIXED_TIME = "2000-01-01T00:00:00.000Z"
_LABELS = frozenset({"name", "nick", "global_name", "display_name", "username", "description", "topic"})
_ID_KEYS = frozenset({"id", "guild_id", "owner_id", "parent_id", "user_id", "bot_id", "integration_id", "subscription_listing_id"})


def _internal_code(exc: BaseException, prefix: str) -> str:
    return f"{prefix}_INTERNAL_{type(exc).__name__.upper()}"


class _Identities:
    def __init__(self, guild_id: str, source_ids: set[str], kinds: Mapping[str, str]) -> None:
        ordered = sorted((item for item in source_ids if item != guild_id), key=lambda item: (int(item), item))
        self._values = {guild_id: "gd:guild:primary"}
        for index, source in enumerate(ordered, start=2):
            kind = kinds.get(source, "object")
            self._values[source] = f"gd:{kind}:synthetic-{index:03d}"

    def get(self, value: Any, *, field_path: str = "identifier", object_type: str = "IDENTIFIER", scenario_id: str | None = None) -> str:
        text = str(value)
        if text not in self._values:
            code = "PSEUDONYMIZATION_UNMAPPED_OVERWRITE_TARGET" if "overwrite" in field_path else "PSEUDONYMIZATION_UNMAPPED_ROLE_REFERENCE" if "role" in field_path else "PSEUDONYMIZATION_CONTEXT_PARENT_RELATIONSHIP_INVALID" if "parent" in field_path else "PSEUDONYMIZATION_UNMAPPED_IDENTIFIER_REFERENCE"
            raise diagnostic_failure(
                failure_stage="identity_graph", stable_error_code=code,
                validation_rule="IDENTITY_REFERENCE_MUST_BE_IN_GRAPH", object_type=object_type,
                scenario_id=scenario_id, field_path=field_path,
                expected_shape="MAPPED_DECIMAL_SOURCE_REFERENCE", observed_value=value,
                contradictory_fields=("source_reference", "identity_graph"),
                cause=LookupError("unmapped identifier"),
            )
        return self._values[text]


def _failure(*, code: str, rule: str, object_type: str, field_path: str, scenario_id: str | None = None, expected: str = "VALID_CAPSULE_FIELD", observed: Any = None, missing: tuple[str, ...] = (), contradictory: tuple[str, ...] = (), cause: BaseException | None = None) -> CurrentBaselineFailure:
    return diagnostic_failure(
        failure_stage="identity_graph" if code.startswith("PSEUDONYMIZATION_") else "scenario_capsule_assembly",
        stable_error_code=code, validation_rule=rule, object_type=object_type,
        field_path=field_path, scenario_id=scenario_id, expected_shape=expected,
        observed_value=observed, missing_required_fields=missing,
        contradictory_fields=contradictory, cause=cause,
    )


def _source_id(value: Any, *, field_path: str, object_type: str, scenario_id: str | None = None) -> str:
    text = str(value)
    if not text.isdecimal() or int(text) <= 0:
        raise _failure(code="PSEUDONYMIZATION_SYNTHETIC_ID_INVALID", rule="SOURCE_ID_MUST_BE_POSITIVE_DECIMAL", object_type=object_type, field_path=field_path, scenario_id=scenario_id, expected="POSITIVE_DECIMAL_SOURCE_ID", observed=value, cause=ValueError("source id"))
    return text


def _collect_ids(value: Any, *, key: str = "") -> set[str]:
    found: set[str] = set()
    if isinstance(value, Mapping):
        for child_key, child in value.items():
            found.update(_collect_ids(child, key=str(child_key)))
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        for child in value:
            found.update(_collect_ids(child, key=key))
    elif value is not None and (key in _ID_KEYS or key.endswith("_id") or key.endswith("_ids") or key == "roles"):
        text = str(value)
        if text.isdecimal():
            found.add(text)
    return found


def _safe(value: Any, identities: _Identities, *, key: str = "", path: str = "", scenario_id: str | None = None) -> Any:
    if isinstance(value, Mapping):
        return {
            str(child_key): _safe(child, identities, key=str(child_key), path=f"{path}.{child_key}".lstrip("."), scenario_id=scenario_id)
            for child_key, child in sorted(value.items(), key=lambda item: str(item[0]))
            if str(child_key).lower() not in _LABELS and "token" not in str(child_key).lower() and "authorization" not in str(child_key).lower() and not str(child_key).startswith("_")
        }
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [_safe(child, identities, key=key, path=f"{path}[{index}]", scenario_id=scenario_id) for index, child in enumerate(value)]
    if value is not None and (key in _ID_KEYS or key.endswith("_id") or key.endswith("_ids") or key == "roles"):
        text = str(value)
        return identities.get(text, field_path=path or key, object_type="IDENTIFIER", scenario_id=scenario_id) if text.isdecimal() else value
    return value


def _minimal_bundle(raw: Mapping[str, Any], identities: _Identities) -> dict[str, Any]:
    guild = _safe(raw["guild"], identities, path="guild")
    roles = [_safe(item, identities, path=f"roles[{index}]") for index, item in enumerate(sorted(raw["roles"], key=lambda item: int(item["id"])))]
    channels = [_safe(item, identities, path=f"channels[{index}]") for index, item in enumerate(sorted(raw["channels"], key=lambda item: int(item["id"])))]
    channel_ids = {str(item.get("id")) for item in channels if isinstance(item, Mapping)}
    for channel in channels:
        if isinstance(channel, dict) and channel.get("parent_id") not in (None, *channel_ids):
            channel["parent_id"] = None
    members = [_safe(item, identities, path=f"members[{index}]") for index, item in enumerate(sorted(raw["members"], key=lambda item: int(item["user"]["id"])))]
    threads = [_safe(item, identities, path=f"active_threads[{index}]") for index, item in enumerate(sorted(raw.get("active_threads", []), key=lambda item: int(item["id"])))]
    health = {
        key: {"status": "COMPLETE", "expected_count": len(value) if isinstance(value, list) else 1, "received_count": len(value) if isinstance(value, list) else 1, "page_count": 1, "cursor_complete": True, "source_interface": "REST", "error_codes": []}
        for key, value in {"guild": guild, "roles": roles, "channels": channels, "active_threads": threads, "members": members}.items()
    }
    return {
        "scan_profile": "STRUCTURE_BASELINE",
        "started_at": _FIXED_TIME,
        "completed_at": _FIXED_TIME,
        "source_api_version": "10",
        "source_library": "discord.py",
        "source_library_version": "2.7.1",
        "source_adapter_version": "GUILD-DOCTOR-DISCORDPY-ADAPTER-0.2",
        "gateway_connected": False,
        "collection_health": health,
        "guild": guild,
        "roles": roles,
        "channels": channels,
        "active_threads": threads,
        "members": members,
        "requested_guild_id": identities.get(raw["guild"]["id"]),
    }


def _validate_identity_graph(raw: Mapping[str, Any], scenarios: Sequence[LiveScenario], guild_id: str) -> None:
    roles = raw["roles"]
    channels = raw["channels"]
    members = raw["members"]
    role_ids = {str(item.get("id")) for item in roles if isinstance(item, Mapping) and str(item.get("id", "")).isdecimal()}
    member_ids = {str(item.get("user", {}).get("id")) for item in members if isinstance(item, Mapping) and isinstance(item.get("user"), Mapping) and str(item["user"].get("id", "")).isdecimal()}
    channel_ids = {str(item.get("id")) for item in channels if isinstance(item, Mapping) and str(item.get("id", "")).isdecimal()}
    if guild_id not in role_ids:
        raise _failure(code="PSEUDONYMIZATION_EVERYONE_RELATIONSHIP_INVALID", rule="EVERYONE_ROLE_ID_EQUALS_GUILD_ID", object_type="ROLE", field_path="roles.@everyone.id", expected="GUILD_ID_REFERENCE", observed=roles, contradictory=("guild.id", "roles.@everyone.id"), cause=ValueError("everyone relationship"))
    for index, member in enumerate(members):
        assigned = member.get("roles", ()) if isinstance(member, Mapping) else ()
        if not isinstance(assigned, (list, tuple)):
            raise _failure(code="PSEUDONYMIZATION_ACTOR_ROLE_RELATIONSHIP_INVALID", rule="MEMBER_ASSIGNED_ROLES_ARRAY", object_type="MEMBER", field_path=f"members[{index}].roles", expected="ARRAY_OF_ROLE_REFERENCES", observed=assigned, cause=TypeError("assigned roles"))
        for role_index, role_id in enumerate(assigned):
            if str(role_id) not in role_ids:
                raise _failure(code="PSEUDONYMIZATION_UNMAPPED_ROLE_REFERENCE", rule="MEMBER_ROLE_REFERENCE_MUST_EXIST", object_type="MEMBER", field_path=f"members[{index}].roles[{role_index}]", expected="EXISTING_ROLE_REFERENCE", observed=role_id, cause=LookupError("member role"))
    for index, channel in enumerate(channels):
        overwrites = channel.get("permission_overwrites", ()) if isinstance(channel, Mapping) else ()
        if not isinstance(overwrites, (list, tuple)):
            raise _failure(code="PSEUDONYMIZATION_CHANNEL_MANAGE_INVALID", rule="OVERWRITE_COLLECTION_ARRAY", object_type="CHANNEL", field_path=f"channels[{index}].permission_overwrites", expected="ARRAY", observed=overwrites, cause=TypeError("overwrites"))
        for overwrite_index, overwrite in enumerate(overwrites):
            target_id = str(overwrite.get("id")) if isinstance(overwrite, Mapping) else ""
            overwrite_type = overwrite.get("type") if isinstance(overwrite, Mapping) else None
            is_member_target = overwrite_type in (1, "1", "member", "MEMBER")
            is_role_target = overwrite_type in (0, "0", "role", "ROLE")
            if (is_role_target and target_id not in role_ids and target_id != guild_id) or (is_member_target and not target_id.isdecimal()) or (not is_role_target and not is_member_target):
                raise _failure(code="PSEUDONYMIZATION_UNMAPPED_OVERWRITE_TARGET", rule="OVERWRITE_TARGET_MUST_EXIST", object_type="CHANNEL", field_path=f"channels[{index}].permission_overwrites[{overwrite_index}].id", expected="EXISTING_ROLE_OR_MEMBER_REFERENCE", observed=target_id, cause=LookupError("overwrite target"))
    for scenario in scenarios:
        if scenario.actor_member_id not in member_ids:
            raise _failure(code="PSEUDONYMIZATION_ACTOR_ROLE_RELATIONSHIP_INVALID", rule="ACTOR_MEMBER_MUST_EXIST", object_type="ACTOR_MEMBER", field_path="scenario.actor_member_id", scenario_id=scenario.scenario_id, expected="EXISTING_MEMBER_REFERENCE", observed=scenario.actor_member_id, cause=LookupError("actor"))
        if scenario.target_type == "MEMBER" and scenario.target_id not in member_ids:
            raise _failure(code="PSEUDONYMIZATION_TARGET_ROLE_RELATIONSHIP_INVALID", rule="TARGET_MEMBER_MUST_EXIST", object_type="TARGET_MEMBER", field_path="scenario.target_id", scenario_id=scenario.scenario_id, expected="EXISTING_MEMBER_REFERENCE", observed=scenario.target_id, cause=LookupError("target member"))
        if scenario.target_type == "ROLE" and scenario.target_id not in role_ids:
            raise _failure(code="PSEUDONYMIZATION_TARGET_ROLE_RELATIONSHIP_INVALID", rule="TARGET_ROLE_MUST_EXIST", object_type="TARGET_ROLE", field_path="scenario.target_id", scenario_id=scenario.scenario_id, expected="EXISTING_ROLE_REFERENCE", observed=scenario.target_id, cause=LookupError("target role"))
        if scenario.target_type == "CHANNEL" and scenario.target_id not in channel_ids:
            raise _failure(code="PSEUDONYMIZATION_CONTEXT_PARENT_RELATIONSHIP_INVALID", rule="TARGET_CHANNEL_MUST_EXIST", object_type="TARGET_CHANNEL", field_path="scenario.target_id", scenario_id=scenario.scenario_id, expected="EXISTING_CHANNEL_REFERENCE", observed=scenario.target_id, cause=LookupError("target channel"))


def build_current_baseline_capsules(raw: Mapping[str, Any], scenarios: Sequence[LiveScenario]) -> tuple[dict[str, Any], ...]:
    """Return one minimized synthetic capsule per scenario; never return a map."""

    if contains_credential(raw):
        raise _failure(code="PSEUDONYMIZATION_CREDENTIAL_PRESENT", rule="NO_CREDENTIAL_SHAPES_REACH_MINIMIZATION", object_type="CURRENT_BASELINE", field_path="raw", expected="CREDENTIAL_FREE_OBJECT", observed=raw, cause=ValueError("credential"))
    if not isinstance(raw.get("guild"), Mapping) or not isinstance(raw.get("roles"), list) or not isinstance(raw.get("channels"), list) or not isinstance(raw.get("members"), list):
        raise _failure(code="PSEUDONYMIZATION_IDENTITY_GRAPH_INVALID", rule="REQUIRED_NORMALIZED_COLLECTIONS_PRESENT", object_type="IDENTITY_GRAPH", field_path="raw", expected="OBJECT_WITH_GUILD_ROLES_CHANNELS_MEMBERS", observed=raw, cause=TypeError("identity graph"))
    guild_id = _source_id(raw["guild"].get("id"), field_path="guild.id", object_type="GUILD")
    source_ids = _collect_ids(raw)
    kinds: dict[str, str] = {guild_id: "guild"}
    for role in raw["roles"]:
        if isinstance(role, Mapping) and str(role.get("id", "")).isdecimal():
            kinds.setdefault(str(role["id"]), "role")
    for member in raw["members"]:
        if isinstance(member, Mapping) and isinstance(member.get("user"), Mapping) and str(member["user"].get("id", "")).isdecimal():
            kinds.setdefault(str(member["user"]["id"]), "member")
    for channel in raw["channels"]:
        if isinstance(channel, Mapping) and str(channel.get("id", "")).isdecimal():
            kinds.setdefault(str(channel["id"]), "category" if channel.get("type") == 4 else "channel")
    for scenario in scenarios:
        source_ids.update(filter(None, (scenario.guild_id, scenario.actor_member_id, scenario.target_id, scenario.context_id, scenario.thread_id)))
        kinds[scenario.actor_member_id] = "member"
        if scenario.target_id:
            kinds.setdefault(scenario.target_id, {"MEMBER": "member", "ROLE": "role", "CHANNEL": "channel"}.get(scenario.target_type, "object"))
    identities = _Identities(guild_id, source_ids, kinds)
    synthetic_values = list(identities._values.values())
    if len(synthetic_values) != len(set(synthetic_values)) or any(not item.startswith("gd:") or item.isdecimal() for item in synthetic_values):
        raise _failure(code="PSEUDONYMIZATION_ID_COLLISION" if len(synthetic_values) != len(set(synthetic_values)) else "PSEUDONYMIZATION_SYNTHETIC_ID_INVALID", rule="SYNTHETIC_IDENTITIES_MUST_BE_UNIQUE_NON_DECIMAL_SYMBOLS", object_type="IDENTITY_GRAPH", field_path="identities", expected="UNIQUE_TYPED_SYMBOLIC_SYNTHETIC_IDS", observed=synthetic_values, cause=ValueError("synthetic identity"))
    try:
        _validate_identity_graph(raw, scenarios, guild_id)
    except CurrentBaselineFailure:
        raise
    except (KeyError, TypeError, ValueError, AttributeError, IndexError, AssertionError) as exc:
        raise _failure(
            code=_internal_code(exc, "PSEUDONYMIZATION_IDENTITY_GRAPH"),
            rule="UNEXPECTED_EXCEPTION_IN_IDENTITY_GRAPH",
            object_type="IDENTITY_GRAPH", field_path="identity_graph", expected="VALIDATED_NORMALIZED_IDENTITY_GRAPH",
            cause=exc,
        ) from exc
    try:
        bundle = _minimal_bundle(raw, identities)
    except CurrentBaselineFailure:
        raise
    except (KeyError, TypeError, ValueError, AttributeError, IndexError, AssertionError) as exc:
        raise _failure(
            code=_internal_code(exc, "PSEUDONYMIZATION_MINIMIZATION"),
            rule="UNEXPECTED_EXCEPTION_IN_MINIMIZATION",
            object_type="IDENTITY_GRAPH", field_path="minimization", expected="PRIVACY_SAFE_NORMALIZED_BUNDLE",
            cause=exc,
        ) from exc
    capsules: list[dict[str, Any]] = []
    for scenario in scenarios:
        synthetic = {
            "scenario_id": scenario.scenario_id,
            "guild_id": scenario.guild_id,
            "operation_key": scenario.operation_key,
            "actor_member_id": scenario.actor_member_id,
            "target_type": scenario.target_type,
            "target_id": scenario.target_id,
            "context_id": scenario.context_id,
            "thread_id": scenario.thread_id,
            "expected_evidence_classifications": list(scenario.expected_evidence_classifications),
            "expected_structural_facts": {},
            "expected_modeled_result": None,
            "member_acquisition_explicitly_authorized": True,
            "notes": "privacy-safe current baseline",
            "verification_status": "CURRENT_GET_ONLY_BASELINE",
        }
        for field in ("guild_id", "actor_member_id", "target_id", "context_id", "thread_id"):
            if synthetic.get(field) is not None:
                synthetic[field] = identities.get(synthetic[field], field_path=f"scenario.{field}", object_type="SCENARIO_REFERENCE", scenario_id=scenario.scenario_id)
        synthetic["expected_structural_facts"] = {}
        synthetic["expected_modeled_result"] = None
        capsule = {
            "contract": CURRENT_BASELINE_CONTRACT_VERSION,
            "privacy_contract": PRIVACY_SAFE_BASELINE_CONTRACT_VERSION,
            "baseline_kind": "CURRENT_GET_ONLY_BASELINE",
            "scenario": synthetic,
            "bundle": bundle,
            "actor_mfa_state": "UNKNOWN_NOT_EXPOSED",
            "synthetic_identifiers": True,
            "identifier_kind": "SYNTHETIC_SYMBOLIC",
            "identifier_namespace": SYNTHETIC_ID_NAMESPACE,
            "synthetic_id_version": SYNTHETIC_ID_VERSION,
            "source_identifier_mapping_emitted": False,
            "raw_payload_retained": False,
            "gateway_connected": False,
            "discord_write_requests": 0,
        }
        capsule["capsule_fingerprint"] = fingerprint(capsule)
        try:
            errors = validate_capsule(capsule)
        except CurrentBaselineFailure:
            raise
        except (KeyError, TypeError, ValueError, AttributeError, IndexError, AssertionError) as exc:
            raise _failure(
                code=_internal_code(exc, "CAPSULE_SCHEMA"),
                rule="UNEXPECTED_EXCEPTION_IN_CAPSULE_SCHEMA_VALIDATION",
                object_type="CURRENT_BASELINE_CAPSULE", field_path="capsule.schema_validation",
                scenario_id=scenario.scenario_id, expected="VALIDATED_CURRENT_BASELINE_CAPSULE",
                cause=exc,
            ) from exc
        if errors:
            first = errors[0]
            if first == "CAPSULE_FIELD_INVALID:actor_mfa_state":
                code, field = "CAPSULE_MFA_STATE_INVALID", "actor_mfa_state"
            elif first.startswith("REAL_IDENTIFIER") or first.startswith("SYNTHETIC_IDENTIFIER"):
                code, field = "PSEUDONYMIZATION_SYNTHETIC_ID_INVALID", first.split(":", 1)[1] if ":" in first else "capsule"
            elif first == "CREDENTIAL_PRESENT":
                code, field = "PSEUDONYMIZATION_CREDENTIAL_PRESENT", "capsule"
            else:
                code = {"member.timeout": "CAPSULE_MEMBER_TIMEOUT_INVALID", "role.edit": "CAPSULE_ROLE_EDIT_INVALID", "channel.manage": "CAPSULE_CHANNEL_MANAGE_INVALID"}.get(scenario.operation_key, "PSEUDONYMIZATION_CAPSULE_SCHEMA_INVALID")
                field = "capsule"
            raise _failure(code=code, rule="FROZEN_CAPSULE_SCHEMA", object_type="CURRENT_BASELINE_CAPSULE", field_path=field, scenario_id=scenario.scenario_id, expected="VALIDATED_CURRENT_BASELINE_CAPSULE", observed=capsule, contradictory=tuple(errors), cause=ValueError("capsule validation"))
        capsules.append(capsule)
    return tuple(capsules)


__all__ = ["build_current_baseline_capsules"]
