"""Deterministic hypothetical role-set projections for Stage 5 Pass 3."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .canonical import canonical_json
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY
from .constants import KNOWN_PERMISSION_MASK
from .doctor_query import DoctorQuery
from .doctor_role_comparison_query import (
    ACTION,
    CAPABILITY,
    CAPABILITY_SET,
    DEFAULT_PROJECTION_ASSUMPTIONS,
    RAW_PERMISSION,
    RoleComparisonQuery,
    RoleComparisonSubject,
)


SYNTHETIC_DOCTOR_SUBJECT_ID = "1"
PROJECTION_DISCLAIMER = (
    "This is a hypothetical role-set projection, not a real member. "
    "Member-specific overwrites, timeout state, thread membership, human MFA, "
    "voice state, and ownership are not established unless explicitly supplied."
)
ACTION_PROJECTION_DISCLAIMER = (
    "Action comparison is a PRE_EXECUTION_MODEL only; execution_attempted=false "
    "and execution_guarantee=false. No Discord operation was attempted."
)


def _read(value: Any, key: str, default: Any = None) -> Any:
    if isinstance(value, Mapping):
        return value.get(key, default)
    return getattr(value, key, default)


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _records(value: Any) -> tuple[Mapping[str, Any], ...]:
    if isinstance(value, Mapping):
        if "id" in value:
            return (value,)
        return tuple(item for item in value.values() if isinstance(item, Mapping))
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return tuple(item for item in value if isinstance(item, Mapping))
    return ()


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(child) for key, child in sorted(value.items(), key=lambda item: str(item[0]))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(child) for child in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(child) for child in sorted(value, key=str))
    return deepcopy(value)


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _thaw(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [_thaw(child) for child in value]
    return deepcopy(value)


def _int(value: Any) -> int | None:
    try:
        if isinstance(value, bool) or value is None:
            return None
        return int(str(value), 0) if isinstance(value, str) and str(value).lower().startswith("0x") else int(value)
    except (TypeError, ValueError):
        return None


def _guild_id(snapshot: Mapping[str, Any]) -> str | None:
    direct = _snowflake(snapshot.get("guild_id"))
    if direct:
        return direct
    guild = snapshot.get("guild")
    return _snowflake(guild.get("id")) if isinstance(guild, Mapping) else None


def _role_index(snapshot: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    return {
        role_id: role
        for role in _records(snapshot.get("roles"))
        for role_id in (_snowflake(role.get("id")),)
        if role_id is not None
    }


def _everyone_id(snapshot: Mapping[str, Any], roles: Mapping[str, Mapping[str, Any]]) -> str | None:
    for role in roles.values():
        if role.get("is_everyone") is True:
            return _snowflake(role.get("id"))
    return _guild_id(snapshot)


def _projection_id(query: RoleComparisonQuery, subject: RoleComparisonSubject) -> str:
    payload = {
        "query_id": query.query_id,
        "comparison_subject_id": subject.comparison_subject_id,
        "role_ids": list(subject.role_ids),
        "target_kind": query.target_kind,
        "target_key": query.target_key,
        "capability_keys": list(query.capability_keys),
        "context_type": query.context_type,
        "context_id": query.context_id,
        "parent_id": query.parent_id,
        "thread_id": query.thread_id,
    }
    digest = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()[:24]
    return f"synthetic-role-projection-{digest}"


def _effective_role_ids(snapshot: Mapping[str, Any], subject: RoleComparisonSubject, roles: Mapping[str, Mapping[str, Any]]) -> tuple[str, ...]:
    everyone = _everyone_id(snapshot, roles)
    selected = set(subject.role_ids)
    if everyone is not None:
        selected.add(everyone)
    return tuple(sorted(selected, key=lambda value: (int(value) if value.isdecimal() else value)))


def _highest_role(effective_role_ids: Sequence[str], roles: Mapping[str, Mapping[str, Any]]) -> tuple[str | None, int | None]:
    available = [roles[item] for item in effective_role_ids if item in roles]
    if not available:
        return None, None
    selected = max(available, key=lambda role: (_int(role.get("position")) if _int(role.get("position")) is not None else -1, _snowflake(role.get("id")) or ""))
    return _snowflake(selected.get("id")), _int(selected.get("position"))


@dataclass(frozen=True, slots=True)
class RoleProjection:
    """Resolved metadata and explicit limitations for one role-set projection."""

    comparison_subject_id: str
    synthetic_projection_id: str
    doctor_subject_id: str
    explicit_role_ids: tuple[str, ...]
    effective_role_ids: tuple[str, ...]
    resolved_role_records: tuple[Mapping[str, Any], ...]
    everyone_role_id: str | None
    highest_role_id: str | None
    highest_role_position: int | None
    raw_permission_decimal: str | None
    raw_permission_hex: str | None
    known_permission_bits_decimal: str | None
    known_permission_bits_hex: str | None
    unknown_permission_bits_decimal: str | None
    unknown_permission_bits_hex: str | None
    managed_role_ids: tuple[str, ...]
    projection_assumptions: Mapping[str, Any]
    limitations: tuple[str, ...]
    evidence_classification: str
    projection_complete: bool

    @property
    def synthetic_member_record(self) -> dict[str, Any]:
        assumptions = dict(_thaw(self.projection_assumptions))
        return {
            "id": self.doctor_subject_id,
            "guild_id": self._guild_id,
            "role_ids": list(self.effective_role_ids),
            "timeout_state": assumptions.get("timeout_state", "UNKNOWN"),
            "mfa_state": assumptions.get("actor_mfa_state", "UNKNOWN"),
            "bot": None,
            "highest_role_id": self.highest_role_id,
            "highest_role_position": self.highest_role_position,
            "projection_identity": self.synthetic_projection_id,
            "projection_is_real_member": False,
        }

    @property
    def _guild_id(self) -> str | None:
        if self.resolved_role_records:
            value = self.resolved_role_records[0].get("guild_id")
            if _snowflake(value):
                return _snowflake(value)
        return None

    def as_dict(self) -> dict[str, Any]:
        return {
            "comparison_subject_id": self.comparison_subject_id,
            "synthetic_projection_id": self.synthetic_projection_id,
            "doctor_subject_id": self.doctor_subject_id,
            "explicit_role_ids": list(self.explicit_role_ids),
            "effective_role_ids": list(self.effective_role_ids),
            "resolved_role_records": [_thaw(role) for role in self.resolved_role_records],
            "everyone_role_id": self.everyone_role_id,
            "highest_role_id": self.highest_role_id,
            "highest_role_position": self.highest_role_position,
            "raw_permission_decimal": self.raw_permission_decimal,
            "raw_permission_hex": self.raw_permission_hex,
            "known_permission_bits_decimal": self.known_permission_bits_decimal,
            "known_permission_bits_hex": self.known_permission_bits_hex,
            "unknown_permission_bits_decimal": self.unknown_permission_bits_decimal,
            "unknown_permission_bits_hex": self.unknown_permission_bits_hex,
            "managed_role_ids": list(self.managed_role_ids),
            "projection_assumptions": _thaw(self.projection_assumptions),
            "limitations": list(self.limitations),
            "evidence_classification": self.evidence_classification,
            "projection_complete": self.projection_complete,
            "synthetic_member_record": self.synthetic_member_record,
        }


def build_role_projection(query: RoleComparisonQuery, subject: RoleComparisonSubject) -> RoleProjection:
    snapshot = _thaw(query.snapshot) if query.snapshot is not None else {}
    roles = _role_index(snapshot)
    effective_ids = _effective_role_ids(snapshot, subject, roles)
    records = tuple(roles[role_id] for role_id in effective_ids if role_id in roles)
    everyone = _everyone_id(snapshot, roles)
    highest_id, highest_position = _highest_role(effective_ids, roles)
    raw_values = [_int(role.get("permissions_decimal")) for role in records]
    complete_raw = all(value is not None for value in raw_values) and bool(records)
    raw_value = 0
    if complete_raw:
        for value in raw_values:
            raw_value |= int(value or 0)
    known = raw_value & KNOWN_PERMISSION_MASK if complete_raw else None
    unknown = raw_value & ~KNOWN_PERMISSION_MASK if complete_raw else None
    assumptions = _freeze(dict(query.projection_assumptions or DEFAULT_PROJECTION_ASSUMPTIONS))
    limitations = [PROJECTION_DISCLAIMER]
    if assumptions.get("execution_mode") == "PRE_EXECUTION_MODEL" or query.target_kind == ACTION:
        limitations.append(ACTION_PROJECTION_DISCLAIMER)
    if assumptions.get("member_overwrite_policy") == "EXCLUDED":
        limitations.append("Member-specific overwrites are excluded from this role-only projection.")
    if assumptions.get("timeout_state") == "UNKNOWN":
        limitations.append("Timeout state is UNKNOWN unless explicitly supplied.")
    if assumptions.get("membership_state") == "UNKNOWN":
        limitations.append("Thread membership is UNKNOWN unless explicitly supplied.")
    managed = tuple(sorted(role_id for role_id in effective_ids if roles.get(role_id, {}).get("managed") is True))
    return RoleProjection(
        comparison_subject_id=subject.comparison_subject_id,
        synthetic_projection_id=_projection_id(query, subject),
        doctor_subject_id=SYNTHETIC_DOCTOR_SUBJECT_ID,
        explicit_role_ids=tuple(subject.role_ids),
        effective_role_ids=effective_ids,
        resolved_role_records=tuple(_freeze(record) for record in records),
        everyone_role_id=everyone,
        highest_role_id=highest_id,
        highest_role_position=highest_position,
        raw_permission_decimal=str(raw_value) if complete_raw else None,
        raw_permission_hex=format(raw_value, "#x") if complete_raw else None,
        known_permission_bits_decimal=str(known) if known is not None else None,
        known_permission_bits_hex=format(known, "#x") if known is not None else None,
        unknown_permission_bits_decimal=str(unknown) if unknown is not None else None,
        unknown_permission_bits_hex=format(unknown, "#x") if unknown is not None else None,
        managed_role_ids=managed,
        projection_assumptions=assumptions,
        limitations=tuple(dict.fromkeys(limitations)),
        evidence_classification=subject.evidence_classification,
        projection_complete=complete_raw and bool(records),
    )


def _snapshot_record(snapshot: Mapping[str, Any], key: str, identifier: str | None) -> Mapping[str, Any] | None:
    if not identifier:
        return None
    records = _records(snapshot.get(key))
    for record in records:
        if _snowflake(record.get("id")) == identifier:
            return record
    return None


def build_projection_doctor_query(
    query: RoleComparisonQuery,
    projection: RoleProjection,
    *,
    target_kind: str,
    target_key: str,
) -> DoctorQuery:
    """Build the one frozen Pass 1 query used by a projection target."""

    snapshot = _thaw(query.snapshot) if query.snapshot is not None else {}
    assumptions = dict(_thaw(projection.projection_assumptions))
    target_record = None
    if query.target_type == "ROLE":
        target_record = _snapshot_record(snapshot, "roles", query.target_id)
    elif query.target_type == "CHANNEL":
        target_record = _snapshot_record(snapshot, "channels", query.target_id or query.context_id)
    elif query.target_type == "THREAD":
        target_record = _snapshot_record(snapshot, "threads", query.target_id or query.thread_id)
    member = projection.synthetic_member_record
    member["guild_id"] = query.guild_id
    member["id"] = projection.doctor_subject_id
    return DoctorQuery.from_mapping(
        {
            "query_id": f"{query.query_id}:projection:{projection.comparison_subject_id}:{target_key}",
            "query_intent": "EXPLAIN_ACTUAL_RESULT",
            "target_kind": target_kind,
            "target_key": target_key,
            "guild_id": query.guild_id,
            "subject_id": projection.doctor_subject_id,
            "actor_id": projection.doctor_subject_id,
            "target_type": query.target_type,
            "target_id": query.target_id,
            "context_id": query.context_id,
            "context_type": query.context_type,
            "parent_id": query.parent_id,
            "thread_id": query.thread_id,
            "thread_type": query.thread_type,
            "assigned_role_ids": list(projection.effective_role_ids),
            "timeout_state": assumptions.get("timeout_state", "UNKNOWN"),
            "membership_state": assumptions.get("membership_state", "UNKNOWN"),
            "actor_mfa_state": assumptions.get("actor_mfa_state", "UNKNOWN"),
            "guild_mfa_level": assumptions.get("guild_mfa_level", "UNKNOWN"),
            "actor_highest_role_id": projection.highest_role_id,
            "actor_highest_role_position": projection.highest_role_position,
            "target_role_managed": _read(target_record, "managed") if target_record else None,
            "target_role_is_everyone": _read(target_record, "is_everyone") if target_record else None,
            "snapshot": snapshot,
            "member_record": member,
            "target_record": target_record,
            "input_health": {"structural_completeness": "COMPLETE" if projection.projection_complete else "UNKNOWN"},
            "explicitly_supplied_member_health": {"status": "ROLE_PROJECTION"},
            "explicitly_supplied_role_reference_health": {"status": "COMPLETE" if projection.projection_complete else "UNKNOWN"},
            "snapshot_or_fixture_version": query.snapshot.get("fixture_version") if isinstance(query.snapshot, Mapping) else None,
            "explanation_mode": query.explanation_mode,
            "presentation_profile": query.presentation_profile,
            "labels": {"subject": projection.synthetic_projection_id},
            "evidence_classifications": list(query.evidence_classifications),
            "verification_statuses": list(query.verification_statuses),
            "source_references": [*query.source_references, f"role-projection:{projection.comparison_subject_id}"],
        }
    )


__all__ = [
    "ACTION_PROJECTION_DISCLAIMER",
    "PROJECTION_DISCLAIMER",
    "RoleProjection",
    "SYNTHETIC_DOCTOR_SUBJECT_ID",
    "build_projection_doctor_query",
    "build_role_projection",
]
