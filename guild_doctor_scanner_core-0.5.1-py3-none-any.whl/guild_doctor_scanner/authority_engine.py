"""Pure deterministic Stage 3 Pass 5 authority analysis.

Pass 5 keeps capability permission, target authority, hierarchy, MFA,
permission subsets, managed-object restrictions, and operation preconditions
as independent components.  It does not orchestrate them into an action
conclusion and has no Discord, network, token, persistence, command, or write
dependency.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from .authority_registry import (
    AUTHORITY_OPERATIONS_BY_KEY,
    AUTHORITY_RULES_VERSION,
    CHANNEL_SOURCE_URL,
    GUILD_SOURCE_URL,
    OAUTH2_SOURCE_URL,
    PERMISSION_SOURCE_URL,
    RULE_ADMIN_TIMEOUT_PROTECTION,
    RULE_CONTEXT_CONSISTENCY,
    RULE_EVERYONE_ROLE,
    RULE_MANAGED_ROLE,
    RULE_MEMBER_HIERARCHY,
    RULE_OWNER_PROTECTION,
    RULE_PERMISSION_SUBSET,
    RULE_ROLE_HIERARCHY,
    RULE_ROLE_POSITION,
    RULE_TARGET_CHANNEL_EXCEPTION,
    RULE_TARGET_MEMBER_UNRESOLVED,
    RULE_VOICE_AUTHORITY,
    RULE_VOICE_CONNECTION,
    validate_authority_registry,
)
from .capability_engine import FINAL_ALLOWED, FINAL_DENIED, FINAL_INEFFECTIVE, FINAL_NOT_APPLICABLE, FINAL_UNKNOWN
from .capability_registry import CAPABILITY_REGISTRY_VERSION
from .constants import KNOWN_PERMISSION_MASK, PERMISSION_DEFINITION_VERSION, SNAPSHOT_SCHEMA_VERSION
from .fixture_export import STAGE3_FIXTURE_VERSION
from .mfa_rules import (
    ELEVATED_PERMISSION_FLAGS,
    MFA_RULES_REGISTRY,
    MFA_RULES_VERSION,
    TIMEOUT_ONLY_PERMISSION_FLAG,
    is_elevated_permission,
    validate_mfa_rules,
)
from .object_preconditions import OBJECT_PRECONDITIONS_VERSION, validate_object_preconditions
from .permission_engine import BYPASS_ADMINISTRATOR, BYPASS_NONE, BYPASS_OWNER, COMPLETENESS_COMPLETE, COMPLETENESS_PARTIAL, COMPLETENESS_UNKNOWN, STAGE3_PASS1_ENGINE_CONTRACT_VERSION
from .permission_overwrite_engine import STAGE3_PASS2_ENGINE_CONTRACT_VERSION
from .capability_engine import STAGE3_PASS3_ENGINE_CONTRACT_VERSION
from .thread_engine import STAGE3_PASS4_ENGINE_CONTRACT_VERSION


STAGE3_PASS5_ENGINE_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE3-PASS5-0.1"
SUPPORTED_SOURCE_VERSIONS = frozenset({SNAPSHOT_SCHEMA_VERSION, STAGE3_FIXTURE_VERSION})
ACTOR_KINDS = frozenset({"HUMAN", "BOT"})
TARGET_TYPES = frozenset({"MEMBER", "ROLE", "GUILD", "CHANNEL", "OVERWRITE", "VOICE_STATE", "NONE"})
BYPASS_STATES = frozenset({BYPASS_NONE, BYPASS_OWNER, BYPASS_ADMINISTRATOR})
MFA_STATES = frozenset({"ENABLED", "DISABLED", "UNKNOWN", "NOT_APPLICABLE"})
GUILD_MFA_LEVELS = frozenset({"NONE", "ELEVATED", "UNKNOWN"})
AUTHORITY_SCOPES = frozenset({"GUILD", "PARENT_CHANNEL", "TARGET_CHANNEL"})
COMPONENT_STATES = frozenset({FINAL_ALLOWED, FINAL_DENIED, FINAL_UNKNOWN, FINAL_NOT_APPLICABLE})
PRECONDITION_STATES = frozenset({"SATISFIED", "FAILED", "UNKNOWN", "NOT_APPLICABLE", "UNSUPPORTED", "OUT_OF_SCOPE"})
HIERARCHY_STATES = frozenset({"LOWER", "EQUAL", "HIGHER", "UNKNOWN", "NOT_APPLICABLE"})
TRACE_STAGES = (
    "INPUT_VALIDATION", "OPERATION_REGISTRY", "CAPABILITY_PERMISSION_INPUT", "ACTOR_AUTHORITY_INPUT",
    "TARGET_AUTHORITY_INPUT", "OWNER_PROTECTION", "HIERARCHY", "MANAGED_OBJECT", "PERMISSION_SUBSET",
    "MFA", "OBJECT_PRECONDITION", "COMPONENT_RESULTS", "COMPLETENESS",
)
_MISSING = object()


@dataclass(frozen=True, slots=True)
class AuthorityAnalysisRequest:
    operation_key: str | None = None
    guild_id: int | str | None = None
    guild_owner_id: int | str | None = None
    actor_id: int | str | None = None
    actor_kind: str | None = None
    target_type: str | None = None
    target_id: int | str | None = None
    permission_definition_version: str | None = None
    pass1_contract_version: str | None = None
    pass2_contract_version: str | None = None
    pass3_contract_version: str | None = None
    pass4_contract_version: str | None = None
    snapshot_or_fixture_version: str | None = None
    capability_permission_result: Any = None
    capability_result: Any = None
    capability_record: Any = None
    source_capability_key: str | None = None
    required_source_permission_flags: Sequence[str] | None = None
    actor_raw_guild_permissions_decimal: int | str | None = None
    actor_raw_guild_permissions_hex: str | None = None
    actor_raw_context_permissions_decimal: int | str | None = None
    actor_raw_context_permissions_hex: str | None = None
    actor_bypass_state: str | None = None
    actor_highest_role_id: int | str | None = None
    actor_highest_role_position: int | None = None
    actor_role_order_health: Any = None
    actor_is_guild_owner: bool | None = None
    actor_is_bot: bool | None = None
    actor_mfa_state: str | None = None
    target_is_guild_owner: bool | None = None
    target_has_administrator: bool | None = None
    target_highest_role_id: int | str | None = None
    target_highest_role_position: int | None = None
    target_role_managed: bool | None = None
    target_role_tags: Mapping[str, Any] | None = None
    target_role_binding_type: str | None = None
    target_role_is_everyone: bool | None = None
    target_role_source_health: Mapping[str, Any] | None = None
    requested_permission_bits: int | str | None = None
    requested_overwrite_allow_bits: int | str | None = None
    requested_overwrite_deny_bits: int | str | None = None
    actor_authorized_permission_bits: int | str | None = None
    permission_authority_scope: str | None = None
    actor_has_effective_manage_roles_in_target_channel: bool | None = None
    assigned_or_removed_role_id: int | str | None = None
    proposed_role_position: int | None = None
    guild_mfa_level: str | None = None
    relevant_elevated_permission_flag: str | None = None
    mfa_source_health: Mapping[str, Any] | None = None
    target_currently_connected_to_voice: bool | None = None
    source_channel_id: int | str | None = None
    destination_channel_id: int | str | None = None
    actor_can_connect_to_source: bool | None = None
    actor_can_connect_to_destination: bool | None = None
    target_member_id: int | str | None = None
    target_member_is_guild_owner: bool | None = None
    target_member_has_administrator: bool | None = None
    target_member_highest_role_position: int | None = None
    target_member_role_order_health: Any = None
    target_member_hierarchy_result: str | None = None
    context_guild_id: int | str | None = None
    parent_channel_id: int | str | None = None
    target_channel_id: int | str | None = None
    overwrite_guild_id: int | str | None = None
    overwrite_target_id: int | str | None = None
    overwrite_target_type: str | None = None
    input_health: Mapping[str, Any] | None = None
    evidence_classification: str | None = None
    verification_status: str | None = None
    source_references: Sequence[str] | None = None


@dataclass(frozen=True, slots=True)
class OperationPreconditionRecord:
    key: str
    result: str
    rule_id: str
    verification_status: str
    source_input: str
    missing_input: tuple[str, ...]
    source_references: tuple[str, ...]
    notes: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "result": self.result,
            "rule_id": self.rule_id,
            "verification_status": self.verification_status,
            "source_input": self.source_input,
            "missing_input": list(self.missing_input),
            "source_references": list(self.source_references),
            "notes": self.notes,
        }


@dataclass(frozen=True, slots=True)
class AuthorityTraceEvent:
    sequence: int
    stage: str
    details: Mapping[str, Any]

    @property
    def code(self) -> str:
        return self.stage

    def as_dict(self) -> dict[str, Any]:
        return {"sequence": self.sequence, "stage": self.stage, "code": self.stage, "details": _canonicalize(self.details)}


@dataclass(frozen=True, slots=True)
class AuthorityAnalysisResult:
    engine_contract_version: str
    authority_rules_version: str
    object_preconditions_version: str
    mfa_rules_version: str
    pass1_contract_version: str
    pass2_contract_version: str
    pass3_contract_version: str
    pass4_contract_version: str
    capability_registry_version: str
    permission_definition_version: str | None
    snapshot_or_fixture_version: str | None
    guild_id: str | None
    actor_id: str | None
    actor_kind: str | None
    target_type: str | None
    target_id: str | None
    operation_key: str | None
    bypass_state: str | None
    capability_permission: str
    target_authority: str
    hierarchy_result: str
    mfa_precondition: str
    permission_subset_result: str
    managed_object_precondition: str
    operation_object_preconditions: tuple[OperationPreconditionRecord, ...]
    analysis_completeness: str
    actor_highest_role_evidence: Mapping[str, Any]
    target_highest_role_evidence: Mapping[str, Any]
    strict_lower_role_comparison: str
    requested_permissions: Mapping[str, Any]
    actor_authorized_permissions: Mapping[str, Any]
    unauthorized_permission_bits: Mapping[str, Any]
    unknown_permission_bits: Mapping[str, Any]
    source_capability_key: str | None
    source_capability_verification_status: str
    bot_installation_2fa_precondition: str
    reason_codes: tuple[str, ...]
    raw_permission_values_unchanged: bool
    trace: tuple[AuthorityTraceEvent, ...]

    @property
    def capability_permission_result(self) -> str:
        return self.capability_permission

    @property
    def target_authority_result(self) -> str:
        return self.target_authority

    @property
    def hierarchy(self) -> str:
        return self.hierarchy_result

    @property
    def completeness_state(self) -> str:
        return self.analysis_completeness

    def as_dict(self) -> dict[str, Any]:
        return {
            "engine_contract_version": self.engine_contract_version,
            "authority_rules_version": self.authority_rules_version,
            "object_preconditions_version": self.object_preconditions_version,
            "mfa_rules_version": self.mfa_rules_version,
            "pass1_contract_version": self.pass1_contract_version,
            "pass2_contract_version": self.pass2_contract_version,
            "pass3_contract_version": self.pass3_contract_version,
            "pass4_contract_version": self.pass4_contract_version,
            "capability_registry_version": self.capability_registry_version,
            "permission_definition_version": self.permission_definition_version,
            "snapshot_or_fixture_version": self.snapshot_or_fixture_version,
            "guild_id": self.guild_id,
            "actor_id": self.actor_id,
            "actor_kind": self.actor_kind,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "operation_key": self.operation_key,
            "bypass_state": self.bypass_state,
            "capability_permission": self.capability_permission,
            "target_authority": self.target_authority,
            "hierarchy_result": self.hierarchy_result,
            "mfa_precondition": self.mfa_precondition,
            "permission_subset_result": self.permission_subset_result,
            "managed_object_precondition": self.managed_object_precondition,
            "operation_object_preconditions": [item.as_dict() for item in self.operation_object_preconditions],
            "analysis_completeness": self.analysis_completeness,
            "actor_highest_role_evidence": _canonicalize(self.actor_highest_role_evidence),
            "target_highest_role_evidence": _canonicalize(self.target_highest_role_evidence),
            "strict_lower_role_comparison": self.strict_lower_role_comparison,
            "requested_permissions": _canonicalize(self.requested_permissions),
            "actor_authorized_permissions": _canonicalize(self.actor_authorized_permissions),
            "unauthorized_permission_bits": _canonicalize(self.unauthorized_permission_bits),
            "unknown_permission_bits": _canonicalize(self.unknown_permission_bits),
            "source_capability_key": self.source_capability_key,
            "source_capability_verification_status": self.source_capability_verification_status,
            "bot_installation_2fa_precondition": self.bot_installation_2fa_precondition,
            "reason_codes": list(self.reason_codes),
            "raw_permission_values_unchanged": self.raw_permission_values_unchanged,
            "trace": [item.as_dict() for item in self.trace],
            "mfa_registry_difference": MFA_RULES_REGISTRY["source_difference"],
            "elevated_permission_flags": list(ELEVATED_PERMISSION_FLAGS),
        }


def _canonicalize(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _canonicalize(value[key]) for key in sorted(value, key=lambda item: str(item))}
    if isinstance(value, (list, tuple)):
        return [_canonicalize(item) for item in value]
    return value


def _value(record: Any, name: str) -> Any:
    if record is None:
        return _MISSING
    if isinstance(record, Mapping):
        return record.get(name, _MISSING)
    return getattr(record, name, _MISSING)


def _parse_id(value: Any) -> str | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _parse_int(value: Any) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value >= 0 else None
    if isinstance(value, str) and value.strip().isdecimal():
        return int(value.strip())
    return None


def _parse_permission(value: Any) -> tuple[str | None, int | None]:
    parsed = _parse_int(value)
    return (str(parsed), parsed) if parsed is not None else (None, None)


def _normal(value: Any) -> str | None:
    return value.strip().upper() if isinstance(value, str) and value.strip() else None


def _health(value: Any) -> tuple[str, str | None]:
    if value is None:
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_MISSING"
    if not isinstance(value, Mapping):
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID"
    candidates = [value[key] for key in ("status", "completeness", "role_order_health", "source_health") if key in value]
    for candidate in candidates:
        if isinstance(candidate, str):
            state = candidate.strip().upper()
            if state == COMPLETENESS_COMPLETE:
                return COMPLETENESS_COMPLETE, None
            if state in {COMPLETENESS_PARTIAL, "INCOMPLETE", "AMBIGUOUS", "NOT_REQUESTED"}:
                return COMPLETENESS_PARTIAL, "INPUT_HEALTH_INCOMPLETE"
            if state == COMPLETENESS_UNKNOWN:
                return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INCOMPLETE"
    return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID" if candidates else "INPUT_HEALTH_MISSING"


def _bool_state(value: Any) -> bool | None:
    return value if isinstance(value, bool) else None


def _permission_parts(value: int | None) -> dict[str, Any]:
    if value is None:
        return {"decimal": None, "hex": None, "known_decimal": None, "known_hex": None, "unknown_decimal": None, "unknown_hex": None}
    known = value & KNOWN_PERMISSION_MASK
    unknown = value & ~KNOWN_PERMISSION_MASK
    return {"decimal": str(value), "hex": format(value, "#x"), "known_decimal": str(known), "known_hex": format(known, "#x"), "unknown_decimal": str(unknown), "unknown_hex": format(unknown, "#x")}


def _record_list(result: Any) -> list[Any]:
    records: list[Any] = []
    for name in ("effective_capability_records", "ineffective_grant_records", "denied_capability_records", "unknown_capability_records", "inapplicable_capability_records", "policy_only_category_records"):
        value = _value(result, name)
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
            records.extend(value)
    return records


def _find_capability(result: Any, key: str | None) -> Any:
    if key is None:
        return None
    for record in _record_list(result):
        if _value(record, "capability_key") == key:
            return record
    return None


def _result_from_upstream(request: AuthorityAnalysisRequest, source_key: str | None, reasons: set[str]) -> tuple[str, str, Any]:
    direct = request.capability_permission_result
    record = request.capability_record
    source = request.capability_result
    if direct is None and record is None and source is not None:
        if source_key == "thread.message_send":
            direct = _value(source, "final_thread_send_capability_result")
        elif source_key == "thread.manage":
            direct = _value(source, "manage_threads_gate_result")
        elif source_key == "view.channel":
            direct = _value(source, "parent_visibility_result")
        else:
            record = _find_capability(source, source_key)
    if direct is None and record is not None:
        direct = _value(record, "final_result")
        if direct is _MISSING:
            direct = _value(record, "result_state")
    if isinstance(direct, Mapping):
        direct = _upstream_value(direct, ("final_result", "result_state", "result"))
    elif direct is not None and not isinstance(direct, str):
        direct = _upstream_value(direct, ("final_result", "result_state", "result"))
    raw = _normal(direct)
    verification = _value(record, "verification_status") if record is not None else _value(source, "verification_status")
    verification_out = verification if isinstance(verification, str) else "UNKNOWN"
    if raw == FINAL_ALLOWED:
        return FINAL_ALLOWED, verification_out, record
    if raw in {FINAL_DENIED, FINAL_INEFFECTIVE}:
        if raw == FINAL_INEFFECTIVE:
            reasons.add("CAPABILITY_PERMISSION_INEFFECTIVE")
        return FINAL_DENIED, verification_out, record
    if raw == FINAL_NOT_APPLICABLE:
        return FINAL_NOT_APPLICABLE, verification_out, record
    if raw not in {None, FINAL_UNKNOWN}:
        reasons.add("CAPABILITY_PERMISSION_RESULT_INVALID")
    if direct is None and record is None and source is None:
        reasons.add("CAPABILITY_PERMISSION_EVIDENCE_MISSING")
    return FINAL_UNKNOWN, verification_out, record


def _precondition(key: str, result: str, rule_id: str, status: str, source: str, missing: Sequence[str] = (), refs: Sequence[str] = (), notes: str = "") -> OperationPreconditionRecord:
    return OperationPreconditionRecord(key, result, rule_id, status, source, tuple(sorted(set(missing))), tuple(sorted(set(refs or (PERMISSION_SOURCE_URL,)))), notes)


def _parse_permission_token(value: Any) -> tuple[str | None, int | None]:
    """Parse a decimal or hexadecimal permission value without changing it."""

    if value is None or isinstance(value, bool):
        return None, None
    if isinstance(value, int):
        return (str(value), value) if value >= 0 else (None, None)
    if isinstance(value, str):
        token = value.strip().lower()
        try:
            if token.startswith("0x"):
                parsed = int(token, 16)
            elif token.isdecimal():
                parsed = int(token, 10)
            else:
                return None, None
        except ValueError:
            return None, None
        return (str(parsed), parsed) if parsed >= 0 else (None, None)
    return None, None


def _upstream_value(source: Any, names: Sequence[str]) -> Any:
    for name in names:
        value = _value(source, name)
        if value is not _MISSING and value is not None:
            return value
    return None


def _source_version(source: Any, names: Sequence[str]) -> str | None:
    value = _upstream_value(source, names)
    return value if isinstance(value, str) else None


def _verification(value: Any, fallback: str = "VERIFIED") -> str:
    return value if isinstance(value, str) and value.strip() else fallback


def _state(value: Any, allowed: Sequence[str]) -> str | None:
    normalized = _normal(value)
    return normalized if normalized in set(allowed) else None


def _mfa_level(value: Any) -> str:
    normalized = _normal(value)
    if normalized in {"NONE", "DISABLED", "0"}:
        return "NONE"
    if normalized in {"ELEVATED", "ENABLED", "1"}:
        return "ELEVATED"
    return "UNKNOWN"


def _compare_positions(actor: int | None, target: int | None) -> tuple[str, str]:
    if actor is None or target is None:
        return "UNKNOWN", FINAL_UNKNOWN
    if target < actor:
        return "LOWER", FINAL_ALLOWED
    if target == actor:
        return "EQUAL", FINAL_DENIED
    return "HIGHER", FINAL_DENIED


def _permission_result_map(value: int | None) -> dict[str, Any]:
    return _permission_parts(value)


def _unique_reasons(values: Sequence[str]) -> tuple[str, ...]:
    return tuple(sorted({item for item in values if isinstance(item, str) and item}))


def evaluate_authority_analysis(request: AuthorityAnalysisRequest | Mapping[str, Any]) -> AuthorityAnalysisResult:
    """Evaluate independent Pass 5 authority components deterministically.

    The evaluator consumes caller-supplied evidence only.  It performs no
    Discord calls and never infers that an operation was carried out.
    """

    if isinstance(request, Mapping):
        request = AuthorityAnalysisRequest(**dict(request))
    if not isinstance(request, AuthorityAnalysisRequest):
        raise TypeError("request must be AuthorityAnalysisRequest or a mapping")

    reasons: set[str] = set()
    source = request.capability_result
    operation_key = request.operation_key.strip() if isinstance(request.operation_key, str) and request.operation_key.strip() else None
    if operation_key not in AUTHORITY_OPERATIONS_BY_KEY and isinstance(operation_key, str) and operation_key.lower() in AUTHORITY_OPERATIONS_BY_KEY:
        operation_key = operation_key.lower()
    operation = AUTHORITY_OPERATIONS_BY_KEY.get(operation_key)
    guild_id = _parse_id(request.guild_id)
    actor_id = _parse_id(request.actor_id)
    target_id = _parse_id(request.target_id)
    actor_kind = _normal(request.actor_kind)
    target_type = _normal(request.target_type)
    if guild_id is None:
        reasons.add("GUILD_ID_INVALID")
    if actor_id is None:
        reasons.add("ACTOR_ID_INVALID")
    if operation is None:
        reasons.add("OPERATION_KEY_UNSUPPORTED" if operation_key else "OPERATION_KEY_MISSING")
    if actor_kind not in ACTOR_KINDS:
        reasons.add("ACTOR_KIND_INVALID")
    if target_type not in TARGET_TYPES:
        reasons.add("TARGET_TYPE_INVALID")
    if operation is not None and target_type not in operation.target_types:
        reasons.add("TARGET_TYPE_OPERATION_MISMATCH")
    if target_type not in {None, "NONE"} and target_id is None:
        reasons.add("TARGET_ID_MISSING")
    if target_type == "NONE" and target_id is not None:
        reasons.add("TARGET_ID_NOT_APPLICABLE")

    source_version = request.snapshot_or_fixture_version or _source_version(source, ("snapshot_or_fixture_version", "fixture_version"))
    permission_version = request.permission_definition_version or _source_version(source, ("permission_definition_version",))
    pass1_version = request.pass1_contract_version or _source_version(source, ("pass1_contract_version",))
    pass2_version = request.pass2_contract_version or _source_version(source, ("pass2_contract_version",))
    pass3_version = request.pass3_contract_version or _source_version(source, ("pass3_contract_version",))
    pass4_version = request.pass4_contract_version or _source_version(source, ("pass4_contract_version",))
    expected_versions = (
        ("permission_definition_version", permission_version, PERMISSION_DEFINITION_VERSION),
        ("snapshot_or_fixture_version", source_version, SUPPORTED_SOURCE_VERSIONS),
        ("pass1_contract_version", pass1_version, STAGE3_PASS1_ENGINE_CONTRACT_VERSION),
        ("pass2_contract_version", pass2_version, STAGE3_PASS2_ENGINE_CONTRACT_VERSION),
        ("pass3_contract_version", pass3_version, STAGE3_PASS3_ENGINE_CONTRACT_VERSION),
        ("pass4_contract_version", pass4_version, STAGE3_PASS4_ENGINE_CONTRACT_VERSION),
    )
    for name, value, expected in expected_versions:
        if value is None:
            reasons.add(f"{name.upper()}_MISSING")
        elif isinstance(expected, str) and value != expected:
            reasons.add(f"{name.upper()}_MISMATCH")
        elif isinstance(expected, (set, frozenset)) and value not in expected:
            reasons.add("SOURCE_VERSION_UNSUPPORTED")

    if source is not None:
        upstream_completeness = _normal(_value(source, "completeness_state"))
        if upstream_completeness is not None and upstream_completeness != COMPLETENESS_COMPLETE:
            reasons.add("UPSTREAM_CAPABILITY_INCOMPLETE")
        upstream_health = _normal(_value(source, "input_health_state"))
        if upstream_health is not None and upstream_health != COMPLETENESS_COMPLETE:
            reasons.add("UPSTREAM_INPUT_HEALTH_INCOMPLETE")
        upstream_guild_id = _parse_id(_value(source, "guild_id"))
        if upstream_guild_id is not None and guild_id is not None and upstream_guild_id != guild_id:
            reasons.add("UPSTREAM_GUILD_ID_MISMATCH")

    health_state, health_reason = _health(request.input_health)
    if health_reason:
        reasons.add(health_reason)
    if health_state == COMPLETENESS_PARTIAL:
        reasons.add("INPUT_HEALTH_INCOMPLETE")

    owner_id = _parse_id(request.guild_owner_id)
    actor_owner_derived = actor_id is not None and owner_id is not None and actor_id == owner_id
    actor_owner = request.actor_is_guild_owner if isinstance(request.actor_is_guild_owner, bool) else actor_owner_derived if owner_id is not None else None
    if isinstance(request.actor_is_guild_owner, bool) and owner_id is not None and request.actor_is_guild_owner != actor_owner_derived:
        reasons.add("ACTOR_OWNER_ID_MISMATCH")
    target_owner_derived = target_id is not None and owner_id is not None and target_id == owner_id
    target_owner = request.target_is_guild_owner if isinstance(request.target_is_guild_owner, bool) else target_owner_derived if owner_id is not None else None
    if isinstance(request.target_is_guild_owner, bool) and owner_id is not None and request.target_is_guild_owner != target_owner_derived:
        reasons.add("TARGET_OWNER_ID_MISMATCH")
    if actor_kind == "BOT" and request.actor_is_bot is False:
        reasons.add("ACTOR_BOT_FLAG_MISMATCH")
    if actor_kind == "HUMAN" and request.actor_is_bot is True:
        reasons.add("ACTOR_BOT_FLAG_MISMATCH")

    actor_raw_dec_text, actor_raw_dec = _parse_permission_token(request.actor_raw_guild_permissions_decimal)
    _, actor_raw_hex = _parse_permission_token(request.actor_raw_guild_permissions_hex)
    if request.actor_raw_guild_permissions_decimal is not None and actor_raw_dec is None:
        reasons.add("ACTOR_RAW_GUILD_PERMISSION_INVALID")
    if request.actor_raw_guild_permissions_hex is not None and actor_raw_hex is None:
        reasons.add("ACTOR_RAW_GUILD_PERMISSION_HEX_INVALID")
    if actor_raw_dec is not None and actor_raw_hex is not None and actor_raw_dec != actor_raw_hex:
        reasons.add("ACTOR_RAW_GUILD_PERMISSION_MISMATCH")
    actor_context_text, actor_context = _parse_permission_token(request.actor_raw_context_permissions_decimal)
    _, actor_context_hex = _parse_permission_token(request.actor_raw_context_permissions_hex)
    if request.actor_raw_context_permissions_decimal is not None and actor_context is None:
        reasons.add("ACTOR_RAW_CONTEXT_PERMISSION_INVALID")
    if request.actor_raw_context_permissions_hex is not None and actor_context_hex is None:
        reasons.add("ACTOR_RAW_CONTEXT_PERMISSION_HEX_INVALID")
    if actor_context is not None and actor_context_hex is not None and actor_context != actor_context_hex:
        reasons.add("ACTOR_RAW_CONTEXT_PERMISSION_MISMATCH")
    actor_authorized_text, actor_authorized = _parse_permission_token(request.actor_authorized_permission_bits)
    if request.actor_authorized_permission_bits is not None and actor_authorized is None:
        reasons.add("ACTOR_AUTHORIZED_PERMISSION_INVALID")

    bypass = _normal(request.actor_bypass_state)
    if bypass is None:
        if actor_owner is True:
            bypass = BYPASS_OWNER
        elif actor_raw_dec is not None and actor_raw_dec & (1 << 3):
            bypass = BYPASS_ADMINISTRATOR
        else:
            reasons.add("BYPASS_STATE_MISSING")
    elif bypass not in BYPASS_STATES:
        reasons.add("BYPASS_STATE_INVALID")
    if actor_owner is True and bypass not in {None, BYPASS_OWNER}:
        reasons.add("BYPASS_STATE_OWNER_MISMATCH")
    if actor_owner is False and bypass == BYPASS_OWNER:
        reasons.add("BYPASS_STATE_OWNER_MISMATCH")

    role_health, role_health_reason = _health(request.actor_role_order_health)
    target_role_health, target_role_health_reason = _health(request.target_role_source_health)
    if operation is not None and operation.hierarchy_subject != "NONE" and role_health_reason:
        reasons.add("ACTOR_ROLE_ORDER_HEALTH_MISSING" if role_health_reason == "INPUT_HEALTH_MISSING" else role_health_reason)

    source_key = request.source_capability_key or operation.capability_key if operation is not None else request.source_capability_key
    if operation is not None and request.source_capability_key and request.source_capability_key != operation.capability_key:
        reasons.add("SOURCE_CAPABILITY_KEY_MISMATCH")
    required_flags = tuple(request.required_source_permission_flags or (operation.required_source_permission_flags if operation else ()))
    if operation is not None and request.required_source_permission_flags is not None and tuple(request.required_source_permission_flags) != operation.required_source_permission_flags:
        reasons.add("SOURCE_PERMISSION_REQUIREMENTS_MISMATCH")
    capability, capability_verification, capability_record = _result_from_upstream(request, source_key, reasons)

    operation_object_preconditions: list[OperationPreconditionRecord] = []
    trace_rows: list[tuple[int, str, str, str, str, AuthorityTraceEvent]] = []
    actor_evidence = {
        "role_id": _parse_id(request.actor_highest_role_id),
        "position": request.actor_highest_role_position if isinstance(request.actor_highest_role_position, int) and request.actor_highest_role_position >= 0 else None,
        "role_order_health": role_health,
        "is_guild_owner": actor_owner,
        "is_bot": actor_kind == "BOT" if actor_kind in ACTOR_KINDS else None,
    }
    target_evidence = {
        "role_id": _parse_id(request.target_highest_role_id),
        "position": request.target_highest_role_position if isinstance(request.target_highest_role_position, int) and request.target_highest_role_position >= 0 else None,
        "role_order_health": target_role_health,
        "is_guild_owner": target_owner,
        "managed": request.target_role_managed if isinstance(request.target_role_managed, bool) else None,
        "is_everyone": request.target_role_is_everyone if isinstance(request.target_role_is_everyone, bool) else None,
    }

    def trace(stage: str, component: str, previous: str, new: str, rule_id: str, source_input: str, missing: Sequence[str] = (), verification: str = "VERIFIED") -> None:
        if previous == new:
            return
        details = {
            "guild_id": guild_id,
            "actor_id": actor_id,
            "operation_key": operation_key,
            "target_type": target_type,
            "target_id": target_id,
            "component": component,
            "previous_result": previous,
            "new_result": new,
            "rule_id": rule_id,
            "verification_status": verification,
            "source_input": source_input,
            "missing_input": list(sorted(set(missing))),
            "raw_permission_values_unchanged": True,
        }
        stage_index = TRACE_STAGES.index(stage) if stage in TRACE_STAGES else len(TRACE_STAGES)
        event = AuthorityTraceEvent(0, stage, details)
        trace_rows.append((stage_index, component, operation_key or "", rule_id, target_id or "", event))

    trace("CAPABILITY_PERMISSION_INPUT", "capability_permission", FINAL_UNKNOWN, capability, "DEP-CAPABILITY-PERMISSION-001", "capability evidence", ("capability_permission_result",) if capability == FINAL_UNKNOWN else (), capability_verification)

    def add_precondition(record: OperationPreconditionRecord) -> None:
        operation_object_preconditions.append(record)
        trace("OBJECT_PRECONDITION", record.key, "UNSET", record.result, record.rule_id, record.source_input, record.missing_input, record.verification_status)

    target_authority = FINAL_NOT_APPLICABLE
    target_rule = RULE_OWNER_PROTECTION
    target_missing: list[str] = []
    if operation is not None and operation.target_owner_protected and operation.target_administrator_protected:
        target_rule = RULE_OWNER_PROTECTION
        if target_owner is True or request.target_has_administrator is True:
            target_authority = FINAL_DENIED
        elif target_owner is False and request.target_has_administrator is False:
            target_authority = FINAL_ALLOWED
        else:
            target_authority = FINAL_UNKNOWN
            if target_owner is None:
                target_missing.append("target_is_guild_owner")
            if request.target_has_administrator is None:
                target_missing.append("target_has_administrator")
            reasons.add("TARGET_PROTECTION_EVIDENCE_MISSING")
    elif operation is not None and operation.target_owner_protected:
        target_rule = RULE_OWNER_PROTECTION
        if target_owner is True:
            target_authority = FINAL_DENIED
        elif target_owner is False:
            target_authority = FINAL_ALLOWED
        else:
            target_authority = FINAL_UNKNOWN
            target_missing.append("target_is_guild_owner")
            reasons.add("TARGET_OWNER_PROTECTION_EVIDENCE_MISSING")
    elif operation is not None and operation.target_administrator_protected:
        target_rule = RULE_ADMIN_TIMEOUT_PROTECTION
        if request.target_has_administrator is True:
            target_authority = FINAL_DENIED
        elif request.target_has_administrator is False:
            target_authority = FINAL_ALLOWED
        else:
            target_authority = FINAL_UNKNOWN
            target_missing.append("target_has_administrator")
            reasons.add("TARGET_ADMINISTRATOR_PROTECTION_EVIDENCE_MISSING")
    elif operation is not None and operation.target_types == ("ROLE",):
        target_rule = RULE_EVERYONE_ROLE
        if request.target_role_is_everyone is True:
            target_authority = FINAL_DENIED
        elif request.target_role_is_everyone is False:
            target_authority = FINAL_ALLOWED
        else:
            target_authority = FINAL_UNKNOWN
            target_missing.append("target_role_is_everyone")
            reasons.add("EVERYONE_ROLE_EVIDENCE_MISSING")
    trace("TARGET_AUTHORITY_INPUT", "target_authority", FINAL_NOT_APPLICABLE, target_authority, target_rule, "target protection fields", target_missing)
    if operation is not None and operation.target_owner_protected:
        add_precondition(_precondition("target_owner_protection", "FAILED" if target_authority == FINAL_DENIED else "SATISFIED" if target_authority == FINAL_ALLOWED else "UNKNOWN", RULE_OWNER_PROTECTION, "VERIFIED" if target_authority != FINAL_UNKNOWN else "UNKNOWN", "target_is_guild_owner", target_missing, operation.source_references))
    if operation is not None and operation.target_administrator_protected:
        admin_result = "FAILED" if request.target_has_administrator is True else "SATISFIED" if request.target_has_administrator is False else "UNKNOWN"
        add_precondition(_precondition("target_administrator_timeout_protection", admin_result, RULE_ADMIN_TIMEOUT_PROTECTION, "VERIFIED" if admin_result != "UNKNOWN" else "UNKNOWN", "target_has_administrator", ("target_has_administrator",) if request.target_has_administrator is None else (), operation.source_references))
    if operation is not None and operation.target_types == ("ROLE",):
        add_precondition(_precondition("everyone_role", "FAILED" if target_authority == FINAL_DENIED else "SATISFIED" if target_authority == FINAL_ALLOWED else "UNKNOWN", RULE_EVERYONE_ROLE, "VERIFIED" if target_authority != FINAL_UNKNOWN else "UNKNOWN", "target_role_is_everyone", target_missing, operation.source_references))

    hierarchy = FINAL_NOT_APPLICABLE
    strict_comparison = "NOT_APPLICABLE"
    hierarchy_missing: list[str] = []
    hierarchy_rule = RULE_MEMBER_HIERARCHY
    if operation is not None and operation.hierarchy_subject in {"MEMBER", "ROLE", "PROPOSED_ROLE"}:
        hierarchy_rule = RULE_MEMBER_HIERARCHY if operation.hierarchy_subject == "MEMBER" else RULE_ROLE_HIERARCHY
        target_position = request.target_highest_role_position if operation.hierarchy_subject != "PROPOSED_ROLE" else request.proposed_role_position
        actor_position = actor_evidence["position"]
        if actor_owner is True and target_owner is False and request.target_role_managed is not True and operation.hierarchy_subject != "PROPOSED_ROLE":
            hierarchy = FINAL_ALLOWED
            strict_comparison = "NOT_APPLICABLE" if actor_position is None or target_position is None else _compare_positions(actor_position, target_position)[0]
        elif role_health != COMPLETENESS_COMPLETE:
            hierarchy = FINAL_UNKNOWN
            hierarchy_missing.append("actor_role_order_health")
        elif actor_position is None or target_position is None:
            hierarchy = FINAL_UNKNOWN
            hierarchy_missing.extend([name for name, value in (("actor_highest_role_position", actor_position), ("target_highest_role_position" if operation.hierarchy_subject != "PROPOSED_ROLE" else "proposed_role_position", target_position)) if value is None])
            if operation.hierarchy_subject == "PROPOSED_ROLE" and target_position is None:
                reasons.add("PROPOSED_ROLE_POSITION_MISSING")
        else:
            strict_comparison, hierarchy = _compare_positions(actor_position, target_position)
        trace("HIERARCHY", "hierarchy_result", FINAL_NOT_APPLICABLE, hierarchy, hierarchy_rule, "role positions", hierarchy_missing)
    else:
        trace("HIERARCHY", "hierarchy_result", FINAL_NOT_APPLICABLE, hierarchy, hierarchy_rule, "operation registry")

    managed = "NOT_APPLICABLE"
    if operation is not None and operation.managed_object_kind != "NONE":
        if request.target_role_managed is None:
            managed = "UNKNOWN"
            missing = ("target_role_managed",)
            verification = "UNKNOWN"
            reasons.add("MANAGED_ROLE_EVIDENCE_MISSING")
        elif request.target_role_managed is False:
            managed = "SATISFIED"
            missing = ()
            verification = "VERIFIED"
        elif operation.managed_object_kind == "ROLE_REORDER":
            managed = "UNKNOWN"
            missing = ()
            verification = "NEEDS_TEST"
            reasons.add("MANAGED_ROLE_REORDER_NEEDS_TEST")
        else:
            managed = "FAILED"
            missing = ()
            verification = "VERIFIED"
        trace("MANAGED_OBJECT", "managed_object_precondition", "NOT_APPLICABLE", managed, RULE_MANAGED_ROLE, "target_role_managed", missing, verification)
        add_precondition(_precondition("managed_role", managed, RULE_MANAGED_ROLE, verification, "target_role_managed", missing, operation.source_references))
    else:
        trace("MANAGED_OBJECT", "managed_object_precondition", "NOT_APPLICABLE", managed, RULE_MANAGED_ROLE, "operation registry")

    requested_value: int | None = None
    requested_missing = False
    subset = "NOT_APPLICABLE"
    requested_permissions: dict[str, Any] = _permission_result_map(None)
    authorized_permissions: dict[str, Any] = _permission_result_map(None)
    unauthorized_permissions: dict[str, Any] = _permission_result_map(None)
    unknown_permissions: dict[str, Any] = _permission_result_map(None)
    if operation is not None and operation.subset_kind != "NONE":
        scope = _normal(request.permission_authority_scope) or ("TARGET_CHANNEL" if operation.subset_kind == "OVERWRITE_PERMISSIONS" else "GUILD")
        if scope not in AUTHORITY_SCOPES:
            subset = "UNKNOWN"
            reasons.add("PERMISSION_AUTHORITY_SCOPE_INVALID")
        else:
            allow_text, allow = _parse_permission_token(request.requested_overwrite_allow_bits)
            deny_text, deny = _parse_permission_token(request.requested_overwrite_deny_bits)
            if operation.subset_kind == "ROLE_PERMISSIONS":
                requested_text, requested_value = _parse_permission_token(request.requested_permission_bits)
                if request.requested_permission_bits is not None and requested_value is None:
                    reasons.add("REQUESTED_PERMISSION_BITS_INVALID")
            else:
                if request.requested_overwrite_allow_bits is None and request.requested_overwrite_deny_bits is None:
                    requested_value = _parse_permission_token(request.requested_permission_bits)[1] if request.requested_permission_bits is not None else None
                    if request.requested_permission_bits is not None and requested_value is None:
                        reasons.add("REQUESTED_OVERWRITE_BITS_INVALID")
                elif (request.requested_overwrite_allow_bits is not None and allow is None) or (request.requested_overwrite_deny_bits is not None and deny is None):
                    reasons.add("REQUESTED_OVERWRITE_BITS_INVALID")
                else:
                    requested_value = (allow or 0) | (deny or 0)
                    if allow is not None and deny is not None and allow & deny:
                        subset = "FAILED"
                        reasons.add("OVERWRITE_ALLOW_DENY_COLLISION")
            requested_permissions = _permission_result_map(requested_value)
            if requested_value is None and not reasons.intersection({"REQUESTED_PERMISSION_BITS_INVALID", "REQUESTED_OVERWRITE_BITS_INVALID"}):
                subset = "NOT_APPLICABLE"
            elif requested_value is not None and requested_value == 0 and subset != "FAILED":
                subset = "SATISFIED"
            elif requested_value is None:
                subset = "UNKNOWN"
                requested_missing = True
            if scope == "TARGET_CHANNEL":
                if request.actor_has_effective_manage_roles_in_target_channel is False:
                    subset = "FAILED"
                    reasons.add("TARGET_CHANNEL_MANAGE_ROLES_DENIED")
                elif request.actor_has_effective_manage_roles_in_target_channel is None and requested_value not in {None, 0}:
                    subset = "UNKNOWN"
                    reasons.add("TARGET_CHANNEL_MANAGE_ROLES_UNKNOWN")
            if subset != "FAILED" and requested_value not in {None, 0}:
                if bypass in {BYPASS_OWNER, BYPASS_ADMINISTRATOR}:
                    authorized_value = KNOWN_PERMISSION_MASK
                elif actor_authorized is not None:
                    authorized_value = actor_authorized
                elif scope == "TARGET_CHANNEL":
                    authorized_value = actor_context
                else:
                    authorized_value = actor_raw_dec
                authorized_permissions = _permission_result_map(authorized_value)
                if authorized_value is None:
                    subset = "UNKNOWN"
                    reasons.add("AUTHORIZED_PERMISSION_EVIDENCE_MISSING")
                else:
                    unauthorized_value = requested_value & KNOWN_PERMISSION_MASK & ~authorized_value
                    unknown_value = requested_value & ~KNOWN_PERMISSION_MASK
                    unauthorized_permissions = _permission_result_map(unauthorized_value)
                    unknown_permissions = _permission_result_map(unknown_value)
                    if unauthorized_value:
                        subset = "FAILED"
                        reasons.add("REQUESTED_PERMISSION_NOT_SUBSET")
                    elif unknown_value:
                        subset = "UNKNOWN"
                        reasons.add("REQUESTED_PERMISSION_UNKNOWN_BITS")
                    else:
                        subset = "SATISFIED"
        trace("PERMISSION_SUBSET", "permission_subset_result", "NOT_APPLICABLE", subset, RULE_PERMISSION_SUBSET, "requested and authorized permission values", ("requested_permission_bits",) if requested_missing else ())
    else:
        trace("PERMISSION_SUBSET", "permission_subset_result", "NOT_APPLICABLE", subset, RULE_PERMISSION_SUBSET, "operation registry")

    mfa = "NOT_APPLICABLE"
    bot_installation_2fa = "NOT_APPLICABLE"
    mfa_flag = operation.mfa_permission_flag if operation is not None else request.relevant_elevated_permission_flag
    if operation is not None and operation.mfa_permission_flag and is_elevated_permission(operation.mfa_permission_flag):
        if actor_kind == "BOT":
            mfa = "NOT_APPLICABLE"
            bot_installation_2fa = "OUT_OF_SCOPE"
            add_precondition(_precondition("bot_installation_2fa", "OUT_OF_SCOPE", "MFA-BOT-INSTALLATION-OUT-OF-SCOPE", "OUT_OF_SCOPE", "bot actor; guild installation boundary", (), MFA_RULES_REGISTRY["source_references"], "Bot installation 2FA is outside this analyzer; actor MFA is not used."))
        elif actor_kind == "HUMAN":
            guild_mfa = _mfa_level(request.guild_mfa_level)
            actor_mfa = _normal(request.actor_mfa_state)
            if guild_mfa == "NONE":
                mfa = "NOT_APPLICABLE"
            elif guild_mfa == "ELEVATED" and actor_mfa == "ENABLED":
                mfa = "SATISFIED"
            elif guild_mfa == "ELEVATED" and actor_mfa == "DISABLED":
                mfa = "FAILED"
            else:
                mfa = "UNKNOWN"
                reasons.add("MFA_EVIDENCE_MISSING_OR_INVALID")
        else:
            mfa = "UNKNOWN"
            reasons.add("MFA_ACTOR_KIND_UNKNOWN")
    elif operation is not None and TIMEOUT_ONLY_PERMISSION_FLAG in operation.required_source_permission_flags:
        mfa = "NOT_APPLICABLE"
        reasons.add("TIMEOUT_PERMISSION_NOT_MFA_ELEVATED")
    trace("MFA", "mfa_precondition", "NOT_APPLICABLE", mfa, "MFA-RULE-001", "separate MFA rules registry", ("guild_mfa_level", "actor_mfa_state") if mfa == "UNKNOWN" else (), "VERIFIED" if mfa != "UNKNOWN" else "UNKNOWN")

    if operation is not None and operation.requires_proposed_position:
        proposed_result = hierarchy if operation.hierarchy_subject == "PROPOSED_ROLE" else hierarchy
        proposed_precondition = "SATISFIED" if proposed_result == FINAL_ALLOWED else "FAILED" if proposed_result == FINAL_DENIED else "UNKNOWN"
        add_precondition(_precondition("proposed_role_position", proposed_precondition, RULE_ROLE_POSITION, "VERIFIED" if proposed_precondition != "UNKNOWN" else "UNKNOWN", "actor_highest_role_position/proposed_role_position", hierarchy_missing, operation.source_references))
    if operation is not None and operation.target_member_interaction:
        supplied = _normal(request.target_member_hierarchy_result)
        if supplied in {FINAL_ALLOWED, "SATISFIED"}:
            member_precondition = "SATISFIED"
            status = "VERIFIED"
        elif supplied in {FINAL_DENIED, "FAILED"}:
            member_precondition = "FAILED"
            status = "VERIFIED"
        else:
            member_precondition = "UNKNOWN"
            status = "NEEDS_TEST"
            reasons.add("TARGET_MEMBER_HIERARCHY_NEEDS_TEST")
        add_precondition(_precondition("target_member_hierarchy", member_precondition, RULE_TARGET_MEMBER_UNRESOLVED, status, "target_member_hierarchy_result", ("target_member_hierarchy_result",) if supplied is None else (), operation.source_references))
    if operation is not None and operation.requires_voice_state:
        connected = _bool_state(request.target_currently_connected_to_voice)
        voice_state = "SATISFIED" if connected is True else "FAILED" if connected is False else "UNKNOWN"
        if voice_state == "UNKNOWN":
            reasons.add("VOICE_CONNECTION_STATE_MISSING")
        add_precondition(_precondition("voice_connection", voice_state, RULE_VOICE_CONNECTION, "VERIFIED" if voice_state != "UNKNOWN" else "UNKNOWN", "target_currently_connected_to_voice", ("target_currently_connected_to_voice",) if connected is None else (), (CHANNEL_SOURCE_URL,)))
        if operation.operation_key == "voice.member_move":
            source_connect = _bool_state(request.actor_can_connect_to_source)
            destination_connect = _bool_state(request.actor_can_connect_to_destination)
            authority = "SATISFIED" if source_connect is True and destination_connect is True else "FAILED" if source_connect is False or destination_connect is False else "UNKNOWN"
            if authority == "UNKNOWN":
                reasons.add("VOICE_AUTHORITY_EVIDENCE_MISSING")
            add_precondition(_precondition("voice_authority", authority, RULE_VOICE_AUTHORITY, "NEEDS_TEST" if authority == "UNKNOWN" else "VERIFIED", "actor_can_connect_to_source/actor_can_connect_to_destination", tuple(name for name, value in (("actor_can_connect_to_source", source_connect), ("actor_can_connect_to_destination", destination_connect)) if value is None), operation.source_references))
        add_precondition(_precondition("voice_target_hierarchy", "UNKNOWN", RULE_TARGET_MEMBER_UNRESOLVED, "NEEDS_TEST", "voice target hierarchy", ("voice_target_hierarchy",), operation.source_references, "Voice target hierarchy is intentionally unresolved in Pass 5."))

    context_fields = (request.context_guild_id, request.parent_channel_id, request.target_channel_id, request.overwrite_guild_id, request.overwrite_target_id, request.overwrite_target_type)
    if operation is not None and operation.operation_key in {"channel.manage", "overwrite.permission_change"}:
        context_missing: list[str] = []
        context_result = "SATISFIED"
        context_source = "context identifiers"
        if request.context_guild_id is not None and _parse_id(request.context_guild_id) != guild_id:
            context_result = "FAILED"
            reasons.add("CONTEXT_GUILD_MISMATCH")
        if operation.operation_key == "overwrite.permission_change":
            if request.overwrite_guild_id is None or request.overwrite_target_id is None or request.overwrite_target_type is None:
                context_result = "UNKNOWN"
                context_missing.extend([name for name, value in (("overwrite_guild_id", request.overwrite_guild_id), ("overwrite_target_id", request.overwrite_target_id), ("overwrite_target_type", request.overwrite_target_type)) if value is None])
            elif _parse_id(request.overwrite_guild_id) != guild_id or _parse_id(request.overwrite_target_id) != target_id or _normal(request.overwrite_target_type) != target_type:
                context_result = "FAILED"
                reasons.add("OVERWRITE_CONTEXT_MISMATCH")
        elif any(value is not None for value in context_fields) and request.context_guild_id is None:
            context_result = "UNKNOWN"
            context_missing.append("context_guild_id")
        add_precondition(_precondition("context_consistency", context_result, RULE_CONTEXT_CONSISTENCY, "VERIFIED" if context_result != "UNKNOWN" else "UNKNOWN", context_source, context_missing, operation.source_references))

    core_unknown_reasons = {
        "GUILD_ID_INVALID", "ACTOR_ID_INVALID", "OPERATION_KEY_MISSING", "OPERATION_KEY_UNSUPPORTED", "ACTOR_KIND_INVALID",
        "TARGET_TYPE_INVALID", "TARGET_TYPE_OPERATION_MISMATCH", "TARGET_ID_MISSING", "TARGET_ID_NOT_APPLICABLE",
        "INPUT_HEALTH_MISSING", "INPUT_HEALTH_INVALID", "SOURCE_VERSION_UNSUPPORTED",
        "PERMISSION_DEFINITION_VERSION_MISSING", "SNAPSHOT_OR_FIXTURE_VERSION_MISSING", "PASS1_CONTRACT_VERSION_MISSING",
        "PASS2_CONTRACT_VERSION_MISSING", "PASS3_CONTRACT_VERSION_MISSING", "PASS4_CONTRACT_VERSION_MISSING",
        "PERMISSION_DEFINITION_VERSION_MISMATCH", "PASS1_CONTRACT_VERSION_MISMATCH", "PASS2_CONTRACT_VERSION_MISMATCH",
        "PASS3_CONTRACT_VERSION_MISMATCH", "PASS4_CONTRACT_VERSION_MISMATCH", "BYPASS_STATE_MISSING", "BYPASS_STATE_INVALID",
        "CAPABILITY_PERMISSION_EVIDENCE_MISSING", "CAPABILITY_PERMISSION_RESULT_INVALID", "MFA_ACTOR_KIND_UNKNOWN",
        "UPSTREAM_GUILD_ID_MISMATCH",
    }
    component_values = (capability, target_authority, hierarchy, mfa, subset, managed)
    if any(value == FINAL_UNKNOWN for value in component_values) or any(record.result == "UNKNOWN" for record in operation_object_preconditions):
        completeness = COMPLETENESS_PARTIAL
    else:
        completeness = COMPLETENESS_COMPLETE
    if reasons.intersection(core_unknown_reasons):
        completeness = COMPLETENESS_UNKNOWN
    if operation is None:
        completeness = COMPLETENESS_UNKNOWN
    if any(record.verification_status in {"NEEDS_TEST", "UNSUPPORTED"} for record in operation_object_preconditions):
        completeness = COMPLETENESS_PARTIAL if completeness != COMPLETENESS_UNKNOWN else completeness
    if health_state == COMPLETENESS_PARTIAL and completeness == COMPLETENESS_COMPLETE:
        completeness = COMPLETENESS_PARTIAL
    trace("COMPLETENESS", "analysis_completeness", "UNSET", completeness, "PASS5-COMPLETENESS-001", "component and precondition results", (), "VERIFIED")

    trace_rows.sort(key=lambda row: (row[0], row[1], row[2], row[3], row[4]))
    trace_events = tuple(AuthorityTraceEvent(index, row[5].stage, row[5].details) for index, row in enumerate(trace_rows, 1))
    registry_reasons = validate_authority_registry() + validate_object_preconditions() + validate_mfa_rules()
    reasons.update(registry_reasons)
    return AuthorityAnalysisResult(
        engine_contract_version=STAGE3_PASS5_ENGINE_CONTRACT_VERSION,
        authority_rules_version=AUTHORITY_RULES_VERSION,
        object_preconditions_version=OBJECT_PRECONDITIONS_VERSION,
        mfa_rules_version=MFA_RULES_VERSION,
        pass1_contract_version=pass1_version or STAGE3_PASS1_ENGINE_CONTRACT_VERSION,
        pass2_contract_version=pass2_version or STAGE3_PASS2_ENGINE_CONTRACT_VERSION,
        pass3_contract_version=pass3_version or STAGE3_PASS3_ENGINE_CONTRACT_VERSION,
        pass4_contract_version=pass4_version or STAGE3_PASS4_ENGINE_CONTRACT_VERSION,
        capability_registry_version=CAPABILITY_REGISTRY_VERSION,
        permission_definition_version=permission_version,
        snapshot_or_fixture_version=source_version,
        guild_id=guild_id,
        actor_id=actor_id,
        actor_kind=actor_kind,
        target_type=target_type,
        target_id=target_id,
        operation_key=operation_key,
        bypass_state=bypass,
        capability_permission=capability,
        target_authority=target_authority,
        hierarchy_result=hierarchy,
        mfa_precondition=mfa,
        permission_subset_result=subset,
        managed_object_precondition=managed,
        operation_object_preconditions=tuple(sorted(operation_object_preconditions, key=lambda item: (item.key, item.rule_id, item.result))),
        analysis_completeness=completeness,
        actor_highest_role_evidence=actor_evidence,
        target_highest_role_evidence=target_evidence,
        strict_lower_role_comparison=strict_comparison,
        requested_permissions=requested_permissions,
        actor_authorized_permissions=authorized_permissions,
        unauthorized_permission_bits=unauthorized_permissions,
        unknown_permission_bits=unknown_permissions,
        source_capability_key=source_key,
        source_capability_verification_status=capability_verification,
        bot_installation_2fa_precondition=bot_installation_2fa,
        reason_codes=_unique_reasons(tuple(reasons)),
        raw_permission_values_unchanged=True,
        trace=trace_events,
    )


evaluate_authority = evaluate_authority_analysis
resolve_authority_analysis = evaluate_authority_analysis
evaluate_pass5_authority = evaluate_authority_analysis


__all__ = [
    "ACTOR_KINDS", "AUTHORITY_SCOPES", "AuthorityAnalysisRequest", "AuthorityAnalysisResult",
    "AuthorityTraceEvent", "BYPASS_STATES", "COMPONENT_STATES", "GUILD_MFA_LEVELS",
    "HIERARCHY_STATES", "MFA_STATES", "OperationPreconditionRecord", "PRECONDITION_STATES",
    "STAGE3_PASS5_ENGINE_CONTRACT_VERSION", "SUPPORTED_SOURCE_VERSIONS", "TARGET_TYPES",
    "TRACE_STAGES", "evaluate_authority", "evaluate_authority_analysis", "evaluate_pass5_authority",
    "resolve_authority_analysis",
]
