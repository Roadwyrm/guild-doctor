"""Sanitized local event/audit records; token and payload fields are excluded."""
from __future__ import annotations
PASS5_RUNTIME_AUDIT_CONTRACT="GUILD-DOCTOR-PASS5-RUNTIME-AUDIT-0.1"
ALLOWED_FIELDS=("run_id","command_key","interaction_outcome","authorization_outcome","acknowledgement_class","visibility","adapter_result_state","snapshot_gate_outcome","targeted_fetch_attempted","pagination_count","export_prepared","stable_error_code","operation","exception_category","http_status","request_phase","client_cleanup","request_method","endpoint_template","write_classification","command_sync_write_count","prohibited_mutation_count","raw_payload_retained","token_redacted")
def sanitize_event(value:dict)->dict:return {key:value.get(key) for key in ALLOWED_FIELDS if key in value}|{"raw_payload_retained":False,"token_redacted":True}
