"""Data-only Stage 5 Pass 1 diagnostic rules.

These rules select wording and evidence presentation.  Permission, hierarchy,
MFA, thread, and object decisions remain owned by the frozen Stage 3 engines.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any


DOCTOR_RULES_VERSION = "GUILD-DOCTOR-DOCTOR-RULES-0.1"
PREMISE_CONFIRMED = "CONFIRMED"
PREMISE_CONTRADICTED = "CONTRADICTED"
PREMISE_UNKNOWN = "UNKNOWN"
PREMISE_NOT_APPLICABLE = "NOT_APPLICABLE"
PREMISE_UNSUPPORTED = "UNSUPPORTED"
PREMISE_ALIGNMENTS = frozenset(
    {
        PREMISE_CONFIRMED,
        PREMISE_CONTRADICTED,
        PREMISE_UNKNOWN,
        PREMISE_NOT_APPLICABLE,
        PREMISE_UNSUPPORTED,
    }
)

RULE_PREMISE_ALIGNMENT = "DOCTOR-PREMISE-001"
RULE_CAUSAL_CHAIN = "DOCTOR-CAUSAL-001"
RULE_UNKNOWN_EVIDENCE = "DOCTOR-UNKNOWN-001"
RULE_SOURCE_LOCATION = "DOCTOR-SOURCE-LOCATION-001"

_DEFINITIVE = frozenset({"ALLOWED", "DENIED", "INEFFECTIVE", "NOT_APPLICABLE", "UNSUPPORTED"})


def _state(result: Any) -> str:
    if isinstance(result, Mapping):
        value = result.get("final_result", result.get("final_state", result.get("result_state")))
    else:
        value = getattr(result, "final_result", getattr(result, "result_state", None))
    return str(value).upper() if isinstance(value, str) else "UNKNOWN"


def align_premise(intent: str, result_state: str) -> str:
    """Align the requested premise with the authoritative Stage 3 state."""

    state = (result_state or "UNKNOWN").upper()
    if intent == "EXPLAIN_ACTUAL_RESULT":
        return PREMISE_NOT_APPLICABLE
    if state not in _DEFINITIVE and state != "UNKNOWN":
        return PREMISE_UNSUPPORTED
    if intent == "WHY_CAN":
        if state == "ALLOWED":
            return PREMISE_CONFIRMED
        if state in {"DENIED", "INEFFECTIVE"}:
            return PREMISE_CONTRADICTED
        if state == "UNKNOWN":
            return PREMISE_UNKNOWN
        return PREMISE_NOT_APPLICABLE
    if intent == "WHY_CANNOT":
        if state in {"DENIED", "INEFFECTIVE"}:
            return PREMISE_CONFIRMED
        if state == "ALLOWED":
            return PREMISE_CONTRADICTED
        if state == "UNKNOWN":
            return PREMISE_UNKNOWN
        return PREMISE_NOT_APPLICABLE
    if intent == "WHY_UNKNOWN":
        return PREMISE_CONFIRMED if state == "UNKNOWN" else PREMISE_CONTRADICTED
    return PREMISE_UNSUPPORTED


def _read(result: Any, key: str, default: Any = None) -> Any:
    if isinstance(result, Mapping):
        return result.get(key, default)
    return getattr(result, key, default)


def _unique_text(values: Sequence[Any] | None) -> tuple[str, ...]:
    if not values:
        return ()
    return tuple(sorted({str(item) for item in values if str(item)}))


def material_reasons(result: Any, *, selected_record: Any = None) -> dict[str, tuple[str, ...]]:
    """Extract evidence already emitted by Stage 3; never recalculate it."""

    source = selected_record if selected_record is not None else result
    blocking = _read(source, "definitive_blockers", ()) or _read(source, "blocking_rule_ids", ())
    uncertain = _read(source, "material_uncertainties", ()) or _read(source, "dependency_uncertainties", ())
    ineffective = _read(source, "ineffective_grants", ())
    reasons = _read(source, "reason_codes", ())
    missing = _read(source, "missing_components", ()) or _read(source, "missing_evidence", ())
    return {
        "blocking": _unique_text(blocking),
        "uncertain": _unique_text(uncertain),
        "ineffective": _unique_text(ineffective),
        "reason_codes": _unique_text(reasons),
        "missing": _unique_text(missing),
    }


def direct_answer(intent: str, target_key: str, result_state: str, reasons: Mapping[str, Sequence[str]]) -> str:
    """Produce deterministic premise-aware wording without recommendations."""

    state = result_state.upper()
    label = target_key or "the requested diagnostic target"
    if state in {"DENIED", "INEFFECTIVE"}:
        actual = "denied" if state == "DENIED" else "ineffective"
    elif state == "ALLOWED":
        actual = "allowed"
    elif state == "NOT_APPLICABLE":
        actual = "not applicable"
    elif state == "UNSUPPORTED":
        actual = "unsupported"
    else:
        actual = "unknown"

    alignment = align_premise(intent, state)
    if alignment == PREMISE_CONFIRMED and intent == "WHY_CAN":
        return f"Yes. {label} is allowed under the supplied state."
    if alignment == PREMISE_CONFIRMED and intent == "WHY_CANNOT":
        return f"No. {label} is {actual} under the supplied state."
    if alignment == PREMISE_CONFIRMED and intent == "WHY_UNKNOWN":
        return f"The result for {label} is unknown under the supplied state."
    if alignment == PREMISE_CONTRADICTED:
        return f"The premise is not supported. {label} is {actual} under the supplied state."
    if alignment == PREMISE_UNKNOWN:
        return f"I cannot determine this safely because the result for {label} is unknown under the supplied state."
    if alignment == PREMISE_NOT_APPLICABLE:
        return f"The supplied state evaluates {label} as {actual}; the requested premise is not applicable."
    return f"The supplied state evaluates {label} as {actual}, but this target is not supported by the registered rules."


def primary_reason(reasons: Mapping[str, Sequence[str]], result_state: str) -> str:
    """Select one stable reason code from Stage 3 evidence."""

    for key in ("blocking", "uncertain", "missing", "ineffective", "reason_codes"):
        values = reasons.get(key, ())
        if values:
            return str(sorted(values)[0])
    return {
        "ALLOWED": "DOCTOR-ACTUAL-ALLOWED-001",
        "DENIED": "DOCTOR-ACTUAL-DENIED-001",
        "INEFFECTIVE": "DOCTOR-ACTUAL-INEFFECTIVE-001",
        "NOT_APPLICABLE": "DOCTOR-ACTUAL-NOT-APPLICABLE-001",
        "UNSUPPORTED": "DOCTOR-ACTUAL-UNSUPPORTED-001",
    }.get(result_state.upper(), RULE_UNKNOWN_EVIDENCE)


def causal_chain(
    result_family: str,
    *,
    stage_results: Mapping[str, Any],
    selected_record: Any = None,
) -> tuple[Mapping[str, Any], ...]:
    """Return material provenance stages, not a second permission algorithm."""

    chain: list[Mapping[str, Any]] = []
    ordered = ("PASS1", "PASS2", "PASS3", "PASS4", "PASS5", "PASS6", "STAGE4")
    for stage in ordered:
        result = stage_results.get(stage)
        if result is None:
            continue
        result_state = _state(result)
        if stage == "PASS3" and selected_record is not None:
            result_state = str(_read(selected_record, "final_result", "UNKNOWN")).upper()
        chain.append(
            {
                "stage": stage,
                "result_family": result_family,
                "state": result_state,
                "rule_id": RULE_CAUSAL_CHAIN,
                "source_contract": _read(result, "engine_contract_version", _read(result, "pass6_contract_version", None)),
                "source_result_fingerprint": _read(result, "result_fingerprint", None),
            }
        )
    return tuple(chain)


def source_locations(result_family: str, *, query: Any, stage_results: Mapping[str, Any]) -> tuple[Mapping[str, Any], ...]:
    """Identify evidence locations only; no remediation advice is emitted."""

    locations: list[Mapping[str, Any]] = []
    if query.target_kind == "CAPABILITY":
        if query.context_type == "CATEGORY":
            locations.append({"location": "category", "context_id": query.context_id, "rule_id": RULE_SOURCE_LOCATION})
        elif query.context_id:
            locations.append({"location": "channel", "context_id": query.context_id, "rule_id": RULE_SOURCE_LOCATION})
        locations.append({"location": "guild_role", "guild_id": query.guild_id, "rule_id": RULE_SOURCE_LOCATION})
    else:
        locations.append({"location": "target", "target_type": query.target_type, "target_id": query.target_id, "rule_id": RULE_SOURCE_LOCATION})
        if query.context_id:
            locations.append({"location": "context", "context_id": query.context_id, "rule_id": RULE_SOURCE_LOCATION})
    return tuple(locations)


def validate_doctor_rules() -> tuple[str, ...]:
    return () if DOCTOR_RULES_VERSION == "GUILD-DOCTOR-DOCTOR-RULES-0.1" else ("DOCTOR_RULES_VERSION_MISMATCH",)


__all__ = [
    "DOCTOR_RULES_VERSION",
    "PREMISE_ALIGNMENTS",
    "PREMISE_CONFIRMED",
    "PREMISE_CONTRADICTED",
    "PREMISE_NOT_APPLICABLE",
    "PREMISE_UNKNOWN",
    "PREMISE_UNSUPPORTED",
    "RULE_CAUSAL_CHAIN",
    "RULE_PREMISE_ALIGNMENT",
    "RULE_SOURCE_LOCATION",
    "RULE_UNKNOWN_EVIDENCE",
    "align_premise",
    "causal_chain",
    "direct_answer",
    "material_reasons",
    "primary_reason",
    "source_locations",
    "validate_doctor_rules",
]
