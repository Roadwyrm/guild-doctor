"""Pure Stage 3 Pass 2 raw channel/category permission resolution.

This module consumes a trusted Stage 3 Pass 1 guild-level result and one
selected context's stored overwrite set.  It deliberately does not import
Discord, networking, persistence, commands, or any thread/capability logic.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from .constants import (
    CATEGORY_TYPE_CODE,
    CHANNEL_TYPE_KEYS,
    KNOWN_PERMISSION_MASK,
    PERMISSION_DEFINITION_VERSION,
    SNAPSHOT_SCHEMA_VERSION,
    THREAD_TYPE_CODES,
)
from .fixture_export import STAGE3_FIXTURE_VERSION
from .permission_engine import (
    BYPASS_ADMINISTRATOR,
    BYPASS_NONE,
    BYPASS_OWNER,
    COMPLETENESS_COMPLETE,
    COMPLETENESS_PARTIAL,
    COMPLETENESS_UNKNOWN,
    GuildPermissionEvaluationResult,
    STAGE3_PASS1_ENGINE_CONTRACT_VERSION,
)


STAGE3_PASS2_ENGINE_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE3-PASS2-0.1"
SUPPORTED_SOURCE_VERSIONS = frozenset(
    {SNAPSHOT_SCHEMA_VERSION, STAGE3_FIXTURE_VERSION}
)

SUPPORTED_CONTEXT_TYPES = frozenset(
    {"CATEGORY", "TEXT", "ANNOUNCEMENT", "VOICE", "STAGE", "FORUM", "MEDIA"}
)
SUPPORTED_CONTEXT_TYPE_CODES = frozenset(
    {code for code, key in CHANNEL_TYPE_KEYS.items() if key in SUPPORTED_CONTEXT_TYPES}
)
SUPPORTED_SYNC_STATES = frozenset({"SYNCED", "NOT_SYNCED", "NOT_APPLICABLE", "UNKNOWN"})

_MISSING = object()


@dataclass(frozen=True, slots=True)
class PermissionOverwriteEvaluationRequest:
    """Pure input for one selected category or guild-channel context."""

    guild_id: int | str
    subject_id: int | str
    assigned_role_ids: Sequence[int | str] | None
    guild_permission_result: GuildPermissionEvaluationResult | Mapping[str, Any] | None
    context_id: int | str | None
    context_type: int | str | None
    context_guild_id: int | str | None
    context_parent_id: int | str | None
    context_sync_state: str | None
    context_permission_overwrites: Sequence[Any] | None
    normalized_roles: Mapping[Any, Any] | Sequence[Any] | Any | None
    permission_definition_version: str | None
    snapshot_or_fixture_version: str | None
    input_health: Mapping[str, Any] | None


@dataclass(frozen=True, slots=True)
class PermissionOverwriteContribution:
    """One overwrite source, including whether it applied to this subject."""

    target_id: str
    target_type: str
    allow_decimal: str | None
    allow_hex: str | None
    deny_decimal: str | None
    deny_hex: str | None
    applied: bool
    reason_codes: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "target_id": self.target_id,
            "target_type": self.target_type,
            "allow_decimal": self.allow_decimal,
            "allow_hex": self.allow_hex,
            "deny_decimal": self.deny_decimal,
            "deny_hex": self.deny_hex,
            "applied": self.applied,
            "reason_codes": list(self.reason_codes),
        }


@dataclass(frozen=True, slots=True)
class PermissionOverwriteTraceEvent:
    """Timestamp-free deterministic trace event."""

    sequence: int
    code: str
    details: Mapping[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "sequence": self.sequence,
            "code": self.code,
            "details": _canonicalize(self.details),
        }


@dataclass(frozen=True, slots=True)
class ContextPermissionEvaluationResult:
    """Deterministic raw context permission result."""

    engine_contract_version: str
    pass1_contract_version: str
    permission_definition_version: str | None
    snapshot_or_fixture_version: str | None
    guild_id: str | None
    subject_id: str | None
    context_id: str | None
    context_type: str | None
    context_parent_id: str | None
    observed_sync_state: str | None
    bypass_state: str
    raw_guild_permission_decimal: str | None
    raw_guild_permission_hex: str | None
    everyone_overwrite_contribution: PermissionOverwriteContribution | None
    applicable_role_overwrite_source_ids: tuple[str, ...]
    combined_role_deny_decimal: str | None
    combined_role_deny_hex: str | None
    combined_role_allow_decimal: str | None
    combined_role_allow_hex: str | None
    member_overwrite_contribution: PermissionOverwriteContribution | None
    raw_context_permission_decimal: str | None
    raw_context_permission_hex: str | None
    known_context_permission_bits_decimal: str | None
    known_context_permission_bits_hex: str | None
    unknown_context_permission_bits_decimal: str | None
    unknown_context_permission_bits_hex: str | None
    overwrites_applied: bool | None
    overwrites_bypassed: bool
    context_overwrite_collection_state: str
    missing_role_references: tuple[str, ...]
    invalid_references: tuple[str, ...]
    completeness_state: str
    reason_codes: tuple[str, ...]
    trace: tuple[PermissionOverwriteTraceEvent, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "engine_contract_version": self.engine_contract_version,
            "pass1_contract_version": self.pass1_contract_version,
            "permission_definition_version": self.permission_definition_version,
            "snapshot_or_fixture_version": self.snapshot_or_fixture_version,
            "guild_id": self.guild_id,
            "subject_id": self.subject_id,
            "context_id": self.context_id,
            "context_type": self.context_type,
            "context_parent_id": self.context_parent_id,
            "observed_sync_state": self.observed_sync_state,
            "bypass_state": self.bypass_state,
            "raw_guild_permission_decimal": self.raw_guild_permission_decimal,
            "raw_guild_permission_hex": self.raw_guild_permission_hex,
            "everyone_overwrite_contribution": (
                self.everyone_overwrite_contribution.as_dict()
                if self.everyone_overwrite_contribution is not None
                else None
            ),
            "applicable_role_overwrite_source_ids": list(
                self.applicable_role_overwrite_source_ids
            ),
            "combined_role_deny_decimal": self.combined_role_deny_decimal,
            "combined_role_deny_hex": self.combined_role_deny_hex,
            "combined_role_allow_decimal": self.combined_role_allow_decimal,
            "combined_role_allow_hex": self.combined_role_allow_hex,
            "member_overwrite_contribution": (
                self.member_overwrite_contribution.as_dict()
                if self.member_overwrite_contribution is not None
                else None
            ),
            "raw_context_permission_decimal": self.raw_context_permission_decimal,
            "raw_context_permission_hex": self.raw_context_permission_hex,
            "known_context_permission_bits_decimal": self.known_context_permission_bits_decimal,
            "known_context_permission_bits_hex": self.known_context_permission_bits_hex,
            "unknown_context_permission_bits_decimal": self.unknown_context_permission_bits_decimal,
            "unknown_context_permission_bits_hex": self.unknown_context_permission_bits_hex,
            "overwrites_applied": self.overwrites_applied,
            "overwrites_bypassed": self.overwrites_bypassed,
            "context_overwrite_collection_state": self.context_overwrite_collection_state,
            "missing_role_references": list(self.missing_role_references),
            "invalid_references": list(self.invalid_references),
            "completeness_state": self.completeness_state,
            "reason_codes": list(self.reason_codes),
            "trace": [event.as_dict() for event in self.trace],
        }


@dataclass(frozen=True, slots=True)
class _OverwriteData:
    target_id: str | None
    target_type: str
    raw_target_type: Any
    allow_decimal: str | None
    allow_value: int | None
    deny_decimal: str | None
    deny_value: int | None
    valid: bool
    reason_codes: tuple[str, ...]


def _canonicalize(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {
            str(key): _canonicalize(value[key])
            for key in sorted(value, key=lambda item: str(item))
        }
    if isinstance(value, (list, tuple)):
        return [_canonicalize(item) for item in value]
    return value


def _sort_key(value: str) -> tuple[int, int, str]:
    if value.isdecimal():
        return (0, int(value), value)
    return (1, 0, value)


def _parse_snowflake(value: Any) -> str | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text or not text.isdecimal():
        return None
    integer = int(text)
    return str(integer) if integer > 0 else None


def _parse_permission(value: Any) -> tuple[str | None, int | None]:
    if value is None or isinstance(value, bool):
        return None, None
    if isinstance(value, int):
        return (str(value), value) if value >= 0 else (None, None)
    if not isinstance(value, str):
        return None, None
    text = value.strip()
    if not text or not text.isdecimal():
        return None, None
    integer = int(text)
    return str(integer), integer


def _permission_parts(value: int | None) -> tuple[str | None, str | None, str | None, str | None, str | None, str | None]:
    if value is None:
        return (None, None, None, None, None, None)
    known = value & KNOWN_PERMISSION_MASK
    unknown = value & ~KNOWN_PERMISSION_MASK
    return (
        str(value),
        format(value, "#x"),
        str(known),
        format(known, "#x"),
        str(unknown),
        format(unknown, "#x"),
    )


def _permission_state(value: int | None) -> dict[str, str | None]:
    decimal, hexadecimal, known, known_hex, unknown, unknown_hex = _permission_parts(value)
    return {
        "decimal": decimal,
        "hex": hexadecimal,
        "known_decimal": known,
        "known_hex": known_hex,
        "unknown_decimal": unknown,
        "unknown_hex": unknown_hex,
    }


def _field(record: Any, *names: str) -> Any:
    if isinstance(record, Mapping):
        for name in names:
            if name in record:
                return record[name]
        return _MISSING
    for name in names:
        if hasattr(record, name):
            return getattr(record, name)
    return _MISSING


def _diagnostic_reference(value: Any) -> str:
    if value is _MISSING or value is None:
        return "<missing>"
    return str(value)


def _normalize_context_type(value: Any) -> str | None:
    if isinstance(value, int) and not isinstance(value, bool):
        return CHANNEL_TYPE_KEYS.get(value, f"UNKNOWN_{value}")
    if not isinstance(value, str):
        return None
    text = value.strip().upper()
    aliases = {
        "GUILD_CATEGORY": "CATEGORY",
        "GUILD_TEXT": "TEXT",
        "GUILD_ANNOUNCEMENT": "ANNOUNCEMENT",
        "GUILD_VOICE": "VOICE",
        "GUILD_STAGE_VOICE": "STAGE",
        "GUILD_FORUM": "FORUM",
        "GUILD_MEDIA": "MEDIA",
        "ANNOUNCEMENT_THREAD": "ANNOUNCEMENT_THREAD",
        "PUBLIC_THREAD": "PUBLIC_THREAD",
        "PRIVATE_THREAD": "PRIVATE_THREAD",
    }
    if text in aliases:
        return aliases[text]
    if text.isdecimal():
        return CHANNEL_TYPE_KEYS.get(int(text), f"UNKNOWN_{text}")
    return text or None


def _health_state(input_health: Mapping[str, Any] | None) -> tuple[str, str | None]:
    if input_health is None:
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_MISSING"
    if not isinstance(input_health, Mapping):
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID"
    candidates: list[Any] = []
    for key in (
        "status",
        "structural_completeness",
        "source_structural_completeness",
        "completeness",
    ):
        if key in input_health:
            candidates.append(input_health[key])
    if isinstance(input_health.get("complete"), bool):
        candidates.append(
            COMPLETENESS_COMPLETE if input_health["complete"] else COMPLETENESS_PARTIAL
        )
    for candidate in candidates:
        if isinstance(candidate, str):
            normalized = candidate.strip().upper()
            if normalized == COMPLETENESS_COMPLETE:
                return COMPLETENESS_COMPLETE, None
            if normalized in {COMPLETENESS_PARTIAL, "INCOMPLETE", "NOT_REQUESTED"}:
                return COMPLETENESS_PARTIAL, "INPUT_HEALTH_INCOMPLETE"
            if normalized == COMPLETENESS_UNKNOWN:
                return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INCOMPLETE"
    return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID" if candidates else "INPUT_HEALTH_MISSING"


def _record_sequence(records: Any) -> list[Any] | None:
    if records is None:
        return None
    if isinstance(records, Mapping):
        if "id" in records or "target_id" in records:
            return [records]
        return list(records.values())
    if isinstance(records, Sequence) and not isinstance(records, (str, bytes, bytearray)):
        return list(records)
    return [records]


def _normalize_role_ids(
    records: Any,
    guild_id: str | None,
    missing_role_references: list[str],
    invalid_references: list[str],
    reasons: set[str],
) -> tuple[set[str], bool]:
    values = _record_sequence(records)
    if values is None:
        reasons.add("ROLE_RECORDS_MISSING")
        return set(), False
    role_ids: set[str] = set()
    valid = True
    for record in values:
        raw_id = _field(record, "id")
        role_id = _parse_snowflake(None if raw_id is _MISSING else raw_id)
        if role_id is None:
            invalid_references.append(_diagnostic_reference(raw_id))
            reasons.add("ROLE_ID_INVALID")
            valid = False
            continue
        if role_id in role_ids:
            invalid_references.append(role_id)
            reasons.add("DUPLICATE_NORMALIZED_ROLE_ID")
            valid = False
            continue
        role_ids.add(role_id)
        raw_role_guild_id = _field(record, "guild_id")
        if raw_role_guild_id is not _MISSING and raw_role_guild_id is not None:
            role_guild_id = _parse_snowflake(raw_role_guild_id)
            if role_guild_id is None or guild_id is None or role_guild_id != guild_id:
                invalid_references.append(role_id)
                reasons.add("ROLE_GUILD_ID_MISMATCH")
                valid = False
        raw_is_everyone = _field(record, "is_everyone")
        if raw_is_everyone is True and role_id != guild_id:
            invalid_references.append(role_id)
            reasons.add("EVERYONE_ROLE_ID_MISMATCH")
            valid = False
    if guild_id is None or guild_id not in role_ids:
        reasons.add("EVERYONE_ROLE_MISSING")
        missing_role_references.append(guild_id or "<missing-guild>")
        valid = False
    return role_ids, valid


def _normalize_overwrite(record: Any) -> _OverwriteData:
    raw_target_id = _field(record, "target_id", "id")
    target_id = _parse_snowflake(None if raw_target_id is _MISSING else raw_target_id)
    raw_type = _field(record, "target_type", "type")
    if raw_type in (0, "0", "ROLE", "role"):
        target_type = "ROLE"
    elif raw_type in (1, "1", "MEMBER", "member"):
        target_type = "MEMBER"
    else:
        target_type = "UNKNOWN"
    raw_allow = _field(record, "allow_decimal", "allow")
    raw_deny = _field(record, "deny_decimal", "deny")
    allow_decimal, allow_value = _parse_permission(
        None if raw_allow is _MISSING else raw_allow
    )
    deny_decimal, deny_value = _parse_permission(
        None if raw_deny is _MISSING else raw_deny
    )
    reasons: list[str] = []
    if target_id is None:
        reasons.append("OVERWRITE_TARGET_ID_INVALID")
    if target_type == "UNKNOWN":
        reasons.append("OVERWRITE_TARGET_TYPE_UNKNOWN")
    if allow_value is None:
        reasons.append("OVERWRITE_ALLOW_INVALID")
    if deny_value is None:
        reasons.append("OVERWRITE_DENY_INVALID")
    return _OverwriteData(
        target_id=target_id,
        target_type=target_type,
        raw_target_type=None if raw_type is _MISSING else raw_type,
        allow_decimal=allow_decimal,
        allow_value=allow_value,
        deny_decimal=deny_decimal,
        deny_value=deny_value,
        valid=not reasons,
        reason_codes=tuple(sorted(set(reasons))),
    )


def _contribution(
    item: _OverwriteData,
    *,
    applied: bool,
    reason_codes: Sequence[str] = (),
) -> PermissionOverwriteContribution | None:
    if item.target_id is None:
        return None
    reasons = tuple(sorted(set((*item.reason_codes, *reason_codes))))
    return PermissionOverwriteContribution(
        target_id=item.target_id,
        target_type=item.target_type,
        allow_decimal=item.allow_decimal,
        allow_hex=format(int(item.allow_decimal), "#x") if item.allow_decimal is not None else None,
        deny_decimal=item.deny_decimal,
        deny_hex=format(int(item.deny_decimal), "#x") if item.deny_decimal is not None else None,
        applied=applied,
        reason_codes=reasons,
    )


def _pass1_value(result: Any, name: str) -> Any:
    if isinstance(result, Mapping):
        return result.get(name, _MISSING)
    return getattr(result, name, _MISSING)


def _canonical_id_list(values: Any) -> tuple[str, ...] | None:
    if values is None or isinstance(values, (str, bytes, bytearray)):
        return None
    try:
        parsed = [_parse_snowflake(value) for value in values]
    except TypeError:
        return None
    if any(value is None for value in parsed):
        return None
    return tuple(sorted(set(parsed), key=_sort_key))  # type: ignore[arg-type]


def _trace_state(before: int | None, after: int | None) -> dict[str, Any]:
    return {"before": _permission_state(before), "after": _permission_state(after)}


def evaluate_context_permissions(
    request: PermissionOverwriteEvaluationRequest,
) -> ContextPermissionEvaluationResult:
    """Resolve raw permissions for the selected context only.

    A child channel's own overwrite collection is authoritative for this call.
    Parent and sync metadata are returned and validated as structure, but they
    never cause category overwrites to be copied or merged into the child.
    """

    reasons: set[str] = set()
    missing_role_references: list[str] = []
    invalid_references: list[str] = []
    trace: list[PermissionOverwriteTraceEvent] = []

    def add_trace(code: str, **details: Any) -> None:
        trace.append(
            PermissionOverwriteTraceEvent(
                sequence=len(trace) + 1,
                code=code,
                details={key: details[key] for key in sorted(details)},
            )
        )

    guild_id = _parse_snowflake(request.guild_id)
    subject_id = _parse_snowflake(request.subject_id)
    context_id = _parse_snowflake(request.context_id)
    context_guild_id = _parse_snowflake(request.context_guild_id)
    context_parent_id = _parse_snowflake(request.context_parent_id)
    context_type = _normalize_context_type(request.context_type)
    observed_sync_state = (
        request.context_sync_state.strip().upper()
        if isinstance(request.context_sync_state, str) and request.context_sync_state.strip()
        else None
    )

    if guild_id is None:
        reasons.add("GUILD_ID_INVALID")
    if subject_id is None:
        reasons.add("SUBJECT_ID_INVALID")
    if context_id is None:
        reasons.add("CONTEXT_ID_MISSING_OR_INVALID")
    if context_guild_id is None:
        reasons.add("CONTEXT_GUILD_ID_MISSING_OR_INVALID")
    elif guild_id is not None and context_guild_id != guild_id:
        reasons.add("CONTEXT_GUILD_MISMATCH")
    if context_type is None:
        reasons.add("CONTEXT_TYPE_MISSING")
    elif context_type in {CHANNEL_TYPE_KEYS.get(code) for code in THREAD_TYPE_CODES}:
        reasons.add("UNSUPPORTED_THREAD_CONTEXT")
    elif context_type not in SUPPORTED_CONTEXT_TYPES:
        reasons.add("UNSUPPORTED_OR_UNKNOWN_CONTEXT_TYPE")
    if observed_sync_state is None:
        reasons.add("SYNC_STATE_MISSING")
    elif observed_sync_state not in SUPPORTED_SYNC_STATES:
        reasons.add("SYNC_STATE_INVALID")
    if context_type == "CATEGORY" and observed_sync_state not in {None, "NOT_APPLICABLE"}:
        reasons.add("CATEGORY_SYNC_STATE_INVALID")
    if context_type in SUPPORTED_CONTEXT_TYPES - {"CATEGORY"} and request.context_parent_id is None:
        reasons.add("PARENT_METADATA_MISSING")
    elif request.context_parent_id is not None and context_parent_id is None:
        reasons.add("PARENT_ID_INVALID")

    health_state, health_reason = _health_state(request.input_health)
    if health_reason:
        reasons.add(health_reason)

    permission_version = request.permission_definition_version
    if not isinstance(permission_version, str) or not permission_version.strip():
        permission_version = None
        reasons.add("PERMISSION_DEFINITION_VERSION_MISSING")
    elif permission_version != PERMISSION_DEFINITION_VERSION:
        reasons.add("PERMISSION_DEFINITION_VERSION_MISMATCH")

    source_version = request.snapshot_or_fixture_version
    if not isinstance(source_version, str) or not source_version.strip():
        source_version = None
        reasons.add("SNAPSHOT_OR_FIXTURE_VERSION_MISSING")
    elif source_version not in SUPPORTED_SOURCE_VERSIONS:
        reasons.add("SNAPSHOT_OR_FIXTURE_VERSION_UNSUPPORTED")

    add_trace(
        "INPUT_VALIDATION",
        guild_id=guild_id,
        subject_id=subject_id,
        context_id=context_id,
        context_type=context_type,
        context_guild_id=context_guild_id,
        context_parent_id=context_parent_id,
        sync_state=observed_sync_state,
        input_health_state=health_state,
    )

    pass1 = request.guild_permission_result
    pass1_contract = _pass1_value(pass1, "engine_contract_version") if pass1 is not None else _MISSING
    pass1_guild_id = _parse_snowflake(_pass1_value(pass1, "guild_id")) if pass1 is not None else None
    pass1_subject_id = _parse_snowflake(_pass1_value(pass1, "subject_id")) if pass1 is not None else None
    pass1_bypass = _pass1_value(pass1, "bypass_state") if pass1 is not None else _MISSING
    pass1_raw_decimal = (
        _pass1_value(pass1, "raw_guild_permission_decimal")
        if pass1 is not None
        else _MISSING
    )
    raw_guild_decimal, raw_guild_value = _parse_permission(
        None if pass1_raw_decimal is _MISSING else pass1_raw_decimal
    )
    pass1_assigned = (
        _canonical_id_list(_pass1_value(pass1, "assigned_role_ids"))
        if pass1 is not None
        else None
    )
    requested_assigned = _canonical_id_list(request.assigned_role_ids)
    pass1_trustworthy = True
    if pass1 is None:
        reasons.add("PASS1_RESULT_MISSING")
        pass1_trustworthy = False
    if pass1_contract != STAGE3_PASS1_ENGINE_CONTRACT_VERSION:
        reasons.add("PASS1_CONTRACT_MISMATCH")
        pass1_trustworthy = False
    if guild_id is None or pass1_guild_id != guild_id:
        reasons.add("PASS1_GUILD_ID_MISMATCH")
        pass1_trustworthy = False
    if subject_id is None or pass1_subject_id != subject_id:
        reasons.add("PASS1_SUBJECT_ID_MISMATCH")
        pass1_trustworthy = False
    if raw_guild_value is None:
        reasons.add("PASS1_RAW_PERMISSION_MISSING_OR_INVALID")
        pass1_trustworthy = False
    pass1_hex = _pass1_value(pass1, "raw_guild_permission_hex") if pass1 is not None else _MISSING
    if raw_guild_value is not None and pass1_hex != format(raw_guild_value, "#x"):
        reasons.add("PASS1_RAW_PERMISSION_HEX_MISMATCH")
        pass1_trustworthy = False
    if pass1_bypass not in {BYPASS_NONE, BYPASS_OWNER, BYPASS_ADMINISTRATOR}:
        reasons.add("PASS1_BYPASS_STATE_INVALID")
        pass1_trustworthy = False
    if requested_assigned is None or pass1_assigned is None:
        reasons.add("ASSIGNED_ROLE_IDS_MISSING_OR_INVALID")
        pass1_trustworthy = False
    elif requested_assigned != pass1_assigned:
        reasons.add("PASS1_ASSIGNED_ROLE_IDS_MISMATCH")
        pass1_trustworthy = False
    pass1_completeness = _pass1_value(pass1, "completeness_state") if pass1 is not None else _MISSING
    if pass1_completeness != COMPLETENESS_COMPLETE:
        reasons.add("PASS1_RESULT_INCOMPLETE")
        pass1_trustworthy = False
    pass1_permission_version = _pass1_value(pass1, "permission_definition_version") if pass1 is not None else _MISSING
    pass1_source_version = _pass1_value(pass1, "snapshot_or_fixture_version") if pass1 is not None else _MISSING
    if pass1_permission_version != permission_version:
        reasons.add("PASS1_PERMISSION_DEFINITION_VERSION_MISMATCH")
        pass1_trustworthy = False
    if pass1_source_version != source_version:
        reasons.add("PASS1_SOURCE_VERSION_MISMATCH")
        pass1_trustworthy = False
    pass1_health_state = _pass1_value(pass1, "input_health_state") if pass1 is not None else _MISSING
    if pass1_health_state != COMPLETENESS_COMPLETE:
        reasons.add("PASS1_INPUT_HEALTH_INCOMPLETE")
        pass1_trustworthy = False

    add_trace(
        "GUILD_RESULT_INPUT",
        trustworthy=pass1_trustworthy,
        bypass_state=pass1_bypass if pass1_bypass is not _MISSING else None,
        raw_guild_permission=_permission_state(raw_guild_value),
    )

    role_ids, role_map_valid = _normalize_role_ids(
        request.normalized_roles,
        guild_id,
        missing_role_references,
        invalid_references,
        reasons,
    )

    overwrite_values = _record_sequence(request.context_permission_overwrites)
    overwrite_collection_state = "MISSING" if overwrite_values is None else "VALID"
    overwrites: list[_OverwriteData] = []
    seen_targets: set[tuple[str, str]] = set()
    if overwrite_values is None:
        reasons.add("OVERWRITE_COLLECTION_MISSING")
    else:
        for record in overwrite_values:
            item = _normalize_overwrite(record)
            overwrites.append(item)
            if not item.valid:
                overwrite_collection_state = "INVALID"
                invalid_references.append(
                    item.target_id or _diagnostic_reference(_field(record, "target_id", "id"))
                )
                reasons.update(item.reason_codes)
            key = (item.target_type, item.target_id or _diagnostic_reference(_field(record, "target_id", "id")))
            if key in seen_targets:
                overwrite_collection_state = "INVALID"
                reasons.add("DUPLICATE_OVERWRITE_TARGET_TYPE")
                invalid_references.append(key[1])
            seen_targets.add(key)
        if overwrite_collection_state == "INVALID":
            reasons.add("OVERWRITE_COLLECTION_INVALID")

    everyone_item: _OverwriteData | None = None
    member_item: _OverwriteData | None = None
    applicable_role_items: list[_OverwriteData] = []
    material_missing_role_reference = False
    for item in overwrites:
        if item.target_id is None or item.target_type == "UNKNOWN":
            continue
        if item.target_type == "ROLE":
            if item.target_id == guild_id:
                everyone_item = item
            elif requested_assigned is not None and item.target_id in requested_assigned:
                if item.target_id not in role_ids:
                    missing_role_references.append(item.target_id)
                    reasons.add("ASSIGNED_ROLE_OVERWRITE_REFERENCE_MISSING")
                    material_missing_role_reference = True
                else:
                    applicable_role_items.append(item)
            elif item.target_id not in role_ids:
                missing_role_references.append(item.target_id)
                reasons.add("NON_APPLICABLE_ROLE_REFERENCE_MISSING")
        elif item.target_type == "MEMBER" and item.target_id == subject_id:
            member_item = item

    applicable_role_items.sort(key=lambda item: _sort_key(item.target_id or ""))
    role_source_ids = tuple(item.target_id for item in applicable_role_items if item.target_id is not None)
    role_deny = 0
    role_allow = 0
    role_values_valid = True
    for item in applicable_role_items:
        if item.deny_value is None or item.allow_value is None or not item.valid:
            role_values_valid = False
            reasons.add("APPLICABLE_ROLE_OVERWRITE_INVALID")
        else:
            role_deny |= item.deny_value
            role_allow |= item.allow_value

    if everyone_item is not None and not everyone_item.valid:
        reasons.add("EVERYONE_OVERWRITE_INVALID")
    if member_item is not None and not member_item.valid:
        reasons.add("MEMBER_OVERWRITE_INVALID")

    if everyone_item is not None:
        everyone_contribution = _contribution(
            everyone_item,
            applied=everyone_item.valid and pass1_bypass == BYPASS_NONE,
            reason_codes=(
                ()
                if everyone_item.valid and pass1_bypass == BYPASS_NONE
                else ("OVERWRITES_BYPASSED",) if everyone_item.valid else ()
            ),
        )
    else:
        everyone_contribution = None
    if member_item is not None:
        member_contribution = _contribution(
            member_item,
            applied=member_item.valid and pass1_bypass == BYPASS_NONE,
            reason_codes=(
                ()
                if member_item.valid and pass1_bypass == BYPASS_NONE
                else ("OVERWRITES_BYPASSED",) if member_item.valid else ()
            ),
        )
    else:
        member_contribution = None

    context_core_valid = (
        guild_id is not None
        and subject_id is not None
        and context_id is not None
        and context_guild_id == guild_id
        and context_type in SUPPORTED_CONTEXT_TYPES
        and context_type not in {CHANNEL_TYPE_KEYS.get(code) for code in THREAD_TYPE_CODES}
    )
    role_data_valid = role_map_valid and guild_id is not None and guild_id in role_ids
    material_overwrite_failure = (
        overwrite_collection_state != "VALID"
        or not role_values_valid
        or any(
            code in reasons
            for code in {
                "EVERYONE_OVERWRITE_INVALID",
                "MEMBER_OVERWRITE_INVALID",
                "ASSIGNED_ROLE_OVERWRITE_REFERENCE_MISSING",
                "DUPLICATE_OVERWRITE_TARGET_TYPE",
                "OVERWRITE_TARGET_TYPE_UNKNOWN",
                "OVERWRITE_TARGET_ID_INVALID",
                "OVERWRITE_ALLOW_INVALID",
                "OVERWRITE_DENY_INVALID",
            }
        )
    )
    structural_metadata_partial = any(
        code in reasons
        for code in {
            "PARENT_METADATA_MISSING",
            "PARENT_ID_INVALID",
            "SYNC_STATE_MISSING",
            "SYNC_STATE_INVALID",
            "CATEGORY_SYNC_STATE_INVALID",
        }
    )
    can_calculate = (
        pass1_trustworthy
        and context_core_valid
        and role_data_valid
        and overwrite_collection_state == "VALID"
        and not material_overwrite_failure
        and health_state == COMPLETENESS_COMPLETE
        and permission_version == PERMISSION_DEFINITION_VERSION
        and source_version in SUPPORTED_SOURCE_VERSIONS
    )

    raw_context_value: int | None = None
    overwrites_applied: bool | None = None
    overwrites_bypassed = False
    if pass1_bypass in {BYPASS_OWNER, BYPASS_ADMINISTRATOR} and pass1_trustworthy and context_core_valid:
        raw_context_value = raw_guild_value
        overwrites_bypassed = True
        overwrites_applied = False
        reasons.add("CONTEXT_OVERWRITES_BYPASSED")
        add_trace(
            "OWNER_BYPASS" if pass1_bypass == BYPASS_OWNER else "ADMIN_BYPASS",
            bypass_state=pass1_bypass,
            raw_permission=_permission_state(raw_context_value),
        )
        for bypass_stage in (
            "CONTEXT_EVERYONE_DENY",
            "CONTEXT_EVERYONE_ALLOW",
            "CONTEXT_ROLE_DENY",
            "CONTEXT_ROLE_ALLOW",
            "CONTEXT_MEMBER_DENY",
            "CONTEXT_MEMBER_ALLOW",
        ):
            add_trace(
                bypass_stage,
                state="BYPASSED",
                mutation_applied=False,
                **_trace_state(raw_context_value, raw_context_value),
            )
    elif can_calculate:
        effective = raw_guild_value
        if everyone_item is not None and everyone_item.valid:
            before = effective
            effective &= ~everyone_item.deny_value  # type: ignore[operator]
            add_trace(
                "CONTEXT_EVERYONE_DENY",
                **_trace_state(before, effective),
                deny_decimal=everyone_item.deny_decimal,
                source_id=everyone_item.target_id,
            )
            before = effective
            effective |= everyone_item.allow_value  # type: ignore[operator]
            add_trace(
                "CONTEXT_EVERYONE_ALLOW",
                **_trace_state(before, effective),
                allow_decimal=everyone_item.allow_decimal,
                source_id=everyone_item.target_id,
            )
        else:
            add_trace("CONTEXT_EVERYONE_DENY", state="NO_APPLICABLE_OVERWRITE", **_trace_state(effective, effective))
            add_trace("CONTEXT_EVERYONE_ALLOW", state="NO_APPLICABLE_OVERWRITE", **_trace_state(effective, effective))

        before = effective
        effective &= ~role_deny
        add_trace(
            "CONTEXT_ROLE_DENY",
            **_trace_state(before, effective),
            source_role_ids=list(role_source_ids),
            combined_deny_decimal=str(role_deny),
            combined_deny_hex=format(role_deny, "#x"),
        )
        before = effective
        effective |= role_allow
        add_trace(
            "CONTEXT_ROLE_ALLOW",
            **_trace_state(before, effective),
            source_role_ids=list(role_source_ids),
            combined_allow_decimal=str(role_allow),
            combined_allow_hex=format(role_allow, "#x"),
        )

        if member_item is not None and member_item.valid:
            before = effective
            effective &= ~member_item.deny_value  # type: ignore[operator]
            add_trace(
                "CONTEXT_MEMBER_DENY",
                **_trace_state(before, effective),
                source_id=member_item.target_id,
                deny_decimal=member_item.deny_decimal,
            )
            before = effective
            effective |= member_item.allow_value  # type: ignore[operator]
            add_trace(
                "CONTEXT_MEMBER_ALLOW",
                **_trace_state(before, effective),
                source_id=member_item.target_id,
                allow_decimal=member_item.allow_decimal,
            )
        else:
            add_trace("CONTEXT_MEMBER_DENY", state="NO_APPLICABLE_OVERWRITE", **_trace_state(effective, effective))
            add_trace("CONTEXT_MEMBER_ALLOW", state="NO_APPLICABLE_OVERWRITE", **_trace_state(effective, effective))
        raw_context_value = effective
        overwrites_applied = bool(everyone_item or applicable_role_items or member_item)
        reasons.add("CONTEXT_OVERWRITES_APPLIED" if overwrites_applied else "NO_APPLICABLE_OVERWRITES")
    else:
        if pass1_bypass in {BYPASS_OWNER, BYPASS_ADMINISTRATOR} and pass1_trustworthy:
            add_trace(
                "OWNER_BYPASS" if pass1_bypass == BYPASS_OWNER else "ADMIN_BYPASS",
                bypass_state=pass1_bypass,
                state="CONTEXT_UNRESOLVED",
            )
            for bypass_stage in (
                "CONTEXT_EVERYONE_DENY",
                "CONTEXT_EVERYONE_ALLOW",
                "CONTEXT_ROLE_DENY",
                "CONTEXT_ROLE_ALLOW",
                "CONTEXT_MEMBER_DENY",
                "CONTEXT_MEMBER_ALLOW",
            ):
                add_trace(bypass_stage, state="UNAVAILABLE", mutation_applied=False)
        else:
            add_trace("CONTEXT_EVERYONE_DENY", state="UNAVAILABLE")
            add_trace("CONTEXT_EVERYONE_ALLOW", state="UNAVAILABLE")
            add_trace("CONTEXT_ROLE_DENY", state="UNAVAILABLE")
            add_trace("CONTEXT_ROLE_ALLOW", state="UNAVAILABLE")
            add_trace("CONTEXT_MEMBER_DENY", state="UNAVAILABLE")
            add_trace("CONTEXT_MEMBER_ALLOW", state="UNAVAILABLE")

    if raw_context_value is not None:
        add_trace(
            "CONTEXT_RESULT",
            raw_context_permission=_permission_state(raw_context_value),
            overwrites_applied=overwrites_applied,
            overwrites_bypassed=overwrites_bypassed,
        )
    else:
        add_trace(
            "CONTEXT_RESULT",
            state="UNAVAILABLE_OR_INCOMPLETE",
            overwrites_applied=overwrites_applied,
            overwrites_bypassed=overwrites_bypassed,
        )

    unknown_conditions = {
        "PASS1_RESULT_MISSING",
        "PASS1_CONTRACT_MISMATCH",
        "PASS1_GUILD_ID_MISMATCH",
        "PASS1_SUBJECT_ID_MISMATCH",
        "PASS1_RAW_PERMISSION_MISSING_OR_INVALID",
        "ASSIGNED_ROLE_IDS_MISSING_OR_INVALID",
        "ROLE_RECORDS_MISSING",
        "EVERYONE_ROLE_MISSING",
        "OVERWRITE_COLLECTION_MISSING",
        "CONTEXT_ID_MISSING_OR_INVALID",
        "CONTEXT_GUILD_ID_MISSING_OR_INVALID",
        "CONTEXT_TYPE_MISSING",
        "INPUT_HEALTH_MISSING",
        "INPUT_HEALTH_INVALID",
        "PERMISSION_DEFINITION_VERSION_MISSING",
        "SNAPSHOT_OR_FIXTURE_VERSION_MISSING",
    }
    if any(code in reasons for code in unknown_conditions):
        completeness_state = COMPLETENESS_UNKNOWN
    elif (
        not pass1_trustworthy
        or not context_core_valid
        or material_overwrite_failure
        or material_missing_role_reference
        or health_state != COMPLETENESS_COMPLETE
        or permission_version != PERMISSION_DEFINITION_VERSION
        or source_version not in SUPPORTED_SOURCE_VERSIONS
        or structural_metadata_partial
        or invalid_references
    ):
        completeness_state = COMPLETENESS_PARTIAL
    else:
        completeness_state = COMPLETENESS_COMPLETE
        reasons.add("CALCULATION_COMPLETE")
    if completeness_state != COMPLETENESS_COMPLETE and raw_context_value is None:
        reasons.add("RAW_CONTEXT_PERMISSION_UNAVAILABLE")
    add_trace("COMPLETENESS", state=completeness_state)

    (
        raw_guild_out,
        raw_guild_hex,
        _raw_guild_known,
        _raw_guild_known_hex,
        _raw_guild_unknown,
        _raw_guild_unknown_hex,
    ) = _permission_parts(raw_guild_value)
    (
        context_decimal,
        context_hex,
        context_known,
        context_known_hex,
        context_unknown,
        context_unknown_hex,
    ) = _permission_parts(raw_context_value)
    role_deny_decimal, role_deny_hex, _, _, _, _ = _permission_parts(role_deny)
    role_allow_decimal, role_allow_hex, _, _, _, _ = _permission_parts(role_allow)

    return ContextPermissionEvaluationResult(
        engine_contract_version=STAGE3_PASS2_ENGINE_CONTRACT_VERSION,
        pass1_contract_version=(
            pass1_contract if isinstance(pass1_contract, str) else STAGE3_PASS1_ENGINE_CONTRACT_VERSION
        ),
        permission_definition_version=permission_version,
        snapshot_or_fixture_version=source_version,
        guild_id=guild_id,
        subject_id=subject_id,
        context_id=context_id,
        context_type=context_type,
        context_parent_id=context_parent_id,
        observed_sync_state=observed_sync_state,
        bypass_state=(pass1_bypass if pass1_bypass in {BYPASS_NONE, BYPASS_OWNER, BYPASS_ADMINISTRATOR} else BYPASS_NONE),
        raw_guild_permission_decimal=raw_guild_out,
        raw_guild_permission_hex=raw_guild_hex,
        everyone_overwrite_contribution=everyone_contribution,
        applicable_role_overwrite_source_ids=tuple(sorted(set(role_source_ids), key=_sort_key)),
        combined_role_deny_decimal=role_deny_decimal,
        combined_role_deny_hex=role_deny_hex,
        combined_role_allow_decimal=role_allow_decimal,
        combined_role_allow_hex=role_allow_hex,
        member_overwrite_contribution=member_contribution,
        raw_context_permission_decimal=context_decimal,
        raw_context_permission_hex=context_hex,
        known_context_permission_bits_decimal=context_known,
        known_context_permission_bits_hex=context_known_hex,
        unknown_context_permission_bits_decimal=context_unknown,
        unknown_context_permission_bits_hex=context_unknown_hex,
        overwrites_applied=overwrites_applied,
        overwrites_bypassed=overwrites_bypassed,
        context_overwrite_collection_state=overwrite_collection_state,
        missing_role_references=tuple(sorted(set(missing_role_references), key=_sort_key)),
        invalid_references=tuple(sorted(set(invalid_references), key=_sort_key)),
        completeness_state=completeness_state,
        reason_codes=tuple(sorted(reasons)),
        trace=tuple(trace),
    )


__all__ = [
    "ContextPermissionEvaluationResult",
    "PermissionOverwriteContribution",
    "PermissionOverwriteEvaluationRequest",
    "PermissionOverwriteTraceEvent",
    "STAGE3_PASS2_ENGINE_CONTRACT_VERSION",
    "SUPPORTED_CONTEXT_TYPES",
    "evaluate_context_permissions",
]
