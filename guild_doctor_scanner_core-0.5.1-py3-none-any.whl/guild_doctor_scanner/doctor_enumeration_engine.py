"""Pure Stage 5 Pass 2 orchestration over the frozen Pass 1 Doctor API."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .canonical import canonical_json
from .doctor_aggregation import aggregate_enumeration
from .doctor_enumeration_case import DoctorEnumerationCase, build_enumeration_case
from .doctor_enumeration_query import (
    ACTION,
    ENUMERATION_QUERY_CONTRACT_VERSION,
    EXPLAIN_ACTUAL_RESULT,
    STAGE5_PASS1_CONTRACT_VERSION,
    DoctorEnumerationQuery,
    EnumerationQueryError,
    validate_enumeration_query,
)
from .doctor_population import PopulationNormalization, normalize_population
from .doctor_engine import execute_doctor_query
from .doctor_query import DOCTOR_QUERY_CONTRACT_VERSION, DoctorQuery


class DoctorEnumerationEngineError(RuntimeError):
    """Raised when strict enumeration execution is requested and fails."""


@dataclass(frozen=True, slots=True)
class DoctorEnumerationExecution:
    case: DoctorEnumerationCase
    child_queries: Mapping[str, DoctorQuery]
    child_executions: Mapping[str, Any]
    population: PopulationNormalization | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "case": self.case.as_dict(),
            "child_queries": {key: value.as_dict(include_source=False) for key, value in sorted(self.child_queries.items())},
            "child_executions": {key: _safe(value) for key, value in sorted(self.child_executions.items())},
            "population": _safe(self.population),
        }


def _safe(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _safe(method())
    if isinstance(value, Mapping):
        return {str(k): _safe(v) for k, v in sorted(value.items(), key=lambda item: str(item[0]))}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_safe(v) for v in value]
    return value


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _thaw(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_thaw(v) for v in value]
    return value


def _fingerprint_value(value: Any) -> Any:
    value = _safe(value)
    if isinstance(value, Mapping):
        result = {str(key): _fingerprint_value(child) for key, child in value.items()}
        if isinstance(result.get("candidates"), list):
            result["candidates"] = sorted(result["candidates"], key=lambda item: int(item.get("id", item.get("member_id", "0"))) if isinstance(item, Mapping) and str(item.get("id", item.get("member_id", "0"))).isdecimal() else 0)
        if isinstance(result.get("candidate_dispositions"), list):
            normalized = []
            for item in result["candidate_dispositions"]:
                if isinstance(item, Mapping):
                    item = dict(item)
                    item.pop("original_indexes", None)
                    item.pop("display_label", None)
                normalized.append(item)
            result["candidate_dispositions"] = sorted(normalized, key=lambda item: int(item.get("candidate_id", "0")) if isinstance(item, Mapping) and str(item.get("candidate_id", "0")).isdecimal() else 0)
        return result
    if isinstance(value, list):
        return [_fingerprint_value(child) for child in value]
    return value


def _hash(value: Any) -> str:
    return hashlib.sha256(canonical_json(_fingerprint_value(value)).encode("utf-8")).hexdigest()


def _record_value(record: Mapping[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in record:
            return record[key]
    return default


def _derive_child_query(query: DoctorEnumerationQuery, candidate: Any) -> DoctorQuery:
    record = _thaw(candidate.record)
    candidate_id = candidate.candidate_id
    child: dict[str, Any] = {
        "query_id": f"{query.query_id}:{candidate_id}:{query.target_kind}:{query.target_key}",
        "query_intent": EXPLAIN_ACTUAL_RESULT,
        "target_kind": query.target_kind,
        "target_key": query.target_key,
        "guild_id": query.guild_id,
        "subject_id": candidate_id,
        "actor_id": candidate_id if query.target_kind == ACTION else None,
        "target_type": query.target_type,
        "target_id": query.target_id,
        "context_id": query.context_id,
        "context_type": query.context_type,
        "parent_id": query.parent_id,
        "thread_id": query.thread_id,
        "thread_type": query.thread_type,
        "assigned_role_ids": _record_value(record, "assigned_role_ids", "role_ids"),
        "timeout_state": _record_value(record, "timeout_state"),
        "membership_state": _record_value(record, "membership_state", "thread_membership_state"),
        "bypass_state": _record_value(record, "bypass_state"),
        "explicitly_supplied_member_health": _record_value(record, "member_health", "health", "input_health", default=query.member_collection_health),
        "explicitly_supplied_role_reference_health": _record_value(record, "role_reference_health"),
        "actor_highest_role_id": _record_value(record, "highest_role_id", "actor_highest_role_id"),
        "actor_highest_role_position": _record_value(record, "highest_role_position", "actor_highest_role_position"),
        "target_highest_role_id": _record_value(query.target_attributes or {}, "highest_role_id", "target_highest_role_id"),
        "target_highest_role_position": _record_value(query.target_attributes or {}, "highest_role_position", "target_highest_role_position"),
        "target_role_managed": _record_value(query.target_attributes or {}, "managed", "target_role_managed"),
        "target_role_is_everyone": _record_value(query.target_attributes or {}, "is_everyone", "target_role_is_everyone"),
        "requested_permission_bits": _record_value(query.target_attributes or {}, "requested_permission_bits"),
        "requested_overwrite_allow_bits": _record_value(query.target_attributes or {}, "requested_overwrite_allow_bits"),
        "requested_overwrite_deny_bits": _record_value(query.target_attributes or {}, "requested_overwrite_deny_bits"),
        "actor_mfa_state": _record_value(record, "mfa_state", "actor_mfa_state"),
        "guild_mfa_level": _record_value(query.target_attributes or {}, "guild_mfa_level"),
        "voice_state": _record_value(record, "voice_state"),
        "snapshot": query.snapshot,
        "member_record": record,
        "target_record": query.target_record,
        "input_health": query.member_collection_health,
        "source_stage3_contract_versions": query.source_stage3_contract_versions or query.expected_stage3_contract_versions,
        "registry_versions": query.registry_versions,
        "permission_definition_version": query.permission_definition_version,
        "snapshot_or_fixture_version": query.snapshot_or_fixture_version,
        "explanation_mode": query.aggregate_explanation_mode,
        "presentation_profile": query.presentation_profile,
        "output_format": query.output_format,
        "labels": {"subject": candidate.display_label},
        "evidence_classifications": query.evidence_classifications or ("SYNTHETIC_ENUMERATION",),
        "verification_statuses": query.verification_statuses or ("SYNTHETIC_ENUMERATION",),
        "source_references": (f"enumeration:{query.query_id}",),
        "query_contract_version": query.expected_doctor_query_contract,
        "requested_stage5_pass1_contract": query.expected_stage5_pass1_contract,
    }
    return DoctorQuery.from_mapping(child)


def _invalid_execution(query: DoctorEnumerationQuery, errors: tuple[str, ...]) -> DoctorEnumerationExecution:
    states = ("ALLOWED", "DENIED", "INEFFECTIVE", "UNKNOWN", "NOT_APPLICABLE", "UNSUPPORTED")
    aggregation = {
        "scope": {"scope_classification": "INVALID_QUERY", "scope_statement": "The enumeration query is invalid; no candidates were evaluated.", "server_wide_claims_permitted": False, "population_complete": False, "coverage_reasons": ["QUERY_INVALID"]},
        "population_status_counts": {}, "supplied_member_count": 0, "normalized_candidate_count": 0, "evaluated_candidate_count": 0, "excluded_count": 0, "duplicate_count": 0, "invalid_count": 0, "missing_material_data_count": 0,
        "result_buckets": {state: {"count": 0, "candidate_ids": [], "display_safe_labels": [], "child_case_fingerprints": [], "entries": []} for state in states},
        "intent_result": {"matching_candidate_count": 0, "matching_candidate_ids": [], "contradicted_candidate_count": 0, "contradicted_candidate_ids": [], "unresolved_candidate_count": 0, "unresolved_candidate_ids": [], "not_applicable_count": 0, "unsupported_count": 0, "premise_alignment_counts": {}},
        "aggregation": {"result_state_counts": {}, "premise_alignment_counts": {}, "primary_reason_frequencies": [], "source_location_frequencies": [], "completeness_distribution": {}, "evidence_classification_distribution": {}, "verification_status_distribution": {}, "bypass_distribution": {}, "pre_execution_model_count": 0, "child_case_failure_count": 0, "child_case_failures": []},
        "presentation": {"direct_aggregate_answer": "The enumeration query is invalid.", "bounded_scope_wording": "No candidates were evaluated.", "summary": "0 candidates evaluated.", "matching_member_lines": [], "contradicted_member_lines": [], "unresolved_member_lines": [], "material_population_limitation": "QUERY_INVALID", "pre_execution_disclaimer": None, "no_recommendations": True, "no_risk_scoring": True},
        "population": {"owner_id": None, "member_collection_status": "INVALID", "population_fingerprint": None, "coverage_complete": False},
    }
    case = build_enumeration_case(query, aggregation=aggregation, provenance={"validation_only": True}, integrity={"source_objects_unchanged": True}, status="INVALID", errors=errors)
    return DoctorEnumerationExecution(case=case, child_queries={}, child_executions={}, population=None)


def execute_doctor_enumeration(query: DoctorEnumerationQuery | Mapping[str, Any], *, strict: bool = False) -> DoctorEnumerationExecution:
    """Evaluate each candidate through only the public Pass 1 Doctor interface."""

    try:
        parsed = query if isinstance(query, DoctorEnumerationQuery) else DoctorEnumerationQuery.from_mapping(query)
    except (EnumerationQueryError, TypeError, ValueError) as exc:
        parsed = DoctorEnumerationQuery(
            "invalid", "WHO_UNKNOWN", "CAPABILITY", "message.send", "1",
            candidates=({"id": "1", "bot": False, "role_ids": [], "timeout_state": "INACTIVE"},),
            candidate_inclusion_policy={"include_humans": True, "include_bots": True, "include_owner": True, "include_timed_out_members": True, "include_members_with_partial_data": True},
        )
        result = _invalid_execution(parsed, (f"ENUMERATION_QUERY_CONSTRUCTION:{exc}",))
        if strict:
            raise DoctorEnumerationEngineError(str(exc))
        return result
    violations = validate_enumeration_query(parsed)
    if violations:
        result = _invalid_execution(parsed, violations)
        if strict:
            raise DoctorEnumerationEngineError("; ".join(violations))
        return result

    population = normalize_population(parsed)
    before_population = canonical_json(_safe(population))
    child_queries: dict[str, DoctorQuery] = {}
    child_executions: dict[str, Any] = {}
    for candidate in population.evaluable:
        candidate_id = candidate.candidate_id or ""
        try:
            child_query = _derive_child_query(parsed, candidate)
            child_queries[candidate_id] = child_query
            child_executions[candidate_id] = execute_doctor_query(child_query)
        except Exception as exc:  # preserve one candidate failure without losing the cohort
            child_executions[candidate_id] = {"status": "FAILED", "error": exc.__class__.__name__}

    aggregation = aggregate_enumeration(parsed, population, child_executions)
    after_population = canonical_json(_safe(population))
    child_case_fingerprints = {}
    for key, value in sorted(child_executions.items()):
        case = getattr(value, "case", None)
        child_case_fingerprints[key] = getattr(case, "case_fingerprint", None)
    provenance = {
        "enumeration_query_fingerprint": _hash(parsed.as_dict(include_source=False)),
        "population_fingerprint": population.population_fingerprint,
        "child_query_fingerprints": {key: _hash(value.as_dict(include_source=False)) for key, value in sorted(child_queries.items())},
        "child_case_fingerprints": child_case_fingerprints,
        "aggregation_fingerprint": _hash(aggregation),
        "source_stage3_contract_versions": parsed.source_stage3_contract_versions or parsed.expected_stage3_contract_versions or {},
        "source_stage4_contract_versions": parsed.expected_stage4_contract_versions or {},
        "permission_definition_version": parsed.permission_definition_version,
        "registry_versions": parsed.registry_versions or {},
        "evidence_classifications": list(parsed.evidence_classifications or ("SYNTHETIC_ENUMERATION",)),
        "verification_statuses": list(parsed.verification_statuses or ("SYNTHETIC_ENUMERATION",)),
        "source_references": [f"enumeration:{parsed.query_id}"],
    }
    integrity = {
        "snapshot_unchanged": True,
        "candidate_records_unchanged": before_population == after_population,
        "doctor_cases_unchanged": True,
        "registries_unchanged": True,
        "evidence_files_unchanged": True,
        "source_objects_unchanged": before_population == after_population,
        "only_frozen_pass1_interface_invoked": True,
        "direct_stage3_invocation": False,
        "direct_stage4_invocation": False,
        "no_discord_request": True,
        "no_discord_write": True,
        "no_persistence": True,
        "no_recommendations": True,
    }
    case = build_enumeration_case(parsed, aggregation=aggregation, provenance=provenance, integrity=integrity, status="PASS")
    return DoctorEnumerationExecution(case=case, child_queries=child_queries, child_executions=child_executions, population=population)


def enumerate_doctor(query: DoctorEnumerationQuery | Mapping[str, Any], *, strict: bool = False) -> DoctorEnumerationCase:
    return execute_doctor_enumeration(query, strict=strict).case


run_doctor_enumeration = execute_doctor_enumeration
evaluate_doctor_enumeration = execute_doctor_enumeration


__all__ = [
    "DoctorEnumerationEngineError",
    "DoctorEnumerationExecution",
    "enumerate_doctor",
    "evaluate_doctor_enumeration",
    "execute_doctor_enumeration",
    "run_doctor_enumeration",
]
