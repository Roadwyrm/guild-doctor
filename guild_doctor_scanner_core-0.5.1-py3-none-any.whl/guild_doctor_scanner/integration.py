"""Disposable-guild Pass 5 integration verification harness."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Callable

from .acquisition import ReadOnlyAcquisitionAdapter, RetryPolicy, StructureAcquisition
from .authorization import evaluate_owner_authorization
from .comparison import compare_acquisition_to_snapshot, compare_snapshots
from .fixture_export import export_stage3_fixture

INTEGRATION_CONTRACT_VERSION = "GUILD-DOCTOR-INTEGRATION-0.1"


class InjectedHTTPError(RuntimeError):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status


class FaultInjectingTransport:
    """Read-only wrapper that injects one controlled collection failure."""

    def __init__(self, delegate: Any, *, fail_resource: str, status: int = 503) -> None:
        self._delegate = delegate
        self._fail_resource = fail_resource
        self._status = status
        self.source_library = delegate.source_library
        self.source_library_version = delegate.source_library_version
        self.source_api_version = delegate.source_api_version
        self.adapter_version = f"{getattr(delegate, 'adapter_version', 'UNKNOWN')}+FAULT"
        self.application_flags_value = getattr(delegate, "application_flags_value", None)

    async def read_guild(self, guild_id: int) -> dict[str, Any]:
        return await self._route("guild", self._delegate.read_guild, guild_id)

    async def read_roles(self, guild_id: int) -> list[dict[str, Any]]:
        return await self._route("roles", self._delegate.read_roles, guild_id)

    async def read_channels(self, guild_id: int) -> list[dict[str, Any]]:
        return await self._route("channels", self._delegate.read_channels, guild_id)

    async def read_active_threads(self, guild_id: int) -> dict[str, Any]:
        return await self._route("active_threads", self._delegate.read_active_threads, guild_id)

    async def read_member(self, guild_id: int, member_id: int) -> dict[str, Any]:
        return await self._delegate.read_member(guild_id, member_id)

    async def read_members_page(self, guild_id: int, *, limit: int, after: int | None) -> list[dict[str, Any]]:
        return await self._delegate.read_members_page(guild_id, limit=limit, after=after)

    async def _route(self, resource: str, operation: Any, *args: Any) -> Any:
        if resource == self._fail_resource:
            raise InjectedHTTPError(self._status, f"controlled failure for {resource}")
        return await operation(*args)


@dataclass(frozen=True, slots=True)
class IntegrationScenario:
    name: str
    status: str
    details: dict[str, Any]


@dataclass(slots=True)
class IntegrationVerificationReport:
    contract_version: str
    guild_id: str
    overall_status: str
    scenarios: list[IntegrationScenario] = field(default_factory=list)
    stage3_fixture_sha256: str | None = None
    live_execution: bool = False
    failure: dict[str, Any] | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "contract_version": self.contract_version,
            "guild_id": self.guild_id,
            "overall_status": self.overall_status,
            "live_execution": self.live_execution,
            "stage3_fixture_sha256": self.stage3_fixture_sha256,
            "scenarios": [asdict(item) for item in self.scenarios],
            "failure": self.failure,
        }


class DisposableGuildIntegrationVerifier:
    def __init__(
        self,
        transport: Any,
        *,
        network_timeout_seconds: float = 30.0,
        progress: Callable[[str], None] | None = None,
    ) -> None:
        self._transport = transport
        self._network_timeout_seconds = network_timeout_seconds
        self._progress = progress

    async def run(
        self,
        guild_id: int | str,
        *,
        expected_owner_id: int | str | None = None,
        non_owner_id: int | str | None = None,
        partial_failure_resource: str = "active_threads",
    ) -> tuple[IntegrationVerificationReport, dict[str, Any], StructureAcquisition, StructureAcquisition]:
        guild_text = _snowflake(guild_id)
        scenarios: list[IntegrationScenario] = []

        self._notify("first_scan: starting read-only structure acquisition")
        first = await ReadOnlyAcquisitionAdapter(
            self._transport,
            operation_timeout_seconds=self._network_timeout_seconds,
        ).acquire_structure(guild_text)
        self._notify("first_scan: comparing live source to normalized snapshot")
        provenance_first = compare_acquisition_to_snapshot(first)
        first_details = provenance_first.as_dict()
        first_details["acquisition_health"] = _acquisition_health(first)
        first_complete = _acquisition_is_complete(first)
        first_details["verification_complete"] = first_complete
        first_status = "PASS" if provenance_first.passed and first_complete else "FAIL"
        scenarios.append(
            IntegrationScenario("live_source_to_snapshot", first_status, first_details)
        )

        self._notify("repeat_scan: starting second read-only structure acquisition")
        second = await ReadOnlyAcquisitionAdapter(
            self._transport,
            operation_timeout_seconds=self._network_timeout_seconds,
        ).acquire_structure(guild_text)
        self._notify("repeat_scan: comparing repeat scan for structural drift")
        provenance_second = compare_acquisition_to_snapshot(second)
        drift = compare_snapshots(first.snapshot, second.snapshot)
        second_details = {
            "provenance": provenance_second.as_dict(),
            "drift": drift.as_dict(),
            "acquisition_health": _acquisition_health(second),
        }
        second_complete = _acquisition_is_complete(second)
        second_details["verification_complete"] = second_complete
        repeat_status = (
            "PASS"
            if provenance_second.passed and second_complete and drift.status in {"STABLE", "DRIFTED"}
            else "FAIL"
        )
        scenarios.append(
            IntegrationScenario(
                "repeat_scan_comparison",
                repeat_status,
                second_details,
            )
        )

        self._notify("authorization: evaluating owner and non-owner decisions")
        owner_payload = first.results.get("guild").records if first.results.get("guild") else None
        live_owner_id = owner_payload.get("owner_id") if isinstance(owner_payload, dict) else None
        owner_candidate = expected_owner_id if expected_owner_id is not None else live_owner_id
        owner_decision = evaluate_owner_authorization(
            guild_id=guild_text,
            actor_id=owner_candidate,
            owner_id=live_owner_id,
        )
        if non_owner_id is None:
            base = int(str(live_owner_id)) if str(live_owner_id).isdigit() else 1
            non_owner_id = str(base + 1)
        non_owner_decision = evaluate_owner_authorization(
            guild_id=guild_text,
            actor_id=non_owner_id,
            owner_id=live_owner_id,
        )
        auth_status = "PASS" if owner_decision.allowed and not non_owner_decision.allowed else "FAIL"
        scenarios.append(
            IntegrationScenario(
                "owner_authorization",
                auth_status,
                {
                    "owner_decision": asdict(owner_decision),
                    "non_owner_decision": asdict(non_owner_decision),
                    "owner_source": "LIVE_GUILD_GET",
                },
            )
        )

        self._notify("controlled_failure: injecting one local read failure")
        fault = FaultInjectingTransport(
            self._transport,
            fail_resource=partial_failure_resource,
            status=503,
        )
        partial = await ReadOnlyAcquisitionAdapter(
            fault,
            retry_policy=RetryPolicy(max_attempts=1, base_delay_seconds=0),
            operation_timeout_seconds=self._network_timeout_seconds,
        ).acquire_structure(guild_text)
        failed_result = partial.results[partial_failure_resource]
        partial_ok = (
            failed_result.status == "FAILED"
            and failed_result.records is None
            and partial.snapshot is not None
            and partial.snapshot.structural_completeness in {"PARTIAL", "UNKNOWN"}
        )
        scenarios.append(
            IntegrationScenario(
                "controlled_partial_failure",
                "PASS" if partial_ok else "FAIL",
                {
                    "resource": partial_failure_resource,
                    "collection_status": failed_result.status,
                    "records_is_null": failed_result.records is None,
                    "snapshot_produced": partial.snapshot is not None,
                    "structural_completeness": (
                        partial.snapshot.structural_completeness if partial.snapshot is not None else None
                    ),
                    "error_codes": [error.code for error in failed_result.errors],
                    "errors": [asdict(error) for error in failed_result.errors],
                },
            )
        )

        self._notify("fixture_export: exporting the privacy-minimized fixture")
        if first.snapshot is None:
            fixture = {"error": "first live scan did not produce a snapshot"}
            fixture_sha = None
            scenarios.append(IntegrationScenario("stage3_fixture_export", "FAIL", fixture))
        else:
            exported = export_stage3_fixture(first.snapshot, anonymize=True)
            fixture = exported.fixture
            fixture_sha = exported.sha256
            scenarios.append(
                IntegrationScenario(
                    "stage3_fixture_export",
                    "PASS",
                    {
                        "fixture_version": fixture.get("fixture_version"),
                        "fixture_sha256": fixture_sha,
                        "anonymized_ids": True,
                    },
                )
            )

        overall = "PASS" if all(item.status == "PASS" for item in scenarios) else "FAIL"
        self._notify(f"verification: completed with status {overall}")
        failure = None
        if overall != "PASS":
            failure = {
                "stage": "verification",
                "code": "INCOMPLETE_VERIFICATION",
                "message": "one or more required Pass 5 verification scenarios did not pass",
                "failed_scenarios": [item.name for item in scenarios if item.status != "PASS"],
            }
        report = IntegrationVerificationReport(
            contract_version=INTEGRATION_CONTRACT_VERSION,
            guild_id=guild_text,
            overall_status=overall,
            scenarios=scenarios,
            stage3_fixture_sha256=fixture_sha,
            live_execution=True,
            failure=failure,
        )
        return report, fixture, first, partial

    def _notify(self, message: str) -> None:
        if self._progress is not None:
            self._progress(message)


def _snowflake(value: int | str) -> str:
    if isinstance(value, bool):
        raise ValueError("guild_id must be a positive decimal snowflake")
    text = str(value).strip()
    if not text.isdecimal() or int(text) <= 0:
        raise ValueError("guild_id must be a positive decimal snowflake")
    return str(int(text))


def _acquisition_health(acquisition: StructureAcquisition) -> dict[str, Any]:
    """Expose collection failures without retaining raw Discord payloads."""

    return {
        "snapshot_produced": acquisition.snapshot is not None,
        "all_required_resources_complete": _acquisition_is_complete(acquisition),
        "normalization_error": acquisition.normalization_error,
        "resources": {
            name: {
                "status": result.status,
                "attempt_count": result.attempt_count,
                "http_or_library_status": result.http_or_library_status,
                "errors": [asdict(error) for error in result.errors],
            }
            for name, result in sorted(acquisition.results.items())
        },
    }


def _acquisition_is_complete(acquisition: StructureAcquisition) -> bool:
    return acquisition.snapshot is not None and all(
        result.status == "COMPLETE" for result in acquisition.results.values()
    )
