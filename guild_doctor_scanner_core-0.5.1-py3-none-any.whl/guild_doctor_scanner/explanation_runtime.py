"""Local, read-only runtime surface for the frozen Stage 4 explanation path.

This module deliberately has no Discord, Gateway, HTTP, persistence, command,
or environment-token dependency.  It accepts JSON-shaped queries, invokes only
the public Stage 4 Pass 3 orchestrator, and writes bounded local output through
the CLI layer.  Live-derived verification reads already-created Stage 3 files;
it never contacts Discord and never mutates those files.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .canonical import canonical_json
from .explanation_orchestrator import orchestrate_explanation
from .explanation_query import (
    EXPLANATION_QUERY_CONTRACT_VERSION,
    ExplanationQuery,
    ExplanationQueryError,
    validate_explanation_query,
)
from .explanation_adapters import EXPLANATION_ADAPTERS_VERSION
from .explanation_schema import EXPLANATION_RULES_VERSION, EXPLANATION_SCHEMA_VERSION
from .presentation_profiles import PRESENTATION_PROFILE_VERSION, get_presentation_profile
from .scenario_manifest import hash_identifier, load_scenario_manifest


STAGE4_PASS4_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE4-PASS4-0.1"
EXPLANATION_RUNTIME_CONTRACT_VERSION = "GUILD-DOCTOR-EXPLANATION-RUNTIME-0.1"
EXPLANATION_BATCH_CONTRACT_VERSION = "GUILD-DOCTOR-EXPLANATION-BATCH-0.1"
EXPLANATION_RUNTIME_GOLDEN_VERSION = "GUILD-DOCTOR-EXPLANATION-RUNTIME-GOLDEN-0.1"

RUNTIME_EXIT_SUCCESS = 0
RUNTIME_EXIT_UNKNOWN = 2
RUNTIME_EXIT_ARGUMENTS = 10
RUNTIME_EXIT_INVALID_QUERY = 11
RUNTIME_EXIT_UNSUPPORTED_CONTRACT = 12
RUNTIME_EXIT_INPUT_FAILURE = 13
RUNTIME_EXIT_OUTPUT_FAILURE = 14
RUNTIME_EXIT_ORCHESTRATION_FAILURE = 15
RUNTIME_EXIT_BATCH_PARTIAL = 16
RUNTIME_EXIT_EVIDENCE_FAILURE = 17
RUNTIME_EXIT_CLOSURE_PENDING = 18
RUNTIME_EXIT_INTERRUPTED = 130

_SECRET_KEY_FRAGMENTS = ("token", "authorization", "access_token", "client_secret", "password", "api_key", "credential")
_TOKEN_LIKE_RE = re.compile(r"(?i)(?:^|[^A-Za-z0-9_-])(?:Bot\s+)?[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{20,}(?:$|[^A-Za-z0-9_-])")
_SNOWFLAKE_RE = re.compile(r"(?<!\d)\d{15,20}(?!\d)")
_QUERY_ALLOWED_KEYS = frozenset(
    {
        "query_contract_version", "requested_stage4_pass3_contract", "expected_adapter_registry_version",
        "expected_explanation_schema_version", "expected_explanation_rules_version",
        "expected_presentation_profile_version", "query_id", "query_type", "result_family",
        "source_contract", "source_result", "source_trace", "result", "trace", "guild_id",
        "subject_id", "subject_or_actor_id", "actor_id", "target_type", "target_id", "context_id",
        "context_type", "thread_id", "thread_type", "source_stage3_contract_versions", "contract_versions",
        "registry_versions", "permission_definition_version", "completeness_state", "evidence_classifications",
        "verification_statuses", "source_references", "explanation_mode", "mode", "presentation_profile",
        "output_format", "labels", "disclosure_policy", "section_policy", "presentation_limits", "title",
        "explicit_id_disclosure_allowed", "authoritative_closure", "closure_evidence", "historical_evidence",
    }
)


def _is_secret_key(key: str) -> bool:
    lower = key.lower()
    if lower in {"token_disclosure_status", "token_redaction_status", "token_input"}:
        return False
    return any(fragment in lower for fragment in _SECRET_KEY_FRAGMENTS)


def _looks_like_token(value: str) -> bool:
    if not _TOKEN_LIKE_RE.search(value):
        return False
    # A dotted Python qualified name is not a Discord credential.
    return re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*){2}", value.strip()) is None


class RuntimeValidationError(ValueError):
    """Raised when a local runtime input is not safe or valid."""


class RuntimeInputError(RuntimeError):
    """Raised when a local input cannot be read or verified."""


class RuntimeOutputError(RuntimeError):
    """Raised when a local output cannot be written safely."""


def _copy_json(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _copy_json(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [_copy_json(child) for child in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _contains_secret(value: Any, path: str = "value") -> list[str]:
    violations: list[str] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            lower = key_text.lower()
            child_path = f"{path}.{key_text}"
            if _is_secret_key(lower):
                violations.append(f"CREDENTIAL_FIELD:{child_path}")
            violations.extend(_contains_secret(child, child_path))
    elif isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            violations.extend(_contains_secret(child, f"{path}[{index}]"))
    elif isinstance(value, str) and _looks_like_token(value):
        violations.append(f"TOKEN_SHAPED_VALUE:{path}")
    return violations


def _assert_mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise RuntimeValidationError(f"{label} must be a JSON object")
    return value


def _safe_path(value: str | Path, *, label: str) -> Path:
    path = Path(value)
    if not str(path).strip():
        raise RuntimeValidationError(f"{label} is empty")
    if any(part == ".." for part in path.parts):
        raise RuntimeValidationError(f"{label} contains path traversal")
    return path


def _read_json(path: str | Path) -> tuple[Path, Any, str]:
    safe_path = _safe_path(path, label="input path")
    try:
        raw = safe_path.read_bytes()
    except (OSError, UnicodeError) as exc:
        raise RuntimeInputError(f"INPUT_READ_FAILED:{safe_path}:{type(exc).__name__}") from exc
    try:
        text = raw.decode("utf-8")
        value = json.loads(text)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeInputError(f"INPUT_JSON_INVALID:{safe_path}:{type(exc).__name__}") from exc
    secret_errors = _contains_secret(value)
    if secret_errors:
        raise RuntimeValidationError("TOKEN_OR_CREDENTIAL_INPUT_REJECTED")
    return safe_path, value, hashlib.sha256(raw).hexdigest()


def _atomic_write(path: str | Path, payload: bytes, *, overwrite: bool = False) -> Path:
    target = _safe_path(path, label="output path")
    if target.exists() and not overwrite:
        raise RuntimeOutputError(f"OUTPUT_EXISTS:{target}")
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, target)
        except Exception:
            try:
                os.unlink(temporary_name)
            except OSError:
                pass
            raise
    except (OSError, UnicodeError) as exc:
        raise RuntimeOutputError(f"OUTPUT_WRITE_FAILED:{target}:{type(exc).__name__}") from exc
    return target


def write_json(path: str | Path, value: Mapping[str, Any], *, overwrite: bool = False) -> Path:
    """Write deterministic UTF-8 JSON using an atomic local replacement."""

    secret_errors = _contains_secret(value)
    if secret_errors:
        raise RuntimeValidationError("TOKEN_OR_CREDENTIAL_OUTPUT_REJECTED")
    return _atomic_write(path, (canonical_json(dict(value)) + "\n").encode("utf-8"), overwrite=overwrite)


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int) and value > 0:
        return str(value)
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def validate_query_mapping(value: Mapping[str, Any]) -> tuple[str, ...]:
    """Validate one query without network, Discord, or filesystem side effects."""

    if not isinstance(value, Mapping):
        return ("QUERY_NOT_MAPPING",)
    errors = list(_contains_secret(value, "query"))
    unknown = sorted(set(map(str, value)) - _QUERY_ALLOWED_KEYS)
    errors.extend(f"QUERY_UNKNOWN_FIELD:{key}" for key in unknown)
    try:
        query = ExplanationQuery.from_mapping(value)
    except (ExplanationQueryError, TypeError, ValueError) as exc:
        errors.append(f"QUERY_CONSTRUCTION:{exc}")
        return tuple(sorted(set(errors)))
    errors.extend(validate_explanation_query(query))
    return tuple(sorted(set(errors)))


def load_query(path: str | Path) -> tuple[Path, ExplanationQuery, str]:
    source_path, raw, digest = _read_json(path)
    if not isinstance(raw, Mapping):
        raise RuntimeValidationError("QUERY_NOT_MAPPING")
    errors = validate_query_mapping(raw)
    if errors:
        raise RuntimeValidationError(";".join(errors))
    return source_path, ExplanationQuery.from_mapping(raw), digest


@dataclass(frozen=True, slots=True)
class RuntimeExecutionResult:
    runtime_contract_version: str
    query_id: str | None
    status: str
    result_state: str | None
    exit_code: int
    failure_classification: str | None
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    output_format: str | None
    presentation_profile: str | None
    orchestration: Mapping[str, Any] | None
    source_objects_unchanged: bool
    token_disclosure_status: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS" and self.exit_code in {RUNTIME_EXIT_SUCCESS, RUNTIME_EXIT_UNKNOWN}

    def as_dict(self) -> dict[str, Any]:
        return {
            "runtime_contract_version": self.runtime_contract_version,
            "query_id": self.query_id,
            "status": self.status,
            "result_state": self.result_state,
            "exit_code": self.exit_code,
            "failure_classification": self.failure_classification,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "output_format": self.output_format,
            "presentation_profile": self.presentation_profile,
            "orchestration": _copy_json(self.orchestration),
            "source_objects_unchanged": self.source_objects_unchanged,
            "token_disclosure_status": self.token_disclosure_status,
            "passed": self.passed,
        }


def execute_query(query: ExplanationQuery | Mapping[str, Any]) -> RuntimeExecutionResult:
    """Execute one validated query through the only public Pass 3 orchestrator."""

    if isinstance(query, ExplanationQuery):
        parsed = query
        errors = validate_explanation_query(parsed)
    else:
        errors = validate_query_mapping(query)
        parsed = None
        if not errors:
            parsed = ExplanationQuery.from_mapping(query)
    if errors or parsed is None:
        return RuntimeExecutionResult(
            EXPLANATION_RUNTIME_CONTRACT_VERSION, getattr(parsed, "query_id", None), "FAIL", None,
            RUNTIME_EXIT_INVALID_QUERY, "INPUT_VALIDATION", tuple(errors or ("QUERY_INVALID",)), (), None,
            getattr(parsed, "presentation_profile", None), None, True, "PASS_NO_TOKEN_INPUT",
        )
    try:
        result = orchestrate_explanation(parsed, strict=False)
    except KeyboardInterrupt:
        raise
    except Exception as exc:
        return RuntimeExecutionResult(
            EXPLANATION_RUNTIME_CONTRACT_VERSION, parsed.query_id, "FAIL", None,
            RUNTIME_EXIT_ORCHESTRATION_FAILURE, "ORCHESTRATION", (f"{type(exc).__name__}:{exc}",), (),
            parsed.output_format, parsed.presentation_profile, None, True, "PASS_NO_TOKEN_INPUT",
        )
    if result.errors or not result.passed:
        return RuntimeExecutionResult(
            EXPLANATION_RUNTIME_CONTRACT_VERSION, parsed.query_id, "FAIL", None,
            RUNTIME_EXIT_ORCHESTRATION_FAILURE, "ORCHESTRATION", tuple(result.errors or ("ORCHESTRATION_INCOMPLETE",)),
            tuple(result.warnings), result.output_format, result.presentation_profile, result.as_dict(),
            result.source_objects_unchanged, "PASS_NO_TOKEN_INPUT",
        )
    state = result.explanation_result.result_state if result.explanation_result is not None else None
    exit_code = RUNTIME_EXIT_UNKNOWN if state == "UNKNOWN" else RUNTIME_EXIT_SUCCESS
    return RuntimeExecutionResult(
        EXPLANATION_RUNTIME_CONTRACT_VERSION, parsed.query_id, "PASS", state, exit_code,
        "MODELED_UNKNOWN" if state == "UNKNOWN" else None, tuple(result.errors), tuple(result.warnings),
        result.output_format, result.presentation_profile, result.as_dict(), result.source_objects_unchanged,
        "PASS_NO_TOKEN_INPUT",
    )


def presentation_payload(result: RuntimeExecutionResult) -> str:
    if not result.orchestration or result.status != "PASS":
        raise RuntimeOutputError("PRESENTATION_UNAVAILABLE")
    presentation = result.orchestration.get("presentation_result")
    if not isinstance(presentation, Mapping):
        raise RuntimeOutputError("PRESENTATION_UNAVAILABLE")
    output_format = str(presentation.get("output_format", "PLAIN_TEXT"))
    if output_format == "PLAIN_TEXT":
        return str(presentation.get("plain_text") or "") + "\n"
    if output_format == "DISCORD_MARKDOWN":
        return str(presentation.get("discord_markdown") or "") + "\n"
    structured = presentation.get("structured_json")
    if not isinstance(structured, Mapping):
        raise RuntimeOutputError("STRUCTURED_PRESENTATION_UNAVAILABLE")
    return canonical_json(dict(structured)) + "\n"


def validate_batch_mapping(value: Mapping[str, Any]) -> tuple[str, ...]:
    if not isinstance(value, Mapping):
        return ("BATCH_NOT_MAPPING",)
    errors = list(_contains_secret(value, "batch"))
    if value.get("contract") != EXPLANATION_BATCH_CONTRACT_VERSION:
        errors.append("BATCH_CONTRACT_UNSUPPORTED")
    batch_id = value.get("batch_id")
    if not isinstance(batch_id, str) or not batch_id.strip() or any(part in batch_id for part in ("..", "\\", "/")):
        errors.append("BATCH_ID_INVALID")
    queries = value.get("queries")
    if not isinstance(queries, Sequence) or isinstance(queries, (str, bytes)) or not queries:
        errors.append("BATCH_QUERIES_EMPTY")
    else:
        query_ids: set[str] = set()
        for index, raw_query in enumerate(queries):
            if not isinstance(raw_query, Mapping):
                errors.append(f"BATCH_QUERY_NOT_MAPPING:{index}")
                continue
            query_id = raw_query.get("query_id")
            if not isinstance(query_id, str) or not query_id.strip() or any(part in query_id for part in ("..", "\\", "/")):
                errors.append(f"BATCH_QUERY_ID_INVALID:{index}")
            elif query_id in query_ids:
                errors.append(f"BATCH_QUERY_ID_DUPLICATE:{query_id}")
            query_ids.add(str(query_id))
            errors.extend(f"BATCH_QUERY_{index}:{item}" for item in validate_query_mapping(raw_query))
    policy = value.get("output_policy", {})
    if policy is not None and not isinstance(policy, Mapping):
        errors.append("BATCH_OUTPUT_POLICY_INVALID")
    failure_policy = value.get("failure_policy", "CONTINUE")
    if str(failure_policy).upper() not in {"CONTINUE", "FAIL_FAST"}:
        errors.append("BATCH_FAILURE_POLICY_INVALID")
    return tuple(sorted(set(errors)))


def execute_batch(value: Mapping[str, Any]) -> tuple[dict[str, Any], tuple[RuntimeExecutionResult, ...]]:
    errors = validate_batch_mapping(value)
    if errors:
        raise RuntimeValidationError(";".join(errors))
    results: list[RuntimeExecutionResult] = []
    failure_policy = str(value.get("failure_policy", "CONTINUE")).upper()
    for raw_query in value["queries"]:
        result = execute_query(raw_query)
        results.append(result)
        if failure_policy == "FAIL_FAST" and not result.passed:
            break
    failed = [result for result in results if not result.passed]
    unknown = [result for result in results if result.exit_code == RUNTIME_EXIT_UNKNOWN]
    status = "FAIL" if failed else "PASS"
    exit_code = RUNTIME_EXIT_BATCH_PARTIAL if failed else (RUNTIME_EXIT_UNKNOWN if unknown else RUNTIME_EXIT_SUCCESS)
    summary = {
        "runtime_batch_contract_version": EXPLANATION_BATCH_CONTRACT_VERSION,
        "batch_id": str(value["batch_id"]),
        "status": status,
        "exit_code": exit_code,
        "failure_policy": failure_policy,
        "ordered_query_ids": [result.query_id for result in results],
        "query_count": len(results),
        "completed_count": sum(result.passed for result in results),
        "failed_count": len(failed),
        "unknown_count": len(unknown),
        "evidence_classifications": list(value.get("evidence_classifications", [])),
        "results": [result.as_dict() for result in results],
        "token_disclosure_status": "PASS_NO_TOKEN_INPUT",
    }
    return summary, tuple(results)


def _project_action_identities(value: Any, identities: Mapping[str, str]) -> Any:
    """Project hashed/null Stage 3 identities into a private in-memory query.

    Stage 3 evidence remains untouched.  A missing context or thread is bound to
    the guild only to satisfy the frozen adapter's shape; reports label this as
    a representation projection and redact the resulting decimal IDs.
    """

    if isinstance(value, Mapping):
        return {
            str(key): _project_action_identities(
                identities.get(str(key), value[key])
                if str(key) in identities and (value[key] is None or (isinstance(value[key], str) and value[key].startswith("sha256:")))
                else value[key],
                identities,
            )
            for key in value
        }
    if isinstance(value, list):
        return [_project_action_identities(child, identities) for child in value]
    if isinstance(value, tuple):
        return tuple(_project_action_identities(child, identities) for child in value)
    return value


def _redact_ids(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {
            str(key): _redact_ids(child)
            for key, child in value.items()
            if str(key).lower() not in {"token", "authorization", "access_token"}
        }
    if isinstance(value, list):
        return [_redact_ids(child) for child in value]
    if isinstance(value, tuple):
        return [_redact_ids(child) for child in value]
    if isinstance(value, str):
        return _SNOWFLAKE_RE.sub(lambda match: hash_identifier(match.group(0)), value)
    return value


def _scenario_by_operation(manifest: Any, operation_key: str) -> Any:
    for scenario in manifest:
        if scenario.operation_key == operation_key:
            return scenario
    raise RuntimeInputError(f"SCENARIO_MISSING:{operation_key}")


def verify_live_derived(
    evidence_directory: str | Path,
    scenario_manifest_path: str | Path,
    *,
    output_directory: str | Path | None = None,
) -> dict[str, Any]:
    """Render six local presentations for each of the three frozen actions."""

    evidence_dir = _safe_path(evidence_directory, label="evidence directory")
    scenario_path = _safe_path(scenario_manifest_path, label="scenario manifest path")
    if output_directory is None:
        output_dir = evidence_dir
    else:
        output_dir = _safe_path(output_directory, label="output directory")
    action_path = evidence_dir / "action_results.json"
    try:
        action_bytes = action_path.read_bytes()
    except OSError as exc:
        raise RuntimeInputError(f"EVIDENCE_READ_FAILED:{action_path}") from exc
    try:
        actions = json.loads(action_bytes.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeInputError("ACTION_EVIDENCE_INVALID") from exc
    if not isinstance(actions, list) or not actions:
        raise RuntimeInputError("ACTION_EVIDENCE_EMPTY")
    try:
        scenarios = load_scenario_manifest(scenario_path)
    except (OSError, ValueError, TypeError) as exc:
        raise RuntimeInputError(f"SCENARIO_MANIFEST_INVALID:{type(exc).__name__}") from exc
    profiles = (
        ("SIMPLE_CARD", "PLAIN_TEXT"),
        ("DETAILED_REPORT", "PLAIN_TEXT"),
        ("TECHNICAL_RECORD", "PLAIN_TEXT"),
        ("DISCORD_SAFE_SIMPLE", "DISCORD_MARKDOWN"),
        ("DISCORD_SAFE_DETAILED", "DISCORD_MARKDOWN"),
        ("MACHINE_JSON", "STRUCTURED_JSON"),
    )
    presentations: list[dict[str, Any]] = []
    action_summaries: list[dict[str, Any]] = []
    for action in actions:
        if not isinstance(action, Mapping):
            raise RuntimeInputError("ACTION_RESULT_NOT_MAPPING")
        operation_key = str(action.get("operation_key", ""))
        scenario = _scenario_by_operation(scenarios, operation_key)
        identities = {
            "guild_id": scenario.guild_id,
            "actor_id": scenario.actor_member_id,
            "subject_id": scenario.actor_member_id,
            "target_id": scenario.target_id or scenario.guild_id,
            "context_id": scenario.context_id or scenario.guild_id,
            "thread_id": scenario.thread_id or scenario.guild_id,
            "parent_channel_id": scenario.context_id or scenario.guild_id,
        }
        projected = _project_action_identities(action, identities)
        projection_trace = projected.get("trace", ()) if isinstance(projected, Mapping) else ()
        base = {
            "query_type": "EXPLAIN_ACTION_RESULT",
            "result_family": "ACTION",
            "source_contract": "GUILD-DOCTOR-STAGE3-PASS6-0.1",
            "source_result": projected,
            "source_trace": projection_trace,
            "guild_id": scenario.guild_id,
            "actor_id": scenario.actor_member_id,
            "subject_id": scenario.actor_member_id,
            "target_type": projected.get("target_type", scenario.target_type),
            "target_id": identities["target_id"],
            "context_id": identities["context_id"],
            "context_type": projected.get("context_type") or ("TEXT" if scenario.context_id else "GUILD"),
            "thread_id": identities["thread_id"],
            "thread_type": projected.get("thread_type"),
            "source_stage3_contract_versions": {
                key: projected[key]
                for key in ("pass1_contract_version", "pass2_contract_version", "pass3_contract_version", "pass4_contract_version", "pass5_contract_version", "pass6_contract_version")
                if key in projected
            },
            "permission_definition_version": projected.get("permission_definition_version"),
            "registry_versions": projected.get("registry_versions", {}),
            "completeness_state": projected.get("analysis_completeness"),
            "evidence_classifications": projected.get("evidence_classifications", ()),
            "verification_statuses": projected.get("verification_statuses", ()),
            "source_references": projected.get("source_references", ()),
            "authoritative_closure": {"source": "STAGE3_PASS6_EVIDENCE", "status": "COMPLETE"},
        }
        action_presentations = []
        for index, (profile, output_format) in enumerate(profiles, start=1):
            raw_query = dict(base)
            raw_query.update({
                "query_id": f"P4-{operation_key}-{index:02d}",
                "presentation_profile": profile,
                "output_format": output_format,
                "title": f"Live-derived {operation_key} explanation",
            })
            runtime_result = execute_query(raw_query)
            if not runtime_result.passed:
                raise RuntimeInputError(f"LIVE_DERIVED_ORCHESTRATION_FAILED:{operation_key}:{profile}:{runtime_result.errors}")
            safe_result = _redact_ids(runtime_result.as_dict())
            presentation = {
                "profile_key": profile,
                "output_format": output_format,
                "runtime_result": safe_result,
                "state": runtime_result.result_state,
                "presentation_fingerprint": runtime_result.orchestration.get("presentation_fingerprint") if runtime_result.orchestration else None,
                "identity_projection": "IN_MEMORY_ONLY_REDACTED",
                "source_objects_unchanged": runtime_result.source_objects_unchanged,
            }
            presentations.append({"operation_key": operation_key, "scenario_id": scenario.scenario_id, **presentation})
            action_presentations.append({"profile_key": profile, "output_format": output_format, "state": runtime_result.result_state, "passed": runtime_result.passed, "source_objects_unchanged": runtime_result.source_objects_unchanged})
        action_summaries.append({
            "operation_key": operation_key,
            "scenario_id": scenario.scenario_id,
            "presentation_count": len(action_presentations),
            "presentations": action_presentations,
            "source_objects_unchanged": all(item["source_objects_unchanged"] for item in action_presentations),
        })
    unchanged = hashlib.sha256(action_path.read_bytes()).hexdigest() == hashlib.sha256(action_bytes).hexdigest()
    report = {
        "contract": STAGE4_PASS4_CONTRACT_VERSION,
        "runtime_contract_version": EXPLANATION_RUNTIME_CONTRACT_VERSION,
        "live_derived": True,
        "network_contacted": False,
        "discord_requests": 0,
        "discord_write_requests": 0,
        "ai_or_model_invocation": False,
        "source_objects_unchanged": unchanged,
        "evidence_file_unchanged": unchanged,
        "identity_projection": "IN_MEMORY_ONLY_REDACTED",
        "member_ids_in_report": "REDACTED_OR_HASHED",
        "presentation_profiles": [profile for profile, _ in profiles],
        "action_count": len(action_summaries),
        "presentation_count": len(presentations),
        "action_summaries": action_summaries,
        "presentations": presentations,
        "token_disclosure_status": "PASS_NO_TOKEN_INPUT",
        "status": "PASS" if unchanged and len(presentations) == 18 else "FAIL",
        "result": "PASS" if unchanged and len(presentations) == 18 else "FAIL",
    }
    output_path = output_dir / "live_derived_explanations.json"
    write_json(output_path, report, overwrite=True)
    return report


def runtime_contract_report() -> dict[str, Any]:
    return {
        "contract": STAGE4_PASS4_CONTRACT_VERSION,
        "runtime_contract_version": EXPLANATION_RUNTIME_CONTRACT_VERSION,
        "batch_contract_version": EXPLANATION_BATCH_CONTRACT_VERSION,
        "golden_fixture_version": EXPLANATION_RUNTIME_GOLDEN_VERSION,
        "query_contract_version": EXPLANATION_QUERY_CONTRACT_VERSION,
        "adapter_registry_version": EXPLANATION_ADAPTERS_VERSION,
        "explanation_schema_version": EXPLANATION_SCHEMA_VERSION,
        "explanation_rules_version": EXPLANATION_RULES_VERSION,
        "presentation_profile_version": PRESENTATION_PROFILE_VERSION,
        "public_orchestrator": "guild_doctor_scanner.explanation_orchestrator.orchestrate_explanation",
        "read_only": True,
        "network": False,
        "discord_mutation": False,
        "token_input": False,
        "supported_profiles": [get_presentation_profile(key).profile_key for key in ("SIMPLE_CARD", "DETAILED_REPORT", "TECHNICAL_RECORD", "DISCORD_SAFE_SIMPLE", "DISCORD_SAFE_DETAILED", "MACHINE_JSON")],
    }


__all__ = [
    "EXPLANATION_BATCH_CONTRACT_VERSION", "EXPLANATION_RUNTIME_CONTRACT_VERSION",
    "EXPLANATION_RUNTIME_GOLDEN_VERSION", "RUNTIME_EXIT_ARGUMENTS", "RUNTIME_EXIT_BATCH_PARTIAL",
    "RUNTIME_EXIT_CLOSURE_PENDING", "RUNTIME_EXIT_EVIDENCE_FAILURE", "RUNTIME_EXIT_INPUT_FAILURE",
    "RUNTIME_EXIT_INTERRUPTED", "RUNTIME_EXIT_INVALID_QUERY", "RUNTIME_EXIT_ORCHESTRATION_FAILURE",
    "RUNTIME_EXIT_OUTPUT_FAILURE", "RUNTIME_EXIT_SUCCESS", "RUNTIME_EXIT_UNKNOWN",
    "RuntimeExecutionResult", "RuntimeInputError", "RuntimeOutputError", "RuntimeValidationError",
    "STAGE4_PASS4_CONTRACT_VERSION", "execute_batch", "execute_query", "load_query",
    "presentation_payload", "runtime_contract_report", "validate_batch_mapping", "validate_query_mapping",
    "verify_live_derived", "write_json",
]
