"""Same-process hidden token acquisition with test-only injection."""
from __future__ import annotations
from dataclasses import dataclass
import getpass
SECURE_TOKEN_CONTRACT="GUILD-DOCTOR-PASS5-SECURE-TOKEN-0.1"
class TokenInputError(Exception):pass
@dataclass
class HiddenTokenProvider:
 test_only:bool=False
 def get(self)->str:
  value=getpass.getpass('Guild Doctor bot token: ', echo_char='*')
  if not value:raise TokenInputError('PASS5_TOKEN_INPUT_FAILED')
  print('Token received securely.')
  return value
@dataclass
class FakeTokenProvider:
 value:str='TEST_ONLY_TOKEN';test_only:bool=True
 def get(self)->str:
  if not self.test_only:raise TokenInputError('PASS5_TOKEN_INPUT_FAILED')
  return self.value
def redacted_status()->dict:return {'token_redacted':True,'token_logged':False,'token_persisted':False,'same_process_only':True}
