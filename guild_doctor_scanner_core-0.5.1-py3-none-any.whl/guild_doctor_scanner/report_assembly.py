"""Pure Stage 7 Pass 3 report assembly; no export or presentation runtime."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from .audit_contract import scan_report_private
from .canonical import sha256_hex
from .server_atlas import SERVER_ATLAS_CONTRACT, ServerAtlas

REPORT_CONTRACT="GUILD-DOCTOR-REPORT-0.1"
STAGE7_PASS3_CONTRACT="GUILD-DOCTOR-STAGE7-PASS3-REPORT-ASSEMBLY-0.1"
SECTION_ORDER=("REPORT_IDENTITY_AND_PROVENANCE","SERVER_OVERVIEW","EVIDENCE_HEALTH_AND_COMPLETENESS","PRIORITY_REVIEW_SUMMARY","ROLES_AND_AUTHORITY","CATEGORIES_AND_CHANNELS","PERMISSION_EXCEPTIONS_AND_SYNCHRONIZATION","MEMBER_SPECIFIC_OVERWRITE_REVIEW","AUDIT_FINDINGS","INCOMPLETE_OR_UNKNOWN_EVIDENCE","TECHNICAL_TRACE_REFERENCES","BEGINNER_ORIENTED_NEXT_REVIEW_STEPS")
class ReportAssemblyError(ValueError): pass
@dataclass(frozen=True,slots=True)
class ReportSection:
 section_id:str; ordinal:int; state:str; items:tuple[dict[str,Any],...]; total_item_count:int; continuation_id:str|None
 def as_dict(self): return {"section_id":self.section_id,"ordinal":self.ordinal,"state":self.state,"items":list(self.items),"total_item_count":self.total_item_count,"continuation_id":self.continuation_id}
@dataclass(frozen=True,slots=True)
class GuildDoctorReport:
 atlas_fingerprint:str; source_snapshot_fingerprint:str; sections:tuple[ReportSection,...]; report_contract:str=REPORT_CONTRACT; pass3_contract:str=STAGE7_PASS3_CONTRACT; report_fingerprint:str=""
 def __post_init__(self):
  if tuple(x.section_id for x in self.sections)!=SECTION_ORDER: raise ReportAssemblyError("REPORT_SECTION_ORDER_INVALID")
  p=self.as_dict(False)
  if scan_report_private(p,"report"): raise ReportAssemblyError("REPORT_PRIVACY_FAILED")
  f=sha256_hex(p)
  if self.report_fingerprint and self.report_fingerprint!=f: raise ReportAssemblyError("REPORT_FINGERPRINT_MISMATCH")
  object.__setattr__(self,"report_fingerprint",f)
 def as_dict(self,include_fingerprint=True):
  d={"report_contract":self.report_contract,"pass3_contract":self.pass3_contract,"atlas_fingerprint":self.atlas_fingerprint,"source_snapshot_fingerprint":self.source_snapshot_fingerprint,"sections":[x.as_dict() for x in self.sections]}
  if include_fingerprint:d["report_fingerprint"]=self.report_fingerprint
  return d
def assemble_report(atlas:ServerAtlas,*,review_steps:tuple[dict[str,Any],...]=())->GuildDoctorReport:
 if not isinstance(atlas,ServerAtlas) or atlas.atlas_contract!=SERVER_ATLAS_CONTRACT: raise ReportAssemblyError("REPORT_ATLAS_INVALID")
 if scan_report_private(review_steps,"report.review_steps"): raise ReportAssemblyError("REPORT_PRIVACY_FAILED")
 maps={"SERVER_OVERVIEW":(dict(atlas.guild_overview),),"EVIDENCE_HEALTH_AND_COMPLETENESS":tuple({"collection":k,"state":v} for k,v in sorted(atlas.collection_health.items())),"ROLES_AND_AUTHORITY":atlas.role_inventory,"CATEGORIES_AND_CHANNELS":atlas.category_inventory+atlas.channel_inventory,"PERMISSION_EXCEPTIONS_AND_SYNCHRONIZATION":atlas.synchronization_summaries,"AUDIT_FINDINGS":atlas.aggregated_finding_references,"INCOMPLETE_OR_UNKNOWN_EVIDENCE":atlas.incomplete_evidence_references,"TECHNICAL_TRACE_REFERENCES":atlas.trace_references,"BEGINNER_ORIENTED_NEXT_REVIEW_STEPS":tuple(sorted((dict(x) for x in review_steps),key=sha256_hex))}
 maps["PRIORITY_REVIEW_SUMMARY"]=atlas.aggregated_finding_references; maps["MEMBER_SPECIFIC_OVERWRITE_REVIEW"]=atlas.overwrite_exception_summaries; maps["REPORT_IDENTITY_AND_PROVENANCE"]=( {"atlas_fingerprint":atlas.atlas_fingerprint,"source_snapshot_fingerprint":atlas.source_snapshot_fingerprint}, )
 sections=tuple(ReportSection(key,i+1,"COMPLETE" if items else "NOT_APPLICABLE",tuple(items),len(items),None) for i,(key,items) in enumerate((k,maps.get(k,())) for k in SECTION_ORDER))
 return GuildDoctorReport(atlas.atlas_fingerprint,atlas.source_snapshot_fingerprint,sections)
