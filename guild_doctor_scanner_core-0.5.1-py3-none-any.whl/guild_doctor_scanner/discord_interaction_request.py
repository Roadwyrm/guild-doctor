"""Immutable, Discord-library-independent Pass 3 interaction input model."""
from __future__ import annotations

from dataclasses import dataclass


INTERACTION_REQUEST_CONTRACT = "GUILD-DOCTOR-DISCORD-INTERACTION-REQUEST-0.1"


@dataclass(frozen=True)
class InteractionRequest:
    correlation_id: str
    command_key: str
    guild_context_present: bool
    guild_id: str | None
    actor_member_id: str | None
    owner_member_id: str | None
    authorization_state: str | None = None
    selected_member_id: str | None = None
    selected_role_id: str | None = None
    comparison_role_id: str | None = None
    selected_channel_id: str | None = None
    selected_category_id: str | None = None
    action_key: str | None = None
    capability_key: str | None = None
    permission_key: str | None = None
    detail_level: str = "STANDARD"
    output_mode: str = "RESPONSE"
    requested_visibility: str = "EPHEMERAL"
    interaction_age_seconds: float = 0.0
    snapshot_reference: str | None = None
    snapshot_state: str = "CURRENT_COMPLETE"
    member_health: str = "COMPLETE"
    input_resolution_state: str = "RESOLVED"
    targeted_fetch_decision: str | None = None
    locale: str = "en-US"
    accessibility_preferences: tuple[str, ...] = ()


def validate_request(value: InteractionRequest) -> tuple[str, ...]:
    errors: list[str] = []
    if not value.correlation_id:
        errors.append("STAGE6_INTERACTION_CORRELATION_REQUIRED")
    if not value.command_key:
        errors.append("STAGE6_INTERACTION_COMMAND_REQUIRED")
    if value.interaction_age_seconds < 0:
        errors.append("STAGE6_INTERACTION_AGE_INVALID")
    if value.requested_visibility not in {"EPHEMERAL", "PUBLIC"}:
        errors.append("STAGE6_INTERACTION_VISIBILITY_INVALID")
    return tuple(errors)
