"""Bounded REST-only transport verification for Stage 8 Pass 3.

The production adapter reuses the existing discord.py client and reviewed
GET-only adapter.  It has no Gateway connect method and no generic HTTP API.
"""
from __future__ import annotations

from dataclasses import dataclass
import asyncio
import hashlib
import json
from types import MappingProxyType
from typing import Any, Awaitable, Callable, Mapping
from urllib.parse import urlsplit

from .discord_live_runtime import DiscordPyTransport
from .discordpy_adapter import DISCORDPY_ADAPTER_VERSION, DiscordPyReadTransport
from .private_alpha_command_registration import RegistrationResult, execute_registration
from .private_alpha_configuration import PrivateAlphaConfiguration, SecretPresence, decide_allowlist
from .private_alpha_installation_verification import InstallationVerification, verify_installation
from .private_alpha_preflight import PrivateAlphaPreflightResult, _runtime_inventory, run_preflight


LIVE_TRANSPORT_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-LIVE-TRANSPORT-0.1"
PASS3_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS3-INSTALLATION-COMMAND-REGISTRATION-LIVE-TRANSPORT-0.1"
LIVE_CONFIRMATION = "AUTHORIZE_STAGE8_PASS3_BOUNDED_LIVE_ACCESS"
REGISTRATION_CONFIRMATION = "AUTHORIZE_STAGE8_PASS3_GUILD_SCOPED_REGISTRATION"
ALLOWED_DISCORD_API_HOSTS = frozenset({"discord.com"})
ENDPOINT_INVENTORY = MappingProxyType({
    "AUTHENTICATED_IDENTITY": ("GET", "/users/@me"),
    "EXACT_GUILD_METADATA": ("GET", "/guilds/{guild_id}"),
    "GUILD_ROLE_INVENTORY": ("GET", "/guilds/{guild_id}/roles"),
    "GUILD_CHANNEL_INVENTORY": ("GET", "/guilds/{guild_id}/channels"),
    "ACTIVE_THREAD_INVENTORY": ("GET", "/guilds/{guild_id}/threads/active"),
    "EXACT_OWNER_MEMBER": ("GET", "/guilds/{guild_id}/members/{member_id}"),
    "GUILD_COMMAND_INVENTORY": ("GET", "/applications/{application_id}/guilds/{guild_id}/commands"),
    "GUILD_COMMAND_REGISTRATION": ("PUT", "/applications/{application_id}/guilds/{guild_id}/commands"),
})
FORBIDDEN_ENDPOINT_FAMILIES = frozenset({
    "MESSAGE_HISTORY", "AUDIT_LOGS", "BANS", "INVITES", "WEBHOOKS", "INTEGRATIONS",
    "SCHEDULED_EVENTS", "BROAD_MEMBER_LIST", "PRESENCES", "VOICE_STATES", "GUILD_DISCOVERY",
})
PASS3_AUTHORIZED_MODULES = (
    "guild_doctor_scanner/private_alpha_live_transport.py",
    "guild_doctor_scanner/private_alpha_command_registration.py",
    "guild_doctor_scanner/private_alpha_installation_verification.py",
    "guild_doctor_scanner/private_alpha_pass3_cli.py",
)


def endpoint_allowed(operation: str, method: str) -> bool:
    expected = ENDPOINT_INVENTORY.get(operation)
    return expected is not None and expected[0] == method and (
        method == "GET" or operation == "GUILD_COMMAND_REGISTRATION"
    )


def discord_api_host_allowed(host: str) -> bool:
    normalized = str(host or "").strip().rstrip(".").casefold()
    return normalized in ALLOWED_DISCORD_API_HOSTS


def run_pass3_offline_preflight(
    configuration: PrivateAlphaConfiguration,
    secret_presence: SecretPresence,
    root: Any,
) -> PrivateAlphaPreflightResult:
    root_path = __import__("pathlib").Path(root).resolve()
    if not all((root_path / relative).is_file() for relative in PASS3_AUTHORIZED_MODULES):
        raise ValueError("STAGE8_PASS3_AUTHORIZED_MODULE_SET_INCOMPLETE")
    inventory = _runtime_inventory(root_path)
    return run_preflight(configuration, secret_presence, root_path, inventory_override=inventory)


@dataclass(frozen=True, slots=True)
class OperationRecord:
    sequence: int
    operation_class: str
    method: str
    invocation_count: int
    result_state: str
    status_code_class: str
    retry_count: int
    timeout_classification: str

    def as_dict(self) -> dict[str, Any]:
        return {name: getattr(self, name) for name in self.__dataclass_fields__}


class BoundedOperationLedger:
    def __init__(self) -> None:
        self._records: list[OperationRecord] = []

    def record(
        self, operation: str, method: str, state: str, *, retries: int = 0,
        status_class: str = "2XX", timeout: str = "NOT_TIMED_OUT",
    ) -> None:
        if not endpoint_allowed(operation, method):
            raise ValueError("STAGE8_TRANSPORT_ENDPOINT_NOT_AUTHORIZED")
        self._records.append(OperationRecord(
            len(self._records) + 1, operation, method, 1, state,
            status_class, retries, timeout,
        ))

    @property
    def records(self) -> tuple[OperationRecord, ...]:
        return tuple(self._records)

    @property
    def fingerprint(self) -> str:
        payload = [item.as_dict() for item in self._records]
        return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


class BoundedExecutor:
    def __init__(self, ledger: BoundedOperationLedger, *, timeout_seconds: float = 20.0, get_retry_limit: int = 1):
        if timeout_seconds <= 0 or get_retry_limit < 0 or get_retry_limit > 2:
            raise ValueError("STAGE8_TRANSPORT_BOUND_INVALID")
        self.ledger = ledger
        self.timeout_seconds = float(timeout_seconds)
        self.get_retry_limit = int(get_retry_limit)

    async def get(self, operation: str, callback: Callable[[], Awaitable[Any]]) -> Any:
        if not endpoint_allowed(operation, "GET"):
            raise ValueError("STAGE8_TRANSPORT_ENDPOINT_NOT_AUTHORIZED")
        retries = 0
        while True:
            try:
                result = await asyncio.wait_for(callback(), self.timeout_seconds)
            except asyncio.CancelledError:
                self.ledger.record(operation, "GET", "CANCELLED", retries=retries, status_class="NONE", timeout="CANCELLED")
                raise
            except (asyncio.TimeoutError, TimeoutError):
                if retries < self.get_retry_limit:
                    retries += 1
                    continue
                self.ledger.record(operation, "GET", "FAILED", retries=retries, status_class="NONE", timeout="BOUNDED_TIMEOUT")
                raise
            except Exception as exc:
                status = getattr(exc, "status", None)
                retryable = status == 429 or (isinstance(status, int) and 500 <= status <= 599)
                if retryable and retries < self.get_retry_limit:
                    retries += 1
                    continue
                status_class = f"{int(status) // 100}XX" if isinstance(status, int) and 100 <= status <= 599 else "UNKNOWN"
                state = "RATE_LIMITED" if status == 429 else "FAILED"
                self.ledger.record(operation, "GET", state, retries=retries, status_class=status_class)
                raise
            self.ledger.record(operation, "GET", "COMPLETE", retries=retries)
            return result


class PrivateAlphaDiscordTransport:
    """One existing DiscordPyTransport client plus the reviewed read adapter."""

    def __init__(self) -> None:
        self._base = DiscordPyTransport()
        self._reads: DiscordPyReadTransport | None = None

    async def open_client(self) -> None:
        await self._base.async_open_client()

    async def authenticate(self, secret: str) -> Mapping[str, Any]:
        # Client.login() also fetches /oauth2/applications/@me.  Pass 3's
        # frozen transport inventory authorizes only /users/@me for identity,
        # so bind the returned bot identity without invoking that extra route.
        import discord

        client = self._base._client
        data = await client.http.static_login(secret)
        user = discord.ClientUser(state=client._connection, data=data)
        client._connection.user = user
        client._connection.application_id = user.id
        self._reads = DiscordPyReadTransport.from_client(client)
        return {"identity_available": bool(user and getattr(user, "id", None)), "identity_id": str(getattr(user, "id", ""))}

    def intents(self) -> Mapping[str, bool]:
        intents = getattr(self._base._client, "intents", None)
        return {
            "guilds": bool(getattr(intents, "guilds", False)),
            "message_content": bool(getattr(intents, "message_content", False)),
            "presences": bool(getattr(intents, "presences", False)),
            "members": bool(getattr(intents, "members", False)),
        }

    def _reader(self) -> DiscordPyReadTransport:
        if self._reads is None:
            raise RuntimeError("STAGE8_TRANSPORT_NOT_AUTHENTICATED")
        return self._reads

    async def read_guild(self, guild_id: str) -> Any:
        return await self._reader().read_guild(int(guild_id))

    async def read_roles(self, guild_id: str) -> Any:
        return await self._reader().read_roles(int(guild_id))

    async def read_channels(self, guild_id: str) -> Any:
        return await self._reader().read_channels(int(guild_id))

    async def read_active_threads(self, guild_id: str) -> Any:
        return await self._reader().read_active_threads(int(guild_id))

    async def read_member(self, guild_id: str, member_id: str) -> Any:
        return await self._reader().read_member(int(guild_id), int(member_id))

    async def fetch_guild_commands(self, guild_id: str) -> Any:
        return await self._base.async_fetch_guild_commands(guild_id)

    async def register_frozen_commands(self, guild_id: str) -> Any:
        scope = await self._base.async_prepare_guild_scope(guild_id)
        if scope.get("state") != "GUILD_SCOPE_READY_FOR_SYNC":
            raise RuntimeError("STAGE8_REGISTRATION_LOCAL_SCHEMA_INVALID")
        return await self._base.async_synchronize_guild_commands(guild_id, scope["commands"])

    async def close(self) -> None:
        await self._base.async_close_client()
        self._reads = None

    @staticmethod
    def network_policy_valid() -> bool:
        try:
            from discord.http import Route
        except ImportError:
            return False
        return discord_api_host_allowed(urlsplit(Route.BASE).hostname or "")


@dataclass(frozen=True, slots=True)
class LiveVerificationResult:
    status: str
    stable_reason: str | None
    authentication_state: str
    allowlist_state: str
    installation: InstallationVerification | None
    registration: RegistrationResult | None
    endpoint_ledger: tuple[OperationRecord, ...]
    endpoint_ledger_fingerprint: str
    network_domain_state: str
    role_count: int
    channel_count: int
    active_thread_count: int
    exact_member_acquisition_count: int
    completeness_states: tuple[str, ...]
    source_provenance: tuple[str, ...]
    client_cleanup: str
    gateway_connection_count: int = 0
    guild_mutation_write_count: int = 0
    message_content_request_count: int = 0
    broad_member_enumeration_count: int = 0
    report_workflow_count: int = 0

    def as_dict(self) -> dict[str, Any]:
        return {
            "contract": LIVE_TRANSPORT_CONTRACT,
            "status": self.status,
            "stable_reason": self.stable_reason,
            "authentication_state": self.authentication_state,
            "allowlist_state": self.allowlist_state,
            "installation": self.installation.as_dict() if self.installation else None,
            "registration": self.registration.as_dict() if self.registration else None,
            "endpoint_ledger": [item.as_dict() for item in self.endpoint_ledger],
            "endpoint_ledger_fingerprint": self.endpoint_ledger_fingerprint,
            "network_domain_state": self.network_domain_state,
            "role_count": self.role_count,
            "channel_count": self.channel_count,
            "active_thread_count": self.active_thread_count,
            "exact_member_acquisition_count": self.exact_member_acquisition_count,
            "completeness_states": list(self.completeness_states),
            "source_provenance": list(self.source_provenance),
            "client_cleanup": self.client_cleanup,
            "gateway_connection_count": self.gateway_connection_count,
            "guild_mutation_write_count": self.guild_mutation_write_count,
            "message_content_request_count": self.message_content_request_count,
            "broad_member_enumeration_count": self.broad_member_enumeration_count,
            "report_workflow_count": self.report_workflow_count,
        }


async def execute_live_verification(
    *,
    transport: Any,
    configuration: PrivateAlphaConfiguration,
    offline_preflight: PrivateAlphaPreflightResult,
    secret: str,
    explicitly_authorize_registration: bool,
    request_timeout_seconds: float = 20.0,
    total_timeout_seconds: float = 120.0,
) -> LiveVerificationResult:
    if offline_preflight.overall_state != "READY_OFFLINE":
        raise ValueError("STAGE8_LIVE_PREFLIGHT_BLOCKED")
    if len(configuration.guild_allowlist) != 1:
        raise ValueError("STAGE8_LIVE_EXACTLY_ONE_GUILD_REQUIRED")
    if not transport.network_policy_valid():
        raise ValueError("STAGE8_LIVE_NETWORK_RESTRICTION_FAILED")
    ledger = BoundedOperationLedger()
    executor = BoundedExecutor(ledger, timeout_seconds=request_timeout_seconds, get_retry_limit=1)
    guild_id = configuration.guild_allowlist[0]
    installation: InstallationVerification | None = None
    registration: RegistrationResult | None = None
    authentication_state = "NOT_ATTEMPTED"
    allowlist_state = "NOT_EVALUATED"
    cleanup = "NOT_ATTEMPTED"
    roles: Any = ()
    channels: Any = ()
    threads: Any = {"threads": []}
    stable_reason: str | None = None
    status = "BLOCKED"
    try:
        async with asyncio.timeout(total_timeout_seconds):
            await transport.open_client()
            identity = await executor.get("AUTHENTICATED_IDENTITY", lambda: transport.authenticate(secret))
            authentication_state = "PASS" if identity.get("identity_available") else "FAIL"
            if authentication_state != "PASS":
                raise RuntimeError("STAGE8_LIVE_APPLICATION_IDENTITY_UNAVAILABLE")
            guild = await executor.get("EXACT_GUILD_METADATA", lambda: transport.read_guild(guild_id))
            if str(guild.get("id", "")) != guild_id:
                raise RuntimeError("STAGE8_LIVE_GUILD_BINDING_MISMATCH")
            decision = decide_allowlist(configuration, str(guild.get("id", "")))
            allowlist_state = decision.state
            if decision.state != "ALLOWED":
                raise RuntimeError("STAGE8_LIVE_GUILD_NOT_ALLOWLISTED")
            owner_id = str(guild.get("owner_id", ""))
            if not owner_id.isdecimal():
                raise RuntimeError("STAGE8_LIVE_OWNER_IDENTITY_UNAVAILABLE")
            roles = await executor.get("GUILD_ROLE_INVENTORY", lambda: transport.read_roles(guild_id))
            channels = await executor.get("GUILD_CHANNEL_INVENTORY", lambda: transport.read_channels(guild_id))
            threads = await executor.get("ACTIVE_THREAD_INVENTORY", lambda: transport.read_active_threads(guild_id))
            owner = await executor.get("EXACT_OWNER_MEMBER", lambda: transport.read_member(guild_id, owner_id))
            installation = verify_installation(
                guild=guild, roles=roles, authenticated_user_id=str(identity.get("identity_id", "")),
                owner_member=owner, intents=transport.intents(),
            )
            if installation.state != "PASS":
                raise RuntimeError("STAGE8_LIVE_INSTALLATION_BLOCKED")
            remote_commands = await executor.get("GUILD_COMMAND_INVENTORY", lambda: transport.fetch_guild_commands(guild_id))
            registration = await execute_registration(
                transport=transport, guild_id=guild_id, remote_commands=remote_commands,
                explicitly_authorized=explicitly_authorize_registration,
                timeout_seconds=request_timeout_seconds,
            )
            if registration.registration_operation_count:
                ledger.record(
                    "GUILD_COMMAND_REGISTRATION", "PUT",
                    "COMPLETE" if registration.state == "REGISTRATION_COMPLETED" else "FAILED",
                    status_class="2XX" if registration.state == "REGISTRATION_COMPLETED" else "UNKNOWN",
                )
            if registration.post_registration_fetch_count:
                ledger.record(
                    "GUILD_COMMAND_INVENTORY", "GET",
                    "COMPLETE" if registration.state == "REGISTRATION_COMPLETED" else "FAILED",
                )
            if registration.state not in {"REGISTRATION_NOT_REQUIRED", "REGISTRATION_COMPLETED"}:
                raise RuntimeError(registration.stable_reason or "STAGE8_REGISTRATION_BLOCKED")
            status = "PASS"
    except asyncio.CancelledError:
        stable_reason = "STAGE8_LIVE_CANCELLED"
    except (asyncio.TimeoutError, TimeoutError):
        stable_reason = "STAGE8_LIVE_TOTAL_TIMEOUT"
    except Exception as exc:
        safe = str(exc)
        stable_reason = safe if safe.startswith("STAGE8_") else "STAGE8_LIVE_TRANSPORT_FAILED"
    finally:
        secret = ""
        try:
            await transport.close()
        except Exception:
            cleanup = "FAILED"
            status = "BLOCKED"
            stable_reason = stable_reason or "STAGE8_LIVE_CLIENT_CLOSE_FAILED"
        else:
            cleanup = "CLOSED"
    thread_items = threads.get("threads", []) if isinstance(threads, Mapping) else []
    return LiveVerificationResult(
        status=status,
        stable_reason=stable_reason,
        authentication_state=authentication_state,
        allowlist_state=allowlist_state,
        installation=installation,
        registration=registration,
        endpoint_ledger=ledger.records,
        endpoint_ledger_fingerprint=ledger.fingerprint,
        network_domain_state="DISCORD_API_ONLY",
        role_count=len(roles) if isinstance(roles, (list, tuple)) else 0,
        channel_count=len(channels) if isinstance(channels, (list, tuple)) else 0,
        active_thread_count=len(thread_items) if isinstance(thread_items, (list, tuple)) else 0,
        exact_member_acquisition_count=sum(item.operation_class == "EXACT_OWNER_MEMBER" for item in ledger.records),
        completeness_states=("GUILD_COMPLETE", "ROLES_COMPLETE", "CHANNELS_COMPLETE", "ACTIVE_THREADS_COMPLETE", "OWNER_MEMBER_EXACT"),
        source_provenance=(DISCORDPY_ADAPTER_VERSION, "GUILD-DOCTOR-GET-ONLY-ACQUISITION-0.1"),
        client_cleanup=cleanup,
    )


__all__ = [
    "ALLOWED_DISCORD_API_HOSTS", "ENDPOINT_INVENTORY", "FORBIDDEN_ENDPOINT_FAMILIES",
    "LIVE_CONFIRMATION", "LIVE_TRANSPORT_CONTRACT", "PASS3_CONTRACT", "REGISTRATION_CONFIRMATION",
    "BoundedExecutor", "BoundedOperationLedger", "LiveVerificationResult", "OperationRecord",
    "PASS3_AUTHORIZED_MODULES", "PrivateAlphaDiscordTransport", "discord_api_host_allowed", "endpoint_allowed",
    "execute_live_verification", "run_pass3_offline_preflight",
]
