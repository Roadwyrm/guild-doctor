"""Offline-only Pass 4D qualification CLI with no live execution surface."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .private_alpha_pass4d_qualification import run_offline_qualification


PROHIBITED_ARGUMENT_FRAGMENTS = (
    "token", "guild-id", "gateway", "live", "register", "sync", "webhook",
    "http", "tunnel", "public", "attachment", "component", "follow-up",
    "mutation", "interaction-payload",
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Qualify the Guild Doctor Pass 4D runtime offline.")
    parser.add_argument("--sanitized-snapshot-fixture", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    supplied = tuple(sys.argv[1:] if argv is None else argv)
    if any(any(fragment in item.lower() for fragment in PROHIBITED_ARGUMENT_FRAGMENTS) for item in supplied):
        print('{"status":"REJECTED_PROHIBITED_ARGUMENT"}', flush=True)
        return 2
    try:
        result = run_offline_qualification(build_parser().parse_args(supplied).sanitized_snapshot_fixture)
        print(json.dumps(result.as_dict(), sort_keys=True, separators=(",", ":")), flush=True)
        return 0 if result.status == "PASS" else 2
    except (OSError, ValueError, json.JSONDecodeError):
        print('{"status":"FAILED_CLOSED","privacy_state":"SANITIZED"}', flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
