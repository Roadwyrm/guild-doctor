"""Operator-only bounded Pass 5 interaction-session entry point."""
from __future__ import annotations
import argparse, asyncio, json
from pathlib import Path
from .discord_pass5_interaction_runtime import TARGET_GUILD_ID, execute_interaction_session, write_evidence

def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--guild-id", required=True)
    parser.add_argument("--window-seconds", type=float, default=120.0)
    parser.add_argument("--network-enabled", action="store_true")
    parser.add_argument("--project-root", default="C:\\GuildDoctor")
    args = parser.parse_args(argv)
    if not args.network_enabled or args.guild_id != TARGET_GUILD_ID:
        print(json.dumps({"status": "FAIL", "stable_error": "PASS5_GUILD_SCOPE_INVALID", "token_redacted": True}))
        return 21
    result = asyncio.run(execute_interaction_session(project_root=Path(args.project_root), guild_id=args.guild_id, timeout_seconds=args.window_seconds))
    evidence = write_evidence(Path(args.project_root), result)
    print(json.dumps({"status": result["status"], "stable_error": result.get("stable_error"), "evidence": str(evidence), "token_redacted": True}))
    return 0 if result["status"] == "PASS" else 18

if __name__ == "__main__":
    raise SystemExit(main())
