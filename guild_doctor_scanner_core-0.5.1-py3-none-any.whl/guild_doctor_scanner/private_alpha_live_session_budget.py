"""Deterministic counters and cleanup state for one bounded Gateway session."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import time
from typing import Callable


SESSION_BUDGET_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-GATEWAY-CLEANUP-0.1"


class SessionBudgetError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class SessionBudgetSnapshot:
    session_count: int
    invocation_count: int
    accepted_invocation_count: int
    rejected_invocation_count: int
    response_write_count: int
    deferred_response_count: int
    original_response_edit_count: int
    elapsed_seconds: float
    cleanup_reason: str | None
    closed: bool
    close_count: int

    def as_dict(self):
        return asdict(self)


class LiveSessionBudget:
    def __init__(self, *, maximum_invocations: int, maximum_duration_seconds: float, clock: Callable[[], float] = time.monotonic):
        if not 1 <= maximum_invocations <= 4 or not 0 < maximum_duration_seconds <= 600:
            raise SessionBudgetError("STAGE8_PASS4D_SESSION_BUDGET_INVALID")
        self.maximum_invocations = maximum_invocations
        self.maximum_duration_seconds = float(maximum_duration_seconds)
        self._clock = clock
        self._started = clock()
        self._session_count = 1
        self._invocations = self._accepted = self._rejected = 0
        self._writes = self._defers = self._edits = 0
        self._closed = False
        self._cleanup_reason = None
        self._close_count = 0

    def _active(self) -> None:
        if self._closed:
            raise SessionBudgetError("STAGE8_PASS4D_SESSION_CLOSED")
        if self.elapsed_seconds >= self.maximum_duration_seconds:
            self.cleanup("SESSION_TIMEOUT")
            raise SessionBudgetError("STAGE8_PASS4D_SESSION_TIMEOUT")

    @property
    def elapsed_seconds(self) -> float:
        return max(0.0, self._clock() - self._started)

    def accept(self) -> None:
        self._active()
        if self._accepted >= self.maximum_invocations:
            self.cleanup("INVOCATION_BUDGET_COMPLETE")
            raise SessionBudgetError("STAGE8_PASS4D_INVOCATION_BUDGET_EXHAUSTED")
        self._invocations += 1
        self._accepted += 1

    def reject(self) -> None:
        self._active()
        self._invocations += 1
        self._rejected += 1

    def record_defer(self) -> None:
        self._active(); self._writes += 1; self._defers += 1

    def record_initial(self) -> None:
        self._active(); self._writes += 1

    def record_edit(self) -> None:
        self._active(); self._writes += 1; self._edits += 1

    def invocation_complete(self) -> bool:
        if self._accepted >= self.maximum_invocations:
            self.cleanup("INVOCATION_BUDGET_COMPLETE")
            return True
        return False

    def cleanup(self, reason: str) -> bool:
        if self._closed:
            return False
        self._closed = True
        self._cleanup_reason = str(reason)
        self._close_count = 1
        return True

    @property
    def snapshot(self) -> SessionBudgetSnapshot:
        return SessionBudgetSnapshot(
            self._session_count, self._invocations, self._accepted, self._rejected,
            self._writes, self._defers, self._edits, round(self.elapsed_seconds, 6),
            self._cleanup_reason, self._closed, self._close_count,
        )


__all__ = ["LiveSessionBudget", "SESSION_BUDGET_CONTRACT", "SessionBudgetError", "SessionBudgetSnapshot"]
