"""Structured source-location extraction over the frozen Doctor result.

The extractor consumes the structured Pass 1/Stage 3 trace and result records
already retained by ``DoctorExecution``.  It never recalculates a permission,
capability, action, or explanation and never parses presentation prose.
"""

from __future__ import annotations

import hashlib
from collections import Counter
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .canonical import canonical_json
from .doctor_case import DoctorCase
from .doctor_engine import DoctorExecution, execute_doctor_query
from .doctor_query import DoctorQuery, thaw
from .doctor_source_query import (
    CONTROLLING_ONLY,
    EXPLAIN_SOURCE_OBJECT,
    FIND_CONTROLLING_SOURCE,
    FULL_PROVENANCE,
    LIST_MATERIAL_SOURCES,
    MATERIAL_CHAIN,
    SOURCE_DETAIL_LEVELS,
    SOURCE_LOCATION_CASE_CONTRACT_VERSION,
    SOURCE_LOCATION_INTENTS,
    STAGE5_PASS3_CONTRACT_VERSION,
    STAGE5_PASS3_GOLDEN_VERSION,
    STAGE5_PASS3_RULES_VERSION,
    SourceLocationQuery,
    TRACE_SOURCE_CHAIN,
    validate_source_location_query,
)


# Source types are descriptive records, not decision rules.
GUILD_EVERYONE_ROLE = "GUILD_EVERYONE_ROLE"
GUILD_ASSIGNED_ROLE = "GUILD_ASSIGNED_ROLE"
CATEGORY_OVERWRITE = "CATEGORY_OVERWRITE"
CHANNEL_OVERWRITE = "CHANNEL_OVERWRITE"
MEMBER_OVERWRITE = "MEMBER_OVERWRITE"
THREAD_PARENT = "THREAD_PARENT"
THREAD_MEMBERSHIP = "THREAD_MEMBERSHIP"
THREAD_STATE = "THREAD_STATE"
MEMBER_TIMEOUT = "MEMBER_TIMEOUT"
GUILD_OWNER_BYPASS = "GUILD_OWNER_BYPASS"
ADMINISTRATOR_BYPASS = "ADMINISTRATOR_BYPASS"
TARGET_MEMBER = "TARGET_MEMBER"
TARGET_ROLE = "TARGET_ROLE"
ROLE_HIERARCHY = "ROLE_HIERARCHY"
MANAGED_OBJECT = "MANAGED_OBJECT"
PERMISSION_SUBSET = "PERMISSION_SUBSET"
GUILD_MFA_LEVEL = "GUILD_MFA_LEVEL"
MEMBER_MFA_STATE = "MEMBER_MFA_STATE"
VOICE_STATE = "VOICE_STATE"
OBJECT_PRECONDITION = "OBJECT_PRECONDITION"
CAPABILITY_DEPENDENCY = "CAPABILITY_DEPENDENCY"
UNKNOWN_PERMISSION_BITS = "UNKNOWN_PERMISSION_BITS"
MISSING_EVIDENCE = "MISSING_EVIDENCE"
UNSUPPORTED_RULE = "UNSUPPORTED_RULE"
ACCEPTED_READ_ONLY_LIMITATION = "ACCEPTED_READ_ONLY_LIMITATION"

CONTROLLING_GRANT = "CONTROLLING_GRANT"
CONTROLLING_BLOCK = "CONTROLLING_BLOCK"
CONTRIBUTING_GRANT = "CONTRIBUTING_GRANT"
CONTRIBUTING_BLOCK = "CONTRIBUTING_BLOCK"
INEFFECTIVE_GRANT = "INEFFECTIVE_GRANT"
BYPASSED = "BYPASSED"
OVERRIDDEN = "OVERRIDDEN"
INAPPLICABLE = "INAPPLICABLE"
SUPPORTING_CONTEXT = "SUPPORTING_CONTEXT"
UNKNOWN_EFFECT = "UNKNOWN_EFFECT"
MISSING_REQUIRED_EVIDENCE = "MISSING_REQUIRED_EVIDENCE"
ACCEPTED_LIMITATION = "ACCEPTED_LIMITATION"

SOURCE_TYPES = frozenset(
    {
        GUILD_EVERYONE_ROLE,
        GUILD_ASSIGNED_ROLE,
        CATEGORY_OVERWRITE,
        CHANNEL_OVERWRITE,
        MEMBER_OVERWRITE,
        THREAD_PARENT,
        THREAD_MEMBERSHIP,
        THREAD_STATE,
        MEMBER_TIMEOUT,
        GUILD_OWNER_BYPASS,
        ADMINISTRATOR_BYPASS,
        TARGET_MEMBER,
        TARGET_ROLE,
        ROLE_HIERARCHY,
        MANAGED_OBJECT,
        PERMISSION_SUBSET,
        GUILD_MFA_LEVEL,
        MEMBER_MFA_STATE,
        VOICE_STATE,
        OBJECT_PRECONDITION,
        CAPABILITY_DEPENDENCY,
        UNKNOWN_PERMISSION_BITS,
        MISSING_EVIDENCE,
        UNSUPPORTED_RULE,
        ACCEPTED_READ_ONLY_LIMITATION,
    }
)
SOURCE_EFFECT_CLASSIFICATIONS = frozenset(
    {
        CONTROLLING_GRANT,
        CONTROLLING_BLOCK,
        CONTRIBUTING_GRANT,
        CONTRIBUTING_BLOCK,
        INEFFECTIVE_GRANT,
        BYPASSED,
        OVERRIDDEN,
        INAPPLICABLE,
        SUPPORTING_CONTEXT,
        UNKNOWN_EFFECT,
        MISSING_REQUIRED_EVIDENCE,
        ACCEPTED_LIMITATION,
    }
)


class SourceLocationError(RuntimeError):
    """Raised only for strict source-location execution."""


def _read(value: Any, key: str, default: Any = None) -> Any:
    if isinstance(value, Mapping):
        return value.get(key, default)
    return getattr(value, key, default)


def _as_dict(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _as_dict(method())
    if isinstance(value, Mapping):
        return {str(key): _as_dict(child) for key, child in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [_as_dict(child) for child in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(child) for key, child in sorted(value.items(), key=lambda item: str(item[0]))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(child) for child in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(child) for child in sorted(value, key=str))
    return deepcopy(value)


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _thaw(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [_thaw(child) for child in value]
    return deepcopy(value)


def _hash(value: Any) -> str:
    return hashlib.sha256(canonical_json(_as_dict(value)).encode("utf-8")).hexdigest()


def _text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def _upper(value: Any) -> str | None:
    value = _text(value)
    return value.upper() if value else None


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _int(value: Any) -> int | None:
    try:
        if isinstance(value, bool) or value is None:
            return None
        return int(str(value), 0) if isinstance(value, str) and str(value).lower().startswith("0x") else int(value)
    except (TypeError, ValueError):
        return None


def _records(value: Any) -> tuple[Mapping[str, Any], ...]:
    if isinstance(value, Mapping):
        if "id" in value or "target_id" in value:
            return (value,)
        return tuple(item for item in value.values() if isinstance(item, Mapping))
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return tuple(item for item in value if isinstance(item, Mapping))
    return ()


def _find(snapshot: Mapping[str, Any], collection: str, identifier: str | None) -> Mapping[str, Any] | None:
    if identifier is None:
        return None
    for record in _records(snapshot.get(collection)):
        if _snowflake(record.get("id")) == identifier:
            return record
    return None


def _safe_label(value: Any, fallback: str) -> str:
    label = _text(value) or fallback
    return " ".join(label.replace("@", "@​").split())[:160]


def _trace_events(execution: DoctorExecution) -> tuple[tuple[str, Mapping[str, Any], Mapping[str, Any]], ...]:
    events: list[tuple[str, Mapping[str, Any], Mapping[str, Any]]] = []
    for stage, result in sorted(execution.stage_results.items()):
        result_dict = _as_dict(result)
        for event in _records(result_dict.get("trace")):
            events.append((stage, event, result_dict))
    return tuple(events)


def _selected_record(execution: DoctorExecution) -> Mapping[str, Any]:
    actual = _as_dict(execution.case.actual_result)
    selected = actual.get("selected_record")
    return selected if isinstance(selected, Mapping) else {}


def _final_state(execution: DoctorExecution) -> str:
    return _upper(_read(execution.case.actual_result, "result_state", "UNKNOWN")) or "UNKNOWN"


def _event_relevant(event: Mapping[str, Any], query: DoctorQuery) -> bool:
    details = event.get("details") if isinstance(event.get("details"), Mapping) else {}
    target_key = details.get("capability_key") or details.get("operation_key")
    return target_key is None or target_key == query.target_key


def _source_type(stage: str, code: str, details: Mapping[str, Any], query: DoctorQuery) -> str:
    upper = code.upper()
    if "OWNER" in upper or details.get("bypass_state") == "OWNER":
        return GUILD_OWNER_BYPASS
    if "ADMIN" in upper or details.get("bypass_state") == "ADMINISTRATOR":
        return ADMINISTRATOR_BYPASS
    if "MEMBER_OVERWRITE" in upper or upper.startswith("CONTEXT_MEMBER"):
        return MEMBER_OVERWRITE
    if "CATEGORY" in upper or query.context_type == "CATEGORY":
        return CATEGORY_OVERWRITE
    if upper.startswith("CONTEXT_") or "OVERWRITE" in upper:
        return CHANNEL_OVERWRITE
    if "MEMBERSHIP" in upper:
        return THREAD_MEMBERSHIP
    if "PARENT" in upper:
        return THREAD_PARENT
    if stage == "PASS4" or "THREAD_STATE" in upper or upper.startswith("THREAD") or "ARCHIV" in upper or "LOCK" in upper:
        return THREAD_STATE
    if "TIMEOUT" in upper:
        return MEMBER_TIMEOUT
    if "HIERARCHY" in upper or "ROLE_ORDER" in upper:
        return ROLE_HIERARCHY
    if "MANAGED" in upper:
        return MANAGED_OBJECT
    if "MFA" in upper:
        return GUILD_MFA_LEVEL if "GUILD" in upper else MEMBER_MFA_STATE
    if "VOICE" in upper:
        return VOICE_STATE
    if "OBJECT" in upper or "PRECONDITION" in upper:
        return OBJECT_PRECONDITION
    if "DEPENDENCY" in upper or "SUBSET" in upper:
        return CAPABILITY_DEPENDENCY if "DEPENDENCY" in upper else PERMISSION_SUBSET
    if "UNKNOWN_PERMISSION" in upper or "UNKNOWN_BITS" in upper:
        return UNKNOWN_PERMISSION_BITS
    if "MISSING" in upper or "INCOMPLETE" in upper or "UNAVAILABLE" in upper:
        return MISSING_EVIDENCE
    if stage == "PASS1":
        return GUILD_ASSIGNED_ROLE
    if query.target_type == "ROLE":
        return TARGET_ROLE
    if query.target_type == "MEMBER":
        return TARGET_MEMBER
    return ACCEPTED_READ_ONLY_LIMITATION


def _effect(code: str, details: Mapping[str, Any], final_state: str, *, default: str = SUPPORTING_CONTEXT) -> str:
    upper = code.upper()
    if "MISSING" in upper or "UNKNOWN" in upper or "UNAVAILABLE" in upper:
        return MISSING_REQUIRED_EVIDENCE if "MISSING" in upper or "UNAVAILABLE" in upper else UNKNOWN_EFFECT
    if "BYPASS" in upper or details.get("bypass_active") is True:
        return BYPASSED
    if "INAPPLICABLE" in upper or details.get("state") in {"NOT_APPLICABLE", "NO_APPLICABLE_OVERWRITE"}:
        return INAPPLICABLE
    if "INEFFECTIVE" in upper:
        return INEFFECTIVE_GRANT
    if "OVERRIDDEN" in upper:
        return OVERRIDDEN
    is_block = any(token in upper for token in ("DENY", "DENIED", "BLOCK", "FAIL", "RESTRICT", "UNSATISFIED"))
    is_grant = any(token in upper for token in ("ALLOW", "ALLOWED", "GRANT", "SATISFIED", "RESOLVED"))
    if is_block:
        return CONTROLLING_BLOCK if final_state in {"DENIED", "INEFFECTIVE"} else CONTRIBUTING_BLOCK
    if is_grant:
        return CONTROLLING_GRANT if final_state == "ALLOWED" else CONTRIBUTING_GRANT
    if "LIMITATION" in upper or "READ_ONLY" in upper:
        return ACCEPTED_LIMITATION
    return default


def _object_id(details: Mapping[str, Any], query: DoctorQuery) -> str | None:
    for key in (
        "source_id",
        "source_role_id",
        "target_id",
        "member_id",
        "role_id",
        "context_id",
        "thread_id",
        "parent_id",
        "context_parent_id",
    ):
        value = details.get(key)
        if isinstance(value, (str, int)) and str(value):
            return _snowflake(value) or str(value)
    return query.context_id or query.target_id or query.subject_id


def _before_after(details: Mapping[str, Any]) -> tuple[Mapping[str, Any] | None, Mapping[str, Any] | None]:
    before = details.get("before")
    after = details.get("after")
    return (before if isinstance(before, Mapping) else None, after if isinstance(after, Mapping) else None)


def _record(
    *,
    source_type: str,
    effect_classification: str,
    query: DoctorQuery,
    stage: str,
    code: str,
    details: Mapping[str, Any],
    permission_key: str | None = None,
    object_id: str | None = None,
    allow_value: str | None = None,
    deny_value: str | None = None,
    raw_before: Mapping[str, Any] | None = None,
    raw_after: Mapping[str, Any] | None = None,
    explanation: str | None = None,
    controlling: bool | None = None,
) -> "SourceLocationRecord":
    object_id = object_id or _object_id(details, query)
    controlling = controlling if controlling is not None else effect_classification in {CONTROLLING_GRANT, CONTROLLING_BLOCK}
    base = {
        "source_type": source_type,
        "effect_classification": effect_classification,
        "object_type": source_type,
        "object_id": object_id,
        "permission_or_capability_key": permission_key or query.target_key,
        "allow_value": allow_value,
        "deny_value": deny_value,
        "raw_before": raw_before,
        "raw_after": raw_after,
        "stage": stage,
        "code": code,
        "trace_event_reference": f"{stage}:{details.get('sequence', '')}:{code}",
    }
    record_id = f"source-{_hash(base)[:24]}"
    status = _upper(details.get("verification_status")) or _upper(details.get("state")) or "STRUCTURED_TRACE"
    completeness = _upper(details.get("completeness_state")) or "UNKNOWN"
    if completeness == "UNKNOWN" and effect_classification not in {UNKNOWN_EFFECT, MISSING_REQUIRED_EVIDENCE, ACCEPTED_LIMITATION}:
        completeness = "TRACE_PRESENT"
    label = _safe_label(details.get("display_safe_object_label"), f"{source_type.lower().replace('_', ' ')} {object_id or 'unknown'}")
    return SourceLocationRecord(
        source_record_id=record_id,
        source_type=source_type,
        effect_classification=effect_classification,
        object_type=source_type,
        object_id=object_id,
        permission_or_capability_key=permission_key or query.target_key,
        allow_value=allow_value,
        deny_value=deny_value,
        raw_before=raw_before,
        raw_after=raw_after,
        display_safe_object_label=label,
        stage3_rule_id=_text(details.get("rule_id")) or code,
        trace_event_reference=f"{stage}:{details.get('sequence', '')}:{code}",
        source_result_fingerprint=_text(details.get("source_result_fingerprint")),
        evidence_classification=(query.evidence_classifications[0] if query.evidence_classifications else "SYNTHETIC_SOURCE_DIAGNOSTIC"),
        verification_status=status,
        completeness=completeness,
        explanation=explanation or f"Structured {code} evidence identified this source location.",
        controlling=controlling,
        actionable_in_principle=source_type not in {UNKNOWN_PERMISSION_BITS, MISSING_EVIDENCE, UNSUPPORTED_RULE, ACCEPTED_READ_ONLY_LIMITATION},
        details=_freeze(details),
    )


@dataclass(frozen=True, slots=True)
class SourceLocationRecord:
    source_record_id: str
    source_type: str
    effect_classification: str
    object_type: str | None
    object_id: str | None
    permission_or_capability_key: str | None
    allow_value: str | None
    deny_value: str | None
    raw_before: Mapping[str, Any] | None
    raw_after: Mapping[str, Any] | None
    display_safe_object_label: str
    stage3_rule_id: str
    trace_event_reference: str
    source_result_fingerprint: str | None
    evidence_classification: str
    verification_status: str
    completeness: str
    explanation: str
    controlling: bool
    actionable_in_principle: bool
    details: Mapping[str, Any]

    def __post_init__(self) -> None:
        object.__setattr__(self, "source_type", _upper(self.source_type) or "")
        object.__setattr__(self, "effect_classification", _upper(self.effect_classification) or "")
        object.__setattr__(self, "raw_before", _freeze(self.raw_before) if self.raw_before is not None else None)
        object.__setattr__(self, "raw_after", _freeze(self.raw_after) if self.raw_after is not None else None)
        object.__setattr__(self, "details", _freeze(self.details))

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_record_id": self.source_record_id,
            "source_type": self.source_type,
            "effect_classification": self.effect_classification,
            "object_type": self.object_type,
            "object_id": self.object_id,
            "permission_or_capability_key": self.permission_or_capability_key,
            "allow_value": self.allow_value,
            "deny_value": self.deny_value,
            "raw_before": _thaw(self.raw_before),
            "raw_after": _thaw(self.raw_after),
            "display_safe_object_label": self.display_safe_object_label,
            "stage3_rule_id": self.stage3_rule_id,
            "trace_event_reference": self.trace_event_reference,
            "source_result_fingerprint": self.source_result_fingerprint,
            "evidence_classification": self.evidence_classification,
            "verification_status": self.verification_status,
            "completeness": self.completeness,
            "explanation": self.explanation,
            "controlling": self.controlling,
            "actionable_in_principle": self.actionable_in_principle,
            "details": _thaw(self.details),
        }


def _role_sources(query: DoctorQuery, execution: DoctorExecution, final_state: str) -> list[SourceLocationRecord]:
    pass1 = _as_dict(execution.stage_results.get("PASS1"))
    snapshot = thaw(query.snapshot) if query.snapshot is not None else {}
    role_records = {(_snowflake(role.get("id")) or str(role.get("id"))): role for role in _records(snapshot.get("roles"))}
    records: list[SourceLocationRecord] = []
    for contribution in _records(pass1.get("assigned_role_contributions")):
        role_id = _snowflake(contribution.get("role_id")) or str(contribution.get("role_id"))
        role = role_records.get(role_id, {})
        is_everyone = role.get("is_everyone") is True or role_id == query.guild_id
        source_type = GUILD_EVERYONE_ROLE if is_everyone else GUILD_ASSIGNED_ROLE
        unknown = contribution.get("unknown_permission_bits_decimal") not in (None, "0", 0)
        effect = UNKNOWN_EFFECT if unknown else (CONTRIBUTING_GRANT if contribution.get("included") else INEFFECTIVE_GRANT)
        records.append(
            _record(
                source_type=source_type,
                effect_classification=effect,
                query=query,
                stage="PASS1",
                code="ASSIGNED_ROLE_CONTRIBUTION",
                details=contribution,
                permission_key=query.target_key,
                object_id=role_id,
                allow_value=contribution.get("permission_decimal"),
                explanation=f"The {source_type.lower().replace('_', ' ')} contributed stored permission bits to the guild union.",
                controlling=False,
            )
        )
    bypass = _upper(pass1.get("bypass_state"))
    if bypass in {"OWNER", "ADMINISTRATOR"}:
        records.append(
            _record(
                source_type=GUILD_OWNER_BYPASS if bypass == "OWNER" else ADMINISTRATOR_BYPASS,
                effect_classification=BYPASSED,
                query=query,
                stage="PASS1",
                code="BYPASS_STATE_RESOLVED",
                details={"bypass_state": bypass},
                object_id=query.subject_id,
                explanation=f"The structured Pass 1 result records the {bypass.lower()} bypass as active.",
                controlling=False,
            )
        )
    return records


def _snapshot_overwrite(query: DoctorQuery, object_id: str | None, *, source_role_id: str | None = None, member: bool = False) -> Mapping[str, Any] | None:
    snapshot = thaw(query.snapshot) if query.snapshot is not None else {}
    context_id = query.context_id or query.parent_id
    context = _find(snapshot, "channels", context_id)
    if context is None:
        return None
    for overwrite in _records(context.get("permission_overwrites")):
        target_id = _snowflake(overwrite.get("target_id"))
        if member and target_id == query.subject_id:
            return overwrite
        if source_role_id and target_id == source_role_id:
            return overwrite
        if object_id and target_id == object_id:
            return overwrite
    return None


def _structured_overwrite_sources(query: DoctorQuery, execution: DoctorExecution, final_state: str) -> list[SourceLocationRecord]:
    pass2 = _as_dict(execution.stage_results.get("PASS2")) or {}
    records: list[SourceLocationRecord] = []
    everyone = pass2.get("everyone_overwrite_contribution")
    if isinstance(everyone, Mapping):
        source_type = CATEGORY_OVERWRITE if query.context_type == "CATEGORY" else CHANNEL_OVERWRITE
        before, after = _before_after(everyone)
        effect = _effect("CONTEXT_EVERYONE_DENY" if everyone.get("deny_decimal") not in (None, "0") else "CONTEXT_EVERYONE_ALLOW", everyone, final_state)
        records.append(_record(source_type=source_type, effect_classification=effect, query=query, stage="PASS2", code="EVERYONE_OVERWRITE", details=everyone, object_id=everyone.get("target_id"), allow_value=everyone.get("allow_decimal"), deny_value=everyone.get("deny_decimal"), raw_before=before, raw_after=after, explanation="The structured context result retained the @everyone overwrite contribution."))
    for source_role_id in pass2.get("applicable_role_overwrite_source_ids", ()) or ():
        role_id = _snowflake(source_role_id) or str(source_role_id)
        overwrite = _snapshot_overwrite(query, role_id, source_role_id=role_id)
        details = dict(overwrite or {"source_role_id": role_id})
        details["source_role_id"] = role_id
        source_type = CATEGORY_OVERWRITE if query.context_type == "CATEGORY" else CHANNEL_OVERWRITE
        code = "CONTEXT_ROLE_ALLOW" if _int(details.get("allow_decimal")) else "CONTEXT_ROLE_DENY"
        records.append(_record(source_type=source_type, effect_classification=_effect(code, details, final_state), query=query, stage="PASS2", code=code, details=details, object_id=role_id, allow_value=details.get("allow_decimal"), deny_value=details.get("deny_decimal"), explanation="The structured context result identified an applicable role overwrite source."))
    member = pass2.get("member_overwrite_contribution")
    if isinstance(member, Mapping):
        records.append(_record(source_type=MEMBER_OVERWRITE, effect_classification=_effect("CONTEXT_MEMBER_DENY" if _int(member.get("deny_decimal")) else "CONTEXT_MEMBER_ALLOW", member, final_state), query=query, stage="PASS2", code="MEMBER_OVERWRITE", details=member, object_id=query.subject_id, allow_value=member.get("allow_decimal"), deny_value=member.get("deny_decimal"), explanation="The structured context result retained member-specific overwrite evidence."))
    return records


def _selected_record_sources(query: DoctorQuery, execution: DoctorExecution, final_state: str) -> list[SourceLocationRecord]:
    selected = _selected_record(execution)
    if not selected:
        return []
    records: list[SourceLocationRecord] = []
    key = selected.get("capability_key") or query.target_key
    if selected.get("source_permission_flag") is not None or selected.get("raw_granted") is not None:
        raw_granted = selected.get("raw_granted")
        effect = CONTROLLING_GRANT if raw_granted is True and final_state == "ALLOWED" else CONTROLLING_BLOCK if raw_granted is False and final_state == "DENIED" else INEFFECTIVE_GRANT if final_state == "INEFFECTIVE" else SUPPORTING_CONTEXT
        records.append(_record(source_type=PERMISSION_SUBSET, effect_classification=effect, query=query, stage="PASS3", code="SELECTED_CAPABILITY_RECORD", details=selected, permission_key=key, object_id=query.context_id, explanation="The selected structured capability record identifies the permission subset used by the authoritative result."))
    dependency = selected.get("dependency_result")
    if dependency and str(dependency).upper() not in {"SATISFIED", "NOT_EVALUATED"}:
        records.append(_record(source_type=CAPABILITY_DEPENDENCY, effect_classification=CONTROLLING_BLOCK if final_state == "DENIED" else UNKNOWN_EFFECT, query=query, stage="PASS3", code="CAPABILITY_DEPENDENCY", details=selected, permission_key=key, explanation="The selected structured capability record retained dependency evidence."))
    for field, source_type, code in (("timeout_result", MEMBER_TIMEOUT, "TIMEOUT"), ("source_bypass", ADMINISTRATOR_BYPASS, "BYPASS")):
        value = selected.get(field)
        if value not in (None, "INACTIVE", "NONE"):
            records.append(_record(source_type=source_type, effect_classification=_effect(code, {field: value}, final_state), query=query, stage="PASS3", code=code, details={field: value}, permission_key=key, explanation=f"The structured capability record retained {field} evidence."))
    return records


def _trace_sources(query: DoctorQuery, execution: DoctorExecution, final_state: str) -> list[SourceLocationRecord]:
    records: list[SourceLocationRecord] = []
    for stage, event, result in _trace_events(execution):
        if not _event_relevant(event, query):
            continue
        code = _text(event.get("code")) or "TRACE_EVENT"
        details = event.get("details") if isinstance(event.get("details"), Mapping) else {}
        details = dict(details)
        details.setdefault("sequence", event.get("sequence"))
        source_type = _source_type(stage, code, details, query)
        if source_type == GUILD_ASSIGNED_ROLE and "role_id" not in details and stage != "PASS1":
            source_type = PERMISSION_SUBSET
        before, after = _before_after(details)
        permission_key = details.get("capability_key") or details.get("operation_key") or query.target_key
        allow = details.get("allow_decimal") or details.get("combined_allow_decimal")
        deny = details.get("deny_decimal") or details.get("combined_deny_decimal")
        effect = _effect(code, details, final_state)
        records.append(_record(source_type=source_type, effect_classification=effect, query=query, stage=stage, code=code, details=details, permission_key=permission_key, object_id=_object_id(details, query), allow_value=allow, deny_value=deny, raw_before=before, raw_after=after, explanation=f"The structured {stage} trace event {code} is retained as provenance."))
    return records


def _result_health_sources(query: DoctorQuery, execution: DoctorExecution, final_state: str) -> list[SourceLocationRecord]:
    records: list[SourceLocationRecord] = []
    for stage, result in sorted(execution.stage_results.items()):
        value = _as_dict(result)
        completeness = _upper(value.get("completeness_state") or value.get("analysis_completeness") or value.get("completeness"))
        reasons = tuple(str(item) for item in (value.get("reason_codes") or value.get("missing_components") or ()))
        unknown_bits = value.get("unknown_permission_bits_decimal") or value.get("unknown_context_permission_bits_decimal")
        if completeness in {"UNKNOWN", "PARTIAL", "INCOMPLETE"} or reasons or unknown_bits not in (None, "0", 0):
            if unknown_bits not in (None, "0", 0):
                source_type = UNKNOWN_PERMISSION_BITS
                effect = UNKNOWN_EFFECT
                code = "UNKNOWN_PERMISSION_BITS"
            elif completeness in {"UNKNOWN", "PARTIAL", "INCOMPLETE"} or any("MISSING" in reason or "UNKNOWN" in reason or "INCOMPLETE" in reason for reason in reasons):
                source_type = MISSING_EVIDENCE
                effect = MISSING_REQUIRED_EVIDENCE
                code = "MISSING_MATERIAL_EVIDENCE"
            else:
                continue
            records.append(
                _record(
                    source_type=source_type,
                    effect_classification=effect,
                    query=query,
                    stage=stage,
                    code=code,
                    details={"completeness_state": completeness, "reason_codes": list(reasons), "unknown_permission_bits_decimal": unknown_bits},
                    object_id=query.context_id or query.target_id,
                    explanation=f"The structured {stage} result retained incomplete or unknown evidence; it was not treated as an empty source set.",
                    controlling=final_state == "UNKNOWN",
                )
            )
    return records


def _deduplicate(records: Sequence[SourceLocationRecord]) -> tuple[SourceLocationRecord, ...]:
    by_id: dict[str, SourceLocationRecord] = {}
    for record in records:
        by_id.setdefault(record.source_record_id, record)
    return tuple(sorted(by_id.values(), key=lambda item: (0 if item.controlling and item.effect_classification == CONTROLLING_BLOCK else 1 if item.controlling else 2, item.source_record_id)))


def _validate_controlling(records: Sequence[SourceLocationRecord]) -> tuple[str, ...]:
    effects: dict[str, set[str]] = {}
    for record in records:
        if record.controlling and record.permission_or_capability_key:
            effects.setdefault(record.permission_or_capability_key, set()).add(record.effect_classification)
    errors = []
    for key, values in effects.items():
        if CONTROLLING_GRANT in values and CONTROLLING_BLOCK in values:
            errors.append(f"CONTRADICTORY_CONTROLLING_SOURCES:{key}")
    return tuple(sorted(errors))


def _selected_by_detail(query: SourceLocationQuery, records: Sequence[SourceLocationRecord]) -> tuple[SourceLocationRecord, ...]:
    if query.source_intent == FIND_CONTROLLING_SOURCE or query.source_detail_level == CONTROLLING_ONLY:
        return tuple(record for record in records if record.controlling or record.effect_classification in {MISSING_REQUIRED_EVIDENCE, UNKNOWN_EFFECT})
    if query.source_intent in {TRACE_SOURCE_CHAIN, LIST_MATERIAL_SOURCES} or query.source_detail_level == MATERIAL_CHAIN:
        return tuple(record for record in records if record.effect_classification not in {INAPPLICABLE})
    return tuple(records)


@dataclass(frozen=True, slots=True)
class SourceLocationCase:
    stage5_pass3_contract_version: str
    source_location_case_contract_version: str
    source_location_query_contract_version: str
    stage5_pass3_rules_version: str
    stage5_pass3_golden_version: str
    query_identity: Mapping[str, Any]
    authoritative_doctor_case: DoctorCase | None
    authoritative_result_state: str
    primary_reason: str | None
    controlling_sources: tuple[SourceLocationRecord, ...]
    material_sources: tuple[SourceLocationRecord, ...]
    supporting_sources: tuple[SourceLocationRecord, ...]
    ineffective_sources: tuple[SourceLocationRecord, ...]
    bypassed_sources: tuple[SourceLocationRecord, ...]
    unknown_sources: tuple[SourceLocationRecord, ...]
    missing_evidence_sources: tuple[SourceLocationRecord, ...]
    accepted_limitations: tuple[SourceLocationRecord, ...]
    ordered_causal_chain: tuple[Mapping[str, Any], ...]
    source_object_summary: Mapping[str, Any]
    source_type_frequency: Mapping[str, int]
    source_effect_frequency: Mapping[str, int]
    returned_sources: tuple[SourceLocationRecord, ...]
    stage4_explanation: Mapping[str, Any] | None
    fingerprints: Mapping[str, str]
    provenance: Mapping[str, Any]
    immutability_status: Mapping[str, Any]
    status: str
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    case_fingerprint: str = ""

    def __post_init__(self) -> None:
        for field_name in ("query_identity", "source_object_summary", "source_type_frequency", "source_effect_frequency", "stage4_explanation", "fingerprints", "provenance", "immutability_status"):
            value = getattr(self, field_name)
            object.__setattr__(self, field_name, _freeze(value) if value is not None else None)

    def as_dict(self) -> dict[str, Any]:
        payload = {
            "stage5_pass3_contract_version": self.stage5_pass3_contract_version,
            "source_location_case_contract_version": self.source_location_case_contract_version,
            "source_location_query_contract_version": self.source_location_query_contract_version,
            "stage5_pass3_rules_version": self.stage5_pass3_rules_version,
            "stage5_pass3_golden_version": self.stage5_pass3_golden_version,
            "query_identity": _thaw(self.query_identity),
            "authoritative_doctor_case": self.authoritative_doctor_case.as_dict() if self.authoritative_doctor_case else None,
            "authoritative_result_state": self.authoritative_result_state,
            "primary_reason": self.primary_reason,
            "controlling_sources": [item.as_dict() for item in self.controlling_sources],
            "material_sources": [item.as_dict() for item in self.material_sources],
            "supporting_sources": [item.as_dict() for item in self.supporting_sources],
            "ineffective_sources": [item.as_dict() for item in self.ineffective_sources],
            "bypassed_sources": [item.as_dict() for item in self.bypassed_sources],
            "unknown_sources": [item.as_dict() for item in self.unknown_sources],
            "missing_evidence_sources": [item.as_dict() for item in self.missing_evidence_sources],
            "accepted_limitations": [item.as_dict() for item in self.accepted_limitations],
            "ordered_causal_chain": _thaw(self.ordered_causal_chain),
            "source_object_summary": _thaw(self.source_object_summary),
            "source_type_frequency": _thaw(self.source_type_frequency),
            "source_effect_frequency": _thaw(self.source_effect_frequency),
            "returned_sources": [item.as_dict() for item in self.returned_sources],
            "stage4_explanation": _thaw(self.stage4_explanation),
            "fingerprints": _thaw(self.fingerprints),
            "provenance": _thaw(self.provenance),
            "immutability_status": _thaw(self.immutability_status),
            "status": self.status,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "case_fingerprint": self.case_fingerprint,
        }
        return payload


@dataclass(frozen=True, slots=True)
class SourceLocationExecution:
    case: SourceLocationCase
    doctor_execution: DoctorExecution | None

    @property
    def passed(self) -> bool:
        return self.case.status == "PASS"

    def as_dict(self) -> dict[str, Any]:
        return {
            "case": self.case.as_dict(),
            "doctor_execution": self.doctor_execution.as_dict() if self.doctor_execution else None,
        }


def _build_case(query: SourceLocationQuery, execution: DoctorExecution | None, *, errors: tuple[str, ...] = (), status: str = "PASS") -> SourceLocationCase:
    if execution is None:
        empty: tuple[SourceLocationRecord, ...] = ()
        case = SourceLocationCase(
            STAGE5_PASS3_CONTRACT_VERSION,
            SOURCE_LOCATION_CASE_CONTRACT_VERSION,
            query.source_location_query_contract_version,
            STAGE5_PASS3_RULES_VERSION,
            STAGE5_PASS3_GOLDEN_VERSION,
            {"query_id": query.query_id, "doctor_query_id": query.doctor_query.query_id},
            None,
            "UNKNOWN",
            None,
            empty,
            empty,
            empty,
            empty,
            empty,
            empty,
            empty,
            empty,
            (),
            {},
            {},
            {},
            empty,
            None,
            {},
            {"validation_only": True},
            {"doctor_case_unchanged": True},
            status,
            errors,
            (),
            "",
        )
        fingerprint = _hash(case.as_dict() | {"case_fingerprint": ""})
        values = {field: getattr(case, field) for field in case.__dataclass_fields__}
        values["case_fingerprint"] = fingerprint
        return SourceLocationCase(**values)

    doctor_case = execution.case
    final_state = _final_state(execution)
    records = _deduplicate(_role_sources(query.doctor_query, execution, final_state) + _structured_overwrite_sources(query.doctor_query, execution, final_state) + _selected_record_sources(query.doctor_query, execution, final_state) + _trace_sources(query.doctor_query, execution, final_state) + _result_health_sources(query.doctor_query, execution, final_state))
    control_errors = _validate_controlling(records)
    status = "INVALID" if control_errors else status
    errors = tuple(sorted(set(errors + control_errors)))
    controlling = tuple(record for record in records if record.controlling)
    material = tuple(record for record in records if record.effect_classification not in {INAPPLICABLE, ACCEPTED_LIMITATION})
    supporting = tuple(record for record in records if record.effect_classification in {SUPPORTING_CONTEXT, CONTRIBUTING_GRANT, CONTRIBUTING_BLOCK})
    ineffective = tuple(record for record in records if record.effect_classification in {INEFFECTIVE_GRANT, OVERRIDDEN})
    bypassed = tuple(record for record in records if record.effect_classification == BYPASSED)
    unknown = tuple(record for record in records if record.effect_classification == UNKNOWN_EFFECT)
    missing = tuple(record for record in records if record.effect_classification == MISSING_REQUIRED_EVIDENCE)
    limitations = tuple(record for record in records if record.effect_classification == ACCEPTED_LIMITATION)
    answer = _as_dict(doctor_case.diagnostic_answer)
    chain = answer.get("causal_chain") if isinstance(answer.get("causal_chain"), list) else []
    type_frequency = Counter(record.source_type for record in records)
    effect_frequency = Counter(record.effect_classification for record in records)
    full_fp = _hash([record.as_dict() for record in records])
    fingerprints = {"source_records_fingerprint": full_fp, "authoritative_doctor_case_fingerprint": doctor_case.case_fingerprint, "causal_chain_fingerprint": _hash(chain)}
    source_summary = {"object_types": sorted({record.object_type for record in records if record.object_type}), "object_ids_present": sum(record.object_id is not None for record in records), "controlling_count": len(controlling), "material_count": len(material)}
    provenance = {"source_stage3_contract_versions": _as_dict(doctor_case.provenance).get("source_stage3_contract_versions", {}), "registry_versions": _as_dict(doctor_case.provenance).get("registry_versions", {}), "evidence_classifications": _as_dict(doctor_case.provenance).get("evidence_classifications", []), "verification_statuses": _as_dict(doctor_case.provenance).get("verification_statuses", [])}
    case = SourceLocationCase(
        STAGE5_PASS3_CONTRACT_VERSION,
        SOURCE_LOCATION_CASE_CONTRACT_VERSION,
        query.source_location_query_contract_version,
        STAGE5_PASS3_RULES_VERSION,
        STAGE5_PASS3_GOLDEN_VERSION,
        {"query_id": query.query_id, "doctor_query_id": query.doctor_query.query_id, "source_intent": query.source_intent, "source_detail_level": query.source_detail_level},
        doctor_case,
        final_state,
        _as_dict(doctor_case.diagnostic_answer).get("primary_reason"),
        controlling,
        material,
        supporting,
        ineffective,
        bypassed,
        unknown,
        missing,
        limitations,
        tuple(chain),
        source_summary,
        dict(sorted(type_frequency.items())),
        dict(sorted(effect_frequency.items())),
        _selected_by_detail(query, records),
        _as_dict(doctor_case.explanation),
        fingerprints,
        provenance,
        {"doctor_case_unchanged": True, "source_records_immutable": True, "snapshot_unchanged": _as_dict(doctor_case.integrity).get("snapshot_unchanged", True), "no_direct_stage3_invocation": True, "no_direct_stage4_invocation": True},
        status,
        errors,
        (),
        "",
    )
    fingerprint = _hash(
        {
            "query_identity": case.query_identity,
            "authoritative_doctor_case_fingerprint": doctor_case.case_fingerprint,
            "authoritative_result_state": case.authoritative_result_state,
            "primary_reason": case.primary_reason,
            "source_records": [record.as_dict() for record in records],
            "ordered_causal_chain": chain,
            "returned_source_ids": [record.source_record_id for record in case.returned_sources],
        }
    )
    values = {field: getattr(case, field) for field in case.__dataclass_fields__}
    values["case_fingerprint"] = fingerprint
    return SourceLocationCase(**values)


def execute_source_location_query(
    query: SourceLocationQuery | Mapping[str, Any],
    *,
    strict: bool = False,
    doctor_execution: DoctorExecution | None = None,
) -> SourceLocationExecution:
    try:
        parsed = query if isinstance(query, SourceLocationQuery) else SourceLocationQuery.from_mapping(query)
    except (TypeError, ValueError) as exc:
        if strict:
            raise SourceLocationError(str(exc))
        fallback = SourceLocationQuery(query_id="invalid-source", source_intent=FIND_CONTROLLING_SOURCE, doctor_query=DoctorQuery.from_mapping({"query_id": "invalid-doctor", "query_intent": "WHY_UNKNOWN", "target_kind": "CAPABILITY", "target_key": "message.send", "guild_id": "1", "subject_id": "1"}))
        return SourceLocationExecution(_build_case(fallback, None, errors=(f"SOURCE_QUERY_CONSTRUCTION:{exc}",), status="INVALID"), None)
    violations = validate_source_location_query(parsed)
    if violations:
        if strict:
            raise SourceLocationError("; ".join(violations))
        return SourceLocationExecution(_build_case(parsed, None, errors=violations, status="INVALID"), None)
    execution = doctor_execution if doctor_execution is not None else execute_doctor_query(parsed.doctor_query, strict=strict)
    return SourceLocationExecution(_build_case(parsed, execution), execution)


extract_source_location = execute_source_location_query
run_source_location_query = execute_source_location_query


__all__ = [
    "ACCEPTED_LIMITATION",
    "ACCEPTED_READ_ONLY_LIMITATION",
    "ADMINISTRATOR_BYPASS",
    "BYPASSED",
    "CATEGORY_OVERWRITE",
    "CAPABILITY_DEPENDENCY",
    "CHANNEL_OVERWRITE",
    "CONTROLLING_BLOCK",
    "CONTROLLING_GRANT",
    "CONTRIBUTING_BLOCK",
    "CONTRIBUTING_GRANT",
    "GUILD_ASSIGNED_ROLE",
    "GUILD_EVERYONE_ROLE",
    "GUILD_MFA_LEVEL",
    "GUILD_OWNER_BYPASS",
    "INEFFECTIVE_GRANT",
    "INAPPLICABLE",
    "LIST_MATERIAL_SOURCES",
    "MANAGED_OBJECT",
    "MEMBER_MFA_STATE",
    "MEMBER_OVERWRITE",
    "MEMBER_TIMEOUT",
    "MISSING_EVIDENCE",
    "MISSING_REQUIRED_EVIDENCE",
    "OBJECT_PRECONDITION",
    "OVERRIDDEN",
    "PERMISSION_SUBSET",
    "ROLE_HIERARCHY",
    "SOURCE_EFFECT_CLASSIFICATIONS",
    "SOURCE_TYPES",
    "SourceLocationCase",
    "SourceLocationError",
    "SourceLocationExecution",
    "SourceLocationRecord",
    "THREAD_MEMBERSHIP",
    "THREAD_PARENT",
    "THREAD_STATE",
    "TARGET_MEMBER",
    "TARGET_ROLE",
    "UNKNOWN_EFFECT",
    "UNKNOWN_PERMISSION_BITS",
    "UNSUPPORTED_RULE",
    "VOICE_STATE",
    "execute_source_location_query",
    "extract_source_location",
    "run_source_location_query",
]
