"""Validated, redacted scenario manifests for Stage 3 Pass 6 live review.

The manifest describes *what may be reviewed*; it never contains a bot token or
an instruction to execute an action.  Decimal snowflakes are accepted in a
real run and are hashed in every public evidence projection.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .action_registry import ACTION_CONTEXT_TYPES, ACTION_RULES_BY_KEY, ACTION_TARGET_TYPES


SCENARIO_MANIFEST_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE3-PASS6-SCENARIOS-0.1"
ALLOWED_EVIDENCE_CLASSIFICATIONS = frozenset(
    {
        "LIVE_DERIVED_STRUCTURE",
        "LIVE_DERIVED_ACTOR",
        "LIVE_DERIVED_TARGET",
        "LIVE_DERIVED_ROLE",
        "LIVE_DERIVED_CONTEXT",
        "LIVE_DERIVED_THREAD",
        "MODELED_RESULT",
        "DOCUMENTED_EXPECTATION",
        "SYNTHETIC_REQUEST",
        "NEEDS_LIVE_TEST",
        "NEEDS_WRITE_VERIFICATION",
    }
)
FORBIDDEN_PUBLIC_LABELS = frozenset(
    {"LIVE_EXECUTION_VERIFIED", "ENDPOINT_CONFIRMED", "ACTION_SUCCEEDED", "WRITE_VERIFIED"}
)
_PLACEHOLDER_RE = re.compile(r"^<[^>]+>$")
_SENSITIVE_KEY_PARTS = frozenset({"token", "secret", "password", "credential"})
_TOKEN_LIKE_RE = re.compile(
    r"(?i)(?:^|[^A-Za-z0-9_-])(?:Bot\s+)?[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{20,}(?:$|[^A-Za-z0-9_-])"
)
_BOOLEAN_FACT_KEYS = frozenset(
    {
        "actor_is_guild_owner",
        "target_is_guild_owner",
        "target_has_administrator",
        "target_role_managed",
        "target_role_is_everyone",
        "thread_archived",
    }
)
_INTEGER_FACT_SUFFIXES = ("_position", "_count")


def is_positive_decimal_snowflake(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    text = value.strip()
    return text.isdecimal() and int(text) > 0


def hash_identifier(value: Any) -> str:
    """Return a stable, non-reversible-looking identifier for evidence files."""

    text = str(value).strip()
    return "sha256:" + hashlib.sha256(("GUILD-DOCTOR-ID|" + text).encode("utf-8")).hexdigest()


def _contains_sensitive_key(value: Any) -> bool:
    if isinstance(value, Mapping):
        for key, item in value.items():
            key_text = str(key).lower()
            if any(part in key_text for part in _SENSITIVE_KEY_PARTS):
                return True
            if _contains_sensitive_key(item):
                return True
    elif isinstance(value, (list, tuple)):
        return any(_contains_sensitive_key(item) for item in value)
    return False


def _contains_token_like_value(value: Any) -> bool:
    """Reject token-shaped strings even when a credential key was not used."""

    if isinstance(value, Mapping):
        return any(_contains_token_like_value(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(_contains_token_like_value(item) for item in value)
    return isinstance(value, str) and bool(_TOKEN_LIKE_RE.search(value))


@dataclass(frozen=True, slots=True)
class LiveScenario:
    scenario_id: str
    guild_id: str
    operation_key: str
    actor_member_id: str
    target_type: str
    target_id: str | None
    context_id: str | None
    thread_id: str | None
    expected_evidence_classifications: tuple[str, ...]
    expected_structural_facts: Mapping[str, Any]
    expected_modeled_result: str | None
    member_acquisition_explicitly_authorized: bool
    notes: str
    verification_status: str

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any], *, index: int) -> "LiveScenario":
        required = {
            "scenario_id", "guild_id", "operation_key", "actor_member_id", "target_type",
            "target_id", "context_id", "thread_id", "expected_evidence_classifications",
            "expected_structural_facts", "expected_modeled_result",
            "member_acquisition_explicitly_authorized", "notes", "verification_status",
        }
        missing = sorted(required - set(raw))
        if missing:
            raise ValueError(f"scenario[{index}] missing fields: {', '.join(missing)}")
        scenario_id = str(raw["scenario_id"]).strip()
        if not scenario_id or _PLACEHOLDER_RE.match(scenario_id):
            raise ValueError(f"scenario[{index}].scenario_id must be filled")
        guild_id = _parse_id(raw["guild_id"], f"scenario[{index}].guild_id")
        actor_id = _parse_id(raw["actor_member_id"], f"scenario[{index}].actor_member_id")
        target_id = _optional_id(raw["target_id"], f"scenario[{index}].target_id")
        context_id = _optional_id(raw["context_id"], f"scenario[{index}].context_id")
        thread_id = _optional_id(raw["thread_id"], f"scenario[{index}].thread_id")
        target_type = str(raw["target_type"]).strip().upper()
        if not target_type:
            raise ValueError(f"scenario[{index}].target_type must be non-empty")
        operation_key = str(raw["operation_key"]).strip()
        action_rule = ACTION_RULES_BY_KEY.get(operation_key)
        if action_rule is None:
            raise ValueError(f"scenario[{index}].operation_key is not registered: {operation_key or '<missing>'}")
        if target_type not in ACTION_TARGET_TYPES or target_type not in action_rule.target_types:
            allowed = ", ".join(action_rule.target_types)
            raise ValueError(
                f"scenario[{index}] target_type {target_type or '<missing>'} is incompatible with "
                f"{operation_key}; expected one of: {allowed}"
            )
        classifications_raw = raw["expected_evidence_classifications"]
        if not isinstance(classifications_raw, (list, tuple)):
            raise ValueError(f"scenario[{index}].expected_evidence_classifications must be an array")
        classifications = tuple(sorted({str(item).strip() for item in classifications_raw}))
        unknown = sorted(set(classifications) - ALLOWED_EVIDENCE_CLASSIFICATIONS)
        forbidden = sorted(set(classifications) & FORBIDDEN_PUBLIC_LABELS)
        if unknown:
            raise ValueError(f"scenario[{index}] unknown evidence classifications: {', '.join(unknown)}")
        if forbidden:
            raise ValueError(f"scenario[{index}] forbidden evidence classifications: {', '.join(forbidden)}")
        facts = raw["expected_structural_facts"]
        if not isinstance(facts, Mapping):
            raise ValueError(f"scenario[{index}].expected_structural_facts must be an object")
        _validate_expected_facts(facts, action_rule.context_types, index=index)
        expected = raw["expected_modeled_result"]
        if expected is not None:
            expected = str(expected).strip().upper()
            if expected not in {"ALLOWED", "DENIED", "UNKNOWN", "NOT_APPLICABLE", "UNSUPPORTED"}:
                raise ValueError(f"scenario[{index}].expected_modeled_result is not a supported result")
        authorized = raw["member_acquisition_explicitly_authorized"]
        if not isinstance(authorized, bool):
            raise ValueError(f"scenario[{index}].member_acquisition_explicitly_authorized must be boolean")
        if not authorized:
            raise ValueError(f"scenario[{index}] must explicitly authorize targeted member acquisition")
        if target_type == "NONE" and target_id is not None:
            raise ValueError(f"scenario[{index}] target_id must be null for target_type NONE")
        return cls(
            scenario_id=scenario_id,
            guild_id=guild_id,
            operation_key=operation_key,
            actor_member_id=actor_id,
            target_type=target_type,
            target_id=target_id,
            context_id=context_id,
            thread_id=thread_id,
            expected_evidence_classifications=classifications,
            expected_structural_facts=dict(facts),
            expected_modeled_result=expected,
            member_acquisition_explicitly_authorized=authorized,
            notes=str(raw["notes"]),
            verification_status=str(raw["verification_status"]).strip().upper(),
        )

    def as_redacted_dict(self) -> dict[str, Any]:
        return {
            "scenario_id": self.scenario_id,
            "guild_id": hash_identifier(self.guild_id),
            "operation_key": self.operation_key,
            "actor_member_id": hash_identifier(self.actor_member_id),
            "target_type": self.target_type,
            "target_id": hash_identifier(self.target_id) if self.target_id else None,
            "context_id": hash_identifier(self.context_id) if self.context_id else None,
            "thread_id": hash_identifier(self.thread_id) if self.thread_id else None,
            "expected_evidence_classifications": list(self.expected_evidence_classifications),
            "expected_structural_facts": _redact_ids(self.expected_structural_facts),
            "expected_modeled_result": self.expected_modeled_result,
            "member_acquisition_explicitly_authorized": self.member_acquisition_explicitly_authorized,
            "notes": self.notes,
            "verification_status": self.verification_status,
        }


def _parse_id(value: Any, field_name: str) -> str:
    if not is_positive_decimal_snowflake(value) or _PLACEHOLDER_RE.match(str(value).strip()):
        raise ValueError(f"{field_name} must be a positive decimal snowflake")
    return str(int(str(value).strip()))


def _optional_id(value: Any, field_name: str) -> str | None:
    if value is None:
        return None
    return _parse_id(value, field_name)


def _validate_expected_facts(
    facts: Mapping[str, Any],
    allowed_context_types: tuple[str, ...],
    *,
    index: int,
) -> None:
    """Validate the observed-fact shapes without contacting Discord."""

    for key, value in facts.items():
        field = f"scenario[{index}].expected_structural_facts.{key}"
        if _contains_placeholder(value):
            raise ValueError(f"{field} contains an unfilled placeholder")
        key_text = str(key).lower()
        if key_text in _BOOLEAN_FACT_KEYS:
            if not isinstance(value, bool):
                raise ValueError(f"{field} must be boolean")
        elif key_text.endswith("_id") or key_text == "id":
            if value is not None:
                _parse_id(value, field)
        elif key_text.endswith("_ids"):
            if not isinstance(value, (list, tuple)) or not all(is_positive_decimal_snowflake(item) for item in value):
                raise ValueError(f"{field} must be an array of positive decimal snowflakes")
        elif key_text.endswith(_INTEGER_FACT_SUFFIXES):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{field} must be a non-negative integer")
        if key_text == "context_type":
            context_type = str(value).strip().upper()
            if context_type not in ACTION_CONTEXT_TYPES or context_type not in allowed_context_types:
                allowed = ", ".join(allowed_context_types)
                raise ValueError(f"{field} {context_type or '<missing>'} is incompatible; expected one of: {allowed}")


def _contains_placeholder(value: Any) -> bool:
    if isinstance(value, str):
        return bool(_PLACEHOLDER_RE.match(value.strip()))
    if isinstance(value, Mapping):
        return any(_contains_placeholder(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(_contains_placeholder(item) for item in value)
    return False


def _redact_ids(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _redact_ids(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact_ids(item) for item in value]
    if isinstance(value, tuple):
        return [_redact_ids(item) for item in value]
    if is_positive_decimal_snowflake(value):
        return hash_identifier(value)
    return value


def load_scenario_manifest(path: Path) -> tuple[LiveScenario, ...]:
    return validate_scenario_manifest_data(json.loads(path.read_text(encoding="utf-8")))


def validate_scenario_manifest_data(data: Any) -> tuple[LiveScenario, ...]:
    """Validate already-loaded manifest data without filesystem or network access."""

    if _contains_sensitive_key(data) or _contains_token_like_value(data):
        raise ValueError("scenario manifest contains a forbidden credential field")
    if not isinstance(data, Mapping):
        raise ValueError("scenario manifest must be a JSON object")
    contract = str(data.get("contract", ""))
    if contract != SCENARIO_MANIFEST_CONTRACT_VERSION:
        raise ValueError(f"unsupported scenario manifest contract: {contract or '<missing>'}")
    scenarios = data.get("scenarios")
    if not isinstance(scenarios, list) or not scenarios:
        raise ValueError("scenario manifest must contain at least one scenario")
    result = tuple(LiveScenario.from_mapping(item, index=index) for index, item in enumerate(scenarios))
    guilds = {item.guild_id for item in result}
    if len(guilds) != 1:
        raise ValueError("all scenarios must target one disposable guild")
    scenario_ids = [item.scenario_id for item in result]
    if len(scenario_ids) != len(set(scenario_ids)):
        raise ValueError("scenario_id values must be unique")
    return result


def redacted_manifest(scenarios: tuple[LiveScenario, ...]) -> dict[str, Any]:
    return {
        "contract": SCENARIO_MANIFEST_CONTRACT_VERSION,
        "scenario_count": len(scenarios),
        "guild_id": hash_identifier(scenarios[0].guild_id) if scenarios else None,
        "scenarios": [item.as_redacted_dict() for item in scenarios],
    }


__all__ = [
    "ALLOWED_EVIDENCE_CLASSIFICATIONS",
    "FORBIDDEN_PUBLIC_LABELS",
    "LiveScenario",
    "SCENARIO_MANIFEST_CONTRACT_VERSION",
    "hash_identifier",
    "is_positive_decimal_snowflake",
    "load_scenario_manifest",
    "redacted_manifest",
    "validate_scenario_manifest_data",
]
