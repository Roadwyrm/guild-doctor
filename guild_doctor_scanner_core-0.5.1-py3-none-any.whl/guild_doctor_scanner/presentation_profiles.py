"""Immutable Stage 4 Pass 3 presentation and disclosure profiles."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any


PRESENTATION_PROFILE_VERSION = "GUILD-DOCTOR-PRESENTATION-PROFILES-0.1"

OUTPUT_FORMATS = frozenset({"PLAIN_TEXT", "DISCORD_MARKDOWN", "STRUCTURED_JSON"})
PRESENTATION_MODES = frozenset({"SIMPLE", "DETAILED", "TECHNICAL"})
PRESENTATION_SECTIONS = frozenset(
    {
        "RESULT",
        "SUMMARY",
        "PRIMARY_REASON",
        "SUPPORTING_REASONS",
        "BLOCKERS",
        "UNCERTAINTIES",
        "BYPASS",
        "RAW_VERSUS_EFFECTIVE",
        "THREAD_STATE",
        "AUTHORITY",
        "MFA",
        "PRECONDITIONS",
        "PRE_EXECUTION_DISCLAIMER",
        "PROVENANCE",
        "TRACE",
    }
)


class PresentationProfileError(ValueError):
    """Raised for an invalid profile or disclosure policy."""


@dataclass(frozen=True, slots=True)
class DisclosurePolicy:
    """Boolean presentation disclosures; source meaning is never changed."""

    include_ids: bool = False
    include_raw_permission_values: bool = False
    include_unknown_bits: bool = False
    include_contract_versions: bool = False
    include_registry_versions: bool = False
    include_rule_ids: bool = False
    include_trace_summary: bool = False
    include_full_trace: bool = False
    include_source_references: bool = False
    include_fingerprints: bool = False
    include_evidence_classifications: bool = False
    include_verification_statuses: bool = False

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any] | "DisclosurePolicy" | None) -> "DisclosurePolicy":
        if value is None:
            return cls()
        if isinstance(value, cls):
            return value
        if not isinstance(value, Mapping):
            raise PresentationProfileError("DISCLOSURE_POLICY_NOT_MAPPING")
        names = {field.name for field in cls.__dataclass_fields__.values()}
        unknown = sorted(str(key) for key in value if str(key) not in names)
        if unknown:
            raise PresentationProfileError(f"DISCLOSURE_POLICY_UNKNOWN_FIELDS:{','.join(unknown)}")
        normalized: dict[str, bool] = {}
        for name in names:
            if name in value:
                raw = value[name]
                if not isinstance(raw, bool):
                    raise PresentationProfileError(f"DISCLOSURE_POLICY_NOT_BOOLEAN:{name}")
                normalized[name] = raw
        return cls(**normalized)

    def as_dict(self) -> dict[str, bool]:
        return {field.name: bool(getattr(self, field.name)) for field in self.__dataclass_fields__.values()}


@dataclass(frozen=True, slots=True)
class PresentationProfile:
    profile_key: str
    purpose: str
    default_mode: str
    default_output_format: str
    allowed_modes: tuple[str, ...]
    allowed_output_formats: tuple[str, ...]
    default_disclosure: DisclosurePolicy
    section_order: tuple[str, ...]
    supported_sections: tuple[str, ...]
    max_characters: int | None
    max_lines: int | None
    discord_safe: bool
    order: int

    def __post_init__(self) -> None:
        object.__setattr__(self, "profile_key", self.profile_key.strip().upper())
        object.__setattr__(self, "default_mode", self.default_mode.strip().upper())
        object.__setattr__(self, "default_output_format", self.default_output_format.strip().upper())
        object.__setattr__(self, "allowed_modes", tuple(sorted({item.strip().upper() for item in self.allowed_modes})))
        object.__setattr__(self, "allowed_output_formats", tuple(sorted({item.strip().upper() for item in self.allowed_output_formats})))
        object.__setattr__(self, "section_order", tuple(item.strip().upper() for item in self.section_order))
        object.__setattr__(self, "supported_sections", tuple(sorted({item.strip().upper() for item in self.supported_sections})))
        if not isinstance(self.default_disclosure, DisclosurePolicy):
            object.__setattr__(self, "default_disclosure", DisclosurePolicy.from_mapping(self.default_disclosure))

    def as_dict(self) -> dict[str, Any]:
        return {
            "presentation_profile_version": PRESENTATION_PROFILE_VERSION,
            "profile_key": self.profile_key,
            "purpose": self.purpose,
            "default_mode": self.default_mode,
            "default_output_format": self.default_output_format,
            "allowed_modes": list(self.allowed_modes),
            "allowed_output_formats": list(self.allowed_output_formats),
            "default_disclosure": self.default_disclosure.as_dict(),
            "section_order": list(self.section_order),
            "supported_sections": list(self.supported_sections),
            "max_characters": self.max_characters,
            "max_lines": self.max_lines,
            "discord_safe": self.discord_safe,
            "order": self.order,
        }


_SIMPLE_SECTIONS = (
    "RESULT",
    "SUMMARY",
    "PRIMARY_REASON",
    "SUPPORTING_REASONS",
    "UNCERTAINTIES",
    "PRE_EXECUTION_DISCLAIMER",
)
_DETAILED_SECTIONS = (
    "RESULT",
    "SUMMARY",
    "PRIMARY_REASON",
    "SUPPORTING_REASONS",
    "BLOCKERS",
    "UNCERTAINTIES",
    "BYPASS",
    "RAW_VERSUS_EFFECTIVE",
    "THREAD_STATE",
    "AUTHORITY",
    "MFA",
    "PRECONDITIONS",
    "PRE_EXECUTION_DISCLAIMER",
    "PROVENANCE",
)
_TECHNICAL_SECTIONS = _DETAILED_SECTIONS + ("TRACE",)

_SIMPLE_DISCLOSURE = DisclosurePolicy(include_evidence_classifications=True, include_verification_statuses=True)
_DETAILED_DISCLOSURE = DisclosurePolicy(
    include_trace_summary=True,
    include_source_references=True,
    include_evidence_classifications=True,
    include_verification_statuses=True,
)
_TECHNICAL_DISCLOSURE = DisclosurePolicy(
    include_ids=True,
    include_raw_permission_values=True,
    include_unknown_bits=True,
    include_contract_versions=True,
    include_registry_versions=True,
    include_rule_ids=True,
    include_trace_summary=True,
    include_full_trace=True,
    include_source_references=True,
    include_fingerprints=True,
    include_evidence_classifications=True,
    include_verification_statuses=True,
)


PRESENTATION_PROFILES = (
    PresentationProfile(
        "SIMPLE_CARD", "Compact beginner explanation", "SIMPLE", "PLAIN_TEXT",
        ("SIMPLE",), ("PLAIN_TEXT",), _SIMPLE_DISCLOSURE, _SIMPLE_SECTIONS,
        _SIMPLE_SECTIONS, 4000, 20, False, 1,
    ),
    PresentationProfile(
        "DETAILED_REPORT", "Owner or administrator explanation", "DETAILED", "PLAIN_TEXT",
        ("DETAILED",), ("PLAIN_TEXT",), _DETAILED_DISCLOSURE, _DETAILED_SECTIONS,
        _DETAILED_SECTIONS, 12000, 80, False, 2,
    ),
    PresentationProfile(
        "TECHNICAL_RECORD", "Developer and evidence review", "TECHNICAL", "PLAIN_TEXT",
        ("TECHNICAL",), ("PLAIN_TEXT", "STRUCTURED_JSON"), _TECHNICAL_DISCLOSURE,
        _TECHNICAL_SECTIONS, _TECHNICAL_SECTIONS, 20000, 160, False, 3,
    ),
    PresentationProfile(
        "DISCORD_SAFE_SIMPLE", "Simple explanation safe for later Discord display", "SIMPLE", "DISCORD_MARKDOWN",
        ("SIMPLE",), ("DISCORD_MARKDOWN",), _SIMPLE_DISCLOSURE, _SIMPLE_SECTIONS,
        _SIMPLE_SECTIONS, 2000, 20, True, 4,
    ),
    PresentationProfile(
        "DISCORD_SAFE_DETAILED", "Detailed explanation safe for later Discord display", "DETAILED", "DISCORD_MARKDOWN",
        ("DETAILED",), ("DISCORD_MARKDOWN",), _DETAILED_DISCLOSURE, _DETAILED_SECTIONS,
        _DETAILED_SECTIONS, 2000, 40, True, 5,
    ),
    PresentationProfile(
        "MACHINE_JSON", "Complete deterministic structured explanation", "TECHNICAL", "STRUCTURED_JSON",
        ("TECHNICAL",), ("STRUCTURED_JSON",), _TECHNICAL_DISCLOSURE, _TECHNICAL_SECTIONS,
        _TECHNICAL_SECTIONS, None, None, False, 6,
    ),
)

PRESENTATION_PROFILES_BY_KEY = MappingProxyType({item.profile_key: item for item in PRESENTATION_PROFILES})


def validate_presentation_profiles() -> tuple[str, ...]:
    errors: list[str] = []
    keys: set[str] = set()
    orders: set[int] = set()
    for profile in PRESENTATION_PROFILES:
        if profile.profile_key in keys:
            errors.append(f"DUPLICATE_PROFILE:{profile.profile_key}")
        if profile.order in orders:
            errors.append(f"DUPLICATE_PROFILE_ORDER:{profile.order}")
        keys.add(profile.profile_key)
        orders.add(profile.order)
        if profile.default_mode not in profile.allowed_modes:
            errors.append(f"DEFAULT_MODE_NOT_ALLOWED:{profile.profile_key}")
        if profile.default_output_format not in profile.allowed_output_formats:
            errors.append(f"DEFAULT_FORMAT_NOT_ALLOWED:{profile.profile_key}")
        if set(profile.section_order) - set(profile.supported_sections):
            errors.append(f"SECTION_ORDER_NOT_SUPPORTED:{profile.profile_key}")
        if set(profile.supported_sections) - set(PRESENTATION_SECTIONS):
            errors.append(f"UNKNOWN_SECTION:{profile.profile_key}")
        if profile.max_characters is not None and profile.max_characters <= 0:
            errors.append(f"MAX_CHARACTERS_INVALID:{profile.profile_key}")
        if profile.max_lines is not None and profile.max_lines <= 0:
            errors.append(f"MAX_LINES_INVALID:{profile.profile_key}")
    if keys != {"SIMPLE_CARD", "DETAILED_REPORT", "TECHNICAL_RECORD", "DISCORD_SAFE_SIMPLE", "DISCORD_SAFE_DETAILED", "MACHINE_JSON"}:
        errors.append("PROFILE_COVERAGE_INCOMPLETE")
    return tuple(sorted(set(errors)))


def get_presentation_profile(profile_key: str) -> PresentationProfile | None:
    if not isinstance(profile_key, str):
        return None
    return PRESENTATION_PROFILES_BY_KEY.get(profile_key.strip().upper())


__all__ = [
    "DisclosurePolicy",
    "OUTPUT_FORMATS",
    "PRESENTATION_MODES",
    "PRESENTATION_PROFILE_VERSION",
    "PRESENTATION_PROFILES",
    "PRESENTATION_PROFILES_BY_KEY",
    "PRESENTATION_SECTIONS",
    "PresentationProfile",
    "PresentationProfileError",
    "get_presentation_profile",
    "validate_presentation_profiles",
]
