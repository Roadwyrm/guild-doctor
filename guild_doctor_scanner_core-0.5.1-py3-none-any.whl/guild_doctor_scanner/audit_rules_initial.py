"""Pure evaluators for the exact Stage 6 Pass 6B seven-rule tranche."""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import re
from types import MappingProxyType
from typing import Any, Callable

from .audit_finding import AffectedObjectReference, AuditFinding, EvidenceReference
from .canonical import sha256_hex
from .capability_engine import STAGE3_PASS3_ENGINE_CONTRACT_VERSION
from .capability_registry import KNOWN_PERMISSION_FLAGS


INITIAL_RULE_EVALUATOR_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS6B-RULE-EVALUATOR-0.1"
PERMITTED_TRACE_CONTRACTS = frozenset({STAGE3_PASS3_ENGINE_CONTRACT_VERSION})
SUPPORTED_CATEGORY_CHILD_TYPES = frozenset({"TEXT", "ANNOUNCEMENT", "VOICE", "STAGE", "FORUM", "MEDIA"})
BROAD_MANAGEMENT_PERMISSION_FLAGS = (
    "BAN_MEMBERS",
    "KICK_MEMBERS",
    "MANAGE_CHANNELS",
    "MANAGE_EVENTS",
    "MANAGE_GUILD_EXPRESSIONS",
    "MANAGE_GUILD",
    "MANAGE_MESSAGES",
    "MANAGE_ROLES",
    "MANAGE_THREADS",
    "MANAGE_WEBHOOKS",
    "MODERATE_MEMBERS",
)
_MASKS = {flag.name: flag.mask for flag in KNOWN_PERMISSION_FLAGS}
_FINGERPRINT = re.compile(r"^[0-9a-f]{64}$")


class AuditRuleInputError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class RuleEvaluation:
    rule_id: str
    evaluation_state: str
    findings: tuple[AuditFinding, ...] = ()
    missing_evidence: tuple[str, ...] = ()
    errors: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "evaluation_state": self.evaluation_state,
            "findings": [finding.as_dict() for finding in self.findings],
            "missing_evidence": list(self.missing_evidence),
            "errors": list(self.errors),
        }


def _records(snapshot: Mapping[str, Any], key: str) -> tuple[Mapping[str, Any], ...] | None:
    value = snapshot.get(key)
    if value is None:
        return None
    if isinstance(value, Mapping):
        rows = tuple(value.values())
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        rows = tuple(value)
    else:
        raise AuditRuleInputError(f"AUDIT_{key.upper()}_COLLECTION_INVALID")
    if any(not isinstance(row, Mapping) for row in rows):
        raise AuditRuleInputError(f"AUDIT_{key.upper()}_RECORD_INVALID")
    return tuple(sorted(rows, key=lambda row: _decimal_id(row.get("id"), f"AUDIT_{key.upper()}_ID_INVALID")))


def _decimal_id(value: Any, error: str) -> str:
    result = str(value or "").strip()
    if not result.isdecimal():
        raise AuditRuleInputError(error)
    return result


def _collection_state(snapshot: Mapping[str, Any], key: str) -> str:
    collections = snapshot.get("collections")
    if isinstance(collections, Mapping):
        value = collections.get(key)
        if isinstance(value, Mapping):
            return str(value.get("status", "UNKNOWN")).upper()
        if isinstance(value, str):
            return value.upper()
    return "UNKNOWN"


def _section_complete(snapshot: Mapping[str, Any], key: str) -> bool:
    structural = str(snapshot.get("structural_completeness", "UNKNOWN")).upper()
    state = _collection_state(snapshot, key)
    return structural == "COMPLETE" and state in {"COMPLETE", "UNKNOWN"} and snapshot.get(key) is not None


def _permissions(role: Mapping[str, Any]) -> int:
    value = str(role.get("permissions_decimal", "")).strip()
    if not value.isdecimal():
        raise AuditRuleInputError("AUDIT_ROLE_PERMISSIONS_INVALID")
    return int(value)


def _binding_types(role: Mapping[str, Any]) -> tuple[str, ...]:
    tags = role.get("role_tags")
    if not isinstance(tags, Mapping):
        return ()
    fields = (
        ("bot_id", "BOT"),
        ("integration_id", "INTEGRATION"),
        ("subscription_listing_id", "SUBSCRIPTION"),
        ("available_for_purchase", "PURCHASABLE"),
        ("guild_connections", "GUILD_CONNECTIONS"),
    )
    return tuple(label for field, label in fields if tags.get(field) not in (None, False))


def _opaque_id(prefix: str, payload: Mapping[str, Any]) -> str:
    return f"{prefix}-{sha256_hex(dict(payload))[:16].upper()}"


def _role_ref(role: Mapping[str, Any]) -> AffectedObjectReference:
    return AffectedObjectReference("ROLE", _decimal_id(role.get("id"), "AUDIT_ROLE_ID_INVALID"), "Role reference", "roles")


def _channel_ref(channel: Mapping[str, Any]) -> AffectedObjectReference:
    kind = "CATEGORY" if str(channel.get("type_key", "")).upper() == "CATEGORY" else "CHANNEL"
    return AffectedObjectReference(kind, _decimal_id(channel.get("id"), "AUDIT_CHANNEL_ID_INVALID"), f"{kind.title()} reference", "channels")


def _member_ref(overwrite: Mapping[str, Any]) -> AffectedObjectReference:
    return AffectedObjectReference("MEMBER", _decimal_id(overwrite.get("target_id"), "AUDIT_MEMBER_OVERWRITE_ID_INVALID"), "Member overwrite target", "channels.permission_overwrites")


def _evidence(field_path: str, *, contract: str = "GUILD-DOCTOR-SNAPSHOT-0.1", trace: str | None = None, fingerprint: str | None = None) -> EvidenceReference:
    return EvidenceReference("NORMALIZED_SNAPSHOT" if trace is None else "FROZEN_TRACE", contract, field_path, fingerprint, trace)


def _finding(
    *,
    rule_id: str,
    title: str,
    finding_class: str,
    severity: str,
    confidence: str,
    verification_label: str,
    objects: Sequence[AffectedObjectReference],
    observed: Mapping[str, Any],
    importance: str,
    evidence: Sequence[EvidenceReference],
    traces: Sequence[EvidenceReference] = (),
    missing: Sequence[str] = (),
    beginner: str,
    technical: str,
    options: Sequence[str] = ("REVIEW_CONFIGURATION", "LEAVE_UNCHANGED"),
    tradeoffs: Sequence[str] = (),
    group_payload: Mapping[str, Any],
    evaluation_state: str = "FINDING",
) -> AuditFinding:
    group = _opaque_id(f"AUDIT-GROUP-{rule_id}", group_payload)
    finding_id = _opaque_id(f"AUDIT-{rule_id}", {"group": group})
    return AuditFinding(
        finding_id=finding_id,
        rule_id=rule_id,
        title=title,
        finding_class=finding_class,
        severity=severity,
        confidence=confidence,
        verification_label=verification_label,
        evaluation_state=evaluation_state,
        completeness_state="COMPLETE" if evaluation_state == "FINDING" else "PARTIAL",
        affected_objects=tuple(objects),
        observed_condition=observed,
        practical_importance=importance,
        evidence_references=tuple(evidence),
        causal_trace_references=tuple(traces),
        missing_evidence=tuple(missing),
        beginner_explanation=beginner,
        technical_explanation=technical,
        safe_options=tuple(options),
        tradeoffs=tuple(tradeoffs),
        duplicate_grouping_key=group,
        status="PASS",
    )


def evaluate_administrator_grant(snapshot: Mapping[str, Any], traces: Sequence[Mapping[str, Any]]) -> RuleEvaluation:
    del traces
    rule_id = "ADMINISTRATOR_GRANT"
    if not _section_complete(snapshot, "roles"):
        return RuleEvaluation(rule_id, "INCOMPLETE", missing_evidence=("ROLES_COMPLETE_REQUIRED",))
    roles = _records(snapshot, "roles") or ()
    eligible_roles = tuple(role for role in roles if role.get("is_everyone") is not True)
    if not eligible_roles:
        return RuleEvaluation(rule_id, "NOT_APPLICABLE")
    findings: list[AuditFinding] = []
    for role in eligible_roles:
        bits = _permissions(role)
        if not bits & _MASKS["ADMINISTRATOR"]:
            continue
        managed = bool(role.get("managed"))
        bindings = _binding_types(role)
        findings.append(_finding(
            rule_id=rule_id, title="Role directly grants Administrator", finding_class="SECURITY_AUTHORITY",
            severity="MEDIUM" if managed else "HIGH", confidence="VERIFIED", verification_label="VERIFIED_DISCORD_BEHAVIOR",
            objects=(_role_ref(role),), observed={"administrator_granted": True, "managed": managed, "binding_types": list(bindings)},
            importance="Administrator bypasses channel permission overwrites, so the direct grant has server-wide authority implications.",
            evidence=(_evidence("roles.permissions_decimal"), _evidence("roles.managed"), _evidence("roles.role_tags")),
            beginner="This role directly grants Administrator. That bypasses channel permission overwrites, but this finding does not infer why the role was configured this way.",
            technical="The normalized role permission integer contains the frozen Administrator bit. No holder, owner intent, or effective member state was inferred.",
            tradeoffs=("Managed or integration roles may intentionally require broad authority.",), group_payload={"role_id": role["id"]},
        ))
    return RuleEvaluation(rule_id, "FINDING" if findings else "NOT_FOUND", tuple(findings))


def evaluate_broad_management_authority(snapshot: Mapping[str, Any], traces: Sequence[Mapping[str, Any]]) -> RuleEvaluation:
    del traces
    rule_id = "BROAD_MANAGEMENT_AUTHORITY"
    if not _section_complete(snapshot, "roles"):
        return RuleEvaluation(rule_id, "INCOMPLETE", missing_evidence=("ROLES_COMPLETE_REQUIRED",))
    eligible_roles = tuple(role for role in (_records(snapshot, "roles") or ()) if role.get("is_everyone") is not True)
    if not eligible_roles:
        return RuleEvaluation(rule_id, "NOT_APPLICABLE")
    findings: list[AuditFinding] = []
    for role in eligible_roles:
        bits = _permissions(role)
        grants = tuple(flag for flag in BROAD_MANAGEMENT_PERMISSION_FLAGS if bits & _MASKS[flag])
        if len(grants) < 3:
            continue
        managed = bool(role.get("managed"))
        severity = "HIGH" if len(grants) >= 6 and not managed else "MEDIUM" if not managed else "LOW"
        findings.append(_finding(
            rule_id=rule_id, title="Role has broad management authority", finding_class="SECURITY_AUTHORITY",
            severity=severity, confidence="VERIFIED", verification_label="VERIFIED_DISCORD_BEHAVIOR",
            objects=(_role_ref(role),), observed={"management_grants": list(grants), "grant_count": len(grants), "administrator_excluded": True, "managed": managed, "binding_types": list(_binding_types(role))},
            importance="Several direct management grants can affect broad server configuration or moderation scope.",
            evidence=(_evidence("roles.permissions_decimal"), _evidence("permission_definition.management_flags"), _evidence("roles.managed")),
            beginner="This role combines several management permissions. The finding records the grants without claiming abuse, compromise, or incorrect owner intent.",
            technical="The grouped result uses the frozen Pass 6B management flag set and excludes Administrator from the count.",
            tradeoffs=("Broad management roles may be intentional, especially for managed integrations.",), group_payload={"role_id": role["id"], "grants": grants},
        ))
    return RuleEvaluation(rule_id, "FINDING" if findings else "NOT_FOUND", tuple(findings))


def _validated_trace(value: Mapping[str, Any]) -> dict[str, Any]:
    contract = str(value.get("trace_contract", ""))
    fingerprint = str(value.get("trace_fingerprint", ""))
    if contract not in PERMITTED_TRACE_CONTRACTS:
        raise AuditRuleInputError("AUDIT_TRACE_CONTRACT_UNSUPPORTED")
    if not _FINGERPRINT.fullmatch(fingerprint):
        raise AuditRuleInputError("AUDIT_TRACE_FINGERPRINT_INVALID")
    scope_type = str(value.get("scope_type", "")).upper()
    if scope_type not in {"GUILD", "CHANNEL", "CATEGORY", "THREAD"}:
        raise AuditRuleInputError("AUDIT_TRACE_SCOPE_TYPE_INVALID")
    scope_id = _decimal_id(value.get("scope_id"), "AUDIT_TRACE_SCOPE_ID_INVALID")
    subject_id = _decimal_id(value.get("subject_id"), "AUDIT_TRACE_SUBJECT_ID_INVALID")
    target_kind = str(value.get("target_kind", "")).upper()
    target_key = str(value.get("target_key", "")).strip()
    final_result = str(value.get("final_result", "")).upper()
    if final_result not in {"INEFFECTIVE", "EFFECTIVE", "NOT_APPLICABLE", "UNKNOWN", "INCOMPLETE"}:
        raise AuditRuleInputError("AUDIT_TRACE_FINAL_RESULT_INVALID")
    missing = value.get("missing_prerequisites", ())
    if isinstance(missing, str) or not isinstance(missing, Sequence):
        raise AuditRuleInputError("AUDIT_TRACE_PREREQUISITES_INVALID")
    missing_values = tuple(sorted({str(item).strip() for item in missing if str(item).strip()}))
    trace_ref = str(value.get("trace_event_reference", "")).strip()
    if not target_kind or not target_key or not trace_ref:
        raise AuditRuleInputError("AUDIT_TRACE_REQUIRED_FIELD_MISSING")
    if final_result == "INEFFECTIVE" and not missing_values:
        raise AuditRuleInputError("AUDIT_TRACE_PREREQUISITE_MISSING")
    return {"trace_contract": contract, "trace_fingerprint": fingerprint, "scope_type": scope_type, "scope_id": scope_id, "subject_id": subject_id, "target_kind": target_kind, "target_key": target_key, "final_result": final_result, "missing_prerequisites": missing_values, "trace_event_reference": trace_ref}


def project_ineffective_capability_traces(result: Any) -> tuple[dict[str, Any], ...]:
    """Project frozen Stage 3 ineffective records without recalculating them."""
    method = getattr(result, "as_dict", None)
    payload = method() if callable(method) else result
    if not isinstance(payload, Mapping):
        raise AuditRuleInputError("AUDIT_TRACE_SOURCE_NOT_MAPPING")
    if payload.get("engine_contract_version") != STAGE3_PASS3_ENGINE_CONTRACT_VERSION:
        raise AuditRuleInputError("AUDIT_TRACE_CONTRACT_UNSUPPORTED")
    if payload.get("raw_permission_bits_unchanged") is not True:
        raise AuditRuleInputError("AUDIT_TRACE_RAW_PERMISSION_PRESERVATION_REQUIRED")
    source_trace = payload.get("trace")
    records = payload.get("ineffective_grant_records")
    if not isinstance(source_trace, Sequence) or isinstance(source_trace, (str, bytes, bytearray)) or not source_trace:
        raise AuditRuleInputError("AUDIT_TRACE_EVENTS_REQUIRED")
    if not isinstance(records, Sequence) or isinstance(records, (str, bytes, bytearray)):
        raise AuditRuleInputError("AUDIT_TRACE_INEFFECTIVE_RECORDS_INVALID")
    fingerprint = sha256_hex({"engine_contract_version": STAGE3_PASS3_ENGINE_CONTRACT_VERSION, "trace": list(source_trace)})
    subject_id = _decimal_id(payload.get("subject_id"), "AUDIT_TRACE_SUBJECT_ID_INVALID")
    context_id = payload.get("context_id")
    context_type = str(payload.get("context_type") or "").upper()
    if context_id is None:
        scope_type = "GUILD"
        scope_id = _decimal_id(payload.get("guild_id"), "AUDIT_TRACE_SCOPE_ID_INVALID")
    else:
        scope_type = "CATEGORY" if context_type == "CATEGORY" else "THREAD" if context_type.endswith("THREAD") else "CHANNEL"
        scope_id = _decimal_id(context_id, "AUDIT_TRACE_SCOPE_ID_INVALID")
    projections: list[dict[str, Any]] = []
    for record in records:
        if not isinstance(record, Mapping):
            raise AuditRuleInputError("AUDIT_TRACE_INEFFECTIVE_RECORD_INVALID")
        if str(record.get("final_result", "")).upper() != "INEFFECTIVE" or record.get("raw_granted") is not True:
            raise AuditRuleInputError("AUDIT_TRACE_INEFFECTIVE_RECORD_CONTRADICTORY")
        if str(record.get("verification_status", "")).upper() != "VERIFIED":
            raise AuditRuleInputError("AUDIT_TRACE_RECORD_NOT_VERIFIED")
        blocking = record.get("blocking_rule_ids")
        if not isinstance(blocking, Sequence) or isinstance(blocking, (str, bytes, bytearray)) or not blocking:
            raise AuditRuleInputError("AUDIT_TRACE_PREREQUISITE_MISSING")
        target_key = str(record.get("capability_key", "")).strip()
        if not target_key:
            raise AuditRuleInputError("AUDIT_TRACE_REQUIRED_FIELD_MISSING")
        reference = f"CAPABILITY-TRACE-{sha256_hex({'trace': fingerprint, 'target_key': target_key})[:16].upper()}"
        projections.append({
            "trace_contract": STAGE3_PASS3_ENGINE_CONTRACT_VERSION,
            "trace_fingerprint": fingerprint,
            "scope_type": scope_type,
            "scope_id": scope_id,
            "subject_id": subject_id,
            "target_kind": "CAPABILITY",
            "target_key": target_key,
            "final_result": "INEFFECTIVE",
            "missing_prerequisites": sorted({str(item) for item in blocking}),
            "trace_event_reference": reference,
        })
    return tuple(sorted(projections, key=lambda item: (item["target_key"], item["trace_event_reference"])))


def _trace_objects_exist(snapshot: Mapping[str, Any], trace: Mapping[str, Any]) -> bool:
    roles = _records(snapshot, "roles")
    if roles is None or trace["subject_id"] not in {str(role.get("id")) for role in roles}:
        return False
    if trace["scope_type"] == "GUILD":
        return trace["scope_id"] == str(snapshot.get("guild_id") or (snapshot.get("guild") or {}).get("id"))
    collection = "threads" if trace["scope_type"] == "THREAD" else "channels"
    records = _records(snapshot, collection)
    return records is not None and trace["scope_id"] in {str(record.get("id")) for record in records}


def evaluate_trace_backed_ineffective_permission(snapshot: Mapping[str, Any], traces: Sequence[Mapping[str, Any]]) -> RuleEvaluation:
    rule_id = "TRACE_BACKED_INEFFECTIVE_PERMISSION"
    if not traces:
        return RuleEvaluation(rule_id, "INCOMPLETE", missing_evidence=("AUTHORITATIVE_TRACE_REQUIRED",))
    findings: list[AuditFinding] = []
    saw_not_applicable = False
    for raw in traces:
        trace = _validated_trace(raw)
        if trace["final_result"] == "NOT_APPLICABLE":
            saw_not_applicable = True
            continue
        if not _trace_objects_exist(snapshot, trace):
            return RuleEvaluation(rule_id, "INCOMPLETE", missing_evidence=("TRACE_AFFECTED_OBJECT_NOT_IN_SNAPSHOT",))
        if trace["final_result"] != "INEFFECTIVE":
            continue
        scope = AffectedObjectReference(trace["scope_type"], trace["scope_id"], f"{trace['scope_type'].title()} scope", "trace.scope")
        subject = AffectedObjectReference("ROLE", trace["subject_id"], "Role reference", "trace.subject")
        trace_evidence = _evidence("trace.final_result", contract=trace["trace_contract"], trace=trace["trace_event_reference"], fingerprint=trace["trace_fingerprint"])
        findings.append(_finding(
            rule_id=rule_id, title="Granted permission or capability is ineffective", finding_class="CONFLICTS_INEFFECTIVENESS",
            severity="MEDIUM", confidence="VERIFIED", verification_label="VERIFIED_DISCORD_BEHAVIOR",
            objects=(subject, scope), observed={"target_kind": trace["target_kind"], "target_key": trace["target_key"], "frozen_result": "INEFFECTIVE", "missing_prerequisites": list(trace["missing_prerequisites"]), "scope_type": trace["scope_type"]},
            importance="A frozen engine trace shows that the direct grant cannot take effect in the supplied scope because required evidence is absent.",
            evidence=(trace_evidence,), traces=(trace_evidence,),
            beginner="The permission is granted, but the supplied frozen trace says a required prerequisite is missing in this specific scope.",
            technical="The finding consumes an authoritative INEFFECTIVE trace result and does not recalculate prerequisite logic or convert the result to DENIED.",
            tradeoffs=("The conclusion applies only to the supplied trace scope.",), group_payload={"fingerprint": trace["trace_fingerprint"], "target": trace["target_key"]},
        ))
    return RuleEvaluation(rule_id, "FINDING" if findings else "NOT_APPLICABLE" if saw_not_applicable else "NOT_FOUND", tuple(findings))


def evaluate_non_synced_category_child(snapshot: Mapping[str, Any], traces: Sequence[Mapping[str, Any]]) -> RuleEvaluation:
    del traces
    rule_id = "NON_SYNCED_CATEGORY_CHILD"
    if not _section_complete(snapshot, "channels"):
        return RuleEvaluation(rule_id, "INCOMPLETE", missing_evidence=("CHANNELS_COMPLETE_REQUIRED",))
    channels = _records(snapshot, "channels") or ()
    supported_children = tuple(channel for channel in channels if str(channel.get("type_key", "")).upper() in SUPPORTED_CATEGORY_CHILD_TYPES)
    if not supported_children:
        return RuleEvaluation(rule_id, "NOT_APPLICABLE")
    by_id = {_decimal_id(row.get("id"), "AUDIT_CHANNEL_ID_INVALID"): row for row in channels}
    grouped: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for channel in channels:
        parent_id = str(channel.get("parent_id") or "")
        if str(channel.get("type_key", "")).upper() not in SUPPORTED_CATEGORY_CHILD_TYPES:
            continue
        if parent_id and str(channel.get("sync_state", "")).upper() == "NOT_SYNCED":
            parent = by_id.get(parent_id)
            if parent is None or str(parent.get("type_key", "")).upper() != "CATEGORY":
                raise AuditRuleInputError("AUDIT_CATEGORY_PARENT_INVALID")
            grouped[parent_id].append(channel)
    findings: list[AuditFinding] = []
    for parent_id in sorted(grouped, key=int):
        parent = by_id[parent_id]
        children = sorted(grouped[parent_id], key=lambda row: int(str(row["id"])))
        findings.append(_finding(
            rule_id=rule_id, title="Category child is not permission-synced", finding_class="SYNCHRONIZATION_EXCEPTIONS",
            severity="LOW", confidence="VERIFIED", verification_label="GUILD_DOCTOR_DOCTRINE",
            objects=(_channel_ref(parent), *(_channel_ref(child) for child in children)),
            observed={"unsynced_child_count": len(children), "sync_state": "NOT_SYNCED", "supported_child_types": sorted({str(child.get("type_key", "")).upper() for child in children})},
            importance="Unsynced category children can accumulate independent permission exceptions that require separate review.",
            evidence=(_evidence("channels.parent_id"), _evidence("channels.sync_state"), _evidence("channels.sync_evidence")),
            beginner="These channels do not share the category's overwrites. This may be intentional; Guild Doctor records a review item, not a Discord error.",
            technical="The normalized child sync_state is NOT_SYNCED and the resolved parent is a CATEGORY. No owner intent was inferred.",
            tradeoffs=("Intentional exceptions are valid and should not be treated as defects.",), group_payload={"category_id": parent_id},
        ))
    return RuleEvaluation(rule_id, "FINDING" if findings else "NOT_FOUND", tuple(findings))


def _overwrites(channel: Mapping[str, Any]) -> tuple[Mapping[str, Any], ...]:
    value = channel.get("permission_overwrites", ())
    if value is None:
        return ()
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)) or any(not isinstance(item, Mapping) for item in value):
        raise AuditRuleInputError("AUDIT_OVERWRITE_COLLECTION_INVALID")
    return tuple(value)


def evaluate_member_overwrite_presence(snapshot: Mapping[str, Any], traces: Sequence[Mapping[str, Any]]) -> RuleEvaluation:
    del traces
    rule_id = "MEMBER_OVERWRITE_PRESENCE"
    if not _section_complete(snapshot, "channels"):
        return RuleEvaluation(rule_id, "INCOMPLETE", missing_evidence=("CHANNELS_COMPLETE_REQUIRED",))
    channels = _records(snapshot, "channels") or ()
    eligible_channels = tuple(channel for channel in channels if str(channel.get("type_key", "")).upper() in SUPPORTED_CATEGORY_CHILD_TYPES | {"CATEGORY"})
    if not eligible_channels:
        return RuleEvaluation(rule_id, "NOT_APPLICABLE")
    member_complete = str(snapshot.get("member_completeness", "UNKNOWN")).upper() == "COMPLETE"
    findings: list[AuditFinding] = []
    for channel in eligible_channels:
        member_overwrites = tuple(sorted((item for item in _overwrites(channel) if str(item.get("target_type", "")).upper() == "MEMBER"), key=lambda item: int(_decimal_id(item.get("target_id"), "AUDIT_MEMBER_OVERWRITE_ID_INVALID"))))
        if not member_overwrites:
            continue
        missing = () if member_complete else (f"MEMBER_IDENTITY_METADATA_{str(snapshot.get('member_completeness', 'UNKNOWN')).upper()}",)
        findings.append(_finding(
            rule_id=rule_id, title="Member-specific permission overwrite is present", finding_class="MAINTAINABILITY_PERMISSION_DEBT",
            severity="LOW", confidence="VERIFIED", verification_label="GUILD_DOCTOR_DOCTRINE",
            objects=(_channel_ref(channel), *(_member_ref(item) for item in member_overwrites)),
            observed={"member_overwrite_count": len(member_overwrites), "member_identity_metadata_complete": member_complete, "presence_only": True},
            importance="Member-specific overwrites add maintenance and explanation cost because access depends on individual exceptions.",
            evidence=(_evidence("channels.permission_overwrites.target_type"), _evidence("member_completeness")), missing=missing,
            beginner="This channel or category has an individual member permission exception. Presence alone does not mean the overwrite is harmful or wrong.",
            technical="The normalized overwrite target_type is MEMBER. The raw target ID is retained only as internal identity and is not serialized.",
            tradeoffs=("Individual exceptions may be intentional and necessary.",), group_payload={"channel_id": channel["id"]},
        ))
    return RuleEvaluation(rule_id, "FINDING" if findings else "NOT_FOUND", tuple(findings))


def _role_profile(role: Mapping[str, Any]) -> dict[str, Any]:
    position = role.get("position")
    if type(position) is not int or position < 0:
        raise AuditRuleInputError("AUDIT_ROLE_POSITION_INVALID")
    return {
        "permissions_decimal": str(_permissions(role)),
        "position": position,
        "managed": bool(role.get("managed")),
        "is_everyone": bool(role.get("is_everyone")),
        "binding_types": list(_binding_types(role)),
    }


def evaluate_identical_role_profiles(snapshot: Mapping[str, Any], traces: Sequence[Mapping[str, Any]]) -> RuleEvaluation:
    del traces
    rule_id = "IDENTICAL_ROLE_PROFILES"
    if not _section_complete(snapshot, "roles"):
        return RuleEvaluation(rule_id, "INCOMPLETE", missing_evidence=("ROLES_COMPLETE_REQUIRED",))
    eligible_roles = tuple(role for role in (_records(snapshot, "roles") or ()) if role.get("is_everyone") is not True)
    if not eligible_roles:
        return RuleEvaluation(rule_id, "NOT_APPLICABLE")
    groups: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    profiles: dict[str, dict[str, Any]] = {}
    for role in eligible_roles:
        profile = _role_profile(role)
        key = sha256_hex(profile)
        groups[key].append(role)
        profiles[key] = profile
    findings: list[AuditFinding] = []
    for key in sorted(groups):
        roles = sorted(groups[key], key=lambda row: int(str(row["id"])))
        if len(roles) < 2:
            continue
        profile = profiles[key]
        findings.append(_finding(
            rule_id=rule_id, title="Distinct roles have identical authority-significant profiles", finding_class="MAINTAINABILITY_PERMISSION_DEBT",
            severity="LOW", confidence="VERIFIED", verification_label="GUILD_DOCTOR_DOCTRINE",
            objects=tuple(_role_ref(role) for role in roles),
            observed={"role_count": len(roles), "profile_fingerprint": key, "profile_fields": ["permissions_decimal", "position", "managed", "is_everyone", "binding_types"]},
            importance="Identical authority-significant profiles may increase maintenance effort when several roles must be reviewed separately.",
            evidence=(_evidence("roles.permissions_decimal"), _evidence("roles.position"), _evidence("roles.managed"), _evidence("roles.role_tags")),
            beginner="These distinct roles currently have the same permission, hierarchy, managed, and binding profile. Their purpose may still be different, so no merge is recommended.",
            technical="Equality includes permissions_decimal, hierarchy position, managed state, @everyone state, and binding-type presence. Names, display settings, and nearly-equal profiles are excluded.",
            tradeoffs=("Identical permission profiles do not imply identical owner purpose.",), group_payload={"profile_fingerprint": key, "role_ids": [role["id"] for role in roles]},
        ))
    return RuleEvaluation(rule_id, "FINDING" if findings else "NOT_FOUND", tuple(findings))


def evaluate_incomplete_evidence(snapshot: Mapping[str, Any], traces: Sequence[Mapping[str, Any]]) -> RuleEvaluation:
    del traces
    rule_id = "INCOMPLETE_EVIDENCE"
    states: dict[str, str] = {
        "structural": str(snapshot.get("structural_completeness", "UNKNOWN")).upper(),
        "members": str(snapshot.get("member_completeness", "UNKNOWN")).upper(),
        "threads": str(snapshot.get("thread_completeness", "UNKNOWN")).upper(),
    }
    collections = snapshot.get("collections")
    if isinstance(collections, Mapping):
        for key, value in sorted(collections.items(), key=lambda item: str(item[0])):
            states[f"collection.{key}"] = str(value.get("status", "UNKNOWN") if isinstance(value, Mapping) else value).upper()
    incomplete = {key: value for key, value in states.items() if value not in {"COMPLETE", "NOT_APPLICABLE"}}
    if not incomplete:
        return RuleEvaluation(rule_id, "NOT_FOUND")
    guild_id = _decimal_id(snapshot.get("guild_id") or (snapshot.get("guild") or {}).get("id"), "AUDIT_GUILD_ID_INVALID")
    missing = tuple(f"{key.upper().replace('.', '_')}:{value}" for key, value in sorted(incomplete.items()))
    finding = _finding(
        rule_id=rule_id, title="Audit evidence is incomplete", finding_class="NEEDS_REVIEW_INCOMPLETE_DATA",
        severity="NEEDS_REVIEW", confidence="INSUFFICIENT_DATA", verification_label="PROPOSED_PRODUCT_BEHAVIOR",
        objects=(AffectedObjectReference("GUILD", guild_id, "Guild scope", "snapshot"),),
        observed={"incomplete_evidence": incomplete, "affected_audit_scope": sorted(incomplete)},
        importance="Missing or incomplete collections prevent affected audit areas from making a complete absence-of-risk claim.",
        evidence=(_evidence("snapshot.completeness"), _evidence("collections.status")), missing=missing,
        beginner="Some audit evidence was not requested or is incomplete. Guild Doctor keeps that uncertainty visible instead of treating missing evidence as a clean result.",
        technical="The finding groups explicit non-COMPLETE completeness states without creating one finding for every skipped rule.",
        options=("REQUEST_MISSING_EVIDENCE", "LEAVE_UNCHANGED"), tradeoffs=("Collecting more evidence may increase privacy exposure and must be separately authorized.",),
        group_payload={"states": incomplete}, evaluation_state="NEEDS_REVIEW",
    )
    return RuleEvaluation(rule_id, "NEEDS_REVIEW", (finding,), missing)


EVALUATORS: Mapping[str, Callable[[Mapping[str, Any], Sequence[Mapping[str, Any]]], RuleEvaluation]] = MappingProxyType({
    "evaluate_administrator_grant": evaluate_administrator_grant,
    "evaluate_broad_management_authority": evaluate_broad_management_authority,
    "evaluate_trace_backed_ineffective_permission": evaluate_trace_backed_ineffective_permission,
    "evaluate_non_synced_category_child": evaluate_non_synced_category_child,
    "evaluate_member_overwrite_presence": evaluate_member_overwrite_presence,
    "evaluate_identical_role_profiles": evaluate_identical_role_profiles,
    "evaluate_incomplete_evidence": evaluate_incomplete_evidence,
})


__all__ = [
    "AuditRuleInputError", "BROAD_MANAGEMENT_PERMISSION_FLAGS", "EVALUATORS", "INITIAL_RULE_EVALUATOR_CONTRACT",
    "PERMITTED_TRACE_CONTRACTS", "RuleEvaluation", "project_ineffective_capability_traces",
]
