"""Immutable, data-driven Stage 4 Pass 1 explanation rules."""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .explanation_schema import (
    EXPLANATION_GOLDEN_VERSION,
    EXPLANATION_RULES_VERSION,
    RESULT_FAMILIES,
)


@dataclass(frozen=True, slots=True)
class ExplanationRule:
    rule_id: str
    family: str
    stage: str
    priority: int
    template_key: str
    reason_kind: str
    description: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "family": self.family,
            "stage": self.stage,
            "priority": self.priority,
            "template_key": self.template_key,
            "reason_kind": self.reason_kind,
            "description": self.description,
        }


def _rule(
    rule_id: str,
    description: str,
    *,
    family: str = "*",
    stage: str = "EVIDENCE",
    priority: int = 100,
    template_key: str | None = None,
    reason_kind: str = "supporting",
) -> ExplanationRule:
    return ExplanationRule(
        rule_id=rule_id,
        family=family,
        stage=stage,
        priority=priority,
        template_key=template_key or rule_id,
        reason_kind=reason_kind,
        description=description,
    )


EXPLANATION_RULES = (
    _rule("GRANTED_BY_EVERYONE_ROLE", "The @everyone role is a recorded permission source.", family="GUILD_PERMISSION", priority=90),
    _rule("GRANTED_BY_ASSIGNED_ROLE", "An assigned role is a recorded permission source.", family="GUILD_PERMISSION", priority=91),
    _rule("OWNER_BYPASS", "The Stage 3 result records owner bypass treatment.", priority=30, reason_kind="bypass"),
    _rule("ADMINISTRATOR_BYPASS", "The Stage 3 result records Administrator channel-permission bypass treatment.", priority=31, reason_kind="bypass"),
    _rule("DENIED_BY_EVERYONE_OVERWRITE", "The @everyone overwrite is recorded as a deny source.", family="CONTEXT_PERMISSION", priority=50, reason_kind="blocking"),
    _rule("ALLOWED_BY_EVERYONE_OVERWRITE", "The @everyone overwrite is recorded as an allow source.", family="CONTEXT_PERMISSION", priority=51),
    _rule("DENIED_BY_ROLE_OVERWRITE", "The combined role overwrite is recorded as a deny source.", family="CONTEXT_PERMISSION", priority=52, reason_kind="blocking"),
    _rule("ALLOWED_BY_ROLE_OVERWRITE", "The combined role overwrite is recorded as an allow source.", family="CONTEXT_PERMISSION", priority=53),
    _rule("DENIED_BY_MEMBER_OVERWRITE", "The member-specific overwrite is recorded as a deny source.", family="CONTEXT_PERMISSION", priority=54, reason_kind="blocking"),
    _rule("ALLOWED_BY_MEMBER_OVERWRITE", "The member-specific overwrite is recorded as an allow source.", family="CONTEXT_PERMISSION", priority=55),
    _rule("RAW_GRANTED_BUT_CONTEXT_INAPPLICABLE", "A raw permission grant is recorded as inapplicable in this context.", family="CAPABILITY", priority=60, reason_kind="blocking"),
    _rule("RAW_GRANTED_BUT_VIEW_CHANNEL_MISSING", "A raw grant is ineffective because VIEW_CHANNEL is unavailable.", family="CAPABILITY", priority=61, reason_kind="blocking"),
    _rule("RAW_GRANTED_BUT_SEND_MESSAGES_MISSING", "A raw grant is ineffective because SEND_MESSAGES is unavailable.", family="CAPABILITY", priority=62, reason_kind="blocking"),
    _rule("RAW_GRANTED_BUT_TIMEOUT_RESTRICTED", "A raw grant is restricted by the recorded timeout state.", family="CAPABILITY", priority=63, reason_kind="blocking"),
    _rule("THREAD_PARENT_NOT_VISIBLE", "The thread parent visibility result is not allowed.", family="THREAD", priority=40, reason_kind="blocking"),
    _rule("PRIVATE_THREAD_MEMBERSHIP_REQUIRED", "Private-thread membership is required by the recorded thread result.", family="THREAD", priority=41, reason_kind="blocking"),
    _rule("THREAD_SEND_PERMISSION_MISSING", "The thread send permission result is not allowed.", family="THREAD", priority=42, reason_kind="blocking"),
    _rule("THREAD_ARCHIVED_AUTO_UNARCHIVE_PREDICTION", "The result predicts auto-unarchive; it does not perform it.", family="THREAD", priority=80, reason_kind="limitation"),
    _rule("THREAD_LOCKED_RESTRICTION", "The locked-thread state is recorded as a restriction.", family="THREAD", priority=43, reason_kind="blocking"),
    _rule("HIERARCHY_TARGET_EQUAL_OR_HIGHER", "The target role is not recorded as strictly below the actor.", family="AUTHORITY", priority=44, reason_kind="blocking"),
    _rule("GUILD_OWNER_TARGET_PROTECTED", "The guild-owner target protection is recorded.", family="AUTHORITY", priority=45, reason_kind="blocking"),
    _rule("ADMINISTRATOR_TIMEOUT_TARGET_PROTECTED", "The Administrator timeout-target protection is recorded.", family="AUTHORITY", priority=46, reason_kind="blocking"),
    _rule("MANAGED_ROLE_RESTRICTION", "The managed-role restriction is recorded.", family="AUTHORITY", priority=47, reason_kind="blocking"),
    _rule("PERMISSION_SUBSET_FAILED", "The requested permission subset is recorded as failed.", family="AUTHORITY", priority=48, reason_kind="blocking"),
    _rule("MFA_REQUIRED_AND_MISSING", "A required MFA precondition is recorded as missing.", family="AUTHORITY", priority=49, reason_kind="blocking"),
    _rule("OBJECT_PRECONDITION_FAILED", "An operation object precondition is recorded as failed.", family="AUTHORITY", priority=50, reason_kind="blocking"),
    _rule("REQUIRED_EVIDENCE_UNKNOWN", "Required evidence is recorded as unknown or incomplete.", priority=10, reason_kind="uncertainty"),
    _rule("OPERATION_UNSUPPORTED", "The operation is outside the registered action vocabulary.", family="ACTION", priority=11, reason_kind="uncertainty"),
    _rule("ACTION_NOT_APPLICABLE", "The registered action does not apply to this target or context.", family="ACTION", priority=12, reason_kind="supporting"),
    _rule("PRE_EXECUTION_MODEL_ONLY", "The Stage 3 result is a pre-execution model and is not an endpoint guarantee.", family="ACTION", priority=18, reason_kind="limitation"),
    _rule("UNKNOWN_PERMISSION_BITS_PRESENT", "Unknown permission bits are preserved without fabricated names.", priority=70, reason_kind="uncertainty"),
    _rule("ACCEPTED_READ_ONLY_LIMITATION", "A read-only boundary limits what can be claimed.", priority=90, reason_kind="limitation"),
)

EXPLANATION_RULES_BY_ID = MappingProxyType({item.rule_id: item for item in EXPLANATION_RULES})

# These are the frozen Stage 3 identifiers accepted by the Pass 1 explanation
# layer.  They are metadata only; the explanation engine never imports or runs
# any Stage 3 calculation engine.
FROZEN_STAGE3_CONTRACTS = MappingProxyType(
    {
        "scanner_contract_version": "GUILD-DOCTOR-SCANNER-0.5",
        "snapshot_schema_version": "GUILD-DOCTOR-SNAPSHOT-0.1",
        "pass1_contract_version": "GUILD-DOCTOR-STAGE3-PASS1-0.1",
        "pass2_contract_version": "GUILD-DOCTOR-STAGE3-PASS2-0.1",
        "pass3_contract_version": "GUILD-DOCTOR-STAGE3-PASS3-0.1",
        "pass4_contract_version": "GUILD-DOCTOR-STAGE3-PASS4-0.1",
        "pass5_contract_version": "GUILD-DOCTOR-STAGE3-PASS5-0.1",
        "pass6_contract_version": "GUILD-DOCTOR-STAGE3-PASS6-0.1",
        "closure_contract_version": "GUILD-DOCTOR-STAGE3-CLOSURE-0.1",
        "permission_definition_version": "DISCORD-PERM-2026-07-13",
    }
)


def validate_explanation_registry() -> tuple[str, ...]:
    errors: list[str] = []
    seen: set[str] = set()
    for item in EXPLANATION_RULES:
        if item.rule_id in seen:
            errors.append(f"DUPLICATE_RULE_ID:{item.rule_id}")
        seen.add(item.rule_id)
        if not item.rule_id or not item.description:
            errors.append(f"RULE_METADATA_MISSING:{item.rule_id or '<empty>'}")
        if item.family != "*" and item.family not in RESULT_FAMILIES:
            errors.append(f"RULE_FAMILY_INVALID:{item.rule_id}")
        if item.priority < 0:
            errors.append(f"RULE_PRIORITY_INVALID:{item.rule_id}")
    return tuple(sorted(set(errors)))


__all__ = [
    "EXPLANATION_GOLDEN_VERSION",
    "EXPLANATION_RULES",
    "EXPLANATION_RULES_BY_ID",
    "EXPLANATION_RULES_VERSION",
    "ExplanationRule",
    "FROZEN_STAGE3_CONTRACTS",
    "validate_explanation_registry",
]
