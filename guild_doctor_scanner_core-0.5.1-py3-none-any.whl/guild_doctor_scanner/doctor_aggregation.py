"""Pure deterministic aggregation rules for Stage 5 Pass 2."""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping, Sequence
from typing import Any

from .canonical import canonical_json
from .doctor_enumeration_query import (
    ENUMERATE_ACTUAL_RESULTS,
    DoctorEnumerationQuery,
    WHO_CAN,
    WHO_CANNOT,
    WHO_UNKNOWN,
)
from .doctor_population import (
    CandidateDisposition,
    DUPLICATE_INPUT,
    EVALUATED,
    EXCLUDED_BY_POLICY,
    INVALID_CANDIDATE,
    MISSING_MATERIAL_DATA,
    PopulationNormalization,
)


ENUMERATION_RULES_VERSION = "GUILD-DOCTOR-ENUMERATION-RULES-0.1"
ENUMERATION_CASE_CONTRACT_VERSION = "GUILD-DOCTOR-ENUMERATION-CASE-0.1"
ENUMERATION_GOLDEN_VERSION = "GUILD-DOCTOR-ENUMERATION-GOLDEN-0.1"
BUCKET_ORDER = ("ALLOWED", "DENIED", "INEFFECTIVE", "UNKNOWN", "NOT_APPLICABLE", "UNSUPPORTED")
LOCATION_ORDER = (
    "guild_role",
    "category",
    "channel",
    "member_overwrite",
    "thread_membership",
    "timeout",
    "target",
    "hierarchy",
    "guild_mfa",
    "managed_object",
    "object_precondition",
    "context",
    "unknown",
)


def _safe(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _safe(method())
    if isinstance(value, Mapping):
        return {str(k): _safe(v) for k, v in sorted(value.items(), key=lambda item: str(item[0]))}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_safe(v) for v in value]
    return value


def _case(value: Any) -> Any:
    return getattr(value, "case", value)


def _case_dict(value: Any) -> Mapping[str, Any]:
    item = _case(value)
    if isinstance(item, Mapping):
        return item
    method = getattr(item, "as_dict", None)
    return method() if callable(method) else {}


def _state(value: Any) -> str:
    data = _case_dict(value)
    actual = data.get("actual_result") if isinstance(data, Mapping) else None
    state = actual.get("result_state") if isinstance(actual, Mapping) else None
    if not isinstance(state, str):
        state = "UNKNOWN"
    return state.upper() if state.upper() in BUCKET_ORDER else "UNKNOWN"


def _child_fingerprint(value: Any) -> str | None:
    data = _case_dict(value)
    value = data.get("case_fingerprint")
    return str(value) if value else None


def _child_query_id(value: Any) -> str | None:
    data = _case_dict(value)
    value = data.get("query_id")
    return str(value) if value else None


def _child_answer(value: Any) -> Mapping[str, Any]:
    data = _case_dict(value)
    answer = data.get("diagnostic_answer")
    return answer if isinstance(answer, Mapping) else {}


def _child_actual(value: Any) -> Mapping[str, Any]:
    data = _case_dict(value)
    actual = data.get("actual_result")
    return actual if isinstance(actual, Mapping) else {}


def _child_provenance(value: Any) -> Mapping[str, Any]:
    data = _case_dict(value)
    provenance = data.get("provenance")
    return provenance if isinstance(provenance, Mapping) else {}


def _bounded_subject_phrase(query: DoctorEnumerationQuery, population: PopulationNormalization, count: int) -> str:
    if population.coverage_complete:
        return f"all {len(population.evaluable)} evaluated guild members"
    if query.population_source == "EXPLICIT_CANDIDATES":
        return f"the {len(population.evaluable)} evaluated candidates"
    return f"the {len(population.evaluable)} evaluated members"


def _scope(query: DoctorEnumerationQuery, population: PopulationNormalization) -> dict[str, Any]:
    if population.coverage_complete:
        classification = "COMPLETE_GUILD_POPULATION"
        statement = f"This report covers all {len(population.evaluable)} evaluated guild members under the supplied complete collection evidence."
    elif query.population_coverage == "PARTIAL_GUILD_MEMBERS":
        classification = "PARTIAL_GUILD_POPULATION"
        statement = "This report is bounded to the available member records; it is not a server-wide result."
    elif query.population_coverage == "UNKNOWN_COVERAGE":
        classification = "UNKNOWN_POPULATION"
        statement = "This report is bounded to the supplied records; population coverage is unknown."
    elif query.population_coverage == "NOT_REQUESTED":
        classification = "POPULATION_NOT_REQUESTED"
        statement = "This report is bounded to the supplied records; complete guild membership was not requested."
    else:
        classification = "EXPLICIT_CANDIDATE_SET"
        statement = "This report is bounded to the supplied candidate set; it is not a server-wide result."
    return {
        "scope_classification": classification,
        "scope_statement": statement,
        "server_wide_claims_permitted": population.coverage_complete,
        "population_complete": population.coverage_complete,
        "coverage_reasons": list(population.coverage_reasons),
    }


def _matching(state: str, intent: str) -> str:
    if intent == WHO_CAN:
        return "MATCHING" if state == "ALLOWED" else "CONTRADICTED" if state in {"DENIED", "INEFFECTIVE"} else "UNRESOLVED" if state == "UNKNOWN" else state
    if intent == WHO_CANNOT:
        return "MATCHING" if state in {"DENIED", "INEFFECTIVE"} else "CONTRADICTED" if state == "ALLOWED" else "UNRESOLVED" if state == "UNKNOWN" else state
    if intent == WHO_UNKNOWN:
        return "MATCHING" if state == "UNKNOWN" else "RESOLVED" if state in {"ALLOWED", "DENIED", "INEFFECTIVE"} else state
    return "ACTUAL_RESULT"


def aggregate_enumeration(
    query: DoctorEnumerationQuery,
    population: PopulationNormalization,
    child_results: Mapping[str, Any],
) -> dict[str, Any]:
    """Aggregate authoritative child cases without recalculating permission."""

    entries_by_state: dict[str, list[dict[str, Any]]] = {key: [] for key in BUCKET_ORDER}
    premise_counts: Counter[str] = Counter()
    reason_counts: Counter[str] = Counter()
    location_counts: Counter[tuple[str, str]] = Counter()
    completeness_counts: Counter[str] = Counter()
    evidence_counts: Counter[str] = Counter()
    verification_counts: Counter[str] = Counter()
    bypass_counts: Counter[str] = Counter()
    pre_execution_count = 0
    child_case_failures: list[dict[str, Any]] = []

    for disposition in population.evaluable:
        child = child_results.get(disposition.candidate_id or "")
        state = _state(child) if child is not None else "UNKNOWN"
        data = _case_dict(child) if child is not None else {}
        answer = _child_answer(child) if child is not None else {}
        actual = _child_actual(child) if child is not None else {}
        provenance = _child_provenance(child) if child is not None else {}
        if child is None or data.get("status") != "PASS":
            child_case_failures.append({"candidate_id": disposition.candidate_id, "reason": "CHILD_DOCTOR_FAILURE", "child_status": data.get("status", "MISSING")})
        premise = str(data.get("premise_alignment", "UNKNOWN"))
        premise_counts[premise] += 1
        reason = str(answer.get("primary_reason", "ENUMERATION-UNKNOWN-001"))
        reason_counts[reason] += 1
        for location in answer.get("source_locations", ()) if isinstance(answer.get("source_locations"), Sequence) else ():
            if isinstance(location, Mapping):
                location_type = str(location.get("location", "unknown"))
                location_id = str(location.get("context_id") or location.get("target_id") or location.get("guild_id") or "")
                location_counts[(location_type, location_id)] += 1
        completeness = str(actual.get("completeness", "UNKNOWN"))
        completeness_counts[completeness] += 1
        for key in provenance.get("evidence_classifications", ()) if isinstance(provenance.get("evidence_classifications"), Sequence) else ():
            evidence_counts[str(key)] += 1
        for key in provenance.get("verification_statuses", ()) if isinstance(provenance.get("verification_statuses"), Sequence) else ():
            verification_counts[str(key)] += 1
        bypass_counts[str(actual.get("bypass_state") or "NONE")] += 1
        if actual.get("decision_basis") == "PRE_EXECUTION_MODEL":
            pre_execution_count += 1
        entry: dict[str, Any] = {
            "candidate_id": disposition.candidate_id,
            "display_label": disposition.display_label,
            "candidate_kind": disposition.candidate_kind,
            "child_query_id": _child_query_id(child),
            "child_case_fingerprint": _child_fingerprint(child),
            "primary_reason": reason,
            "source_locations": _safe(answer.get("source_locations", ())),
            "premise_alignment": premise,
            "status": data.get("status", "MISSING"),
        }
        if query.include_full_doctor_cases:
            entry["doctor_case"] = _safe(child)
        entries_by_state[state].append(entry)

    for state in BUCKET_ORDER:
        entries_by_state[state].sort(key=lambda item: int(item["candidate_id"]) if str(item.get("candidate_id", "")).isdecimal() else 0)

    intent_records = []
    for state in BUCKET_ORDER:
        for entry in entries_by_state[state]:
            intent_records.append((entry, _matching(state, query.enumeration_intent)))
    matching = [entry for entry, alignment in intent_records if alignment == "MATCHING"]
    contradicted = [entry for entry, alignment in intent_records if alignment == "CONTRADICTED"]
    unresolved = [entry for entry, alignment in intent_records if alignment == "UNRESOLVED"]
    not_applicable = entries_by_state["NOT_APPLICABLE"]
    unsupported = entries_by_state["UNSUPPORTED"]

    scope = _scope(query, population)
    evaluated_count = len(population.evaluable)
    if matching:
        direct = f"{len(matching)} of {_bounded_subject_phrase(query, population, len(matching))} match {query.enumeration_intent}."
    else:
        if population.coverage_complete:
            direct = f"No matching members were found among all {evaluated_count} evaluated guild members."
        else:
            direct = f"No matching members were found among the {evaluated_count} evaluated candidates; this is not a server-wide result."
    if query.enumeration_intent == ENUMERATE_ACTUAL_RESULTS:
        direct = f"Actual results are reported for {evaluated_count} evaluated candidates; no premise was applied."

    population_status_counts = Counter(item.status for item in population.dispositions)
    bucket_payload: dict[str, Any] = {}
    for state in BUCKET_ORDER:
        entries = entries_by_state[state]
        bucket_payload[state] = {
            "count": len(entries),
            "candidate_ids": [entry["candidate_id"] for entry in entries],
            "display_safe_labels": [entry["display_label"] for entry in entries],
            "child_case_fingerprints": [entry["child_case_fingerprint"] for entry in entries if entry.get("child_case_fingerprint")],
            "entries": entries if query.include_result_buckets else [],
        }

    ordered_reasons = sorted(reason_counts.items(), key=lambda item: (-item[1], item[0]))
    location_rank = {key: index for index, key in enumerate(LOCATION_ORDER)}
    ordered_locations = sorted(location_counts.items(), key=lambda item: (-item[1], location_rank.get(item[0][0], len(LOCATION_ORDER)), item[0][1]))
    source_locations = [{"location": key[0], "location_id": key[1], "count": value} for key, value in ordered_locations]
    return {
        "scope": scope,
        "population_status_counts": dict(sorted(population_status_counts.items())),
        "supplied_member_count": len(population.dispositions),
        "normalized_candidate_count": len({item.candidate_id for item in population.dispositions if item.candidate_id}),
        "evaluated_candidate_count": evaluated_count,
        "excluded_count": sum(population_status_counts[key] for key in (EXCLUDED_BY_POLICY, INVALID_CANDIDATE, DUPLICATE_INPUT, MISSING_MATERIAL_DATA)),
        "duplicate_count": population_status_counts[DUPLICATE_INPUT],
        "invalid_count": population_status_counts[INVALID_CANDIDATE],
        "missing_material_data_count": population_status_counts[MISSING_MATERIAL_DATA],
        "result_buckets": bucket_payload,
        "intent_result": {
            "matching_candidate_count": len(matching),
            "matching_candidate_ids": [item["candidate_id"] for item in matching],
            "contradicted_candidate_count": len(contradicted),
            "contradicted_candidate_ids": [item["candidate_id"] for item in contradicted],
            "unresolved_candidate_count": len(unresolved),
            "unresolved_candidate_ids": [item["candidate_id"] for item in unresolved],
            "not_applicable_count": len(not_applicable),
            "unsupported_count": len(unsupported),
            "premise_alignment_counts": dict(sorted(premise_counts.items())),
        },
        "aggregation": {
            "result_state_counts": {key: len(entries_by_state[key]) for key in BUCKET_ORDER},
            "premise_alignment_counts": dict(sorted(premise_counts.items())),
            "primary_reason_frequencies": [{"reason_code": key, "count": value} for key, value in ordered_reasons] if query.include_reason_frequencies else [],
            "source_location_frequencies": source_locations if query.include_source_location_frequencies else [],
            "completeness_distribution": dict(sorted(completeness_counts.items())),
            "evidence_classification_distribution": dict(sorted(evidence_counts.items())),
            "verification_status_distribution": dict(sorted(verification_counts.items())),
            "bypass_distribution": dict(sorted(bypass_counts.items())),
            "pre_execution_model_count": pre_execution_count,
            "child_case_failure_count": len(child_case_failures),
            "child_case_failures": child_case_failures,
        },
        "presentation": {
            "direct_aggregate_answer": direct,
            "bounded_scope_wording": scope["scope_statement"],
            "summary": f"{evaluated_count} candidates evaluated; {sum(len(entries_by_state[key]) for key in BUCKET_ORDER)} authoritative child results retained.",
            "matching_member_lines": [f"{entry['display_label']}: {entry['primary_reason']}" for entry in matching],
            "contradicted_member_lines": [f"{entry['display_label']}: {entry['primary_reason']}" for entry in contradicted],
            "unresolved_member_lines": [f"{entry['display_label']}: {entry['primary_reason']}" for entry in unresolved],
            "material_population_limitation": None if population.coverage_complete else scope["scope_statement"],
            "pre_execution_disclaimer": "Action results are pre-execution models only; no Discord operation was attempted." if query.target_kind == "ACTION" else None,
            "no_recommendations": True,
            "no_risk_scoring": True,
        },
        "population": {
            "owner_id": population.owner_id,
            "member_collection_status": population.member_collection_status,
            "population_fingerprint": population.population_fingerprint,
            "coverage_complete": population.coverage_complete,
            "candidate_dispositions": [item.as_dict() for item in population.dispositions],
        },
        "rules_version": ENUMERATION_RULES_VERSION,
        "canonical_aggregation_input": canonical_json(
            {
                "query_id": query.query_id,
                "population_fingerprint": population.population_fingerprint,
                "child_case_fingerprints": [entry.get("child_case_fingerprint") for state in BUCKET_ORDER for entry in entries_by_state[state]],
            }
        ),
    }


__all__ = [
    "BUCKET_ORDER",
    "ENUMERATION_CASE_CONTRACT_VERSION",
    "ENUMERATION_GOLDEN_VERSION",
    "ENUMERATION_RULES_VERSION",
    "LOCATION_ORDER",
    "aggregate_enumeration",
]
