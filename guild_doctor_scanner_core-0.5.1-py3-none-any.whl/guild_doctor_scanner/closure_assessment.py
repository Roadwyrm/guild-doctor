"""Formal, read-only Stage 3 closure assessment.

This module evaluates already-produced evidence.  It never contacts Discord and
never treats a modeled action result or a generic evidence classification as
proof that a Discord operation occurred.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any


CLOSURE_ASSESSMENT_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE3-CLOSURE-0.1"
_REQUIRED_LIVE_TARGET_TYPES = ("MEMBER", "ROLE", "CHANNEL")
_GENERIC_CLASSIFICATIONS = {"NEEDS_LIVE_TEST", "NEEDS_WRITE_VERIFICATION"}
_PASS_VERSION_KEYS = (
    "pass1_contract_version",
    "pass2_contract_version",
    "pass3_contract_version",
    "pass4_contract_version",
    "pass5_contract_version",
    "pass6_contract_version",
)


def _text(value: Any) -> str:
    return str(value).strip() if value is not None else ""


def _scenario_value(scenario: Any, key: str, default: Any = None) -> Any:
    if isinstance(scenario, Mapping):
        return scenario.get(key, default)
    return getattr(scenario, key, default)


def _scenario_record(scenario: Any) -> dict[str, Any]:
    return {
        "scenario_id": _text(_scenario_value(scenario, "scenario_id")),
        "operation_key": _text(_scenario_value(scenario, "operation_key")),
        "target_type": _text(_scenario_value(scenario, "target_type")).upper(),
        "target_id": _scenario_value(scenario, "target_id"),
        "context_id": _scenario_value(scenario, "context_id"),
        "expected_evidence_classifications": tuple(
            _text(item).upper()
            for item in (_scenario_value(scenario, "expected_evidence_classifications", ()) or ())
        ),
    }


def _blocker(
    *,
    blocker_id: str,
    reason_code: str,
    detail: str,
    safe_next_action: str,
    scenario: Mapping[str, Any] | None = None,
    required_evidence: Sequence[str] = (),
    source: str,
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "blocker_id": blocker_id,
        "reason_code": reason_code,
        "detail": detail,
        "required_evidence": list(required_evidence),
        "safe_next_action": safe_next_action,
        "source": source,
    }
    if scenario is not None:
        result.update({
            "scenario_id": scenario.get("scenario_id") or None,
            "operation_key": scenario.get("operation_key") or None,
            "target_type": scenario.get("target_type") or None,
            "target_id": scenario.get("target_id"),
            "context_id": scenario.get("context_id"),
        })
    return result


def _scenario_index(scenarios: Sequence[Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for scenario in scenarios:
        record = _scenario_record(scenario)
        if record["scenario_id"]:
            result[record["scenario_id"]] = record
    return result


def _readiness_index(report: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    readiness = report.get("readiness_preflight")
    if not isinstance(readiness, Mapping):
        return {}
    return {
        _text(item.get("scenario_id")): item
        for item in (readiness.get("scenarios") or ())
        if isinstance(item, Mapping) and _text(item.get("scenario_id"))
    }


def _item_is_concrete(item: Mapping[str, Any]) -> bool:
    if item.get("blocking") is False:
        return False
    identity = any(_text(item.get(key)) for key in ("scenario_id", "operation_key", "target_type", "affected_rule"))
    requirement = any(
        bool(item.get(key))
        for key in ("reason_codes", "reasons", "required_evidence", "missing_required_evidence", "safe_next_action", "detail", "code")
    )
    return identity and requirement


def _accepted_limitation(code: str, detail: str, *, scenarios: Sequence[str] = ()) -> dict[str, Any]:
    return {
        "classification": "ACCEPTED_READ_ONLY_BOUNDARY",
        "code": code,
        "detail": detail,
        "scenario_ids": list(scenarios),
        "blocking": False,
    }


def assess_stage3_closure(
    *,
    authority_report: Mapping[str, Any],
    verification_backlog: Mapping[str, Any],
    action_results: Sequence[Mapping[str, Any]],
    scenarios: Sequence[Any] = (),
    live_snapshot: Mapping[str, Any] | None = None,
    repeated_snapshot: Mapping[str, Any] | None = None,
    transport_audit: Mapping[str, Any] | None = None,
    pass7_started: bool = False,
) -> dict[str, Any]:
    """Assess closure using evidence already in memory or on disk.

    Only concrete missing evidence can create a blocker.  Generic
    ``NEEDS_LIVE_TEST`` and ``NEEDS_WRITE_VERIFICATION`` classifications are
    retained as non-blocking boundary limitations unless a concrete evidence
    record identifies what is missing and why it is required.
    """

    scenario_map = _scenario_index(scenarios)
    readiness_map = _readiness_index(authority_report)
    blockers: list[dict[str, Any]] = []
    accepted: list[dict[str, Any]] = []
    successful: list[dict[str, Any]] = []

    def add_success(code: str, detail: str) -> None:
        successful.append({"code": code, "detail": detail})

    def add_blocker(item: dict[str, Any]) -> None:
        if not any(existing["blocker_id"] == item["blocker_id"] for existing in blockers):
            blockers.append(item)

    if authority_report.get("live_execution") is True:
        add_success("LIVE_EXECUTION", "Live GET-only acquisition completed.")
    else:
        add_blocker(_blocker(
            blocker_id="LIVE_EXECUTION_MISSING",
            reason_code="LIVE_EXECUTION_MISSING",
            detail="The closure evidence does not establish that the approved live acquisition ran.",
            required_evidence=("live_execution=true",),
            safe_next_action="Run the authorized GET-only live verifier with the disposable guild.",
            source="authority_verification_report.live_execution",
        ))

    readiness = authority_report.get("readiness_preflight")
    if isinstance(readiness, Mapping) and readiness.get("outcome") == "READY":
        add_success("READINESS_READY", "All requested live scenario inputs were present and structurally compatible.")
    else:
        reason = "The readiness preflight did not report READY."
        if isinstance(readiness, Mapping) and readiness.get("reasons"):
            reason = "Readiness reasons: " + ", ".join(_text(item) for item in readiness["reasons"])
        add_blocker(_blocker(
            blocker_id="READINESS_NOT_READY",
            reason_code="READINESS_NOT_READY",
            detail=reason,
            required_evidence=("readiness_preflight.outcome=READY",),
            safe_next_action="Resolve the named live object or member evidence gap within the approved GET-only boundary.",
            source="authority_verification_report.readiness_preflight",
        ))

    for scenario_id, scenario in scenario_map.items():
        observed = readiness_map.get(scenario_id)
        if observed is None:
            add_blocker(_blocker(
                blocker_id=f"MISSING_SCENARIO_READINESS:{scenario_id}",
                reason_code="MISSING_REQUIRED_LIVE_SCENARIO_EVIDENCE",
                detail=f"No readiness record exists for scenario {scenario_id}.",
                scenario=scenario,
                required_evidence=("readiness_preflight.scenarios",),
                safe_next_action="Acquire the explicitly authorized actor, target, role, or context with a bounded GET.",
                source="authority_verification_report.readiness_preflight.scenarios",
            ))
        elif observed.get("ready") is not True:
            checks = observed.get("checks") or observed.get("fact_mismatches") or ["scenario_not_ready"]
            add_blocker(_blocker(
                blocker_id=f"SCENARIO_NOT_READY:{scenario_id}",
                reason_code="MISSING_REQUIRED_LIVE_SCENARIO_EVIDENCE",
                detail=f"Scenario {scenario_id} is not ready: {checks}.",
                scenario=scenario,
                required_evidence=tuple(_text(item) for item in checks),
                safe_next_action="Resolve the exact scenario readiness checks using approved GET-only acquisition.",
                source="authority_verification_report.readiness_preflight.scenarios",
            ))

    target_types_present = {scenario.get("target_type") for scenario in scenario_map.values()}
    for target_type in _REQUIRED_LIVE_TARGET_TYPES:
        if target_type not in target_types_present:
            add_blocker(_blocker(
                blocker_id=f"LIVE_COVERAGE_MISSING:{target_type}",
                reason_code="MISSING_REQUIRED_LIVE_COVERAGE",
                detail=f"Meaningful live {target_type} coverage is not represented in the scenario manifest.",
                scenario={"scenario_id": None, "operation_key": None, "target_type": target_type, "target_id": None, "context_id": None},
                required_evidence=(f"scenario target_type={target_type}",),
                safe_next_action=f"Add one safe GET-only scenario covering a real {target_type} before closure.",
                source="scenario_manifest",
            ))
        else:
            add_success(f"LIVE_COVERAGE_{target_type}", f"Live {target_type} coverage is represented and ready.")

    repeated = authority_report.get("repeated_acquisition")
    repeated_status = repeated.get("status") if isinstance(repeated, Mapping) else None
    if repeated_status == "STABLE":
        add_success("REPEATED_ACQUISITION_STABLE", "Repeated live structure and member fingerprints are stable.")
    else:
        add_blocker(_blocker(
            blocker_id="REPEATED_ACQUISITION_NOT_STABLE",
            reason_code="REPEATED_ACQUISITION_NOT_STABLE",
            detail=f"Repeated acquisition status is {repeated_status or 'missing'}, not STABLE.",
            required_evidence=("repeated_acquisition.status=STABLE",),
            safe_next_action="Repeat the bounded GET-only acquisition and resolve the reported drift or incompleteness.",
            source="authority_verification_report.repeated_acquisition",
        ))

    determinism = authority_report.get("determinism")
    determinism_status = determinism.get("status") if isinstance(determinism, Mapping) else None
    if determinism_status == "STABLE":
        add_success("MODELED_RESULT_DETERMINISM_STABLE", "Repeated pre-execution modeled outputs are deterministic.")
    else:
        add_blocker(_blocker(
            blocker_id="MODELED_RESULT_NOT_DETERMINISTIC",
            reason_code="MODELED_RESULT_NOT_DETERMINISTIC",
            detail=f"Modeled-result determinism status is {determinism_status or 'missing'}, not STABLE.",
            required_evidence=("determinism.status=STABLE",),
            safe_next_action="Resolve the deterministic model drift before closure.",
            source="authority_verification_report.determinism",
        ))

    model_errors = authority_report.get("model_errors") or []
    for error in model_errors:
        if isinstance(error, Mapping):
            scenario = scenario_map.get(_text(error.get("scenario_id")))
            add_blocker(_blocker(
                blocker_id=f"MODEL_ERROR:{_text(error.get('scenario_id'))}:{_text(error.get('code'))}",
                reason_code=_text(error.get("code")) or "MODEL_ERROR",
                detail=_text(error.get("message")) or "A modeled scenario failed.",
                scenario=scenario,
                required_evidence=("action_results",),
                safe_next_action="Resolve the named model or input error without adding a Discord write operation.",
                source="authority_verification_report.model_errors",
            ))
    if not model_errors:
        add_success("NO_MODEL_ERRORS", "No scenario model errors were reported.")

    mismatches = authority_report.get("expected_result_mismatches") or []
    for mismatch in mismatches:
        if isinstance(mismatch, Mapping):
            scenario = scenario_map.get(_text(mismatch.get("scenario_id")))
            add_blocker(_blocker(
                blocker_id=f"EXPECTED_RESULT_MISMATCH:{_text(mismatch.get('scenario_id'))}",
                reason_code="EXPECTED_RESULT_MISMATCH",
                detail=f"Expected {mismatch.get('expected')} but observed {mismatch.get('observed')}.",
                scenario=scenario,
                required_evidence=("expected_modeled_result", "final_result"),
                safe_next_action="Resolve the frozen expected-result mismatch before closure.",
                source="authority_verification_report.expected_result_mismatches",
            ))
    if not mismatches:
        add_success("NO_EXPECTED_RESULT_MISMATCHES", "No frozen expected modeled-result mismatch was reported.")

    for raw_item in verification_backlog.get("items", ()) if isinstance(verification_backlog, Mapping) else ():
        if isinstance(raw_item, Mapping) and _item_is_concrete(raw_item):
            scenario = scenario_map.get(_text(raw_item.get("scenario_id")))
            add_blocker(_blocker(
                blocker_id=_text(raw_item.get("blocker_id")) or f"BACKLOG:{_text(raw_item.get('scenario_id'))}:{_text(raw_item.get('code'))}",
                reason_code=_text(raw_item.get("reason_code")) or _text(raw_item.get("code")) or "CONCRETE_LIVE_TEST_REQUIRED",
                detail=_text(raw_item.get("detail")) or _text(raw_item.get("reasons")) or "A concrete verification item remains unresolved.",
                scenario=scenario,
                required_evidence=tuple(_text(item) for item in (raw_item.get("required_evidence") or raw_item.get("missing_required_evidence") or ())),
                safe_next_action=_text(raw_item.get("safe_next_action")) or "Resolve the exact listed verification item within the approved boundary.",
                source="verification_backlog.items",
            ))

    for raw_item in verification_backlog.get("needs_live_test", ()) if isinstance(verification_backlog, Mapping) else ():
        if isinstance(raw_item, Mapping) and _item_is_concrete(raw_item):
            scenario = scenario_map.get(_text(raw_item.get("scenario_id")))
            add_blocker(_blocker(
                blocker_id=_text(raw_item.get("blocker_id")) or f"NEEDS_LIVE_TEST:{_text(raw_item.get('scenario_id'))}",
                reason_code=_text(raw_item.get("reason_code")) or "CONCRETE_LIVE_TEST_REQUIRED",
                detail=_text(raw_item.get("detail")) or "A concrete live-test requirement remains unresolved.",
                scenario=scenario,
                required_evidence=tuple(_text(item) for item in (raw_item.get("required_evidence") or ())),
                safe_next_action=_text(raw_item.get("safe_next_action")) or "Resolve the exact live-test requirement within the approved boundary.",
                source="verification_backlog.needs_live_test",
            ))

    audit = transport_audit or {}
    if isinstance(audit, Mapping):
        if audit.get("audit_status") == "PASS":
            add_success("READ_ONLY_TRANSPORT_AUDIT_PASS", "The recorded transport audit is GET-only.")
        else:
            add_blocker(_blocker(
                blocker_id="READ_ONLY_TRANSPORT_AUDIT_FAILED",
                reason_code="READ_ONLY_TRANSPORT_AUDIT_FAILED",
                detail="The transport audit is missing or not PASS.",
                required_evidence=("transport_audit.audit_status=PASS",),
                safe_next_action="Repair the transport boundary before any further live run.",
                source="transport_audit",
            ))
        if audit.get("discord_write_requests") == 0 and audit.get("non_get_attempted") is False:
            add_success("ZERO_DISCORD_WRITES", "The recorded Discord write count is zero and no non-GET was attempted.")
        else:
            add_blocker(_blocker(
                blocker_id="DISCORD_WRITE_BOUNDARY_VIOLATED",
                reason_code="DISCORD_WRITE_BOUNDARY_VIOLATED",
                detail="The transport evidence does not establish zero Discord writes.",
                required_evidence=("discord_write_requests=0", "non_get_attempted=false"),
                safe_next_action="Stop and review the read-only transport boundary.",
                source="transport_audit",
            ))

    pass_versions_complete = bool(action_results) and all(
        all(_text(item.get(key)) for key in _PASS_VERSION_KEYS)
        for item in action_results
    )
    if pass_versions_complete:
        add_success("PASSES_1_TO_6_IMPLEMENTED", "Action results carry the frozen Pass 1-6 contract chain.")
    else:
        add_blocker(_blocker(
            blocker_id="PASSES_1_TO_6_EVIDENCE_MISSING",
            reason_code="PASSES_1_TO_6_EVIDENCE_MISSING",
            detail="The evidence does not establish a complete Pass 1-6 implementation chain.",
            required_evidence=_PASS_VERSION_KEYS,
            safe_next_action="Complete the missing local Stage 3 implementation evidence before closure.",
            source="action_results",
        ))

    if pass7_started:
        add_blocker(_blocker(
            blocker_id="PASS7_STARTED",
            reason_code="PASS7_STARTED_OUT_OF_SCOPE",
            detail="Pass 7 work is present, but this closure is limited to Pass 6.",
            required_evidence=("Pass 7 absent",),
            safe_next_action="Remove the out-of-scope Pass 7 work and restore the frozen boundary.",
            source="scope_audit",
        ))
    else:
        add_success("PASS7_NOT_STARTED", "No Pass 7 implementation is part of this closure.")

    generic_live_scenarios: list[str] = []
    generic_write_scenarios: list[str] = []
    for scenario in scenario_map.values():
        if "NEEDS_LIVE_TEST" in scenario["expected_evidence_classifications"]:
            generic_live_scenarios.append(scenario["scenario_id"])
        if "NEEDS_WRITE_VERIFICATION" in scenario["expected_evidence_classifications"]:
            generic_write_scenarios.append(scenario["scenario_id"])
    if generic_live_scenarios:
        accepted.append(_accepted_limitation(
            "GENERIC_NEEDS_LIVE_TEST_CLASSIFICATION",
            "Generic NEEDS_LIVE_TEST classifications identify no concrete scenario, rule, object, required field, or safe read-only test and therefore do not block closure.",
            scenarios=sorted(generic_live_scenarios),
        ))
    if generic_write_scenarios:
        accepted.append(_accepted_limitation(
            "WRITE_VERIFICATION_OUTSIDE_READ_ONLY_BOUNDARY",
            "Mutation-endpoint success cannot be established by this GET-only verifier and is outside the frozen read-only closure boundary.",
            scenarios=sorted(generic_write_scenarios),
        ))

    observed_facts = [
        item.get("observed_facts", {})
        for item in readiness_map.values()
        if isinstance(item, Mapping) and isinstance(item.get("observed_facts"), Mapping)
    ]
    if any("mfa_observation" in facts for facts in observed_facts):
        accepted.append(_accepted_limitation(
            "HUMAN_MFA_NOT_OBSERVABLE",
            "Human-member MFA state is not observable through the reviewed GET-only transport.",
        ))
    if any(facts.get("voice_observation") == "UNAVAILABLE_FROM_REVIEWED_GETS" for facts in observed_facts):
        accepted.append(_accepted_limitation(
            "VOICE_STATE_NOT_OBSERVABLE",
            "Live voice state is unavailable through the reviewed GET-only transport.",
        ))

    execution_flags = authority_report.get("execution_flags") or {}
    if execution_flags.get("execution_attempted") is False and execution_flags.get("endpoint_success_verified") is False:
        accepted.append(_accepted_limitation(
            "PRE_EXECUTION_MODEL_ONLY",
            "Modeled results remain PRE_EXECUTION_MODEL only; no mutation endpoint was tested or claimed.",
        ))
    accepted.append(_accepted_limitation(
        "POST_ACQUISITION_STATE_CHANGE_NOT_TESTED",
        "State changes after read-only acquisition are outside this pre-execution closure.",
    ))

    thread_scenarios = [scenario for scenario in scenario_map.values() if scenario.get("target_type") == "THREAD"]
    snapshot_threads = live_snapshot.get("threads") if isinstance(live_snapshot, Mapping) else None
    if not thread_scenarios and (isinstance(snapshot_threads, Mapping) and not snapshot_threads):
        accepted.append(_accepted_limitation(
            "ACTIVE_THREAD_LIVE_COVERAGE_LIMITATION",
            "The verified guild has no useful active thread. Canonical Pass 4 synthetic/documented thread coverage plus live parent/channel verification satisfies the frozen scope; no mutation is required.",
        ))

    closure_checks = {
        "passes_1_to_6_implemented": pass_versions_complete,
        "meaningful_live_actor_target_role_channel": all(target in target_types_present for target in _REQUIRED_LIVE_TARGET_TYPES) and all(
            readiness_map.get(scenario["scenario_id"], {}).get("ready") is True
            for scenario in scenario_map.values()
            if scenario.get("target_type") in _REQUIRED_LIVE_TARGET_TYPES
        ),
        "readiness_ready": isinstance(readiness, Mapping) and readiness.get("outcome") == "READY",
        "repeated_acquisition_stable": repeated_status == "STABLE",
        "modeled_outputs_deterministic": determinism_status == "STABLE",
        "no_concrete_material_read_only_blocker": not blockers,
        "write_endpoint_gaps_outside_read_only_boundary": True,
        "uncertainty_visible_not_claimed_as_verified": True,
        "pass7_not_started": not pass7_started,
    }
    status = "PASS" if not blockers and all(closure_checks.values()) else "PENDING"
    decision = "STAGE3_COMPLETE" if status == "PASS" else "STAGE3_IN_PROGRESS_LIVE_VERIFICATION_PENDING"
    if status == "PASS":
        rationale = (
            "Closure passes: meaningful actor, target, role, and channel live coverage is READY; "
            "repeated acquisition is STABLE; modeled outputs are deterministic; the Pass 1-6 "
            "contract chain is present; and no concrete material read-only blocker remains. "
            "Generic classifications and approved write/MFA/voice/thread/state limitations are "
            "preserved as ACCEPTED_READ_ONLY_BOUNDARY. Results remain PRE_EXECUTION_MODEL only."
        )
    else:
        rationale = "Closure remains pending because one or more concrete material checks failed; see concrete_blockers and verification_backlog.items."

    concrete_needs_live = [item for item in blockers if item.get("reason_code", "").startswith("LIVE_") or "LIVE_TEST" in item.get("reason_code", "") or "SCENARIO" in item.get("reason_code", "")]
    concrete_needs_write = [item for item in blockers if "WRITE" in item.get("reason_code", "")]
    return {
        "contract": CLOSURE_ASSESSMENT_CONTRACT_VERSION,
        "decision": decision,
        "status": status,
        "successful_evidence": successful,
        "concrete_blockers": blockers,
        "accepted_read_only_limitations": accepted,
        "needs_live_test": concrete_needs_live,
        "needs_write_verification": concrete_needs_write,
        "closure_contract_checks": closure_checks,
        "rationale": rationale,
    }


def verification_backlog_from_assessment(assessment: Mapping[str, Any]) -> dict[str, Any]:
    """Return a structured backlog with no generic unidentified entries."""

    blockers = assessment.get("concrete_blockers") or []
    return {
        "contract": CLOSURE_ASSESSMENT_CONTRACT_VERSION,
        "items": list(blockers),
        "needs_live_test": list(assessment.get("needs_live_test") or []),
        "needs_write_verification": list(assessment.get("needs_write_verification") or []),
    }


__all__ = [
    "CLOSURE_ASSESSMENT_CONTRACT_VERSION",
    "assess_stage3_closure",
    "verification_backlog_from_assessment",
]
