"""Offline runtime provenance and fail-closed source-selection checks."""

from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import json
import sys
from pathlib import Path
from typing import Any


PROVENANCE_CONTRACT = "GUILD-DOCTOR-STAGE5-RUNTIME-PROVENANCE-0.1"
REPAIRED_MARKERS = (
    "PSEUDONYMIZATION_UNMAPPED_OVERWRITE_TARGET",
    "PSEUDONYMIZATION_UNMAPPED_ROLE_REFERENCE",
    "CAPSULE_MFA_STATE_INVALID",
    "CurrentBaselineFailure",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _source_tree_fingerprint(root: Path) -> str:
    digest = hashlib.sha256()
    paths = [root / "pyproject.toml", root / "RUN_GUILD_DOCTOR_STAGE5_CURRENT_BASELINE.ps1"]
    paths.extend(sorted((root / "guild_doctor_scanner").rglob("*.py")))
    for path in paths:
        if path.is_file():
            relative = path.relative_to(root).as_posix().encode("utf-8")
            digest.update(relative + b"\0" + path.read_bytes() + b"\0")
    return digest.hexdigest()


def _package_copies(root: Path) -> list[str]:
    copies: set[str] = set()
    for path in root.rglob("guild_doctor_scanner"):
        if path.is_dir() and (path / "__init__.py").is_file():
            copies.add(path.resolve().relative_to(root.resolve()).as_posix())
    return sorted(copies)


def build_provenance(root: Path, runner_script: Path) -> dict[str, Any]:
    root = root.resolve()
    runner_script = runner_script.resolve()
    module_names = {
        "current_baseline_cli": "guild_doctor_scanner.current_baseline_cli",
        "baseline_pseudonymization": "guild_doctor_scanner.baseline_pseudonymization",
        "current_baseline_schema": "guild_doctor_scanner.current_baseline_schema",
        "get_only_acquisition": "guild_doctor_scanner.get_only_acquisition",
    }
    modules = {key: importlib.import_module(name) for key, name in module_names.items()}
    module_paths = {key: Path(module.__file__).resolve() for key, module in modules.items() if getattr(module, "__file__", None)}
    pseudo_source = module_paths["baseline_pseudonymization"].read_text(encoding="utf-8", errors="replace")
    schema_source = module_paths["current_baseline_schema"].read_text(encoding="utf-8", errors="replace")
    marker_results = {marker: marker in pseudo_source or marker in schema_source for marker in REPAIRED_MARKERS}
    from .current_baseline_schema import diagnostic_failure
    probe = diagnostic_failure(
        failure_stage="scenario_capsule_assembly", stable_error_code="CAPSULE_CHANNEL_MANAGE_INVALID",
        validation_rule="OFFLINE_RUNTIME_PROVENANCE_PROBE", object_type="CURRENT_BASELINE_CAPSULE",
        field_path="scenario.target_id", scenario_id="synthetic-provenance-probe",
        expected_shape="EXISTING_CHANNEL_REFERENCE", observed_value="invalid", cause=ValueError("synthetic probe"),
    ).diagnostic
    site_packages = [str(Path(path or ".").resolve()) for path in sys.path if "site-packages" in str(path).lower()]
    editable_files = []
    for site in site_packages:
        site_path = Path(site)
        if site_path.is_dir():
            editable_files.extend(path.name for path in site_path.glob("*.pth") if "editable" in path.name.lower())
    copies = _package_copies(root)
    module_inside = all(_inside(path, root) for path in module_paths.values())
    expected_python = root / ".venv" / "Scripts" / "python.exe"
    try:
        package_version = importlib.metadata.version("guild-doctor-scanner-core")
    except importlib.metadata.PackageNotFoundError:
        package_version = "UNKNOWN"
    return {
        "contract": PROVENANCE_CONTRACT,
        "python_executable": str(Path(sys.executable).resolve()),
        "expected_python_executable": str(expected_python.resolve()),
        "python_executable_matches_expected": Path(sys.executable).resolve() == expected_python.resolve(),
        "python_version": sys.version.split()[0],
        "current_working_directory": str(Path.cwd().resolve()),
        "project_root": str(root),
        "imported_package_root": str(Path(modules["current_baseline_cli"].__file__).resolve().parent),
        "imported_module_paths": {key: str(path) for key, path in module_paths.items()},
        "package_version": package_version,
        "source_tree_fingerprint": _source_tree_fingerprint(root),
        "pseudonymization_implementation_fingerprint": _sha256(module_paths["baseline_pseudonymization"]),
        "diagnostic_schema_fingerprint": _sha256(module_paths["current_baseline_schema"]),
        "runner_script_fingerprint": _sha256(runner_script) if runner_script.is_file() else None,
        "repaired_diagnostic_markers": marker_results,
        "synthetic_precise_failure_probe": {
            key: probe[key] for key in ("stable_error_code", "field_path", "scenario_id", "object_type", "raw_payload_retained", "token_redacted")
        },
        "editable_install_active": bool(editable_files),
        "editable_install_files": sorted(editable_files),
        "site_packages_used": any(_inside(path, Path(item)) for path in module_paths.values() for item in site_packages),
        "build_lib_used": any("build\\lib" in str(path).lower() or "build/lib" in str(path).lower() for path in module_paths.values()),
        "multiple_package_copies_discoverable": len(copies) > 1,
        "discoverable_package_copies": copies,
        "modules_inside_authoritative_checkout": module_inside,
        "sys_path_authoritative_first": bool(sys.path) and (sys.path[0] in ("", str(root))),
        "network_contacted": False,
        "discord_contacted": False,
        "discord_write_requests": 0,
        "token_redacted": True,
        "raw_payload_retained": False,
    }


def validate_provenance(report: dict[str, Any], checkpoint: dict[str, Any] | None = None) -> list[str]:
    errors: list[str] = []
    if not report.get("python_executable_matches_expected"):
        errors.append("RUNTIME_PROVENANCE_FAILED:PYTHON_EXECUTABLE")
    if not report.get("modules_inside_authoritative_checkout"):
        errors.append("RUNTIME_PROVENANCE_FAILED:MODULE_OUTSIDE_CHECKOUT")
    if not all(report.get("repaired_diagnostic_markers", {}).values()):
        errors.append("STALE_RUNTIME:REPAIRED_DIAGNOSTICS_MISSING")
    probe = report.get("synthetic_precise_failure_probe", {})
    if not probe.get("stable_error_code") or probe.get("stable_error_code") == "BASELINE_PSEUDONYMIZATION_FAILED" or not probe.get("field_path") or not probe.get("scenario_id"):
        errors.append("STALE_RUNTIME:PRECISE_DIAGNOSTIC_PROBE_FAILED")
    if report.get("build_lib_used") or report.get("site_packages_used"):
        errors.append("STALE_RUNTIME:NON_SOURCE_MODULE_PRECEDENCE")
    if checkpoint:
        for key in ("source_tree_fingerprint", "pseudonymization_implementation_fingerprint", "diagnostic_schema_fingerprint", "runner_script_fingerprint"):
            if checkpoint.get(key) != report.get(key):
                errors.append(f"STALE_RUNTIME:CHECKPOINT_MISMATCH:{key}")
    return sorted(set(errors))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")


__all__ = ["PROVENANCE_CONTRACT", "build_provenance", "validate_provenance", "write_json"]
