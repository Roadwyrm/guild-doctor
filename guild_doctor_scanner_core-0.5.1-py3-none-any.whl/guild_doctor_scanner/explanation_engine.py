"""Pure deterministic rendering of frozen Stage 3 results.

This module is deliberately downstream-only.  It reads Stage 3 result fields
and trace events, applies immutable explanation metadata, and renders wording.
It never calls a Stage 3 evaluator and has no Discord, network, persistence,
command, or AI dependency.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping, Sequence
from typing import Any

from .canonical import canonical_json
from .explanation_registry import (
    EXPLANATION_RULES_BY_ID,
    FROZEN_STAGE3_CONTRACTS,
    ExplanationRule,
    validate_explanation_registry,
)
from .explanation_schema import (
    EXPLANATION_RULES_VERSION,
    EXPLANATION_SCHEMA_VERSION,
    STAGE4_PASS1_CONTRACT_VERSION,
    ExplanationInputError,
    ExplanationOutput,
    ExplanationRequest,
    RESULT_FAMILIES,
)


_MISSING = object()
_RESULT_STATES = frozenset(
    {
        "ALLOWED",
        "DENIED",
        "UNKNOWN",
        "INEFFECTIVE",
        "NOT_APPLICABLE",
        "UNSUPPORTED",
        "POLICY_ONLY",
        "COMPLETE",
        "PARTIAL",
    }
)
_CONTROLLING_TRACE_STAGES = frozenset(
    {
        "FINAL_RESULT",
        "RESULT_FINALIZED",
        "FINAL_PRECEDENCE",
        "THREAD_VIEW_RESULT",
        "THREAD_SEND_RESULT",
        "COMPLETENESS",
    }
)
_STATE_PRIORITY = {
    "DENIED": 1,
    "INEFFECTIVE": 2,
    "UNKNOWN": 3,
    "UNSUPPORTED": 4,
    "NOT_APPLICABLE": 5,
    "POLICY_ONLY": 6,
    "ALLOWED": 7,
    "COMPLETE": 8,
    "PARTIAL": 9,
}
_TRACE_RULE_MAP = {
    "EVERYONE_ROLE_RESOLVED": "GRANTED_BY_EVERYONE_ROLE",
    "CONTEXT_EVERYONE_DENY": "DENIED_BY_EVERYONE_OVERWRITE",
    "CONTEXT_EVERYONE_ALLOW": "ALLOWED_BY_EVERYONE_OVERWRITE",
    "CONTEXT_ROLE_DENY": "DENIED_BY_ROLE_OVERWRITE",
    "CONTEXT_ROLE_ALLOW": "ALLOWED_BY_ROLE_OVERWRITE",
    "CONTEXT_MEMBER_DENY": "DENIED_BY_MEMBER_OVERWRITE",
    "CONTEXT_MEMBER_ALLOW": "ALLOWED_BY_MEMBER_OVERWRITE",
    "PARENT_VISIBILITY": "THREAD_PARENT_NOT_VISIBLE",
    "MEMBERSHIP": "PRIVATE_THREAD_MEMBERSHIP_REQUIRED",
    "SEND_PERMISSION": "THREAD_SEND_PERMISSION_MISSING",
    "THREAD_SEND_RESULT": "THREAD_SEND_PERMISSION_MISSING",
    "ARCHIVED_STATE": "THREAD_ARCHIVED_AUTO_UNARCHIVE_PREDICTION",
    "LOCKED_STATE": "THREAD_LOCKED_RESTRICTION",
    "HIERARCHY": "HIERARCHY_TARGET_EQUAL_OR_HIGHER",
    "MANAGED_OBJECT": "MANAGED_ROLE_RESTRICTION",
    "PERMISSION_SUBSET": "PERMISSION_SUBSET_FAILED",
    "MFA": "MFA_REQUIRED_AND_MISSING",
    "UPSTREAM_TRUST": "REQUIRED_EVIDENCE_UNKNOWN",
    "MATERIAL_UNCERTAINTIES": "REQUIRED_EVIDENCE_UNKNOWN",
    "COMPLETENESS": "REQUIRED_EVIDENCE_UNKNOWN",
    "PROVENANCE": "PRE_EXECUTION_MODEL_ONLY",
}
_CODE_RULE_MAP = {
    "OWNER_BYPASS": "OWNER_BYPASS",
    "ADMINISTRATOR_BYPASS": "ADMINISTRATOR_BYPASS",
    "BYPASS_OWNER": "OWNER_BYPASS",
    "BYPASS_ADMINISTRATOR": "ADMINISTRATOR_BYPASS",
    "UNKNOWN_PERMISSION_BITS_PRESENT": "UNKNOWN_PERMISSION_BITS_PRESENT",
    "ARCHIVED_SEND_PREDICTS_AUTO_UNARCHIVE": "THREAD_ARCHIVED_AUTO_UNARCHIVE_PREDICTION",
    "MISSING_PRIVATE_THREAD_MEMBERSHIP": "PRIVATE_THREAD_MEMBERSHIP_REQUIRED",
    "THREAD_MEMBERSHIP_UNKNOWN_RULE": "PRIVATE_THREAD_MEMBERSHIP_REQUIRED",
    "THREAD_VIEW_RULE": "THREAD_PARENT_NOT_VISIBLE",
    "THREAD_SEND_PERMISSION_RULE": "THREAD_SEND_PERMISSION_MISSING",
    "THREAD_LOCK_RULE": "THREAD_LOCKED_RESTRICTION",
    "HIERARCHY_TARGET_EQUAL_OR_HIGHER": "HIERARCHY_TARGET_EQUAL_OR_HIGHER",
    "TARGET_OWNER_PROTECTED": "GUILD_OWNER_TARGET_PROTECTED",
    "TARGET_ADMINISTRATOR_PROTECTED": "ADMINISTRATOR_TIMEOUT_TARGET_PROTECTED",
    "MANAGED_ROLE_RESTRICTION": "MANAGED_ROLE_RESTRICTION",
    "PERMISSION_SUBSET_FAILED": "PERMISSION_SUBSET_FAILED",
    "MFA_REQUIRED_AND_MISSING": "MFA_REQUIRED_AND_MISSING",
    "OBJECT_PRECONDITION_FAILED": "OBJECT_PRECONDITION_FAILED",
    "ACTION-UNSUPPORTED-001": "OPERATION_UNSUPPORTED",
    "ACTION-NOT-APPLICABLE-001": "ACTION_NOT_APPLICABLE",
    "ACTION-EXECUTION-NOT-ATTEMPTED-001": "PRE_EXECUTION_MODEL_ONLY",
    "ACTION-UPSTREAM-INCOMPLETE-001": "REQUIRED_EVIDENCE_UNKNOWN",
}
_UNCERTAINTY_WORDS = (
    "UNKNOWN",
    "INCOMPLETE",
    "MISSING",
    "INVALID",
    "MISMATCH",
    "UNSUPPORTED",
    "NEEDS_",
    "NOT_REQUESTED",
    "NOT_OBSERVABLE",
    "LIMITATION",
    "SYNTHETIC",
    "DOCUMENTED_EXPECTATION",
    "CONTRACT",
    "HEALTH",
)
_BLOCKING_WORDS = (
    "DENIED",
    "FAILED",
    "BLOCKED",
    "RESTRICTED",
    "PROTECTED",
    "INEFFECTIVE",
    "FORBIDDEN",
)


def _read(value: Any, name: str, default: Any = _MISSING) -> Any:
    if isinstance(value, Mapping):
        return value.get(name, default)
    found = getattr(value, name, default)
    return found


def _as_mapping(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    as_dict = getattr(value, "as_dict", None)
    if callable(as_dict):
        value = as_dict()
    if isinstance(value, Mapping):
        return {str(key): _public_value(item, str(key)) for key, item in value.items() if str(key).lower() not in {"token", "authorization", "access_token"}}
    if hasattr(value, "__dict__"):
        return {str(key): _public_value(item, str(key)) for key, item in vars(value).items() if str(key).lower() not in {"token", "authorization", "access_token"}}
    return {}


def _public_value(value: Any, key: str = "") -> Any:
    if key.lower() in {"token", "authorization", "access_token"} or "discord_token" in key.lower():
        return None
    as_dict = getattr(value, "as_dict", None)
    if callable(as_dict):
        return _public_value(as_dict(), key)
    if isinstance(value, Mapping):
        return {
            str(k): _public_value(v, str(k))
            for k, v in sorted(value.items(), key=lambda item: str(item))
            if str(k).lower() not in {"token", "authorization", "access_token"} and "discord_token" not in str(k).lower()
        }
    if isinstance(value, (tuple, list)):
        return [_public_value(item, key) for item in value]
    if isinstance(value, set | frozenset):
        return [_public_value(item, key) for item in sorted(value, key=str)]
    return value


def _text(value: Any) -> str | None:
    return value.strip() if isinstance(value, str) and value.strip() else None


def _upper(value: Any) -> str | None:
    text = _text(value)
    return text.upper() if text else None


def _values(value: Any) -> tuple[Any, ...]:
    if value is None or value is _MISSING:
        return ()
    if isinstance(value, Mapping):
        return tuple(value.values())
    if isinstance(value, str):
        return (value,)
    if isinstance(value, Sequence) or isinstance(value, set | frozenset):
        return tuple(value)
    return (value,)


def _strings(value: Any) -> tuple[str, ...]:
    return tuple(sorted({str(item).strip() for item in _values(value) if str(item).strip()}))


def _id(value: Any) -> str | None:
    if value is None or value is _MISSING or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str):
        return value.strip() or None
    return None


def _decimal_snowflake(value: str | None) -> bool:
    return value is None or (value.isdecimal() and int(value) > 0)


def _trace_rows(request: ExplanationRequest, result: Mapping[str, Any]) -> tuple[dict[str, Any], ...]:
    source = request.trace if request.trace is not None else result.get("trace", ())
    rows: list[dict[str, Any]] = []
    for index, raw in enumerate(_values(source), start=1):
        row = _as_mapping(raw)
        details = row.get("details")
        if not isinstance(details, Mapping):
            details = {}
        stage = _upper(row.get("stage", row.get("code", details.get("stage")))) or "UNKNOWN_STAGE"
        sequence = row.get("sequence", details.get("sequence", index))
        try:
            sequence = int(sequence)
        except (TypeError, ValueError):
            sequence = index
        rule_id = _text(row.get("rule_id", details.get("rule_id")))
        component = _text(row.get("component", details.get("component", details.get("capability_key"))))
        new_state = _upper(
            row.get(
                "new_state",
                row.get(
                    "new_orchestration_state",
                    details.get("new_state", details.get("new", details.get("state", details.get("result")))),
                ),
            )
        )
        rows.append(
            {
                "trace_event_id": f"TRACE-{sequence:04d}",
                "sequence": sequence,
                "stage": stage,
                "code": _text(row.get("code")) or stage,
                "component": component,
                "new_state": new_state,
                "previous_state": _upper(row.get("previous_state", row.get("previous_orchestration_state", details.get("previous")))),
                "rule_id": rule_id,
                "verification": _upper(row.get("verification", details.get("verification"))),
                "evidence_source": _text(row.get("evidence_source", details.get("source"))),
                "details": _public_value(details),
            }
        )
    return tuple(sorted(rows, key=lambda item: (item["sequence"], item["stage"], item.get("rule_id") or "", canonical_json(item))))


def _trace_issues(rows: Sequence[Mapping[str, Any]]) -> list[str]:
    groups: dict[tuple[str, str, str], set[str]] = {}
    for row in rows:
        stage = str(row.get("stage", ""))
        if stage not in _CONTROLLING_TRACE_STAGES:
            continue
        key = (stage, str(row.get("component") or ""), str(row.get("rule_id") or ""))
        state = row.get("new_state")
        if state is not None:
            groups.setdefault(key, set()).add(str(state))
    return [
        "CONTRADICTORY_CONTROLLING_TRACE"
        for states in groups.values()
        if len(states) > 1
    ]


def _state(result: Mapping[str, Any], request: ExplanationRequest) -> tuple[str, str | None]:
    for key in ("result_state", "final_result", "permission_result", "state", "completeness_state", "analysis_completeness"):
        value = _upper(result.get(key))
        if value in _RESULT_STATES:
            return value, key
    value = _upper(request.completeness_state)
    return (value if value in _RESULT_STATES else "UNKNOWN"), None


def _identity(request: ExplanationRequest, result: Mapping[str, Any]) -> tuple[dict[str, str | None], list[str]]:
    supplied = {
        "guild_id": request.guild_id,
        "subject_id": request.subject_id or request.actor_id,
        "target_id": request.target_id,
        "context_id": request.context_id or request.thread_id,
    }
    source = {
        "guild_id": _id(result.get("guild_id")),
        "subject_id": _id(result.get("subject_id", result.get("actor_id"))),
        "target_id": _id(result.get("target_id")),
        "context_id": _id(result.get("context_id", result.get("thread_id"))),
    }
    output = {
        "guild_id": supplied["guild_id"] or source["guild_id"],
        "subject_id": supplied["subject_id"] or source["subject_id"],
        "actor_id": request.actor_id or _id(result.get("actor_id")),
        "target_id": supplied["target_id"] or source["target_id"],
        "context_id": supplied["context_id"] or source["context_id"],
        "thread_id": request.thread_id or _id(result.get("thread_id")),
    }
    issues: list[str] = []
    for key, value in supplied.items():
        if value is not None and source[key] is not None and value != source[key]:
            issues.append(f"{key.upper()}_MISMATCH")
        if value is not None and not _decimal_snowflake(value):
            issues.append(f"{key.upper()}_NOT_DECIMAL_SNOWFLAKE")
    for key, value in source.items():
        if value is not None and not _decimal_snowflake(value):
            issues.append(f"SOURCE_{key.upper()}_NOT_DECIMAL_SNOWFLAKE")
    return output, sorted(set(issues))


def _label(labels: Mapping[str, Any], kind: str, object_id: str | None, *, simple: bool) -> str:
    candidates = []
    if object_id:
        candidates.extend((object_id, f"{kind}:{object_id}"))
    candidates.append(kind)
    for candidate in candidates:
        value = labels.get(candidate)
        if isinstance(value, str) and value.strip():
            return sanitize_display_label(value, hide_ids=simple)
    if simple:
        return f"the selected {kind.replace('_', ' ')}"
    return f"{kind.replace('_', ' ')} {object_id}" if object_id else f"the selected {kind.replace('_', ' ')}"


def sanitize_display_label(value: Any, *, hide_ids: bool = False) -> str:
    """Escape markdown and neutralize Discord mention syntax in labels."""

    text = str(value) if value is not None else ""
    if hide_ids:
        text = re.sub(r"<@!?\s*\d+>", "[member mention]", text)
        text = re.sub(r"<@&\s*\d+>", "[role mention]", text)
        text = re.sub(r"<#\s*\d+>", "[channel mention]", text)
    else:
        text = re.sub(r"<@!?\s*\d+>", lambda match: "<\u200b" + match.group(0)[1:], text)
        text = re.sub(r"<@&\s*\d+>", lambda match: "<\u200b" + match.group(0)[1:], text)
        text = re.sub(r"<#\s*\d+>", lambda match: "<\u200b" + match.group(0)[1:], text)
    text = text.replace("@everyone", "@\u200beveryone").replace("@here", "@\u200bhere")
    text = text.replace("@", "@\u200b")
    return re.sub(r"([\\`*_~>|])", r"\\\1", text)


def _permission_label(result: Mapping[str, Any], labels: Mapping[str, Any], simple: bool) -> str:
    raw_values = tuple(_text(result.get(key)) for key in ("permission_name", "permission_flag", "capability_key", "source_permission_flag", "operation_key"))
    for key in ("permission", "capability", *(value or "" for value in raw_values)):
        value = labels.get(key)
        if isinstance(value, str) and value.strip():
            return sanitize_display_label(value, hide_ids=simple)
    for value in raw_values:
        if value:
            return sanitize_display_label(value, hide_ids=simple)
    return "This result" if not simple else "This permission"


def _rule_for_code(code: str, *, stage: str | None = None) -> str | None:
    if code in EXPLANATION_RULES_BY_ID:
        return code
    mapped = _CODE_RULE_MAP.get(code)
    if mapped:
        return mapped
    if stage and stage in _TRACE_RULE_MAP:
        return _TRACE_RULE_MAP[stage]
    return None


def _human_code(code: str) -> str:
    known = EXPLANATION_RULES_BY_ID.get(code)
    if known:
        return known.description
    text = code.replace("-", " ").replace("_", " ").lower()
    return text[:1].upper() + text[1:] + "."


def _code_kind(code: str) -> str:
    rule_id = _rule_for_code(code)
    if rule_id:
        return EXPLANATION_RULES_BY_ID[rule_id].reason_kind
    upper = code.upper()
    if any(word in upper for word in _UNCERTAINTY_WORDS):
        return "uncertainty"
    if any(word in upper for word in _BLOCKING_WORDS):
        return "blocking"
    return "supporting"


def _reason_inputs(result: Mapping[str, Any], rows: Sequence[Mapping[str, Any]]) -> tuple[str, ...]:
    values: list[str] = []
    for key in (
        "reason_codes",
        "blocking_rule_ids",
        "definitive_blockers",
        "material_uncertainties",
        "missing_components",
        "unsupported_evidence",
        "warnings",
    ):
        values.extend(_strings(result.get(key)))
    for key in ("missing_role_references", "invalid_role_references", "invalid_references"):
        if _values(result.get(key)):
            values.append(key.upper())
    for key in ("dependency_uncertainties",):
        for item in _values(result.get(key)):
            if isinstance(item, Mapping):
                values.extend(_strings(item.get("rule_id")))
    for row in rows:
        rule_id = _text(row.get("rule_id"))
        if rule_id:
            values.append(rule_id)
        code = _text(row.get("code"))
        if code:
            mapped = _rule_for_code(code, stage=_text(row.get("stage")))
            if mapped:
                values.append(mapped)
    return tuple(sorted(set(values)))


def _collect_source_rules(result: Mapping[str, Any], rows: Sequence[Mapping[str, Any]], reasons: Sequence[str]) -> tuple[str, ...]:
    values: set[str] = set()
    for code in reasons:
        mapped = _rule_for_code(code)
        if mapped:
            values.add(mapped)
    for row in rows:
        mapped = _rule_for_code(str(row.get("rule_id") or ""), stage=str(row.get("stage") or ""))
        if mapped:
            values.add(mapped)
    for key in ("component_evidence", "operation_object_preconditions"):
        for item in _values(result.get(key)):
            if isinstance(item, Mapping):
                mapped = _rule_for_code(str(item.get("rule_id") or ""))
                if mapped:
                    values.add(mapped)
    if _upper(result.get("bypass_state")) == "OWNER":
        values.add("OWNER_BYPASS")
    if _upper(result.get("bypass_state")) == "ADMINISTRATOR":
        values.add("ADMINISTRATOR_BYPASS")
    return tuple(sorted(values, key=lambda item: (EXPLANATION_RULES_BY_ID[item].priority, item)))


def _source_fingerprint(result: Mapping[str, Any]) -> str | None:
    for key in ("result_fingerprint", "source_result_fingerprint", "input_fingerprint"):
        value = _text(result.get(key))
        if value:
            return value
    if not result:
        return None
    payload = dict(result)
    if isinstance(payload.get("trace"), (list, tuple)):
        payload["trace"] = sorted(
            (_as_mapping(item) for item in payload["trace"]),
            key=lambda item: (
                int(item.get("sequence", 0)) if str(item.get("sequence", "0")).lstrip("-").isdigit() else 0,
                str(item.get("stage", item.get("code", ""))),
                str(item.get("rule_id", "")),
                canonical_json(_public_value(item)),
            ),
        )
    return hashlib.sha256(canonical_json(_public_value(payload)).encode("utf-8")).hexdigest()


def _records(result: Mapping[str, Any], *keys: str) -> tuple[Mapping[str, Any], ...]:
    records: list[Mapping[str, Any]] = []
    for key in keys:
        for item in _values(result.get(key)):
            if isinstance(item, Mapping):
                records.append(item)
            else:
                records.append(_as_mapping(item))
    return tuple(records)


def _family_evidence(
    family: str,
    result: Mapping[str, Any],
    rows: Sequence[Mapping[str, Any]],
    labels: Mapping[str, Any],
    *,
    simple: bool,
) -> tuple[list[str], list[str], list[str], list[str], list[str], list[str]]:
    sources: list[str] = []
    ignored: list[str] = []
    raw_effective: list[str] = []
    blockers: list[str] = []
    contributing: list[str] = []
    extra_uncertainties: list[str] = []

    if family == "GUILD_PERMISSION":
        if result.get("everyone_permission_decimal") is not None:
            sources.append("the @everyone role")
        for item in _records(result, "assigned_role_contributions"):
            role_id = _id(item.get("role_id"))
            label = _label(labels, "role", role_id, simple=simple)
            if item.get("included") is True:
                sources.append(label)
                contributing.append(f"{label} is recorded as an included role source.")
            else:
                ignored.append(f"{label} was not included because the source record reported {', '.join(_strings(item.get('reason_codes'))) or 'a source limitation'}.")
        raw_effective.append("The guild-level raw permission union is the authoritative Pass 1 output.")
        if result.get("unknown_permission_bits_decimal") not in (None, "0", 0):
            extra_uncertainties.append("Unknown permission bits remain unnamed; no capability name is assigned to them.")

    elif family == "CONTEXT_PERMISSION":
        everyone = result.get("everyone_overwrite_contribution")
        if isinstance(everyone, Mapping):
            if everyone.get("applied") is True:
                sources.append("the @everyone overwrite")
            else:
                ignored.append("The @everyone overwrite was present but not applied to this subject.")
        role_ids = [_id(item) for item in _values(result.get("applicable_role_overwrite_source_ids"))]
        if role_ids:
            sources.extend(_label(labels, "role", item, simple=simple) for item in role_ids)
        member = result.get("member_overwrite_contribution")
        if isinstance(member, Mapping):
            if member.get("applied") is True:
                sources.append("the member-specific overwrite")
            else:
                ignored.append("The member-specific overwrite was present but not applied to this subject.")
        if result.get("overwrites_bypassed") is True:
            ignored.append("Context overwrites were bypassed by the recorded Stage 3 bypass state.")
        raw_effective.append("Stored context overwrites are the raw Pass 2 evidence; the category is not described as an additional runtime layer beneath a child channel.")
        raw_effective.append("Combined role overwrites are explained as a merged source; role order is not treated as overwrite precedence.")
        for row in rows:
            stage = str(row.get("stage") or "")
            mapped = _TRACE_RULE_MAP.get(stage)
            if mapped in {"DENIED_BY_EVERYONE_OVERWRITE", "DENIED_BY_ROLE_OVERWRITE", "DENIED_BY_MEMBER_OVERWRITE"}:
                blockers.append(_human_code(mapped))
            elif mapped in {"ALLOWED_BY_EVERYONE_OVERWRITE", "ALLOWED_BY_ROLE_OVERWRITE", "ALLOWED_BY_MEMBER_OVERWRITE"}:
                contributing.append(_human_code(mapped))

    elif family == "CAPABILITY":
        effective = _records(result, "effective_capability_records", "effective_records")
        ineffective = _records(result, "ineffective_grant_records", "ineffective_records")
        denied = _records(result, "denied_capability_records", "denied_records")
        unknown = _records(result, "unknown_capability_records", "unknown_records")
        inapplicable = _records(result, "inapplicable_capability_records", "inapplicable_records", "policy_only_category_records")
        for item in effective:
            key = _text(item.get("capability_key")) or "the capability"
            sources.append(_text(item.get("source_bypass")) or _text(item.get("source_permission_flag")) or key)
        for item in ineffective + denied:
            key = _text(item.get("capability_key")) or "the capability"
            ineffective_reason = _strings(item.get("blocking_rule_ids")) or _strings(item.get("notes"))
            blockers.append(f"{key} is recorded as {str(item.get('final_result', 'DENIED')).upper()}" + (f" ({', '.join(ineffective_reason)})" if ineffective_reason else ""))
        for item in unknown:
            key = _text(item.get("capability_key")) or "the capability"
            extra_uncertainties.append(f"{key} remains UNKNOWN in the authoritative capability records.")
        for item in inapplicable:
            key = _text(item.get("capability_key")) or "the capability"
            ignored.append(f"{key} is recorded as inapplicable or policy-only in this context.")
        raw_effective.append("Configured/raw permission bits and effective capability records remain separate Stage 3 outputs.")
        if result.get("raw_context_permission_decimal") is not None:
            raw_effective.append(f"The recorded raw context permission is {result.get('raw_context_permission_decimal')}.")
        if result.get("unknown_context_permission_bits_decimal") not in (None, "0", 0):
            extra_uncertainties.append("Unknown permission bits remain unnamed; no capability name is assigned to them.")

    elif family == "THREAD":
        parent = _upper(result.get("parent_visibility_result"))
        membership = _upper(result.get("membership_gate_result"))
        send = _upper(result.get("final_thread_send_capability_result", result.get("thread_send_permission_result")))
        if parent in {"DENIED", "INEFFECTIVE"}:
            blockers.append(_human_code("THREAD_PARENT_NOT_VISIBLE"))
        if membership in {"DENIED", "UNKNOWN"}:
            blockers.append(_human_code("PRIVATE_THREAD_MEMBERSHIP_REQUIRED") if membership == "DENIED" else "Private-thread membership is unknown.")
        if send in {"DENIED", "INEFFECTIVE"}:
            blockers.append(_human_code("THREAD_SEND_PERMISSION_MISSING"))
        if result.get("auto_unarchive_on_send") is True:
            contributing.append(_human_code("THREAD_ARCHIVED_AUTO_UNARCHIVE_PREDICTION"))
        if result.get("locked_state") is True:
            blockers.append(_human_code("THREAD_LOCKED_RESTRICTION"))
        raw_effective.append("Thread visibility, history, and sending are separate recorded results; SEND_MESSAGES is not treated as a substitute for SEND_MESSAGES_IN_THREADS.")
        for item in _records(result, "blocked_or_ineffective_records"):
            blockers.extend(_strings(item.get("blocking_rule_ids")))
        for item in _records(result, "unknown_records"):
            extra_uncertainties.append(f"{_text(item.get('capability_key')) or 'A thread capability'} remains UNKNOWN.")
        classifications = set(_strings(result.get("evidence_classifications")))
        if "SYNTHETIC_THREAD" in classifications or "DOCUMENTED_EXPECTATION" in classifications:
            extra_uncertainties.append("Synthetic or documented thread evidence is not live Discord evidence.")

    elif family == "AUTHORITY":
        fields = (
            ("capability_permission", "the capability permission"),
            ("target_authority", "target authority"),
            ("hierarchy_result", "role hierarchy"),
            ("mfa_precondition", "the MFA precondition"),
            ("permission_subset_result", "the permission subset"),
            ("managed_object_precondition", "the managed-object precondition"),
            ("bot_installation_2fa_precondition", "the bot-installation MFA precondition"),
        )
        for field, name in fields:
            state = _upper(result.get(field))
            if state in {"DENIED", "FAILED", "INEFFECTIVE"}:
                blockers.append(f"{name} is recorded as {state}.")
            elif state == "UNKNOWN":
                extra_uncertainties.append(f"{name.capitalize()} is UNKNOWN.")
            elif state in {"ALLOWED", "SATISFIED"}:
                contributing.append(f"{name.capitalize()} is recorded as {state}.")
        for item in _records(result, "operation_object_preconditions"):
            state = _upper(item.get("result", item.get("result_state")))
            if state in {"DENIED", "FAILED", "INEFFECTIVE"}:
                blockers.append(_text(item.get("notes")) or "An operation object precondition is recorded as failed.")
        raw_effective.append("Authority components remain separate; the explanation does not combine or recalculate them.")
        if _upper(result.get("bypass_state")) == "ADMINISTRATOR" and result.get("hierarchy_result") is not None:
            raw_effective.append("Administrator bypass treatment does not bypass the separate role-hierarchy result.")
        if _upper(result.get("bypass_state")) == "OWNER" and result.get("managed_object_precondition") is not None:
            raw_effective.append("Owner treatment does not make a managed role editable.")

    elif family == "ACTION":
        blockers.extend(_strings(result.get("definitive_blockers")))
        extra_uncertainties.extend(_strings(result.get("material_uncertainties")))
        extra_uncertainties.extend(_strings(result.get("missing_components")))
        ignored.extend(_strings(result.get("inapplicable_components")))
        for item in _records(result, "component_evidence"):
            state = _upper(item.get("normalized_state", item.get("raw_state")))
            name = _text(item.get("name")) or "component"
            if state in {"DENIED", "FAILED", "INEFFECTIVE"}:
                blockers.append(f"{name} is recorded as {state}.")
            elif state in {"UNKNOWN", "UNSUPPORTED"}:
                extra_uncertainties.append(f"{name} is recorded as {state}.")
            elif state in {"ALLOWED", "SATISFIED"}:
                contributing.append(f"{name} is recorded as {state}.")
        raw_effective.append("The final action result is distinct from its upstream capability, thread, and authority components.")
        if result.get("decision_basis") == "PRE_EXECUTION_MODEL" or result.get("execution_attempted") is False or result.get("execution_guarantee") is False:
            extra_uncertainties.append(_human_code("PRE_EXECUTION_MODEL_ONLY"))

    return sources, ignored, raw_effective, blockers, contributing, extra_uncertainties


def _reason_lists(
    state: str,
    reasons: Sequence[str],
    family_blockers: Sequence[str],
    family_contributing: Sequence[str],
    family_uncertainties: Sequence[str],
    request_mismatch_issues: Sequence[str],
    trace_issues: Sequence[str],
) -> tuple[list[str], list[str], list[str], list[str], list[str]]:
    blocking: list[str] = list(family_blockers)
    contributing = list(family_contributing)
    uncertainty = list(family_uncertainties)
    bypass: list[str] = []
    unknown_codes: list[str] = []
    for code in reasons:
        if code in {"OWNER_BYPASS", "ADMINISTRATOR_BYPASS", "BYPASS_OWNER", "BYPASS_ADMINISTRATOR"}:
            bypass.append(_human_code(_CODE_RULE_MAP.get(code, code)))
            continue
        kind = _code_kind(code)
        rendered = _human_code(code)
        if kind == "blocking":
            blocking.append(rendered)
        elif kind in {"uncertainty", "limitation"}:
            uncertainty.append(rendered)
        else:
            contributing.append(rendered)
        if code.startswith("UNKNOWN_REASON") or code.startswith("FAKE_") or code.startswith("NOT_A_"):
            unknown_codes.append(code)
    uncertainty.extend(request_mismatch_issues)
    uncertainty.extend(trace_issues)
    if any(item.endswith("_MISMATCH") for item in request_mismatch_issues):
        if any(item == "RESULT_FAMILY_MISMATCH" for item in request_mismatch_issues):
            uncertainty.append("The requested result family does not match the family recorded in the Stage 3 result.")
        else:
            uncertainty.append("The caller identity does not match the identity recorded in the Stage 3 result.")
    if trace_issues:
        uncertainty.append("The controlling trace contains contradictory events; the explanation refuses to resolve the conflict.")
    if state == "UNKNOWN" and not uncertainty:
        uncertainty.append(_human_code("REQUIRED_EVIDENCE_UNKNOWN"))
    if state == "DENIED" and not blocking:
        blocking.append("The authoritative Stage 3 result is DENIED.")
    if state == "INEFFECTIVE" and not blocking:
        blocking.append("The authoritative Stage 3 result is INEFFECTIVE.")
    if state in {"NOT_APPLICABLE", "POLICY_ONLY"} and not uncertainty:
        contributing.append(f"The authoritative Stage 3 result is {state}.")
    if unknown_codes:
        uncertainty.append("An unrecognized reason code was preserved as unknown rather than assigned a meaning.")
    return (
        _dedupe(blocking),
        _dedupe(contributing),
        _dedupe(uncertainty),
        _dedupe(bypass),
        unknown_codes,
    )


def _dedupe(values: Sequence[str]) -> list[str]:
    return list(dict.fromkeys(str(item) for item in values if str(item).strip()))


def _primary_reason(
    state: str,
    blocking: Sequence[str],
    uncertainty: Sequence[str],
    bypass: Sequence[str],
    contributing: Sequence[str],
) -> str:
    if state in {"UNKNOWN", "PARTIAL"} and uncertainty:
        return str(uncertainty[0])
    if state in {"DENIED", "INEFFECTIVE"} and blocking:
        return str(blocking[0])
    if bypass:
        return str(bypass[0])
    if contributing:
        return str(contributing[0])
    if state == "ALLOWED":
        return "The authoritative Stage 3 result is ALLOWED."
    if state == "NOT_APPLICABLE":
        return "The authoritative Stage 3 result is NOT_APPLICABLE."
    if state == "UNSUPPORTED":
        return "The authoritative Stage 3 result is UNSUPPORTED."
    if state == "POLICY_ONLY":
        return "The authoritative Stage 3 result is POLICY_ONLY; no executable action is claimed."
    if state == "COMPLETE":
        return "The authoritative Stage 3 evidence is COMPLETE."
    return f"The authoritative Stage 3 result is {state}."


def _short_answer(state: str, label: str, primary: str, *, simple: bool) -> str:
    if state == "ALLOWED":
        return f"Yes. {label} is allowed in the recorded Stage 3 result." if not simple else f"Yes. {label} is allowed."
    if state == "DENIED":
        return f"No. {label} is denied in the recorded Stage 3 result." if not simple else f"No. {label} is denied."
    if state == "INEFFECTIVE":
        return f"No. {label} is configured but ineffective in the recorded context."
    if state == "UNKNOWN":
        return "I cannot determine this safely from the available Stage 3 evidence."
    if state == "UNSUPPORTED":
        return f"{label} is unsupported by the recorded action vocabulary."
    if state == "NOT_APPLICABLE":
        return f"{label} is not applicable to the recorded target or context."
    if state == "POLICY_ONLY":
        return f"{label} is policy-only evidence; no executable action is claimed."
    if state == "PARTIAL":
        return f"{label} has only partial Stage 3 evidence."
    return f"{label} is recorded as {state}."


def _confidence(result: Mapping[str, Any], request: ExplanationRequest, uncertainty: Sequence[str]) -> str:
    completeness = _upper(request.completeness_state or result.get("completeness_state", result.get("analysis_completeness"))) or "UNKNOWN"
    if completeness == "COMPLETE" and not uncertainty:
        statement = "The Stage 3 evidence is complete for this result."
    else:
        statement = f"The Stage 3 evidence is {completeness.lower()} and important uncertainty remains."
    statuses = _strings(request.verification_statuses) + _strings(result.get("verification_statuses"))
    if any(status not in {"VERIFIED", "COMPLETE"} for status in statuses):
        statement += " Verification status is not uniformly VERIFIED."
    classifications = set(request.evidence_classifications) | set(_strings(result.get("evidence_classifications")))
    if classifications.intersection({"SYNTHETIC_THREAD", "SYNTHETIC_EXPLANATION", "DOCUMENTED_EXPECTATION"}):
        statement += " Synthetic or documented evidence is not presented as live evidence."
    return statement


def _pre_execution(result_family: str, result: Mapping[str, Any], reasons: Sequence[str]) -> str | None:
    if result_family != "ACTION" and result.get("decision_basis") != "PRE_EXECUTION_MODEL":
        return None
    if result.get("execution_attempted") is False or result.get("execution_guarantee") is False or "PRE_EXECUTION_MODEL_ONLY" in reasons:
        return "This is a PRE_EXECUTION_MODEL. No Discord action was performed, and ALLOWED does not guarantee future endpoint success."
    return "This explanation describes a modeled result; it is not a claim that Discord executed an action."


def _technical_lines(
    result: Mapping[str, Any],
    identity: Mapping[str, str | None],
    rules: Sequence[str],
    trace_refs: Sequence[Mapping[str, Any]],
    request: ExplanationRequest,
    source_contracts: Mapping[str, str],
    registry_versions: Mapping[str, str],
) -> list[str]:
    lines = [
        f"Result family={request.result_family}; result_state={_upper(result.get('result_state', result.get('final_result', result.get('completeness_state')))) or 'UNKNOWN'}.",
        f"IDs: guild_id={identity.get('guild_id')}; subject_id={identity.get('subject_id')}; actor_id={identity.get('actor_id')}; target_id={identity.get('target_id')}; context_id={identity.get('context_id')}; thread_id={identity.get('thread_id')}.",
        f"Source rule IDs: {', '.join(rules) or 'none recorded'}.",
        f"Source contracts: {canonical_json(dict(source_contracts))}.",
        f"Registry versions: {canonical_json(dict(registry_versions))}.",
    ]
    if request.include_full_trace_in_technical:
        lines.insert(3, f"Trace references: {', '.join(str(item['trace_event_id']) for item in trace_refs) or 'none recorded'}.")
    else:
        lines.insert(3, "Trace references: withheld by the technical disclosure control.")
    technical_fields = sorted(
        key
        for key in result
        if key.endswith("_decimal") or key.endswith("_hex") or key in {"decision_basis", "execution_attempted", "execution_guarantee", "raw_permission_bits_unchanged"}
    )
    if technical_fields:
        lines.append("Recorded technical fields: " + "; ".join(f"{key}={result[key]}" for key in technical_fields) + ".")
    return lines


def render_explanation(request: ExplanationRequest | Mapping[str, Any]) -> ExplanationOutput:
    """Render one deterministic explanation without recalculating Stage 3."""

    request = request if isinstance(request, ExplanationRequest) else ExplanationRequest.from_mapping(request)
    result = _as_mapping(request.result)
    rows = _trace_rows(request, result)
    identity, identity_issues = _identity(request, result)
    state, state_source = _state(result, request)
    family_in_result = _upper(result.get("result_family", result.get("source_result_family")))
    family_issues = []
    if family_in_result and family_in_result != request.result_family:
        family_issues.append("RESULT_FAMILY_MISMATCH")
    trace_issues = _trace_issues(rows)
    reasons = list(_reason_inputs(result, rows))
    if state_source is None:
        reasons.append("RESULT_STATE_MISSING")
    if not result:
        reasons.append("RESULT_MISSING")
    if family_issues:
        reasons.extend(family_issues)
    reasons.extend(identity_issues)
    reasons.extend(trace_issues)
    bypass_state = _upper(result.get("bypass_state"))
    if bypass_state in {"OWNER", "ADMINISTRATOR"}:
        reasons.append(f"{bypass_state}_BYPASS")
    if not rows:
        reasons.append("TRACE_MISSING")
    if validate_explanation_registry():
        reasons.append("EXPLANATION_REGISTRY_INVALID")
    source_contracts = dict(request.source_stage3_contract_versions or {})
    if not source_contracts:
        source_contracts = {
            key: str(result[key])
            for key in (
                "engine_contract_version",
                "pass1_contract_version",
                "pass2_contract_version",
                "pass3_contract_version",
                "pass4_contract_version",
                "pass5_contract_version",
                "pass6_contract_version",
                "scanner_contract_version",
                "snapshot_schema_version",
            )
            if isinstance(result.get(key), str) and result.get(key)
        }
    registry_versions = dict(request.registry_versions or result.get("registry_versions", {}) or {})
    if not registry_versions:
        registry_versions = {
            key: str(result[key])
            for key in (
                "capability_registry_version",
                "thread_rules_version",
                "authority_rules_version",
                "object_preconditions_version",
                "mfa_rules_version",
                "action_rules_version",
                "action_golden_version",
            )
            if isinstance(result.get(key), str) and result.get(key)
        }
    permission_definition_version = request.permission_definition_version or _text(result.get("permission_definition_version"))
    if permission_definition_version is None:
        reasons.append("PERMISSION_DEFINITION_VERSION_MISSING")

    labels = request.labels if isinstance(request.labels, Mapping) else {}
    simple = request.mode == "SIMPLE" and not request.include_ids_in_simple
    sources, ignored, raw_effective, family_blockers, family_contributing, family_uncertainties = _family_evidence(
        request.result_family, result, rows, labels, simple=simple
    )
    blocking, contributing, uncertainty, bypass, unknown_codes = _reason_lists(
        state,
        reasons,
        family_blockers,
        family_contributing,
        family_uncertainties,
        identity_issues + family_issues,
        trace_issues,
    )
    rules = _collect_source_rules(result, rows, reasons)
    permission_label = _permission_label(result, labels, simple)
    primary = _primary_reason(state, blocking, uncertainty, bypass, contributing)
    short = _short_answer(state, permission_label, primary, simple=simple)
    confidence = _confidence(result, request, uncertainty)
    disclaimer = _pre_execution(request.result_family, result, reasons)
    if state == "INEFFECTIVE":
        summary = f"{short} {primary}"
    elif state == "UNKNOWN":
        summary = f"{short} {primary}"
    else:
        summary = short
    source_fingerprint = _source_fingerprint(result)
    refs = tuple(
        sorted(
            set(request.source_references) | set(_strings(result.get("source_references"))) | set(_strings(result.get("source_refs")))),
        )
    statuses = tuple(sorted(set(request.verification_statuses) | set(_strings(result.get("verification_statuses")))))
    if not statuses:
        statuses = tuple(sorted({str(item.get("verification")) for item in rows if item.get("verification")}))

    if request.mode == "SIMPLE":
        support = []
        if sources:
            support.append("Recorded source: " + ", ".join(sources) + ".")
        support.extend(contributing)
        support.extend(blocking if state in {"DENIED", "INEFFECTIVE"} else uncertainty)
        lines = tuple([short, primary] + _dedupe(support)[:3])
    elif request.mode == "DETAILED":
        lines_list = [short, primary]
        if sources:
            lines_list.append("Recorded permission source: " + ", ".join(sources) + ".")
        lines_list.extend(raw_effective[:3])
        if request.include_raw_bits_in_detailed:
            raw_fields = sorted(
                key
                for key in result
                if key.endswith("_decimal") or key.endswith("_hex")
                if result.get(key) is not None
            )
            lines_list.extend(f"Recorded raw field {key}={result[key]}." for key in raw_fields[:8])
        lines_list.extend(bypass[:2])
        lines_list.extend(blocking[:2] if state in {"DENIED", "INEFFECTIVE"} else contributing[:2])
        lines_list.extend(uncertainty[:2])
        if disclaimer:
            lines_list.append(disclaimer)
        lines = tuple(_dedupe(lines_list))
    else:
        lines = tuple(
            _dedupe(
                [short, primary, confidence]
                + raw_effective
                + blocking
                + uncertainty
                + bypass
                + _technical_lines(result, identity, rules, rows, request, source_contracts, registry_versions)
                + ([disclaimer] if disclaimer else [])
            )
        )

    one_line = f"{short} {primary}".strip()
    sections = (
        {"section_id": "RESULT", "title": "Result", "lines": [short]},
        {"section_id": "REASON", "title": "Controlling reason", "lines": [primary]},
        {"section_id": "SUPPORTING_EVIDENCE", "title": "Supporting evidence", "lines": list(lines[2:])},
    )
    if disclaimer:
        sections += ({"section_id": "LIMITATION", "title": "Limitations", "lines": [disclaimer]},)

    output = ExplanationOutput(
        stage4_pass1_contract_version=STAGE4_PASS1_CONTRACT_VERSION,
        explanation_schema_version=EXPLANATION_SCHEMA_VERSION,
        explanation_rules_version=EXPLANATION_RULES_VERSION,
        source_stage3_contract_versions=source_contracts,
        permission_definition_version=permission_definition_version,
        registry_versions=registry_versions,
        result_family=request.result_family,
        explanation_mode=request.mode,
        guild_id=identity["guild_id"],
        subject_id=identity["subject_id"],
        actor_id=identity["actor_id"],
        target_id=identity["target_id"],
        context_id=identity["context_id"],
        thread_id=identity["thread_id"],
        result_state=state,
        short_answer=short,
        summary=summary,
        confidence_or_completeness_statement=confidence,
        pre_execution_disclaimer=disclaimer,
        primary_reason=primary,
        contributing_reasons=tuple(contributing),
        blocking_reasons=tuple(blocking),
        uncertainty_reasons=tuple(uncertainty),
        bypass_reasons=tuple(bypass),
        ineffective_grants=tuple(family_blockers),
        applicable_permission_sources=tuple(_dedupe(sources)),
        ignored_or_inapplicable_sources=tuple(_dedupe(ignored)),
        raw_vs_effective=tuple(_dedupe(raw_effective)),
        trace_references=tuple(dict(item) for item in rows),
        source_rule_ids=rules,
        verification_statuses=statuses,
        source_result_fingerprint=source_fingerprint,
        source_references=refs,
        ordered_sections=tuple(sections),
        ordered_explanation_lines=lines,
        one_line=one_line,
        explanation_fingerprint="",
    )
    payload = output.as_dict()
    payload.pop("explanation_fingerprint", None)
    payload.get("technical_provenance", {}).pop("explanation_fingerprint", None)
    fingerprint = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
    return ExplanationOutput(**{**output.__dict__, "explanation_fingerprint": fingerprint}) if hasattr(output, "__dict__") else _replace_output(output, fingerprint)


def _replace_output(output: ExplanationOutput, fingerprint: str) -> ExplanationOutput:
    from dataclasses import replace

    return replace(output, explanation_fingerprint=fingerprint)


def explain_result(request: ExplanationRequest | Mapping[str, Any]) -> ExplanationOutput:
    """Public alias emphasizing that the result is explanation-only."""

    return render_explanation(request)


def render_explanation_dict(request: ExplanationRequest | Mapping[str, Any]) -> dict[str, Any]:
    return render_explanation(request).as_dict()


__all__ = [
    "explain_result",
    "render_explanation",
    "render_explanation_dict",
    "sanitize_display_label",
]
