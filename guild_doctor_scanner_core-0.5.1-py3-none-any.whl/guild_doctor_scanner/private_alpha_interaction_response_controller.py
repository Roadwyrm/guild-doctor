"""One-shot ephemeral response budget for the bounded private-alpha runtime."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


RESPONSE_CONTROLLER_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-INTERACTION-RESPONSE-CONTROLLER-0.1"


class ResponseBudgetError(RuntimeError):
    """Stable response-budget failure without payload disclosure."""


class EphemeralResponseTransport(Protocol):
    async def send_initial_ephemeral(self, content: str) -> None: ...
    async def defer_ephemeral(self) -> None: ...
    async def edit_original_ephemeral(self, content: str) -> None: ...


@dataclass(frozen=True, slots=True)
class ResponseBudgetSnapshot:
    state: str
    initial_response_count: int
    defer_count: int
    original_edit_count: int
    prohibited_attempt_count: int
    terminal: bool


class InteractionResponseController:
    """Retains only a narrow transport port and counters, never interaction identity."""

    def __init__(self, transport: EphemeralResponseTransport):
        self._transport = transport
        self._state = "NEW"
        self._initial = 0
        self._deferred = 0
        self._edited = 0
        self._prohibited = 0
        self._terminal = False

    def _require_active(self) -> None:
        if self._terminal:
            raise ResponseBudgetError("STAGE8_PASS4D_RESPONSE_AFTER_CLEANUP")

    async def send_initial(self, content: str, *, ephemeral: bool = True) -> None:
        self._require_active()
        if ephemeral is not True:
            self._prohibited += 1
            raise ResponseBudgetError("STAGE8_PASS4D_PUBLIC_RESPONSE_PROHIBITED")
        if self._state != "NEW":
            self._prohibited += 1
            raise ResponseBudgetError("STAGE8_PASS4D_SECOND_RESPONSE_PROHIBITED")
        await self._transport.send_initial_ephemeral(str(content))
        self._initial = 1
        self._state = "IMMEDIATE_COMPLETE"

    async def defer(self, *, ephemeral: bool = True) -> None:
        self._require_active()
        if ephemeral is not True:
            self._prohibited += 1
            raise ResponseBudgetError("STAGE8_PASS4D_PUBLIC_RESPONSE_PROHIBITED")
        if self._state != "NEW":
            self._prohibited += 1
            raise ResponseBudgetError("STAGE8_PASS4D_DEFER_SEQUENCE_INVALID")
        await self._transport.defer_ephemeral()
        self._deferred = 1
        self._state = "DEFERRED"

    async def edit_original(self, content: str) -> None:
        self._require_active()
        if self._state != "DEFERRED" or self._edited:
            self._prohibited += 1
            raise ResponseBudgetError("STAGE8_PASS4D_ORIGINAL_EDIT_BUDGET_EXCEEDED")
        await self._transport.edit_original_ephemeral(str(content))
        self._edited = 1
        self._state = "DEFERRED_COMPLETE"

    def prohibit(self, operation: str) -> None:
        self._require_active()
        self._prohibited += 1
        codes = {
            "FOLLOW_UP": "STAGE8_PASS4D_FOLLOW_UP_PROHIBITED",
            "DELETE": "STAGE8_PASS4D_RESPONSE_DELETE_PROHIBITED",
            "ATTACHMENT": "STAGE8_PASS4D_ATTACHMENT_PROHIBITED",
            "COMPONENT": "STAGE8_PASS4D_COMPONENT_PROHIBITED",
            "MODAL": "STAGE8_PASS4D_MODAL_PROHIBITED",
            "PUBLIC": "STAGE8_PASS4D_PUBLIC_RESPONSE_PROHIBITED",
            "CHANNEL_MESSAGE": "STAGE8_PASS4D_CHANNEL_MESSAGE_PROHIBITED",
        }
        raise ResponseBudgetError(codes.get(operation, "STAGE8_PASS4D_UNAUTHORIZED_RESPONSE_OPERATION"))

    def terminate(self) -> None:
        self._terminal = True
        self._transport = None

    @property
    def snapshot(self) -> ResponseBudgetSnapshot:
        return ResponseBudgetSnapshot(
            self._state, self._initial, self._deferred, self._edited,
            self._prohibited, self._terminal,
        )


__all__ = [
    "EphemeralResponseTransport", "InteractionResponseController",
    "RESPONSE_CONTROLLER_CONTRACT", "ResponseBudgetError", "ResponseBudgetSnapshot",
]
