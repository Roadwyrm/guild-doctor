"""Future acknowledgement plumbing is constrained by Pass 3 policy."""
from .discord_interaction_policy import acknowledgement_for,visibility_for
RUNTIME_ACKNOWLEDGEMENT_CONTRACT="GUILD-DOCTOR-DISCORD-RUNTIME-ACKNOWLEDGEMENT-0.1"
def plan_acknowledgement(*,authorized:bool,age:float,work:str)->dict:return {"acknowledgement":acknowledgement_for(authorized=authorized,interaction_age_seconds=age,estimated_work=work),"visibility":visibility_for(authorized=authorized,requested_visibility="PUBLIC",command_key="future")}
