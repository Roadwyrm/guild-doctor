"""Reviewed six-GET acquisition boundary for Stage 5 current baselines."""

from __future__ import annotations

import asyncio
import traceback
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Mapping

from .baseline_pseudonymization import build_current_baseline_capsules
from .current_baseline_schema import (
    CONFIRMATION_PHRASE,
    GET_ONLY_ACQUISITION_CONTRACT_VERSION,
    CurrentBaselineError,
    CurrentBaselineFailure,
    diagnostic_failure,
    validate_baseline_scenarios,
)
from .discordpy_adapter import DiscordPyReadTransport
from .scenario_manifest import LiveScenario


ROUTES = {
    "client.login": "/users/@me",
    "read_guild": "/guilds/{guild_id}",
    "read_roles": "/guilds/{guild_id}/roles",
    "read_channels": "/guilds/{guild_id}/channels",
    "read_member": "/guilds/{guild_id}/members/{member_id}",
    "read_active_threads": "/guilds/{guild_id}/threads/active",
}
FORBIDDEN_ROUTE_FRAGMENTS = ("messages", "audit-logs", "invites", "integrations", "webhooks", "bans", "commands")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def safe_error(exc: BaseException) -> dict[str, str]:
    status = getattr(exc, "status", None)
    if status == 401 or exc.__class__.__name__ == "LoginFailure":
        code = "AUTHENTICATION_FAILED"
    elif status == 403:
        code = "AUTHORIZATION_DENIED"
    elif isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        code = "NETWORK_TIMEOUT"
    elif status is not None:
        code = f"HTTP_{status}"
    else:
        code = "ACQUISITION_FAILED"
    return {"code": code, "error_type": type(exc).__name__, "message": code}


def _transport_failure(exc: BaseException, audit: Mapping[str, Any]) -> CurrentBaselineFailure:
    failure = safe_error(exc)
    return diagnostic_failure(
        failure_stage="transport",
        stable_error_code=failure["code"],
        validation_rule="ALLOWLISTED_GET_BOUNDED_TIMEOUT",
        object_type="TRANSPORT",
        cause=exc,
        transport_completed=False,
        transport_request_count=int(audit.get("get_request_count", 0)),
    )


def _post_transport_failure(exc: BaseException, audit: Mapping[str, Any]) -> CurrentBaselineFailure:
    """Classify failures after the allowlisted GETs without retaining payloads."""
    if isinstance(exc, CurrentBaselineFailure):
        return exc
    if isinstance(exc, (KeyError, TypeError, ValueError, AttributeError, IndexError, AssertionError)):
        internal_code = {
            KeyError: "PSEUDONYMIZATION_INTERNAL_KEY_ERROR",
            TypeError: "PSEUDONYMIZATION_INTERNAL_TYPE_ERROR",
            ValueError: "PSEUDONYMIZATION_INTERNAL_VALUE_ERROR",
            AttributeError: "PSEUDONYMIZATION_INTERNAL_ATTRIBUTE_ERROR",
            IndexError: "PSEUDONYMIZATION_INTERNAL_INDEX_ERROR",
            AssertionError: "PSEUDONYMIZATION_INTERNAL_ASSERTION_ERROR",
        }[type(exc)]
        frames = traceback.extract_tb(exc.__traceback__) if exc.__traceback__ else []
        function = frames[-1].name if frames else "unknown"
        return diagnostic_failure(
            failure_stage="pseudonymization", stable_error_code=internal_code,
            validation_rule=f"UNEXPECTED_EXCEPTION_IN_{function.upper()}",
            object_type="CURRENT_BASELINE_CAPSULE", field_path=f"phase.{function}",
            scenario_id=getattr(exc, "scenario_id", None), expected_shape="NO_UNEXPECTED_PYTHON_EXCEPTION",
            cause=exc, transport_completed=True,
            transport_request_count=int(audit.get("get_request_count", 0)),
        )
    message = str(exc).lower()
    if "credential" in message:
        code = "BASELINE_MINIMIZATION_FAILED"
        stage = "minimization"
        rule = "NO_CREDENTIAL_SHAPES_REACH_MINIMIZATION"
    elif "capsule" in message or "identifier" in message:
        code = "BASELINE_PSEUDONYMIZATION_FAILED"
        stage = "pseudonymization"
        rule = "PRIVACY_SAFE_SYNTHETIC_CAPSULE_VALIDATION"
    else:
        code = "BASELINE_PSEUDONYMIZATION_FAILED"
        stage = "pseudonymization"
        rule = "PRIVACY_SAFE_SYNTHETIC_CAPSULE_BUILD"
    return diagnostic_failure(
        failure_stage=stage,
        stable_error_code=code,
        validation_rule=rule,
        object_type="CURRENT_BASELINE_CAPSULE",
        field_path="capsule",
        expected_shape="PRIVACY_SAFE_SYNTHETIC_CAPSULE_SET",
        observed_value={},
        cause=exc,
        transport_completed=True,
        transport_request_count=int(audit.get("get_request_count", 0)),
    )


def _validate_acquired_objects(
    guild: Any,
    roles: Any,
    channels: Any,
    members: Any,
    scenarios: tuple[LiveScenario, ...],
    *,
    request_count: int,
    expected_guild_id: str | None = None,
) -> None:
    """Validate response shape and exact scenario relationships without retaining values."""

    if not isinstance(guild, Mapping):
        raise diagnostic_failure(
            failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_GUILD_INVALID",
            validation_rule="GUILD_RESPONSE_OBJECT", object_type="GUILD", field_path="guild",
            expected_shape="OBJECT", observed_value=guild, cause=TypeError("guild shape"), transport_request_count=request_count,
        )
    guild_id = str(guild.get("id", ""))
    if not guild_id.isdecimal() or int(guild_id) <= 0:
        raise diagnostic_failure(
            failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_GUILD_INVALID",
            validation_rule="GUILD_ID_DECIMAL_SNOWFLAKE", object_type="GUILD", field_path="guild.id",
            expected_shape="POSITIVE_DECIMAL_SNOWFLAKE", observed_value=guild.get("id"), cause=ValueError("guild id"), transport_request_count=request_count,
        )
    if expected_guild_id is not None and guild_id != str(expected_guild_id):
        raise diagnostic_failure(
            failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_GUILD_INVALID",
            validation_rule="GUILD_RESPONSE_ID_EQUALS_REQUESTED_GUILD", object_type="GUILD", field_path="guild.id",
            expected_shape="REQUESTED_GUILD_DECIMAL_SNOWFLAKE", observed_value=guild.get("id"),
            contradictory_fields=("requested_guild_id", "response_guild_id"), cause=ValueError("guild identity"),
            transport_request_count=request_count,
        )
    if not isinstance(roles, list):
        raise diagnostic_failure(
            failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_ROLE_RELATIONSHIP_INVALID",
            validation_rule="ROLES_RESPONSE_ARRAY", object_type="ROLE", field_path="roles",
            expected_shape="ARRAY", observed_value=roles, cause=TypeError("roles shape"), transport_request_count=request_count,
        )
    role_ids = set()
    for index, role in enumerate(roles):
        if not isinstance(role, Mapping) or not str(role.get("id", "")).isdecimal():
            raise diagnostic_failure(
                failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_ROLE_RELATIONSHIP_INVALID",
                validation_rule="ROLE_ID_DECIMAL_SNOWFLAKE", object_type="ROLE", field_path=f"roles[{index}].id",
                expected_shape="POSITIVE_DECIMAL_SNOWFLAKE", observed_value=role.get("id") if isinstance(role, Mapping) else role,
                cause=ValueError("role id"), transport_request_count=request_count,
            )
        role_ids.add(str(role["id"]))
    if guild_id not in role_ids:
        raise diagnostic_failure(
            failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_ROLE_RELATIONSHIP_INVALID",
            validation_rule="EVERYONE_ROLE_ID_EQUALS_GUILD_ID", object_type="ROLE", field_path="roles",
            expected_shape="ARRAY_CONTAINING_GUILD_EVERYONE_ROLE", observed_value=roles, cause=ValueError("everyone role"), transport_request_count=request_count,
        )
    if not isinstance(channels, list):
        raise diagnostic_failure(
            failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_TARGET_CHANNEL_NOT_FOUND",
            validation_rule="CHANNELS_RESPONSE_ARRAY", object_type="CHANNEL", field_path="channels",
            expected_shape="ARRAY", observed_value=channels, cause=TypeError("channels shape"), transport_request_count=request_count,
        )
    channel_ids = set()
    for index, channel in enumerate(channels):
        if not isinstance(channel, Mapping) or not str(channel.get("id", "")).isdecimal():
            raise diagnostic_failure(
                failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_TARGET_CHANNEL_NOT_FOUND",
                validation_rule="CHANNEL_ID_DECIMAL_SNOWFLAKE", object_type="CHANNEL", field_path=f"channels[{index}].id",
                expected_shape="POSITIVE_DECIMAL_SNOWFLAKE", observed_value=channel.get("id") if isinstance(channel, Mapping) else channel,
                cause=ValueError("channel id"), transport_request_count=request_count,
            )
        channel_ids.add(str(channel["id"]))
        parent = channel.get("parent_id")
        if parent is not None and not str(parent).isdecimal():
            raise diagnostic_failure(
                failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_PARENT_CONTEXT_INVALID",
                validation_rule="PARENT_ID_NULL_OR_DECIMAL_SNOWFLAKE", object_type="PARENT_CATEGORY", field_path=f"channels[{index}].parent_id",
                expected_shape="NULL_OR_POSITIVE_DECIMAL_SNOWFLAKE", observed_value=parent, cause=ValueError("parent id"), transport_request_count=request_count,
            )
        overwrites = channel.get("permission_overwrites", [])
        if not isinstance(overwrites, list):
            raise diagnostic_failure(
                failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_OVERWRITE_INVALID",
                validation_rule="OVERWRITES_RESPONSE_ARRAY", object_type="CHANNEL", field_path=f"channels[{index}].permission_overwrites",
                expected_shape="ARRAY", observed_value=overwrites, cause=TypeError("overwrite shape"), transport_request_count=request_count,
            )
        for overwrite_index, overwrite in enumerate(overwrites):
            if not isinstance(overwrite, Mapping) or not str(overwrite.get("id", "")).isdecimal() or overwrite.get("type") not in (0, 1, "0", "1", "role", "ROLE", "member", "MEMBER"):
                raise diagnostic_failure(
                    failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_OVERWRITE_INVALID",
                    validation_rule="OVERWRITE_ID_AND_NUMERIC_TYPE", object_type="CHANNEL", field_path=f"channels[{index}].permission_overwrites[{overwrite_index}]",
                    expected_shape="OBJECT_WITH_DECIMAL_ID_AND_ROLE_MEMBER_TYPE", observed_value=overwrite,
                    cause=ValueError("overwrite"), transport_request_count=request_count,
                )
    target_channel_ids = {item.target_id for item in scenarios if item.target_type == "CHANNEL" and item.target_id}
    required_parent_ids = {
        str(channel.get("parent_id"))
        for channel in channels
        if isinstance(channel, Mapping) and str(channel.get("id")) in target_channel_ids and channel.get("parent_id") is not None
    }
    missing_parents = sorted(required_parent_ids - channel_ids, key=int)
    if missing_parents:
        raise diagnostic_failure(
            failure_stage="acquired_object_validation", stable_error_code="ACQUISITION_PARENT_CONTEXT_INVALID",
            validation_rule="PARENT_CATEGORY_EXISTS_IN_CHANNEL_GET", object_type="PARENT_CATEGORY", field_path="channels.parent_id",
            expected_shape="NULL_OR_EXISTING_CATEGORY_REFERENCE", observed_value={},
            contradictory_fields=("channel_parent_id", "channel_id_set"), cause=LookupError("parent category"),
            transport_request_count=request_count,
        )
    if not isinstance(members, list):
        raise diagnostic_failure(
            failure_stage="actor_target_member_normalization", stable_error_code="ACQUISITION_ACTOR_MEMBER_INVALID",
            validation_rule="TARGETED_MEMBERS_RESPONSE_ARRAY", object_type="ACTOR_MEMBER", field_path="members",
            expected_shape="ARRAY", observed_value=members, cause=TypeError("members shape"), transport_request_count=request_count,
        )
    returned_members = set()
    for index, member in enumerate(members):
        user = member.get("user") if isinstance(member, Mapping) else None
        if not isinstance(user, Mapping) or not str(user.get("id", "")).isdecimal():
            raise diagnostic_failure(
                failure_stage="actor_target_member_normalization", stable_error_code="ACQUISITION_ACTOR_MEMBER_INVALID",
                validation_rule="MEMBER_USER_ID_DECIMAL_SNOWFLAKE", object_type="ACTOR_MEMBER", field_path=f"members[{index}].user.id",
                expected_shape="POSITIVE_DECIMAL_SNOWFLAKE", observed_value=user.get("id") if isinstance(user, Mapping) else user,
                cause=ValueError("member id"), transport_request_count=request_count,
            )
        returned_members.add(str(user["id"]))
        roles_for_member = member.get("roles", [])
        if not isinstance(roles_for_member, list) or any(not str(role_id).isdecimal() for role_id in roles_for_member):
            raise diagnostic_failure(
                failure_stage="actor_target_member_normalization", stable_error_code="ACQUISITION_ACTOR_MEMBER_INVALID",
                validation_rule="MEMBER_ROLE_IDS_DECIMAL_ARRAY", object_type="ACTOR_MEMBER", field_path=f"members[{index}].roles",
                expected_shape="ARRAY_OF_DECIMAL_SNOWFLAKES", observed_value=roles_for_member, cause=ValueError("member roles"), transport_request_count=request_count,
            )
        timeout = member.get("communication_disabled_until")
        if timeout is not None and not isinstance(timeout, str):
            raise diagnostic_failure(
                failure_stage="actor_target_member_normalization", stable_error_code="ACQUISITION_TARGET_MEMBER_INVALID",
                validation_rule="TIMEOUT_NULL_OR_RFC3339_STRING", object_type="TARGET_MEMBER", field_path=f"members[{index}].communication_disabled_until",
                expected_shape="NULL_OR_RFC3339_STRING", observed_value=timeout, cause=ValueError("timeout"), transport_request_count=request_count,
            )
    required_member_ids = {item.actor_member_id for item in scenarios} | {item.target_id for item in scenarios if item.target_type == "MEMBER" and item.target_id}
    if not required_member_ids.issubset(returned_members):
        raise diagnostic_failure(
            failure_stage="scenario_object_validation", stable_error_code="ACQUISITION_TARGET_MEMBER_INVALID",
            validation_rule="EXACT_ACTOR_AND_TARGET_MEMBERS_RETURNED", object_type="TARGET_MEMBER", field_path="members",
            expected_shape="ARRAY_CONTAINING_EXACT_AUTHORIZED_MEMBERS", observed_value=members, cause=ValueError("member relationship"), transport_request_count=request_count,
        )
    for scenario in scenarios:
        if scenario.target_type == "ROLE" and scenario.target_id not in role_ids:
            raise diagnostic_failure(
                failure_stage="scenario_object_validation", stable_error_code="ACQUISITION_TARGET_ROLE_NOT_FOUND",
                validation_rule="SCENARIO_ROLE_EXISTS_IN_ROLE_GET", object_type="TARGET_ROLE", scenario_id=scenario.scenario_id,
                field_path="scenario.target_id", expected_shape="EXISTING_ROLE_REFERENCE", observed_value=None,
                cause=LookupError("role not found"), transport_request_count=request_count,
            )
        if scenario.target_type == "CHANNEL" and scenario.target_id not in channel_ids:
            raise diagnostic_failure(
                failure_stage="scenario_object_validation", stable_error_code="ACQUISITION_TARGET_CHANNEL_NOT_FOUND",
                validation_rule="SCENARIO_CHANNEL_EXISTS_IN_CHANNEL_GET", object_type="TARGET_CHANNEL", scenario_id=scenario.scenario_id,
                field_path="scenario.target_id", expected_shape="EXISTING_CHANNEL_REFERENCE", observed_value=None,
                cause=LookupError("channel not found"), transport_request_count=request_count,
            )


@dataclass(slots=True)
class AuditCall:
    sequence: int
    operation: str
    endpoint_template: str
    started_at: str
    completed_at: str | None = None
    status: str = "STARTED"
    http_status: int | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "sequence": self.sequence,
            "method": "GET",
            "operation": self.operation,
            "sanitized_endpoint_template": self.endpoint_template,
            "allowlisted": self.operation in ROUTES and not any(item in self.endpoint_template for item in FORBIDDEN_ROUTE_FRAGMENTS),
            "request_body_sent": False,
            "write_operation": False,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "status": self.status,
            "http_status": self.http_status,
        }


class GetOnlyTransport:
    """Narrow facade with no generic request and no member-list method."""

    def __init__(self, transport: DiscordPyReadTransport, *, timeout_seconds: float = 20.0) -> None:
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        self._transport = transport
        self.timeout_seconds = float(timeout_seconds)
        self.calls: list[AuditCall] = []

    def record_login(self, status: str, *, http_status: int | None = None) -> None:
        now = _now()
        self.calls.append(AuditCall(len(self.calls) + 1, "client.login", ROUTES["client.login"], now, now, status, http_status))

    async def _get(self, operation: str, callback: Callable[[], Awaitable[Any]]) -> Any:
        if operation not in ROUTES:
            raise CurrentBaselineError("GET operation is not allowlisted")
        call = AuditCall(len(self.calls) + 1, operation, ROUTES[operation], _now())
        self.calls.append(call)
        try:
            value = await asyncio.wait_for(callback(), timeout=self.timeout_seconds)
        except BaseException as exc:
            call.completed_at = _now()
            call.status = "FAILED"
            call.http_status = getattr(exc, "status", None)
            raise
        call.completed_at = _now()
        call.status = "COMPLETE"
        call.http_status = 200
        return value

    async def read_guild(self, guild_id: int) -> Any:
        return await self._get("read_guild", lambda: self._transport.read_guild(guild_id))

    async def read_roles(self, guild_id: int) -> Any:
        return await self._get("read_roles", lambda: self._transport.read_roles(guild_id))

    async def read_channels(self, guild_id: int) -> Any:
        return await self._get("read_channels", lambda: self._transport.read_channels(guild_id))

    async def read_member(self, guild_id: int, member_id: int) -> Any:
        return await self._get("read_member", lambda: self._transport.read_member(guild_id, member_id))

    async def read_active_threads(self, guild_id: int) -> Any:
        return await self._get("read_active_threads", lambda: self._transport.read_active_threads(guild_id))

    def audit(self) -> dict[str, Any]:
        calls = [item.as_dict() for item in self.calls]
        return {
            "contract": GET_ONLY_ACQUISITION_CONTRACT_VERSION,
            "transport": "REST_GET_ONLY",
            "calls": calls,
            "get_request_count": len(calls),
            "write_request_count": 0,
            "gateway_connected": False,
            "request_bodies_sent": 0,
            "all_calls_allowlisted": all(item["allowlisted"] for item in calls),
            "non_get_attempted": False,
            "raw_response_serialized": False,
            "status": "PASS" if all(item["allowlisted"] and item["method"] == "GET" for item in calls) else "FAIL",
        }


class GetOnlyAcquisitionFailure(RuntimeError):
    """Carry a sanitized failure and the audit completed before failure."""

    def __init__(self, failure: Mapping[str, str], audit: Mapping[str, Any]) -> None:
        super().__init__(failure.get("code", "ACQUISITION_FAILED"))
        self.failure = dict(failure)
        self.audit = dict(audit)


def readiness_report(scenarios: tuple[LiveScenario, ...], confirmation: str | None = None) -> dict[str, Any]:
    errors = list(validate_baseline_scenarios(scenarios))
    if confirmation is not None and confirmation != CONFIRMATION_PHRASE:
        errors.append("DISPOSABLE_GUILD_CONFIRMATION_INVALID")
    member_ids = sorted(
        {item.actor_member_id for item in scenarios}
        | {item.target_id for item in scenarios if item.target_type == "MEMBER" and item.target_id},
        key=int,
    )
    thread_required = any(item.thread_id for item in scenarios)
    plan = ["client.login", "read_guild", "read_roles", "read_channels"] + ["read_member"] * len(member_ids)
    if thread_required:
        plan.append("read_active_threads")
    return {
        "contract": GET_ONLY_ACQUISITION_CONTRACT_VERSION,
        "status": "READY" if not errors else "NOT_READY",
        "errors": sorted(set(errors)),
        "planned_get_request_count": len(plan),
        "planned_operations": plan,
        "member_records_requested": len(member_ids),
        "full_member_list_requested": False,
        "active_threads_requested": thread_required,
        "write_request_count": 0,
        "gateway_connected": False,
        "raw_payload_persistence": False,
        "token_transport": "CHILD_STDIN_ONLY",
        "token_command_line_argument": False,
        "token_environment_variable": False,
        "stage6_started": False,
    }


async def acquire_current_baseline(
    client: Any,
    token: str,
    scenarios: tuple[LiveScenario, ...],
    *,
    confirmation: str,
    timeout_seconds: float = 20.0,
    emit: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """Acquire exact allowlisted objects and return only synthetic capsules."""

    emit = emit or (lambda _: None)
    ready = readiness_report(scenarios, confirmation)
    if ready["status"] != "READY":
        raise CurrentBaselineError(";".join(ready["errors"]))
    guild_id = scenarios[0].guild_id
    if not token:
        raise CurrentBaselineError("token was not supplied through child stdin")
    emit("GET 1/6 authentication")
    try:
        await asyncio.wait_for(client.login(token), timeout=timeout_seconds)
    except (KeyboardInterrupt, asyncio.CancelledError):
        raise
    except Exception as exc:
        now = _now()
        audit = {
            "contract": GET_ONLY_ACQUISITION_CONTRACT_VERSION, "transport": "REST_GET_ONLY",
            "calls": [AuditCall(1, "client.login", ROUTES["client.login"], now, now, "FAILED", getattr(exc, "status", None)).as_dict()],
            "get_request_count": 1, "write_request_count": 0, "gateway_connected": False,
            "request_bodies_sent": 0, "all_calls_allowlisted": True, "non_get_attempted": False,
            "raw_response_serialized": False, "status": "FAIL",
        }
        failure = _transport_failure(exc, audit)
        raise GetOnlyAcquisitionFailure(failure.diagnostic, audit) from exc
    transport = GetOnlyTransport(DiscordPyReadTransport.from_client(client), timeout_seconds=timeout_seconds)
    transport.record_login("COMPLETE", http_status=200)
    try:
        gid = int(guild_id)
        emit("GET 2/6 guild metadata")
        guild = await transport.read_guild(gid)
        emit("GET 3/6 roles")
        roles = await transport.read_roles(gid)
        emit("GET 4/6 channels")
        channels = await transport.read_channels(gid)
        member_ids = sorted(
            {item.actor_member_id for item in scenarios}
            | {item.target_id for item in scenarios if item.target_type == "MEMBER" and item.target_id},
            key=int,
        )
        members = []
        for index, member_id in enumerate(member_ids, start=5):
            emit(f"GET {index}/6 explicitly authorized member")
            members.append(await transport.read_member(gid, int(member_id)))
        threads: list[dict[str, Any]] = []
        if any(item.thread_id for item in scenarios):
            thread_payload = await transport.read_active_threads(gid)
            threads = list(thread_payload.get("threads", ()))
        _validate_acquired_objects(guild, roles, channels, members, scenarios, request_count=len(transport.calls), expected_guild_id=guild_id)
        raw = {"guild": guild, "roles": roles, "channels": channels, "members": members, "active_threads": threads}
        try:
            capsules = build_current_baseline_capsules(raw, scenarios)
        except (KeyboardInterrupt, asyncio.CancelledError):
            raise
        except Exception as exc:
            failure = _post_transport_failure(exc, transport.audit())
            raise GetOnlyAcquisitionFailure(failure.diagnostic, transport.audit()) from exc
        raw = guild = roles = channels = members = threads = None
        return {"capsules": capsules, "transport_audit": transport.audit(), "readiness": ready}
    except (KeyboardInterrupt, asyncio.CancelledError):
        raise
    except GetOnlyAcquisitionFailure:
        raise
    except Exception as exc:
        audit = transport.audit()
        failed_get = any(call.get("status") == "FAILED" for call in audit.get("calls", ()))
        failure = _transport_failure(exc, audit) if failed_get else _post_transport_failure(exc, audit)
        raise GetOnlyAcquisitionFailure(failure.diagnostic, transport.audit()) from exc


__all__ = ["GetOnlyAcquisitionFailure", "GetOnlyTransport", "ROUTES", "acquire_current_baseline", "readiness_report", "safe_error"]
