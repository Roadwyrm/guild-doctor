"""Live REST-only structural scan command.

Authentication uses ``GUILD_DOCTOR_DISCORD_TOKEN``.  The command logs in through
Discord's HTTP API but never opens a Gateway connection and never calls a write
endpoint.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

from .acquisition import ReadOnlyAcquisitionAdapter
from .canonical import canonical_json
from .discordpy_adapter import DiscordLibraryCompatibilityError, DiscordPyReadTransport


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run a strictly read-only Guild Doctor structural scan")
    parser.add_argument("guild_id", help="Discord guild/server ID")
    parser.add_argument("--output", "-o", type=Path, required=True, help="Normalized snapshot JSON output")
    parser.add_argument(
        "--envelope-output",
        type=Path,
        help="Optional acquisition envelope output without secrets or raw payload bodies",
    )
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output")
    return parser


async def _run(args: argparse.Namespace) -> int:
    token = os.environ.get("GUILD_DOCTOR_DISCORD_TOKEN")
    if not token:
        print("guild-doctor-live-scan: GUILD_DOCTOR_DISCORD_TOKEN is not set", file=sys.stderr)
        return 1

    try:
        import discord
    except ImportError:
        print("guild-doctor-live-scan: discord.py 2.7.1 is not installed", file=sys.stderr)
        return 1

    # Intents.none() and login() are sufficient for the four REST GET endpoints.
    # We deliberately do not call start(), connect(), or run(), so no Gateway
    # connection is opened during Pass 2 structural acquisition.
    client = discord.Client(intents=discord.Intents.none(), max_messages=None)
    try:
        async with client:
            await client.login(token)
            transport = DiscordPyReadTransport.from_client(client)
            acquisition = await ReadOnlyAcquisitionAdapter(transport).acquire_structure(args.guild_id)
    except DiscordLibraryCompatibilityError as exc:
        print(f"guild-doctor-live-scan: compatibility error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        message = " ".join(str(exc).split())[:500] or exc.__class__.__name__
        print(f"guild-doctor-live-scan: authentication/acquisition error: {message}", file=sys.stderr)
        return 1

    if args.envelope_output:
        args.envelope_output.parent.mkdir(parents=True, exist_ok=True)
        envelope = {
            "guild_id": acquisition.guild_id,
            "started_at": acquisition.started_at,
            "completed_at": acquisition.completed_at,
            "normalization_error": acquisition.normalization_error,
            "results": {name: result.as_dict() for name, result in acquisition.results.items()},
        }
        args.envelope_output.write_text(
            json.dumps(envelope, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
        )

    if acquisition.snapshot is None:
        print(
            f"guild-doctor-live-scan: no canonical snapshot produced: {acquisition.normalization_error}",
            file=sys.stderr,
        )
        return 2

    data = acquisition.snapshot.as_dict()
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) if args.pretty else canonical_json(data)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text + "\n", encoding="utf-8")

    return 0 if acquisition.snapshot.structural_completeness == "COMPLETE" else 2


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return asyncio.run(_run(args))


if __name__ == "__main__":
    raise SystemExit(main())
