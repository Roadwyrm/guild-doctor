"""Immutable Stage 5 Pass 2 enumeration-query contract.

Pass 2 describes a finite, explicit population and one registered diagnostic
target.  It contains no Discord client, network callback, persistence handle,
command object, natural-language question, or remediation request.
"""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .action_registry import ACTION_RULES_BY_KEY, ACTION_RULES_VERSION
from .capability_registry import CAPABILITY_REGISTRY_VERSION, DEFAULT_CAPABILITY_REGISTRY
from .canonical import canonical_json
from .constants import PERMISSION_DEFINITION_VERSION, SNAPSHOT_SCHEMA_VERSION
from .doctor_query import (
    ACTION,
    CAPABILITY,
    DOCTOR_QUERY_CONTRACT_VERSION,
    EXPECTED_REGISTRY_VERSIONS,
    EXPECTED_STAGE3_CONTRACT_VERSIONS,
    EXPLAIN_ACTUAL_RESULT,
    STAGE5_PASS1_CONTRACT_VERSION,
    SUPPORTED_CONTEXT_TYPES,
    TARGET_KINDS,
)
from .explanation_adapters import EXPLANATION_ADAPTERS_VERSION
from .explanation_query import EXPLANATION_QUERY_CONTRACT_VERSION
from .explanation_schema import EXPLANATION_MODES
from .explanation_orchestrator import STAGE4_PASS3_CONTRACT_VERSION
from .fixture_export import STAGE3_FIXTURE_VERSION


STAGE5_PASS2_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE5-PASS2-0.1"
ENUMERATION_QUERY_CONTRACT_VERSION = "GUILD-DOCTOR-ENUMERATION-QUERY-0.1"
ENUMERATION_MAX_CANDIDATES = 250

WHO_CAN = "WHO_CAN"
WHO_CANNOT = "WHO_CANNOT"
WHO_UNKNOWN = "WHO_UNKNOWN"
ENUMERATE_ACTUAL_RESULTS = "ENUMERATE_ACTUAL_RESULTS"
ENUMERATION_INTENTS = frozenset({WHO_CAN, WHO_CANNOT, WHO_UNKNOWN, ENUMERATE_ACTUAL_RESULTS})

EXPLICIT_CANDIDATES = "EXPLICIT_CANDIDATES"
SNAPSHOT_MEMBERS = "SNAPSHOT_MEMBERS"
POPULATION_SOURCES = frozenset({EXPLICIT_CANDIDATES, SNAPSHOT_MEMBERS})

COMPLETE_GUILD_MEMBERS = "COMPLETE_GUILD_MEMBERS"
PARTIAL_GUILD_MEMBERS = "PARTIAL_GUILD_MEMBERS"
EXPLICIT_CANDIDATE_SET = "EXPLICIT_CANDIDATE_SET"
UNKNOWN_COVERAGE = "UNKNOWN_COVERAGE"
NOT_REQUESTED = "NOT_REQUESTED"
POPULATION_COVERAGES = frozenset(
    {COMPLETE_GUILD_MEMBERS, PARTIAL_GUILD_MEMBERS, EXPLICIT_CANDIDATE_SET, UNKNOWN_COVERAGE, NOT_REQUESTED}
)

HUMAN = "HUMAN"
BOT = "BOT"
MEMBER_KINDS = frozenset({HUMAN, BOT})

_SNAPSHOT_VERSIONS = frozenset({SNAPSHOT_SCHEMA_VERSION, STAGE3_FIXTURE_VERSION})
_SECRET_FRAGMENTS = ("token", "authorization", "access_token", "client_secret", "password", "api_key", "credential")
_FORBIDDEN_KEYS = frozenset(
    {
        "environment",
        "environment_dump",
        "database",
        "connection",
        "interaction",
        "callback",
        "live_discord_object",
        "natural_language_question",
        "question",
        "prompt",
        "recommendation",
        "recommendations",
        "remediation",
        "repair",
        "output_path",
        "channel_destination",
        "executable_code",
        "network_callback",
    }
)
_TOKEN_SHAPE = re.compile(r"^(?:mfa\.)?[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{8,}$")


class EnumerationQueryError(ValueError):
    """Raised when strict enumeration-query construction is requested."""


def _text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def _upper(value: Any) -> str | None:
    value = _text(value)
    return value.upper() if value else None


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _freeze(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        value = method()
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(value[key]) for key in sorted(value, key=lambda item: str(item))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(item) for item in sorted(value, key=str))
    return deepcopy(value)


def thaw_enumeration(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): thaw_enumeration(child) for key, child in value.items()}
    if isinstance(value, (tuple, list)):
        return [thaw_enumeration(child) for child in value]
    return deepcopy(value)


def _redact(value: Any, key: str = "") -> Any:
    lower = key.lower()
    if any(fragment in lower for fragment in _SECRET_FRAGMENTS):
        return None
    if isinstance(value, Mapping):
        return {
            str(child_key): _redact(child, str(child_key))
            for child_key, child in value.items()
            if not any(fragment in str(child_key).lower() for fragment in _SECRET_FRAGMENTS)
        }
    if isinstance(value, (list, tuple)):
        return [_redact(child, key) for child in value]
    if isinstance(value, str) and (_TOKEN_SHAPE.fullmatch(value.strip()) or value.lower().startswith("bot ")):
        return None
    return value


def _scan_forbidden(value: Any, path: str = "enumeration_query") -> tuple[str, ...]:
    errors: list[str] = []
    if callable(value):
        errors.append(f"ENUMERATION_FORBIDDEN_EXECUTABLE:{path}")
    elif isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            lower = key_text.lower()
            child_path = f"{path}.{key_text}"
            if any(fragment in lower for fragment in _SECRET_FRAGMENTS):
                errors.append(f"ENUMERATION_CREDENTIAL_FIELD:{child_path}")
            if lower in _FORBIDDEN_KEYS:
                errors.append(f"ENUMERATION_FORBIDDEN_FIELD:{child_path}")
            errors.extend(_scan_forbidden(child, child_path))
    elif isinstance(value, (list, tuple, set, frozenset)):
        for index, child in enumerate(value):
            errors.extend(_scan_forbidden(child, f"{path}[{index}]"))
    elif isinstance(value, str) and (_TOKEN_SHAPE.fullmatch(value.strip()) or value.lower().startswith("bot ")):
        errors.append(f"ENUMERATION_CREDENTIAL_VALUE:{path}")
    return tuple(sorted(set(errors)))


def _mapping(value: Any) -> Mapping[str, Any] | None:
    return value if isinstance(value, Mapping) else None


def _default_stage4_contracts() -> dict[str, str]:
    return {
        "stage4_pass3_contract_version": STAGE4_PASS3_CONTRACT_VERSION,
        "explanation_query_contract_version": EXPLANATION_QUERY_CONTRACT_VERSION,
        "explanation_adapters_version": EXPLANATION_ADAPTERS_VERSION,
    }


@dataclass(frozen=True, slots=True)
class DoctorEnumerationQuery:
    """One immutable finite-population enumeration request."""

    query_id: str
    enumeration_intent: str
    target_kind: str
    target_key: str
    guild_id: str
    target_type: str | None = None
    target_id: str | None = None
    context_id: str | None = None
    context_type: str | None = None
    parent_id: str | None = None
    thread_id: str | None = None
    thread_type: str | None = None
    target_record: Mapping[str, Any] | None = None
    target_attributes: Mapping[str, Any] | None = None
    population_source: str | None = None
    population_coverage: str | None = None
    candidates: tuple[Mapping[str, Any], ...] = ()
    snapshot: Mapping[str, Any] | None = None
    member_collection_health: Mapping[str, Any] | None = None
    population_completeness: Mapping[str, Any] | None = None
    expected_member_count: int | None = None
    retrieved_member_count: int | None = None
    candidate_inclusion_policy: Mapping[str, Any] | None = None
    explicit_exclusion_ids: tuple[str, ...] = ()
    maximum_candidate_count: int = ENUMERATION_MAX_CANDIDATES
    evidence_classifications: tuple[str, ...] = ()
    verification_statuses: tuple[str, ...] = ()
    aggregate_explanation_mode: str = "SIMPLE"
    presentation_profile: str = "SIMPLE_CARD"
    output_format: str = "PLAIN_TEXT"
    include_full_doctor_cases: bool = False
    include_result_buckets: bool = True
    include_reason_frequencies: bool = True
    include_source_location_frequencies: bool = True
    display_safe_labels: Mapping[str, str] | None = None
    source_stage3_contract_versions: Mapping[str, str] | None = None
    expected_stage3_contract_versions: Mapping[str, str] | None = None
    expected_stage4_contract_versions: Mapping[str, str] | None = None
    permission_definition_version: str = PERMISSION_DEFINITION_VERSION
    registry_versions: Mapping[str, str] | None = None
    snapshot_or_fixture_version: str | None = None
    requested_stage5_pass2_contract: str = STAGE5_PASS2_CONTRACT_VERSION
    enumeration_query_contract_version: str = ENUMERATION_QUERY_CONTRACT_VERSION
    expected_stage5_pass1_contract: str = STAGE5_PASS1_CONTRACT_VERSION
    expected_doctor_query_contract: str = DOCTOR_QUERY_CONTRACT_VERSION

    def __post_init__(self) -> None:
        for field_name in (
            "guild_id",
            "target_id",
            "context_id",
            "parent_id",
            "thread_id",
        ):
            object.__setattr__(self, field_name, _snowflake(getattr(self, field_name)))
        for field_name in ("enumeration_intent", "target_kind", "target_type", "context_type", "thread_type", "population_source", "population_coverage", "aggregate_explanation_mode", "presentation_profile", "output_format"):
            object.__setattr__(self, field_name, _upper(getattr(self, field_name)))
        object.__setattr__(self, "query_id", _text(self.query_id) or "")
        object.__setattr__(self, "target_key", _text(self.target_key) or "")
        if self.candidates is None:
            object.__setattr__(self, "candidates", ())
        else:
            object.__setattr__(self, "candidates", tuple(_freeze(item) for item in self.candidates))
        for field_name in (
            "target_record",
            "target_attributes",
            "snapshot",
            "member_collection_health",
            "population_completeness",
            "candidate_inclusion_policy",
            "display_safe_labels",
            "source_stage3_contract_versions",
            "expected_stage3_contract_versions",
            "expected_stage4_contract_versions",
            "registry_versions",
        ):
            value = getattr(self, field_name)
            if value is None and field_name == "expected_stage3_contract_versions":
                value = dict(EXPECTED_STAGE3_CONTRACT_VERSIONS)
            elif value is None and field_name == "expected_stage4_contract_versions":
                value = _default_stage4_contracts()
            elif value is None and field_name == "registry_versions":
                value = dict(EXPECTED_REGISTRY_VERSIONS)
            object.__setattr__(self, field_name, None if value is None else _freeze(value))
        for field_name in ("explicit_exclusion_ids", "evidence_classifications", "verification_statuses"):
            value = getattr(self, field_name)
            values = () if value is None else value if not isinstance(value, str) else (value,)
            object.__setattr__(self, field_name, tuple(sorted({str(item).strip() for item in values if str(item).strip()})))

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "DoctorEnumerationQuery":
        if not isinstance(value, Mapping):
            raise EnumerationQueryError("ENUMERATION_QUERY_NOT_MAPPING")
        policy = value.get("candidate_inclusion_policy")
        return cls(
            query_id=value.get("query_id", ""),
            enumeration_intent=value.get("enumeration_intent", value.get("intent", "")),
            target_kind=value.get("target_kind", ""),
            target_key=value.get("target_key", ""),
            guild_id=value.get("guild_id"),
            target_type=value.get("target_type"),
            target_id=value.get("target_id"),
            context_id=value.get("context_id"),
            context_type=value.get("context_type"),
            parent_id=value.get("parent_id"),
            thread_id=value.get("thread_id"),
            thread_type=value.get("thread_type"),
            target_record=value.get("target_record"),
            target_attributes=value.get("target_attributes"),
            population_source=value.get("population_source"),
            population_coverage=value.get("population_coverage"),
            candidates=value.get("candidates", ()),
            snapshot=value.get("snapshot"),
            member_collection_health=value.get("member_collection_health"),
            population_completeness=value.get("population_completeness"),
            expected_member_count=value.get("expected_member_count"),
            retrieved_member_count=value.get("retrieved_member_count"),
            candidate_inclusion_policy=policy,
            explicit_exclusion_ids=value.get("explicit_exclusion_ids", ()),
            maximum_candidate_count=value.get("maximum_candidate_count", ENUMERATION_MAX_CANDIDATES),
            evidence_classifications=value.get("evidence_classifications", ()),
            verification_statuses=value.get("verification_statuses", ()),
            aggregate_explanation_mode=value.get("aggregate_explanation_mode", value.get("explanation_mode", "SIMPLE")),
            presentation_profile=value.get("presentation_profile", "SIMPLE_CARD"),
            output_format=value.get("output_format", "PLAIN_TEXT"),
            include_full_doctor_cases=value.get("include_full_doctor_cases", False),
            include_result_buckets=value.get("include_result_buckets", True),
            include_reason_frequencies=value.get("include_reason_frequencies", True),
            include_source_location_frequencies=value.get("include_source_location_frequencies", True),
            display_safe_labels=value.get("display_safe_labels", value.get("labels")),
            source_stage3_contract_versions=value.get("source_stage3_contract_versions"),
            expected_stage3_contract_versions=value.get("expected_stage3_contract_versions"),
            expected_stage4_contract_versions=value.get("expected_stage4_contract_versions"),
            permission_definition_version=value.get("permission_definition_version", PERMISSION_DEFINITION_VERSION),
            registry_versions=value.get("registry_versions"),
            snapshot_or_fixture_version=value.get("snapshot_or_fixture_version"),
            requested_stage5_pass2_contract=value.get("requested_stage5_pass2_contract", STAGE5_PASS2_CONTRACT_VERSION),
            enumeration_query_contract_version=value.get("enumeration_query_contract_version", ENUMERATION_QUERY_CONTRACT_VERSION),
            expected_stage5_pass1_contract=value.get("expected_stage5_pass1_contract", STAGE5_PASS1_CONTRACT_VERSION),
            expected_doctor_query_contract=value.get("expected_doctor_query_contract", DOCTOR_QUERY_CONTRACT_VERSION),
        )

    def as_dict(self, *, include_source: bool = True) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "requested_stage5_pass2_contract": self.requested_stage5_pass2_contract,
            "enumeration_query_contract_version": self.enumeration_query_contract_version,
            "expected_stage5_pass1_contract": self.expected_stage5_pass1_contract,
            "expected_doctor_query_contract": self.expected_doctor_query_contract,
            "query_id": self.query_id,
            "enumeration_intent": self.enumeration_intent,
            "target_kind": self.target_kind,
            "target_key": self.target_key,
            "guild_id": self.guild_id,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "context_id": self.context_id,
            "context_type": self.context_type,
            "parent_id": self.parent_id,
            "thread_id": self.thread_id,
            "thread_type": self.thread_type,
            "target_attributes": _redact(thaw_enumeration(self.target_attributes)),
            "population_source": self.population_source,
            "population_coverage": self.population_coverage,
            "candidates": _redact(thaw_enumeration(self.candidates)),
            "member_collection_health": _redact(thaw_enumeration(self.member_collection_health)),
            "population_completeness": _redact(thaw_enumeration(self.population_completeness)),
            "expected_member_count": self.expected_member_count,
            "retrieved_member_count": self.retrieved_member_count,
            "candidate_inclusion_policy": _redact(thaw_enumeration(self.candidate_inclusion_policy)),
            "explicit_exclusion_ids": list(self.explicit_exclusion_ids),
            "maximum_candidate_count": self.maximum_candidate_count,
            "evidence_classifications": list(self.evidence_classifications),
            "verification_statuses": list(self.verification_statuses),
            "aggregate_explanation_mode": self.aggregate_explanation_mode,
            "presentation_profile": self.presentation_profile,
            "output_format": self.output_format,
            "include_full_doctor_cases": self.include_full_doctor_cases,
            "include_result_buckets": self.include_result_buckets,
            "include_reason_frequencies": self.include_reason_frequencies,
            "include_source_location_frequencies": self.include_source_location_frequencies,
            "display_safe_labels": _redact(thaw_enumeration(self.display_safe_labels)),
            "source_stage3_contract_versions": thaw_enumeration(self.source_stage3_contract_versions) or {},
            "expected_stage3_contract_versions": thaw_enumeration(self.expected_stage3_contract_versions) or {},
            "expected_stage4_contract_versions": thaw_enumeration(self.expected_stage4_contract_versions) or {},
            "permission_definition_version": self.permission_definition_version,
            "registry_versions": thaw_enumeration(self.registry_versions) or {},
            "snapshot_or_fixture_version": self.snapshot_or_fixture_version,
        }
        if include_source:
            payload["target_record"] = _redact(thaw_enumeration(self.target_record))
            payload["snapshot"] = _redact(thaw_enumeration(self.snapshot))
        return payload


def _snapshot_members(query: DoctorEnumerationQuery) -> Any:
    if not isinstance(query.snapshot, Mapping):
        return None
    for key in ("members", "member_records", "member_data"):
        value = query.snapshot.get(key)
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            return value
    return None


def validate_enumeration_query(value: DoctorEnumerationQuery | Mapping[str, Any]) -> tuple[str, ...]:
    """Validate an enumeration query without accessing Discord or the network."""

    if isinstance(value, DoctorEnumerationQuery):
        query = value
        raw = query.as_dict(include_source=True)
    elif isinstance(value, Mapping):
        raw = deepcopy(dict(value))
        try:
            query = DoctorEnumerationQuery.from_mapping(value)
        except (EnumerationQueryError, TypeError, ValueError) as exc:
            return (f"ENUMERATION_QUERY_CONSTRUCTION:{exc}",)
    else:
        return ("ENUMERATION_QUERY_NOT_MAPPING",)

    errors = list(_scan_forbidden(raw))
    if not query.query_id:
        errors.append("ENUMERATION_QUERY_ID_MISSING")
    if query.enumeration_query_contract_version != ENUMERATION_QUERY_CONTRACT_VERSION:
        errors.append("ENUMERATION_QUERY_CONTRACT_UNSUPPORTED")
    if query.requested_stage5_pass2_contract != STAGE5_PASS2_CONTRACT_VERSION:
        errors.append("STAGE5_PASS2_CONTRACT_UNSUPPORTED")
    if query.expected_stage5_pass1_contract != STAGE5_PASS1_CONTRACT_VERSION:
        errors.append("STAGE5_PASS1_EXPECTATION_MISMATCH")
    if query.expected_doctor_query_contract != DOCTOR_QUERY_CONTRACT_VERSION:
        errors.append("DOCTOR_QUERY_EXPECTATION_MISMATCH")
    if query.permission_definition_version != PERMISSION_DEFINITION_VERSION:
        errors.append("PERMISSION_DEFINITION_MISMATCH")
    if query.enumeration_intent not in ENUMERATION_INTENTS:
        errors.append("ENUMERATION_INTENT_UNKNOWN")
    if query.target_kind not in TARGET_KINDS:
        errors.append("ENUMERATION_TARGET_KIND_UNKNOWN")
    if not query.target_key:
        errors.append("ENUMERATION_TARGET_KEY_MISSING")
    elif query.target_kind == CAPABILITY and query.target_key not in {item.capability_key for item in DEFAULT_CAPABILITY_REGISTRY.capabilities}:
        errors.append("ENUMERATION_CAPABILITY_KEY_UNKNOWN")
    elif query.target_kind == ACTION and query.target_key not in ACTION_RULES_BY_KEY:
        errors.append("ENUMERATION_OPERATION_KEY_UNKNOWN")
    if _snowflake(query.guild_id) is None:
        errors.append("ENUMERATION_GUILD_ID_MISSING_OR_INVALID")
    if query.target_type is not None and query.target_kind == ACTION and query.target_key in ACTION_RULES_BY_KEY:
        rule = ACTION_RULES_BY_KEY[query.target_key]
        if query.target_type is None:
            errors.append("ENUMERATION_FIXED_TARGET_TYPE_MISSING")
        elif query.target_type not in rule.target_types:
            errors.append("ENUMERATION_ACTION_TARGET_TYPE_INCOMPATIBLE")
        if query.context_type is None and "NONE" not in rule.context_types:
            errors.append("ENUMERATION_FIXED_CONTEXT_MISSING")
        if query.context_type is not None and query.context_type not in rule.context_types:
            errors.append("ENUMERATION_ACTION_CONTEXT_TYPE_INCOMPATIBLE")
        if query.target_type != "NONE" and query.target_id is None:
            errors.append("ENUMERATION_FIXED_TARGET_ID_MISSING")
    if query.context_type is not None and query.context_type not in SUPPORTED_CONTEXT_TYPES:
        errors.append("ENUMERATION_CONTEXT_TYPE_UNSUPPORTED")
    if query.thread_type is not None and query.thread_type not in {"PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"}:
        errors.append("ENUMERATION_THREAD_TYPE_UNSUPPORTED")
    if query.target_kind == CAPABILITY and query.context_type is not None:
        definition = next((item for item in DEFAULT_CAPABILITY_REGISTRY.capabilities if item.capability_key == query.target_key), None)
        if definition is not None and query.context_type not in {"GUILD", "CATEGORY", *definition.context_types, "PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"}:
            errors.append("ENUMERATION_CAPABILITY_CONTEXT_TYPE_INCOMPATIBLE")
    if query.population_source not in POPULATION_SOURCES:
        errors.append("ENUMERATION_POPULATION_SOURCE_UNKNOWN")
    if query.population_coverage not in POPULATION_COVERAGES:
        errors.append("ENUMERATION_POPULATION_COVERAGE_UNKNOWN")
    if query.population_source == SNAPSHOT_MEMBERS and query.snapshot is None:
        errors.append("ENUMERATION_SNAPSHOT_MISSING")
    if query.population_source == EXPLICIT_CANDIDATES and not query.candidates:
        errors.append("ENUMERATION_EMPTY_EXPLICIT_POPULATION")
    if query.maximum_candidate_count != ENUMERATION_MAX_CANDIDATES:
        errors.append("ENUMERATION_MAXIMUM_CANDIDATE_COUNT_MISMATCH")
    if len(query.candidates) > ENUMERATION_MAX_CANDIDATES:
        errors.append("ENUMERATION_CANDIDATE_LIMIT_EXCEEDED")
    if any(not isinstance(item, Mapping) for item in query.candidates):
        errors.append("ENUMERATION_CANDIDATE_NOT_MAPPING")
    snapshot_records = _snapshot_members(query)
    if snapshot_records is not None and len(snapshot_records) > ENUMERATION_MAX_CANDIDATES:
        errors.append("ENUMERATION_CANDIDATE_LIMIT_EXCEEDED")
    if query.expected_member_count is not None and (isinstance(query.expected_member_count, bool) or not isinstance(query.expected_member_count, int) or query.expected_member_count < 0):
        errors.append("ENUMERATION_EXPECTED_MEMBER_COUNT_INVALID")
    if query.retrieved_member_count is not None and (isinstance(query.retrieved_member_count, bool) or not isinstance(query.retrieved_member_count, int) or query.retrieved_member_count < 0):
        errors.append("ENUMERATION_RETRIEVED_MEMBER_COUNT_INVALID")
    policy = _mapping(query.candidate_inclusion_policy)
    required_policy = ("include_humans", "include_bots", "include_owner", "include_timed_out_members", "include_members_with_partial_data")
    if policy is None:
        errors.append("ENUMERATION_INCLUSION_POLICY_MISSING")
    else:
        for key in required_policy:
            if key not in policy or not isinstance(policy[key], bool):
                errors.append(f"ENUMERATION_INCLUSION_POLICY_{key.upper()}_REQUIRED")
    for item in query.explicit_exclusion_ids:
        if _snowflake(item) is None:
            errors.append("ENUMERATION_EXPLICIT_EXCLUSION_ID_INVALID")
    for key, expected in (query.expected_stage3_contract_versions or EXPECTED_STAGE3_CONTRACT_VERSIONS).items():
        if expected != EXPECTED_STAGE3_CONTRACT_VERSIONS.get(key, expected):
            errors.append(f"ENUMERATION_STAGE3_CONTRACT_MISMATCH:{key}")
    expected_stage4 = query.expected_stage4_contract_versions or _default_stage4_contracts()
    for key, expected in expected_stage4.items():
        if key in _default_stage4_contracts() and expected != _default_stage4_contracts()[key]:
            errors.append(f"ENUMERATION_STAGE4_CONTRACT_MISMATCH:{key}")
    for key, expected in (query.registry_versions or EXPECTED_REGISTRY_VERSIONS).items():
        if key in EXPECTED_REGISTRY_VERSIONS and expected != EXPECTED_REGISTRY_VERSIONS[key]:
            errors.append(f"ENUMERATION_REGISTRY_VERSION_MISMATCH:{key}")
    if query.aggregate_explanation_mode not in EXPLANATION_MODES:
        errors.append("ENUMERATION_EXPLANATION_MODE_UNSUPPORTED")
    if not isinstance(query.include_full_doctor_cases, bool) or not isinstance(query.include_result_buckets, bool) or not isinstance(query.include_reason_frequencies, bool) or not isinstance(query.include_source_location_frequencies, bool):
        errors.append("ENUMERATION_PRESENTATION_BOOLEAN_INVALID")
    if query.snapshot is not None and isinstance(query.snapshot, Mapping):
        snapshot_guild = _snowflake(query.snapshot.get("guild_id"))
        if snapshot_guild is None and isinstance(query.snapshot.get("guild"), Mapping):
            snapshot_guild = _snowflake(query.snapshot["guild"].get("id"))
        if snapshot_guild is not None and snapshot_guild != query.guild_id:
            errors.append("ENUMERATION_GUILD_MISMATCH")
        version = query.snapshot_or_fixture_version or query.snapshot.get("fixture_version") or query.snapshot.get("schema_version")
        if isinstance(query.snapshot.get("source"), Mapping):
            version = version or query.snapshot["source"].get("snapshot_schema_version") or query.snapshot["source"].get("fixture_version")
        if version is not None and version not in _SNAPSHOT_VERSIONS:
            errors.append("ENUMERATION_SNAPSHOT_CONTRACT_UNSUPPORTED")
    if query.population_source == SNAPSHOT_MEMBERS and _snapshot_members(query) is None:
        errors.append("ENUMERATION_MEMBER_COLLECTION_MISSING")
    return tuple(sorted(set(errors)))


__all__ = [
    "ACTION",
    "BOT",
    "CAPABILITY",
    "COMPLETE_GUILD_MEMBERS",
    "ENUMERATE_ACTUAL_RESULTS",
    "ENUMERATION_INTENTS",
    "ENUMERATION_MAX_CANDIDATES",
    "ENUMERATION_QUERY_CONTRACT_VERSION",
    "EXPLICIT_CANDIDATE_SET",
    "EXPLICIT_CANDIDATES",
    "HUMAN",
    "NOT_REQUESTED",
    "PARTIAL_GUILD_MEMBERS",
    "POPULATION_COVERAGES",
    "POPULATION_SOURCES",
    "SNAPSHOT_MEMBERS",
    "STAGE5_PASS2_CONTRACT_VERSION",
    "UNKNOWN_COVERAGE",
    "WHO_CAN",
    "WHO_CANNOT",
    "WHO_UNKNOWN",
    "DoctorEnumerationQuery",
    "EnumerationQueryError",
    "thaw_enumeration",
    "validate_enumeration_query",
]
