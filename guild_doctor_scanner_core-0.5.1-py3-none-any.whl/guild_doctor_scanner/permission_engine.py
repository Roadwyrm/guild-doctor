"""Pure guild-level permission evaluation for Stage 3 Pass 1.

This module deliberately has no Discord, network, persistence, command, or
channel-resolution dependency.  It evaluates only the guild-level union of
the @everyone role and explicitly assigned role permissions.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from .constants import (
    KNOWN_PERMISSION_MASK,
    PERMISSION_DEFINITION_VERSION,
    SNAPSHOT_SCHEMA_VERSION,
)
from .fixture_export import STAGE3_FIXTURE_VERSION


STAGE3_PASS1_ENGINE_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE3-PASS1-0.1"
ADMINISTRATOR_PERMISSION_BIT = 1 << 3
SUPPORTED_SOURCE_VERSIONS = frozenset(
    {SNAPSHOT_SCHEMA_VERSION, STAGE3_FIXTURE_VERSION}
)

BYPASS_NONE = "NONE"
BYPASS_OWNER = "OWNER"
BYPASS_ADMINISTRATOR = "ADMINISTRATOR"

COMPLETENESS_COMPLETE = "COMPLETE"
COMPLETENESS_PARTIAL = "PARTIAL"
COMPLETENESS_UNKNOWN = "UNKNOWN"

_MISSING = object()


@dataclass(frozen=True, slots=True)
class PermissionEvaluationRequest:
    """All input required for a deterministic guild-level evaluation."""

    guild_id: int | str
    guild_owner_id: int | str | None
    subject_id: int | str
    assigned_role_ids: Sequence[int | str] | None
    role_records: Mapping[Any, Any] | Sequence[Any] | Any | None
    permission_definition_version: str | None
    snapshot_or_fixture_version: str | None
    input_health: Mapping[str, Any] | None


@dataclass(frozen=True, slots=True)
class PermissionRoleContribution:
    """The contribution of one explicitly assigned role."""

    role_id: str
    permission_decimal: str | None
    permission_hex: str | None
    known_permission_bits_decimal: str | None
    known_permission_bits_hex: str | None
    unknown_permission_bits_decimal: str | None
    unknown_permission_bits_hex: str | None
    included: bool
    reason_codes: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "role_id": self.role_id,
            "permission_decimal": self.permission_decimal,
            "permission_hex": self.permission_hex,
            "known_permission_bits_decimal": self.known_permission_bits_decimal,
            "known_permission_bits_hex": self.known_permission_bits_hex,
            "unknown_permission_bits_decimal": self.unknown_permission_bits_decimal,
            "unknown_permission_bits_hex": self.unknown_permission_bits_hex,
            "included": self.included,
            "reason_codes": list(self.reason_codes),
        }


@dataclass(frozen=True, slots=True)
class PermissionTraceEvent:
    """One stable, timestamp-free evaluation trace event."""

    sequence: int
    code: str
    details: Mapping[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "sequence": self.sequence,
            "code": self.code,
            "details": _canonicalize(self.details),
        }


@dataclass(frozen=True, slots=True)
class GuildPermissionEvaluationResult:
    """Deterministic result returned by :func:`evaluate_guild_permissions`."""

    guild_id: str | None
    guild_owner_id: str | None
    subject_id: str | None
    assigned_role_ids: tuple[str, ...]
    bypass_state: str
    everyone_permission_decimal: str | None
    everyone_permission_hex: str | None
    assigned_role_contributions: tuple[PermissionRoleContribution, ...]
    raw_guild_permission_decimal: str | None
    raw_guild_permission_hex: str | None
    known_permission_bits_decimal: str | None
    known_permission_bits_hex: str | None
    unknown_permission_bits_decimal: str | None
    unknown_permission_bits_hex: str | None
    missing_role_references: tuple[str, ...]
    invalid_role_references: tuple[str, ...]
    completeness_state: str
    input_health_state: str
    reason_codes: tuple[str, ...]
    trace: tuple[PermissionTraceEvent, ...]
    engine_contract_version: str
    permission_definition_version: str | None
    snapshot_or_fixture_version: str | None

    def as_dict(self) -> dict[str, Any]:
        """Return a stable JSON-ready representation with decimal-string IDs."""

        return {
            "engine_contract_version": self.engine_contract_version,
            "permission_definition_version": self.permission_definition_version,
            "snapshot_or_fixture_version": self.snapshot_or_fixture_version,
            "guild_id": self.guild_id,
            "guild_owner_id": self.guild_owner_id,
            "subject_id": self.subject_id,
            "assigned_role_ids": list(self.assigned_role_ids),
            "bypass_state": self.bypass_state,
            "everyone_permission_decimal": self.everyone_permission_decimal,
            "everyone_permission_hex": self.everyone_permission_hex,
            "assigned_role_contributions": [
                contribution.as_dict()
                for contribution in self.assigned_role_contributions
            ],
            "raw_guild_permission_decimal": self.raw_guild_permission_decimal,
            "raw_guild_permission_hex": self.raw_guild_permission_hex,
            "known_permission_bits_decimal": self.known_permission_bits_decimal,
            "known_permission_bits_hex": self.known_permission_bits_hex,
            "unknown_permission_bits_decimal": self.unknown_permission_bits_decimal,
            "unknown_permission_bits_hex": self.unknown_permission_bits_hex,
            "missing_role_references": list(self.missing_role_references),
            "invalid_role_references": list(self.invalid_role_references),
            "completeness_state": self.completeness_state,
            "input_health_state": self.input_health_state,
            "reason_codes": list(self.reason_codes),
            "trace": [event.as_dict() for event in self.trace],
        }


@dataclass(frozen=True, slots=True)
class _RoleData:
    role_id: str | None
    permission_decimal: str | None
    permission_value: int | None
    valid: bool
    reason_codes: tuple[str, ...]


def _canonicalize(value: Any) -> Any:
    """Canonicalize small diagnostic mappings without changing their meaning."""

    if isinstance(value, Mapping):
        return {
            str(key): _canonicalize(value[key])
            for key in sorted(value, key=lambda item: str(item))
        }
    if isinstance(value, (list, tuple)):
        return [_canonicalize(item) for item in value]
    return value


def _unique_sorted(values: Sequence[str]) -> tuple[str, ...]:
    return tuple(sorted(set(values), key=lambda value: (int(value) if value.isdecimal() else 0, value)))


def _reference_sort_key(value: str) -> tuple[int, int, str]:
    if value.isdecimal():
        return (0, int(value), value)
    return (1, 0, value)


def _parse_snowflake(value: Any) -> str | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        if value <= 0:
            return None
        return str(value)
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text or not text.isdecimal():
        return None
    integer = int(text)
    return str(integer) if integer > 0 else None


def _parse_permission(value: Any) -> tuple[str | None, int | None]:
    if value is None or isinstance(value, bool):
        return None, None
    if isinstance(value, int):
        if value < 0:
            return None, None
        return str(value), value
    if not isinstance(value, str):
        return None, None
    text = value.strip()
    if not text or not text.isdecimal():
        return None, None
    integer = int(text)
    return str(integer), integer


def _permission_parts(value: int | None) -> tuple[str | None, str | None, str | None, str | None, str | None, str | None]:
    if value is None:
        return (None, None, None, None, None, None)
    known = value & KNOWN_PERMISSION_MASK
    unknown = value & ~KNOWN_PERMISSION_MASK
    return (
        str(value),
        format(value, "#x"),
        str(known),
        format(known, "#x"),
        str(unknown),
        format(unknown, "#x"),
    )


def _field(record: Any, *names: str) -> Any:
    if isinstance(record, Mapping):
        for name in names:
            if name in record:
                return record[name]
        return _MISSING
    for name in names:
        if hasattr(record, name):
            return getattr(record, name)
    return _MISSING


def _record_sequence(records: Any) -> list[Any] | None:
    if records is None:
        return None
    if isinstance(records, Mapping):
        if "id" in records or "permissions_decimal" in records or "permissions" in records:
            return [records]
        return list(records.values())
    if isinstance(records, Sequence) and not isinstance(records, (str, bytes, bytearray)):
        return list(records)
    return [records]


def _diagnostic_reference(value: Any) -> str:
    if value is _MISSING or value is None:
        return "<missing>"
    if isinstance(value, str):
        return value
    return str(value)


def _normalize_role(record: Any, guild_id: str | None) -> _RoleData:
    raw_id = _field(record, "id")
    role_id = _parse_snowflake(None if raw_id is _MISSING else raw_id)
    reasons: list[str] = []
    if role_id is None:
        reasons.append("ROLE_ID_INVALID")

    raw_permissions = _field(record, "permissions_decimal", "permissions")
    permission_decimal, permission_value = _parse_permission(
        None if raw_permissions is _MISSING else raw_permissions
    )
    if permission_value is None:
        reasons.append("ROLE_PERMISSION_INVALID")

    raw_role_guild_id = _field(record, "guild_id")
    if raw_role_guild_id is not _MISSING and raw_role_guild_id is not None:
        role_guild_id = _parse_snowflake(raw_role_guild_id)
        if role_guild_id is None or guild_id is None or role_guild_id != guild_id:
            reasons.append("ROLE_GUILD_ID_MISMATCH")

    raw_is_everyone = _field(record, "is_everyone")
    if raw_is_everyone is True and role_id is not None and role_id != guild_id:
        reasons.append("EVERYONE_ROLE_ID_MISMATCH")

    return _RoleData(
        role_id=role_id,
        permission_decimal=permission_decimal,
        permission_value=permission_value,
        valid=not reasons,
        reason_codes=tuple(sorted(set(reasons))),
    )


def _health_state(input_health: Mapping[str, Any] | None) -> tuple[str, str | None]:
    if input_health is None:
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_MISSING"
    if not isinstance(input_health, Mapping):
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID"

    candidates: list[Any] = []
    for key in (
        "status",
        "structural_completeness",
        "source_structural_completeness",
        "completeness",
    ):
        if key in input_health:
            candidates.append(input_health[key])
    if "complete" in input_health and isinstance(input_health["complete"], bool):
        candidates.append(COMPLETENESS_COMPLETE if input_health["complete"] else COMPLETENESS_PARTIAL)

    for candidate in candidates:
        if isinstance(candidate, str):
            normalized = candidate.strip().upper()
            if normalized == COMPLETENESS_COMPLETE:
                return COMPLETENESS_COMPLETE, None
            if normalized in {COMPLETENESS_PARTIAL, "INCOMPLETE", "NOT_REQUESTED"}:
                return COMPLETENESS_PARTIAL, "INPUT_HEALTH_INCOMPLETE"
            if normalized in {COMPLETENESS_UNKNOWN, "UNKNOWN"}:
                return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INCOMPLETE"
    if candidates:
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID"
    return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_MISSING"


def _make_contribution(
    role_id: str,
    permission_value: int | None,
    included: bool,
    reason_codes: Sequence[str] = (),
) -> PermissionRoleContribution:
    (
        permission_decimal,
        permission_hex,
        known_decimal,
        known_hex,
        unknown_decimal,
        unknown_hex,
    ) = _permission_parts(permission_value)
    return PermissionRoleContribution(
        role_id=role_id,
        permission_decimal=permission_decimal,
        permission_hex=permission_hex,
        known_permission_bits_decimal=known_decimal,
        known_permission_bits_hex=known_hex,
        unknown_permission_bits_decimal=unknown_decimal,
        unknown_permission_bits_hex=unknown_hex,
        included=included,
        reason_codes=tuple(sorted(set(reason_codes))),
    )


def evaluate_guild_permissions(
    request: PermissionEvaluationRequest,
) -> GuildPermissionEvaluationResult:
    """Evaluate the guild-level permission union without external side effects.

    The function never treats absent or invalid input as a zero-valued role.
    It may calculate a partial union from valid records, but the result is not
    marked complete unless every required input and the input-health assertion
    are explicitly complete.
    """

    reasons: set[str] = set()
    trace: list[PermissionTraceEvent] = []

    def add_trace(code: str, **details: Any) -> None:
        trace.append(
            PermissionTraceEvent(
                sequence=len(trace) + 1,
                code=code,
                details={key: details[key] for key in sorted(details)},
            )
        )

    guild_id = _parse_snowflake(request.guild_id)
    subject_id = _parse_snowflake(request.subject_id)
    if guild_id is None:
        reasons.add("GUILD_ID_INVALID")
    if subject_id is None:
        reasons.add("SUBJECT_ID_INVALID")
    add_trace(
        "INPUT_IDENTIFIERS_VALIDATED",
        guild_id=guild_id,
        subject_id=subject_id,
        guild_id_valid=guild_id is not None,
        subject_id_valid=subject_id is not None,
    )

    health_state, health_reason = _health_state(request.input_health)
    if health_reason:
        reasons.add(health_reason)
    add_trace("INPUT_HEALTH_ASSESSED", state=health_state, reason=health_reason)

    owner_id: str | None
    if request.guild_owner_id is None:
        owner_id = None
        reasons.add("OWNER_ID_MISSING")
    else:
        owner_id = _parse_snowflake(request.guild_owner_id)
        if owner_id is None:
            reasons.add("OWNER_ID_INVALID")

    permission_version = request.permission_definition_version
    if permission_version is None or not isinstance(permission_version, str) or not permission_version.strip():
        permission_version = None
        reasons.add("PERMISSION_DEFINITION_VERSION_MISSING")
    elif permission_version != PERMISSION_DEFINITION_VERSION:
        reasons.add("PERMISSION_DEFINITION_VERSION_MISMATCH")

    source_version = request.snapshot_or_fixture_version
    if source_version is None or not isinstance(source_version, str) or not source_version.strip():
        source_version = None
        reasons.add("SNAPSHOT_OR_FIXTURE_VERSION_MISSING")
    elif source_version not in SUPPORTED_SOURCE_VERSIONS:
        reasons.add("SNAPSHOT_OR_FIXTURE_VERSION_UNSUPPORTED")

    role_values = _record_sequence(request.role_records)
    invalid_role_references: list[str] = []
    missing_role_references: list[str] = []
    invalid_role_ids: set[str] = set()
    duplicate_role_ids: set[str] = set()
    role_index: dict[str, _RoleData] = {}

    if role_values is None:
        reasons.add("ROLE_RECORDS_MISSING")
        add_trace("ROLE_RECORDS_ASSESSED", state="MISSING", record_count=0)
    else:
        normalized_roles: list[_RoleData] = []
        for record in role_values:
            role_data = _normalize_role(record, guild_id)
            normalized_roles.append(role_data)
            if role_data.role_id is None:
                invalid_role_references.append(
                    _diagnostic_reference(_field(record, "id"))
                )
                reasons.update(role_data.reason_codes)
                continue
            if role_data.role_id in role_index:
                duplicate_role_ids.add(role_data.role_id)
                invalid_role_ids.add(role_data.role_id)
                reasons.add("DUPLICATE_NORMALIZED_ROLE_ID")
                continue
            role_index[role_data.role_id] = role_data
            if not role_data.valid:
                invalid_role_ids.add(role_data.role_id)
                invalid_role_references.append(role_data.role_id)
                reasons.update(role_data.reason_codes)

        for duplicate_id in duplicate_role_ids:
            role_index.pop(duplicate_id, None)
            invalid_role_references.append(duplicate_id)
        add_trace(
            "ROLE_RECORDS_ASSESSED",
            state="PRESENT",
            record_count=len(role_values),
            valid_record_count=sum(role.valid for role in normalized_roles),
            indexed_role_ids=sorted(role_index, key=lambda value: int(value)),
            duplicate_role_ids=sorted(duplicate_role_ids, key=lambda value: int(value)),
        )

    assigned_ids: list[str] = []
    invalid_assigned_ids: list[str] = []
    assigned_role_ids_known = request.assigned_role_ids is not None
    if request.assigned_role_ids is None:
        reasons.add("ASSIGNED_ROLE_IDS_MISSING")
        add_trace("ASSIGNED_ROLE_IDS_ASSESSED", state="MISSING", role_count=0)
    else:
        try:
            raw_assigned_ids = list(request.assigned_role_ids)
        except TypeError:
            raw_assigned_ids = [request.assigned_role_ids]
            reasons.add("ASSIGNED_ROLE_IDS_INVALID")
        for raw_role_id in raw_assigned_ids:
            role_id = _parse_snowflake(raw_role_id)
            if role_id is None:
                invalid_role_id = _diagnostic_reference(raw_role_id)
                invalid_assigned_ids.append(invalid_role_id)
                invalid_role_references.append(invalid_role_id)
                reasons.add("ASSIGNED_ROLE_ID_INVALID")
                reasons.add("INVALID_ROLE_REFERENCE")
                continue
            assigned_ids.append(role_id)
        if len(set(assigned_ids)) != len(assigned_ids):
            reasons.add("DUPLICATE_ASSIGNED_ROLE_ID")
        assigned_ids = sorted(set(assigned_ids), key=lambda value: int(value))
        add_trace(
            "ASSIGNED_ROLE_IDS_ASSESSED",
            state="PRESENT",
            role_count=len(assigned_ids),
            role_ids=assigned_ids,
        )

    contributions: list[PermissionRoleContribution] = []
    everyone_permission_value: int | None = None
    everyone_status = "UNAVAILABLE"
    if role_values is None:
        everyone_status = "UNKNOWN"
    elif guild_id is None:
        everyone_status = "UNKNOWN"
    elif guild_id not in role_index:
        reasons.add("EVERYONE_ROLE_MISSING")
        everyone_status = "MISSING"
    elif guild_id in invalid_role_ids:
        reasons.add("EVERYONE_ROLE_INVALID")
        everyone_status = "INVALID"
    else:
        everyone_data = role_index[guild_id]
        everyone_permission_value = everyone_data.permission_value
        if everyone_permission_value is None:
            reasons.add("EVERYONE_ROLE_INVALID")
            everyone_status = "INVALID"
        else:
            everyone_status = "RESOLVED"
    add_trace("EVERYONE_ROLE_RESOLVED", status=everyone_status)

    for role_id in assigned_ids:
        role_data = role_index.get(role_id)
        if role_id == guild_id and everyone_permission_value is not None:
            contributions.append(
                _make_contribution(
                    role_id,
                    everyone_permission_value,
                    included=True,
                    reason_codes=("EVERYONE_ROLE_ALREADY_INCLUDED",),
                )
            )
            continue
        if role_data is None:
            if role_id in invalid_role_ids or role_id in duplicate_role_ids:
                invalid_role_references.append(role_id)
                reasons.add("INVALID_ROLE_REFERENCE")
                contributions.append(
                    _make_contribution(
                        role_id,
                        None,
                        included=False,
                        reason_codes=("INVALID_ROLE_REFERENCE",),
                    )
                )
            else:
                missing_role_references.append(role_id)
                reasons.add("MISSING_ROLE_REFERENCE")
                contributions.append(
                    _make_contribution(
                        role_id,
                        None,
                        included=False,
                        reason_codes=("MISSING_ROLE_REFERENCE",),
                    )
                )
            continue
        if not role_data.valid or role_data.permission_value is None:
            invalid_role_references.append(role_id)
            reasons.add("INVALID_ROLE_REFERENCE")
            contributions.append(
                _make_contribution(
                    role_id,
                    None,
                    included=False,
                    reason_codes=("INVALID_ROLE_REFERENCE",) + role_data.reason_codes,
                )
            )
            continue
        contributions.append(
            _make_contribution(role_id, role_data.permission_value, included=True)
        )

    for role_id in sorted(set(invalid_assigned_ids), key=_reference_sort_key):
        contributions.append(
            _make_contribution(
                role_id,
                None,
                included=False,
                reason_codes=("ASSIGNED_ROLE_ID_INVALID", "INVALID_ROLE_REFERENCE"),
            )
        )

    contributions.sort(key=lambda contribution: _reference_sort_key(contribution.role_id))
    add_trace(
        "ASSIGNED_ROLE_CONTRIBUTIONS_RESOLVED",
        contribution_count=len(contributions),
        included_role_ids=[
            contribution.role_id
            for contribution in contributions
            if contribution.included
        ],
    )

    raw_permission_value: int | None = None
    if everyone_permission_value is not None:
        raw_permission_value = everyone_permission_value
        for contribution in contributions:
            if contribution.included and contribution.permission_decimal is not None:
                raw_permission_value |= int(contribution.permission_decimal)
        add_trace(
            "GUILD_PERMISSION_UNION_CALCULATED",
            raw_permission_decimal=str(raw_permission_value),
            raw_permission_hex=format(raw_permission_value, "#x"),
        )
    else:
        reasons.add("RAW_PERMISSION_UNAVAILABLE")
        add_trace("GUILD_PERMISSION_UNION_CALCULATED", state="UNAVAILABLE")

    if raw_permission_value is not None:
        administrator_detected = bool(raw_permission_value & ADMINISTRATOR_PERMISSION_BIT)
        if administrator_detected:
            reasons.add("ADMINISTRATOR_DETECTED")
            add_trace(
                "ADMINISTRATOR_DETECTED",
                permission_bit=ADMINISTRATOR_PERMISSION_BIT,
            )
        else:
            administrator_detected = False
    else:
        administrator_detected = False
        reasons.add("ADMINISTRATOR_STATE_UNKNOWN")

    if owner_id is not None and subject_id is not None and owner_id == subject_id:
        bypass_state = BYPASS_OWNER
        reasons.add("OWNER_BYPASS")
    elif administrator_detected:
        bypass_state = BYPASS_ADMINISTRATOR
        reasons.add("ADMINISTRATOR_BYPASS")
    else:
        bypass_state = BYPASS_NONE
        reasons.add("NO_BYPASS")
    add_trace("BYPASS_STATE_RESOLVED", bypass_state=bypass_state)

    if not assigned_role_ids_known or role_values is None:
        completeness_state = COMPLETENESS_UNKNOWN
    elif health_state == COMPLETENESS_UNKNOWN:
        completeness_state = COMPLETENESS_UNKNOWN
    elif (
        guild_id is None
        or subject_id is None
        or owner_id is None
        or permission_version != PERMISSION_DEFINITION_VERSION
        or source_version not in SUPPORTED_SOURCE_VERSIONS
        or everyone_permission_value is None
        or missing_role_references
        or invalid_role_references
        or health_state != COMPLETENESS_COMPLETE
        or reasons.intersection(
            {
                "GUILD_ID_INVALID",
                "SUBJECT_ID_INVALID",
                "OWNER_ID_INVALID",
                "OWNER_ID_MISSING",
                "ROLE_RECORDS_MISSING",
                "ASSIGNED_ROLE_IDS_MISSING",
                "EVERYONE_ROLE_MISSING",
                "EVERYONE_ROLE_INVALID",
                "PERMISSION_DEFINITION_VERSION_MISSING",
                "PERMISSION_DEFINITION_VERSION_MISMATCH",
                "SNAPSHOT_OR_FIXTURE_VERSION_MISSING",
                "SNAPSHOT_OR_FIXTURE_VERSION_UNSUPPORTED",
                "INPUT_HEALTH_INVALID",
                "INPUT_HEALTH_INCOMPLETE",
                "DUPLICATE_NORMALIZED_ROLE_ID",
                "ASSIGNED_ROLE_IDS_INVALID",
                "ASSIGNED_ROLE_ID_INVALID",
            }
        )
    ):
        completeness_state = COMPLETENESS_PARTIAL
    else:
        completeness_state = COMPLETENESS_COMPLETE
        reasons.add("CALCULATION_COMPLETE")
    add_trace("COMPLETENESS_RESOLVED", state=completeness_state)

    (
        everyone_decimal,
        everyone_hex,
        _everyone_known_decimal,
        _everyone_known_hex,
        _everyone_unknown_decimal,
        _everyone_unknown_hex,
    ) = _permission_parts(everyone_permission_value)
    (
        raw_decimal,
        raw_hex,
        known_decimal,
        known_hex,
        unknown_decimal,
        unknown_hex,
    ) = _permission_parts(raw_permission_value)

    add_trace("RESULT_FINALIZED", completeness_state=completeness_state)
    return GuildPermissionEvaluationResult(
        guild_id=guild_id,
        guild_owner_id=owner_id,
        subject_id=subject_id,
        assigned_role_ids=tuple(assigned_ids),
        bypass_state=bypass_state,
        everyone_permission_decimal=everyone_decimal,
        everyone_permission_hex=everyone_hex,
        assigned_role_contributions=tuple(contributions),
        raw_guild_permission_decimal=raw_decimal,
        raw_guild_permission_hex=raw_hex,
        known_permission_bits_decimal=known_decimal,
        known_permission_bits_hex=known_hex,
        unknown_permission_bits_decimal=unknown_decimal,
        unknown_permission_bits_hex=unknown_hex,
        missing_role_references=_unique_sorted(missing_role_references),
        invalid_role_references=tuple(
            sorted(set(invalid_role_references), key=_reference_sort_key)
        ),
        completeness_state=completeness_state,
        input_health_state=health_state,
        reason_codes=tuple(sorted(reasons)),
        trace=tuple(trace),
        engine_contract_version=STAGE3_PASS1_ENGINE_CONTRACT_VERSION,
        permission_definition_version=permission_version,
        snapshot_or_fixture_version=source_version,
    )


__all__ = [
    "ADMINISTRATOR_PERMISSION_BIT",
    "BYPASS_ADMINISTRATOR",
    "BYPASS_NONE",
    "BYPASS_OWNER",
    "COMPLETENESS_COMPLETE",
    "COMPLETENESS_PARTIAL",
    "COMPLETENESS_UNKNOWN",
    "GuildPermissionEvaluationResult",
    "PermissionEvaluationRequest",
    "PermissionRoleContribution",
    "PermissionTraceEvent",
    "STAGE3_PASS1_ENGINE_CONTRACT_VERSION",
    "SUPPORTED_SOURCE_VERSIONS",
    "evaluate_guild_permissions",
]
