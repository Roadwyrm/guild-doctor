"""Pure readiness assessment for a future disposable-guild sync."""
from __future__ import annotations
from dataclasses import dataclass
DEPLOYMENT_READINESS_CONTRACT="GUILD-DOCTOR-DISCORD-DEPLOYMENT-READINESS-0.1"
READINESS_STATES=("NOT_READY","READY_FOR_LOCAL_DRY_RUN","READY_FOR_DISPOSABLE_SYNC","BLOCKED_MANIFEST","BLOCKED_PROVENANCE","BLOCKED_TESTS","BLOCKED_SCOPE","BLOCKED_SECURITY","BLOCKED_PACKAGE","INTERNAL_ERROR")
@dataclass(frozen=True)
class ReadinessInput:
 manifest_valid:bool; schema_deterministic:bool; provenance_pass:bool; tests_pass:bool; scope_clean:bool; package_version:str; project_sources_count:int; protected_evidence_pass:bool; sync_guard_ready:bool
def assess(value:ReadinessInput)->str:
 if not value.manifest_valid or not value.schema_deterministic:return "BLOCKED_MANIFEST"
 if not value.provenance_pass:return "BLOCKED_PROVENANCE"
 if not value.tests_pass:return "BLOCKED_TESTS"
 if not value.scope_clean:return "BLOCKED_SCOPE"
 if value.package_version!="0.5.1" or value.project_sources_count!=25:return "BLOCKED_PACKAGE"
 if not value.protected_evidence_pass:return "BLOCKED_SECURITY"
 return "READY_FOR_DISPOSABLE_SYNC" if value.sync_guard_ready else "READY_FOR_LOCAL_DRY_RUN"
