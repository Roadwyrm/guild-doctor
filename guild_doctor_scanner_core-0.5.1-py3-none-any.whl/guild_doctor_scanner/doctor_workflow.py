"""Immutable Stage 5 Pass 4 workflow-plan contract.

This module is intentionally a local validation boundary.  It accepts only an
explicit workflow kind and one frozen Stage 5 query shape; it neither acquires
Discord data nor chooses a workflow from arbitrary input.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .canonical import canonical_json
from .constants import PERMISSION_DEFINITION_VERSION
from .doctor_enumeration_query import (
    ENUMERATION_QUERY_CONTRACT_VERSION,
    STAGE5_PASS2_CONTRACT_VERSION,
    DoctorEnumerationQuery,
    validate_enumeration_query,
)
from .doctor_query import (
    DOCTOR_QUERY_CONTRACT_VERSION,
    STAGE5_PASS1_CONTRACT_VERSION,
    DoctorQuery,
    validate_doctor_query,
)
from .doctor_role_comparison_query import RoleComparisonQuery, validate_role_comparison_query
from .doctor_source_query import (
    ROLE_COMPARISON_QUERY_CONTRACT_VERSION,
    SOURCE_LOCATION_QUERY_CONTRACT_VERSION,
    STAGE5_PASS3_CONTRACT_VERSION,
    SourceLocationQuery,
    validate_source_location_query,
)
from .explanation_query import EXPLANATION_QUERY_CONTRACT_VERSION, STAGE4_PASS3_CONTRACT_VERSION


STAGE5_PASS4_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE5-PASS4-0.1"
DOCTOR_WORKFLOW_CONTRACT_VERSION = "GUILD-DOCTOR-DOCTOR-WORKFLOW-0.1"

WHY = "WHY"
ENUMERATION = "ENUMERATION"
SOURCE_LOCATION = "SOURCE_LOCATION"
ROLE_COMPARISON = "ROLE_COMPARISON"
WORKFLOW_KINDS = (WHY, ENUMERATION, SOURCE_LOCATION, ROLE_COMPARISON)

DIRECT_QUERY = "DIRECT_QUERY"
GUIDED_SELECTION = "GUIDED_SELECTION"
SCRIPTED_GUIDED_SELECTION = "SCRIPTED_GUIDED_SELECTION"
SOURCE_MODES = frozenset({DIRECT_QUERY, GUIDED_SELECTION, SCRIPTED_GUIDED_SELECTION})

SIMPLE = "SIMPLE"
DETAILED = "DETAILED"
TECHNICAL = "TECHNICAL"
EXPLANATION_MODES = frozenset({SIMPLE, DETAILED, TECHNICAL})
PLAIN_TEXT = "PLAIN_TEXT"
DISCORD_MARKDOWN = "DISCORD_MARKDOWN"
STRUCTURED_JSON = "STRUCTURED_JSON"
OUTPUT_FORMATS = frozenset({PLAIN_TEXT, DISCORD_MARKDOWN, STRUCTURED_JSON})
FAIL_FAST = "FAIL_FAST"
CONTINUE_WITH_REPORT = "CONTINUE_WITH_REPORT"
FAILURE_POLICIES = frozenset({FAIL_FAST, CONTINUE_WITH_REPORT})

_SECRET_FRAGMENTS = ("token", "authorization", "access_token", "client_secret", "password", "api_key", "credential")
_FORBIDDEN_FIELD_FRAGMENTS = (
    "environment",
    "database",
    "interaction",
    "callback",
    "command_registration",
    "application_command",
    "recommendation",
    "remediation",
    "repair",
    "risk",
    "stage6",
    "stage_6",
    "audit_request",
    "natural_language",
    "question_text",
    "prompt",
    "output_path",
    "output_directory",
)
_FORBIDDEN_FIELD_NAMES = frozenset({"connection", "network", "url", "endpoint", "network_url", "database_connection"})
_TOKEN_SHAPE = re.compile(r"^[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{8,}$")


class DoctorWorkflowError(ValueError):
    """Raised for strict workflow-plan construction failures."""


def _text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def _upper(value: Any) -> str | None:
    value = _text(value)
    return value.upper() if value else None


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int) and value > 0:
        return str(value)
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _freeze(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        value = method()
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(value[key]) for key in sorted(value, key=lambda item: str(item))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(item) for item in sorted(value, key=str))
    return deepcopy(value)


def thaw_workflow(value: Any) -> Any:
    """Return a detached JSON-compatible representation of a frozen value."""

    if isinstance(value, Mapping):
        return {str(key): thaw_workflow(child) for key, child in value.items()}
    if isinstance(value, (tuple, list)):
        return [thaw_workflow(child) for child in value]
    return deepcopy(value)


def _tuple_text(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (value.strip(),) if value.strip() else ()
    if isinstance(value, Mapping):
        value = value.values()
    try:
        return tuple(sorted({str(item).strip() for item in value if str(item).strip()}))
    except TypeError:
        return ()


def _scan_forbidden(value: Any, path: str = "workflow") -> tuple[str, ...]:
    errors: list[str] = []
    if callable(value):
        errors.append(f"WORKFLOW_FORBIDDEN_EXECUTABLE:{path}")
    elif isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            lower = key_text.lower()
            child_path = f"{path}.{key_text}"
            if any(fragment in lower for fragment in _SECRET_FRAGMENTS):
                errors.append(f"WORKFLOW_CREDENTIAL_FIELD:{child_path}")
            if lower in _FORBIDDEN_FIELD_NAMES or any(fragment in lower for fragment in _FORBIDDEN_FIELD_FRAGMENTS):
                errors.append(f"WORKFLOW_FORBIDDEN_FIELD:{child_path}")
            errors.extend(_scan_forbidden(child, child_path))
    elif isinstance(value, (list, tuple, set, frozenset)):
        for index, child in enumerate(value):
            errors.extend(_scan_forbidden(child, f"{path}[{index}]"))
    elif isinstance(value, str):
        if _TOKEN_SHAPE.fullmatch(value.strip()) or value.strip().lower().startswith("bot "):
            errors.append(f"WORKFLOW_CREDENTIAL_VALUE:{path}")
    return tuple(sorted(set(errors)))


def _query_contract(workflow_kind: str) -> tuple[str, str, type[Any], Any]:
    if workflow_kind == WHY:
        return DOCTOR_QUERY_CONTRACT_VERSION, STAGE5_PASS1_CONTRACT_VERSION, DoctorQuery, validate_doctor_query
    if workflow_kind == ENUMERATION:
        return ENUMERATION_QUERY_CONTRACT_VERSION, STAGE5_PASS2_CONTRACT_VERSION, DoctorEnumerationQuery, validate_enumeration_query
    if workflow_kind == SOURCE_LOCATION:
        return SOURCE_LOCATION_QUERY_CONTRACT_VERSION, STAGE5_PASS3_CONTRACT_VERSION, SourceLocationQuery, validate_source_location_query
    if workflow_kind == ROLE_COMPARISON:
        return ROLE_COMPARISON_QUERY_CONTRACT_VERSION, STAGE5_PASS3_CONTRACT_VERSION, RoleComparisonQuery, validate_role_comparison_query
    raise DoctorWorkflowError("WORKFLOW_KIND_UNKNOWN")


def _query_type_name(query: Any) -> str:
    return type(query).__name__


@dataclass(frozen=True, slots=True)
class DoctorWorkflowPlan:
    """One immutable, explicit local Permission Doctor workflow plan."""

    workflow_id: str
    workflow_kind: str
    source_mode: str
    guild_id: str | int | None
    normalized_query: Mapping[str, Any] | DoctorQuery | DoctorEnumerationQuery | SourceLocationQuery | RoleComparisonQuery
    snapshot_source_reference: str | None = None
    evidence_classifications: tuple[str, ...] = ()
    verification_statuses: tuple[str, ...] = ()
    explanation_mode: str = SIMPLE
    presentation_profile: str = "SIMPLE_CARD"
    output_format: str = PLAIN_TEXT
    disclosure_policy: str = "SAFE_DEFAULT"
    display_safe_labels: Mapping[str, str] | None = None
    title: str | None = None
    section_policy: Mapping[str, Any] | None = None
    validate_only: bool = False
    require_review_confirmation: bool = True
    confirmed: bool = False
    overwrite_output: bool = False
    failure_policy: str = FAIL_FAST
    maximum_output_size: int | None = None
    selector_session_fingerprint: str | None = None
    workflow_contract_version: str = DOCTOR_WORKFLOW_CONTRACT_VERSION
    stage5_pass4_contract_version: str = STAGE5_PASS4_CONTRACT_VERSION
    expected_stage4_contract: str = STAGE4_PASS3_CONTRACT_VERSION
    expected_explanation_query_contract: str = EXPLANATION_QUERY_CONTRACT_VERSION
    permission_definition_version: str = PERMISSION_DEFINITION_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "workflow_id", _text(self.workflow_id) or "")
        object.__setattr__(self, "workflow_kind", _upper(self.workflow_kind) or "")
        object.__setattr__(self, "source_mode", _upper(self.source_mode) or "")
        object.__setattr__(self, "guild_id", _snowflake(self.guild_id))
        object.__setattr__(self, "snapshot_source_reference", _text(self.snapshot_source_reference))
        object.__setattr__(self, "explanation_mode", _upper(self.explanation_mode) or "")
        object.__setattr__(self, "presentation_profile", _upper(self.presentation_profile) or "")
        object.__setattr__(self, "output_format", _upper(self.output_format) or "")
        object.__setattr__(self, "disclosure_policy", _upper(self.disclosure_policy) or "")
        object.__setattr__(self, "failure_policy", _upper(self.failure_policy) or "")
        object.__setattr__(self, "title", _text(self.title))
        object.__setattr__(self, "selector_session_fingerprint", _text(self.selector_session_fingerprint))
        object.__setattr__(self, "normalized_query", _freeze(self.normalized_query))
        object.__setattr__(self, "display_safe_labels", _freeze(self.display_safe_labels or {}))
        object.__setattr__(self, "section_policy", _freeze(self.section_policy or {}))
        object.__setattr__(self, "evidence_classifications", _tuple_text(self.evidence_classifications))
        object.__setattr__(self, "verification_statuses", _tuple_text(self.verification_statuses))
        if self.maximum_output_size is not None:
            try:
                object.__setattr__(self, "maximum_output_size", int(self.maximum_output_size))
            except (TypeError, ValueError):
                object.__setattr__(self, "maximum_output_size", -1)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "DoctorWorkflowPlan":
        if not isinstance(value, Mapping):
            raise DoctorWorkflowError("WORKFLOW_NOT_MAPPING")
        return cls(
            workflow_id=value.get("workflow_id", ""),
            workflow_kind=value.get("workflow_kind", ""),
            source_mode=value.get("source_mode", DIRECT_QUERY),
            guild_id=value.get("guild_id"),
            normalized_query=value.get("normalized_query", value.get("query")),
            snapshot_source_reference=value.get("snapshot_source_reference"),
            evidence_classifications=value.get("evidence_classifications", ()),
            verification_statuses=value.get("verification_statuses", ()),
            explanation_mode=value.get("explanation_mode", SIMPLE),
            presentation_profile=value.get("presentation_profile", "SIMPLE_CARD"),
            output_format=value.get("output_format", PLAIN_TEXT),
            disclosure_policy=value.get("disclosure_policy", "SAFE_DEFAULT"),
            display_safe_labels=value.get("display_safe_labels", value.get("labels", {})),
            title=value.get("title"),
            section_policy=value.get("section_policy", {}),
            validate_only=value.get("validate_only", False),
            require_review_confirmation=value.get("require_review_confirmation", True),
            confirmed=value.get("confirmed", False),
            overwrite_output=value.get("overwrite_output", False),
            failure_policy=value.get("failure_policy", FAIL_FAST),
            maximum_output_size=value.get("maximum_output_size"),
            selector_session_fingerprint=value.get("selector_session_fingerprint"),
            workflow_contract_version=value.get("workflow_contract_version", DOCTOR_WORKFLOW_CONTRACT_VERSION),
            stage5_pass4_contract_version=value.get("stage5_pass4_contract_version", STAGE5_PASS4_CONTRACT_VERSION),
            expected_stage4_contract=value.get("expected_stage4_contract", STAGE4_PASS3_CONTRACT_VERSION),
            expected_explanation_query_contract=value.get("expected_explanation_query_contract", EXPLANATION_QUERY_CONTRACT_VERSION),
            permission_definition_version=value.get("permission_definition_version", PERMISSION_DEFINITION_VERSION),
        )

    def as_dict(self) -> dict[str, Any]:
        expected_query_contract, expected_pass_contract, _, _ = _query_contract(self.workflow_kind) if self.workflow_kind in WORKFLOW_KINDS else (None, None, None, None)
        data = {
            "stage5_pass4_contract_version": self.stage5_pass4_contract_version,
            "workflow_contract_version": self.workflow_contract_version,
            "workflow_id": self.workflow_id,
            "workflow_kind": self.workflow_kind,
            "source_mode": self.source_mode,
            "guild_id": self.guild_id,
            "snapshot_source_reference": self.snapshot_source_reference,
            "normalized_query": thaw_workflow(self.normalized_query),
            "normalized_query_contract": expected_query_contract,
            "expected_stage5_contract": expected_pass_contract,
            "expected_stage4_contract": self.expected_stage4_contract,
            "expected_explanation_query_contract": self.expected_explanation_query_contract,
            "permission_definition_version": self.permission_definition_version,
            "evidence_classifications": list(self.evidence_classifications),
            "verification_statuses": list(self.verification_statuses),
            "explanation_mode": self.explanation_mode,
            "presentation_profile": self.presentation_profile,
            "output_format": self.output_format,
            "disclosure_policy": self.disclosure_policy,
            "display_safe_labels": thaw_workflow(self.display_safe_labels),
            "title": self.title,
            "section_policy": thaw_workflow(self.section_policy),
            "validate_only": self.validate_only,
            "require_review_confirmation": self.require_review_confirmation,
            "confirmed": self.confirmed,
            "overwrite_output": self.overwrite_output,
            "failure_policy": self.failure_policy,
            "maximum_output_size": self.maximum_output_size,
            "selector_session_fingerprint": self.selector_session_fingerprint,
        }
        data["normalized_query_fingerprint"] = hashlib.sha256(canonical_json(data["normalized_query"]).encode("utf-8")).hexdigest()
        fingerprint_payload = dict(data)
        data["workflow_plan_fingerprint"] = hashlib.sha256(canonical_json(fingerprint_payload).encode("utf-8")).hexdigest()
        return data


def _parse_query(plan: DoctorWorkflowPlan) -> tuple[Any | None, tuple[str, ...]]:
    try:
        _, _, query_type, validator = _query_contract(plan.workflow_kind)
        raw = thaw_workflow(plan.normalized_query)
        if not isinstance(raw, Mapping):
            return None, ("WORKFLOW_NORMALIZED_QUERY_NOT_MAPPING",)
        query = query_type.from_mapping(raw)
        return query, tuple(validator(query))
    except (DoctorWorkflowError, TypeError, ValueError) as exc:
        return None, (f"WORKFLOW_QUERY_CONSTRUCTION:{type(exc).__name__}",)


def validate_doctor_workflow(value: DoctorWorkflowPlan | Mapping[str, Any]) -> tuple[str, ...]:
    """Validate a plan without filesystem, Discord, or network effects."""

    errors: list[str] = []
    if isinstance(value, DoctorWorkflowPlan):
        plan = value
        raw = plan.as_dict()
    elif isinstance(value, Mapping):
        raw = value
        try:
            plan = DoctorWorkflowPlan.from_mapping(value)
        except (TypeError, ValueError) as exc:
            return (f"WORKFLOW_CONSTRUCTION:{type(exc).__name__}",)
    else:
        return ("WORKFLOW_NOT_MAPPING",)
    errors.extend(_scan_forbidden(raw))
    if plan.stage5_pass4_contract_version != STAGE5_PASS4_CONTRACT_VERSION:
        errors.append("WORKFLOW_STAGE5_PASS4_CONTRACT_UNSUPPORTED")
    if plan.workflow_contract_version != DOCTOR_WORKFLOW_CONTRACT_VERSION:
        errors.append("WORKFLOW_CONTRACT_UNSUPPORTED")
    if not plan.workflow_id or any(part in plan.workflow_id for part in ("..", "\\", "/")):
        errors.append("WORKFLOW_ID_INVALID")
    if plan.workflow_kind not in WORKFLOW_KINDS:
        errors.append("WORKFLOW_KIND_UNKNOWN")
        return tuple(sorted(set(errors)))
    if plan.source_mode not in SOURCE_MODES:
        errors.append("WORKFLOW_SOURCE_MODE_UNSUPPORTED")
    if _snowflake(plan.guild_id) is None:
        errors.append("WORKFLOW_GUILD_ID_INVALID")
    if plan.explanation_mode not in EXPLANATION_MODES:
        errors.append("WORKFLOW_EXPLANATION_MODE_UNSUPPORTED")
    if plan.output_format not in OUTPUT_FORMATS:
        errors.append("WORKFLOW_OUTPUT_FORMAT_UNSUPPORTED")
    if plan.failure_policy not in FAILURE_POLICIES:
        errors.append("WORKFLOW_FAILURE_POLICY_UNSUPPORTED")
    if not isinstance(plan.validate_only, bool) or not isinstance(plan.require_review_confirmation, bool) or not isinstance(plan.confirmed, bool):
        errors.append("WORKFLOW_BOOLEAN_POLICY_INVALID")
    if plan.maximum_output_size is not None and (not isinstance(plan.maximum_output_size, int) or plan.maximum_output_size < 256):
        errors.append("WORKFLOW_MAXIMUM_OUTPUT_SIZE_INVALID")
    if plan.expected_stage4_contract != STAGE4_PASS3_CONTRACT_VERSION:
        errors.append("WORKFLOW_STAGE4_CONTRACT_MISMATCH")
    if plan.expected_explanation_query_contract != EXPLANATION_QUERY_CONTRACT_VERSION:
        errors.append("WORKFLOW_EXPLANATION_QUERY_CONTRACT_MISMATCH")
    if plan.permission_definition_version != PERMISSION_DEFINITION_VERSION:
        errors.append("WORKFLOW_PERMISSION_DEFINITION_MISMATCH")
    query, query_errors = _parse_query(plan)
    errors.extend(f"WORKFLOW_QUERY:{item}" for item in query_errors)
    if query is not None:
        query_guild = _snowflake(getattr(query, "guild_id", None))
        if query_guild is None and hasattr(query, "doctor_query"):
            query_guild = _snowflake(getattr(getattr(query, "doctor_query"), "guild_id", None))
        if query_guild != plan.guild_id:
            errors.append("WORKFLOW_GUILD_QUERY_MISMATCH")
        query_mode = _upper(getattr(query, "explanation_mode", None))
        if query_mode and query_mode != plan.explanation_mode:
            errors.append("WORKFLOW_EXPLANATION_MODE_QUERY_MISMATCH")
        query_format = _upper(getattr(query, "output_format", None))
        if query_format and query_format != plan.output_format:
            errors.append("WORKFLOW_OUTPUT_FORMAT_QUERY_MISMATCH")
    if plan.require_review_confirmation and not plan.confirmed and not plan.validate_only:
        errors.append("WORKFLOW_CONFIRMATION_REQUIRED")
    return tuple(sorted(set(errors)))


def build_workflow_plan(
    *,
    workflow_id: str,
    workflow_kind: str,
    normalized_query: Mapping[str, Any] | DoctorQuery | DoctorEnumerationQuery | SourceLocationQuery | RoleComparisonQuery,
    source_mode: str = DIRECT_QUERY,
    confirmed: bool = True,
    **policies: Any,
) -> DoctorWorkflowPlan:
    """Build an immutable plan and fail closed if its contract is malformed."""

    raw_query = thaw_workflow(normalized_query)
    guild_id = raw_query.get("guild_id") if isinstance(raw_query, Mapping) else None
    if guild_id is None and isinstance(raw_query, Mapping) and isinstance(raw_query.get("doctor_query"), Mapping):
        guild_id = raw_query["doctor_query"].get("guild_id")
    plan = DoctorWorkflowPlan(
        workflow_id=workflow_id,
        workflow_kind=workflow_kind,
        source_mode=source_mode,
        guild_id=guild_id,
        normalized_query=raw_query,
        confirmed=confirmed,
        explanation_mode=policies.pop("explanation_mode", raw_query.get("explanation_mode", raw_query.get("aggregate_explanation_mode", SIMPLE)) if isinstance(raw_query, Mapping) else SIMPLE),
        presentation_profile=policies.pop("presentation_profile", raw_query.get("presentation_profile", "SIMPLE_CARD") if isinstance(raw_query, Mapping) else "SIMPLE_CARD"),
        output_format=policies.pop("output_format", raw_query.get("output_format", PLAIN_TEXT) if isinstance(raw_query, Mapping) else PLAIN_TEXT),
        **policies,
    )
    errors = validate_doctor_workflow(plan)
    if errors:
        raise DoctorWorkflowError(";".join(errors))
    return plan


__all__ = [
    "CONTINUE_WITH_REPORT", "DETAILED", "DIRECT_QUERY", "DISCORD_MARKDOWN", "DOCTOR_WORKFLOW_CONTRACT_VERSION",
    "DoctorWorkflowError", "DoctorWorkflowPlan", "ENUMERATION", "EXPLANATION_MODES", "FAIL_FAST", "GUIDED_SELECTION",
    "OUTPUT_FORMATS", "PLAIN_TEXT", "ROLE_COMPARISON", "SCRIPTED_GUIDED_SELECTION", "SIMPLE", "SOURCE_LOCATION",
    "SOURCE_MODES", "STAGE5_PASS4_CONTRACT_VERSION", "STRUCTURED_JSON", "TECHNICAL", "WHY", "WORKFLOW_KINDS",
    "build_workflow_plan", "thaw_workflow", "validate_doctor_workflow",
]
