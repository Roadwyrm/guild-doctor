"""Targeted and temporary exhaustive guild-member acquisition.

Stage 2 Pass 3 stays REST-only. Targeted member reads use Discord's single-member
GET endpoint. Exhaustive enumeration uses the privileged List Guild Members GET
endpoint with deterministic ``after`` pagination. Member payloads are minimized
before entering Guild Doctor's bundle: only stable IDs, role IDs, timeout state, bot
state, pending state, and an evidence hash are retained.
"""

from __future__ import annotations

import asyncio
import copy
import math
from dataclasses import asdict, dataclass, field
from typing import Any, Awaitable, Callable, Protocol

from .acquisition import (
    AcquisitionResult,
    RetryPolicy,
    ScanError,
    StructureAcquisition,
    classify_exception,
    payload_sha256,
    utc_now,
)
from .enums import CollectionStatus
from .errors import SnapshotError
from .normalizer import normalize_bundle

_JSON = dict[str, Any]

GATEWAY_GUILD_MEMBERS = 1 << 14
GATEWAY_GUILD_MEMBERS_LIMITED = 1 << 15


@dataclass(slots=True)
class MemberIntentCapabilityReport:
    """Application-level evidence for HTTP/Gateway member-list access.

    Application flags show whether the privileged member intent is configured or
    approved. They do not replace the endpoint result, so the actual HTTP outcome
    is recorded separately.
    """

    state: str
    application_flags_decimal: str | None
    gateway_guild_members: bool | None
    gateway_guild_members_limited: bool | None
    list_members_expected_authorized: bool | None
    list_members_endpoint_result: str = "NOT_ATTEMPTED"
    source: str = "APPLICATION_FLAGS"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class MemberEnumerationPolicy:
    page_size: int = 1000
    max_pages: int = 10_000
    max_members: int = 10_000_000

    def __post_init__(self) -> None:
        if not 1 <= self.page_size <= 1000:
            raise ValueError("page_size must be between 1 and 1000")
        if self.max_pages < 1:
            raise ValueError("max_pages must be positive")
        if self.max_members < 1:
            raise ValueError("max_members must be positive")


@dataclass(slots=True)
class MemberAcquisition:
    guild_id: str
    scan_profile: str
    started_at: str
    completed_at: str
    results: dict[str, AcquisitionResult]
    bundle: dict[str, Any]
    snapshot: Any | None
    capability_report: MemberIntentCapabilityReport
    normalization_error: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.snapshot is not None


@dataclass(slots=True)
class RetentionReceipt:
    lifecycle: str
    guild_id: str
    scan_profile: str
    acquired_member_count: int
    disposed_at: str
    member_records_retained: int
    member_payload_hashes_retained: int
    note: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class TemporaryMemberLease:
    """In-memory lease for exhaustive member records.

    The caller performs the approved calculation while the lease is active and
    then calls ``dispose`` (or uses ``async with``). Disposal drops normalized
    members, minimized raw members, and member payload hashes. Aggregate health,
    counts, errors, and a non-identifying receipt remain available.
    """

    __slots__ = ("acquisition", "_disposed", "_receipt")

    def __init__(self, acquisition: MemberAcquisition) -> None:
        self.acquisition = acquisition
        self._disposed = False
        self._receipt: RetentionReceipt | None = None

    @property
    def disposed(self) -> bool:
        return self._disposed

    @property
    def receipt(self) -> RetentionReceipt | None:
        return self._receipt

    async def __aenter__(self) -> MemberAcquisition:
        if self._disposed:
            raise RuntimeError("temporary member lease has already been disposed")
        return self.acquisition

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.dispose()

    def dispose(self) -> RetentionReceipt:
        if self._receipt is not None:
            return self._receipt

        result = self.acquisition.results.get("members")
        count = result.received_count if result and result.received_count is not None else 0

        if result is not None:
            result.records = None
            result.raw_payload_hashes.clear()
        self.acquisition.bundle["members"] = None
        if self.acquisition.snapshot is not None:
            self.acquisition.snapshot.members = None
            self.acquisition.snapshot.counts["members"] = None
        # The member-bearing snapshot fingerprint is no longer valid after
        # disposal. Drop the snapshot rather than exposing a mutated artifact.
        self.acquisition.snapshot = None

        self._disposed = True
        self._receipt = RetentionReceipt(
            lifecycle="DISPOSED",
            guild_id=self.acquisition.guild_id,
            scan_profile=self.acquisition.scan_profile,
            acquired_member_count=count,
            disposed_at=utc_now(),
            member_records_retained=0,
            member_payload_hashes_retained=0,
            note="Temporary member profiles and member payload hashes were discarded.",
        )
        return self._receipt


class ReadOnlyMemberTransport(Protocol):
    source_library: str
    source_library_version: str
    source_api_version: str
    adapter_version: str
    application_flags_value: int | None

    async def read_member(self, guild_id: int, member_id: int) -> _JSON: ...

    async def read_members_page(self, guild_id: int, *, limit: int, after: int | None) -> list[_JSON]: ...


@dataclass(slots=True)
class _CallOutcome:
    payload: Any | None
    errors: list[ScanError]
    attempts: int
    status: str


class ReadOnlyMemberAcquisitionAdapter:
    """Add targeted and temporary member acquisition to a structural adapter."""

    __slots__ = ("_transport", "_structure", "_retry", "_sleep", "_enumeration", "_operation_timeout_seconds")

    def __init__(
        self,
        transport: ReadOnlyMemberTransport,
        structure_adapter: Any,
        *,
        retry_policy: RetryPolicy | None = None,
        enumeration_policy: MemberEnumerationPolicy | None = None,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
        operation_timeout_seconds: float = 30.0,
    ) -> None:
        timeout = float(operation_timeout_seconds)
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("operation_timeout_seconds must be a finite positive number")
        self._transport = transport
        self._structure = structure_adapter
        self._retry = retry_policy or RetryPolicy()
        self._enumeration = enumeration_policy or MemberEnumerationPolicy()
        self._sleep = sleep
        self._operation_timeout_seconds = timeout

    def capability_report(self) -> MemberIntentCapabilityReport:
        flags = self._transport.application_flags_value
        if flags is None:
            return MemberIntentCapabilityReport(
                state="UNKNOWN",
                application_flags_decimal=None,
                gateway_guild_members=None,
                gateway_guild_members_limited=None,
                list_members_expected_authorized=None,
                source="APPLICATION_FLAGS_UNAVAILABLE",
            )
        full = bool(flags & GATEWAY_GUILD_MEMBERS)
        limited = bool(flags & GATEWAY_GUILD_MEMBERS_LIMITED)
        enabled = full or limited
        return MemberIntentCapabilityReport(
            state="ENABLED" if enabled else "DISABLED",
            application_flags_decimal=str(flags),
            gateway_guild_members=full,
            gateway_guild_members_limited=limited,
            list_members_expected_authorized=enabled,
        )

    async def acquire_targeted_members(
        self, guild_id: int | str, member_ids: list[int | str] | tuple[int | str, ...]
    ) -> MemberAcquisition:
        guild_int = self._parse_snowflake(guild_id, "guild_id")
        targets = self._parse_member_ids(member_ids)
        started_at = utc_now()
        structure = await self._structure.acquire_structure(guild_int)
        member_result = await self._targeted_collection(guild_int, targets)
        capability = self.capability_report()
        return self._finalize(
            structure,
            profile="TARGETED_MEMBER",
            member_result=member_result,
            capability=capability,
            started_at=started_at,
            member_metadata={
                "mode": "TARGETED_MEMBER",
                "requested_member_count": len(targets),
                "temporary": False,
                "gateway_chunking_used": False,
            },
        )

    async def enumerate_members_temporary(self, guild_id: int | str) -> TemporaryMemberLease:
        guild_int = self._parse_snowflake(guild_id, "guild_id")
        started_at = utc_now()
        structure = await self._structure.acquire_structure(guild_int)
        capability = self.capability_report()
        member_result, enum_metadata = await self._enumerate_collection(guild_int, capability)
        acquisition = self._finalize(
            structure,
            profile="WHO_CAN_TEMPORARY",
            member_result=member_result,
            capability=capability,
            started_at=started_at,
            member_metadata=enum_metadata,
        )
        return TemporaryMemberLease(acquisition)

    async def _targeted_collection(self, guild_id: int, member_ids: list[int]) -> AcquisitionResult:
        requested_at = utc_now()
        records: list[dict[str, Any]] = []
        errors: list[ScanError] = []
        total_attempts = 0
        hashes: list[str] = []

        for member_id in member_ids:
            outcome = await self._call(lambda member_id=member_id: self._transport.read_member(guild_id, member_id))
            total_attempts += outcome.attempts
            for error in outcome.errors:
                error.entity_id = str(member_id)
                errors.append(error)
            if outcome.payload is None:
                continue
            if not isinstance(outcome.payload, dict):
                errors.append(
                    ScanError(
                        code="RESPONSE_SHAPE_INVALID",
                        error_type="TypeError",
                        message="targeted member response must be an object",
                        retryable=False,
                        attempt=outcome.attempts,
                        entity_id=str(member_id),
                    )
                )
                continue
            minimized, digest = minimize_member_payload(outcome.payload)
            records.append(minimized)
            hashes.append(digest)

        if len(records) == len(member_ids):
            status = CollectionStatus.COMPLETE.value
        elif records:
            status = CollectionStatus.PARTIAL.value
        elif errors and all(e.code in {"AUTHORIZATION_DENIED", "RESOURCE_NOT_FOUND"} for e in errors):
            status = CollectionStatus.UNAVAILABLE.value
        else:
            status = CollectionStatus.FAILED.value

        return AcquisitionResult(
            resource="members",
            status=status,
            requested_at=requested_at,
            completed_at=utc_now(),
            records=records if records else None,
            expected_count=len(member_ids),
            received_count=len(records),
            page_count=None,
            cursor_complete=len(records) == len(member_ids),
            source_interface="REST",
            source_version=self._source_version,
            http_or_library_status="OK" if status == CollectionStatus.COMPLETE.value else None,
            errors=errors,
            raw_payload_hashes=hashes,
            attempt_count=max(total_attempts, 1),
        )

    async def _enumerate_collection(
        self, guild_id: int, capability: MemberIntentCapabilityReport
    ) -> tuple[AcquisitionResult, dict[str, Any]]:
        requested_at = utc_now()
        metadata: dict[str, Any] = {
            "mode": "WHO_CAN_TEMPORARY",
            "temporary": True,
            "page_size": self._enumeration.page_size,
            "gateway_chunking_used": False,
            "gateway_chunk_reconciliation": "NOT_APPLICABLE_REST_ENUMERATION",
            "application_capability": capability.as_dict(),
        }

        if capability.list_members_expected_authorized is False:
            capability.list_members_endpoint_result = "NOT_ATTEMPTED_DISABLED"
            error = ScanError(
                code="MEMBER_INTENT_UNAVAILABLE",
                error_type="CapabilityUnavailable",
                message="GUILD_MEMBERS privileged intent is not enabled in application flags",
                retryable=False,
                attempt=0,
            )
            return (
                AcquisitionResult(
                    resource="members",
                    status=CollectionStatus.UNAVAILABLE.value,
                    requested_at=requested_at,
                    completed_at=utc_now(),
                    records=None,
                    expected_count=None,
                    received_count=None,
                    page_count=0,
                    cursor_complete=False,
                    source_interface="REST",
                    source_version=self._source_version,
                    http_or_library_status=None,
                    errors=[error],
                    raw_payload_hashes=[],
                    attempt_count=0,
                ),
                metadata,
            )

        records: list[dict[str, Any]] = []
        hashes: list[str] = []
        errors: list[ScanError] = []
        seen_ids: set[int] = set()
        after: int | None = None
        page_count = 0
        total_attempts = 0
        cursor_complete = False
        last_page_size = 0

        while page_count < self._enumeration.max_pages:
            outcome = await self._call(
                lambda after=after: self._transport.read_members_page(
                    guild_id, limit=self._enumeration.page_size, after=after
                )
            )
            total_attempts += outcome.attempts
            errors.extend(outcome.errors)
            if outcome.payload is None:
                capability.list_members_endpoint_result = (
                    "DENIED" if any(e.code in {"AUTHORIZATION_DENIED", "AUTHENTICATION_FAILED"} for e in outcome.errors)
                    else "FAILED"
                )
                break
            if not isinstance(outcome.payload, list):
                errors.append(
                    ScanError(
                        code="RESPONSE_SHAPE_INVALID",
                        error_type="TypeError",
                        message="member enumeration page must be a list",
                        retryable=False,
                        attempt=outcome.attempts,
                    )
                )
                capability.list_members_endpoint_result = "FAILED"
                break

            capability.list_members_endpoint_result = "AUTHORIZED"
            page_count += 1
            last_page_size = len(outcome.payload)
            page_digest = payload_sha256(outcome.payload)
            hashes.append(page_digest)

            page_ids: list[int] = []
            page_records: list[dict[str, Any]] = []
            page_invalid = False
            for raw in outcome.payload:
                if not isinstance(raw, dict):
                    page_invalid = True
                    break
                try:
                    member_id = member_id_from_payload(raw)
                except (TypeError, ValueError):
                    page_invalid = True
                    break
                if member_id in seen_ids or (after is not None and member_id <= after):
                    page_invalid = True
                    break
                minimized, digest = minimize_member_payload(raw)
                page_ids.append(member_id)
                page_records.append(minimized)
                hashes.append(digest)

            if page_invalid:
                errors.append(
                    ScanError(
                        code="MEMBER_ENUMERATION_CURSOR_INVALID",
                        error_type="PaginationError",
                        message="member page contained a duplicate, missing ID, or non-advancing cursor",
                        retryable=False,
                        attempt=outcome.attempts,
                    )
                )
                capability.list_members_endpoint_result = "FAILED"
                break

            # Discord's ``after`` cursor is the highest user ID from the previous
            # page. Canonicalize page order without relying on response ordering.
            ordered = sorted(zip(page_ids, page_records), key=lambda pair: pair[0])
            for member_id, record in ordered:
                seen_ids.add(member_id)
                records.append(record)

            if len(records) > self._enumeration.max_members:
                errors.append(
                    ScanError(
                        code="MEMBER_ENUMERATION_LIMIT_EXCEEDED",
                        error_type="SafetyLimit",
                        message="member enumeration exceeded the configured maximum member count",
                        retryable=False,
                        attempt=outcome.attempts,
                    )
                )
                capability.list_members_endpoint_result = "FAILED"
                break

            if last_page_size < self._enumeration.page_size:
                cursor_complete = True
                break
            if not page_ids:
                cursor_complete = True
                break
            next_after = max(page_ids)
            if after is not None and next_after <= after:
                errors.append(
                    ScanError(
                        code="MEMBER_ENUMERATION_CURSOR_INVALID",
                        error_type="PaginationError",
                        message="member enumeration cursor did not advance",
                        retryable=False,
                        attempt=outcome.attempts,
                    )
                )
                capability.list_members_endpoint_result = "FAILED"
                break
            after = next_after
        else:
            errors.append(
                ScanError(
                    code="MEMBER_ENUMERATION_PAGE_LIMIT_EXCEEDED",
                    error_type="SafetyLimit",
                    message="member enumeration reached the configured maximum page count",
                    retryable=False,
                    attempt=total_attempts,
                )
            )

        if cursor_complete and not errors:
            status = CollectionStatus.COMPLETE.value
        elif records:
            status = CollectionStatus.PARTIAL.value
        elif any(e.code in {"AUTHORIZATION_DENIED", "AUTHENTICATION_FAILED", "MEMBER_INTENT_UNAVAILABLE"} for e in errors):
            status = CollectionStatus.UNAVAILABLE.value
        else:
            status = CollectionStatus.FAILED.value

        metadata.update(
            {
                "pages_completed": page_count,
                "members_received": len(records),
                "last_page_size": last_page_size,
                "cursor_complete": cursor_complete,
                "endpoint_result": capability.list_members_endpoint_result,
                "retention_lifecycle": "IN_MEMORY_UNTIL_DISPOSED",
            }
        )
        return (
            AcquisitionResult(
                resource="members",
                status=status,
                requested_at=requested_at,
                completed_at=utc_now(),
                records=records if records or status == CollectionStatus.COMPLETE.value else None,
                expected_count=None,  # Guild counts are approximate, not an exact pagination contract.
                received_count=len(records),
                page_count=page_count,
                cursor_complete=cursor_complete,
                source_interface="REST",
                source_version=self._source_version,
                http_or_library_status="OK" if status == CollectionStatus.COMPLETE.value else None,
                errors=errors,
                raw_payload_hashes=hashes,
                attempt_count=max(total_attempts, 1),
            ),
            metadata,
        )

    async def _call(self, operation: Callable[[], Awaitable[Any]]) -> _CallOutcome:
        errors: list[ScanError] = []
        attempts = 0
        while attempts < self._retry.max_attempts:
            attempts += 1
            try:
                return _CallOutcome(
                    await asyncio.wait_for(operation(), timeout=self._operation_timeout_seconds),
                    errors,
                    attempts,
                    "COMPLETE",
                )
            except Exception as exc:
                error = classify_exception(exc, attempt=attempts)
                errors.append(error)
                if not error.retryable or attempts >= self._retry.max_attempts:
                    return _CallOutcome(None, errors, attempts, "FAILED")
                await self._sleep(self._retry.delay_for_attempt(attempts))
        raise AssertionError("retry loop exited without an outcome")

    def _finalize(
        self,
        structure: StructureAcquisition,
        *,
        profile: str,
        member_result: AcquisitionResult,
        capability: MemberIntentCapabilityReport,
        started_at: str,
        member_metadata: dict[str, Any],
    ) -> MemberAcquisition:
        completed_at = utc_now()
        bundle = copy.deepcopy(structure.bundle)
        bundle["scan_profile"] = profile
        bundle["started_at"] = started_at
        bundle["completed_at"] = completed_at
        bundle["members"] = copy.deepcopy(member_result.records)
        bundle.setdefault("collection_health", {})["members"] = member_result.health_dict()

        reported_count = None
        if structure.snapshot is not None and structure.snapshot.guild is not None:
            reported_count = structure.snapshot.guild.reported_member_count
        member_metadata = copy.deepcopy(member_metadata)
        member_metadata["reported_member_count_approximate"] = reported_count
        if reported_count is not None and member_result.received_count is not None:
            member_metadata["approximate_count_delta"] = member_result.received_count - reported_count
        member_metadata["application_capability"] = capability.as_dict()
        bundle["member_acquisition"] = member_metadata

        results = dict(structure.results)
        results["members"] = member_result
        snapshot = None
        normalization_error = None
        try:
            snapshot = normalize_bundle(bundle)
        except SnapshotError as exc:
            normalization_error = str(exc)

        return MemberAcquisition(
            guild_id=structure.guild_id,
            scan_profile=profile,
            started_at=started_at,
            completed_at=completed_at,
            results=results,
            bundle=bundle,
            snapshot=snapshot,
            capability_report=capability,
            normalization_error=normalization_error,
        )

    @property
    def _source_version(self) -> str:
        return (
            f"{self._transport.source_library}/{self._transport.source_library_version} "
            f"Discord-API/{self._transport.source_api_version}"
        )

    @staticmethod
    def _parse_snowflake(value: int | str, field_name: str) -> int:
        if isinstance(value, bool):
            raise ValueError(f"{field_name} must be a positive decimal snowflake")
        text = str(value).strip()
        if not text.isdecimal() or int(text) <= 0:
            raise ValueError(f"{field_name} must be a positive decimal snowflake")
        return int(text)

    @classmethod
    def _parse_member_ids(cls, values: list[int | str] | tuple[int | str, ...]) -> list[int]:
        if not values:
            raise ValueError("at least one member_id is required")
        return sorted({cls._parse_snowflake(value, "member_id") for value in values})


def member_id_from_payload(raw: dict[str, Any]) -> int:
    user = raw.get("user")
    if not isinstance(user, dict):
        raise TypeError("member payload is missing user object")
    value = user.get("id")
    text = str(value).strip()
    if not text.isdecimal() or int(text) <= 0:
        raise ValueError("member payload has invalid user id")
    return int(text)


def minimize_member_payload(raw: dict[str, Any]) -> tuple[dict[str, Any], str]:
    """Return Guild Doctor's minimum member record and a hash of the full response."""

    digest = payload_sha256(raw)
    member_id = member_id_from_payload(raw)
    user = raw.get("user") or {}
    roles = [str(role_id) for role_id in raw.get("roles", [])]
    minimized = {
        "user": {
            "id": str(member_id),
            "bot": user.get("bot"),
        },
        "roles": roles,
        "communication_disabled_until": raw.get("communication_disabled_until"),
        "pending": raw.get("pending"),
        "_payload_sha256": digest,
    }
    return minimized, digest
