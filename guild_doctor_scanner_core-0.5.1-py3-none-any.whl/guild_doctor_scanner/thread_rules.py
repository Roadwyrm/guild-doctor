"""Versioned rule registry for Stage 3 Pass 4 thread resolution.

The registry is data only.  It records the externally documented thread
relationships and the deterministic rule identifiers used by the pure
resolver; it does not perform Discord access or mutate thread state.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

THREAD_RULES_VERSION = "GUILD-DOCTOR-THREAD-RULES-0.1"
THREAD_PERMISSIONS_SOURCE_URL = "https://docs.discord.com/developers/topics/permissions"
THREADS_SOURCE_URL = "https://docs.discord.com/developers/topics/threads"
CHANNEL_SOURCE_URL = "https://docs.discord.com/developers/resources/channel"
OFFICIAL_SOURCE_REVIEW_DATE = "2026-07-14"

THREAD_PARENT_RELATIONSHIP_RULE = "THREAD-PARENT-001"
THREAD_TYPE_RULE = "THREAD-TYPE-001"
THREAD_VIEW_RULE = "DEP-THREAD-002"
THREAD_MEMBERSHIP_RULE = "DEP-THREAD-003"
THREAD_MEMBERSHIP_UNKNOWN_RULE = "THREAD-MEMBERSHIP-UNKNOWN"
THREAD_SEND_PERMISSION_RULE = "DEP-THREAD-001"
THREAD_ARCHIVE_RULE = "DEP-THREAD-ARCHIVE-001"
THREAD_LOCK_RULE = "DEP-THREAD-LOCK-001"
THREAD_TIMEOUT_RULE = "DEP-TIMEOUT-001"


@dataclass(frozen=True, slots=True)
class ThreadRuleDefinition:
    """One stable rule used by the Pass 4 trace and decision records."""

    rule_id: str
    title: str
    applies_to: str
    references: tuple[str, ...]
    notes: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "title": self.title,
            "applies_to": self.applies_to,
            "references": list(self.references),
            "notes": self.notes,
        }


THREAD_RULES: tuple[ThreadRuleDefinition, ...] = tuple(
    sorted(
        (
            ThreadRuleDefinition(
                THREAD_ARCHIVE_RULE,
                "Archived unlocked sends may auto-unarchive",
                "ARCHIVED_STATE",
                (THREADS_SOURCE_URL,),
                "The resolver predicts the state effect only; it never performs an unarchive.",
            ),
            ThreadRuleDefinition(
                THREAD_LOCK_RULE,
                "Locked threads require thread management for ordinary sends",
                "LOCKED_STATE",
                (THREADS_SOURCE_URL,),
                "MANAGE_THREADS can bypass the locked restriction when the send permission is present.",
            ),
            ThreadRuleDefinition(
                THREAD_MEMBERSHIP_RULE,
                "Private visibility requires membership or thread management",
                "MEMBERSHIP",
                (THREADS_SOURCE_URL,),
                "Private threads are gated by explicit membership unless MANAGE_THREADS is effective.",
            ),
            ThreadRuleDefinition(
                THREAD_MEMBERSHIP_UNKNOWN_RULE,
                "Incomplete membership data remains unknown",
                "MEMBERSHIP",
                (THREADS_SOURCE_URL,),
                "A missing or incomplete membership source is never converted into NOT_MEMBER.",
            ),
            ThreadRuleDefinition(
                THREAD_PARENT_RELATIONSHIP_RULE,
                "Thread guild and parent identifiers must match",
                "THREAD_RELATIONSHIP",
                (THREADS_SOURCE_URL,),
                "The supplied thread record is related to exactly one supplied parent result.",
            ),
            ThreadRuleDefinition(
                THREAD_SEND_PERMISSION_RULE,
                "SEND_MESSAGES_IN_THREADS controls thread sending",
                "SEND_PERMISSION",
                (THREAD_PERMISSIONS_SOURCE_URL, THREADS_SOURCE_URL),
                "SEND_MESSAGES does not substitute for the thread-specific permission.",
            ),
            ThreadRuleDefinition(
                THREAD_TIMEOUT_RULE,
                "Timeout effects are consumed from the completed parent capability result",
                "TIMEOUT",
                (THREAD_PERMISSIONS_SOURCE_URL,),
                "Owner and administrator bypass behavior is not reimplemented by Pass 4.",
            ),
            ThreadRuleDefinition(
                THREAD_TYPE_RULE,
                "Thread and parent channel type combinations are constrained",
                "THREAD_TYPE",
                (CHANNEL_SOURCE_URL, THREADS_SOURCE_URL),
                "Public threads use text/forum/media parents; private threads use text; announcement threads use announcement channels.",
            ),
            ThreadRuleDefinition(
                THREAD_VIEW_RULE,
                "Parent VIEW_CHANNEL is required",
                "PARENT_VISIBILITY",
                (THREAD_PERMISSIONS_SOURCE_URL, THREADS_SOURCE_URL),
                "Membership, direct mention, and MANAGE_THREADS do not override missing parent visibility.",
            ),
        ),
        key=lambda item: item.rule_id,
    )
)


def validate_thread_rules(rules: tuple[ThreadRuleDefinition, ...] = THREAD_RULES) -> tuple[str, ...]:
    """Return deterministic validation diagnostics for the frozen registry."""

    reasons: list[str] = []
    if THREAD_RULES_VERSION != "GUILD-DOCTOR-THREAD-RULES-0.1":
        reasons.append("THREAD_RULES_VERSION_MISMATCH")
    ids = [item.rule_id for item in rules]
    if len(ids) != len(set(ids)):
        reasons.append("DUPLICATE_THREAD_RULE_ID")
    if any(not item.rule_id or not item.title or not item.references for item in rules):
        reasons.append("MALFORMED_THREAD_RULE")
    return tuple(sorted(set(reasons)))


__all__ = [
    "CHANNEL_SOURCE_URL",
    "OFFICIAL_SOURCE_REVIEW_DATE",
    "THREAD_ARCHIVE_RULE",
    "THREAD_LOCK_RULE",
    "THREAD_MEMBERSHIP_RULE",
    "THREAD_MEMBERSHIP_UNKNOWN_RULE",
    "THREAD_PARENT_RELATIONSHIP_RULE",
    "THREAD_PERMISSIONS_SOURCE_URL",
    "THREAD_RULES",
    "THREAD_RULES_VERSION",
    "THREAD_SEND_PERMISSION_RULE",
    "THREAD_TIMEOUT_RULE",
    "THREAD_TYPE_RULE",
    "THREADS_SOURCE_URL",
    "THREAD_VIEW_RULE",
    "ThreadRuleDefinition",
    "validate_thread_rules",
]
