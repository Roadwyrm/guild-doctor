"""Pure deterministic Stage 3 Pass 6 action-result orchestration.

This module combines already-produced Pass 3, Pass 4, and Pass 5 evidence into
one modeled pre-execution result.  It does not acquire Discord data, call a
transport, persist anything, or perform an operation.  Unknown and incomplete
evidence remains visible in the result and in the ordered trace.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

from .action_registry import (
    ACTION_CONTEXT_TYPES,
    ACTION_GOLDEN_VERSION,
    ACTION_RULES_BY_KEY,
    ACTION_RULES_VERSION,
    ACTION_SOURCE_REVIEW_DATE,
    ACTION_SOURCE_URLS,
    ACTION_TARGET_TYPES,
    ActionComponentDefinition,
    ActionRule,
    STAGE3_PASS6_ENGINE_CONTRACT_VERSION,
)
from .authority_registry import AUTHORITY_RULES_VERSION
from .canonical import canonical_json
from .capability_engine import (
    FINAL_ALLOWED,
    FINAL_DENIED,
    FINAL_INEFFECTIVE,
    FINAL_NOT_APPLICABLE,
    FINAL_POLICY_ONLY,
    FINAL_UNKNOWN,
    STAGE3_PASS3_ENGINE_CONTRACT_VERSION,
)
from .capability_registry import CAPABILITY_REGISTRY_VERSION
from .constants import PERMISSION_DEFINITION_VERSION, SNAPSHOT_SCHEMA_VERSION
from .fixture_export import STAGE3_FIXTURE_VERSION
from .mfa_rules import MFA_RULES_VERSION
from .object_preconditions import OBJECT_PRECONDITIONS_VERSION
from .permission_engine import (
    BYPASS_ADMINISTRATOR,
    BYPASS_NONE,
    BYPASS_OWNER,
    COMPLETENESS_COMPLETE,
    COMPLETENESS_PARTIAL,
    COMPLETENESS_UNKNOWN,
    STAGE3_PASS1_ENGINE_CONTRACT_VERSION,
)
from .permission_overwrite_engine import STAGE3_PASS2_ENGINE_CONTRACT_VERSION
from .thread_engine import STAGE3_PASS4_ENGINE_CONTRACT_VERSION
from .thread_rules import THREAD_RULES_VERSION


FINAL_RESULTS = frozenset({"ALLOWED", "DENIED", "UNKNOWN", "NOT_APPLICABLE", "UNSUPPORTED"})
DECISION_BASIS = "PRE_EXECUTION_MODEL"
EXECUTION_ATTEMPTED = False
EXECUTION_GUARANTEE = False
TRACE_STAGES = (
    "INPUT_VALIDATION",
    "ACTION_REGISTRY",
    "CONTRACT_VALIDATION",
    "IDENTITY_VALIDATION",
    "UPSTREAM_TRUST",
    "COMPONENT_COLLECTION",
    "COMPONENT_NORMALIZATION",
    "DEFINITIVE_BLOCKERS",
    "MATERIAL_UNCERTAINTIES",
    "SATISFIED_COMPONENTS",
    "FINAL_PRECEDENCE",
    "FINAL_RESULT",
    "COMPLETENESS",
    "PROVENANCE",
)
_NORMALIZED_STATES = frozenset(
    {"ALLOWED", "DENIED", "UNKNOWN", "NOT_APPLICABLE", "INEFFECTIVE", "POLICY_ONLY", "UNSUPPORTED", "FAILED", "SATISFIED"}
)
_BLOCKER_STATES = frozenset({"DENIED", "FAILED", "INEFFECTIVE"})
_UNCERTAINTY_STATES = frozenset({"UNKNOWN", "UNSUPPORTED", "POLICY_ONLY"})
_SATISFIED_STATES = frozenset({"ALLOWED", "SATISFIED"})
_INAPPLICABLE_STATES = frozenset({"NOT_APPLICABLE", "OUT_OF_SCOPE"})
_VERSION_FIELDS = (
    "pass1_contract_version",
    "pass2_contract_version",
    "pass3_contract_version",
    "pass4_contract_version",
    "pass5_contract_version",
    "capability_registry_version",
    "thread_rules_version",
    "authority_rules_version",
    "object_preconditions_version",
    "mfa_rules_version",
    "permission_definition_version",
    "snapshot_or_fixture_version",
)
_SOURCE_SAFE_FIELDS = {
    "PASS3": (
        "engine_contract_version", "pass2_contract_version", "pass1_contract_version", "capability_registry_version",
        "permission_definition_version", "snapshot_or_fixture_version", "guild_id", "subject_id", "context_id",
        "context_type", "bypass_state", "timeout_state", "completeness_state", "input_health_state",
        "raw_permission_bits_unchanged", "effective_capability_records", "ineffective_grant_records",
        "denied_capability_records", "unknown_capability_records", "inapplicable_capability_records",
        "policy_only_category_records", "reason_codes",
    ),
    "PASS4": (
        "engine_contract_version", "thread_rules_version", "pass3_contract_version", "pass2_contract_version",
        "pass1_contract_version", "capability_registry_version", "permission_definition_version",
        "snapshot_or_fixture_version", "guild_id", "subject_id", "thread_id", "thread_guild_id",
        "parent_channel_id", "parent_guild_id", "parent_channel_type", "thread_type", "thread_owner_id",
        "bypass_state", "completeness_state", "input_health_state", "raw_permission_bits_unchanged",
        "thread_visibility_result", "thread_read_history_result", "final_thread_send_capability_result",
        "reason_codes",
    ),
    "PASS5": (
        "engine_contract_version", "authority_rules_version", "object_preconditions_version", "mfa_rules_version",
        "pass1_contract_version", "pass2_contract_version", "pass3_contract_version", "pass4_contract_version",
        "capability_registry_version", "permission_definition_version", "snapshot_or_fixture_version", "guild_id",
        "actor_id", "actor_kind", "target_type", "target_id", "operation_key", "bypass_state",
        "capability_permission", "target_authority", "hierarchy_result", "mfa_precondition", "permission_subset_result",
        "managed_object_precondition", "operation_object_preconditions", "analysis_completeness",
        "source_capability_key", "source_capability_verification_status", "bot_installation_2fa_precondition",
        "raw_permission_values_unchanged", "reason_codes",
    ),
}


@dataclass(frozen=True, slots=True)
class ActionOrchestrationRequest:
    operation_key: str | None = None
    guild_id: str | int | None = None
    actor_id: str | int | None = None
    subject_id: str | int | None = None
    target_type: str | None = None
    target_id: str | int | None = None
    context_id: str | int | None = None
    context_type: str | None = None
    thread_id: str | int | None = None
    thread_type: str | None = None
    bypass_state: str | None = None
    capability_result: Any = None
    thread_result: Any = None
    authority_result: Any = None
    component_evidence: Mapping[str, Any] | None = None
    input_health: Mapping[str, Any] | None = None
    evidence_classifications: tuple[str, ...] = ()
    verification_statuses: tuple[str, ...] = ()
    source_references: tuple[str, ...] = ()
    pass1_contract_version: str | None = None
    pass2_contract_version: str | None = None
    pass3_contract_version: str | None = None
    pass4_contract_version: str | None = None
    pass5_contract_version: str | None = None
    capability_registry_version: str | None = None
    thread_rules_version: str | None = None
    authority_rules_version: str | None = None
    object_preconditions_version: str | None = None
    mfa_rules_version: str | None = None
    permission_definition_version: str | None = None
    snapshot_or_fixture_version: str | None = None


@dataclass(frozen=True, slots=True)
class ActionComponentEvidence:
    name: str
    required: bool
    source_engine: str
    source_field: str | None
    raw_state: str | None
    normalized_state: str
    verification_status: str
    evidence_source: str
    source_references: tuple[str, ...]
    rule_id: str
    upstream_unchanged: bool
    notes: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "required": self.required,
            "source_engine": self.source_engine,
            "source_field": self.source_field,
            "raw_state": self.raw_state,
            "normalized_state": self.normalized_state,
            "verification_status": self.verification_status,
            "evidence_source": self.evidence_source,
            "source_references": list(self.source_references),
            "rule_id": self.rule_id,
            "upstream_unchanged": self.upstream_unchanged,
            "notes": list(self.notes),
        }


@dataclass(frozen=True, slots=True)
class ActionTraceEvent:
    sequence: int
    stage: str
    operation_key: str | None
    actor_id: str | None
    target_id: str | None
    component: str | None
    raw_upstream_state: str | None
    normalized_state: str | None
    previous_state: str | None
    new_state: str | None
    rule_id: str
    verification: str
    evidence_source: str
    upstream_unchanged: bool

    @property
    def code(self) -> str:
        return self.stage

    def as_dict(self) -> dict[str, Any]:
        return {
            "sequence": self.sequence,
            "stage": self.stage,
            "operation_key": self.operation_key,
            "actor_id": self.actor_id,
            "target_id": self.target_id,
            "component": self.component,
            "raw_upstream_state": self.raw_upstream_state,
            "normalized_state": self.normalized_state,
            "previous_orchestration_state": self.previous_state,
            "new_orchestration_state": self.new_state,
            "rule_id": self.rule_id,
            "verification": self.verification,
            "evidence_source": self.evidence_source,
            "upstream_unchanged": self.upstream_unchanged,
        }


@dataclass(frozen=True, slots=True)
class ActionOrchestrationResult:
    pass6_contract_version: str
    action_rules_version: str
    action_golden_version: str
    pass1_contract_version: str | None
    pass2_contract_version: str | None
    pass3_contract_version: str | None
    pass4_contract_version: str | None
    pass5_contract_version: str | None
    capability_registry_version: str | None
    thread_rules_version: str | None
    authority_rules_version: str | None
    object_preconditions_version: str | None
    mfa_rules_version: str | None
    permission_definition_version: str | None
    snapshot_or_fixture_version: str | None
    guild_id: str | None
    actor_id: str | None
    subject_id: str | None
    operation_key: str | None
    target_type: str | None
    target_id: str | None
    context_id: str | None
    context_type: str | None
    thread_id: str | None
    thread_type: str | None
    final_result: str
    decision_basis: str
    execution_attempted: bool
    execution_guarantee: bool
    action_supported: bool
    action_applicable: bool
    bypass_state: str | None
    analysis_completeness: str
    required_components: tuple[str, ...]
    optional_components: tuple[str, ...]
    normalized_component_results: Mapping[str, str]
    component_evidence: tuple[ActionComponentEvidence, ...]
    satisfied_components: tuple[str, ...]
    definitive_blockers: tuple[str, ...]
    material_uncertainties: tuple[str, ...]
    warnings: tuple[str, ...]
    inapplicable_components: tuple[str, ...]
    unsupported_evidence: tuple[str, ...]
    missing_components: tuple[str, ...]
    source_pass3_result_digest: str | None
    source_pass4_result_digest: str | None
    source_pass5_result_digest: str | None
    registry_versions: Mapping[str, str]
    reason_codes: tuple[str, ...]
    source_references: tuple[str, ...]
    evidence_classifications: tuple[str, ...]
    verification_statuses: tuple[str, ...]
    input_health: Mapping[str, Any]
    input_fingerprint: str
    result_fingerprint: str
    upstream_objects_unchanged: bool
    trace: tuple[ActionTraceEvent, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "pass6_contract_version": self.pass6_contract_version,
            "action_rules_version": self.action_rules_version,
            "action_golden_version": self.action_golden_version,
            "pass1_contract_version": self.pass1_contract_version,
            "pass2_contract_version": self.pass2_contract_version,
            "pass3_contract_version": self.pass3_contract_version,
            "pass4_contract_version": self.pass4_contract_version,
            "pass5_contract_version": self.pass5_contract_version,
            "capability_registry_version": self.capability_registry_version,
            "thread_rules_version": self.thread_rules_version,
            "authority_rules_version": self.authority_rules_version,
            "object_preconditions_version": self.object_preconditions_version,
            "mfa_rules_version": self.mfa_rules_version,
            "permission_definition_version": self.permission_definition_version,
            "snapshot_or_fixture_version": self.snapshot_or_fixture_version,
            "guild_id": self.guild_id,
            "actor_id": self.actor_id,
            "subject_id": self.subject_id,
            "operation_key": self.operation_key,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "context_id": self.context_id,
            "context_type": self.context_type,
            "thread_id": self.thread_id,
            "thread_type": self.thread_type,
            "final_result": self.final_result,
            "decision_basis": self.decision_basis,
            "execution_attempted": self.execution_attempted,
            "execution_guarantee": self.execution_guarantee,
            "action_supported": self.action_supported,
            "action_applicable": self.action_applicable,
            "bypass_state": self.bypass_state,
            "analysis_completeness": self.analysis_completeness,
            "required_components": list(self.required_components),
            "optional_components": list(self.optional_components),
            "normalized_component_results": _safe_canonical(self.normalized_component_results),
            "component_evidence": [item.as_dict() for item in self.component_evidence],
            "satisfied_components": list(self.satisfied_components),
            "definitive_blockers": list(self.definitive_blockers),
            "material_uncertainties": list(self.material_uncertainties),
            "warnings": list(self.warnings),
            "inapplicable_components": list(self.inapplicable_components),
            "unsupported_evidence": list(self.unsupported_evidence),
            "missing_components": list(self.missing_components),
            "source_pass3_result_digest": self.source_pass3_result_digest,
            "source_pass4_result_digest": self.source_pass4_result_digest,
            "source_pass5_result_digest": self.source_pass5_result_digest,
            "registry_versions": _safe_canonical(self.registry_versions),
            "reason_codes": list(self.reason_codes),
            "source_references": list(self.source_references),
            "evidence_classifications": list(self.evidence_classifications),
            "verification_statuses": list(self.verification_statuses),
            "input_health": _safe_canonical(self.input_health),
            "input_fingerprint": self.input_fingerprint,
            "result_fingerprint": self.result_fingerprint,
            "upstream_objects_unchanged": self.upstream_objects_unchanged,
            "trace": [item.as_dict() for item in self.trace],
            "official_source_review_date": ACTION_SOURCE_REVIEW_DATE,
            "official_sources": list(ACTION_SOURCE_URLS),
        }


def _read(value: Any, name: str, default: Any = None) -> Any:
    if value is None:
        return default
    if isinstance(value, Mapping):
        return value.get(name, default)
    return getattr(value, name, default)


def _as_mapping(value: Any) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return value
    method = getattr(value, "as_dict", None)
    if callable(method):
        result = method()
        if isinstance(result, Mapping):
            return result
    return {}


def _normal(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    text = str(value).strip().upper().replace("-", "_").replace(" ", "_")
    return text or None


def _id(value: Any) -> str | None:
    if value is None:
        return None
    return str(value)


def _safe_text(value: Any) -> str | None:
    if not isinstance(value, str):
        return _id(value)
    lowered = value.lower()
    if "token" in lowered or lowered.startswith("bot "):
        return "[REDACTED]"
    return value


def _safe_canonical(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _safe_canonical(value[key]) for key in sorted(value, key=lambda item: str(item)) if str(key).lower() != "token"}
    if isinstance(value, (list, tuple)):
        return [_safe_canonical(item) for item in value]
    if isinstance(value, str):
        return _safe_text(value)
    return value


def _digest(value: Mapping[str, Any] | None) -> str | None:
    if value is None:
        return None
    return hashlib.sha256(canonical_json(dict(_safe_canonical(value))).encode("utf-8")).hexdigest()


def _safe_source_projection(source: Any, engine: str) -> dict[str, Any] | None:
    if source is None:
        return None
    source_map = _as_mapping(source)
    projection: dict[str, Any] = {}
    for field in _SOURCE_SAFE_FIELDS[engine]:
        if field in source_map:
            value = source_map[field]
            if field in {"effective_capability_records", "ineffective_grant_records", "denied_capability_records", "unknown_capability_records", "inapplicable_capability_records", "policy_only_category_records", "operation_object_preconditions"}:
                records = value if isinstance(value, (list, tuple)) else ()
                safe_records: list[dict[str, Any]] = []
                for record in records:
                    record_map = _as_mapping(record)
                    allowed = {key: _safe_canonical(record_map[key]) for key in ("capability_key", "final_result", "result", "key", "verification_status", "source_references", "source_input", "missing_input", "rule_id") if key in record_map}
                    safe_records.append(allowed)
                safe_records.sort(key=lambda item: canonical_json(item))
                projection[field] = safe_records
            else:
                projection[field] = _safe_canonical(value)
    return projection


def _source_digest(source: Any, engine: str) -> str | None:
    projection = _safe_source_projection(source, engine)
    return _digest(projection)


def _source_refs(source: Any) -> tuple[str, ...]:
    refs = _read(source, "source_references", ())
    if not refs:
        refs = _read(source, "source_refs", ())
    if not isinstance(refs, (list, tuple, set)):
        return ()
    return tuple(sorted({item for item in (_safe_text(item) for item in refs) if item and str(item).startswith(("https://", "http://"))}))


def _record_state(record: Any) -> str | None:
    value = _read(record, "final_result", None)
    if value is None:
        value = _read(record, "result", None)
    if value is None:
        value = _read(record, "result_state", None)
    return _normal(value)


def _record_key(record: Any) -> str | None:
    value = _read(record, "capability_key", None)
    if value is None:
        value = _read(record, "key", None)
    return _safe_text(value)


def _records(source: Any, field: str) -> tuple[Any, ...]:
    value = _read(source, field, ())
    if isinstance(value, (list, tuple)):
        return tuple(value)
    return ()


def _capability_states(source: Any, capability_key: str) -> tuple[tuple[str, Any], ...]:
    found: list[tuple[str, Any]] = []
    for field in (
        "effective_capability_records",
        "ineffective_grant_records",
        "denied_capability_records",
        "unknown_capability_records",
        "inapplicable_capability_records",
        "policy_only_category_records",
    ):
        for record in _records(source, field):
            if _record_key(record) == capability_key:
                found.append((_record_state(record) or "UNKNOWN", record))
    return tuple(found)


def _precondition_state(source: Any, key: str) -> tuple[str | None, Any | None]:
    for record in _records(source, "operation_object_preconditions"):
        if _normal(_read(record, "key", None)) == _normal(key):
            return _record_state(record), record
    return None, None


def _aggregate_preconditions(source: Any) -> tuple[str | None, Any | None]:
    records = _records(source, "operation_object_preconditions")
    if not records:
        return None, None
    states = tuple(_record_state(record) or "UNKNOWN" for record in records)
    if any(state in _BLOCKER_STATES for state in states):
        return next(state for state in states if state in _BLOCKER_STATES), records
    if any(state in _UNCERTAINTY_STATES for state in states):
        return "UNKNOWN", records
    if all(state in _INAPPLICABLE_STATES for state in states):
        return "NOT_APPLICABLE", records
    return "SATISFIED", records


def _direct_value(request: ActionOrchestrationRequest, name: str) -> tuple[bool, Any]:
    evidence = request.component_evidence
    if not isinstance(evidence, Mapping) or name not in evidence:
        return False, None
    return True, evidence[name]


def _normalize_direct(value: Any) -> tuple[str, str | None, tuple[str, ...]]:
    values = value if isinstance(value, (list, tuple)) else (value,)
    states: list[str] = []
    for item in values:
        if isinstance(item, Mapping):
            item = item.get("normalized_state", item.get("final_result", item.get("result", item.get("state"))))
        state = _normal(item) or "UNKNOWN"
        states.append(state if state in _NORMALIZED_STATES else "UNKNOWN")
    distinct = tuple(sorted(set(states)))
    if len(distinct) > 1:
        return "UNKNOWN", None, ("ACTION-DUPLICATE-COMPONENT-001",)
    return states[0] if states else "UNKNOWN", states[0] if states else None, ()


def _component_normalized_state(name: str, state: str) -> str:
    if name == "hierarchy_result":
        return {
            "LOWER": "ALLOWED",
            "EQUAL": "DENIED",
            "HIGHER": "DENIED",
            "UNKNOWN": "UNKNOWN",
            "NOT_APPLICABLE": "NOT_APPLICABLE",
        }.get(state, "UNKNOWN")
    return state


def _component_value(request: ActionOrchestrationRequest, definition: ActionComponentDefinition, rule: ActionRule) -> tuple[Any, str | None, str, tuple[str, ...]]:
    direct, value = _direct_value(request, definition.name)
    if direct:
        normalized, raw, notes = _normalize_direct(value)
        return value, raw, _component_normalized_state(definition.name, normalized), notes
    source: Any = None
    source_name = definition.source_engine
    if source_name == "PASS3":
        source = request.capability_result
    elif source_name == "PASS4":
        source = request.thread_result
    elif source_name == "PASS5":
        source = request.authority_result
    elif source_name == "COMBINED":
        source = request.authority_result or request.capability_result or request.thread_result
    if source is None:
        return None, None, "UNKNOWN", ("ACTION-COMPONENT-REQUIRED-001",)
    if definition.name == "capability_permission":
        capability_states: list[tuple[str, Any]] = []
        for key in rule.required_capability_keys:
            capability_states.extend(_capability_states(request.capability_result, key))
        if not capability_states:
            return None, None, "UNKNOWN", ("ACTION-COMPONENT-REQUIRED-001",)
        states = {state for state, _ in capability_states}
        if len(states) > 1:
            return capability_states, None, "UNKNOWN", ("ACTION-DUPLICATE-COMPONENT-001",)
        state, record = capability_states[0]
        return record, state, state, ()
    if definition.name in {"target_owner_protection", "target_admin_timeout_protection", "target_member_hierarchy", "context_consistency"}:
        for field in definition.source_fields:
            state, record = _precondition_state(request.authority_result, definition.name)
            if record is not None:
                return record, state, state or "UNKNOWN", ()
        return None, None, "UNKNOWN", ("ACTION-COMPONENT-REQUIRED-001",)
    if definition.name == "operation_object_preconditions":
        state, record = _aggregate_preconditions(request.authority_result)
        return record, state, state or "UNKNOWN", ()
    for field in definition.source_fields:
        value = _read(source, field, None)
        if value is not None:
            normalized = _record_state(value) if not isinstance(value, str) else _normal(value)
            normalized = normalized or "UNKNOWN"
            normalized = _component_normalized_state(definition.name, normalized)
            if normalized not in _NORMALIZED_STATES:
                normalized = "UNKNOWN"
            return value, _record_state(value) if not isinstance(value, str) else _normal(value), normalized, ()
    return None, None, "UNKNOWN", ("ACTION-COMPONENT-REQUIRED-001",)


def _verification_status(definition: ActionComponentDefinition, raw_value: Any, request: ActionOrchestrationRequest) -> str:
    direct = _direct_value(request, definition.name)[1]
    if isinstance(direct, Mapping):
        value = direct.get("verification_status")
        if value:
            return _normal(value) or "UNKNOWN"
    value = _read(raw_value, "verification_status", None)
    if value:
        return _normal(value) or "UNKNOWN"
    if request.verification_statuses:
        return _normal(request.verification_statuses[0]) or "UNKNOWN"
    return "VERIFIED"


def _source_for_component(definition: ActionComponentDefinition, request: ActionOrchestrationRequest) -> tuple[str, Any]:
    if _direct_value(request, definition.name)[0]:
        return "REQUEST_COMPONENT_EVIDENCE", request.component_evidence
    if definition.source_engine == "PASS3":
        return "PASS3_CAPABILITY_RESULT", request.capability_result
    if definition.source_engine == "PASS4":
        return "PASS4_THREAD_RESULT", request.thread_result
    return "PASS5_AUTHORITY_RESULT", request.authority_result


def _required_engines(rule: ActionRule) -> tuple[str, ...]:
    engines = {component.source_engine for component in rule.components if component.required and component.source_engine in {"PASS3", "PASS4", "PASS5"}}
    if rule.source_engine in {"PASS3", "PASS4", "PASS5"}:
        engines.add(rule.source_engine)
    return tuple(sorted(engines))


def _source_version_map(request: ActionOrchestrationRequest, engine: str) -> dict[str, Any]:
    source = request.capability_result if engine == "PASS3" else request.thread_result if engine == "PASS4" else request.authority_result
    mapping: dict[str, Any] = {}
    if engine == "PASS3":
        names = {"pass3_contract_version": "engine_contract_version", "pass2_contract_version": "pass2_contract_version", "pass1_contract_version": "pass1_contract_version", "capability_registry_version": "capability_registry_version", "permission_definition_version": "permission_definition_version", "snapshot_or_fixture_version": "snapshot_or_fixture_version"}
    elif engine == "PASS4":
        names = {"pass4_contract_version": "engine_contract_version", "thread_rules_version": "thread_rules_version", "pass3_contract_version": "pass3_contract_version", "pass2_contract_version": "pass2_contract_version", "pass1_contract_version": "pass1_contract_version", "capability_registry_version": "capability_registry_version", "permission_definition_version": "permission_definition_version", "snapshot_or_fixture_version": "snapshot_or_fixture_version"}
    else:
        names = {"pass5_contract_version": "engine_contract_version", "authority_rules_version": "authority_rules_version", "object_preconditions_version": "object_preconditions_version", "mfa_rules_version": "mfa_rules_version", "pass4_contract_version": "pass4_contract_version", "pass3_contract_version": "pass3_contract_version", "pass2_contract_version": "pass2_contract_version", "pass1_contract_version": "pass1_contract_version", "capability_registry_version": "capability_registry_version", "permission_definition_version": "permission_definition_version", "snapshot_or_fixture_version": "snapshot_or_fixture_version"}
    for request_name, source_name in names.items():
        value = _read(source, source_name, None)
        if value is not None:
            mapping[request_name] = value
    return mapping


def _expected_versions(engine: str) -> dict[str, str | tuple[str, ...]]:
    common: dict[str, str | tuple[str, ...]] = {
        "pass1_contract_version": STAGE3_PASS1_ENGINE_CONTRACT_VERSION,
        "pass2_contract_version": STAGE3_PASS2_ENGINE_CONTRACT_VERSION,
        "permission_definition_version": PERMISSION_DEFINITION_VERSION,
        "snapshot_or_fixture_version": (SNAPSHOT_SCHEMA_VERSION, STAGE3_FIXTURE_VERSION),
    }
    if engine == "PASS3":
        return {**common, "pass3_contract_version": STAGE3_PASS3_ENGINE_CONTRACT_VERSION, "capability_registry_version": CAPABILITY_REGISTRY_VERSION}
    if engine == "PASS4":
        return {**common, "pass3_contract_version": STAGE3_PASS3_ENGINE_CONTRACT_VERSION, "pass4_contract_version": STAGE3_PASS4_ENGINE_CONTRACT_VERSION, "capability_registry_version": CAPABILITY_REGISTRY_VERSION, "thread_rules_version": THREAD_RULES_VERSION}
    if engine == "PASS5":
        return {**common, "pass3_contract_version": STAGE3_PASS3_ENGINE_CONTRACT_VERSION, "pass4_contract_version": STAGE3_PASS4_ENGINE_CONTRACT_VERSION, "pass5_contract_version": "GUILD-DOCTOR-STAGE3-PASS5-0.1", "capability_registry_version": CAPABILITY_REGISTRY_VERSION, "authority_rules_version": AUTHORITY_RULES_VERSION, "object_preconditions_version": OBJECT_PRECONDITIONS_VERSION, "mfa_rules_version": MFA_RULES_VERSION}
    return common


def _trace(
    events: list[ActionTraceEvent],
    stage: str,
    request: ActionOrchestrationRequest,
    *,
    component: str | None = None,
    raw: str | None = None,
    normalized: str | None = None,
    previous: str | None = None,
    new: str | None = None,
    rule_id: str = "ACTION-REGISTRY-001",
    verification: str = "VERIFIED",
    evidence_source: str = "ORCHESTRATOR",
    upstream_unchanged: bool = True,
) -> None:
    events.append(
        ActionTraceEvent(
            sequence=len(events),
            stage=stage,
            operation_key=_safe_text(request.operation_key),
            actor_id=_id(request.actor_id),
            target_id=_id(request.target_id),
            component=component,
            raw_upstream_state=raw,
            normalized_state=normalized,
            previous_state=previous,
            new_state=new,
            rule_id=rule_id,
            verification=verification,
            evidence_source=evidence_source,
            upstream_unchanged=upstream_unchanged,
        )
    )


def _input_fingerprint(request: ActionOrchestrationRequest, digests: Mapping[str, str | None]) -> str:
    safe = {
        "operation_key": _safe_text(request.operation_key),
        "guild_id": _id(request.guild_id),
        "actor_id": _id(request.actor_id),
        "subject_id": _id(request.subject_id),
        "target_type": _normal(request.target_type),
        "target_id": _id(request.target_id),
        "context_id": _id(request.context_id),
        "context_type": _normal(request.context_type),
        "thread_id": _id(request.thread_id),
        "thread_type": _normal(request.thread_type),
        "bypass_state": _normal(request.bypass_state),
        "versions": {field: getattr(request, field) for field in _VERSION_FIELDS},
        "input_health": _safe_canonical(request.input_health or {}),
        "evidence_classifications": sorted({_safe_text(item) for item in request.evidence_classifications if _safe_text(item)}),
        "verification_statuses": sorted({_normal(item) for item in request.verification_statuses if _normal(item)}),
        "source_references": sorted(set(_source_refs(request))),
        "source_digests": dict(digests),
    }
    return _digest(safe) or ""


def _base_kwargs(request: ActionOrchestrationRequest, rule: ActionRule | None) -> dict[str, Any]:
    return {
        "pass6_contract_version": STAGE3_PASS6_ENGINE_CONTRACT_VERSION,
        "action_rules_version": ACTION_RULES_VERSION,
        "action_golden_version": ACTION_GOLDEN_VERSION,
        **{field: getattr(request, field) for field in _VERSION_FIELDS},
        "guild_id": _id(request.guild_id),
        "actor_id": _id(request.actor_id),
        "subject_id": _id(request.subject_id),
        "operation_key": _safe_text(request.operation_key),
        "target_type": _normal(request.target_type),
        "target_id": _id(request.target_id),
        "context_id": _id(request.context_id),
        "context_type": _normal(request.context_type),
        "thread_id": _id(request.thread_id),
        "thread_type": _normal(request.thread_type),
        "decision_basis": DECISION_BASIS,
        "execution_attempted": EXECUTION_ATTEMPTED,
        "execution_guarantee": EXECUTION_GUARANTEE,
        "action_supported": rule is not None,
        "action_applicable": False,
        "bypass_state": _normal(request.bypass_state),
        "required_components": rule.required_components if rule else (),
        "optional_components": rule.optional_components if rule else (),
        "normalized_component_results": {},
        "component_evidence": (),
        "satisfied_components": (),
        "definitive_blockers": (),
        "material_uncertainties": (),
        "warnings": (),
        "inapplicable_components": (),
        "unsupported_evidence": (),
        "missing_components": (),
        "source_pass3_result_digest": _source_digest(request.capability_result, "PASS3"),
        "source_pass4_result_digest": _source_digest(request.thread_result, "PASS4"),
        "source_pass5_result_digest": _source_digest(request.authority_result, "PASS5"),
        "registry_versions": {
            "pass6_contract_version": STAGE3_PASS6_ENGINE_CONTRACT_VERSION,
            "action_rules_version": ACTION_RULES_VERSION,
            "action_golden_version": ACTION_GOLDEN_VERSION,
            "capability_registry_version": CAPABILITY_REGISTRY_VERSION,
            "thread_rules_version": THREAD_RULES_VERSION,
            "authority_rules_version": AUTHORITY_RULES_VERSION,
            "object_preconditions_version": OBJECT_PRECONDITIONS_VERSION,
            "mfa_rules_version": MFA_RULES_VERSION,
        },
        "reason_codes": (),
        "source_references": tuple(sorted(set(ACTION_SOURCE_URLS) | set(_source_refs(request)) | set(_source_refs(request.authority_result)) | set(_source_refs(request.thread_result)) | set(_source_refs(request.capability_result)))),
        "evidence_classifications": tuple(sorted({_safe_text(item) for item in request.evidence_classifications if _safe_text(item)})),
        "verification_statuses": tuple(sorted({_normal(item) for item in request.verification_statuses if _normal(item)})),
        "input_health": _safe_canonical(request.input_health or {}),
        "input_fingerprint": "",
        "result_fingerprint": "",
        "upstream_objects_unchanged": True,
        "trace": (),
        "analysis_completeness": COMPLETENESS_UNKNOWN,
    }


def _finalize(result: ActionOrchestrationResult) -> ActionOrchestrationResult:
    payload = result.as_dict()
    payload.pop("result_fingerprint", None)
    fingerprint = _digest(payload) or ""
    return replace(result, result_fingerprint=fingerprint)


def _unsupported(request: ActionOrchestrationRequest, reason: str) -> ActionOrchestrationResult:
    events: list[ActionTraceEvent] = []
    _trace(events, "INPUT_VALIDATION", request, new="UNSUPPORTED", rule_id="ACTION-UNSUPPORTED-001")
    _trace(events, "ACTION_REGISTRY", request, new="UNSUPPORTED", rule_id="ACTION-UNSUPPORTED-001")
    _trace(events, "FINAL_PRECEDENCE", request, previous="UNKNOWN", new="UNSUPPORTED", rule_id="ACTION-UNSUPPORTED-001")
    _trace(events, "FINAL_RESULT", request, new="UNSUPPORTED", rule_id="ACTION-UNSUPPORTED-001")
    _trace(events, "COMPLETENESS", request, new="COMPLETE", rule_id="ACTION-EXECUTION-NOT-ATTEMPTED-001")
    _trace(events, "PROVENANCE", request, new="UNSUPPORTED", rule_id="ACTION-UNSUPPORTED-001")
    digests = {"pass3": _source_digest(request.capability_result, "PASS3"), "pass4": _source_digest(request.thread_result, "PASS4"), "pass5": _source_digest(request.authority_result, "PASS5")}
    kwargs = _base_kwargs(request, None)
    kwargs.update({"final_result": "UNSUPPORTED", "action_applicable": False, "analysis_completeness": COMPLETENESS_COMPLETE, "reason_codes": (reason, "ACTION-UNSUPPORTED-001"), "input_fingerprint": _input_fingerprint(request, digests), "trace": tuple(events)})
    return _finalize(ActionOrchestrationResult(**kwargs))


def evaluate_action_orchestration(request: ActionOrchestrationRequest | Mapping[str, Any]) -> ActionOrchestrationResult:
    """Evaluate one registered action with Pass 3/4/5 evidence.

    The function is deterministic for equivalent inputs and always returns a
    structured result, including for malformed, incomplete, or unsupported
    requests.
    """

    if not isinstance(request, ActionOrchestrationRequest):
        request = ActionOrchestrationRequest(**dict(request))
    operation_key = _safe_text(request.operation_key)
    rule = ACTION_RULES_BY_KEY.get(operation_key or "")
    if rule is None:
        return _unsupported(request, "ACTION-OPERATION-UNSUPPORTED-001")

    events: list[ActionTraceEvent] = []
    reasons: set[str] = set()
    missing: set[str] = set()
    uncertainties: set[str] = set()
    blockers: set[str] = set()
    warnings: set[str] = set()
    unsupported_evidence: set[str] = set()
    inapplicable_components: set[str] = set()
    satisfied: set[str] = set()
    direct_unknown = False
    required_inapplicable: set[str] = set()
    _trace(events, "INPUT_VALIDATION", request, new="VALIDATED", rule_id="ACTION-REGISTRY-001")
    _trace(events, "ACTION_REGISTRY", request, new="REGISTERED", rule_id="ACTION-REGISTRY-001")

    target_type = _normal(request.target_type)
    if target_type is None:
        if "NONE" in rule.target_types:
            target_type = "NONE"
        else:
            reasons.add("ACTION-TARGET-MISSING-001")
            uncertainties.add("TARGET_IDENTITY_MISSING")
            direct_unknown = True
    elif target_type not in ACTION_TARGET_TYPES:
        reasons.add("ACTION-TARGET-MALFORMED-001")
        uncertainties.add("TARGET_TYPE_MALFORMED")
        direct_unknown = True
    context_type = _normal(request.context_type)
    if context_type is None:
        if "NONE" in rule.context_types:
            context_type = "NONE"
        else:
            reasons.add("ACTION-CONTEXT-MISSING-001")
            uncertainties.add("CONTEXT_IDENTITY_MISSING")
            direct_unknown = True
    elif context_type not in ACTION_CONTEXT_TYPES:
        reasons.add("ACTION-CONTEXT-MALFORMED-001")
        uncertainties.add("CONTEXT_TYPE_MALFORMED")
        direct_unknown = True
    if target_type in ACTION_TARGET_TYPES and target_type != "NONE" and _id(request.target_id) is None:
        reasons.add("ACTION-TARGET-ID-MISSING-001")
        uncertainties.add("TARGET_IDENTITY_MISSING")
        direct_unknown = True
    if _normal(request.bypass_state) not in {None, BYPASS_NONE, BYPASS_OWNER, BYPASS_ADMINISTRATOR}:
        reasons.add("ACTION-BYPASS-MALFORMED-001")
        uncertainties.add("BYPASS_STATE_MALFORMED")
        direct_unknown = True
    _trace(events, "INPUT_VALIDATION", request, normalized=target_type, new="TARGET_CONTEXT_CHECKED", rule_id="ACTION-REGISTRY-001")

    # A known target/context mismatch is an applicability result, while an
    # unknown target/context is an evidence-quality result.
    if not direct_unknown and target_type not in rule.target_types:
        reasons.add("ACTION-NOT-APPLICABLE-001")
        events_result = "NOT_APPLICABLE"
        _trace(events, "FINAL_PRECEDENCE", request, previous="REGISTERED", new=events_result, rule_id="ACTION-NOT-APPLICABLE-001")
        _trace(events, "FINAL_RESULT", request, new=events_result, rule_id="ACTION-NOT-APPLICABLE-001")
        _trace(events, "COMPLETENESS", request, new="COMPLETE", rule_id="ACTION-EXECUTION-NOT-ATTEMPTED-001")
        _trace(events, "PROVENANCE", request, new=events_result, rule_id="ACTION-NOT-APPLICABLE-001")
        kwargs = _base_kwargs(request, rule)
        kwargs.update({"target_type": target_type, "context_type": context_type, "final_result": events_result, "action_applicable": False, "analysis_completeness": COMPLETENESS_COMPLETE, "reason_codes": tuple(sorted(reasons)), "input_fingerprint": _input_fingerprint(request, {"pass3": kwargs["source_pass3_result_digest"], "pass4": kwargs["source_pass4_result_digest"], "pass5": kwargs["source_pass5_result_digest"]}), "trace": tuple(events)})
        return _finalize(ActionOrchestrationResult(**kwargs))
    if not direct_unknown and context_type not in rule.context_types:
        reasons.add("ACTION-NOT-APPLICABLE-001")
        _trace(events, "FINAL_PRECEDENCE", request, previous="REGISTERED", new="NOT_APPLICABLE", rule_id="ACTION-NOT-APPLICABLE-001")
        _trace(events, "FINAL_RESULT", request, new="NOT_APPLICABLE", rule_id="ACTION-NOT-APPLICABLE-001")
        _trace(events, "COMPLETENESS", request, new="COMPLETE", rule_id="ACTION-EXECUTION-NOT-ATTEMPTED-001")
        _trace(events, "PROVENANCE", request, new="NOT_APPLICABLE", rule_id="ACTION-NOT-APPLICABLE-001")
        kwargs = _base_kwargs(request, rule)
        kwargs.update({"target_type": target_type, "context_type": context_type, "final_result": "NOT_APPLICABLE", "action_applicable": False, "analysis_completeness": COMPLETENESS_COMPLETE, "reason_codes": tuple(sorted(reasons)), "input_fingerprint": _input_fingerprint(request, {"pass3": kwargs["source_pass3_result_digest"], "pass4": kwargs["source_pass4_result_digest"], "pass5": kwargs["source_pass5_result_digest"]}), "trace": tuple(events)})
        return _finalize(ActionOrchestrationResult(**kwargs))
    if _id(request.guild_id) is None or _id(request.actor_id) is None:
        reasons.add("ACTION-IDENTITY-MISSING-001")
        uncertainties.add("IDENTITY_MISSING")
        direct_unknown = True
    _trace(events, "CONTRACT_VALIDATION", request, new="PENDING", rule_id="ACTION-CONTRACT-MISMATCH-001")

    required_engines = _required_engines(rule)
    source_by_engine = {"PASS3": request.capability_result, "PASS4": request.thread_result, "PASS5": request.authority_result}
    for engine in required_engines:
        if source_by_engine[engine] is None:
            missing.add(f"{engine}_RESULT")
            uncertainties.add("UPSTREAM_RESULT_MISSING")
            reasons.add("ACTION-UPSTREAM-INCOMPLETE-001")
        source_versions = _source_version_map(request, engine)
        expected = _expected_versions(engine)
        for field, expected_value in expected.items():
            request_value = getattr(request, field)
            source_value = source_versions.get(field)
            if request_value is not None and (request_value not in expected_value if isinstance(expected_value, tuple) else request_value != expected_value):
                reasons.add("ACTION-CONTRACT-MISMATCH-001")
                uncertainties.add("CONTRACT_VERSION_MISMATCH")
                direct_unknown = True
            if source_value is not None and (source_value not in expected_value if isinstance(expected_value, tuple) else source_value != expected_value):
                reasons.add("ACTION-CONTRACT-MISMATCH-001")
                uncertainties.add("UPSTREAM_CONTRACT_MISMATCH")
                direct_unknown = True
            if request_value is None and source_value is None:
                missing.add(field)
                reasons.add("ACTION-CONTRACT-MISSING-001")
                uncertainties.add("CONTRACT_VERSION_MISSING")
                direct_unknown = True
    _trace(events, "CONTRACT_VALIDATION", request, new="CHECKED", rule_id="ACTION-CONTRACT-MISMATCH-001")

    # Identity checks are explicit and only use fields from the reviewed Pass
    # result contracts.  A mismatch is never silently repaired.
    identity_checks = (
        ("PASS3", request.capability_result, "guild_id", request.guild_id),
        ("PASS3", request.capability_result, "subject_id", request.actor_id),
        ("PASS4", request.thread_result, "guild_id", request.guild_id),
        ("PASS4", request.thread_result, "thread_guild_id", request.guild_id),
        ("PASS4", request.thread_result, "parent_guild_id", request.guild_id),
        ("PASS4", request.thread_result, "subject_id", request.actor_id),
        ("PASS4", request.thread_result, "thread_id", request.target_id if target_type == "THREAD" else None),
        ("PASS4", request.thread_result, "parent_channel_id", request.context_id),
        ("PASS5", request.authority_result, "guild_id", request.guild_id),
        ("PASS5", request.authority_result, "actor_id", request.actor_id),
        ("PASS5", request.authority_result, "target_id", request.target_id if target_type != "NONE" else None),
    )
    for engine, source, field, expected in identity_checks:
        source_value = _read(source, field, None)
        if source_value is not None and expected is not None and _id(source_value) != _id(expected):
            reasons.add("ACTION-IDENTITY-MISMATCH-001")
            uncertainties.add("IDENTITY_MISMATCH")
            direct_unknown = True
    _trace(events, "IDENTITY_VALIDATION", request, new="CHECKED", rule_id="ACTION-IDENTITY-MISMATCH-001")

    for engine in required_engines:
        source = source_by_engine[engine]
        if source is None:
            continue
        completeness = _normal(_read(source, "completeness_state", _read(source, "analysis_completeness", None)))
        health = _normal(_read(source, "input_health_state", None))
        if completeness not in {COMPLETENESS_COMPLETE, "COMPLETE"} or health not in {None, COMPLETENESS_COMPLETE, "COMPLETE"}:
            uncertainties.add("UPSTREAM_INCOMPLETE")
            reasons.add("ACTION-UPSTREAM-INCOMPLETE-001")
        unchanged = _read(source, "raw_permission_bits_unchanged", _read(source, "raw_permission_values_unchanged", True))
        if unchanged is False:
            uncertainties.add("UPSTREAM_RAW_BITS_CHANGED")
            reasons.add("ACTION-UPSTREAM-INCOMPLETE-001")
    _trace(events, "UPSTREAM_TRUST", request, new="CHECKED", rule_id="ACTION-UPSTREAM-INCOMPLETE-001")

    evidence_items: list[ActionComponentEvidence] = []
    all_components = tuple(rule.components)
    for definition in all_components:
        raw_value, raw_state, normalized, extraction_notes = _component_value(request, definition, rule)
        verification = _verification_status(definition, raw_value, request)
        evidence_source, source = _source_for_component(definition, request)
        source_refs = tuple(sorted(set(_source_refs(source)) | set(ACTION_SOURCE_URLS)))
        notes = list(extraction_notes)
        if normalized not in _NORMALIZED_STATES:
            normalized = "UNKNOWN"
        if raw_value is None:
            if definition.required:
                missing.add(definition.name)
                reasons.add("ACTION-COMPONENT-REQUIRED-001")
            else:
                warnings.add(definition.name)
                reasons.add("ACTION-OPTIONAL-COMPONENT-MISSING-001")
        if normalized in _BLOCKER_STATES and definition.required:
            blockers.add(definition.name)
        elif normalized in _UNCERTAINTY_STATES:
            if definition.required:
                uncertainties.add(definition.name)
            else:
                warnings.add(definition.name)
            if normalized == "POLICY_ONLY":
                reasons.add("ACTION-POLICY-ONLY-001")
            if normalized == "UNSUPPORTED":
                unsupported_evidence.add(definition.name)
        elif normalized in _SATISFIED_STATES:
            satisfied.add(definition.name)
        elif normalized in _INAPPLICABLE_STATES:
            inapplicable_components.add(definition.name)
            if definition.required and not definition.allow_not_applicable:
                required_inapplicable.add(definition.name)
        if extraction_notes:
            uncertainties.update(extraction_notes)
            reasons.update(extraction_notes)
        if verification in {"UNKNOWN", "NEEDS_LIVE_TEST", "NEEDS_TEST"} and definition.required and normalized not in _BLOCKER_STATES:
            uncertainties.add(f"VERIFICATION_{definition.name}")
            notes.append("Verification status is not complete for a live endpoint claim.")
        evidence_items.append(ActionComponentEvidence(
            name=definition.name,
            required=definition.required,
            source_engine=definition.source_engine,
            source_field=definition.source_fields[0] if definition.source_fields else None,
            raw_state=raw_state,
            normalized_state=normalized,
            verification_status=verification,
            evidence_source=evidence_source,
            source_references=source_refs,
            rule_id=definition.rule_id,
            upstream_unchanged=True,
            notes=tuple(sorted(set(notes))),
        ))
        _trace(events, "COMPONENT_COLLECTION", request, component=definition.name, raw=raw_state, new="COLLECTED" if raw_value is not None else "MISSING", rule_id=definition.rule_id, verification=verification, evidence_source=evidence_source)
        _trace(events, "COMPONENT_NORMALIZATION", request, component=definition.name, raw=raw_state, normalized=normalized, previous="COLLECTED", new=normalized, rule_id=definition.rule_id, verification=verification, evidence_source=evidence_source)

    _trace(events, "DEFINITIVE_BLOCKERS", request, new="PRESENT" if blockers else "NONE", rule_id="ACTION-BLOCKER-001")
    _trace(events, "MATERIAL_UNCERTAINTIES", request, new="PRESENT" if (uncertainties or missing or direct_unknown) else "NONE", rule_id="ACTION-UNKNOWN-001")
    _trace(events, "SATISFIED_COMPONENTS", request, new="PRESENT" if satisfied else "NONE", rule_id="ACTION-ALLOW-001")

    required_names = {item.name for item in evidence_items if item.required}
    if blockers:
        final_result = "DENIED"
        reasons.add("ACTION-BLOCKER-001")
    elif required_inapplicable and required_inapplicable == required_names and not direct_unknown and not uncertainties and not missing:
        final_result = "NOT_APPLICABLE"
        reasons.add("ACTION-NOT-APPLICABLE-001")
    elif required_inapplicable:
        final_result = "UNKNOWN"
        uncertainties.update(required_inapplicable)
        reasons.add("ACTION-UNKNOWN-001")
    elif direct_unknown or uncertainties or missing:
        final_result = "UNKNOWN"
        reasons.add("ACTION-UNKNOWN-001")
    elif all(
        item.name in satisfied or item.name in inapplicable_components or not item.required
        for item in evidence_items
    ):
        final_result = "ALLOWED"
        reasons.add("ACTION-ALLOW-001")
    else:
        final_result = "UNKNOWN"
        reasons.add("ACTION-UNKNOWN-001")
    if final_result == "UNKNOWN" and not direct_unknown and not missing and not blockers:
        analysis_completeness = COMPLETENESS_PARTIAL
    elif final_result in {"ALLOWED", "DENIED"} and not (uncertainties or missing):
        analysis_completeness = COMPLETENESS_COMPLETE
    elif final_result in {"NOT_APPLICABLE", "UNSUPPORTED"}:
        analysis_completeness = COMPLETENESS_COMPLETE
    else:
        analysis_completeness = COMPLETENESS_PARTIAL if uncertainties or missing else COMPLETENESS_UNKNOWN
    _trace(events, "FINAL_PRECEDENCE", request, previous="COMPONENTS", new=final_result, rule_id=next(iter(sorted({"ACTION-BLOCKER-001"} if blockers else {"ACTION-UNKNOWN-001"} if final_result == "UNKNOWN" else {"ACTION-ALLOW-001"}))))
    _trace(events, "FINAL_RESULT", request, new=final_result, rule_id=next(iter(sorted({"ACTION-BLOCKER-001"} if blockers else {"ACTION-UNKNOWN-001"} if final_result == "UNKNOWN" else {"ACTION-ALLOW-001"}))))
    _trace(events, "COMPLETENESS", request, new=analysis_completeness, rule_id="ACTION-EXECUTION-NOT-ATTEMPTED-001")
    _trace(events, "PROVENANCE", request, new=final_result, rule_id="ACTION-EXECUTION-NOT-ATTEMPTED-001")
    digests = {"pass3": _source_digest(request.capability_result, "PASS3"), "pass4": _source_digest(request.thread_result, "PASS4"), "pass5": _source_digest(request.authority_result, "PASS5")}
    kwargs = _base_kwargs(request, rule)
    kwargs.update({
        "target_type": target_type,
        "context_type": context_type,
        "final_result": final_result,
        "action_applicable": True,
        "analysis_completeness": analysis_completeness,
        "normalized_component_results": {item.name: item.normalized_state for item in sorted(evidence_items, key=lambda item: item.name)},
        "component_evidence": tuple(sorted(evidence_items, key=lambda item: item.name)),
        "satisfied_components": tuple(sorted(satisfied)),
        "definitive_blockers": tuple(sorted(blockers)),
        "material_uncertainties": tuple(sorted(uncertainties)),
        "warnings": tuple(sorted(warnings)),
        "inapplicable_components": tuple(sorted(inapplicable_components)),
        "unsupported_evidence": tuple(sorted(unsupported_evidence)),
        "missing_components": tuple(sorted(missing)),
        "reason_codes": tuple(sorted(reasons)),
        "input_fingerprint": _input_fingerprint(request, digests),
        "trace": tuple(events),
    })
    return _finalize(ActionOrchestrationResult(**kwargs))


evaluate_action = evaluate_action_orchestration
resolve_action_result = evaluate_action_orchestration
evaluate_pass6_action = evaluate_action_orchestration


__all__ = [
    "ActionComponentEvidence",
    "ActionOrchestrationRequest",
    "ActionOrchestrationResult",
    "ActionTraceEvent",
    "DECISION_BASIS",
    "EXECUTION_ATTEMPTED",
    "EXECUTION_GUARANTEE",
    "FINAL_RESULTS",
    "STAGE3_PASS6_ENGINE_CONTRACT_VERSION",
    "TRACE_STAGES",
    "evaluate_action",
    "evaluate_action_orchestration",
    "evaluate_pass6_action",
    "resolve_action_result",
]
