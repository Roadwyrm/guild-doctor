"""Pure deterministic effective capability expansion for Stage 3 Pass 3.

This module consumes a completed Stage 3 Pass 2 result and expands raw known
permission bits into context-aware capability records.  It has no Discord,
network, environment, persistence, command, token, thread-membership,
hierarchy, target, MFA, or mutation dependency.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .capability_registry import (
    CAPABILITY_REGISTRY_VERSION,
    DEP_EXTERNAL_APP_BEHAVIOR,
    DEP_SEND_MESSAGES,
    DEP_TIMEOUT,
    DEP_VIEW_CHANNEL,
    DEP_VOICE_CONNECT,
    DEFAULT_CAPABILITY_REGISTRY,
    SUPPORTED_EXECUTABLE_CONTEXTS,
    CapabilityDefinition,
    CapabilityRegistry,
    validate_capability_registry,
)
from .constants import (
    KNOWN_PERMISSION_MASK,
    PERMISSION_DEFINITION_VERSION,
    SNAPSHOT_SCHEMA_VERSION,
)
from .fixture_export import STAGE3_FIXTURE_VERSION
from .permission_engine import (
    BYPASS_ADMINISTRATOR,
    BYPASS_NONE,
    BYPASS_OWNER,
    COMPLETENESS_COMPLETE,
    COMPLETENESS_PARTIAL,
    COMPLETENESS_UNKNOWN,
    STAGE3_PASS1_ENGINE_CONTRACT_VERSION,
)
from .permission_overwrite_engine import STAGE3_PASS2_ENGINE_CONTRACT_VERSION


STAGE3_PASS3_ENGINE_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE3-PASS3-0.1"
SUPPORTED_SOURCE_VERSIONS = frozenset({SNAPSHOT_SCHEMA_VERSION, STAGE3_FIXTURE_VERSION})
SUPPORTED_CONTEXT_TYPES = frozenset({"CATEGORY", *SUPPORTED_EXECUTABLE_CONTEXTS})
UNSUPPORTED_THREAD_CONTEXTS = frozenset(
    {"PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"}
)
TIMEOUT_STATES = frozenset({"ACTIVE", "INACTIVE", "UNKNOWN"})

FINAL_ALLOWED = "ALLOWED"
FINAL_DENIED = "DENIED"
FINAL_INEFFECTIVE = "INEFFECTIVE"
FINAL_UNKNOWN = "UNKNOWN"
FINAL_NOT_APPLICABLE = "NOT_APPLICABLE"
FINAL_POLICY_ONLY = "POLICY_ONLY"

_MISSING = object()
_VIEW_BIT = 1 << 10
_SEND_BIT = 1 << 11
_CONNECT_BIT = 1 << 20
_VIEW_CAPABILITY_KEYS = frozenset({"view.channel", "message.read_history"})
_SEND_DEPENDENT_CAPABILITY_KEYS = frozenset(
    {
        "message.send_tts",
        "message.mention_everyone",
        "message.attach_files",
        "message.embed_links",
    }
)
_VOICE_CONNECTION_DEPENDENT_KEYS = frozenset(
    {
        "voice.stream",
        "stage.stream",
        "voice.speak",
        "voice.mute_members",
        "stage.mute_members",
        "voice.deafen_members",
        "voice.move_members",
        "stage.move_members",
        "voice.use_vad",
        "activity.use_embedded",
        "voice.use_soundboard",
        "voice.use_external_sounds",
        "stage.use_external_sounds",
        "voice.send_voice_messages",
        "stage.send_voice_messages",
        "voice.status.set",
    }
)
_UNKNOWN_BEHAVIOR_CAPABILITY_KEYS = frozenset({"application.external_use"})


@dataclass(frozen=True, slots=True)
class CapabilityExpansionRequest:
    """Explicit pure input for one Pass 3 context expansion."""

    pass2_result: Any = None
    guild_id: int | str | None = None
    subject_id: int | str | None = None
    context_id: int | str | None = None
    context_type: int | str | None = None
    bypass_state: str | None = None
    raw_guild_permission_decimal: int | str | None = None
    raw_guild_permission_hex: str | None = None
    raw_context_permission_decimal: int | str | None = None
    raw_context_permission_hex: str | None = None
    known_permission_bits_decimal: int | str | None = None
    known_permission_bits_hex: str | None = None
    unknown_permission_bits_decimal: int | str | None = None
    unknown_permission_bits_hex: str | None = None
    timeout_state: str | None = None
    permission_definition_version: str | None = None
    snapshot_or_fixture_version: str | None = None
    input_health: Mapping[str, Any] | None = None
    capability_registry: CapabilityRegistry | None = None
    registry: CapabilityRegistry | None = None

    @classmethod
    def from_pass2_result(
        cls,
        pass2_result: Any,
        *,
        timeout_state: str,
        input_health: Mapping[str, Any] | None = None,
        capability_registry: CapabilityRegistry | None = None,
    ) -> "CapabilityExpansionRequest":
        """Create an explicit request from a trusted Pass 2 result."""

        get = lambda name: _value(pass2_result, name)
        return cls(
            pass2_result=pass2_result,
            guild_id=get("guild_id"),
            subject_id=get("subject_id"),
            context_id=get("context_id"),
            context_type=get("context_type"),
            bypass_state=get("bypass_state"),
            raw_guild_permission_decimal=get("raw_guild_permission_decimal"),
            raw_guild_permission_hex=get("raw_guild_permission_hex"),
            raw_context_permission_decimal=get("raw_context_permission_decimal"),
            raw_context_permission_hex=get("raw_context_permission_hex"),
            known_permission_bits_decimal=get("known_context_permission_bits_decimal"),
            known_permission_bits_hex=get("known_context_permission_bits_hex"),
            unknown_permission_bits_decimal=get("unknown_context_permission_bits_decimal"),
            unknown_permission_bits_hex=get("unknown_context_permission_bits_hex"),
            timeout_state=timeout_state,
            permission_definition_version=get("permission_definition_version"),
            snapshot_or_fixture_version=get("snapshot_or_fixture_version"),
            input_health=input_health,
            capability_registry=capability_registry,
        )


@dataclass(frozen=True, slots=True)
class CapabilityRecord:
    """One capability decision, preserving the raw source bit separately."""

    capability_key: str
    source_permission_flag: str | None
    source_bypass: str | None
    scope: str
    raw_granted: bool
    permission_satisfied: bool
    context_applicable: bool
    dependency_result: str
    timeout_result: str
    final_result: str
    blocking_rule_ids: tuple[str, ...]
    verification_status: str
    source_references: tuple[str, ...]
    notes: str

    @property
    def source_refs(self) -> tuple[str, ...]:
        return self.source_references

    @property
    def result_state(self) -> str:
        return self.final_result

    def as_dict(self) -> dict[str, Any]:
        return {
            "capability_key": self.capability_key,
            "source_permission_flag": self.source_permission_flag,
            "source_bypass": self.source_bypass,
            "scope": self.scope,
            "raw_granted": self.raw_granted,
            "permission_satisfied": self.permission_satisfied,
            "context_applicable": self.context_applicable,
            "dependency_result": self.dependency_result,
            "timeout_result": self.timeout_result,
            "final_result": self.final_result,
            "result_state": self.final_result,
            "blocking_rule_ids": list(self.blocking_rule_ids),
            "verification_status": self.verification_status,
            "source_references": list(self.source_references),
            "source_refs": list(self.source_references),
            "notes": self.notes,
        }


@dataclass(frozen=True, slots=True)
class CapabilityTraceEvent:
    """Stable timestamp-free trace event for one Pass 3 stage decision."""

    sequence: int
    stage: str
    details: Mapping[str, Any]

    @property
    def code(self) -> str:
        return self.stage

    def as_dict(self) -> dict[str, Any]:
        return {
            "sequence": self.sequence,
            "stage": self.stage,
            "code": self.stage,
            "details": _canonicalize(self.details),
        }


@dataclass(frozen=True, slots=True)
class CapabilityExpansionResult:
    """Deterministic Pass 3 output with separated raw/effective states."""

    engine_contract_version: str
    pass2_contract_version: str
    pass1_contract_version: str
    capability_registry_version: str
    permission_definition_version: str | None
    snapshot_or_fixture_version: str | None
    guild_id: str | None
    subject_id: str | None
    context_id: str | None
    context_type: str | None
    bypass_state: str | None
    timeout_state: str | None
    raw_guild_permission_decimal: str | None
    raw_guild_permission_hex: str | None
    raw_context_permission_decimal: str | None
    raw_context_permission_hex: str | None
    known_context_permission_bits_decimal: str | None
    known_context_permission_bits_hex: str | None
    unknown_context_permission_bits_decimal: str | None
    unknown_context_permission_bits_hex: str | None
    known_granted_permission_flags: tuple[str, ...]
    known_granted_guild_permission_flags: tuple[str, ...]
    effective_capability_records: tuple[CapabilityRecord, ...]
    ineffective_grant_records: tuple[CapabilityRecord, ...]
    denied_capability_records: tuple[CapabilityRecord, ...]
    unknown_capability_records: tuple[CapabilityRecord, ...]
    inapplicable_capability_records: tuple[CapabilityRecord, ...]
    policy_only_category_records: tuple[CapabilityRecord, ...]
    dependency_uncertainties: tuple[Mapping[str, Any], ...]
    completeness_state: str
    input_health_state: str
    raw_permission_bits_unchanged: bool
    reason_codes: tuple[str, ...]
    trace: tuple[CapabilityTraceEvent, ...]

    @property
    def effective_capabilities(self) -> tuple[CapabilityRecord, ...]:
        return self.effective_capability_records

    @property
    def effective_records(self) -> tuple[CapabilityRecord, ...]:
        return self.effective_capability_records

    @property
    def ineffective_capabilities(self) -> tuple[CapabilityRecord, ...]:
        return self.ineffective_grant_records

    @property
    def ineffective_records(self) -> tuple[CapabilityRecord, ...]:
        return self.ineffective_grant_records

    @property
    def denied_capabilities(self) -> tuple[CapabilityRecord, ...]:
        return self.denied_capability_records

    @property
    def denied_records(self) -> tuple[CapabilityRecord, ...]:
        return self.denied_capability_records

    @property
    def unknown_capabilities(self) -> tuple[CapabilityRecord, ...]:
        return self.unknown_capability_records

    @property
    def inapplicable_capabilities(self) -> tuple[CapabilityRecord, ...]:
        return self.inapplicable_capability_records

    @property
    def policy_only_capabilities(self) -> tuple[CapabilityRecord, ...]:
        return self.policy_only_category_records

    @property
    def known_granted_flags(self) -> tuple[str, ...]:
        return self.known_granted_permission_flags

    @property
    def unknown_bits_decimal(self) -> str | None:
        return self.unknown_context_permission_bits_decimal

    @property
    def unknown_bits_hex(self) -> str | None:
        return self.unknown_context_permission_bits_hex

    @property
    def registry_version(self) -> str:
        return self.capability_registry_version

    def as_dict(self) -> dict[str, Any]:
        return {
            "engine_contract_version": self.engine_contract_version,
            "pass2_contract_version": self.pass2_contract_version,
            "pass1_contract_version": self.pass1_contract_version,
            "capability_registry_version": self.capability_registry_version,
            "permission_definition_version": self.permission_definition_version,
            "snapshot_or_fixture_version": self.snapshot_or_fixture_version,
            "guild_id": self.guild_id,
            "subject_id": self.subject_id,
            "context_id": self.context_id,
            "context_type": self.context_type,
            "bypass_state": self.bypass_state,
            "timeout_state": self.timeout_state,
            "raw_guild_permission_decimal": self.raw_guild_permission_decimal,
            "raw_guild_permission_hex": self.raw_guild_permission_hex,
            "raw_context_permission_decimal": self.raw_context_permission_decimal,
            "raw_context_permission_hex": self.raw_context_permission_hex,
            "known_context_permission_bits_decimal": self.known_context_permission_bits_decimal,
            "known_context_permission_bits_hex": self.known_context_permission_bits_hex,
            "unknown_context_permission_bits_decimal": self.unknown_context_permission_bits_decimal,
            "unknown_context_permission_bits_hex": self.unknown_context_permission_bits_hex,
            "known_granted_permission_flags": list(self.known_granted_permission_flags),
            "known_granted_guild_permission_flags": list(self.known_granted_guild_permission_flags),
            "effective_capability_records": [item.as_dict() for item in self.effective_capability_records],
            "ineffective_grant_records": [item.as_dict() for item in self.ineffective_grant_records],
            "denied_capability_records": [item.as_dict() for item in self.denied_capability_records],
            "unknown_capability_records": [item.as_dict() for item in self.unknown_capability_records],
            "inapplicable_capability_records": [item.as_dict() for item in self.inapplicable_capability_records],
            "policy_only_category_records": [item.as_dict() for item in self.policy_only_category_records],
            "dependency_uncertainties": [_canonicalize(item) for item in self.dependency_uncertainties],
            "completeness_state": self.completeness_state,
            "input_health_state": self.input_health_state,
            "raw_permission_bits_unchanged": self.raw_permission_bits_unchanged,
            "reason_codes": list(self.reason_codes),
            "trace": [event.as_dict() for event in self.trace],
        }


def _canonicalize(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _canonicalize(value[key]) for key in sorted(value, key=lambda item: str(item))}
    if isinstance(value, (list, tuple)):
        return [_canonicalize(item) for item in value]
    return value


def _value(record: Any, name: str) -> Any:
    if record is None:
        return _MISSING
    if isinstance(record, Mapping):
        return record.get(name, _MISSING)
    return getattr(record, name, _MISSING)


def _parse_snowflake(value: Any) -> str | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text or not text.isdecimal():
        return None
    parsed = int(text)
    return str(parsed) if parsed > 0 else None


def _parse_permission(value: Any) -> tuple[str | None, int | None]:
    if value is None or isinstance(value, bool):
        return None, None
    if isinstance(value, int):
        return (str(value), value) if value >= 0 else (None, None)
    if not isinstance(value, str):
        return None, None
    text = value.strip()
    if not text or not text.isdecimal():
        return None, None
    parsed = int(text)
    return str(parsed), parsed


def _permission_parts(value: int | None) -> tuple[str | None, str | None, str | None, str | None, str | None, str | None]:
    if value is None:
        return (None, None, None, None, None, None)
    known = value & KNOWN_PERMISSION_MASK
    unknown = value & ~KNOWN_PERMISSION_MASK
    return (
        str(value),
        format(value, "#x"),
        str(known),
        format(known, "#x"),
        str(unknown),
        format(unknown, "#x"),
    )


def _normalize_context_type(value: Any) -> str | None:
    if isinstance(value, int) and not isinstance(value, bool):
        return {
            0: "TEXT",
            2: "VOICE",
            4: "CATEGORY",
            5: "ANNOUNCEMENT",
            10: "ANNOUNCEMENT_THREAD",
            11: "PUBLIC_THREAD",
            12: "PRIVATE_THREAD",
            13: "STAGE",
            15: "FORUM",
            16: "MEDIA",
        }.get(value, f"UNKNOWN_{value}")
    if not isinstance(value, str):
        return None
    text = value.strip().upper()
    aliases = {
        "GUILD_CATEGORY": "CATEGORY",
        "GUILD_TEXT": "TEXT",
        "GUILD_ANNOUNCEMENT": "ANNOUNCEMENT",
        "GUILD_VOICE": "VOICE",
        "GUILD_STAGE_VOICE": "STAGE",
        "GUILD_FORUM": "FORUM",
        "GUILD_MEDIA": "MEDIA",
    }
    if text in aliases:
        return aliases[text]
    if text.isdecimal():
        return _normalize_context_type(int(text))
    return text or None


def _health_state(input_health: Mapping[str, Any] | None) -> tuple[str, str | None]:
    if input_health is None:
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_MISSING"
    if not isinstance(input_health, Mapping):
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID"
    candidates: list[Any] = []
    for key in ("status", "structural_completeness", "source_structural_completeness", "completeness"):
        if key in input_health:
            candidates.append(input_health[key])
    if isinstance(input_health.get("complete"), bool):
        candidates.append(COMPLETENESS_COMPLETE if input_health["complete"] else COMPLETENESS_PARTIAL)
    for candidate in candidates:
        if isinstance(candidate, str):
            state = candidate.strip().upper()
            if state == COMPLETENESS_COMPLETE:
                return COMPLETENESS_COMPLETE, None
            if state in {COMPLETENESS_PARTIAL, "INCOMPLETE", "NOT_REQUESTED"}:
                return COMPLETENESS_PARTIAL, "INPUT_HEALTH_INCOMPLETE"
            if state == COMPLETENESS_UNKNOWN:
                return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INCOMPLETE"
    return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID" if candidates else "INPUT_HEALTH_MISSING"


def _coalesce(request_value: Any, pass2: Any, field: str) -> Any:
    return request_value if request_value is not None else _value(pass2, field)


def _state(raw: int | None) -> dict[str, Any]:
    decimal, hexadecimal, known, known_hex, unknown, unknown_hex = _permission_parts(raw)
    return {
        "decimal": decimal,
        "hex": hexadecimal,
        "known_decimal": known,
        "known_hex": known_hex,
        "unknown_decimal": unknown,
        "unknown_hex": unknown_hex,
    }


def _flag_names(registry: CapabilityRegistry, value: int | None) -> tuple[str, ...]:
    if value is None:
        return ()
    return tuple(flag.name for flag in registry.permission_flags if value & flag.mask)


def _record_sort_key(record: CapabilityRecord) -> str:
    return record.capability_key


def _trace_details(
    definition: CapabilityDefinition,
    *,
    context_type: str | None,
    raw_context: int | None,
    raw_unchanged: bool,
    previous: str,
    new: str,
    blocking: tuple[str, ...] = (),
    source_bypass: str | None = None,
) -> dict[str, Any]:
    return {
        "capability_key": definition.capability_key,
        "source_permission_flag": definition.source_permission_flag,
        "source_bypass": source_bypass,
        "permission_bit": definition.permission_bit,
        "previous_state": previous,
        "new_state": new,
        "blocking_rule_ids": list(blocking),
        "verification_status": definition.verification_status,
        "context_type": context_type,
        "raw_context_permission_decimal": str(raw_context) if raw_context is not None else None,
        "raw_context_permission_hex": format(raw_context, "#x") if raw_context is not None else None,
        "raw_permission_bits_unchanged": raw_unchanged,
    }


def evaluate_capability_expansion(request: CapabilityExpansionRequest) -> CapabilityExpansionResult:
    """Expand one completed Pass 2 result without altering any raw bitfield."""

    reasons: set[str] = set()
    trace: list[CapabilityTraceEvent] = []
    registry = request.capability_registry or request.registry or DEFAULT_CAPABILITY_REGISTRY
    registry_reasons = validate_capability_registry(registry)
    reasons.update(registry_reasons)

    pass2 = request.pass2_result
    guild_id = _parse_snowflake(_coalesce(request.guild_id, pass2, "guild_id"))
    subject_id = _parse_snowflake(_coalesce(request.subject_id, pass2, "subject_id"))
    context_id = _parse_snowflake(_coalesce(request.context_id, pass2, "context_id"))
    context_type = _normalize_context_type(_coalesce(request.context_type, pass2, "context_type"))
    bypass_state = _coalesce(request.bypass_state, pass2, "bypass_state")
    if not isinstance(bypass_state, str):
        bypass_state = None
    else:
        bypass_state = bypass_state.strip().upper()

    permission_version = _coalesce(request.permission_definition_version, pass2, "permission_definition_version")
    source_version = _coalesce(request.snapshot_or_fixture_version, pass2, "snapshot_or_fixture_version")
    timeout_state = request.timeout_state.strip().upper() if isinstance(request.timeout_state, str) else None
    health_state, health_reason = _health_state(request.input_health)
    if health_reason:
        reasons.add(health_reason)

    if pass2 is None:
        reasons.add("PASS2_RESULT_MISSING")
    pass2_contract = _value(pass2, "engine_contract_version")
    pass1_contract = _value(pass2, "pass1_contract_version")
    if pass2_contract != STAGE3_PASS2_ENGINE_CONTRACT_VERSION:
        reasons.add("PASS2_CONTRACT_MISMATCH")
    if pass1_contract != STAGE3_PASS1_ENGINE_CONTRACT_VERSION:
        reasons.add("PASS1_CONTRACT_MISMATCH")
    if guild_id is None:
        reasons.add("GUILD_ID_INVALID")
    if subject_id is None:
        reasons.add("SUBJECT_ID_INVALID")
    if context_id is None:
        reasons.add("CONTEXT_ID_INVALID")
    if context_type is None:
        reasons.add("CONTEXT_TYPE_MISSING")
    elif context_type in UNSUPPORTED_THREAD_CONTEXTS:
        reasons.add("UNSUPPORTED_THREAD_CONTEXT")
    elif context_type not in SUPPORTED_CONTEXT_TYPES:
        reasons.add("UNSUPPORTED_OR_UNKNOWN_CONTEXT_TYPE")
    if bypass_state not in {BYPASS_NONE, BYPASS_OWNER, BYPASS_ADMINISTRATOR}:
        reasons.add("BYPASS_STATE_INVALID")
    if timeout_state not in TIMEOUT_STATES:
        reasons.add("TIMEOUT_STATE_MISSING_OR_INVALID")
    if permission_version is None:
        reasons.add("PERMISSION_DEFINITION_VERSION_MISSING")
    elif permission_version != PERMISSION_DEFINITION_VERSION:
        reasons.add("PERMISSION_DEFINITION_VERSION_MISMATCH")
    if source_version is None:
        reasons.add("SNAPSHOT_OR_FIXTURE_VERSION_MISSING")
    elif source_version not in SUPPORTED_SOURCE_VERSIONS:
        reasons.add("SNAPSHOT_OR_FIXTURE_VERSION_UNSUPPORTED")

    p2_guild_id = _parse_snowflake(_value(pass2, "guild_id"))
    p2_subject_id = _parse_snowflake(_value(pass2, "subject_id"))
    p2_context_id = _parse_snowflake(_value(pass2, "context_id"))
    p2_context_type = _normalize_context_type(_value(pass2, "context_type"))
    if guild_id is not None and p2_guild_id != guild_id:
        reasons.add("PASS2_GUILD_ID_MISMATCH")
    if subject_id is not None and p2_subject_id != subject_id:
        reasons.add("PASS2_SUBJECT_ID_MISMATCH")
    if context_id is not None and p2_context_id != context_id:
        reasons.add("PASS2_CONTEXT_ID_MISMATCH")
    if context_type is not None and p2_context_type != context_type:
        reasons.add("PASS2_CONTEXT_TYPE_MISMATCH")
    if pass2 is not None and _value(pass2, "bypass_state") != bypass_state:
        reasons.add("PASS2_BYPASS_STATE_MISMATCH")
    if _value(pass2, "completeness_state") != COMPLETENESS_COMPLETE:
        reasons.add("PASS2_RESULT_INCOMPLETE")
    if _value(pass2, "permission_definition_version") != permission_version:
        reasons.add("PASS2_PERMISSION_DEFINITION_VERSION_MISMATCH")
    if _value(pass2, "snapshot_or_fixture_version") != source_version:
        reasons.add("PASS2_SOURCE_VERSION_MISMATCH")

    raw_guild_decimal, raw_guild = _parse_permission(
        _coalesce(request.raw_guild_permission_decimal, pass2, "raw_guild_permission_decimal")
    )
    raw_context_decimal, raw_context = _parse_permission(
        _coalesce(request.raw_context_permission_decimal, pass2, "raw_context_permission_decimal")
    )
    pass2_raw_guild_decimal, pass2_raw_guild = _parse_permission(_value(pass2, "raw_guild_permission_decimal"))
    pass2_raw_context_decimal, pass2_raw_context = _parse_permission(_value(pass2, "raw_context_permission_decimal"))
    if request.raw_guild_permission_decimal is not None and pass2_raw_guild is not None and raw_guild != pass2_raw_guild:
        reasons.add("PASS2_RAW_GUILD_PERMISSION_MISMATCH")
    if request.raw_context_permission_decimal is not None and pass2_raw_context is not None and raw_context != pass2_raw_context:
        reasons.add("PASS2_RAW_CONTEXT_PERMISSION_MISMATCH")
    raw_guild_hex = request.raw_guild_permission_hex or _value(pass2, "raw_guild_permission_hex")
    raw_context_hex = request.raw_context_permission_hex or _value(pass2, "raw_context_permission_hex")
    if raw_guild_hex is _MISSING:
        raw_guild_hex = format(raw_guild, "#x") if raw_guild is not None else None
    if raw_context_hex is _MISSING:
        raw_context_hex = format(raw_context, "#x") if raw_context is not None else None
    if raw_guild is not None and raw_guild_hex != format(raw_guild, "#x"):
        reasons.add("RAW_GUILD_PERMISSION_HEX_MISMATCH")
    if raw_context is not None and raw_context_hex != format(raw_context, "#x"):
        reasons.add("RAW_CONTEXT_PERMISSION_HEX_MISMATCH")
    if raw_guild is None:
        reasons.add("RAW_GUILD_PERMISSION_MISSING_OR_INVALID")
    if raw_context is None:
        reasons.add("RAW_CONTEXT_PERMISSION_MISSING_OR_INVALID")

    known_decimal = _coalesce(request.known_permission_bits_decimal, pass2, "known_context_permission_bits_decimal")
    unknown_decimal = _coalesce(request.unknown_permission_bits_decimal, pass2, "unknown_context_permission_bits_decimal")
    _known_decimal, known_value = _parse_permission(known_decimal)
    _unknown_decimal, unknown_value = _parse_permission(unknown_decimal)
    if raw_context is not None:
        expected_known = raw_context & KNOWN_PERMISSION_MASK
        expected_unknown = raw_context & ~KNOWN_PERMISSION_MASK
        if known_value != expected_known:
            reasons.add("KNOWN_PERMISSION_BITS_MISMATCH")
        if unknown_value != expected_unknown:
            reasons.add("UNKNOWN_PERMISSION_BITS_MISMATCH")
    known_out = str(known_value) if known_value is not None else None
    known_hex_out = format(known_value, "#x") if known_value is not None else None
    unknown_out = str(unknown_value) if unknown_value is not None else None
    unknown_hex_out = format(unknown_value, "#x") if unknown_value is not None else None
    known_hex_input = request.known_permission_bits_hex or _value(pass2, "known_context_permission_bits_hex")
    unknown_hex_input = request.unknown_permission_bits_hex or _value(pass2, "unknown_context_permission_bits_hex")
    if known_hex_input is _MISSING:
        known_hex_input = known_hex_out
    if unknown_hex_input is _MISSING:
        unknown_hex_input = unknown_hex_out
    if known_value is not None and known_hex_input != known_hex_out:
        reasons.add("KNOWN_PERMISSION_BITS_HEX_MISMATCH")
    if unknown_value is not None and unknown_hex_input != unknown_hex_out:
        reasons.add("UNKNOWN_PERMISSION_BITS_HEX_MISMATCH")
    if unknown_value not in (None, 0):
        reasons.add("UNKNOWN_PERMISSION_BITS_PRESENT")

    raw_unchanged = (
        raw_context is not None
        and raw_context_hex == format(raw_context, "#x")
        and known_value == (raw_context & KNOWN_PERMISSION_MASK)
        and unknown_value == (raw_context & ~KNOWN_PERMISSION_MASK)
    )

    trace.append(
        CapabilityTraceEvent(
            sequence=0,
            stage="INPUT_VALIDATION",
            details={
                "guild_id": guild_id,
                "subject_id": subject_id,
                "context_id": context_id,
                "context_type": context_type,
                "pass2_contract_version": pass2_contract if isinstance(pass2_contract, str) else None,
                "pass1_contract_version": pass1_contract if isinstance(pass1_contract, str) else None,
                "validation_reason_codes": sorted(reasons),
            },
        )
    )
    trace.append(
        CapabilityTraceEvent(
            sequence=0,
            stage="RAW_CONTEXT_INPUT",
            details={
                "raw_guild_permission": _state(raw_guild),
                "raw_context_permission": _state(raw_context),
                "raw_permission_bits_unchanged": raw_unchanged,
            },
        )
    )
    trace.append(
        CapabilityTraceEvent(
            sequence=0,
            stage="BYPASS",
            details={
                "bypass_state": bypass_state,
                "bypass_active": bypass_state in {BYPASS_OWNER, BYPASS_ADMINISTRATOR},
                "timeout_exempt": bypass_state in {BYPASS_OWNER, BYPASS_ADMINISTRATOR},
            },
        )
    )

    validation_blockers = {
        "PASS2_RESULT_MISSING",
        "PASS2_CONTRACT_MISMATCH",
        "PASS1_CONTRACT_MISMATCH",
        "PASS2_GUILD_ID_MISMATCH",
        "PASS2_SUBJECT_ID_MISMATCH",
        "PASS2_CONTEXT_ID_MISMATCH",
        "PASS2_CONTEXT_TYPE_MISMATCH",
        "PASS2_BYPASS_STATE_MISMATCH",
        "PASS2_RESULT_INCOMPLETE",
        "PASS2_PERMISSION_DEFINITION_VERSION_MISMATCH",
        "PASS2_SOURCE_VERSION_MISMATCH",
        "RAW_GUILD_PERMISSION_MISSING_OR_INVALID",
        "RAW_CONTEXT_PERMISSION_MISSING_OR_INVALID",
        "PASS2_RAW_GUILD_PERMISSION_MISMATCH",
        "PASS2_RAW_CONTEXT_PERMISSION_MISMATCH",
        "RAW_GUILD_PERMISSION_HEX_MISMATCH",
        "RAW_CONTEXT_PERMISSION_HEX_MISMATCH",
        "KNOWN_PERMISSION_BITS_MISMATCH",
        "UNKNOWN_PERMISSION_BITS_MISMATCH",
        "KNOWN_PERMISSION_BITS_HEX_MISMATCH",
        "UNKNOWN_PERMISSION_BITS_HEX_MISMATCH",
        "BYPASS_STATE_INVALID",
        "TIMEOUT_STATE_MISSING_OR_INVALID",
        "PERMISSION_DEFINITION_VERSION_MISMATCH",
        "PERMISSION_DEFINITION_VERSION_MISSING",
        "SNAPSHOT_OR_FIXTURE_VERSION_MISSING",
        "SNAPSHOT_OR_FIXTURE_VERSION_UNSUPPORTED",
        "GUILD_ID_INVALID",
        "SUBJECT_ID_INVALID",
        "CONTEXT_ID_INVALID",
        "CONTEXT_TYPE_MISSING",
        "INPUT_HEALTH_MISSING",
        "INPUT_HEALTH_INVALID",
        "INPUT_HEALTH_INCOMPLETE",
    }
    can_expand = (
        not (reasons & validation_blockers)
        and not registry_reasons
        and context_type in set(SUPPORTED_EXECUTABLE_CONTEXTS) | {"CATEGORY"}
    )

    records: list[CapabilityRecord] = []
    uncertainties: list[Mapping[str, Any]] = []
    if can_expand:
        assert raw_context is not None
        bypass_active = bypass_state in {BYPASS_OWNER, BYPASS_ADMINISTRATOR}
        context_is_category = context_type == "CATEGORY"
        known_flags = _flag_names(registry, raw_context & KNOWN_PERMISSION_MASK)
        known_guild_flags = _flag_names(registry, raw_guild & KNOWN_PERMISSION_MASK if raw_guild is not None else None)
        for definition in sorted(registry.capabilities, key=lambda item: (item.permission_bit, item.capability_key)):
            raw_granted = bool(raw_context & (1 << definition.permission_bit))
            permission_satisfied = raw_granted or bypass_active
            source_bypass = bypass_state if bypass_active else None
            records.append(
                _evaluate_definition(
                    definition,
                    context_type=context_type,
                    raw_context=raw_context,
                    raw_granted=raw_granted,
                    permission_satisfied=permission_satisfied,
                    source_bypass=source_bypass,
                    timeout_state=timeout_state,
                    bypass_active=bypass_active,
                    context_is_category=context_is_category,
                    raw_unchanged=raw_unchanged,
                    trace=trace,
                    uncertainties=uncertainties,
                )
            )
    else:
        known_flags = _flag_names(registry, known_value)
        known_guild_flags = _flag_names(registry, (raw_guild & KNOWN_PERMISSION_MASK) if raw_guild is not None else None)

    # Input-independent uncertainty records are still useful when no capability can be expanded.
    if unknown_value not in (None, 0):
        uncertainties.append(
            {
                "rule_id": "UNKNOWN-PERM-001",
                "state": "UNKNOWN",
                "unknown_bits_decimal": unknown_out,
                "unknown_bits_hex": unknown_hex_out,
                "notes": "Unknown permission bits are preserved but never assigned a fabricated capability.",
            }
        )
    if timeout_state == "UNKNOWN":
        uncertainties.append(
            {
                "rule_id": DEP_TIMEOUT,
                "state": "UNKNOWN",
                "notes": "Timeout state is material and was not defaulted to active or inactive.",
            }
        )
    uncertainties = sorted(
        {_canonical_json_key(item): item for item in uncertainties}.values(),
        key=lambda item: (str(item.get("rule_id", "")), str(item.get("capability_key", ""))),
    )

    effective = tuple(item for item in records if item.final_result == FINAL_ALLOWED)
    ineffective = tuple(item for item in records if item.final_result == FINAL_INEFFECTIVE)
    denied = tuple(item for item in records if item.final_result == FINAL_DENIED)
    unknown = tuple(item for item in records if item.final_result == FINAL_UNKNOWN)
    inapplicable = tuple(item for item in records if item.final_result == FINAL_NOT_APPLICABLE)
    policy_only = tuple(item for item in records if item.final_result == FINAL_POLICY_ONLY)

    if unknown:
        reasons.add("CAPABILITY_RESULT_UNKNOWN")
    if any(item.verification_status == "NEEDS_TEST" and item.raw_granted for item in records):
        reasons.add("CAPABILITY_VERIFICATION_NEEDS_TEST")
    if context_type == "CATEGORY" and records:
        reasons.add("CATEGORY_POLICY_ONLY")
    expansion_complete = (
        can_expand
        and not unknown
        and not registry_reasons
        and not (unknown_value not in (None, 0))
        and timeout_state in {"ACTIVE", "INACTIVE"}
    )
    if expansion_complete:
        reasons.add("CAPABILITY_EXPANSION_COMPLETE")

    stage_order = {
        "INPUT_VALIDATION": 0,
        "RAW_CONTEXT_INPUT": 1,
        "BYPASS": 2,
        "FLAG_EXPANSION": 3,
        "CONTEXT_APPLICABILITY": 4,
        "DEPENDENCY": 5,
        "TIMEOUT": 6,
        "CAPABILITY_RESULT": 7,
    }
    fixed_prefix = trace[:3]
    decision_trace = sorted(
        trace[3:],
        key=lambda event: (
            stage_order.get(event.stage, 99),
            int(event.details.get("permission_bit", -1)),
            str(event.details.get("capability_key", "")),
            repr(event.details.get("blocking_rule_ids", ())),
        ),
    )
    trace = fixed_prefix + decision_trace

    unsupported_context = bool(reasons & {"UNSUPPORTED_THREAD_CONTEXT", "UNSUPPORTED_OR_UNKNOWN_CONTEXT_TYPE"})
    if not unsupported_context and any(code in reasons for code in {"PASS2_RESULT_MISSING", "RAW_CONTEXT_PERMISSION_MISSING_OR_INVALID", "GUILD_ID_INVALID", "SUBJECT_ID_INVALID", "CONTEXT_ID_INVALID", "CONTEXT_TYPE_MISSING", "INPUT_HEALTH_MISSING", "INPUT_HEALTH_INVALID"}):
        completeness = COMPLETENESS_UNKNOWN
    elif reasons - {"CAPABILITY_EXPANSION_COMPLETE"}:
        completeness = COMPLETENESS_PARTIAL
    else:
        completeness = COMPLETENESS_COMPLETE
    if completeness == COMPLETENESS_COMPLETE and not expansion_complete:
        completeness = COMPLETENESS_PARTIAL
    trace.append(
        CapabilityTraceEvent(
            sequence=0,
            stage="COMPLETENESS",
            details={"state": completeness, "reason_codes": sorted(reasons)},
        )
    )
    finalized_trace = tuple(
        CapabilityTraceEvent(index, event.stage, event.details)
        for index, event in enumerate(trace, start=1)
    )

    raw_guild_out, raw_guild_hex_out, _, _, _, _ = _permission_parts(raw_guild)
    raw_context_out, raw_context_hex_out, _, _, _, _ = _permission_parts(raw_context)
    return CapabilityExpansionResult(
        engine_contract_version=STAGE3_PASS3_ENGINE_CONTRACT_VERSION,
        pass2_contract_version=pass2_contract if isinstance(pass2_contract, str) else STAGE3_PASS2_ENGINE_CONTRACT_VERSION,
        pass1_contract_version=pass1_contract if isinstance(pass1_contract, str) else STAGE3_PASS1_ENGINE_CONTRACT_VERSION,
        capability_registry_version=getattr(registry, "version", CAPABILITY_REGISTRY_VERSION),
        permission_definition_version=permission_version if isinstance(permission_version, str) else None,
        snapshot_or_fixture_version=source_version if isinstance(source_version, str) else None,
        guild_id=guild_id,
        subject_id=subject_id,
        context_id=context_id,
        context_type=context_type,
        bypass_state=bypass_state,
        timeout_state=timeout_state,
        raw_guild_permission_decimal=raw_guild_out,
        raw_guild_permission_hex=raw_guild_hex_out,
        raw_context_permission_decimal=raw_context_out,
        raw_context_permission_hex=raw_context_hex_out,
        known_context_permission_bits_decimal=known_out,
        known_context_permission_bits_hex=known_hex_out,
        unknown_context_permission_bits_decimal=unknown_out,
        unknown_context_permission_bits_hex=unknown_hex_out,
        known_granted_permission_flags=tuple(known_flags),
        known_granted_guild_permission_flags=tuple(known_guild_flags),
        effective_capability_records=tuple(effective),
        ineffective_grant_records=tuple(ineffective),
        denied_capability_records=tuple(denied),
        unknown_capability_records=tuple(unknown),
        inapplicable_capability_records=tuple(inapplicable),
        policy_only_category_records=tuple(policy_only),
        dependency_uncertainties=tuple(uncertainties),
        completeness_state=completeness,
        input_health_state=health_state,
        raw_permission_bits_unchanged=raw_unchanged,
        reason_codes=tuple(sorted(reasons)),
        trace=finalized_trace,
    )


def _evaluate_definition(
    definition: CapabilityDefinition,
    *,
    context_type: str,
    raw_context: int,
    raw_granted: bool,
    permission_satisfied: bool,
    source_bypass: str | None,
    timeout_state: str | None,
    bypass_active: bool,
    context_is_category: bool,
    raw_unchanged: bool,
    trace: list[CapabilityTraceEvent],
    uncertainties: list[Mapping[str, Any]],
) -> CapabilityRecord:
    """Apply one registry mapping in the fixed Pass 3 decision order."""

    def add(stage: str, previous: str, new: str, blocking: tuple[str, ...] = ()) -> None:
        trace.append(
            CapabilityTraceEvent(
                sequence=0,
                stage=stage,
                details=_trace_details(
                    definition,
                    context_type=context_type,
                    raw_context=raw_context,
                    raw_unchanged=raw_unchanged,
                    previous=previous,
                    new=new,
                    blocking=blocking,
                    source_bypass=source_bypass,
                ),
            )
        )

    add("FLAG_EXPANSION", "UNSEEN", "RAW_GRANTED" if raw_granted else "RAW_NOT_GRANTED")
    if context_is_category:
        add("CONTEXT_APPLICABILITY", "RAW_GRANTED" if raw_granted else "RAW_NOT_GRANTED", FINAL_POLICY_ONLY)
        add("DEPENDENCY", FINAL_POLICY_ONLY, FINAL_POLICY_ONLY)
        add("TIMEOUT", FINAL_POLICY_ONLY, FINAL_POLICY_ONLY)
        add("CAPABILITY_RESULT", FINAL_POLICY_ONLY, FINAL_POLICY_ONLY)
        return CapabilityRecord(
            capability_key=definition.capability_key,
            source_permission_flag=definition.source_permission_flag,
            source_bypass=source_bypass,
            scope="POLICY_ONLY",
            raw_granted=raw_granted,
            permission_satisfied=permission_satisfied,
            context_applicable=False,
            dependency_result="POLICY_ONLY",
            timeout_result="EXEMPT" if bypass_active else "POLICY_ONLY",
            final_result=FINAL_POLICY_ONLY,
            blocking_rule_ids=(),
            verification_status=definition.verification_status,
            source_references=definition.source_references,
            notes=(definition.notes + " " if definition.notes else "") + "CATEGORY is structural policy context only; no executable action is claimed.",
        )

    context_applicable = context_type in definition.context_types
    state = "RAW_GRANTED" if raw_granted else "RAW_NOT_GRANTED"
    if not context_applicable:
        add("CONTEXT_APPLICABILITY", state, FINAL_NOT_APPLICABLE)
        add("DEPENDENCY", FINAL_NOT_APPLICABLE, FINAL_NOT_APPLICABLE)
        add("TIMEOUT", FINAL_NOT_APPLICABLE, FINAL_NOT_APPLICABLE)
        add("CAPABILITY_RESULT", FINAL_NOT_APPLICABLE, FINAL_NOT_APPLICABLE)
        return CapabilityRecord(
            capability_key=definition.capability_key,
            source_permission_flag=definition.source_permission_flag,
            source_bypass=source_bypass,
            scope=definition.scope,
            raw_granted=raw_granted,
            permission_satisfied=permission_satisfied,
            context_applicable=False,
            dependency_result="NOT_APPLICABLE",
            timeout_result="NOT_APPLICABLE",
            final_result=FINAL_NOT_APPLICABLE,
            blocking_rule_ids=(),
            verification_status=definition.verification_status,
            source_references=definition.source_references,
            notes=definition.notes,
        )
    add("CONTEXT_APPLICABILITY", state, "APPLICABLE")

    blocking: list[str] = []
    dependency_result = "NOT_EVALUATED" if not permission_satisfied else "SATISFIED"
    if permission_satisfied:
        if (
            definition.scope != "GUILD"
            and definition.capability_key not in _VIEW_CAPABILITY_KEYS
            and not bypass_active
            and not raw_context & _VIEW_BIT
        ):
            blocking.append(DEP_VIEW_CHANNEL)
            dependency_result = "INEFFECTIVE"
        if (
            definition.capability_key in _SEND_DEPENDENT_CAPABILITY_KEYS
            and not bypass_active
            and not raw_context & _SEND_BIT
        ):
            blocking.append(DEP_SEND_MESSAGES)
            dependency_result = "INEFFECTIVE"
        if (
            definition.capability_key in _VOICE_CONNECTION_DEPENDENT_KEYS
            and not bypass_active
            and not raw_context & _CONNECT_BIT
        ):
            blocking.append(DEP_VOICE_CONNECT)
            dependency_result = "UNKNOWN"
            uncertainties.append(
                {
                    "rule_id": DEP_VOICE_CONNECT,
                    "capability_key": definition.capability_key,
                    "state": "UNKNOWN",
                    "verification_status": "NEEDS_TEST",
                    "notes": "CONNECT-absent voice/stage behavior is not treated as ALLOWED.",
                }
            )
        if definition.capability_key in _UNKNOWN_BEHAVIOR_CAPABILITY_KEYS:
            blocking.append(DEP_EXTERNAL_APP_BEHAVIOR)
            dependency_result = "UNKNOWN"
            uncertainties.append(
                {
                    "rule_id": DEP_EXTERNAL_APP_BEHAVIOR,
                    "capability_key": definition.capability_key,
                    "state": "UNKNOWN",
                    "verification_status": "NEEDS_TEST",
                    "notes": definition.notes,
                }
            )
    blocking_tuple = tuple(sorted(set(blocking)))
    state = FINAL_INEFFECTIVE if dependency_result == "INEFFECTIVE" else FINAL_UNKNOWN if dependency_result == "UNKNOWN" else state
    add("DEPENDENCY", "APPLICABLE", state, blocking_tuple)

    if bypass_active:
        timeout_result = "EXEMPT"
    elif timeout_state == "ACTIVE":
        timeout_result = "INACTIVE" if definition.capability_key in _VIEW_CAPABILITY_KEYS else "INEFFECTIVE"
        if definition.capability_key not in _VIEW_CAPABILITY_KEYS and permission_satisfied:
            blocking.append(DEP_TIMEOUT)
            if state not in {FINAL_INEFFECTIVE}:
                state = FINAL_INEFFECTIVE
    elif timeout_state == "UNKNOWN":
        timeout_result = "UNKNOWN"
        if permission_satisfied and definition.capability_key not in _VIEW_CAPABILITY_KEYS:
            blocking.append(DEP_TIMEOUT)
            if state not in {FINAL_INEFFECTIVE}:
                state = FINAL_UNKNOWN
    else:
        timeout_result = "INACTIVE"
    blocking_tuple = tuple(sorted(set(blocking)))
    add("TIMEOUT", state, state, blocking_tuple)

    if not permission_satisfied:
        final_result = FINAL_DENIED
    elif state == FINAL_INEFFECTIVE:
        final_result = FINAL_INEFFECTIVE
    elif state == FINAL_UNKNOWN:
        final_result = FINAL_UNKNOWN
    else:
        final_result = FINAL_ALLOWED
    add("CAPABILITY_RESULT", state, final_result, blocking_tuple)
    return CapabilityRecord(
        capability_key=definition.capability_key,
        source_permission_flag=definition.source_permission_flag,
        source_bypass=source_bypass,
        scope=definition.scope,
        raw_granted=raw_granted,
        permission_satisfied=permission_satisfied,
        context_applicable=True,
        dependency_result=dependency_result,
        timeout_result=timeout_result,
        final_result=final_result,
        blocking_rule_ids=blocking_tuple,
        verification_status=definition.verification_status,
        source_references=definition.source_references,
        notes=definition.notes,
    )


def _canonical_json_key(value: Mapping[str, Any]) -> str:
    return repr(sorted((str(key), repr(value[key])) for key in value))


def evaluate_effective_capabilities(request: CapabilityExpansionRequest) -> CapabilityExpansionResult:
    """Compatibility name for the Pass 3 pure expansion boundary."""

    return evaluate_capability_expansion(request)


def expand_effective_capabilities(request: CapabilityExpansionRequest) -> CapabilityExpansionResult:
    """Explicit verb for callers that describe Pass 3 as an expansion."""

    return evaluate_capability_expansion(request)


__all__ = [
    "CapabilityExpansionRequest",
    "CapabilityExpansionResult",
    "CapabilityRecord",
    "CapabilityTraceEvent",
    "FINAL_ALLOWED",
    "FINAL_DENIED",
    "FINAL_INEFFECTIVE",
    "FINAL_NOT_APPLICABLE",
    "FINAL_POLICY_ONLY",
    "FINAL_UNKNOWN",
    "STAGE3_PASS3_ENGINE_CONTRACT_VERSION",
    "SUPPORTED_CONTEXT_TYPES",
    "TIMEOUT_STATES",
    "evaluate_capability_expansion",
    "evaluate_effective_capabilities",
    "expand_effective_capabilities",
]
