"""Deterministic owner-only authorization policy used by commands and integration tests."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class OwnerAuthorizationDecision:
    allowed: bool
    code: str
    guild_id: str | None
    actor_id: str | None
    owner_id: str | None


def evaluate_owner_authorization(
    *,
    guild_id: int | str | None,
    actor_id: int | str | None,
    owner_id: int | str | None,
) -> OwnerAuthorizationDecision:
    """Evaluate private-alpha owner access without relying on cached roles.

    Missing or malformed identity fails closed.  This function has no Discord
    side effects and is shared by command handling and Pass 5 verification.
    """

    guild = _optional_snowflake(guild_id)
    actor = _optional_snowflake(actor_id)
    owner = _optional_snowflake(owner_id)

    if guild is None or actor is None:
        return OwnerAuthorizationDecision(False, "GUILD_CONTEXT_REQUIRED", guild, actor, owner)
    if owner is None:
        return OwnerAuthorizationDecision(False, "OWNER_LOOKUP_UNAVAILABLE", guild, actor, owner)
    if actor != owner:
        return OwnerAuthorizationDecision(False, "OWNER_ONLY", guild, actor, owner)
    return OwnerAuthorizationDecision(True, "OWNER_AUTHORIZED", guild, actor, owner)


def _optional_snowflake(value: int | str | None) -> str | None:
    if value is None or isinstance(value, bool):
        return None
    text = str(value).strip()
    if not text.isdecimal() or int(text) <= 0:
        return None
    return str(int(text))
