"""Trusted local paths for one future Pass 4E session; no Discord boundary."""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json
import re
import secrets
from pathlib import Path, PureWindowsPath

PATH_POLICY_VERSION = "GUILD-DOCTOR-STAGE8-PASS4E-SESSION-ARTIFACT-PATHS-0.1"
NAMESPACE_FORMAT_VERSION = "GUILD-DOCTOR-STAGE8-PASS4E-NAMESPACE-0.1"
DEFAULT_APPROVED_ROOT = Path(r"C:\GuildDoctor-Local")
REPAIR4D_NAMESPACE = "repair4d"
MULTI_SESSION_NAMESPACE_PREFIX = "repair4d_"
_ISSUANCE = re.compile(r"^[0-9a-f]{32}$")

class SessionArtifactPathError(RuntimeError): pass


def canonical_issuance_binding(issuance_reference: str) -> dict[str, str]:
    """Return filesystem-independent bound names for one trusted reference.

    This validator is deliberately free of creation-state checks.  Authority
    records must remain valid while their store owns its lock file; path
    collision checks belong to artifact creation, not record validation.
    """
    if not isinstance(issuance_reference, str) or not _ISSUANCE.fullmatch(issuance_reference):
        raise SessionArtifactPathError("STAGE8_PASS4E_SESSION_ISSUANCE_IDENTIFIER_INVALID")
    namespace = MULTI_SESSION_NAMESPACE_PREFIX + issuance_reference
    authority_basename = f"stage8_pass4e_{namespace}_authority.json"
    receipt_basename = f"stage8_pass4e_{namespace}_runtime_receipt.json"
    value = {
        "policy": PATH_POLICY_VERSION,
        "namespace": namespace,
        "issuance": issuance_reference,
        "authority": authority_basename.casefold(),
        "receipt": receipt_basename.casefold(),
    }
    return {
        "issuance_reference": issuance_reference,
        "session_namespace": namespace,
        "namespace_format_version": NAMESPACE_FORMAT_VERSION,
        "authority_basename": authority_basename,
        "receipt_basename": receipt_basename,
        "binding_fingerprint": sha256(
            json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
    }

def _windows_key(path: Path) -> str:
    return str(PureWindowsPath(str(path))).replace("/", "\\").casefold()

def _validate(path: Path, root: Path, expected_name: str) -> Path:
    if not isinstance(path, Path) or not path.is_absolute() or path.suffix.casefold() != ".json":
        raise SessionArtifactPathError("STAGE8_PASS4E_SESSION_ARTIFACT_PATH_INVALID")
    raw = str(path)
    if raw.startswith("\\\\") or raw.startswith("\\\\?\\") or any(ord(c) < 32 for c in raw):
        raise SessionArtifactPathError("STAGE8_PASS4E_SESSION_ARTIFACT_PATH_INVALID")
    root = root.resolve(strict=False)
    resolved = path.resolve(strict=False)
    if _windows_key(resolved.parent) != _windows_key(root) or resolved.name.casefold() != expected_name.casefold():
        raise SessionArtifactPathError("STAGE8_PASS4E_SESSION_ARTIFACT_PATH_OUTSIDE_APPROVED_ROOT")
    if resolved.exists() and resolved.is_dir():
        raise SessionArtifactPathError("STAGE8_PASS4E_SESSION_ARTIFACT_PATH_IS_DIRECTORY")
    if resolved.exists() and resolved.is_symlink():
        raise SessionArtifactPathError("STAGE8_PASS4E_SESSION_ARTIFACT_REPARSE_ESCAPE")
    return resolved

@dataclass(frozen=True, slots=True)
class SessionArtifactPaths:
    approved_root: Path
    session_namespace: str
    authority_path: Path
    receipt_path: Path

    @classmethod
    def repair4d(cls, *, approved_root: Path = DEFAULT_APPROVED_ROOT) -> "SessionArtifactPaths":
        root = Path(approved_root).resolve(strict=False)
        return cls(root, REPAIR4D_NAMESPACE, root / "stage8_pass4e_repair4d_authority.json", root / "stage8_pass4e_repair4d_runtime_receipt.json").validated()

    @classmethod
    def for_issuance(cls, issuance_identifier: str, *, approved_root: Path = DEFAULT_APPROVED_ROOT) -> "SessionArtifactPaths":
        binding = canonical_issuance_binding(issuance_identifier)
        root = Path(approved_root).resolve(strict=False)
        return cls(
            root,
            binding["session_namespace"],
            root / binding["authority_basename"],
            root / binding["receipt_basename"],
        ).validated()

    @classmethod
    def generate(cls, *, approved_root: Path = DEFAULT_APPROVED_ROOT) -> "SessionArtifactPaths":
        return cls.for_issuance(secrets.token_hex(16), approved_root=approved_root)

    @property
    def issuance_identifier(self) -> str | None:
        return self.session_namespace.removeprefix(MULTI_SESSION_NAMESPACE_PREFIX) if self.session_namespace.startswith(MULTI_SESSION_NAMESPACE_PREFIX) else None

    def validated(self) -> "SessionArtifactPaths":
        issuance = self.issuance_identifier
        if self.session_namespace != REPAIR4D_NAMESPACE and (issuance is None or not _ISSUANCE.fullmatch(issuance)):
            raise SessionArtifactPathError("STAGE8_PASS4E_SESSION_NAMESPACE_INVALID")
        root = Path(self.approved_root).resolve(strict=False)
        authority_name = "stage8_pass4e_repair4d_authority.json" if issuance is None else f"stage8_pass4e_{self.session_namespace}_authority.json"
        receipt_name = "stage8_pass4e_repair4d_runtime_receipt.json" if issuance is None else f"stage8_pass4e_{self.session_namespace}_runtime_receipt.json"
        authority = _validate(Path(self.authority_path), root, authority_name)
        receipt = _validate(Path(self.receipt_path), root, receipt_name)
        if _windows_key(authority) == _windows_key(receipt):
            raise SessionArtifactPathError("STAGE8_PASS4E_SESSION_ARTIFACT_PATH_COLLISION")
        for path in (authority, receipt):
            for suffix in (".lock", ".tmp"):
                if path.with_suffix(path.suffix + suffix).exists():
                    raise SessionArtifactPathError("STAGE8_PASS4E_SESSION_ARTIFACT_CREATION_AMBIGUOUS")
        return SessionArtifactPaths(root, self.session_namespace, authority, receipt)

    @property
    def binding_fingerprint(self) -> str:
        if self.issuance_identifier is not None:
            return canonical_issuance_binding(self.issuance_identifier)["binding_fingerprint"]
        value = {"policy": PATH_POLICY_VERSION, "namespace": self.session_namespace, "issuance": self.issuance_identifier, "authority": self.authority_path.name.casefold(), "receipt": self.receipt_path.name.casefold()}
        return sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

__all__ = ["DEFAULT_APPROVED_ROOT", "MULTI_SESSION_NAMESPACE_PREFIX", "NAMESPACE_FORMAT_VERSION", "PATH_POLICY_VERSION", "REPAIR4D_NAMESPACE", "SessionArtifactPathError", "SessionArtifactPaths", "canonical_issuance_binding"]
