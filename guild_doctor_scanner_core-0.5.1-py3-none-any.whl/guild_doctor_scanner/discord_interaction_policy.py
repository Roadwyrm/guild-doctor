"""Deterministic offline acknowledgement and visibility policy."""
from __future__ import annotations


INTERACTION_POLICY_CONTRACT = "GUILD-DOCTOR-DISCORD-INTERACTION-POLICY-0.1"
IMMEDIATE_RESPONSE = "IMMEDIATE_RESPONSE"
DEFER_EPHEMERAL = "DEFER_EPHEMERAL"
DEFER_PUBLIC = "DEFER_PUBLIC"
REFUSE_BEFORE_DEFER = "REFUSE_BEFORE_DEFER"
INTERACTION_EXPIRED = "INTERACTION_EXPIRED"
INTERNAL_ERROR = "INTERNAL_ERROR"
IMMEDIATE_THRESHOLD_SECONDS = 1.0
EXPIRY_THRESHOLD_SECONDS = 14.0 * 60.0


def visibility_for(*, authorized: bool, requested_visibility: str, command_key: str) -> str:
    """Pass 3 private alpha never enables public diagnostic output."""
    del requested_visibility, command_key
    return "EPHEMERAL" if authorized else "EPHEMERAL"


def acknowledgement_for(*, authorized: bool, interaction_age_seconds: float, estimated_work: str = "STANDARD") -> str:
    if interaction_age_seconds >= EXPIRY_THRESHOLD_SECONDS:
        return INTERACTION_EXPIRED
    if not authorized:
        return REFUSE_BEFORE_DEFER
    if estimated_work in {"ENUMERATION", "EXPORT", "LARGE"} or interaction_age_seconds >= IMMEDIATE_THRESHOLD_SECONDS:
        return DEFER_EPHEMERAL
    return IMMEDIATE_RESPONSE
