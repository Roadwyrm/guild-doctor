"""Pure report-provider and deterministic Pass 5 interaction projection."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib

from .audit_contract import scan_report_private
from .canonical import sha256_hex
from .discord_interaction_envelope import InteractionEnvelope, REPORT_RESULT, ReportResultPayload
from .export_receipt_validation import (
    ExportReceiptValidationError,
    validate_export_receipt_metadata,
)
from .report_assembly import GuildDoctorReport, REPORT_CONTRACT


REPORT_PAGINATION_CONTRACT = "GUILD-DOCTOR-REPORT-PAGINATION-0.1"
REPORT_PAYLOAD_REPAIR_CONTRACT = "GUILD-DOCTOR-STAGE7-PASS5-REPORT-PAYLOAD-REPAIR-0.1"


class ReportInteractionError(ValueError):
    """Stable fail-closed report presentation error."""


@dataclass(frozen=True, slots=True)
class InjectedReportProvider:
    """Explicit test/offline provider; it never acquires data or contacts Discord."""

    report: GuildDoctorReport | None

    def get_report(self, guild_id: str) -> GuildDoctorReport:
        if self.report is None:
            raise ReportInteractionError("REPORT_UNAVAILABLE")
        if not isinstance(guild_id, str) or not guild_id:
            raise ReportInteractionError("REPORT_GUILD_INCOMPATIBLE")
        return _validated_report(self.report)


def _validated_report(report: GuildDoctorReport) -> GuildDoctorReport:
    if not isinstance(report, GuildDoctorReport) or report.report_contract != REPORT_CONTRACT:
        raise ReportInteractionError("REPORT_CONTRACT_INVALID")
    if scan_report_private(report.as_dict(), "report_provider_result"):
        raise ReportInteractionError("REPORT_PRIVACY_FAILED")
    if report.report_fingerprint != sha256_hex(report.as_dict(include_fingerprint=False)):
        raise ReportInteractionError("REPORT_FINGERPRINT_MISMATCH")
    if len(report.atlas_fingerprint) != 64 or any(character not in "0123456789abcdef" for character in report.atlas_fingerprint):
        raise ReportInteractionError("ATLAS_FINGERPRINT_MISMATCH")
    if len(report.source_snapshot_fingerprint) != 64 or any(character not in "0123456789abcdef" for character in report.source_snapshot_fingerprint):
        raise ReportInteractionError("REPORT_SNAPSHOT_INCOMPATIBLE")
    if any(section.total_item_count != len(section.items) for section in report.sections):
        raise ReportInteractionError("REPORT_RESULT_MALFORMED")
    return report


def _token(report: GuildDoctorReport, section: str, page: int, page_size: int) -> str:
    digest = hashlib.sha256(
        f"{REPORT_PAGINATION_CONTRACT}|{report.report_fingerprint}|{section}|{page}|{page_size}".encode("utf-8")
    ).hexdigest()
    return f"REPORT-CONT-{digest[:24].upper()}"


def _page_envelope(
    report: GuildDoctorReport,
    *,
    section_index: int,
    page_index: int,
    page_size: int,
) -> InteractionEnvelope:
    section = report.sections[section_index]
    total_page_count = max(1, (section.total_item_count + page_size - 1) // page_size)
    if page_index < 1 or page_index > total_page_count:
        raise ReportInteractionError("REPORT_CONTINUATION_INVALID")
    start = (page_index - 1) * page_size
    ordered_items = tuple(dict(item) for item in section.items[start:start + page_size])
    safe_provenance = (
        {"report_contract": report.report_contract},
        {"report_fingerprint": report.report_fingerprint},
        {"atlas_fingerprint": report.atlas_fingerprint},
        {"source_snapshot_reference": report.source_snapshot_fingerprint},
        {"pagination_contract": REPORT_PAGINATION_CONTRACT},
    )
    payload = ReportResultPayload(
        subtype="REPORT_PAGE",
        report_fingerprint=report.report_fingerprint,
        atlas_fingerprint=report.atlas_fingerprint,
        source_snapshot_reference=report.source_snapshot_fingerprint,
        report_contract=report.report_contract,
        section_identifier=section.section_id,
        section_ordinal=section.ordinal,
        section_state=section.state,
        completeness_state=section.state,
        page_index=page_index,
        total_page_count=total_page_count,
        total_section_count=len(report.sections),
        total_section_item_count=section.total_item_count,
        displayed_item_count=len(ordered_items),
        ordered_items=ordered_items,
        continuation_identifier=_token(report, section.section_id, page_index, page_size),
        previous_available=page_index > 1,
        next_available=page_index < total_page_count,
        safe_provenance=safe_provenance,
    )
    return InteractionEnvelope(REPORT_RESULT, report_result=payload)


def report_pages(report: GuildDoctorReport, *, page_size: int = 50) -> tuple[InteractionEnvelope, ...]:
    """Project every report section and item in frozen order, including empty sections."""
    report = _validated_report(report)
    if type(page_size) is not int or page_size < 1:
        raise ReportInteractionError("REPORT_CONTINUATION_INVALID")
    pages: list[InteractionEnvelope] = []
    try:
        for section_index, section in enumerate(report.sections):
            count = max(1, (section.total_item_count + page_size - 1) // page_size)
            pages.extend(
                _page_envelope(report, section_index=section_index, page_index=index, page_size=page_size)
                for index in range(1, count + 1)
            )
    except ReportInteractionError:
        raise
    except (TypeError, ValueError) as exc:
        raise ReportInteractionError("REPORT_PAGINATION_FAILED") from exc
    return tuple(pages)


def report_page(
    report: GuildDoctorReport,
    *,
    section_identifier: str | None = None,
    page_index: int = 1,
    page_size: int = 50,
    continuation_identifier: str | None = None,
) -> InteractionEnvelope:
    """Return one exact page by section/page or by deterministic continuation."""
    pages = report_pages(report, page_size=page_size)
    if continuation_identifier is not None:
        matches = tuple(
            page for page in pages
            if page.report_result is not None
            and page.report_result.continuation_identifier == continuation_identifier
        )
        if len(matches) != 1:
            raise ReportInteractionError("REPORT_CONTINUATION_INVALID")
        return matches[0]
    selected_section = section_identifier or report.sections[0].section_id
    matches = tuple(
        page for page in pages
        if page.report_result is not None
        and page.report_result.section_identifier == selected_section
        and page.report_result.page_index == page_index
    )
    if not any(section.section_id == selected_section for section in report.sections):
        raise ReportInteractionError("REPORT_SECTION_INVALID")
    if len(matches) != 1:
        raise ReportInteractionError("REPORT_CONTINUATION_INVALID")
    return matches[0]


def export_receipt(
    report: GuildDoctorReport,
    *,
    format: str,
    content_fingerprint: str,
    byte_count: int,
    safe_basename: str,
    write_status: str = "PREPARED",
    replacement_status: str = "NOT_REQUESTED",
    privacy_validation_status: str = "PASS",
    stable_reason: str = "EXPORT_PREPARED_NO_DELIVERY",
) -> InteractionEnvelope:
    """Project safe export metadata only; never content, a path, or credentials."""
    report = _validated_report(report)
    if not isinstance(content_fingerprint, str) or len(content_fingerprint) != 64:
        raise ReportInteractionError("EXPORT_RECEIPT_UNAVAILABLE")
    if type(byte_count) is not int or byte_count < 0:
        raise ReportInteractionError("EXPORT_RECEIPT_UNAVAILABLE")
    try:
        validated = validate_export_receipt_metadata(
            format=format,
            write_status=write_status,
            replacement_status=replacement_status,
            privacy_validation_status=privacy_validation_status,
            safe_basename=safe_basename,
            stable_reason=stable_reason,
        )
    except ExportReceiptValidationError as exc:
        raise ReportInteractionError(str(exc)) from None
    receipt = {
        "format": validated.format,
        "source_report_fingerprint": report.report_fingerprint,
        "content_fingerprint": content_fingerprint,
        "byte_count": byte_count,
        "write_status": validated.write_status,
        "replacement_status": validated.replacement_status,
        "privacy_validation_status": validated.privacy_validation_status,
        "safe_basename": validated.safe_basename,
        "stable_reason": validated.stable_reason,
    }
    if scan_report_private(receipt, "export_receipt"):
        raise ReportInteractionError("EXPORT_PRIVACY_FAILED")
    try:
        payload = ReportResultPayload(
            subtype="EXPORT_RECEIPT",
            report_fingerprint=report.report_fingerprint,
            atlas_fingerprint=report.atlas_fingerprint,
            source_snapshot_reference=report.source_snapshot_fingerprint,
            report_contract=report.report_contract,
            **receipt,
        )
    except ValueError as exc:
        raise ReportInteractionError(str(exc)) from exc
    return InteractionEnvelope(REPORT_RESULT, report_result=payload)


__all__ = [
    "InjectedReportProvider", "REPORT_PAGINATION_CONTRACT",
    "REPORT_PAYLOAD_REPAIR_CONTRACT", "ReportInteractionError",
    "export_receipt", "report_page", "report_pages",
]
