"""Versioned Stage 3 Pass 5 authority and operation registry.

This module is data-only.  It names the documented capability sources,
hierarchy subjects, target protections, and operation families without
combining them into an action decision.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

PERMISSION_SOURCE_URL = "https://docs.discord.com/developers/topics/permissions"
GUILD_SOURCE_URL = "https://docs.discord.com/developers/resources/guild"
CHANNEL_SOURCE_URL = "https://docs.discord.com/developers/resources/channel"
USER_SOURCE_URL = "https://docs.discord.com/developers/resources/user"
OAUTH2_SOURCE_URL = "https://docs.discord.com/developers/topics/oauth2"
AUTHORITY_RULES_VERSION = "GUILD-DOCTOR-AUTHORITY-RULES-0.1"

RULE_MEMBER_HIERARCHY = "DEP-HIERARCHY-MEMBER-001"
RULE_ROLE_HIERARCHY = "DEP-HIERARCHY-ROLE-001"
RULE_OWNER_PROTECTION = "DEP-TARGET-OWNER-001"
RULE_ADMIN_TIMEOUT_PROTECTION = "DEP-TARGET-ADMIN-TIMEOUT-001"
RULE_EVERYONE_ROLE = "DEP-EVERYONE-ROLE-001"
RULE_MANAGED_ROLE = "DEP-MANAGED-ROLE-001"
RULE_PERMISSION_SUBSET = "DEP-PERM-SUBSET-001"
RULE_TARGET_CHANNEL_EXCEPTION = "DEP-TARGET-CHANNEL-MANAGE-ROLES-001"
RULE_TARGET_MEMBER_UNRESOLVED = "DEP-TARGET-MEMBER-HIERARCHY-NEEDS-TEST"
RULE_ROLE_POSITION = "DEP-ROLE-POSITION-001"
RULE_VOICE_CONNECTION = "DEP-VOICE-CONNECTION-001"
RULE_VOICE_AUTHORITY = "DEP-VOICE-AUTHORITY-001"
RULE_CONTEXT_CONSISTENCY = "DEP-CONTEXT-CONSISTENCY-001"


@dataclass(frozen=True, slots=True)
class OperationDefinition:
    operation_key: str
    capability_key: str
    required_source_permission_flags: tuple[str, ...]
    target_types: tuple[str, ...]
    hierarchy_subject: str
    mfa_permission_flag: str | None = None
    subset_kind: str = "NONE"
    target_owner_protected: bool = False
    target_administrator_protected: bool = False
    managed_object_kind: str = "NONE"
    requires_proposed_position: bool = False
    requires_voice_state: bool = False
    target_member_interaction: bool = False
    verification_status: str = "VERIFIED"
    source_references: tuple[str, ...] = (PERMISSION_SOURCE_URL,)
    notes: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "operation_key": self.operation_key,
            "capability_key": self.capability_key,
            "required_source_permission_flags": list(self.required_source_permission_flags),
            "target_types": list(self.target_types),
            "hierarchy_subject": self.hierarchy_subject,
            "mfa_permission_flag": self.mfa_permission_flag,
            "subset_kind": self.subset_kind,
            "target_owner_protected": self.target_owner_protected,
            "target_administrator_protected": self.target_administrator_protected,
            "managed_object_kind": self.managed_object_kind,
            "requires_proposed_position": self.requires_proposed_position,
            "requires_voice_state": self.requires_voice_state,
            "target_member_interaction": self.target_member_interaction,
            "verification_status": self.verification_status,
            "source_references": list(self.source_references),
            "notes": self.notes,
        }


def _op(key: str, capability: str, flags: tuple[str, ...], targets: tuple[str, ...], hierarchy: str, **kwargs: Any) -> OperationDefinition:
    return OperationDefinition(key, capability, flags, targets, hierarchy, **kwargs)


AUTHORITY_OPERATIONS: tuple[OperationDefinition, ...] = tuple(
    sorted(
        (
            _op("member.kick", "member.kick", ("KICK_MEMBERS",), ("MEMBER",), "MEMBER", mfa_permission_flag="KICK_MEMBERS", target_owner_protected=True),
            _op("member.ban", "member.ban", ("BAN_MEMBERS",), ("MEMBER",), "MEMBER", mfa_permission_flag="BAN_MEMBERS", target_owner_protected=True),
            _op("nickname.manage_other", "member.manage_nicknames", ("MANAGE_NICKNAMES",), ("MEMBER",), "MEMBER", mfa_permission_flag=None, target_owner_protected=True),
            _op("member.timeout", "member.moderate", ("MODERATE_MEMBERS",), ("MEMBER",), "MEMBER", target_owner_protected=True, target_administrator_protected=True, notes="MODERATE_MEMBERS uses the timeout footnote, not the elevated MFA asterisk."),
            _op("role.create", "role.manage", ("MANAGE_ROLES",), ("NONE",), "PROPOSED_ROLE", mfa_permission_flag="MANAGE_ROLES", subset_kind="ROLE_PERMISSIONS", requires_proposed_position=True),
            _op("role.edit", "role.manage", ("MANAGE_ROLES",), ("ROLE",), "ROLE", mfa_permission_flag="MANAGE_ROLES", subset_kind="ROLE_PERMISSIONS", managed_object_kind="ROLE_EDIT"),
            _op("role.delete", "role.manage", ("MANAGE_ROLES",), ("ROLE",), "ROLE", mfa_permission_flag="MANAGE_ROLES", managed_object_kind="ROLE_DELETE"),
            _op("role.reorder", "role.manage", ("MANAGE_ROLES",), ("ROLE",), "ROLE", mfa_permission_flag="MANAGE_ROLES", managed_object_kind="ROLE_REORDER", requires_proposed_position=True),
            _op("role.permission_change", "role.manage", ("MANAGE_ROLES",), ("ROLE",), "ROLE", mfa_permission_flag="MANAGE_ROLES", subset_kind="ROLE_PERMISSIONS", managed_object_kind="ROLE_PERMISSION_CHANGE"),
            _op("member.role_assign", "role.manage", ("MANAGE_ROLES",), ("ROLE",), "ROLE", mfa_permission_flag="MANAGE_ROLES", target_member_interaction=True),
            _op("member.role_remove", "role.manage", ("MANAGE_ROLES",), ("ROLE",), "ROLE", mfa_permission_flag="MANAGE_ROLES", target_member_interaction=True),
            _op("channel.manage", "channel.manage", ("MANAGE_CHANNELS",), ("CHANNEL",), "NONE", mfa_permission_flag="MANAGE_CHANNELS"),
            _op("overwrite.permission_change", "overwrite.manage", ("MANAGE_ROLES",), ("OVERWRITE",), "NONE", mfa_permission_flag="MANAGE_ROLES", subset_kind="OVERWRITE_PERMISSIONS", source_references=(PERMISSION_SOURCE_URL, CHANNEL_SOURCE_URL)),
            _op("voice.member_move", "voice.move_members", ("MOVE_MEMBERS",), ("VOICE_STATE",), "NONE", requires_voice_state=True, verification_status="NEEDS_TEST", source_references=(PERMISSION_SOURCE_URL, CHANNEL_SOURCE_URL)),
            _op("voice.member_mute", "voice.mute_members", ("MUTE_MEMBERS",), ("VOICE_STATE",), "NONE", requires_voice_state=True, verification_status="NEEDS_TEST", source_references=(PERMISSION_SOURCE_URL, CHANNEL_SOURCE_URL)),
            _op("voice.member_deafen", "voice.deafen_members", ("DEAFEN_MEMBERS",), ("VOICE_STATE",), "NONE", requires_voice_state=True, verification_status="NEEDS_TEST", source_references=(PERMISSION_SOURCE_URL, CHANNEL_SOURCE_URL)),
            _op("guild.manage", "guild.manage", ("MANAGE_GUILD",), ("GUILD",), "NONE", mfa_permission_flag="MANAGE_GUILD"),
            _op("message.manage", "message.manage", ("MANAGE_MESSAGES",), ("NONE",), "NONE", mfa_permission_flag="MANAGE_MESSAGES"),
            _op("webhook.manage", "webhook.manage", ("MANAGE_WEBHOOKS",), ("NONE",), "NONE", mfa_permission_flag="MANAGE_WEBHOOKS"),
            _op("guild_expression.manage_all", "guild.expressions.manage", ("MANAGE_GUILD_EXPRESSIONS",), ("NONE",), "NONE", mfa_permission_flag="MANAGE_GUILD_EXPRESSIONS"),
            _op("thread.manage", "thread.manage", ("MANAGE_THREADS",), ("NONE",), "NONE", mfa_permission_flag="MANAGE_THREADS"),
            _op("monetization_analytics.view", "creator_analytics.view", ("VIEW_CREATOR_MONETIZATION_ANALYTICS",), ("NONE",), "NONE", mfa_permission_flag="VIEW_CREATOR_MONETIZATION_ANALYTICS"),
        ),
        key=lambda item: item.operation_key,
    )
)

AUTHORITY_OPERATIONS_BY_KEY = {item.operation_key: item for item in AUTHORITY_OPERATIONS}


def validate_authority_registry() -> tuple[str, ...]:
    reasons: list[str] = []
    keys = [item.operation_key for item in AUTHORITY_OPERATIONS]
    if len(keys) != len(set(keys)):
        reasons.append("DUPLICATE_OPERATION_KEY")
    if any(not item.operation_key or not item.capability_key or not item.target_types for item in AUTHORITY_OPERATIONS):
        reasons.append("MALFORMED_OPERATION_DEFINITION")
    if AUTHORITY_RULES_VERSION != "GUILD-DOCTOR-AUTHORITY-RULES-0.1":
        reasons.append("AUTHORITY_RULES_VERSION_MISMATCH")
    return tuple(sorted(set(reasons)))


AUTHORITY_RULES = {
    "version": AUTHORITY_RULES_VERSION,
    "rules": tuple(sorted({
        RULE_MEMBER_HIERARCHY, RULE_ROLE_HIERARCHY, RULE_OWNER_PROTECTION,
        RULE_ADMIN_TIMEOUT_PROTECTION, RULE_EVERYONE_ROLE, RULE_MANAGED_ROLE,
        RULE_PERMISSION_SUBSET, RULE_TARGET_CHANNEL_EXCEPTION,
        RULE_TARGET_MEMBER_UNRESOLVED, RULE_ROLE_POSITION,
        RULE_VOICE_CONNECTION, RULE_VOICE_AUTHORITY, RULE_CONTEXT_CONSISTENCY,
    })),
    "source_references": (PERMISSION_SOURCE_URL, GUILD_SOURCE_URL, CHANNEL_SOURCE_URL, USER_SOURCE_URL, OAUTH2_SOURCE_URL),
}


__all__ = [
    "AUTHORITY_OPERATIONS", "AUTHORITY_OPERATIONS_BY_KEY", "AUTHORITY_RULES", "AUTHORITY_RULES_VERSION",
    "CHANNEL_SOURCE_URL", "GUILD_SOURCE_URL", "OAUTH2_SOURCE_URL", "PERMISSION_SOURCE_URL", "USER_SOURCE_URL",
    "OperationDefinition", "RULE_ADMIN_TIMEOUT_PROTECTION", "RULE_CONTEXT_CONSISTENCY", "RULE_EVERYONE_ROLE",
    "RULE_MANAGED_ROLE", "RULE_MEMBER_HIERARCHY", "RULE_OWNER_PROTECTION", "RULE_PERMISSION_SUBSET",
    "RULE_ROLE_HIERARCHY", "RULE_ROLE_POSITION", "RULE_TARGET_CHANNEL_EXCEPTION", "RULE_TARGET_MEMBER_UNRESOLVED",
    "RULE_VOICE_AUTHORITY", "RULE_VOICE_CONNECTION", "validate_authority_registry",
]
