"""CLI for bounded, GET-only Stage 3 Pass 6 live authority verification."""

from __future__ import annotations

import argparse
import asyncio
import json
import math
import os
import re
import sys
import traceback
from pathlib import Path
from typing import Any, Iterable

from .acquisition import utc_now
from .authority_live_verifier import ReadOnlyTransportAudit, _failure_run, run_read_only_live_verification
from .discordpy_adapter import DiscordPyReadTransport
from .scenario_manifest import load_scenario_manifest


DEFAULT_NETWORK_TIMEOUT_SECONDS = 30.0
CONFIRMATION_VALUES = {"1", "true", "yes", "on"}
FAILURE_EXIT_CODE = 2
INTERRUPTED_EXIT_CODE = 130
_DISCORD_TOKEN_RE = re.compile(r"(?i)(?:mfa\.)?[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{20,}")
_DIAGNOSTIC_TRACEBACK_LIMIT = 16000


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run Guild Doctor Stage 3 Pass 6 read-only authority verification")
    parser.add_argument("guild_id", help="Disposable Discord guild ID")
    parser.add_argument("--scenario-manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--network-timeout-seconds", type=float, default=DEFAULT_NETWORK_TIMEOUT_SECONDS)
    return parser


class ProgressReporter:
    """Emit progress without allowing a broken Windows output handle to abort verification."""

    def __init__(
        self,
        output_dir: Path | None = None,
        *,
        stdout: Any | None = None,
        stderr: Any | None = None,
        secrets: Iterable[str] = (),
    ) -> None:
        self.output_dir = output_dir
        self.stdout = sys.stdout if stdout is None else stdout
        self.stderr = sys.stderr if stderr is None else stderr
        self.secrets = tuple(secret for secret in secrets if secret)
        self._stdout_failed = False
        self._fallback_used = False
        self._stream_errors: list[dict[str, Any]] = []
        self._log_path = output_dir / "transport_progress.log" if output_dir is not None else None

    def set_secrets(self, secrets: Iterable[str]) -> None:
        self.secrets = tuple(secret for secret in secrets if secret)

    def clear_secrets(self) -> None:
        self.secrets = ()

    def _safe_text(self, value: str) -> str:
        return _redact_text(value, self.secrets)

    def _record_stream_error(self, stream_name: str, exc: BaseException) -> None:
        self._fallback_used = True
        self._stream_errors.append({
            "stream": stream_name,
            "error_type": exc.__class__.__name__,
            "errno": getattr(exc, "errno", None),
            "message": self._safe_text(" ".join(str(exc).split()) or exc.__class__.__name__)[:500],
        })

    def _write_log(self, line: str) -> None:
        if self._log_path is None:
            return
        try:
            with self._log_path.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(line + "\n")
                handle.flush()
        except (OSError, ValueError) as exc:
            self._record_stream_error("progress_log", exc)

    def _write_stream(self, stream_name: str, stream: Any, line: str) -> bool:
        try:
            stream.write(line + "\n")
            stream.flush()
            return True
        except (OSError, ValueError) as exc:
            self._record_stream_error(stream_name, exc)
            return False

    def emit(self, message: str) -> None:
        line = self._safe_text(f"[Guild Doctor Stage 3 Pass 6] {message}")
        if not self._stdout_failed and self._write_stream("stdout", self.stdout, line):
            return
        self._stdout_failed = True
        if self._write_stream("stderr", self.stderr, line):
            return
        self._write_log(line)

    def error(self, message: str) -> None:
        line = self._safe_text(f"guild-doctor-stage3-authority-verify: {message}")
        if self._write_stream("stderr", self.stderr, line):
            return
        if not self._stdout_failed and self._write_stream("stdout", self.stdout, line):
            return
        self._stdout_failed = True
        self._write_log(line)

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": "FALLBACK" if self._fallback_used else "PASS",
            "fallback_used": self._fallback_used,
            "stream_errors": list(self._stream_errors),
            "progress_log_path": str(self._log_path) if self._log_path is not None else None,
        }


def _progress(message: str, reporter: ProgressReporter | None = None) -> None:
    (reporter or ProgressReporter()).emit(message)


def _error(message: str, reporter: ProgressReporter | None = None) -> None:
    (reporter or ProgressReporter()).error(message)


def _parse_snowflake(value: Any) -> str:
    text = str(value).strip()
    if not text.isdecimal() or int(text) <= 0:
        raise ValueError("guild_id must be a positive decimal snowflake")
    return str(int(text))


def _validate_args(args: argparse.Namespace) -> str:
    guild_id = _parse_snowflake(args.guild_id)
    timeout = float(args.network_timeout_seconds)
    if not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("--network-timeout-seconds must be a finite positive number")
    if args.output_dir.exists() and not args.output_dir.is_dir():
        raise OSError(f"output path exists and is not a directory: {args.output_dir}")
    return guild_id


def _redact_text(value: str, secrets: Iterable[str]) -> str:
    result = value
    for secret in secrets:
        if secret:
            result = result.replace(secret, "[REDACTED]")
    return _DISCORD_TOKEN_RE.sub("[REDACTED]", result)


def _redact_value(value: Any, secrets: Iterable[str]) -> Any:
    secret_values = tuple(secrets)
    if isinstance(value, dict):
        return {_redact_text(str(key), secret_values): _redact_value(item, secret_values) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact_value(item, secret_values) for item in value]
    if isinstance(value, tuple):
        return [_redact_value(item, secret_values) for item in value]
    if isinstance(value, str):
        return _redact_text(value, secret_values)
    return value


def _exception_message(exc: BaseException, secrets: Iterable[str] = ()) -> str:
    return _redact_text(" ".join(str(exc).split()) or exc.__class__.__name__, secrets)[:500]


def _exception_traceback(exc: BaseException, secrets: Iterable[str] = ()) -> str:
    text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    return _redact_text(text, secrets)[:_DIAGNOSTIC_TRACEBACK_LIMIT]


def _failure_code(exc: BaseException, stage: str) -> str:
    if isinstance(exc, (asyncio.CancelledError, KeyboardInterrupt)):
        return "INTERRUPTED"
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        return "NETWORK_TIMEOUT"
    status = getattr(exc, "status", None)
    if status == 401 or exc.__class__.__name__ in {"LoginFailure", "AuthenticationError"}:
        return "AUTHENTICATION_FAILED"
    if status == 403:
        return "AUTHORIZATION_DENIED"
    if isinstance(status, int):
        return f"HTTP_ERROR_{status}"
    if stage == "manifest":
        return "SCENARIO_MANIFEST_INVALID"
    if stage == "dependency":
        return "DEPENDENCY_MISSING"
    if stage == "transport_compatibility":
        return "TRANSPORT_COMPATIBILITY_FAILED"
    if stage == "acquisition":
        return "ACQUISITION_FAILED"
    if stage == "normalization":
        return "NORMALIZATION_FAILED"
    if stage == "comparison":
        return "COMPARISON_FAILED"
    if stage == "client_shutdown":
        return "NETWORK_TIMEOUT" if isinstance(exc, (asyncio.TimeoutError, TimeoutError)) else "CLIENT_SHUTDOWN_FAILED"
    if stage == "filesystem" or isinstance(exc, OSError):
        return "FILESYSTEM_FAILURE"
    if stage == "authentication":
        return "AUTHENTICATION_FAILED"
    return "VERIFICATION_FAILED"


def _write_json(path: Path, value: Any, secrets: Iterable[str]) -> None:
    safe = _redact_value(value, secrets)
    path.write_text(json.dumps(safe, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def _write_run(output_dir: Path, run: dict[str, Any], secrets: Iterable[str]) -> None:
    names = (
        "authority_verification_report",
        "authority_live_snapshot",
        "repeated_authority_live_snapshot",
        "action_results",
        "acquisition_health",
        "scenario_manifest_redacted",
        "verification_backlog",
        "transport_audit",
        "stage3_closure_assessment",
        "transport_compatibility_diagnostic",
    )
    for name in names:
        _write_json(output_dir / f"{name}.json", run.get(name), secrets)


def _failure_run_for(
    guild_id: str,
    reason: str,
    message: str,
    *,
    started_at: str,
    stage: str,
    secrets: Iterable[str] = (),
    reporter: ProgressReporter | None = None,
    exc: BaseException | None = None,
    login_outcome: str | None = None,
) -> dict[str, Any]:
    audit = ReadOnlyTransportAudit(type("EmptyTransport", (), {})())
    if login_outcome is not None:
        audit.record_login(outcome=login_outcome)
    run = _failure_run(reason, audit, started_at)
    safe_message = _exception_message(exc, secrets) if exc is not None else _redact_text(message, secrets)
    location = f"guild_doctor_scanner.authority_verification_cli._run:{stage}"
    diagnostic = {
        "contract": "GUILD-DOCTOR-STAGE3-PASS6-TRANSPORT-DIAGNOSTIC-0.1",
        "source_category": stage,
        "diagnostic_location": location,
        "failure_stage": stage,
        "exception_type": exc.__class__.__name__ if exc is not None else None,
        "exception_message": safe_message,
        "traceback": _exception_traceback(exc, secrets) if exc is not None else "",
        "progress_output": reporter.as_dict() if reporter is not None else None,
        "discord_write_requests": 0,
    }
    report = run["authority_verification_report"]
    report["guild_id"] = guild_id
    report["failure_message"] = safe_message
    report["failure_stage"] = stage
    report["diagnostic_location"] = location
    report["progress_output"] = diagnostic["progress_output"]
    run["stage3_closure_assessment"]["reasons"].append(safe_message)
    run["transport_compatibility_diagnostic"] = diagnostic
    return run


async def _run(args: argparse.Namespace, guild_id: str, started_at: str, reporter: ProgressReporter) -> int:
    token = os.environ.get("GUILD_DOCTOR_DISCORD_TOKEN")
    stage = "preflight"
    secrets = (token or "",)
    reporter.set_secrets(secrets)
    try:
        reporter.emit("preflight: validating the disposable-guild confirmation")
        if os.environ.get("GUILD_DOCTOR_DISPOSABLE_GUILD_CONFIRMED", "").strip().lower() not in CONFIRMATION_VALUES:
            run = _failure_run_for(
                guild_id,
                "DISPOSABLE_GUILD_CONFIRMATION_REQUIRED",
                "set GUILD_DOCTOR_DISPOSABLE_GUILD_CONFIRMED=1 only for a disposable test guild",
                started_at=started_at,
                stage=stage,
                secrets=secrets,
                reporter=reporter,
            )
            _write_run(args.output_dir, run, secrets)
            reporter.error(f"disposable-guild confirmation is required; failure report: {args.output_dir / 'authority_verification_report.json'}")
            return 1
        if not token:
            stage = "authentication"
            run = _failure_run_for(
                guild_id,
                "AUTHENTICATION_TOKEN_MISSING",
                "GUILD_DOCTOR_DISCORD_TOKEN is not set",
                started_at=started_at,
                stage=stage,
                reporter=reporter,
            )
            _write_run(args.output_dir, run, ())
            reporter.error(f"bot token is missing; failure report: {args.output_dir / 'authority_verification_report.json'}")
            return 1

        stage = "manifest"
        reporter.emit(f"manifest: loading {args.scenario_manifest}")
        scenarios = load_scenario_manifest(args.scenario_manifest)
        if any(item.guild_id != guild_id for item in scenarios):
            raise ValueError("scenario guild IDs must match the CLI guild ID")
        if not all(item.member_acquisition_explicitly_authorized for item in scenarios):
            raise ValueError("every scenario must explicitly authorize targeted member acquisition")
        reporter.emit(f"manifest: {len(scenarios)} scenario(s) validated; no write operation is represented")

        stage = "dependency"
        reporter.emit("dependency: loading pinned discord.py 2.7.1")
        try:
            import discord
        except ImportError as exc:  # pragma: no cover - environment-specific
            raise RuntimeError("discord.py 2.7.1 is not installed") from exc

        stage = "client_initialization"
        reporter.emit("client: initializing the read-only HTTP client")
        client = discord.Client(intents=discord.Intents.none(), max_messages=None)
        close_error: BaseException | None = None
        try:
            stage = "authentication"
            reporter.emit(f"authentication: starting bounded login (timeout {args.network_timeout_seconds:g}s)")
            await asyncio.wait_for(client.login(token), timeout=args.network_timeout_seconds)
            reporter.emit("authentication: succeeded")
            stage = "transport_compatibility"
            reporter.emit("transport: validating the pinned GET-only interface")
            transport = DiscordPyReadTransport.from_client(client)
            reporter.emit("transport: GET-only interface ready; no Discord write operation is available")

            def verification_progress(message: str) -> None:
                nonlocal stage
                if message.startswith("STAGE 1/") or message.startswith("STAGE 2/") or message.startswith("STAGE 3/") or message.startswith("STAGE 4/"):
                    stage = "acquisition"
                elif message.startswith("STAGE 5/"):
                    stage = "comparison"
                elif message.startswith("STAGE 6/"):
                    stage = "verification"
                reporter.emit(message)

            stage = "acquisition"
            result = await run_read_only_live_verification(
                transport,
                scenarios,
                timeout_seconds=args.network_timeout_seconds,
                emit=verification_progress,
            )
            # Authentication itself is an audited GET through discord.py's
            # static login endpoint; it never enters the verifier as a token.
            audit = result.get("transport_audit")
            if isinstance(audit, dict):
                audit.setdefault("calls", []).insert(0, {"http_method": "GET", "route_family": "/users/@me", "operation": "client.login", "outcome": "COMPLETE"})
                audit["http_method_counts"]["GET"] = int(audit["http_method_counts"].get("GET", 0)) + 1
            result.setdefault("transport_compatibility_diagnostic", None)
            result["authority_verification_report"]["started_at"] = started_at
            result["authority_verification_report"]["completed_at"] = utc_now()
            result["authority_verification_report"]["progress_output"] = reporter.as_dict()
            stage = "filesystem"
            reporter.emit("filesystem: writing read-only evidence artifacts")
            result["authority_verification_report"]["progress_output"] = reporter.as_dict()
            _write_run(args.output_dir, result, secrets)
            status = result["authority_verification_report"].get("overall_status")
            reporter.emit(f"complete: live authority verification status {status}")
            reporter.emit(f"complete: evidence directory {args.output_dir}")
        finally:
            try:
                await asyncio.wait_for(client.close(), timeout=args.network_timeout_seconds)
            except BaseException as exc:
                close_error = exc
                reporter.emit(f"client: bounded close failed ({_exception_message(exc, secrets)})")
        if close_error is not None:
            stage = "client_shutdown"
            raise close_error
        return 0 if status == "PASS" else FAILURE_EXIT_CODE
    except (asyncio.CancelledError, KeyboardInterrupt) as exc:
        run = _failure_run_for(
            guild_id,
            "INTERRUPTED",
            "verification was interrupted before completion",
            started_at=started_at,
            stage=stage,
            secrets=secrets,
            reporter=reporter,
            exc=exc,
        )
        try:
            _write_run(args.output_dir, run, secrets)
        except OSError:
            pass
        reporter.error(f"interrupted; failure report: {args.output_dir / 'authority_verification_report.json'}")
        return INTERRUPTED_EXIT_CODE
    except BaseException as exc:
        code = _failure_code(exc, stage)
        message = _exception_message(exc, secrets)
        login_outcome = "FAILED" if stage == "authentication" else "COMPLETE" if stage in {"transport_compatibility", "filesystem", "acquisition", "comparison", "verification", "client_shutdown"} else None
        run = _failure_run_for(
            guild_id,
            code,
            message,
            started_at=started_at,
            stage=stage,
            secrets=secrets,
            reporter=reporter,
            exc=exc,
            login_outcome=login_outcome,
        )
        try:
            _write_run(args.output_dir, run, secrets)
        except OSError as report_exc:
            reporter.error(f"{stage} failed with {code}; failure report could not be written: {_exception_message(report_exc, secrets)}")
        else:
            reporter.error(f"{stage} failed with {code}: {message}; failure report: {args.output_dir / 'authority_verification_report.json'}")
        return FAILURE_EXIT_CODE
    finally:
        token = None
        reporter.clear_secrets()


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        guild_id = _validate_args(args)
    except (ValueError, OSError) as exc:
        _error(f"argument validation failed: {_exception_message(exc)}")
        return FAILURE_EXIT_CODE
    try:
        # This is deliberately the first filesystem mutation after argument
        # validation, before token lookup, import, login, or any Discord call.
        args.output_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        _error(f"filesystem failure creating output directory: {_exception_message(exc)}")
        return FAILURE_EXIT_CODE
    reporter = ProgressReporter(args.output_dir)
    started_at = utc_now()
    reporter.emit(f"output_directory: ready at {args.output_dir}")
    try:
        return asyncio.run(_run(args, guild_id, started_at, reporter))
    except KeyboardInterrupt:
        run = _failure_run_for(
            guild_id,
            "INTERRUPTED",
            "verification was interrupted before completion",
            started_at=started_at,
            stage="interrupted",
            reporter=reporter,
        )
        try:
            _write_run(args.output_dir, run, ())
        except OSError:
            pass
        reporter.error(f"interrupted; failure report: {args.output_dir / 'authority_verification_report.json'}")
        return INTERRUPTED_EXIT_CODE


if __name__ == "__main__":
    raise SystemExit(main())
