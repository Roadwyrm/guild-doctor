"""Pass 5 production boundary: route through frozen contracts or fail closed."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping
from .discord_engine_routing_contract import ROUTES
from .discord_role_comparison_projection import project_role_comparison_subject
from .doctor_role_comparison_query import (
    CAPABILITY, COMPARE_CONTEXT_CAPABILITY, RAW_PERMISSION, ROLE_COMPARISON_QUERY_CONTRACT_VERSION,
    RoleComparisonQuery,
)
from .doctor_role_comparison import execute_role_comparison_query
from .doctor_role_comparison import RoleComparisonExecution
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY, KNOWN_PERMISSION_FLAGS
from .action_registry import ACTION_RULES_BY_KEY
from .discord_interaction_envelope import (
    COMPARISON_CONTRACT_ID, COMPARISON_RESULT, ComparisonResultPayload,
    ENVELOPE_ERRORS, ERROR_RESULT, ErrorResultPayload, InteractionEnvelope,
    derive_comparison_outcome,
)

FROZEN_ENGINE_PROVIDER_CONTRACT="GUILD-DOCTOR-STAGE6-FROZEN-ENGINE-PROVIDER-0.1"

@dataclass(frozen=True)
class FrozenEngineResult:
    result: Mapping[str, Any] | None
    stable_error: str | None
    route_id: str
    envelope: InteractionEnvelope | None = None


def _comparison_error(code: str, route: str) -> FrozenEngineResult:
    if code not in ENVELOPE_ERRORS:
        code = "STAGE6_COMPARISON_PAYLOAD_INVALID"
    envelope = InteractionEnvelope(
        ERROR_RESULT,
        error_result=ErrorResultPayload(code, "Guild Doctor could not safely prepare this comparison."),
    )
    return FrozenEngineResult(None, code, route, envelope)


def _single_capability_key(resolved_inputs: Mapping[str, Any]) -> str | None:
    """Accept only the registered single-key shape approved for this route."""
    supplied = resolved_inputs.get("capability_keys", ())
    if supplied is None:
        supplied = ()
    if isinstance(supplied, str):
        supplied = (supplied,)
    if not isinstance(supplied, (tuple, list)) or supplied:
        return None
    key = resolved_inputs.get("capability")
    if not isinstance(key, str) or not key.strip():
        return None
    key = key.strip()
    return key if key in {item.capability_key for item in DEFAULT_CAPABILITY_REGISTRY.capabilities} else None


def _single_action_key(resolved_inputs: Mapping[str, Any]) -> str | None:
    """Accept only one exact registered action; action-set semantics are excluded."""
    supplied = resolved_inputs.get("action_keys", ())
    if supplied is None:
        supplied = ()
    if isinstance(supplied, str):
        supplied = (supplied,)
    if not isinstance(supplied, (tuple, list)) or supplied:
        return None
    key = resolved_inputs.get("action")
    if not isinstance(key, str) or not key.strip():
        return None
    key = key.strip()
    return key if key in ACTION_RULES_BY_KEY else None


def _action_context_required(route: str, action_key: str) -> FrozenEngineResult:
    return FrozenEngineResult(
        {"action_key": action_key, "no_action": True, "no_write": True},
        "STAGE6_ACTION_CONTEXT_REQUIRED",
        route,
        InteractionEnvelope(
            ERROR_RESULT,
            error_result=ErrorResultPayload(
                "STAGE6_ACTION_CONTEXT_REQUIRED",
                "Guild Doctor needs additional frozen action context before it can compare this action safely.",
                action_key=action_key,
            ),
        ),
    )


def _capability_comparison_result(case: Any, key: str, route: str) -> FrozenEngineResult:
    """Validate frozen comparison fields without interpreting permission state."""
    if getattr(case, "role_comparison_query_contract_version", None) != ROLE_COMPARISON_QUERY_CONTRACT_VERSION:
        return _comparison_error("STAGE6_COMPARISON_CONTRACT_MISMATCH", route)
    if getattr(case, "role_comparison_case_contract_version", None) != "GUILD-DOCTOR-ROLE-COMPARISON-CASE-0.1":
        return _comparison_error("STAGE6_COMPARISON_CONTRACT_MISMATCH", route)
    if getattr(case, "target_kind", None) != CAPABILITY:
        return _comparison_error("STAGE6_COMPARISON_CONTRACT_MISMATCH", route)
    if getattr(case, "target_key", None) != key:
        return _comparison_error("STAGE6_COMPARISON_CONTRACT_MISMATCH", route)
    comparison = getattr(case, "comparison", None)
    if not isinstance(comparison, Mapping):
        return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
    not_comparable = comparison.get("not_comparable")
    different = comparison.get("different_results")
    if type(not_comparable) is not bool or type(different) is not bool:
        return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
    primary_reason = getattr(case, "projection_disclaimer", None)
    fingerprint = getattr(case, "case_fingerprint", None)
    if not isinstance(primary_reason, str) or not primary_reason or not isinstance(fingerprint, str):
        return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
    comparable = not not_comparable
    try:
        outcome = derive_comparison_outcome(comparable, different if comparable else None)
        payload = ComparisonResultPayload(
            comparison_outcome=outcome,
            comparable=comparable,
            results_differ=different if comparable else None,
            primary_reason=primary_reason,
            case_fingerprint=fingerprint,
            source_contract_id=COMPARISON_CONTRACT_ID,
            source_contract_version=getattr(case, "stage5_pass3_contract_version", ""),
            target_kind=case.target_kind,
            target_key=case.target_key,
        )
    except ValueError:
        return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
    result = {
        "capability_key": key,
        "comparison_outcome": payload.comparison_outcome,
        "comparable": payload.comparable,
        "results_differ": payload.results_differ,
        "primary_reason": payload.primary_reason,
        "case_fingerprint": payload.case_fingerprint,
        "comparison_contract_id": payload.source_contract_id,
        "comparison_contract_version": payload.source_contract_version,
        "role_comparison_query_contract_version": case.role_comparison_query_contract_version,
        "target_kind": payload.target_kind,
        "no_action": True,
        "no_write": True,
    }
    return FrozenEngineResult(result, None, route, InteractionEnvelope(COMPARISON_RESULT, comparison_result=payload))

def produce_frozen_engine_result(*, command_key:str, normalized_snapshot:Mapping[str,Any], resolved_inputs:Mapping[str,Any], interaction_context:Mapping[str,Any]) -> FrozenEngineResult:
    """No permission logic: reject unavailable frozen query prerequisites."""
    route=ROUTES.get(command_key)
    if route is None or command_key=="diagnose": return FrozenEngineResult(None,"STAGE6_ENGINE_RESULT_PROVIDER_MISSING",route or "UNKNOWN")
    if command_key in {"why-can","why-cannot"}: return FrozenEngineResult(None,"STAGE6_MEMBER_DATA_REQUIRED",route)
    if command_key in {"who-can","who-cannot","who-unknown"}: return FrozenEngineResult(None,"STAGE6_POPULATION_INCOMPLETE",route)
    if command_key=="compare-role-permission":
        try:
            first=project_role_comparison_subject(resolved_inputs["first_role"],normalized_snapshot,index=0); second=project_role_comparison_subject(resolved_inputs["second_role"],normalized_snapshot,index=1)
            key=resolved_inputs.get("permission")
            if (not key or first.role_ids==second.role_ids or
                    str(key).upper() not in {flag.name for flag in KNOWN_PERMISSION_FLAGS}):
                return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID",route)
            query=RoleComparisonQuery(query_id=interaction_context["correlation_id"],comparison_intent="COMPARE_RAW_ROLE_PERMISSIONS",guild_id=normalized_snapshot["guild_id"],compared_subjects=(first,second),target_kind="RAW_PERMISSION",target_key=key,snapshot=normalized_snapshot)
            execution=execute_role_comparison_query(query)
            if not isinstance(execution, RoleComparisonExecution):
                return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
            case = execution.case
            if getattr(case, "target_kind", None) != RAW_PERMISSION or getattr(case, "target_key", None) != key:
                return _comparison_error("STAGE6_COMPARISON_CONTRACT_MISMATCH", route)
            comparison = case.comparison
            comparable = not bool(comparison.get("not_comparable"))
            different = comparison.get("different_results")
            outcome = derive_comparison_outcome(comparable, different)
            payload = ComparisonResultPayload(
                comparison_outcome=outcome,
                comparable=comparable,
                results_differ=different if comparable else None,
                primary_reason=case.projection_disclaimer,
                case_fingerprint=case.case_fingerprint,
                source_contract_id=COMPARISON_CONTRACT_ID,
                source_contract_version=case.stage5_pass3_contract_version,
                target_kind=case.target_kind,
                target_key=case.target_key,
            )
            result=case.as_dict(); result["primary_reason"]=case.projection_disclaimer; result["engine_result_fingerprint"]=case.case_fingerprint
            envelope = InteractionEnvelope(COMPARISON_RESULT, comparison_result=payload)
            return FrozenEngineResult(result,envelope.error_result.stable_error if envelope.error_result else None,route,envelope)
        except ValueError as exc:
            code = str(exc).split(":", 1)[0]
            return _comparison_error(code if code in ENVELOPE_ERRORS else "STAGE6_COMPARISON_PAYLOAD_INVALID", route)
        except Exception:
            return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
    if command_key=="compare-role-capability":
        try:
            if resolved_inputs.get("comparison_intent", COMPARE_CONTEXT_CAPABILITY) != COMPARE_CONTEXT_CAPABILITY:
                return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
            if resolved_inputs.get("target_kind", CAPABILITY) != CAPABILITY:
                return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
            key = _single_capability_key(resolved_inputs)
            if key is None:
                return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
            first=project_role_comparison_subject(resolved_inputs["first_role"],normalized_snapshot,index=0); second=project_role_comparison_subject(resolved_inputs["second_role"],normalized_snapshot,index=1)
            if first.role_ids == second.role_ids:
                return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
            query=RoleComparisonQuery(query_id=interaction_context["correlation_id"],comparison_intent=COMPARE_CONTEXT_CAPABILITY,guild_id=normalized_snapshot["guild_id"],compared_subjects=(first,second),target_kind=CAPABILITY,target_key=key,capability_keys=(),snapshot=normalized_snapshot)
            execution=execute_role_comparison_query(query)
            if not isinstance(execution, RoleComparisonExecution):
                return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
            return _capability_comparison_result(execution.case, key, route)
        except (KeyError, TypeError, ValueError):
            return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
        except Exception:
            return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
    if command_key == "compare-role-action":
        try:
            key = _single_action_key(resolved_inputs)
            if key is None:
                return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
            first = project_role_comparison_subject(resolved_inputs["first_role"], normalized_snapshot, index=0)
            second = project_role_comparison_subject(resolved_inputs["second_role"], normalized_snapshot, index=1)
            if first.role_ids == second.role_ids:
                return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
            return _action_context_required(route, key)
        except (KeyError, TypeError, ValueError):
            return _comparison_error("STAGE6_COMPARISON_PAYLOAD_INVALID", route)
    # These families require a frozen projection/result context not present in
    # the normalized Stage 2 snapshot alone.  Never synthesize one here.
    return FrozenEngineResult(None,"STAGE6_FROZEN_PROJECTION_UNAVAILABLE",route)
