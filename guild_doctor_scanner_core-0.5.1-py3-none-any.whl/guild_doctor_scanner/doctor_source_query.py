"""Immutable Stage 5 Pass 3 source-location query contract.

This module is intentionally a validation boundary.  It owns no permission,
capability, action, or explanation rules; the nested frozen ``DoctorQuery``
remains the only diagnostic execution input.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .doctor_query import (
    ACTION,
    CAPABILITY,
    DOCTOR_QUERY_CONTRACT_VERSION,
    STAGE5_PASS1_CONTRACT_VERSION,
    DoctorQuery,
    thaw,
    validate_doctor_query,
)


STAGE5_PASS3_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE5-PASS3-0.1"
SOURCE_LOCATION_QUERY_CONTRACT_VERSION = "GUILD-DOCTOR-SOURCE-LOCATION-QUERY-0.1"
SOURCE_LOCATION_CASE_CONTRACT_VERSION = "GUILD-DOCTOR-SOURCE-LOCATION-CASE-0.1"
ROLE_COMPARISON_QUERY_CONTRACT_VERSION = "GUILD-DOCTOR-ROLE-COMPARISON-QUERY-0.1"
ROLE_COMPARISON_CASE_CONTRACT_VERSION = "GUILD-DOCTOR-ROLE-COMPARISON-CASE-0.1"
STAGE5_PASS3_RULES_VERSION = "GUILD-DOCTOR-STAGE5-PASS3-RULES-0.1"
STAGE5_PASS3_GOLDEN_VERSION = "GUILD-DOCTOR-STAGE5-PASS3-GOLDEN-0.1"

FIND_CONTROLLING_SOURCE = "FIND_CONTROLLING_SOURCE"
TRACE_SOURCE_CHAIN = "TRACE_SOURCE_CHAIN"
LIST_MATERIAL_SOURCES = "LIST_MATERIAL_SOURCES"
EXPLAIN_SOURCE_OBJECT = "EXPLAIN_SOURCE_OBJECT"
SOURCE_LOCATION_INTENTS = frozenset(
    {FIND_CONTROLLING_SOURCE, TRACE_SOURCE_CHAIN, LIST_MATERIAL_SOURCES, EXPLAIN_SOURCE_OBJECT}
)

CONTROLLING_ONLY = "CONTROLLING_ONLY"
MATERIAL_CHAIN = "MATERIAL_CHAIN"
FULL_PROVENANCE = "FULL_PROVENANCE"
SOURCE_DETAIL_LEVELS = frozenset({CONTROLLING_ONLY, MATERIAL_CHAIN, FULL_PROVENANCE})

SOURCE_LOCATION_QUERY_REGISTRY = tuple(
    (intent, SOURCE_LOCATION_QUERY_CONTRACT_VERSION)
    for intent in (FIND_CONTROLLING_SOURCE, TRACE_SOURCE_CHAIN, LIST_MATERIAL_SOURCES, EXPLAIN_SOURCE_OBJECT)
)

_TOKEN_SHAPE = re.compile(r"^[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{8,}$")
_SECRET_FRAGMENTS = ("token", "authorization", "access_token", "client_secret", "password", "api_key", "credential")
_FORBIDDEN_KEYS = frozenset(
    {
        "question",
        "natural_language_question",
        "prompt",
        "recommendation",
        "recommendations",
        "remediation",
        "repair",
        "output_path",
        "interaction",
        "command",
        "callback",
        "connection",
    }
)


class SourceLocationQueryError(ValueError):
    """Raised by strict source-location query construction."""


def _text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def _upper(value: Any) -> str | None:
    value = _text(value)
    return value.upper() if value else None


def _freeze(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        value = method()
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(child) for key, child in sorted(value.items(), key=lambda item: str(item[0]))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(child) for child in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(child) for child in sorted(value, key=str))
    return deepcopy(value)


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _thaw(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [_thaw(child) for child in value]
    return deepcopy(value)


def _scan_forbidden(value: Any, path: str = "source_query") -> tuple[str, ...]:
    errors: list[str] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            lower = key_text.lower()
            child_path = f"{path}.{key_text}"
            if any(fragment in lower for fragment in _SECRET_FRAGMENTS):
                errors.append(f"SOURCE_QUERY_CREDENTIAL_FIELD:{child_path}")
            if lower in _FORBIDDEN_KEYS:
                errors.append(f"SOURCE_QUERY_FORBIDDEN_FIELD:{child_path}")
            errors.extend(_scan_forbidden(child, child_path))
    elif isinstance(value, (list, tuple, set, frozenset)):
        for index, child in enumerate(value):
            errors.extend(_scan_forbidden(child, f"{path}[{index}]"))
    elif isinstance(value, str):
        lower = value.lower()
        if "bot " in lower or _TOKEN_SHAPE.fullmatch(value.strip()):
            errors.append(f"SOURCE_QUERY_CREDENTIAL_VALUE:{path}")
    return tuple(sorted(set(errors)))


def _safe_label(value: Any, fallback: str) -> str:
    text = _text(value) or fallback
    text = " ".join(text.replace("@", "@​").split())
    return text[:160]


@dataclass(frozen=True, slots=True)
class SourceLocationQuery:
    """One immutable source-location request over one frozen Doctor query."""

    query_id: str
    source_intent: str
    doctor_query: DoctorQuery
    source_detail_level: str = MATERIAL_CHAIN
    explanation_mode: str = "SIMPLE"
    presentation_profile: str = "SIMPLE_CARD"
    disclosure_policy: str = "SAFE_DEFAULT"
    display_safe_labels: Mapping[str, str] | None = None
    stage5_pass3_contract_version: str = STAGE5_PASS3_CONTRACT_VERSION
    source_location_query_contract_version: str = SOURCE_LOCATION_QUERY_CONTRACT_VERSION
    expected_stage5_pass1_contract: str = STAGE5_PASS1_CONTRACT_VERSION
    expected_doctor_query_contract: str = DOCTOR_QUERY_CONTRACT_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "query_id", _text(self.query_id) or "")
        object.__setattr__(self, "source_intent", _upper(self.source_intent) or "")
        object.__setattr__(self, "source_detail_level", _upper(self.source_detail_level) or "")
        object.__setattr__(self, "explanation_mode", _upper(self.explanation_mode) or "SIMPLE")
        object.__setattr__(self, "presentation_profile", _upper(self.presentation_profile) or "SIMPLE_CARD")
        object.__setattr__(self, "disclosure_policy", _upper(self.disclosure_policy) or "SAFE_DEFAULT")
        labels = {
            str(key): _safe_label(value, str(key))
            for key, value in (self.display_safe_labels or {}).items()
        }
        object.__setattr__(self, "display_safe_labels", _freeze(labels))

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "SourceLocationQuery":
        if not isinstance(value, Mapping):
            raise SourceLocationQueryError("SOURCE_QUERY_NOT_MAPPING")
        nested = value.get("doctor_query", value.get("nested_doctor_query"))
        if isinstance(nested, DoctorQuery):
            doctor_query = nested
        elif isinstance(nested, Mapping):
            doctor_query = DoctorQuery.from_mapping(nested)
        else:
            raise SourceLocationQueryError("SOURCE_QUERY_DOCTOR_QUERY_MISSING")
        return cls(
            query_id=value.get("query_id", ""),
            source_intent=value.get("source_intent", value.get("intent", "")),
            doctor_query=doctor_query,
            source_detail_level=value.get("source_detail_level", MATERIAL_CHAIN),
            explanation_mode=value.get("explanation_mode", "SIMPLE"),
            presentation_profile=value.get("presentation_profile", "SIMPLE_CARD"),
            disclosure_policy=value.get("disclosure_policy", "SAFE_DEFAULT"),
            display_safe_labels=value.get("display_safe_labels", value.get("labels", {})),
            stage5_pass3_contract_version=value.get("stage5_pass3_contract_version", STAGE5_PASS3_CONTRACT_VERSION),
            source_location_query_contract_version=value.get("source_location_query_contract_version", SOURCE_LOCATION_QUERY_CONTRACT_VERSION),
            expected_stage5_pass1_contract=value.get("expected_stage5_pass1_contract", STAGE5_PASS1_CONTRACT_VERSION),
            expected_doctor_query_contract=value.get("expected_doctor_query_contract", DOCTOR_QUERY_CONTRACT_VERSION),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "stage5_pass3_contract_version": self.stage5_pass3_contract_version,
            "source_location_query_contract_version": self.source_location_query_contract_version,
            "expected_stage5_pass1_contract": self.expected_stage5_pass1_contract,
            "expected_doctor_query_contract": self.expected_doctor_query_contract,
            "query_id": self.query_id,
            "source_intent": self.source_intent,
            "source_detail_level": self.source_detail_level,
            "explanation_mode": self.explanation_mode,
            "presentation_profile": self.presentation_profile,
            "disclosure_policy": self.disclosure_policy,
            "display_safe_labels": _thaw(self.display_safe_labels),
            "target_kind": self.doctor_query.target_kind,
            "target_key": self.doctor_query.target_key,
            "guild_id": self.doctor_query.guild_id,
            "doctor_query": self.doctor_query.as_dict(include_source=True),
        }

    @property
    def target_kind(self) -> str | None:
        return self.doctor_query.target_kind

    @property
    def target_key(self) -> str | None:
        return self.doctor_query.target_key


def validate_source_location_query(value: SourceLocationQuery | Mapping[str, Any]) -> tuple[str, ...]:
    """Validate without Discord, network, persistence, or execution."""

    if isinstance(value, SourceLocationQuery):
        query = value
        raw = query.as_dict()
    elif isinstance(value, Mapping):
        raw = deepcopy(dict(value))
        try:
            query = SourceLocationQuery.from_mapping(value)
        except (SourceLocationQueryError, TypeError, ValueError) as exc:
            return (f"SOURCE_QUERY_CONSTRUCTION:{exc}",)
    else:
        return ("SOURCE_QUERY_NOT_MAPPING",)

    errors = list(_scan_forbidden(raw))
    if not query.query_id:
        errors.append("SOURCE_QUERY_ID_MISSING")
    if query.stage5_pass3_contract_version != STAGE5_PASS3_CONTRACT_VERSION:
        errors.append("STAGE5_PASS3_CONTRACT_UNSUPPORTED")
    if query.source_location_query_contract_version != SOURCE_LOCATION_QUERY_CONTRACT_VERSION:
        errors.append("SOURCE_LOCATION_QUERY_CONTRACT_UNSUPPORTED")
    if query.expected_stage5_pass1_contract != STAGE5_PASS1_CONTRACT_VERSION:
        errors.append("STAGE5_PASS1_EXPECTATION_MISMATCH")
    if query.expected_doctor_query_contract != DOCTOR_QUERY_CONTRACT_VERSION:
        errors.append("DOCTOR_QUERY_EXPECTATION_MISMATCH")
    if query.source_intent not in SOURCE_LOCATION_INTENTS:
        errors.append("SOURCE_INTENT_UNSUPPORTED")
    if query.source_detail_level not in SOURCE_DETAIL_LEVELS:
        errors.append("SOURCE_DETAIL_LEVEL_UNSUPPORTED")
    if query.target_kind not in {CAPABILITY, ACTION}:
        errors.append("SOURCE_TARGET_KIND_UNSUPPORTED")
    if query.doctor_query.query_id == query.query_id:
        errors.append("SOURCE_QUERY_ID_MUST_WRAP_DOCTOR_QUERY")
    errors.extend(validate_doctor_query(query.doctor_query))
    return tuple(sorted(set(errors)))


def validate_source_location_query_registry() -> tuple[str, ...]:
    expected = (
        (FIND_CONTROLLING_SOURCE, SOURCE_LOCATION_QUERY_CONTRACT_VERSION),
        (TRACE_SOURCE_CHAIN, SOURCE_LOCATION_QUERY_CONTRACT_VERSION),
        (LIST_MATERIAL_SOURCES, SOURCE_LOCATION_QUERY_CONTRACT_VERSION),
        (EXPLAIN_SOURCE_OBJECT, SOURCE_LOCATION_QUERY_CONTRACT_VERSION),
    )
    return () if SOURCE_LOCATION_QUERY_REGISTRY == expected else ("SOURCE_QUERY_REGISTRY_MUTATED",)


__all__ = [
    "CONTROLLING_ONLY",
    "EXPLAIN_SOURCE_OBJECT",
    "FIND_CONTROLLING_SOURCE",
    "FULL_PROVENANCE",
    "LIST_MATERIAL_SOURCES",
    "MATERIAL_CHAIN",
    "ROLE_COMPARISON_CASE_CONTRACT_VERSION",
    "ROLE_COMPARISON_QUERY_CONTRACT_VERSION",
    "SOURCE_DETAIL_LEVELS",
    "SOURCE_LOCATION_CASE_CONTRACT_VERSION",
    "SOURCE_LOCATION_INTENTS",
    "SOURCE_LOCATION_QUERY_CONTRACT_VERSION",
    "SOURCE_LOCATION_QUERY_REGISTRY",
    "STAGE5_PASS3_CONTRACT_VERSION",
    "STAGE5_PASS3_GOLDEN_VERSION",
    "STAGE5_PASS3_RULES_VERSION",
    "SourceLocationQuery",
    "SourceLocationQueryError",
    "TRACE_SOURCE_CHAIN",
    "validate_source_location_query",
    "validate_source_location_query_registry",
]
