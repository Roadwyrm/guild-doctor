"""Run Pass 5 verification against an explicitly confirmed disposable guild."""

from __future__ import annotations

import argparse
import asyncio
import json
import math
import os
import sys
from pathlib import Path
from typing import Any, Iterable

from .canonical import canonical_json
from .discordpy_adapter import DiscordPyReadTransport
from .integration import (
    DisposableGuildIntegrationVerifier,
    INTEGRATION_CONTRACT_VERSION,
    IntegrationScenario,
    IntegrationVerificationReport,
    _snowflake,
)

DEFAULT_NETWORK_TIMEOUT_SECONDS = 30.0
CONFIRMATION_VALUES = {"1", "true", "yes", "on"}
FAILURE_EXIT_CODE = 2
INTERRUPTED_EXIT_CODE = 130


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Verify Guild Doctor Stage 2 against a disposable Discord guild")
    parser.add_argument("guild_id", help="Disposable Discord guild ID")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-owner-id")
    parser.add_argument("--non-owner-id")
    parser.add_argument(
        "--partial-failure-resource",
        choices=["guild", "roles", "channels", "active_threads"],
        default="active_threads",
    )
    parser.add_argument(
        "--network-timeout-seconds",
        type=float,
        default=DEFAULT_NETWORK_TIMEOUT_SECONDS,
        help="Maximum seconds allowed for each login or Discord read operation",
    )
    return parser


def _progress(message: str) -> None:
    print(f"[Guild Doctor Pass 5] {message}", flush=True)


def _error(message: str) -> None:
    print(f"guild-doctor-integration-verify: {message}", file=sys.stderr, flush=True)


def _validate_args(args: argparse.Namespace) -> str:
    guild_text = _snowflake(args.guild_id)
    for field_name in ("expected_owner_id", "non_owner_id"):
        value = getattr(args, field_name)
        if value is not None:
            _snowflake(value)

    timeout = float(args.network_timeout_seconds)
    if not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("--network-timeout-seconds must be a finite positive number")
    if args.output_dir.exists() and not args.output_dir.is_dir():
        raise OSError(f"output path exists and is not a directory: {args.output_dir}")
    return guild_text


def _redact_text(value: str, secrets: Iterable[str]) -> str:
    result = value
    for secret in secrets:
        if secret:
            result = result.replace(secret, "[REDACTED]")
    return result


def _redact_value(value: Any, secrets: Iterable[str]) -> Any:
    secret_values = tuple(secrets)
    if isinstance(value, dict):
        return {
            _redact_text(str(key), secret_values): _redact_value(item, secret_values)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_redact_value(item, secret_values) for item in value]
    if isinstance(value, tuple):
        return [_redact_value(item, secret_values) for item in value]
    if isinstance(value, str):
        return _redact_text(value, secret_values)
    return value


def _exception_message(exc: BaseException, secrets: Iterable[str] = ()) -> str:
    message = " ".join(str(exc).split()) or exc.__class__.__name__
    return _redact_text(message, secrets)[:500]


def _failure_code(exc: BaseException, stage: str) -> str:
    if isinstance(exc, (asyncio.CancelledError, KeyboardInterrupt)):
        return "INTERRUPTED"
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        return "NETWORK_TIMEOUT"

    status = getattr(exc, "status", None)
    if status == 401 or exc.__class__.__name__ == "LoginFailure":
        return "AUTHENTICATION_FAILED"
    if status == 403:
        return "AUTHORIZATION_DENIED"
    if isinstance(status, int):
        return f"HTTP_ERROR_{status}"
    if stage == "authentication":
        return "AUTHENTICATION_FAILED"
    if stage == "client_initialization":
        return "CLIENT_INITIALIZATION_FAILED"
    if stage == "dependency":
        return "DEPENDENCY_MISSING"
    if stage == "transport_compatibility":
        return "TRANSPORT_COMPATIBILITY_FAILED"
    if stage == "acquisition":
        return "ACQUISITION_FAILED"
    if stage == "normalization":
        return "NORMALIZATION_FAILED"
    if stage == "comparison":
        return "COMPARISON_FAILED"
    if stage == "filesystem" or isinstance(exc, OSError):
        return "FILESYSTEM_FAILURE"
    return "VERIFICATION_FAILED"


def _failure_report(
    guild_id: str,
    *,
    stage: str,
    code: str,
    message: str,
    details: dict[str, Any] | None = None,
) -> IntegrationVerificationReport:
    failure_details: dict[str, Any] = {
        "stage": stage,
        "code": code,
        "message": message,
    }
    if details:
        failure_details.update(details)
    return IntegrationVerificationReport(
        contract_version=INTEGRATION_CONTRACT_VERSION,
        guild_id=guild_id,
        overall_status="FAIL",
        scenarios=[IntegrationScenario(stage, "FAIL", failure_details)],
        live_execution=False,
        failure=failure_details,
    )


def _write_report(output_dir: Path, report: IntegrationVerificationReport, secrets: Iterable[str]) -> Path:
    path = output_dir / "integration_report.json"
    safe_report = _redact_value(report.as_dict(), secrets)
    path.write_text(
        json.dumps(safe_report, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    return path


def _write_json(path: Path, value: Any, secrets: Iterable[str], *, canonical: bool = False) -> None:
    safe_value = _redact_value(value, secrets)
    text = canonical_json(safe_value) if canonical else json.dumps(safe_value, ensure_ascii=False, sort_keys=True, indent=2)
    path.write_text(text + "\n", encoding="utf-8")


def _write_evidence(
    output_dir: Path,
    report: IntegrationVerificationReport,
    fixture: dict[str, Any],
    first: Any,
    partial: Any,
    secrets: Iterable[str],
) -> None:
    _write_json(output_dir / "stage3_fixture.json", fixture, secrets, canonical=True)
    if first.snapshot is not None:
        _write_json(output_dir / "live_snapshot.json", first.snapshot.as_dict(), secrets, canonical=True)
    partial_health = {
        name: result.health_dict() for name, result in sorted(partial.results.items())
    }
    _write_json(output_dir / "partial_failure_health.json", partial_health, secrets)
    _write_report(output_dir, report, secrets)


async def _run(args: argparse.Namespace, guild_text: str) -> int:
    token = os.environ.get("GUILD_DOCTOR_DISCORD_TOKEN")
    stage = "preflight_confirmation"

    try:
        _progress("preflight: confirming the target is disposable")
        if os.environ.get("GUILD_DOCTOR_DISPOSABLE_GUILD_CONFIRMED", "").strip().lower() not in CONFIRMATION_VALUES:
            report = _failure_report(
                guild_text,
                stage=stage,
                code="DISPOSABLE_GUILD_CONFIRMATION_REQUIRED",
                message="set GUILD_DOCTOR_DISPOSABLE_GUILD_CONFIRMED=1 only for a disposable test guild",
            )
            report_path = _write_report(args.output_dir, report, ())
            _error(f"disposable-guild confirmation is required; failure report: {report_path}")
            return 1

        stage = "authentication"
        _progress("preflight: checking that the bot token is available")
        if not token:
            report = _failure_report(
                guild_text,
                stage=stage,
                code="AUTHENTICATION_TOKEN_MISSING",
                message="GUILD_DOCTOR_DISCORD_TOKEN is not set",
            )
            report_path = _write_report(args.output_dir, report, ())
            _error(f"bot token is missing; failure report: {report_path}")
            return 1

        _progress("dependency: loading discord.py 2.7.1")
        try:
            import discord
        except ImportError as exc:
            stage = "dependency"
            raise RuntimeError("discord.py 2.7.1 is not installed") from exc

        stage = "client_initialization"
        _progress("client: initializing the read-only HTTP client")
        client = discord.Client(intents=discord.Intents.none(), max_messages=None)
        async with client:
            stage = "authentication"
            _progress(f"authentication: starting bounded login (timeout {args.network_timeout_seconds:g}s)")
            await asyncio.wait_for(client.login(token), timeout=args.network_timeout_seconds)
            _progress("authentication: succeeded")

            stage = "transport_compatibility"
            _progress("transport: validating the pinned GET-only interface")
            transport = DiscordPyReadTransport.from_client(client)
            _progress("transport: GET-only interface ready; no Discord write operation is available")

            current_stage = "first_scan"

            def verification_progress(message: str) -> None:
                nonlocal current_stage
                if "acquisition" in message:
                    current_stage = "acquisition"
                elif "comparing" in message:
                    current_stage = "comparison"
                else:
                    current_stage = message.split(":", 1)[0]
                _progress(message)

            verifier = DisposableGuildIntegrationVerifier(
                transport,
                network_timeout_seconds=args.network_timeout_seconds,
                progress=verification_progress,
            )
            report, fixture, first, partial = await verifier.run(
                guild_text,
                expected_owner_id=args.expected_owner_id,
                non_owner_id=args.non_owner_id,
                partial_failure_resource=args.partial_failure_resource,
            )
            stage = current_stage

        stage = "filesystem"
        _progress("filesystem: writing evidence artifacts")
        try:
            _write_evidence(args.output_dir, report, fixture, first, partial, (token,))
        except OSError as exc:
            failure = _failure_report(
                guild_text,
                stage=stage,
                code="FILESYSTEM_FAILURE",
                message=_exception_message(exc, (token,)),
            )
            try:
                report_path = _write_report(args.output_dir, failure, (token,))
            except OSError as report_exc:
                _error(
                    "filesystem failure prevented the failure report from being written: "
                    + _exception_message(report_exc, (token,))
                )
            else:
                _error(f"filesystem failure; failure report: {report_path}")
            return FAILURE_EXIT_CODE
        except Exception as exc:
            failure = _failure_report(
                guild_text,
                stage=stage,
                code="EVIDENCE_SERIALIZATION_FAILED",
                message=_exception_message(exc, (token,)),
            )
            try:
                report_path = _write_report(args.output_dir, failure, (token,))
            except OSError as report_exc:
                _error(
                    "evidence serialization failure and failure report could not be written: "
                    + _exception_message(report_exc, (token,))
                )
            else:
                _error(f"evidence serialization failure; failure report: {report_path}")
            return FAILURE_EXIT_CODE

        _progress(f"complete: Pass 5 integration status {report.overall_status}")
        _progress(f"complete: report {args.output_dir / 'integration_report.json'}")
        return 0 if report.overall_status == "PASS" else FAILURE_EXIT_CODE

    except asyncio.CancelledError as exc:
        failure = _failure_report(
            guild_text,
            stage=stage,
            code="INTERRUPTED",
            message="verification was cancelled before completion",
        )
        try:
            report_path = _write_report(args.output_dir, failure, (token or "",))
        except OSError as report_exc:
            _error("interrupted; failure report could not be written: " + _exception_message(report_exc, (token or "",)))
        else:
            _error(f"interrupted; failure report: {report_path}")
        return INTERRUPTED_EXIT_CODE
    except KeyboardInterrupt as exc:
        failure = _failure_report(
            guild_text,
            stage=stage,
            code="INTERRUPTED",
            message="verification was interrupted before completion",
        )
        try:
            report_path = _write_report(args.output_dir, failure, (token or "",))
        except OSError as report_exc:
            _error("interrupted; failure report could not be written: " + _exception_message(report_exc, (token or "",)))
        else:
            _error(f"interrupted; failure report: {report_path}")
        return INTERRUPTED_EXIT_CODE
    except Exception as exc:
        code = _failure_code(exc, stage)
        safe_message = _exception_message(exc, (token or "",))
        failure = _failure_report(
            guild_text,
            stage=stage,
            code=code,
            message=safe_message,
            details={"error_type": exc.__class__.__name__},
        )
        try:
            report_path = _write_report(args.output_dir, failure, (token or "",))
        except OSError as report_exc:
            _error(
                f"{stage} failed with {code}; failure report could not be written: "
                + _exception_message(report_exc, (token or "",))
            )
        else:
            _error(f"{stage} failed with {code}: {safe_message}; failure report: {report_path}")
        return FAILURE_EXIT_CODE
    finally:
        token = None


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        guild_text = _validate_args(args)
    except (ValueError, OSError) as exc:
        _error(f"argument validation failed: {_exception_message(exc)}")
        return FAILURE_EXIT_CODE

    try:
        args.output_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        _error(f"filesystem failure creating output directory: {_exception_message(exc)}")
        return FAILURE_EXIT_CODE

    _progress(f"output_directory: ready at {args.output_dir}")
    try:
        return asyncio.run(_run(args, guild_text))
    except KeyboardInterrupt:
        failure = _failure_report(
            guild_text,
            stage="interrupted",
            code="INTERRUPTED",
            message="verification was interrupted before completion",
        )
        try:
            report_path = _write_report(args.output_dir, failure, ())
        except OSError as exc:
            _error("interrupted; failure report could not be written: " + _exception_message(exc))
        else:
            _error(f"interrupted; failure report: {report_path}")
        return INTERRUPTED_EXIT_CODE


if __name__ == "__main__":
    raise SystemExit(main())
