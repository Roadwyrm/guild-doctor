"""Dedicated bounded Stage 8 Pass 3 invocation; never starts a Gateway."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path

from .private_alpha_configuration import (
    SECRET_ENVIRONMENT_VARIABLE,
    PrivateAlphaConfigurationError,
    check_secret_presence,
    load_configuration,
)
from .private_alpha_live_transport import (
    LIVE_CONFIRMATION,
    REGISTRATION_CONFIRMATION,
    PrivateAlphaDiscordTransport,
    execute_live_verification,
    run_pass3_offline_preflight,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="guild-doctor-private-alpha-pass3",
        description="Bounded REST-only Guild Doctor Stage 8 Pass 3 verification.",
    )
    parser.add_argument("--config", required=True, help="Explicit operator-local active configuration path")
    parser.add_argument("--confirm-live-access", required=True, help="Exact bounded-live authorization phrase")
    parser.add_argument("--confirm-registration", default="", help="Exact guild-scoped registration authorization phrase")
    parser.add_argument("--project-root", default=".", help=argparse.SUPPRESS)
    return parser


def _blocked(code: str) -> dict[str, object]:
    return {
        "contract": "GUILD-DOCTOR-STAGE8-PASS3-INSTALLATION-COMMAND-REGISTRATION-LIVE-TRANSPORT-0.1",
        "status": "BLOCKED",
        "stable_reason": code,
        "discord_get_count": 0,
        "command_registration_write_count": 0,
        "guild_mutation_write_count": 0,
        "gateway_connection_count": 0,
    }


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.confirm_live_access != LIVE_CONFIRMATION:
        print(json.dumps(_blocked("STAGE8_PASS3_LIVE_CONFIRMATION_REQUIRED"), sort_keys=True, separators=(",", ":")))
        return 2
    registration_authorized = args.confirm_registration == REGISTRATION_CONFIRMATION
    if args.confirm_registration and not registration_authorized:
        print(json.dumps(_blocked("STAGE8_PASS3_REGISTRATION_CONFIRMATION_INVALID"), sort_keys=True, separators=(",", ":")))
        return 2
    secret: str | None = None
    try:
        configuration = load_configuration(args.config)
        presence = check_secret_presence(os.environ)
        preflight = run_pass3_offline_preflight(configuration, presence, Path(args.project_root))
        if preflight.overall_state != "READY_OFFLINE":
            print(json.dumps(_blocked("STAGE8_PASS3_OFFLINE_PREFLIGHT_BLOCKED"), sort_keys=True, separators=(",", ":")))
            return 2
        secret = os.environ.get(SECRET_ENVIRONMENT_VARIABLE)
        if presence.state != "PRESENT" or secret is None or secret == "":
            print(json.dumps(_blocked("STAGE8_PASS3_SECRET_NOT_PRESENT"), sort_keys=True, separators=(",", ":")))
            return 2
        result = asyncio.run(execute_live_verification(
            transport=PrivateAlphaDiscordTransport(),
            configuration=configuration,
            offline_preflight=preflight,
            secret=secret,
            explicitly_authorize_registration=registration_authorized,
        ))
        print(json.dumps(result.as_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        return 0 if result.status == "PASS" else 2
    except PrivateAlphaConfigurationError as exc:
        print(json.dumps(_blocked(exc.code), sort_keys=True, separators=(",", ":")))
        return 2
    except Exception:
        print(json.dumps(_blocked("STAGE8_PASS3_INTERNAL_VALIDATION_FAILED"), sort_keys=True, separators=(",", ":")))
        return 3
    finally:
        secret = None


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["build_parser", "main"]
