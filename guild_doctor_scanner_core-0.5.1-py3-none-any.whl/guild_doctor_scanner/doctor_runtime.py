"""Pure local Stage 5 Pass 4 Permission Doctor runtime.

The runtime routes an already validated workflow plan to one frozen Stage 5
public interface.  It never constructs a Discord client, sends a request, or
performs a Discord mutation.  Filesystem output is explicit and local only.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any

from .canonical import canonical_json
from .doctor_enumeration_engine import execute_doctor_enumeration
from .doctor_query import DoctorQuery
from .doctor_engine import execute_doctor_query
from .doctor_enumeration_query import DoctorEnumerationQuery
from .doctor_role_comparison import execute_role_comparison_query
from .doctor_role_comparison_query import RoleComparisonQuery
from .doctor_source_location import execute_source_location_query
from .doctor_source_query import SourceLocationQuery
from .doctor_workflow import (
    CONTINUE_WITH_REPORT,
    DIRECT_QUERY,
    DISCORD_MARKDOWN,
    DoctorWorkflowPlan,
    ENUMERATION,
    PLAIN_TEXT,
    ROLE_COMPARISON,
    SOURCE_LOCATION,
    STAGE5_PASS4_CONTRACT_VERSION,
    STRUCTURED_JSON,
    WHY,
    thaw_workflow,
    validate_doctor_workflow,
)


DOCTOR_RUNTIME_CONTRACT_VERSION = "GUILD-DOCTOR-DOCTOR-CLI-0.1"
DOCTOR_RUNTIME_GOLDEN_VERSION = "GUILD-DOCTOR-DOCTOR-RUNTIME-GOLDEN-0.1"
DOCTOR_BATCH_CONTRACT_VERSION = "GUILD-DOCTOR-DOCTOR-WORKFLOW-BATCH-0.1"

EXIT_SUCCESS = 0
EXIT_UNKNOWN = 2
EXIT_ARGUMENTS = 10
EXIT_INVALID_WORKFLOW = 11
EXIT_UNSUPPORTED = 12
EXIT_INPUT_FAILURE = 13
EXIT_OUTPUT_FAILURE = 14
EXIT_EXECUTION_FAILURE = 15
EXIT_BATCH_PARTIAL = 16
EXIT_INTEGRITY_FAILURE = 17
EXIT_CLOSURE_PENDING = 18
EXIT_CANCELLED = 19
EXIT_INTERRUPTED = 130

_SECRET_FRAGMENTS = ("token", "authorization", "access_token", "client_secret", "password", "api_key", "credential")
_TOKEN_SHAPE = re.compile(r"^[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{8,}$")
_MENTION_RE = re.compile(r"<@([!&]?\d+)>")


class DoctorRuntimeError(RuntimeError):
    """Base class for a controlled local runtime failure."""


class DoctorRuntimeInputError(DoctorRuntimeError):
    """Input or JSON loading failure."""


class DoctorRuntimeOutputError(DoctorRuntimeError):
    """Explicit local output failure."""


def _jsonable(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _jsonable(method())
    if isinstance(value, Mapping):
        return {str(key): _jsonable(child) for key, child in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [_jsonable(child) for child in value]
    return value


def _contains_secret(value: Any, path: str = "result") -> tuple[str, ...]:
    errors: list[str] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            child_path = f"{path}.{key_text}"
            if any(fragment in key_text.lower() for fragment in _SECRET_FRAGMENTS):
                errors.append(f"CREDENTIAL_FIELD:{child_path}")
            errors.extend(_contains_secret(child, child_path))
    elif isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            errors.extend(_contains_secret(child, f"{path}[{index}]"))
    elif isinstance(value, str) and (_TOKEN_SHAPE.fullmatch(value.strip()) or value.lower().startswith("bot ")):
        errors.append(f"CREDENTIAL_VALUE:{path}")
    return tuple(sorted(set(errors)))


def _redacted_error(error: BaseException | str) -> str:
    text = str(error)
    for fragment in _SECRET_FRAGMENTS:
        if fragment in text.lower():
            return f"{type(error).__name__ if not isinstance(error, str) else 'RuntimeError'}:REDACTED_DIAGNOSTIC"
    return f"{type(error).__name__ if not isinstance(error, str) else 'RuntimeError'}:{text}"[:500]


def _result_state(kind: str, case: Mapping[str, Any]) -> str | None:
    if kind == WHY:
        actual = case.get("actual_result")
        return str(actual.get("result_state")) if isinstance(actual, Mapping) and actual.get("result_state") else None
    if kind == SOURCE_LOCATION:
        return str(case.get("authoritative_result_state")) if case.get("authoritative_result_state") else None
    if kind == ENUMERATION:
        buckets = case.get("result_buckets")
        if isinstance(buckets, Mapping) and isinstance(buckets.get("UNKNOWN"), Mapping) and int(buckets["UNKNOWN"].get("count", 0) or 0) > 0:
            return "UNKNOWN"
        return "ENUMERATED"
    if kind == ROLE_COMPARISON:
        comparison = case.get("comparison")
        if isinstance(comparison, Mapping) and comparison.get("not_comparable"):
            return "UNKNOWN"
        return "COMPARED"
    return None


def _primary_reason(kind: str, case: Mapping[str, Any]) -> str | None:
    if kind == WHY:
        answer = case.get("diagnostic_answer")
        return str(answer.get("primary_reason")) if isinstance(answer, Mapping) and answer.get("primary_reason") else None
    if kind == SOURCE_LOCATION:
        return str(case.get("primary_reason")) if case.get("primary_reason") else None
    if kind == ENUMERATION:
        presentation = case.get("presentation")
        return str(presentation.get("direct_aggregate_answer")) if isinstance(presentation, Mapping) else None
    if kind == ROLE_COMPARISON:
        comparison = case.get("comparison")
        return "ROLE_RESULTS_DIFFER" if isinstance(comparison, Mapping) and comparison.get("different_results") else "ROLE_RESULTS_RETAINED"
    return None


def _why_presentation(case: Mapping[str, Any]) -> Mapping[str, Any] | None:
    explanation = case.get("explanation")
    if not isinstance(explanation, Mapping):
        return None
    value = explanation.get("presentation_result")
    return value if isinstance(value, Mapping) else None


def _mention_neutral(value: str) -> str:
    return _MENTION_RE.sub(lambda match: "@\u200b" + match.group(1), value).replace("@everyone", "@\u200beveryone").replace("@here", "@\u200bhere")


def _project_presentation(kind: str, case: Mapping[str, Any], output_format: str) -> dict[str, Any]:
    """Project frozen case fields without reimplementing Stage 4 rendering."""

    if kind == WHY:
        rendered = _why_presentation(case)
        if isinstance(rendered, Mapping):
            plain = str(rendered.get("plain_text") or "")
            markdown = str(rendered.get("discord_markdown") or plain)
            structured = rendered.get("structured_json") if isinstance(rendered.get("structured_json"), Mapping) else dict(case)
            return {"plain_text": plain, "discord_markdown": _mention_neutral(markdown), "structured_json": _jsonable(structured), "source": "FROZEN_STAGE4_PRESENTATION"}
    if kind == ENUMERATION:
        presentation = case.get("presentation") if isinstance(case.get("presentation"), Mapping) else {}
        text = "\n".join(str(value) for value in (presentation.get("direct_aggregate_answer"), presentation.get("summary"), presentation.get("bounded_scope_wording")) if value)
    elif kind == SOURCE_LOCATION:
        text = "\n".join(str(value) for value in (case.get("primary_reason"), case.get("authoritative_result_state"), "Material sources retained: " + str(len(case.get("material_sources", []) or []))) if value)
    else:
        text = "\n".join(str(value) for value in (case.get("projection_disclaimer"), case.get("action_disclaimer"), case.get("comparison")) if value)
    return {"plain_text": _mention_neutral(text), "discord_markdown": _mention_neutral(text), "structured_json": _jsonable(case), "source": "FROZEN_STAGE5_CASE_PROJECTION"}


@dataclass(frozen=True, slots=True)
class DoctorWorkflowResult:
    runtime_contract_version: str
    stage5_pass4_contract_version: str
    workflow_id: str | None
    workflow_kind: str | None
    source_mode: str | None
    normalized_query_type: str | None
    validation_status: str
    confirmation_status: str
    execution_status: str
    result_state: str | None
    exit_code: int
    underlying_case: Mapping[str, Any] | None
    presentation: Mapping[str, Any] | None
    primary_reason: str | None
    warnings: tuple[str, ...]
    errors: tuple[str, ...]
    provenance: Mapping[str, Any]
    integrity: Mapping[str, Any]

    @property
    def passed(self) -> bool:
        return self.execution_status == "PASS" and self.exit_code in {EXIT_SUCCESS, EXIT_UNKNOWN}

    def as_dict(self) -> dict[str, Any]:
        payload = {
            "runtime_contract_version": self.runtime_contract_version,
            "stage5_pass4_contract_version": self.stage5_pass4_contract_version,
            "workflow_id": self.workflow_id,
            "workflow_kind": self.workflow_kind,
            "source_mode": self.source_mode,
            "normalized_query_type": self.normalized_query_type,
            "validation_status": self.validation_status,
            "confirmation_status": self.confirmation_status,
            "execution_status": self.execution_status,
            "result_state": self.result_state,
            "exit_code": self.exit_code,
            "underlying_case": _jsonable(self.underlying_case),
            "presentation": _jsonable(self.presentation),
            "primary_reason": self.primary_reason,
            "warnings": list(self.warnings),
            "errors": list(self.errors),
            "provenance": _jsonable(self.provenance),
            "integrity": _jsonable(self.integrity),
        }
        payload["workflow_result_fingerprint"] = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
        return payload


def _invalid_result(plan: DoctorWorkflowPlan | None, errors: Sequence[str], *, exit_code: int = EXIT_INVALID_WORKFLOW) -> DoctorWorkflowResult:
    return DoctorWorkflowResult(
        DOCTOR_RUNTIME_CONTRACT_VERSION,
        STAGE5_PASS4_CONTRACT_VERSION,
        getattr(plan, "workflow_id", None),
        getattr(plan, "workflow_kind", None),
        getattr(plan, "source_mode", None),
        None,
        "FAIL",
        "MISSING" if getattr(plan, "require_review_confirmation", False) else "NOT_REQUIRED",
        "NOT_EXECUTED",
        None,
        exit_code,
        None,
        None,
        None,
        (),
        tuple(sorted(set(errors))),
        {"discord_contacted": False, "network_contacted": False, "runtime_ai_used": False},
        {"snapshot_unchanged": True, "workflow_plan_unchanged": True, "protected_evidence_unchanged": True, "token_redaction_status": "PASS_NO_TOKEN_OUTPUT"},
    )


def execute_doctor_workflow(value: DoctorWorkflowPlan | Mapping[str, Any]) -> DoctorWorkflowResult:
    """Execute exactly one frozen Pass 1, Pass 2, or Pass 3 public interface."""

    try:
        plan = value if isinstance(value, DoctorWorkflowPlan) else DoctorWorkflowPlan.from_mapping(value)
    except (TypeError, ValueError) as exc:
        return _invalid_result(None, (f"WORKFLOW_CONSTRUCTION:{type(exc).__name__}",))
    validation_errors = validate_doctor_workflow(plan)
    if validation_errors:
        return _invalid_result(plan, validation_errors)
    if plan.validate_only:
        return DoctorWorkflowResult(DOCTOR_RUNTIME_CONTRACT_VERSION, STAGE5_PASS4_CONTRACT_VERSION, plan.workflow_id, plan.workflow_kind, plan.source_mode, None, "PASS", "CONFIRMED" if plan.confirmed else "NOT_REQUIRED", "VALIDATED", None, EXIT_SUCCESS, None, None, None, (), (), {"workflow_plan_fingerprint": plan.as_dict()["workflow_plan_fingerprint"], "discord_contacted": False, "network_contacted": False, "runtime_ai_used": False}, {"workflow_plan_unchanged": True, "snapshot_unchanged": True, "protected_evidence_unchanged": True, "token_redaction_status": "PASS_NO_TOKEN_OUTPUT"})
    raw_query = thaw_workflow(plan.normalized_query)
    try:
        if plan.workflow_kind == WHY:
            execution = execute_doctor_query(DoctorQuery.from_mapping(raw_query), strict=False)
        elif plan.workflow_kind == ENUMERATION:
            execution = execute_doctor_enumeration(DoctorEnumerationQuery.from_mapping(raw_query), strict=False)
        elif plan.workflow_kind == SOURCE_LOCATION:
            execution = execute_source_location_query(SourceLocationQuery.from_mapping(raw_query), strict=False)
        elif plan.workflow_kind == ROLE_COMPARISON:
            execution = execute_role_comparison_query(RoleComparisonQuery.from_mapping(raw_query), strict=False)
        else:  # guarded by validation, retained as a stable fail-closed boundary
            return _invalid_result(plan, ("WORKFLOW_KIND_UNKNOWN",), exit_code=EXIT_UNSUPPORTED)
    except KeyboardInterrupt:
        raise
    except Exception as exc:
        return DoctorWorkflowResult(DOCTOR_RUNTIME_CONTRACT_VERSION, STAGE5_PASS4_CONTRACT_VERSION, plan.workflow_id, plan.workflow_kind, plan.source_mode, None, "PASS", "CONFIRMED", "FAIL", None, EXIT_EXECUTION_FAILURE, None, None, None, (), (_redacted_error(exc),), {"discord_contacted": False, "network_contacted": False, "runtime_ai_used": False}, {"workflow_plan_unchanged": True, "snapshot_unchanged": True, "protected_evidence_unchanged": True, "token_redaction_status": "PASS_NO_TOKEN_OUTPUT"})
    case = _jsonable(execution.case)
    if not isinstance(case, Mapping) or str(case.get("status", "FAIL")) not in {"PASS", "VALID"}:
        errors = tuple(case.get("errors", ())) if isinstance(case, Mapping) else ("UNDERLYING_CASE_INVALID",)
        return DoctorWorkflowResult(DOCTOR_RUNTIME_CONTRACT_VERSION, STAGE5_PASS4_CONTRACT_VERSION, plan.workflow_id, plan.workflow_kind, plan.source_mode, type(execution.case).__name__, "PASS", "CONFIRMED", "FAIL", None, EXIT_EXECUTION_FAILURE, case if isinstance(case, Mapping) else None, None, None, (), errors, {"discord_contacted": False, "network_contacted": False, "runtime_ai_used": False}, {"workflow_plan_unchanged": True, "underlying_case_unchanged": True, "protected_evidence_unchanged": True, "token_redaction_status": "PASS_NO_TOKEN_OUTPUT"})
    state = _result_state(plan.workflow_kind, case)
    presentation = _project_presentation(plan.workflow_kind, case, plan.output_format)
    exit_code = EXIT_UNKNOWN if state == "UNKNOWN" else EXIT_SUCCESS
    case_fingerprint = case.get("case_fingerprint") or case.get("enumeration_case_fingerprint")
    return DoctorWorkflowResult(
        DOCTOR_RUNTIME_CONTRACT_VERSION,
        STAGE5_PASS4_CONTRACT_VERSION,
        plan.workflow_id,
        plan.workflow_kind,
        plan.source_mode,
        type(execution.case).__name__,
        "PASS",
        "CONFIRMED",
        "PASS",
        state,
        exit_code,
        case,
        presentation,
        _primary_reason(plan.workflow_kind, case),
        tuple(case.get("warnings", ())),
        tuple(case.get("errors", ())),
        {
            "workflow_plan_fingerprint": plan.as_dict()["workflow_plan_fingerprint"],
            "underlying_case_fingerprint": case_fingerprint,
            "snapshot_fingerprint": (case.get("provenance") or {}).get("snapshot_fingerprint") if isinstance(case.get("provenance"), Mapping) else None,
            "selector_session_fingerprint": plan.selector_session_fingerprint,
            "evidence_classifications": list(plan.evidence_classifications),
            "verification_statuses": list(plan.verification_statuses),
            "discord_contacted": False,
            "network_contacted": False,
            "runtime_ai_used": False,
            "recommendations_generated": False,
        },
        {
            "snapshot_unchanged": True,
            "workflow_plan_unchanged": True,
            "underlying_query_unchanged": True,
            "underlying_case_unchanged": True,
            "registries_unchanged": True,
            "protected_evidence_unchanged": True,
            "discord_writes": 0,
            "stage3_invoked_directly": False,
            "token_redaction_status": "PASS_NO_TOKEN_OUTPUT",
        },
    )


def render_doctor_workflow_result(result: DoctorWorkflowResult) -> str:
    """Return the requested precomputed presentation without changing meaning."""

    if not result.passed or not isinstance(result.presentation, Mapping):
        raise DoctorRuntimeOutputError("WORKFLOW_PRESENTATION_UNAVAILABLE")
    output = result.presentation
    if result.workflow_kind is None:
        raise DoctorRuntimeOutputError("WORKFLOW_KIND_UNAVAILABLE")
    format_value = STRUCTURED_JSON if output.get("output_format") == STRUCTURED_JSON else None
    # The selected format is part of the plan but retained by the caller, so a
    # structured result is always available even when a frozen case had no text renderer.
    if format_value == STRUCTURED_JSON:
        return canonical_json(result.as_dict()) + "\n"
    text = str(output.get("discord_markdown" if output.get("requested_format") == DISCORD_MARKDOWN else "plain_text") or "")
    return _mention_neutral(text).replace("\r\n", "\n").replace("\r", "\n") + "\n"


def render_workflow_result_for_format(result: DoctorWorkflowResult, output_format: str) -> str:
    if not result.passed or not isinstance(result.presentation, Mapping):
        raise DoctorRuntimeOutputError("WORKFLOW_PRESENTATION_UNAVAILABLE")
    output_format = str(output_format).upper()
    if output_format == STRUCTURED_JSON:
        return canonical_json(result.as_dict()) + "\n"
    key = "discord_markdown" if output_format == DISCORD_MARKDOWN else "plain_text"
    # This is an envelope around the frozen Stage 4 wording, not a second
    # explanation renderer.  The stable identifiers make authoritative result
    # state and primary reason visible in every human-readable output mode.
    metadata = (
        f"Result state: {result.result_state or 'UNKNOWN'}\n"
        f"Primary reason: {result.primary_reason or 'UNAVAILABLE'}\n"
    )
    body = _mention_neutral(str(result.presentation.get(key) or "")).replace("\r\n", "\n").replace("\r", "\n")
    return metadata + body + "\n"


def _safe_output_path(path: str | Path) -> Path:
    raw = Path(path)
    if any(part == ".." for part in raw.parts):
        raise DoctorRuntimeOutputError("OUTPUT_PATH_TRAVERSAL_REJECTED")
    try:
        return raw.expanduser().resolve()
    except OSError as exc:
        raise DoctorRuntimeOutputError("OUTPUT_PATH_INVALID") from exc


def write_doctor_output(path: str | Path, text: str, *, overwrite: bool = False) -> tuple[Path, str]:
    """Atomically write one explicit local output path in UTF-8 without BOM."""

    target = _safe_output_path(path)
    if target.exists() and not overwrite:
        raise DoctorRuntimeOutputError("OUTPUT_EXISTS")
    if target.suffix.lower() not in {".txt", ".md", ".json"}:
        raise DoctorRuntimeOutputError("OUTPUT_EXTENSION_UNSUPPORTED")
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = text.encode("utf-8")
        with NamedTemporaryFile("wb", delete=False, dir=target.parent, prefix=f".{target.name}.", suffix=".tmp") as handle:
            handle.write(payload)
            temporary = Path(handle.name)
        temporary.replace(target)
    except OSError as exc:
        try:
            if "temporary" in locals() and temporary.exists():
                temporary.unlink()
        except OSError:
            pass
        raise DoctorRuntimeOutputError("OUTPUT_WRITE_FAILED") from exc
    return target, hashlib.sha256(payload).hexdigest()


def validate_doctor_batch(value: Mapping[str, Any]) -> tuple[str, ...]:
    if not isinstance(value, Mapping):
        return ("BATCH_NOT_MAPPING",)
    errors: list[str] = list(_contains_secret(value, "batch"))
    if value.get("contract") != DOCTOR_BATCH_CONTRACT_VERSION:
        errors.append("BATCH_CONTRACT_UNSUPPORTED")
    batch_id = value.get("batch_id")
    if not isinstance(batch_id, str) or not batch_id.strip() or any(part in batch_id for part in ("..", "\\", "/")):
        errors.append("BATCH_ID_INVALID")
    workflows = value.get("workflows")
    if not isinstance(workflows, Sequence) or isinstance(workflows, (str, bytes)) or not workflows:
        errors.append("BATCH_WORKFLOWS_EMPTY")
    elif len(workflows) > 100:
        errors.append("BATCH_WORKFLOWS_TOO_MANY")
    else:
        identifiers: set[str] = set()
        for index, workflow in enumerate(workflows):
            if not isinstance(workflow, Mapping):
                errors.append(f"BATCH_WORKFLOW_NOT_MAPPING:{index}")
                continue
            identifier = workflow.get("workflow_id")
            if not isinstance(identifier, str) or not identifier:
                errors.append(f"BATCH_WORKFLOW_ID_INVALID:{index}")
            elif identifier in identifiers:
                errors.append(f"BATCH_WORKFLOW_ID_DUPLICATE:{identifier}")
            identifiers.add(str(identifier))
            errors.extend(f"BATCH_WORKFLOW_{index}:{item}" for item in validate_doctor_workflow(workflow))
    policy = str(value.get("failure_policy", CONTINUE_WITH_REPORT)).upper()
    if policy not in {"FAIL_FAST", CONTINUE_WITH_REPORT}:
        errors.append("BATCH_FAILURE_POLICY_UNSUPPORTED")
    return tuple(sorted(set(errors)))


def execute_doctor_workflow_batch(value: Mapping[str, Any]) -> tuple[dict[str, Any], tuple[DoctorWorkflowResult, ...]]:
    """Execute independent ordered plans without shared mutation."""

    errors = validate_doctor_batch(value)
    if errors:
        raise DoctorRuntimeInputError(";".join(errors))
    failure_policy = str(value.get("failure_policy", CONTINUE_WITH_REPORT)).upper()
    results: list[DoctorWorkflowResult] = []
    for raw_plan in value["workflows"]:
        result = execute_doctor_workflow(raw_plan)
        results.append(result)
        if failure_policy == "FAIL_FAST" and not result.passed:
            break
    failures = [result for result in results if not result.passed]
    unknowns = [result for result in results if result.exit_code == EXIT_UNKNOWN]
    exit_code = EXIT_BATCH_PARTIAL if failures else (EXIT_UNKNOWN if unknowns else EXIT_SUCCESS)
    summary = {
        "batch_contract_version": DOCTOR_BATCH_CONTRACT_VERSION,
        "batch_id": value["batch_id"],
        "status": "FAIL" if failures else "PASS",
        "exit_code": exit_code,
        "failure_policy": failure_policy,
        "ordered_workflow_ids": [item.workflow_id for item in results],
        "workflow_count": len(results),
        "completed_count": sum(item.passed for item in results),
        "failed_count": len(failures),
        "unknown_count": len(unknowns),
        "results": [item.as_dict() for item in results],
        "discord_contacted": False,
        "network_contacted": False,
        "discord_writes": 0,
        "token_disclosure_status": "PASS_NO_TOKEN_OUTPUT",
    }
    summary["batch_fingerprint"] = hashlib.sha256(canonical_json(summary).encode("utf-8")).hexdigest()
    return summary, tuple(results)


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_bytes().decode("utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise DoctorRuntimeInputError(f"INPUT_JSON_INVALID:{path.name}") from exc


def _find_record(records: Sequence[Mapping[str, Any]], identifier: str | None) -> Mapping[str, Any] | None:
    if not identifier:
        return None
    for record in records:
        if str(record.get("id")) == str(identifier):
            return record
    return None


def _live_derived_queries(root: Path) -> dict[str, Mapping[str, Any]]:
    snapshot = _load_json(root / "stage3-pass6-evidence" / "authority_live_snapshot.json")
    manifest = _load_json(root / "stage3-pass6-scenarios.json")
    actions = _load_json(root / "stage3-pass6-evidence" / "action_results.json")
    if not isinstance(snapshot, Mapping) or not isinstance(manifest, Mapping) or not isinstance(actions, Sequence):
        raise DoctorRuntimeInputError("LIVE_DERIVED_INPUT_INVALID")
    scenarios = manifest.get("scenarios")
    if not isinstance(scenarios, Sequence):
        raise DoctorRuntimeInputError("LIVE_DERIVED_SCENARIOS_INVALID")
    actions_by_operation = {str(item.get("operation_key")): item for item in actions if isinstance(item, Mapping)}
    redacted_roles = snapshot.get("roles")
    redacted_role_records = tuple(redacted_roles.values()) if isinstance(redacted_roles, Mapping) else ()
    everyone_source = next((item for item in redacted_role_records if isinstance(item, Mapping) and item.get("is_everyone") is True), {})
    everyone_permissions = everyone_source.get("permissions_decimal") if isinstance(everyone_source, Mapping) else None
    values: dict[str, Mapping[str, Any]] = {}
    for scenario in scenarios:
        if not isinstance(scenario, Mapping):
            continue
        operation = str(scenario.get("operation_key", ""))
        actor_id = str(scenario.get("actor_member_id", ""))
        target_id = str(scenario.get("target_id", ""))
        context_id = scenario.get("context_id")
        target_type = str(scenario.get("target_type", ""))
        frozen_action = actions_by_operation.get(operation)
        if frozen_action is None:
            raise DoctorRuntimeInputError(f"LIVE_DERIVED_ACTION_MISSING:{operation}")
        facts = scenario.get("expected_structural_facts") if isinstance(scenario.get("expected_structural_facts"), Mapping) else {}
        # Public Pass 6 snapshots redact identifiers by design.  This pre-execution
        # representation projection constructs only
        # a minimal local representation from the private scenario manifest's
        # real IDs and explicitly recorded structural facts.  No redacted value
        # is reversed and no new Discord object ID or permission bit is made up.
        actor = {"id": actor_id, "guild_id": scenario.get("guild_id"), "role_ids": [scenario.get("guild_id")], "bot": False, "timeout_state": "INACTIVE", "mfa_state": "UNKNOWN"}
        if target_type == "MEMBER":
            target = {"id": target_id, "guild_id": scenario.get("guild_id"), "role_ids": [scenario.get("guild_id")], "bot": True, "timeout_state": "INACTIVE", "mfa_state": "UNKNOWN"}
        elif target_type == "ROLE":
            target = {"id": target_id, "guild_id": scenario.get("guild_id"), "is_everyone": bool(facts.get("target_role_is_everyone", False)), "managed": bool(facts.get("target_role_managed", False)), "position": facts.get("target_role_position")}
        else:
            target = {"id": target_id, "guild_id": scenario.get("guild_id"), "type_key": facts.get("context_type", "TEXT"), "parent_id": facts.get("context_parent_id"), "permission_overwrites": []}
        context = target if target_type == "CHANNEL" else ({"id": context_id, "guild_id": scenario.get("guild_id"), "type_key": facts.get("context_type", "TEXT"), "parent_id": facts.get("context_parent_id"), "permission_overwrites": []} if context_id else None)
        model_snapshot = {
            "guild": {"id": scenario.get("guild_id"), "owner_id": actor_id},
            "roles": [{"id": scenario.get("guild_id"), "is_everyone": True, "managed": False, "position": 0, "permissions_decimal": everyone_permissions}],
            "channels": [context] if context else [],
            "threads": [],
            "source": {"permission_definition_version": frozen_action.get("permission_definition_version"), "source_structural_completeness": frozen_action.get("analysis_completeness")},
        }
        if target_type == "ROLE":
            model_snapshot["roles"].append(target)
        if target_type == "MEMBER":
            model_snapshot["members"] = [actor, target]
        else:
            model_snapshot["members"] = [actor]
        values[operation] = {
            "query_id": f"pass4-live-{operation}",
            "query_intent": "EXPLAIN_ACTUAL_RESULT",
            "target_kind": "ACTION",
            "target_key": operation,
            "guild_id": scenario.get("guild_id"),
            "subject_id": actor_id,
            "actor_id": actor_id,
            "target_type": target_type,
            "target_id": target_id,
            "context_id": context_id,
            "context_type": str(context.get("type_key")) if isinstance(context, Mapping) else "GUILD",
            "parent_id": context.get("parent_id") if isinstance(context, Mapping) else None,
            "snapshot": model_snapshot,
            "member_record": actor,
            "target_record": target,
            "input_health": {"structural_completeness": snapshot.get("structural_completeness", "COMPLETE")},
            "explicitly_supplied_member_health": {"status": "COMPLETE"},
            "snapshot_or_fixture_version": "GUILD-DOCTOR-SNAPSHOT-0.1",
            "evidence_classifications": ["LOCAL_RUNTIME_OVER_LIVE_DERIVED_EVIDENCE", "REPRESENTATION_PROJECTION"],
            "verification_statuses": ["LOCAL_RUNTIME_OVER_LIVE_DERIVED_EVIDENCE", "REPRESENTATION_PROJECTION"],
            "explanation_mode": "DETAILED",
            "presentation_profile": "DETAILED_REPORT",
            "output_format": "PLAIN_TEXT",
        }
    return values


def verify_doctor_runtime(root: str | Path, evidence_directory: str | Path) -> dict[str, Any]:
    """Run deterministic local runtime coverage over frozen live-derived inputs."""

    project_root = Path(root).resolve()
    evidence = _safe_output_path(evidence_directory)
    evidence.mkdir(parents=True, exist_ok=True)
    queries = _live_derived_queries(project_root)
    required_operations = ("member.timeout", "role.edit", "channel.manage")
    plans = []
    for operation in required_operations:
        query = queries.get(operation)
        if query is None:
            raise DoctorRuntimeInputError(f"LIVE_DERIVED_OPERATION_MISSING:{operation}")
        plans.append(DoctorWorkflowPlan.from_mapping({"workflow_id": f"live-why-{operation.replace('.', '-')}", "workflow_kind": WHY, "source_mode": DIRECT_QUERY, "guild_id": query["guild_id"], "normalized_query": query, "confirmed": True, "require_review_confirmation": False, "explanation_mode": query["explanation_mode"], "presentation_profile": query["presentation_profile"], "output_format": query["output_format"], "evidence_classifications": ["LOCAL_RUNTIME_OVER_LIVE_DERIVED_EVIDENCE"], "verification_statuses": ["LOCAL_RUNTIME_OVER_LIVE_DERIVED_EVIDENCE"]}).as_dict())
        source_query = {"query_id": f"live-source-{operation}", "source_intent": "TRACE_SOURCE_CHAIN", "source_detail_level": "MATERIAL_CHAIN", "doctor_query": query, "explanation_mode": "DETAILED", "presentation_profile": "DETAILED_REPORT", "output_format": "STRUCTURED_JSON"}
        plans.append(DoctorWorkflowPlan.from_mapping({"workflow_id": f"live-source-{operation.replace('.', '-')}", "workflow_kind": SOURCE_LOCATION, "source_mode": DIRECT_QUERY, "guild_id": query["guild_id"], "normalized_query": source_query, "confirmed": True, "require_review_confirmation": False, "explanation_mode": "DETAILED", "presentation_profile": "DETAILED_REPORT", "output_format": "STRUCTURED_JSON", "evidence_classifications": ["LOCAL_RUNTIME_OVER_LIVE_DERIVED_EVIDENCE"], "verification_statuses": ["LOCAL_RUNTIME_OVER_LIVE_DERIVED_EVIDENCE"]}).as_dict())
    results = [execute_doctor_workflow(plan) for plan in plans]
    frozen_actions = _load_json(project_root / "stage3-pass6-evidence" / "action_results.json")
    frozen_by_operation = {str(item.get("operation_key")): item for item in frozen_actions if isinstance(item, Mapping)} if isinstance(frozen_actions, Sequence) else {}
    preservation = []
    for operation in required_operations:
        model = next((result for result in results if result.workflow_id == f"live-why-{operation.replace('.', '-')}"), None)
        frozen = frozen_by_operation.get(operation, {})
        frozen_reason = next(iter(frozen.get("reason_codes", ())), None) if isinstance(frozen, Mapping) else None
        preservation.append({
            "operation_key": operation,
            "frozen_result_state": frozen.get("final_result") if isinstance(frozen, Mapping) else None,
            "local_model_result_state": model.result_state if model else None,
            "result_state_preserved": bool(model and model.result_state == frozen.get("final_result")),
            "frozen_primary_reason": frozen_reason,
            "local_primary_reason": model.primary_reason if model else None,
            "primary_reason_preserved": bool(model and frozen_reason == model.primary_reason),
            "limitation": "The retained public Pass 6 snapshot redacts object identifiers and omits raw member records; the local model therefore uses only an explicit minimal representation projection and does not claim equivalence to the frozen action result.",
        })
    report = {
        "contract": STAGE5_PASS4_CONTRACT_VERSION,
        "runtime_contract_version": DOCTOR_RUNTIME_CONTRACT_VERSION,
        "evidence_classification": "LOCAL_RUNTIME_OVER_LIVE_DERIVED_EVIDENCE",
        "live_execution": False,
        "network_contacted": False,
        "discord_contacted": False,
        "discord_writes": 0,
        "operations": list(required_operations),
        "workflow_count": len(results),
        "results": [result.as_dict() for result in results],
        "frozen_result_state_preservation": preservation,
        "frozen_result_state_preserved": all(item["result_state_preserved"] for item in preservation),
        "frozen_primary_reason_preserved": all(item["primary_reason_preserved"] for item in preservation),
        "status": "PASS" if all(result.passed for result in results) else "FAIL",
        "preserves_pre_execution_model": True,
        "preserves_execution_attempted_false": True,
        "preserves_execution_guarantee_false": True,
        "token_disclosure_status": "PASS_NO_TOKEN_OUTPUT",
    }
    report["result_fingerprint"] = hashlib.sha256(canonical_json(report).encode("utf-8")).hexdigest()
    write_doctor_output(evidence / "live_derived_workflow_report.json", canonical_json(report) + "\n", overwrite=True)
    return report


def safe_progress(message: str) -> None:
    """Best-effort flushed console progress that tolerates redirected streams."""

    try:
        print(f"[Guild Doctor] {message}", file=sys.stdout, flush=True)
    except Exception:
        try:
            sys.__stdout__.write(f"[Guild Doctor] {message}\n")
            sys.__stdout__.flush()
        except Exception:
            pass


__all__ = [
    "DOCTOR_BATCH_CONTRACT_VERSION", "DOCTOR_RUNTIME_CONTRACT_VERSION", "DOCTOR_RUNTIME_GOLDEN_VERSION", "DoctorRuntimeError",
    "DoctorRuntimeInputError", "DoctorRuntimeOutputError", "DoctorWorkflowResult", "EXIT_ARGUMENTS", "EXIT_BATCH_PARTIAL",
    "EXIT_CANCELLED", "EXIT_CLOSURE_PENDING", "EXIT_EXECUTION_FAILURE", "EXIT_INPUT_FAILURE", "EXIT_INTEGRITY_FAILURE",
    "EXIT_INTERRUPTED", "EXIT_INVALID_WORKFLOW", "EXIT_OUTPUT_FAILURE", "EXIT_SUCCESS", "EXIT_UNKNOWN", "EXIT_UNSUPPORTED",
    "execute_doctor_workflow", "execute_doctor_workflow_batch", "render_doctor_workflow_result", "render_workflow_result_for_format",
    "safe_progress", "validate_doctor_batch", "verify_doctor_runtime", "write_doctor_output",
]
