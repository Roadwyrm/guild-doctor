"""Deterministic local typed schema representation; no registration transport."""
from __future__ import annotations
import hashlib,json
from .discord_command_manifest import COMMAND_MANIFEST,manifest_fingerprint
COMMAND_SCHEMA_CONTRACT="GUILD-DOCTOR-DISCORD-COMMAND-SCHEMA-0.1";LIVE_SCHEMA_NORMALIZATION_CONTRACT="GUILD-DOCTOR-LIVE-SCHEMA-NORMALIZATION-0.1"
LIVE_ROOT_NAME="guild-doctor";LIVE_ROOT_DESCRIPTION="Guild Doctor diagnostic commands."
def _option(option):return {"name":option.name,"description":option.description,"type":option.type,"required":option.required,"choices":[{"name":label,"value":value} for label,value in option.choices],"autocomplete":option.autocomplete,"channel_types":list(option.channel_types),"options":[]}
def build_schema():return {"namespace":"guild-doctor","commands":[{"name":item.slash_name,"description":item.description,"options":[_option(option) for option in item.options],"guild_only":item.guild_only,"owner_only":item.owner_only,"default_ephemeral":True} for item in COMMAND_MANIFEST],"manifest_fingerprint":manifest_fingerprint()}
def schema_fingerprint(schema=None):return hashlib.sha256(json.dumps(schema or build_schema(),sort_keys=True,separators=(",",":")).encode()).hexdigest()
def _field(value,name,default=None):return value.get(name,default) if isinstance(value,dict) else getattr(value,name,default)
def _type_name(value,default):
 if value is None:return default
 if isinstance(value,str):return value.lower()
 return {1:"subcommand",2:"subcommand_group",3:"string",4:"integer",5:"boolean",6:"user",7:"channel",8:"role",9:"mentionable",10:"number",11:"attachment"}.get(getattr(value,"value",value),str(getattr(value,"value",value)))
def normalize_channel_type(value):
 raw=getattr(value,"value",value)
 if isinstance(raw,str):
  normalized=raw.lower().replace("channeltype.","")
  if normalized in {"category","text","news","forum","voice","stage_voice"}:return normalized
 mapping={0:"text",2:"voice",4:"category",5:"news",13:"stage_voice",15:"forum"}
 if raw in mapping:return mapping[raw]
 raise ValueError("UNSUPPORTED_CHANNEL_TYPE")
def _normalize_option(value):return {"name":_field(value,"display_name",_field(value,"name")),"description":_field(value,"description", ""),"type":_type_name(_field(value,"type"),"unknown"),"required":bool(_field(value,"required",False)),"choices":[_normalize_option(choice) for choice in (_field(value,"choices",[]) or [])],"autocomplete":bool(_field(value,"autocomplete",False)),"channel_types":[normalize_channel_type(item) for item in (_field(value,"channel_types",[]) or [])],"options":[_normalize_option(option) for option in (_field(value,"options",[]) or [])]}
def _normalize_subcommand(value):return {"name":_field(value,"name"),"description":_field(value,"description", ""),"options":[_normalize_option(option) for option in (_field(value,"options",None) if _field(value,"options",None) is not None else _field(value,"parameters",[]) or [])]}
def normalize_live_commands(commands,*,root_name=LIVE_ROOT_NAME):
 roots=[];unrelated=[]
 for command in list(commands):
  if _field(command,"name")==root_name:roots.append({"root_name":root_name,"root_type":"chat_input","description":_field(command,"description", ""),"subcommands":[_normalize_subcommand(item) for item in (_field(command,"options",None) if _field(command,"options",None) is not None else _field(command,"commands",[]) or [])]})
  else:unrelated.append({"name":_field(command,"name"),"type":_type_name(_field(command,"type"),"chat_input")})
 return {"top_level_command_count":len(list(commands)),"guild_doctor_root_count":len(roots),"guild_doctor_subcommand_count":sum(len(root["subcommands"]) for root in roots),"unrelated_top_level_command_count":len(unrelated),"roots":roots,"unrelated_commands":unrelated}
def expected_live_schema():return {"root_name":LIVE_ROOT_NAME,"root_type":"chat_input","description":LIVE_ROOT_DESCRIPTION,"subcommands":[{"name":item.slash_name,"description":item.description,"options":[_option(option) for option in item.options]} for item in COMMAND_MANIFEST]}
def compare_live_schema(normalized,*,expected=None):
 expected=expected or expected_live_schema();roots=normalized.get("roots",[])
 if not roots:return {"state":"COMMANDS_ABSENT","schema_matches":False,"reason":"NO_GUILD_DOCTOR_ROOT"}
 if len(roots)!=1:return {"state":"COMMANDS_PRESENT_MISMATCH","schema_matches":False,"reason":"ROOT_COUNT"}
 root=roots[0];actual={item.get("name") for item in root.get("subcommands",[])};wanted={item["name"] for item in expected["subcommands"]}
 if root.get("root_name")!=expected["root_name"] or root.get("root_type")!=expected["root_type"] or root.get("description")!=expected["description"]:return {"state":"COMMANDS_PRESENT_MISMATCH","schema_matches":False,"reason":"ROOT_SCHEMA"}
 if "diagnose" in actual or len(actual)!=len(root.get("subcommands",[])) or actual-wanted:return {"state":"COMMANDS_PRESENT_MISMATCH","schema_matches":False,"reason":"SUBCOMMAND_SCHEMA"}
 if actual<wanted:return {"state":"COMMANDS_PRESENT_PARTIAL","schema_matches":False,"reason":"MISSING_SUBCOMMAND"}
 return {"state":"COMMANDS_PRESENT_EXACT" if root.get("subcommands")==expected["subcommands"] else "COMMANDS_PRESENT_MISMATCH","schema_matches":root.get("subcommands")==expected["subcommands"],"reason":"EXACT" if root.get("subcommands")==expected["subcommands"] else "NESTED_SCHEMA"}
