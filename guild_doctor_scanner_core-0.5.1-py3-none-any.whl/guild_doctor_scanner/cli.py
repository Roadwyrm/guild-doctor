"""Command-line fixture normalizer."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .canonical import canonical_json
from .errors import SnapshotError
from .normalizer import normalize_bundle


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Normalize and validate a saved Guild Doctor Stage 2 fixture")
    parser.add_argument("input", type=Path, help="Input Discord-shaped JSON fixture")
    parser.add_argument("--output", "-o", type=Path, help="Write normalized snapshot JSON")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print output instead of canonical compact JSON")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        raw = json.loads(args.input.read_text(encoding="utf-8"))
        snapshot = normalize_bundle(raw)
    except (OSError, json.JSONDecodeError, SnapshotError) as exc:
        print(f"guild-doctor-snapshot: error: {exc}", file=sys.stderr)
        return 1

    data = snapshot.as_dict()
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) if args.pretty else canonical_json(data)
    if args.output:
        args.output.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)

    healthy_states = {"COMPLETE", "NOT_REQUESTED"}
    return (
        0
        if snapshot.structural_completeness in healthy_states
        and snapshot.member_completeness in healthy_states
        and snapshot.thread_completeness in healthy_states
        else 2
    )


if __name__ == "__main__":
    raise SystemExit(main())
