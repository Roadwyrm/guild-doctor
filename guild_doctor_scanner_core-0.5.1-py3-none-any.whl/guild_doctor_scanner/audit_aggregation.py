"""Pure deterministic aggregation for isolated Stage 6 Pass 6B audit results."""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Final

from .audit_contract import AUDIT_CONFIDENCE, AUDIT_FINDING_CONTRACT_VERSION, AUDIT_RULES_VERSION, AUDIT_SEVERITIES, EVALUATION_STATES, freeze, scan_private, thaw
from .audit_finding import AuditFinding
from .audit_rule_evaluator import AUDIT_RULE_EVALUATOR_CONTRACT, AuditEvaluationResult
from .audit_rule_registry import AUDIT_RULES, registry_fingerprint
from .canonical import sha256_hex


AUDIT_AGGREGATION_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS6C-AGGREGATION-0.1"
GROUPED_FINDING_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS6C-GROUPED-FINDING-0.1"
AGGREGATION_RESULT_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS6C-AGGREGATION-RESULT-0.1"

SEVERITY_PRIORITY: Final[dict[str, int]] = {
    "CRITICAL": 0,
    "HIGH": 1,
    "MEDIUM": 2,
    "LOW": 3,
    "INFORMATIONAL": 4,
    "NEEDS_REVIEW": 5,
}
CONFIDENCE_PRIORITY: Final[dict[str, int]] = {
    "VERIFIED": 0,
    "HIGH": 1,
    "MEDIUM": 2,
    "LOW": 3,
    "INSUFFICIENT_DATA": 4,
}


class AuditAggregationError(ValueError):
    """Stable fail-closed aggregation input or compatibility failure."""


def _opaque_group_key(payload: Mapping[str, Any]) -> str:
    return f"AUDIT-AGG-{sha256_hex(dict(payload))[:20].upper()}"


def _semantic_identity(finding: AuditFinding) -> dict[str, Any]:
    """Frozen grouping basis: semantic fields, never display wording or order."""
    return {
        "rule_id": finding.rule_id,
        "finding_class": finding.finding_class,
        "verification_label": finding.verification_label,
        "severity": finding.severity,
        "confidence": finding.confidence,
        "evaluation_state": finding.evaluation_state,
        "completeness_state": finding.completeness_state,
        "duplicate_grouping_key": finding.duplicate_grouping_key,
        "affected_object_reference_keys": [item.opaque_reference_key for item in finding.affected_objects],
    }


@dataclass(frozen=True, slots=True)
class AggregatedRuleState:
    rule_id: str
    evaluation_state: str
    finding_fingerprints: tuple[str, ...]
    missing_evidence: tuple[str, ...]
    errors: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.rule_id not in {rule.rule_id for rule in AUDIT_RULES}:
            raise AuditAggregationError("AUDIT_AGGREGATION_RULE_UNKNOWN")
        if self.evaluation_state not in EVALUATION_STATES:
            raise AuditAggregationError("AUDIT_AGGREGATION_EVALUATION_STATE_INVALID")
        object.__setattr__(self, "finding_fingerprints", tuple(sorted(set(self.finding_fingerprints))))
        object.__setattr__(self, "missing_evidence", tuple(sorted(set(self.missing_evidence))))
        object.__setattr__(self, "errors", tuple(sorted(set(self.errors))))

    def as_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "evaluation_state": self.evaluation_state,
            "finding_fingerprints": list(self.finding_fingerprints),
            "missing_evidence": list(self.missing_evidence),
            "errors": list(self.errors),
        }


@dataclass(frozen=True, slots=True)
class GroupedAuditFinding:
    grouping_key: str
    grouping_basis: Mapping[str, Any]
    occurrence_count: int
    source_finding_fingerprints: tuple[str, ...]
    source_evaluation_states: tuple[str, ...]
    finding: AuditFinding
    grouped_finding_contract: str = GROUPED_FINDING_CONTRACT

    def __post_init__(self) -> None:
        if self.grouped_finding_contract != GROUPED_FINDING_CONTRACT:
            raise AuditAggregationError("AUDIT_AGGREGATION_GROUP_CONTRACT_UNSUPPORTED")
        if not self.grouping_key.startswith("AUDIT-AGG-"):
            raise AuditAggregationError("AUDIT_AGGREGATION_GROUP_KEY_INVALID")
        if self.occurrence_count < 1:
            raise AuditAggregationError("AUDIT_AGGREGATION_OCCURRENCE_INVALID")
        if not self.source_finding_fingerprints:
            raise AuditAggregationError("AUDIT_AGGREGATION_PROVENANCE_MISSING")
        if self.finding.finding_fingerprint not in self.source_finding_fingerprints:
            raise AuditAggregationError("AUDIT_AGGREGATION_SOURCE_FINGERPRINT_MISSING")
        if self.finding.rule_id != self.grouping_basis.get("rule_id"):
            raise AuditAggregationError("AUDIT_AGGREGATION_GROUP_RULE_MISMATCH")
        object.__setattr__(self, "grouping_basis", freeze(dict(self.grouping_basis)))
        object.__setattr__(self, "source_finding_fingerprints", tuple(sorted(set(self.source_finding_fingerprints))))
        object.__setattr__(self, "source_evaluation_states", tuple(sorted(set(self.source_evaluation_states))))
        if scan_private(self.as_dict(), "aggregated_group"):
            raise AuditAggregationError("AUDIT_AGGREGATION_PRIVATE_DATA_FORBIDDEN")

    @property
    def priority_key(self) -> tuple[int, int, str, str]:
        return (
            SEVERITY_PRIORITY[self.finding.severity],
            CONFIDENCE_PRIORITY[self.finding.confidence],
            self.finding.rule_id,
            self.grouping_key,
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "grouping_key": self.grouping_key,
            "grouping_basis": thaw(self.grouping_basis),
            "occurrence_count": self.occurrence_count,
            "source_finding_fingerprints": list(self.source_finding_fingerprints),
            "source_evaluation_states": list(self.source_evaluation_states),
            "priority_key": list(self.priority_key),
            "finding": self.finding.as_dict(),
            "grouped_finding_contract": self.grouped_finding_contract,
        }


@dataclass(frozen=True, slots=True)
class AuditAggregationResult:
    snapshot_fingerprint: str
    source_result_fingerprint: str
    registry_fingerprint: str
    evaluator_contract: str
    finding_schema_contract: str
    grouped_findings: tuple[GroupedAuditFinding, ...]
    rule_states: tuple[AggregatedRuleState, ...]
    aggregation_contract: str = AUDIT_AGGREGATION_CONTRACT
    result_contract: str = AGGREGATION_RESULT_CONTRACT
    no_action: bool = True
    no_write: bool = True
    aggregate_fingerprint: str = ""

    def __post_init__(self) -> None:
        if self.aggregation_contract != AUDIT_AGGREGATION_CONTRACT or self.result_contract != AGGREGATION_RESULT_CONTRACT:
            raise AuditAggregationError("AUDIT_AGGREGATION_CONTRACT_UNSUPPORTED")
        if self.registry_fingerprint != registry_fingerprint():
            raise AuditAggregationError("AUDIT_AGGREGATION_REGISTRY_FINGERPRINT_MISMATCH")
        if self.evaluator_contract != AUDIT_RULE_EVALUATOR_CONTRACT:
            raise AuditAggregationError("AUDIT_AGGREGATION_EVALUATOR_CONTRACT_MISMATCH")
        if self.finding_schema_contract != AUDIT_FINDING_CONTRACT_VERSION:
            raise AuditAggregationError("AUDIT_AGGREGATION_FINDING_CONTRACT_MISMATCH")
        if self.no_action is not True or self.no_write is not True:
            raise AuditAggregationError("AUDIT_AGGREGATION_READ_ONLY_REQUIRED")
        expected_rules = tuple(rule.rule_id for rule in AUDIT_RULES)
        if tuple(state.rule_id for state in self.rule_states) != expected_rules:
            raise AuditAggregationError("AUDIT_AGGREGATION_RULE_STATE_ORDER_INVALID")
        if self.grouped_findings != tuple(sorted(self.grouped_findings, key=lambda item: item.priority_key)):
            raise AuditAggregationError("AUDIT_AGGREGATION_PRIORITY_ORDER_INVALID")
        payload = self._payload(include_fingerprint=False)
        if scan_private(payload, "aggregation_result"):
            raise AuditAggregationError("AUDIT_AGGREGATION_PRIVATE_DATA_FORBIDDEN")
        expected = sha256_hex(payload)
        if self.aggregate_fingerprint and self.aggregate_fingerprint != expected:
            raise AuditAggregationError("AUDIT_AGGREGATION_FINGERPRINT_MISMATCH")
        object.__setattr__(self, "aggregate_fingerprint", expected)

    def _payload(self, *, include_fingerprint: bool) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "aggregation_contract": self.aggregation_contract,
            "result_contract": self.result_contract,
            "snapshot_fingerprint": self.snapshot_fingerprint,
            "source_result_fingerprint": self.source_result_fingerprint,
            "registry_fingerprint": self.registry_fingerprint,
            "evaluator_contract": self.evaluator_contract,
            "finding_schema_contract": self.finding_schema_contract,
            "grouped_findings": [item.as_dict() for item in self.grouped_findings],
            "rule_states": [item.as_dict() for item in self.rule_states],
            "no_action": self.no_action,
            "no_write": self.no_write,
        }
        if include_fingerprint:
            payload["aggregate_fingerprint"] = self.aggregate_fingerprint
        return payload

    def as_dict(self) -> dict[str, Any]:
        return self._payload(include_fingerprint=True)


def _validate_input(result: AuditEvaluationResult) -> None:
    if not isinstance(result, AuditEvaluationResult):
        raise AuditAggregationError("AUDIT_AGGREGATION_INPUT_TYPE_INVALID")
    if result.registry_fingerprint != registry_fingerprint():
        raise AuditAggregationError("AUDIT_AGGREGATION_REGISTRY_FINGERPRINT_MISMATCH")
    if result.evaluator_contract != AUDIT_RULE_EVALUATOR_CONTRACT:
        raise AuditAggregationError("AUDIT_AGGREGATION_EVALUATOR_CONTRACT_MISMATCH")
    if result.no_action is not True or result.no_write is not True:
        raise AuditAggregationError("AUDIT_AGGREGATION_SOURCE_NOT_READ_ONLY")
    expected = tuple(rule.rule_id for rule in AUDIT_RULES)
    if tuple(item.rule_id for item in result.rule_evaluations) != expected:
        raise AuditAggregationError("AUDIT_AGGREGATION_RULE_ORDER_INVALID")
    source_findings = tuple(
        finding
        for evaluation in result.rule_evaluations
        for finding in evaluation.findings
    )
    if tuple(sorted(source_findings, key=lambda item: item.stable_sort_key)) != result.findings:
        raise AuditAggregationError("AUDIT_AGGREGATION_FINDING_PROVENANCE_MISMATCH")
    for finding in result.findings:
        if finding.finding_contract_version != AUDIT_FINDING_CONTRACT_VERSION or finding.rule_registry_version != AUDIT_RULES_VERSION:
            raise AuditAggregationError("AUDIT_AGGREGATION_FINDING_CONTRACT_MISMATCH")


def aggregate_audit_evaluation(result: AuditEvaluationResult) -> AuditAggregationResult:
    """Aggregate one frozen Pass 6B evaluation without altering source findings."""
    _validate_input(result)
    evaluation_by_rule = {item.rule_id: item for item in result.rule_evaluations}
    grouped: dict[str, list[AuditFinding]] = defaultdict(list)
    for finding in result.findings:
        basis = _semantic_identity(finding)
        grouped[_opaque_group_key(basis)].append(finding)

    groups: list[GroupedAuditFinding] = []
    for key in sorted(grouped):
        members = grouped[key]
        representative = min(members, key=lambda item: item.finding_fingerprint)
        basis = _semantic_identity(representative)
        fingerprints = tuple(sorted({item.finding_fingerprint for item in members}))
        source_states = tuple(sorted({evaluation_by_rule[item.rule_id].evaluation_state for item in members}))
        groups.append(GroupedAuditFinding(
            grouping_key=key,
            grouping_basis=basis,
            occurrence_count=len(members),
            source_finding_fingerprints=fingerprints,
            source_evaluation_states=source_states,
            finding=representative,
        ))

    rule_states = tuple(
        AggregatedRuleState(
            rule_id=evaluation.rule_id,
            evaluation_state=evaluation.evaluation_state,
            finding_fingerprints=tuple(item.finding_fingerprint for item in evaluation.findings),
            missing_evidence=evaluation.missing_evidence,
            errors=evaluation.errors,
        )
        for evaluation in result.rule_evaluations
    )
    return AuditAggregationResult(
        snapshot_fingerprint=result.snapshot_fingerprint,
        source_result_fingerprint=result.result_fingerprint,
        registry_fingerprint=result.registry_fingerprint,
        evaluator_contract=result.evaluator_contract,
        finding_schema_contract=AUDIT_FINDING_CONTRACT_VERSION,
        grouped_findings=tuple(sorted(groups, key=lambda item: item.priority_key)),
        rule_states=rule_states,
    )


__all__ = [
    "AGGREGATION_RESULT_CONTRACT", "AUDIT_AGGREGATION_CONTRACT", "AuditAggregationError",
    "AuditAggregationResult", "AggregatedRuleState", "CONFIDENCE_PRIORITY",
    "GROUPED_FINDING_CONTRACT", "GroupedAuditFinding", "SEVERITY_PRIORITY",
    "aggregate_audit_evaluation",
]
