"""Safe local export payload preparation; it never writes or uploads files."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import re

from .discord_response_renderer import render_plain_text
from .discord_response_model import UserResponse


EXPORT_PREPARATION_CONTRACT = "GUILD-DOCTOR-DISCORD-EXPORT-PREPARATION-0.1"
_SNOWFLAKE = re.compile(r"\b\d{17,20}\b")
_FORBIDDEN = ("token", "payload", "mapping", "traceback", "authorization")


@dataclass(frozen=True)
class PreparedExport:
    filename: str
    format: str
    privacy_classification: str
    content: str
    content_fingerprint: str


def prepare_export(response: UserResponse, *, owner_authorized: bool, format: str = "text", max_bytes: int = 24_000) -> PreparedExport | None:
    if not owner_authorized or format not in {"text", "json", "markdown"}:
        return None
    if format == "json":
        body = {"summary": response.concise_summary, "result_state": response.result_state_label, "primary_reason": response.primary_reason, "source_chain": response.source_chain_sections, "uncertainties": response.material_uncertainties, "warnings": response.snapshot_warnings, "no_action_attempted": True, "no_write": True}
        content = json.dumps(body, indent=2, sort_keys=True, default=str)
    else:
        content = render_plain_text(response)
        if format == "markdown":
            content = "# Guild Doctor result\n\n" + content
    content = _SNOWFLAKE.sub("[identifier redacted]", content)
    if len(content.encode("utf-8")) > max_bytes or any(item in content.lower() for item in _FORBIDDEN):
        return None
    return PreparedExport("guild_doctor_result." + ("json" if format == "json" else "md" if format == "markdown" else "txt"), format, "OWNER_ONLY_PRIVATE", content, hashlib.sha256(content.encode()).hexdigest())
