"""Deterministic guild-scoped registration planning and execution."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import asyncio
import hashlib
import json
from typing import Any

from .discord_command_manifest import COMMAND_MANIFEST, manifest_fingerprint
from .discord_command_schema import (
    compare_live_schema,
    expected_live_schema,
    normalize_live_commands,
    schema_fingerprint,
)


REGISTRATION_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-COMMAND-REGISTRATION-0.1"
REGISTRATION_STATES = frozenset({
    "REGISTRATION_NOT_REQUIRED",
    "REGISTRATION_AUTHORIZATION_REQUIRED",
    "REGISTRATION_COMPLETED",
    "REGISTRATION_BLOCKED_PREFLIGHT",
    "REGISTRATION_BLOCKED_ALLOWLIST",
    "REGISTRATION_BLOCKED_FINGERPRINT",
    "REGISTRATION_BLOCKED_REMOTE_INVENTORY",
    "REGISTRATION_FAILED_TRANSPORT",
    "REGISTRATION_FAILED_VALIDATION",
})


def _fingerprint(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(dict(value), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def registration_payload_fingerprint() -> str:
    return _fingerprint({
        "contract": REGISTRATION_CONTRACT,
        "scope": "ONE_EXPLICIT_ALLOWLISTED_GUILD",
        "global": False,
        "expected": expected_live_schema(),
        "manifest_fingerprint": manifest_fingerprint(),
        "schema_fingerprint": schema_fingerprint(),
    })


@dataclass(frozen=True, slots=True)
class RegistrationPlan:
    state: str
    before_schema_state: str
    before_route_count: int
    desired_route_count: int
    unrelated_top_level_count: int
    registration_required: bool
    guild_scoped: bool
    global_registration: bool
    payload_fingerprint: str
    diff_fingerprint: str
    stable_reason: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {name: getattr(self, name) for name in self.__dataclass_fields__}


@dataclass(frozen=True, slots=True)
class RegistrationResult:
    state: str
    before_state: str
    after_state: str
    before_route_count: int
    after_route_count: int
    desired_route_count: int
    authorization_supplied: bool
    registration_operation_count: int
    global_registration_count: int
    post_registration_fetch_count: int
    payload_fingerprint: str
    stable_reason: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {name: getattr(self, name) for name in self.__dataclass_fields__}


def build_registration_plan(
    remote_commands: Sequence[Any],
    *,
    manifest_expected: str | None = None,
    schema_expected: str | None = None,
) -> RegistrationPlan:
    expected_manifest = manifest_expected or manifest_fingerprint()
    expected_schema = schema_expected or schema_fingerprint()
    normalized = normalize_live_commands(tuple(remote_commands))
    comparison = compare_live_schema(normalized, expected=expected_live_schema())
    desired_count = len(COMMAND_MANIFEST)
    unrelated = int(normalized["unrelated_top_level_command_count"])
    desired_names = {item["name"] for item in expected_live_schema()["subcommands"]}
    observed_names = {
        item.get("name")
        for root in normalized.get("roots", ())
        for item in root.get("subcommands", ())
    }
    undeclared = bool(observed_names - desired_names)
    fingerprints_match = expected_manifest == manifest_fingerprint() and expected_schema == schema_fingerprint()
    if not fingerprints_match or desired_count != 13:
        state = "REGISTRATION_BLOCKED_FINGERPRINT"
        reason = "STAGE8_REGISTRATION_FINGERPRINT_MISMATCH"
        required = False
    elif unrelated or undeclared:
        state = "REGISTRATION_BLOCKED_REMOTE_INVENTORY"
        reason = "STAGE8_REGISTRATION_UNDECLARED_COMMAND_PRESENT"
        required = False
    elif comparison["state"] == "COMMANDS_PRESENT_EXACT" and normalized["guild_doctor_subcommand_count"] == 13:
        state = "REGISTRATION_NOT_REQUIRED"
        reason = None
        required = False
    else:
        state = "REGISTRATION_AUTHORIZATION_REQUIRED"
        reason = "STAGE8_REGISTRATION_EXPLICIT_AUTHORIZATION_REQUIRED"
        required = True
    public_diff = {
        "before_schema_state": comparison["state"],
        "before_route_count": normalized["guild_doctor_subcommand_count"],
        "desired_route_count": desired_count,
        "unrelated_top_level_count": unrelated,
        "registration_required": required,
    }
    return RegistrationPlan(
        state=state,
        before_schema_state=comparison["state"],
        before_route_count=int(normalized["guild_doctor_subcommand_count"]),
        desired_route_count=desired_count,
        unrelated_top_level_count=unrelated,
        registration_required=required,
        guild_scoped=True,
        global_registration=False,
        payload_fingerprint=registration_payload_fingerprint(),
        diff_fingerprint=_fingerprint(public_diff),
        stable_reason=reason,
    )


async def execute_registration(
    *,
    transport: Any,
    guild_id: str,
    remote_commands: Sequence[Any],
    explicitly_authorized: bool,
    timeout_seconds: float,
) -> RegistrationResult:
    plan = build_registration_plan(remote_commands)
    if plan.state == "REGISTRATION_NOT_REQUIRED":
        return RegistrationResult(
            state=plan.state,
            before_state=plan.before_schema_state,
            after_state=plan.before_schema_state,
            before_route_count=plan.before_route_count,
            after_route_count=plan.before_route_count,
            desired_route_count=plan.desired_route_count,
            authorization_supplied=explicitly_authorized,
            registration_operation_count=0,
            global_registration_count=0,
            post_registration_fetch_count=0,
            payload_fingerprint=plan.payload_fingerprint,
        )
    if plan.state != "REGISTRATION_AUTHORIZATION_REQUIRED":
        return RegistrationResult(
            state=plan.state,
            before_state=plan.before_schema_state,
            after_state="NOT_FETCHED",
            before_route_count=plan.before_route_count,
            after_route_count=0,
            desired_route_count=plan.desired_route_count,
            authorization_supplied=explicitly_authorized,
            registration_operation_count=0,
            global_registration_count=0,
            post_registration_fetch_count=0,
            payload_fingerprint=plan.payload_fingerprint,
            stable_reason=plan.stable_reason,
        )
    if not explicitly_authorized:
        return RegistrationResult(
            state="REGISTRATION_AUTHORIZATION_REQUIRED",
            before_state=plan.before_schema_state,
            after_state="NOT_FETCHED",
            before_route_count=plan.before_route_count,
            after_route_count=0,
            desired_route_count=plan.desired_route_count,
            authorization_supplied=False,
            registration_operation_count=0,
            global_registration_count=0,
            post_registration_fetch_count=0,
            payload_fingerprint=plan.payload_fingerprint,
            stable_reason="STAGE8_REGISTRATION_EXPLICIT_AUTHORIZATION_REQUIRED",
        )
    try:
        returned = await asyncio.wait_for(transport.register_frozen_commands(guild_id), timeout_seconds)
    except (asyncio.TimeoutError, TimeoutError):
        return RegistrationResult(
            state="REGISTRATION_FAILED_TRANSPORT", before_state=plan.before_schema_state,
            after_state="UNCERTAIN", before_route_count=plan.before_route_count, after_route_count=0,
            desired_route_count=plan.desired_route_count, authorization_supplied=True,
            registration_operation_count=1, global_registration_count=0, post_registration_fetch_count=0,
            payload_fingerprint=plan.payload_fingerprint, stable_reason="STAGE8_REGISTRATION_TIMEOUT_UNCERTAIN",
        )
    except Exception:
        return RegistrationResult(
            state="REGISTRATION_FAILED_TRANSPORT", before_state=plan.before_schema_state,
            after_state="UNCERTAIN", before_route_count=plan.before_route_count, after_route_count=0,
            desired_route_count=plan.desired_route_count, authorization_supplied=True,
            registration_operation_count=1, global_registration_count=0, post_registration_fetch_count=0,
            payload_fingerprint=plan.payload_fingerprint, stable_reason="STAGE8_REGISTRATION_TRANSPORT_FAILED",
        )
    returned_plan = build_registration_plan(returned)
    if returned_plan.state != "REGISTRATION_NOT_REQUIRED":
        return RegistrationResult(
            state="REGISTRATION_FAILED_VALIDATION", before_state=plan.before_schema_state,
            after_state=returned_plan.before_schema_state, before_route_count=plan.before_route_count,
            after_route_count=returned_plan.before_route_count, desired_route_count=plan.desired_route_count,
            authorization_supplied=True, registration_operation_count=1, global_registration_count=0,
            post_registration_fetch_count=0, payload_fingerprint=plan.payload_fingerprint,
            stable_reason="STAGE8_REGISTRATION_RESPONSE_SCHEMA_MISMATCH",
        )
    try:
        observed = await asyncio.wait_for(transport.fetch_guild_commands(guild_id), timeout_seconds)
    except Exception:
        return RegistrationResult(
            state="REGISTRATION_FAILED_VALIDATION", before_state=plan.before_schema_state,
            after_state="UNVERIFIED", before_route_count=plan.before_route_count, after_route_count=0,
            desired_route_count=plan.desired_route_count, authorization_supplied=True,
            registration_operation_count=1, global_registration_count=0, post_registration_fetch_count=1,
            payload_fingerprint=plan.payload_fingerprint,
            stable_reason="STAGE8_REGISTRATION_POST_VERIFICATION_FAILED",
        )
    after = build_registration_plan(observed)
    if after.state != "REGISTRATION_NOT_REQUIRED":
        return RegistrationResult(
            state="REGISTRATION_FAILED_VALIDATION", before_state=plan.before_schema_state,
            after_state=after.before_schema_state, before_route_count=plan.before_route_count,
            after_route_count=after.before_route_count, desired_route_count=plan.desired_route_count,
            authorization_supplied=True, registration_operation_count=1, global_registration_count=0,
            post_registration_fetch_count=1, payload_fingerprint=plan.payload_fingerprint,
            stable_reason="STAGE8_REGISTRATION_POST_SCHEMA_MISMATCH",
        )
    return RegistrationResult(
        state="REGISTRATION_COMPLETED", before_state=plan.before_schema_state,
        after_state=after.before_schema_state, before_route_count=plan.before_route_count,
        after_route_count=after.before_route_count, desired_route_count=plan.desired_route_count,
        authorization_supplied=True, registration_operation_count=1, global_registration_count=0,
        post_registration_fetch_count=1, payload_fingerprint=plan.payload_fingerprint,
    )


__all__ = [
    "REGISTRATION_CONTRACT", "REGISTRATION_STATES", "RegistrationPlan", "RegistrationResult",
    "build_registration_plan", "execute_registration", "registration_payload_fingerprint",
]
