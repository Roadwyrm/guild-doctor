"""Structured, deterministic Stage 5 Pass 1 Doctor-case output."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .canonical import canonical_json
from .doctor_query import DOCTOR_QUERY_CONTRACT_VERSION, STAGE5_PASS1_CONTRACT_VERSION, DoctorQuery, thaw
from .doctor_rules import DOCTOR_RULES_VERSION


DOCTOR_CASE_CONTRACT_VERSION = "GUILD-DOCTOR-DOCTOR-CASE-0.1"
DOCTOR_GOLDEN_VERSION = "GUILD-DOCTOR-DOCTOR-GOLDEN-0.1"


def _safe(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _safe(method())
    if isinstance(value, Mapping):
        return {str(key): _safe(child) for key, child in sorted(value.items(), key=lambda item: str(item[0]))}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_safe(child) for child in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _fingerprint(value: Mapping[str, Any]) -> str:
    payload = dict(value)
    payload.pop("case_fingerprint", None)
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class DoctorCase:
    """One immutable answer, including source and integrity provenance."""

    stage5_pass1_contract_version: str
    doctor_query_contract_version: str
    doctor_case_contract_version: str
    doctor_rules_version: str
    doctor_golden_version: str
    query: Mapping[str, Any]
    query_id: str | None
    query_intent: str | None
    target_kind: str | None
    target_key: str | None
    declared_premise: str | None
    premise_alignment: str
    identity: Mapping[str, Any]
    actual_result: Mapping[str, Any]
    diagnostic_answer: Mapping[str, Any]
    explanation: Mapping[str, Any] | None
    provenance: Mapping[str, Any]
    integrity: Mapping[str, Any]
    status: str
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    case_fingerprint: str = ""

    def as_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "stage5_pass1_contract_version": self.stage5_pass1_contract_version,
            "doctor_query_contract_version": self.doctor_query_contract_version,
            "doctor_case_contract_version": self.doctor_case_contract_version,
            "doctor_rules_version": self.doctor_rules_version,
            "doctor_golden_version": self.doctor_golden_version,
            "query": _safe(self.query),
            "query_id": self.query_id,
            "query_intent": self.query_intent,
            "target_kind": self.target_kind,
            "target_key": self.target_key,
            "declared_premise": self.declared_premise,
            "premise_alignment": self.premise_alignment,
            "identity": _safe(self.identity),
            "actual_result": _safe(self.actual_result),
            "diagnostic_answer": _safe(self.diagnostic_answer),
            "explanation": _safe(self.explanation),
            "provenance": _safe(self.provenance),
            "integrity": _safe(self.integrity),
            "status": self.status,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "case_fingerprint": self.case_fingerprint,
        }
        return payload


def build_doctor_case(
    query: DoctorQuery,
    *,
    premise_alignment: str,
    actual_result: Mapping[str, Any],
    diagnostic_answer: Mapping[str, Any],
    explanation: Mapping[str, Any] | None,
    provenance: Mapping[str, Any],
    integrity: Mapping[str, Any],
    status: str = "PASS",
    errors: tuple[str, ...] = (),
    warnings: tuple[str, ...] = (),
) -> DoctorCase:
    """Create a case and compute its stable fingerprint from canonical JSON."""

    query_payload = query.as_dict(include_source=True)
    identity = {
        "guild_id": query.guild_id,
        "subject_id": query.subject_id,
        "actor_id": query.actor_id,
        "target_type": query.target_type,
        "target_id": query.target_id,
        "context_type": query.context_type,
        "context_id": query.context_id,
        "parent_id": query.parent_id,
        "thread_type": query.thread_type,
        "thread_id": query.thread_id,
    }
    draft = DoctorCase(
        stage5_pass1_contract_version=STAGE5_PASS1_CONTRACT_VERSION,
        doctor_query_contract_version=DOCTOR_QUERY_CONTRACT_VERSION,
        doctor_case_contract_version=DOCTOR_CASE_CONTRACT_VERSION,
        doctor_rules_version=DOCTOR_RULES_VERSION,
        doctor_golden_version=DOCTOR_GOLDEN_VERSION,
        query=query_payload,
        query_id=query.query_id,
        query_intent=query.query_intent,
        target_kind=query.target_kind,
        target_key=query.target_key,
        declared_premise=query.query_intent,
        premise_alignment=premise_alignment,
        identity=identity,
        actual_result=actual_result,
        diagnostic_answer=diagnostic_answer,
        explanation=explanation,
        provenance=provenance,
        integrity=integrity,
        status=status,
        errors=tuple(errors),
        warnings=tuple(warnings),
        case_fingerprint="",
    )
    fingerprint = _fingerprint(draft.as_dict())
    return DoctorCase(**{**draft.__dict__, "case_fingerprint": fingerprint}) if hasattr(draft, "__dict__") else DoctorCase(
        stage5_pass1_contract_version=draft.stage5_pass1_contract_version,
        doctor_query_contract_version=draft.doctor_query_contract_version,
        doctor_case_contract_version=draft.doctor_case_contract_version,
        doctor_rules_version=draft.doctor_rules_version,
        doctor_golden_version=draft.doctor_golden_version,
        query=draft.query,
        query_id=draft.query_id,
        query_intent=draft.query_intent,
        target_kind=draft.target_kind,
        target_key=draft.target_key,
        declared_premise=draft.declared_premise,
        premise_alignment=draft.premise_alignment,
        identity=draft.identity,
        actual_result=draft.actual_result,
        diagnostic_answer=draft.diagnostic_answer,
        explanation=draft.explanation,
        provenance=draft.provenance,
        integrity=draft.integrity,
        status=draft.status,
        errors=draft.errors,
        warnings=draft.warnings,
        case_fingerprint=fingerprint,
    )


__all__ = [
    "DOCTOR_CASE_CONTRACT_VERSION",
    "DOCTOR_GOLDEN_VERSION",
    "DoctorCase",
    "build_doctor_case",
]
