"""Pure Stage 4 closure assessment for the local runtime surface."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


STAGE4_CLOSURE_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE4-CLOSURE-0.1"
STAGE4_CLOSURE_DECISION_COMPLETE = "STAGE4_COMPLETE"
STAGE4_CLOSURE_DECISION_PENDING = "STAGE4_IN_PROGRESS"
STAGE4_CLOSURE_DECISION_INCOMPLETE = "STAGE4_INCOMPLETE"


_REQUIRED_CHECKS = (
    "canonical_environment",
    "complete_test_suite",
    "clean_wheel",
    "console_compatibility",
    "evidence_integrity",
    "live_derived_runtime",
    "read_only_audit",
    "runtime_golden",
    "source_pack",
)


def assess_stage4_closure(checks: Mapping[str, Any]) -> dict[str, Any]:
    """Return a deterministic closure decision from explicit local gate results."""

    normalized = {str(key): value for key, value in checks.items()}
    closure_checks: dict[str, bool] = {}
    blockers: list[str] = []
    for name in _REQUIRED_CHECKS:
        value = normalized.get(name)
        passed = value is True or (isinstance(value, Mapping) and str(value.get("status", "")).upper() == "PASS")
        closure_checks[name] = bool(passed)
        if not passed:
            blockers.append(f"CHECK_FAILED:{name}")
    if normalized.get("future_stage_started") is True:
        blockers.append("SCOPE_FENCE_BREACH:FUTURE_STAGE_STARTED")
    if normalized.get("discord_write_requests", 0) != 0:
        blockers.append("SCOPE_FENCE_BREACH:DISCORD_WRITE_REQUESTS")
    if normalized.get("network_contacted", False) is True:
        blockers.append("SCOPE_FENCE_BREACH:NETWORK_CONTACTED")
    if normalized.get("source_markdown_file_count") != 25:
        blockers.append("SOURCE_PACK_FILE_COUNT_NOT_25")
    if normalized.get("live_derived_presentation_count") != 18:
        blockers.append("LIVE_DERIVED_PRESENTATION_COUNT_NOT_18")
    if normalized.get("token_disclosure_status") != "PASS_NO_TOKEN_INPUT":
        blockers.append("TOKEN_DISCLOSURE_NOT_PROVEN")
    blockers = sorted(set(blockers))
    all_passed = not blockers and all(closure_checks.values())
    decision = STAGE4_CLOSURE_DECISION_COMPLETE if all_passed else STAGE4_CLOSURE_DECISION_PENDING
    status = "PASS" if all_passed else "PENDING"
    limitations = [
        "The runtime is local and read-only; it does not invoke Discord, Gateway, commands, interactions, or write operations.",
        "The live-derived explanation set is derived from retained Stage 3 evidence and preserves its modeled/partial/unknown meaning.",
        "Discord presentation is exercised locally as safe Markdown only; no live Discord display is claimed.",
    ]
    return {
        "contract": STAGE4_CLOSURE_CONTRACT_VERSION,
        "decision": decision,
        "status": status,
        "stage4_pass4_complete": all_passed,
        "closure_checks": closure_checks,
        "successful_evidence": sorted(name for name, passed in closure_checks.items() if passed),
        "concrete_blockers": blockers,
        "accepted_limitations": limitations,
        "verification_backlog_count": len(blockers),
        "verification_backlog": [{"backlog_id": f"STAGE4-PASS4-{index:03d}", "status": "OPEN", "blocker": blocker} for index, blocker in enumerate(blockers, start=1)],
        "runtime_contract_version": normalized.get("runtime_contract_version"),
        "source_markdown_file_count": normalized.get("source_markdown_file_count"),
        "live_derived_presentation_count": normalized.get("live_derived_presentation_count"),
        "canonical_environment": normalized.get("canonical_environment"),
        "package_version": normalized.get("package_version", "0.5.1"),
        "token_disclosure_status": normalized.get("token_disclosure_status"),
        "network_contacted": normalized.get("network_contacted", False),
        "discord_write_requests": normalized.get("discord_write_requests", 0),
    }


def verification_backlog(assessment: Mapping[str, Any]) -> dict[str, Any]:
    blockers = assessment.get("concrete_blockers", [])
    return {
        "contract": STAGE4_CLOSURE_CONTRACT_VERSION,
        "stage": "STAGE4_PASS4",
        "status": "CLEAR" if not blockers else "OPEN",
        "items": list(assessment.get("verification_backlog", [])),
        "count": len(blockers) if isinstance(blockers, list) else 0,
    }


__all__ = [
    "STAGE4_CLOSURE_CONTRACT_VERSION", "STAGE4_CLOSURE_DECISION_COMPLETE",
    "STAGE4_CLOSURE_DECISION_INCOMPLETE", "STAGE4_CLOSURE_DECISION_PENDING",
    "assess_stage4_closure", "verification_backlog",
]
