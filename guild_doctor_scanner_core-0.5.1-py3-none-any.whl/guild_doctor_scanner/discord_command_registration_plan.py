"""Phased local plan; sync phases are explicitly not authorized."""
REGISTRATION_PLAN_CONTRACT="GUILD-DOCTOR-DISCORD-REGISTRATION-PLAN-0.1"
REGISTRATION_PLAN=({"phase":"LOCAL_MANIFEST_GENERATION","authorized":True},{"phase":"SCHEMA_VALIDATION","authorized":True},{"phase":"DRY_RUN_REGISTRATION_SIMULATION","authorized":True},{"phase":"DISPOSABLE_GUILD_SYNCHRONIZATION","authorized":False},{"phase":"DISPOSABLE_GUILD_VERIFICATION","authorized":False},{"phase":"ROLLBACK","authorized":False},{"phase":"PRODUCTION_SYNCHRONIZATION","authorized":False})
