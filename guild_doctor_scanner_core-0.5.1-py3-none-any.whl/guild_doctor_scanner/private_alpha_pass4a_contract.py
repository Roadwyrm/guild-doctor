"""Pure Stage 8 Pass 4A workflow and interaction-boundary design contracts.

This module performs no I/O and imports no Discord runtime.  It derives command
options and command-level presentation flags from the frozen manifest.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from types import MappingProxyType
from typing import Any, Mapping

from .discord_command_manifest import COMMAND_MANIFEST, manifest_fingerprint
from .discord_command_schema import schema_fingerprint
from .discord_engine_routing_contract import ROUTES


PASS4A_WORKFLOW_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4A-WORKFLOW-INTERACTION-DESIGN-0.1"
INTERACTION_VALIDATION_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-INTERACTION-VALIDATION-0.1"
TRANSPORT_BOUNDARY_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-INTERACTION-TRANSPORT-BOUNDARY-0.1"

COMMON_ERRORS = (
    "STAGE6_DM_NOT_SUPPORTED",
    "STAGE6_OWNER_ONLY",
    "STAGE6_GUILD_UNAVAILABLE",
    "STAGE6_OWNER_UNRESOLVED",
    "STAGE6_SNAPSHOT_MISSING",
    "STAGE6_SNAPSHOT_STALE",
    "STAGE6_SNAPSHOT_PARTIAL",
    "STAGE6_SNAPSHOT_SCHEMA_MISMATCH",
    "STAGE6_OBJECT_STALE",
    "STAGE6_INTERACTION_TIMEOUT",
    "STAGE6_ENGINE_INTERNAL_ERROR",
)

_ROUTE_POLICY = MappingProxyType({
    "why-can": ("CURRENT_NORMALIZED_SNAPSHOT_PLUS_EXACT_SELECTED_MEMBER", "PERMISSION_RESULT_OR_ERROR_RESULT", ("STAGE6_MEMBER_DATA_REQUIRED", "STAGE6_MEMBER_NOT_FOUND", "STAGE6_CHANNEL_NOT_FOUND"), "CONDITIONAL_ONE_EXACT_TARGETED_MEMBER_GET"),
    "why-cannot": ("CURRENT_NORMALIZED_SNAPSHOT_PLUS_EXACT_SELECTED_MEMBER", "PERMISSION_RESULT_OR_ERROR_RESULT", ("STAGE6_MEMBER_DATA_REQUIRED", "STAGE6_MEMBER_NOT_FOUND", "STAGE6_CHANNEL_NOT_FOUND"), "CONDITIONAL_ONE_EXACT_TARGETED_MEMBER_GET"),
    "who-can": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_COMPLETE_MEMBER_POPULATION", "PERMISSION_RESULT_OR_ERROR_RESULT", ("STAGE6_POPULATION_INCOMPLETE", "STAGE6_CHANNEL_NOT_FOUND", "STAGE6_PERMISSION_UNKNOWN"), "NO_BROAD_MEMBER_GET_RETURN_INCOMPLETE"),
    "who-cannot": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_COMPLETE_MEMBER_POPULATION", "PERMISSION_RESULT_OR_ERROR_RESULT", ("STAGE6_POPULATION_INCOMPLETE", "STAGE6_CHANNEL_NOT_FOUND", "STAGE6_PERMISSION_UNKNOWN"), "NO_BROAD_MEMBER_GET_RETURN_INCOMPLETE"),
    "who-unknown": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_COMPLETE_MEMBER_POPULATION", "PERMISSION_RESULT_OR_ERROR_RESULT", ("STAGE6_POPULATION_INCOMPLETE", "STAGE6_CHANNEL_NOT_FOUND", "STAGE6_PERMISSION_UNKNOWN"), "NO_BROAD_MEMBER_GET_RETURN_INCOMPLETE"),
    "find-setting": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_CHANNEL_GRAPH", "PERMISSION_RESULT_OR_ERROR_RESULT", ("STAGE6_CHANNEL_NOT_FOUND", "STAGE6_PERMISSION_UNKNOWN", "STAGE6_FROZEN_PROJECTION_UNAVAILABLE"), "NO_DISCORD_GET_FROM_VALIDATED_SNAPSHOT"),
    "explain-role": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_ROLE_GRAPH", "PERMISSION_RESULT_OR_ERROR_RESULT", ("STAGE6_ROLE_NOT_FOUND", "STAGE6_FROZEN_PROJECTION_UNAVAILABLE"), "NO_DISCORD_GET_FROM_VALIDATED_SNAPSHOT"),
    "explain-category": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_CATEGORY_GRAPH", "PERMISSION_RESULT_OR_ERROR_RESULT", ("STAGE6_CATEGORY_NOT_FOUND", "STAGE6_FROZEN_PROJECTION_UNAVAILABLE"), "NO_DISCORD_GET_FROM_VALIDATED_SNAPSHOT"),
    "explain-channel": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_CHANNEL_GRAPH", "PERMISSION_RESULT_OR_ERROR_RESULT", ("STAGE6_CHANNEL_NOT_FOUND", "STAGE6_FROZEN_PROJECTION_UNAVAILABLE"), "NO_DISCORD_GET_FROM_VALIDATED_SNAPSHOT"),
    "compare-role-permission": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_TWO_EXACT_ROLES", "COMPARISON_RESULT_OR_ERROR_RESULT", ("STAGE6_ROLE_NOT_FOUND", "STAGE6_PERMISSION_UNKNOWN", "STAGE6_COMPARISON_PAYLOAD_INVALID"), "NO_DISCORD_GET_FROM_VALIDATED_SNAPSHOT"),
    "compare-role-capability": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_TWO_EXACT_ROLES", "COMPARISON_RESULT_OR_ERROR_RESULT", ("STAGE6_ROLE_NOT_FOUND", "STAGE6_CAPABILITY_UNKNOWN", "STAGE6_COMPARISON_PAYLOAD_INVALID"), "NO_DISCORD_GET_FROM_VALIDATED_SNAPSHOT"),
    "compare-role-action": ("CURRENT_NORMALIZED_SNAPSHOT_WITH_TWO_EXACT_ROLES_AND_FROZEN_ACTION_CONTEXT", "COMPARISON_RESULT_OR_ERROR_RESULT", ("STAGE6_ROLE_NOT_FOUND", "STAGE6_ACTION_UNKNOWN", "STAGE6_ACTION_CONTEXT_REQUIRED"), "NO_DISCORD_GET_FROM_VALIDATED_SNAPSHOT"),
    "server-report": ("VALIDATED_ASSEMBLED_REPORT_FROM_COMPATIBLE_SNAPSHOT_AND_ATLAS", "REPORT_RESULT_OR_ERROR_RESULT", ("REPORT_UNAVAILABLE", "REPORT_CONTRACT_INVALID", "REPORT_PRIVACY_FAILED", "REPORT_SNAPSHOT_INCOMPATIBLE"), "NO_DISCORD_GET_FROM_VALIDATED_LOCAL_REPORT"),
})


@dataclass(frozen=True, slots=True)
class WorkflowRoute:
    command_name: str
    required_options: tuple[str, ...]
    optional_options: tuple[str, ...]
    expected_actor_context: str
    expected_guild_context: str
    required_snapshot_or_acquisition_inputs: str
    route_adapter: str
    domain_route: str
    expected_envelope_branch: str
    expected_pagination_behavior: str
    expected_export_behavior: str
    expected_error_states: tuple[str, ...]
    privacy_classification: str
    discord_get_requirement: str
    discord_response_operation_requirement: str
    offline_user_execution_validation: str
    live_validation_requires_new_authorized_boundary: bool

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def build_workflow_matrix() -> tuple[WorkflowRoute, ...]:
    rows: list[WorkflowRoute] = []
    for command in COMMAND_MANIFEST:
        policy = _ROUTE_POLICY[command.key]
        required = tuple(option.name for option in command.options if option.required)
        optional = tuple(option.name for option in command.options if not option.required)
        is_report = command.key == "server-report"
        rows.append(WorkflowRoute(
            command_name=command.key,
            required_options=required,
            optional_options=optional,
            expected_actor_context="EXACT_AUTHENTICATED_GUILD_OWNER",
            expected_guild_context="EXACT_LOCALLY_ALLOWLISTED_GUILD_NOT_DM",
            required_snapshot_or_acquisition_inputs=policy[0],
            route_adapter="report_interaction_adapter" if is_report else "discord_direct_interaction_adapter",
            domain_route="STAGE7_REPORT_PRESENTATION" if is_report else ROUTES[command.key],
            expected_envelope_branch=policy[1],
            expected_pagination_behavior="DETERMINISTIC_PRIVATE_PAGES" if command.pagination else "SINGLE_PRIVATE_RESPONSE",
            expected_export_behavior="EXPLICIT_OWNER_LOCAL_PREPARATION_ONLY" if command.export else "NO_EXPORT_FROM_COMMAND",
            expected_error_states=tuple(dict.fromkeys((*COMMON_ERRORS, *policy[2]))),
            privacy_classification="OWNER_ONLY_EPHEMERAL_PRIVATE_NO_RAW_IDENTIFIERS",
            discord_get_requirement=policy[3],
            discord_response_operation_requirement=(
                "DEFER_EPHEMERAL_THEN_FOLLOWUP_EPHEMERAL" if command.acknowledgement == "DEFER_EPHEMERAL"
                else "INITIAL_EPHEMERAL_RESPONSE"
            ),
            offline_user_execution_validation="SUPPORTED_WITH_FICTIONAL_OR_SANITIZED_INPUTS",
            live_validation_requires_new_authorized_boundary=True,
        ))
    return tuple(rows)


TRANSPORT_ASSESSMENT = MappingProxyType({
    "discord_gateway_interaction_delivery": "HISTORICAL_STAGE6_DISPOSABLE_RUNTIME_EXISTS_NOT_AUTHORIZED_FOR_STAGE8_PASS4",
    "discord_http_interaction_endpoint_delivery": "NOT_IMPLEMENTED_AND_NOT_AUTHORIZED",
    "rest_only_outbound_discord_operations": "IMPLEMENTED_FOR_BOUNDED_PASS3_VERIFICATION_NOT_AN_INBOUND_INTERACTION_PATH",
    "offline_interaction_envelope_simulation": "IMPLEMENTED_AND_AUTHORIZED_FOR_PASS4A_VALIDATION",
    "current_authoritative_inbound_transport": "NONE",
    "live_interaction_readiness": "BLOCKED_NO_AUTHORIZED_INBOUND_INTERACTION_TRANSPORT",
})

RESPONSE_OPERATION_CLASSIFICATION = MappingProxyType({
    "INITIAL_RESPONSE_SEND": ("DISCORD_INTERACTION_WRITE", "PRESENTATION_ONLY_NOT_GUILD_MUTATION", "NOT_AUTHORIZED_PASS4A"),
    "DEFER_RESPONSE": ("DISCORD_INTERACTION_WRITE", "PRESENTATION_ONLY_NOT_GUILD_MUTATION", "NOT_AUTHORIZED_PASS4A"),
    "EDIT_ORIGINAL_RESPONSE": ("DISCORD_INTERACTION_WRITE", "PRESENTATION_ONLY_NOT_GUILD_MUTATION", "NOT_AUTHORIZED_PASS4A"),
    "FOLLOWUP_RESPONSE": ("DISCORD_INTERACTION_WRITE", "PRESENTATION_ONLY_NOT_GUILD_MUTATION", "NOT_AUTHORIZED_PASS4A"),
    "COMPONENT_OR_PAGE_UPDATE": ("DISCORD_INTERACTION_WRITE", "PRESENTATION_ONLY_NOT_GUILD_MUTATION", "NOT_AUTHORIZED_PASS4A"),
    "LOCAL_PAGE_GENERATION": ("LOCAL_PURE_OPERATION", "NO_DISCORD_WRITE", "AUTHORIZED_OFFLINE"),
    "LOCAL_EXPORT_PREPARATION": ("LOCAL_FILESYSTEM_OPERATION", "NO_DISCORD_WRITE", "EXPLICIT_OWNER_LOCAL_ONLY"),
    "REPORT_ATTACHMENT_DELIVERY": ("DISCORD_INTERACTION_WRITE", "PROHIBITED_BY_STAGE8_PASS1", "PROHIBITED"),
})

FAIL_CLOSED_CRITERIA = (
    "NO_AUTHORITATIVE_INBOUND_INTERACTION_TRANSPORT",
    "UNCLEAR_RESPONSE_OPERATION_AUTHORIZATION",
    "ROUTE_OR_COMMAND_SCHEMA_MISMATCH",
    "OWNER_AUTHORIZATION_AMBIGUITY",
    "GUILD_ALLOWLIST_AMBIGUITY",
    "MISSING_ACTIVE_NORMALIZED_SNAPSHOT_PATH",
    "RESPONSE_NOT_GUARANTEED_EPHEMERAL",
    "PRIVACY_UNSAFE_EVIDENCE",
    "UNEXPECTED_DISCORD_ENDPOINT_REQUIREMENT",
    "GATEWAY_REQUIREMENT_WITHOUT_EXPLICIT_APPROVAL",
    "SERVER_OBJECT_MUTATION_REACHABILITY",
    "TOKEN_OUTSIDE_PROCESS_ENVIRONMENT_BOUNDARY",
)

VALIDATION_PLAN = (
    "PURE_OFFLINE_WORKFLOW_TESTS_ALL_13_ROUTES",
    "GUILD_ALLOWLIST_OWNER_DM_AND_NON_OWNER_DENIAL_TESTS",
    "MALFORMED_AND_WRONG_TYPE_OPTION_TESTS",
    "MISSING_STALE_PARTIAL_AND_SCHEMA_MISMATCH_SNAPSHOT_TESTS",
    "UNKNOWN_NOT_APPLICABLE_INCOMPLETE_AND_UNCERTAINTY_PRESERVATION_TESTS",
    "FOUR_BRANCH_ENVELOPE_DISCRIMINATION_TESTS",
    "SAFE_RENDERER_AND_CLASSIFIED_ERROR_TESTS",
    "DETERMINISTIC_PAGINATION_TESTS",
    "LOCAL_EXPORT_AND_RECEIPT_VALIDATION_TESTS",
    "PRIVACY_PROVENANCE_AND_IDENTIFIER_PSEUDONYMIZATION_TESTS",
    "CONCURRENCY_REPLAY_IDEMPOTENCY_AND_CANCELLATION_TESTS",
    "SEPARATELY_AUTHORIZED_BOUNDED_OWNER_LIVE_INTERACTION_TESTS",
)

LIVE_TEST_LIMIT = MappingProxyType({
    "maximum_command_invocations": 4,
    "required_route_classes": ("ONE_DIRECT_RESULT", "ONE_FAIL_CLOSED", "ONE_COMPARISON_RESULT", "ONE_REPORT_OR_REPORT_REFUSAL"),
    "required_visibility": "EPHEMERAL",
    "response_writes_require_separate_authorization": True,
    "gateway_or_http_transport_requires_separate_authorization": True,
    "cleanup": "CLOSE_TRANSPORT_CLEAR_SECRET_NO_RECONNECT",
    "evidence": "SANITIZED_STATES_COUNTS_FINGERPRINTS_ONLY",
    "stop_conditions": FAIL_CLOSED_CRITERIA,
})


def contract_fingerprint() -> str:
    payload = {
        "workflow_contract": PASS4A_WORKFLOW_CONTRACT,
        "validation_contract": INTERACTION_VALIDATION_CONTRACT,
        "transport_contract": TRANSPORT_BOUNDARY_CONTRACT,
        "manifest_fingerprint": manifest_fingerprint(),
        "schema_fingerprint": schema_fingerprint(),
        "routes": [row.as_dict() for row in build_workflow_matrix()],
        "transport": dict(TRANSPORT_ASSESSMENT),
        "response_operations": dict(RESPONSE_OPERATION_CLASSIFICATION),
        "fail_closed": FAIL_CLOSED_CRITERIA,
        "validation_plan": VALIDATION_PLAN,
        "live_test_limit": dict(LIVE_TEST_LIMIT),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=list).encode()).hexdigest()


def validate_contract() -> tuple[str, ...]:
    errors: list[str] = []
    rows = build_workflow_matrix()
    manifest_keys = tuple(command.key for command in COMMAND_MANIFEST)
    if len(rows) != 13 or tuple(row.command_name for row in rows) != manifest_keys:
        errors.append("STAGE8_PASS4A_ROUTE_MATRIX_MISMATCH")
    if set(_ROUTE_POLICY) != set(manifest_keys):
        errors.append("STAGE8_PASS4A_ROUTE_POLICY_MISMATCH")
    if any(row.privacy_classification != "OWNER_ONLY_EPHEMERAL_PRIVATE_NO_RAW_IDENTIFIERS" for row in rows):
        errors.append("STAGE8_PASS4A_PRIVACY_POLICY_MISMATCH")
    if any(not row.live_validation_requires_new_authorized_boundary for row in rows):
        errors.append("STAGE8_PASS4A_LIVE_BOUNDARY_MISSING")
    if TRANSPORT_ASSESSMENT["current_authoritative_inbound_transport"] != "NONE":
        errors.append("STAGE8_PASS4A_INBOUND_TRANSPORT_UNEXPECTED")
    if any(value[2] == "AUTHORIZED_PASS4A" for value in RESPONSE_OPERATION_CLASSIFICATION.values()):
        errors.append("STAGE8_PASS4A_RESPONSE_WRITE_AUTHORIZED")
    return tuple(errors)


__all__ = [
    "FAIL_CLOSED_CRITERIA", "INTERACTION_VALIDATION_CONTRACT", "LIVE_TEST_LIMIT",
    "PASS4A_WORKFLOW_CONTRACT", "RESPONSE_OPERATION_CLASSIFICATION", "TRANSPORT_ASSESSMENT",
    "TRANSPORT_BOUNDARY_CONTRACT", "VALIDATION_PLAN", "WorkflowRoute", "build_workflow_matrix",
    "contract_fingerprint", "validate_contract",
]
