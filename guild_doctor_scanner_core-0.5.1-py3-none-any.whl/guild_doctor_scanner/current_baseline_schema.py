"""Contracts and fail-closed validation for Stage 5 current baselines."""

from __future__ import annotations

import hashlib
import re
import traceback
from collections.abc import Mapping, Sequence
from typing import Any

from .canonical import canonical_json
from .scenario_manifest import LiveScenario


CURRENT_BASELINE_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE5-CURRENT-BASELINE-0.1"
GET_ONLY_ACQUISITION_CONTRACT_VERSION = "GUILD-DOCTOR-GET-ONLY-ACQUISITION-0.1"
PRIVACY_SAFE_BASELINE_CONTRACT_VERSION = "GUILD-DOCTOR-PRIVACY-SAFE-BASELINE-0.1"
CURRENT_BASELINE_REPLAY_CONTRACT_VERSION = "GUILD-DOCTOR-CURRENT-BASELINE-REPLAY-0.1"

CONFIRMATION_PHRASE = "GET_ONLY_CURRENT_BASELINE"
MFA_STATES = frozenset(
    {
        "PRESENT",
        "ABSENT",
        "UNKNOWN_NOT_EXPOSED",
        "UNKNOWN_ACQUISITION_FAILED",
        "NOT_APPLICABLE",
    }
)
REPLAY_STATUSES = frozenset(
    {
        "EXACT_CURRENT_BASELINE_REPLAY",
        "CURRENT_BASELINE_REPLAY_MISMATCH",
        "CURRENT_BASELINE_INSUFFICIENT",
        "CURRENT_BASELINE_UNSUPPORTED",
        "CURRENT_BASELINE_ACQUISITION_FAILED",
        "INVALID_CURRENT_BASELINE_CAPSULE",
    }
)
ALLOWED_OPERATIONS = frozenset({"member.timeout", "role.edit", "channel.manage"})
EXPECTED_TARGETS = {"member.timeout": "MEMBER", "role.edit": "ROLE", "channel.manage": "CHANNEL"}
TOKEN_RE = re.compile(r"(?i)(?:bot\s+)?[a-z0-9_-]{16,}\.[a-z0-9_-]{4,}\.[a-z0-9_-]{8,}")
REAL_SNOWFLAKE_RE = re.compile(r"(?<!\d)[1-8]\d{14,21}(?!\d)")
SYMBOLIC_SYNTHETIC_ID_RE = re.compile(r"^gd:(guild|role|member|channel|category|thread|object):[a-z][a-z0-9-]{1,63}$")
SYNTHETIC_ID_VERSION = "GUILD-DOCTOR-SYNTH-ID-0.1"
SYNTHETIC_ID_NAMESPACE = "GUILD_DOCTOR_REPLAY"
_IDENTIFIER_KEYS = frozenset({"id", "guild_id", "owner_id", "parent_id", "user_id", "bot_id", "integration_id", "subscription_listing_id", "actor_member_id", "target_id", "context_id", "thread_id"})
_IDENTIFIER_LIST_KEYS = frozenset({"roles", "role_ids", "applied_tags"})
_NON_IDENTIFIER_ID_KEYS = frozenset({"scenario_id", "query_id", "workflow_id", "batch_id", "snapshot_id"})
TRACEBACK_REFERENCE_BASIS_VERSION = "GUILD-DOCTOR-TRACEBACK-STRUCTURAL-0.1"


class CurrentBaselineError(ValueError):
    """Raised when the bounded acquisition or capsule contract is invalid."""


class CurrentBaselineFailure(CurrentBaselineError):
    """A sanitized, structured failure after readiness or transport."""

    def __init__(self, diagnostic: Mapping[str, Any], *, cause: BaseException | None = None) -> None:
        self.diagnostic = dict(diagnostic)
        self.cause_type = type(cause).__name__ if cause is not None else None
        code = str(self.diagnostic.get("stable_error_code", "CURRENT_BASELINE_FAILURE"))
        super().__init__(code + " (credential)" if "CREDENTIAL" in code else code)


def _shape(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "BOOLEAN"
    if isinstance(value, int):
        return "INTEGER"
    if isinstance(value, str):
        return "DECIMAL_STRING" if value.isdecimal() else "STRING"
    if isinstance(value, Mapping):
        return "OBJECT"
    if isinstance(value, (list, tuple)):
        return "ARRAY"
    return type(value).__name__.upper()


def _safe_frame_signature(exc: BaseException | None) -> list[str]:
    """Return stack identifiers without messages, values, or absolute paths."""
    if exc is None or exc.__traceback__ is None:
        return []
    return [
        f"{traceback.FrameSummary(frame.filename, frame.lineno, frame.name).filename.rsplit('\\\\', 1)[-1].rsplit('/', 1)[-1]}:{frame.name}:{frame.lineno}"
        for frame in traceback.extract_tb(exc.__traceback__)
    ]


def _diagnostic_from_chain(exc: BaseException | None) -> Mapping[str, Any] | None:
    seen: set[int] = set()
    current = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        diagnostic = getattr(current, "diagnostic", None)
        if isinstance(diagnostic, Mapping):
            return diagnostic
        current = current.__cause__ or current.__context__
    return None


def _chain_signature(exc: BaseException | None) -> tuple[list[str], int]:
    frames: list[str] = []
    depth = 0
    seen: set[int] = set()
    current = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        depth += 1
        frames.extend(_safe_frame_signature(current))
        current = current.__cause__ or current.__context__
    return frames, depth


def diagnostic_failure(
    *,
    failure_stage: str,
    stable_error_code: str,
    validation_rule: str,
    object_type: str,
    field_path: str | None = None,
    scenario_id: str | None = None,
    expected_shape: str = "JSON value accepted by the frozen contract",
    observed_value: Any = None,
    missing_required_fields: tuple[str, ...] = (),
    contradictory_fields: tuple[str, ...] = (),
    cause: BaseException | None = None,
    transport_completed: bool = True,
    transport_request_count: int = 0,
) -> CurrentBaselineFailure:
    """Build a public-safe failure record without copying exception text or payloads."""

    inner = _diagnostic_from_chain(cause)
    frames, chain_depth = _chain_signature(cause)
    structural_signature = {
        "basis_version": TRACEBACK_REFERENCE_BASIS_VERSION,
        "failure_stage": failure_stage,
        "stable_error_code": stable_error_code,
        "validation_rule": validation_rule,
        "object_type": object_type,
        "field_path": field_path,
        "scenario_id": scenario_id,
        "exception_class": type(cause).__name__ if cause is not None else "CurrentBaselineFailure",
        "stack": frames,
    }
    reference_material = canonical_json(structural_signature)
    inner_available = cause is not None or inner is not None
    inner = inner or {}
    diagnostic = {
        "code": stable_error_code,
        "error_type": type(cause).__name__ if cause is not None else "CurrentBaselineFailure",
        "failure_stage": failure_stage,
        "stable_error_code": stable_error_code,
        "validation_rule": validation_rule,
        "object_type": object_type,
        "scenario_id": scenario_id,
        "field_path": field_path,
        "expected_shape": expected_shape,
        "observed_shape_category": _shape(observed_value),
        "missing_required_fields": list(missing_required_fields),
        "contradictory_fields": list(contradictory_fields),
        "sanitized_exception_type": type(cause).__name__ if cause is not None else None,
        "sanitized_message": stable_error_code,
        "traceback_reference": "sha256:" + hashlib.sha256(reference_material.encode("utf-8")).hexdigest(),
        "traceback_reference_basis_version": TRACEBACK_REFERENCE_BASIS_VERSION,
        "exception_chain_depth": chain_depth,
        "causal_reference": "sha256:" + hashlib.sha256(reference_material.encode("utf-8")).hexdigest(),
        "inner_failure_available": inner_available,
        "inner_failure_preserved": inner_available,
        "inner_stable_error_code": inner.get("stable_error_code", stable_error_code if inner_available else None),
        "inner_failure_stage": inner.get("failure_stage", failure_stage if inner_available else None),
        "inner_field_path": inner.get("field_path", field_path if inner_available else None),
        "inner_scenario_id": inner.get("scenario_id", scenario_id if inner_available else None),
        "inner_object_type": inner.get("object_type", object_type if inner_available else None),
        "inner_validation_rule": inner.get("validation_rule", validation_rule if inner_available else None),
        "inner_expected_shape": inner.get("expected_shape", expected_shape if inner_available else None),
        "inner_observed_shape_category": inner.get("observed_shape_category", _shape(observed_value) if inner_available else None),
        "safe_relationship_metadata": {
            "missing_required_fields": list(inner.get("missing_required_fields", missing_required_fields)),
            "contradictory_fields": list(inner.get("contradictory_fields", contradictory_fields)),
        },
        "transport_completed": transport_completed,
        "transport_request_count": transport_request_count,
        "raw_payload_retained": False,
        "token_redacted": True,
        "discord_write_requests": 0,
    }
    return CurrentBaselineFailure(diagnostic, cause=cause)


def fingerprint(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def contains_credential(value: Any) -> bool:
    if isinstance(value, Mapping):
        return any(str(key).lower() in {"token", "authorization", "access_token", "discord_token"} or contains_credential(item) for key, item in value.items())
    if isinstance(value, (list, tuple)):
        return any(contains_credential(item) for item in value)
    return isinstance(value, str) and bool(TOKEN_RE.search(value))


def identifier_privacy_findings(value: Any, *, path: str = "capsule", key: str = "", relationship_role: str | None = None) -> list[dict[str, Any]]:
    """Find only identifier-shaped leakage, never return identifier values."""
    findings: list[dict[str, Any]] = []
    if isinstance(value, Mapping):
        for child_key, child_value in value.items():
            text_key = str(child_key)
            child_path = f"{path}.{text_key}"
            role = relationship_role
            if text_key == "id":
                role = {"guild": "GUILD", "roles": "ROLE", "channels": "CHANNEL", "members": "MEMBER"}.get(path.rsplit(".", 1)[-1], role)
            findings.extend(identifier_privacy_findings(child_value, path=child_path, key=text_key, relationship_role=role))
        return findings
    if isinstance(value, (list, tuple)):
        for index, child_value in enumerate(value):
            findings.extend(identifier_privacy_findings(child_value, path=f"{path}[{index}]", key=key, relationship_role=relationship_role))
        return findings
    strict_identifier = key not in _NON_IDENTIFIER_ID_KEYS and (key in _IDENTIFIER_KEYS or key.endswith("_id") or key in _IDENTIFIER_LIST_KEYS)
    if not strict_identifier or value is None:
        return findings
    text = str(value)
    snowflake_shaped = bool(REAL_SNOWFLAKE_RE.fullmatch(text))
    symbolic = bool(SYMBOLIC_SYNTHETIC_ID_RE.fullmatch(text))
    if snowflake_shaped or not symbolic:
        findings.append({
            "field_path": path,
            "object_type": "SYNTHETIC_IDENTIFIER",
            "synthetic_namespace_class": text.split(":", 2)[1].upper() if symbolic else "INVALID",
            "length_category": "LONG" if len(text) >= 15 else "SHORT",
            "character_category": "DECIMAL_ONLY" if text.isdecimal() else "SYMBOLIC_OR_OTHER",
            "decimal_only": text.isdecimal(),
            "discord_snowflake_shaped": snowflake_shaped,
            "relationship_role": relationship_role or "REFERENCE",
        })
    return findings


def validate_baseline_scenarios(scenarios: Sequence[LiveScenario]) -> tuple[str, ...]:
    errors: list[str] = []
    if len(scenarios) != 3:
        errors.append("CURRENT_BASELINE_REQUIRES_EXACTLY_THREE_SCENARIOS")
    seen: set[str] = set()
    guilds = {item.guild_id for item in scenarios}
    actors = {item.actor_member_id for item in scenarios}
    if len(guilds) != 1:
        errors.append("SCENARIOS_MUST_SHARE_ONE_GUILD")
    if len(actors) != 1:
        errors.append("SCENARIOS_MUST_SHARE_ONE_ACTOR")
    for item in scenarios:
        if item.operation_key not in ALLOWED_OPERATIONS:
            errors.append(f"OPERATION_NOT_ALLOWLISTED:{item.operation_key}")
            continue
        if item.operation_key in seen:
            errors.append(f"DUPLICATE_OPERATION:{item.operation_key}")
        seen.add(item.operation_key)
        if item.target_type != EXPECTED_TARGETS[item.operation_key]:
            errors.append(f"TARGET_INCOMPATIBLE:{item.operation_key}")
        if item.thread_id is not None:
            errors.append(f"THREAD_NOT_REQUIRED:{item.operation_key}")
    for missing in sorted(ALLOWED_OPERATIONS - seen):
        errors.append(f"REQUIRED_OPERATION_MISSING:{missing}")
    return tuple(sorted(set(errors)))


def validate_capsule(capsule: Mapping[str, Any]) -> tuple[str, ...]:
    errors: list[str] = []
    expected = {
        "contract": CURRENT_BASELINE_CONTRACT_VERSION,
        "privacy_contract": PRIVACY_SAFE_BASELINE_CONTRACT_VERSION,
        "synthetic_identifiers": True,
        "source_identifier_mapping_emitted": False,
        "raw_payload_retained": False,
        "actor_mfa_state": "UNKNOWN_NOT_EXPOSED",
        "identifier_kind": "SYNTHETIC_SYMBOLIC",
        "identifier_namespace": SYNTHETIC_ID_NAMESPACE,
        "synthetic_id_version": SYNTHETIC_ID_VERSION,
    }
    for key, value in expected.items():
        if capsule.get(key) != value:
            errors.append(f"CAPSULE_FIELD_INVALID:{key}")
    if contains_credential(capsule):
        errors.append("CREDENTIAL_PRESENT")
    for finding in identifier_privacy_findings(capsule):
        if finding["discord_snowflake_shaped"]:
            errors.append("REAL_IDENTIFIER_SHAPED_VALUE_PRESENT:" + str(finding["field_path"]))
        else:
            errors.append("SYNTHETIC_IDENTIFIER_INVALID:" + str(finding["field_path"]))
    scenario = capsule.get("scenario")
    if not isinstance(scenario, Mapping):
        errors.append("SCENARIO_MISSING")
    else:
        try:
            if str(scenario.get("operation_key", "")) not in ALLOWED_OPERATIONS:
                errors.append("OPERATION_NOT_ALLOWLISTED")
            for field in ("guild_id", "actor_member_id"):
                if not SYMBOLIC_SYNTHETIC_ID_RE.fullmatch(str(scenario.get(field, ""))):
                    errors.append("SCENARIO_SYNTHETIC_IDENTIFIER_INVALID:" + field)
        except (TypeError, ValueError):
            errors.append("SCENARIO_INVALID")
    if not isinstance(capsule.get("bundle"), Mapping):
        errors.append("BUNDLE_MISSING")
    return tuple(sorted(set(errors)))


__all__ = [
    "ALLOWED_OPERATIONS", "CONFIRMATION_PHRASE", "CURRENT_BASELINE_CONTRACT_VERSION",
    "CURRENT_BASELINE_REPLAY_CONTRACT_VERSION", "CurrentBaselineError", "CurrentBaselineFailure", "GET_ONLY_ACQUISITION_CONTRACT_VERSION",
    "MFA_STATES", "PRIVACY_SAFE_BASELINE_CONTRACT_VERSION", "REAL_SNOWFLAKE_RE", "REPLAY_STATUSES",
    "SYNTHETIC_ID_NAMESPACE", "SYNTHETIC_ID_VERSION", "SYMBOLIC_SYNTHETIC_ID_RE", "contains_credential", "diagnostic_failure", "fingerprint", "identifier_privacy_findings", "validate_baseline_scenarios", "validate_capsule",
]
