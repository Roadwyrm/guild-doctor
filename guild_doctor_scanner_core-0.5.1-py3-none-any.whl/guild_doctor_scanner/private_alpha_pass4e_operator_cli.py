"""Operator entrypoint for the bound Pass4E validation session."""
from __future__ import annotations

import argparse
import asyncio
from dataclasses import asdict
import json
import os
from pathlib import Path

from .private_alpha_configuration import check_secret_presence
from .private_alpha_pass4e_operator_runner import build_context, run_authorized_session
from .private_alpha_pass4e_session_artifacts import SessionArtifactPaths
from .private_alpha_pass4e_validation_authority import (
    ValidationAuthorityStore,
)
from .private_alpha_pass4e_validation_lifecycle import resume_validation_authority
from .private_alpha_pass4e_runtime_receipt import recover_interrupted_receipt
from .private_alpha_pass4e_validation_sync import SyncProofStore


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the bounded Pass4E validation session.")
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--active-config", type=Path, required=True)
    parser.add_argument("--live-config", type=Path, required=True)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--issuance-reference", required=True)
    parser.add_argument("--start-phrase", required=True)
    return parser


async def _run(args: argparse.Namespace) -> int:
    artifacts = SessionArtifactPaths.for_issuance(args.issuance_reference)
    proof_path = artifacts.authority_path.with_name(artifacts.authority_path.stem + "_validation_sync_proof.json")
    proof = SyncProofStore(proof_path).load()
    context = build_context(
        project_root=args.project_root,
        active_configuration_path=args.active_config,
        live_configuration_path=args.live_config,
        snapshot_path=args.snapshot,
        runtime_receipt_path=artifacts.receipt_path,
        session_artifacts=artifacts,
        secret_presence=check_secret_presence(os.environ),
        sync_proof=proof,
    )
    store = ValidationAuthorityStore(artifacts.authority_path)
    record = store.load()
    authority = resume_validation_authority(
        phrase=args.start_phrase,
        issuance_reference=args.issuance_reference,
        store=store,
        binding=__import__("guild_doctor_scanner.private_alpha_pass4e_validation_authority", fromlist=["_binding_from_record"])._binding_from_record(record),
        configuration=context.active_configuration,
        pre_live_sync_proof=proof,
    )
    try:
        result = await run_authorized_session(
            context=context,
            authority=authority,
            start_phrase=args.start_phrase,
            token_provider=lambda: os.environ["GUILD_DOCTOR_DISCORD_TOKEN"],
        )
    except asyncio.TimeoutError:
        recover_interrupted_receipt(artifacts.receipt_path)
        raise RuntimeError("STAGE8_PASS4E_OPERATOR_SESSION_TIMEOUT") from None
    print(json.dumps(asdict(result), sort_keys=True, default=str))
    return 0 if result.state == "PASS" else 2


def main() -> int:
    args = _parser().parse_args()
    try:
        return asyncio.run(_run(args))
    except Exception as exc:
        print(json.dumps({"state": "BLOCKED", "reason": type(exc).__name__}, sort_keys=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
