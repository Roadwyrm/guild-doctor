"""Immutable Stage 6 Pass 6B audit-rule registry."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from types import MappingProxyType
from typing import Final

from .audit_contract import AUDIT_RULES_VERSION, FINDING_CLASSES, OBJECT_TYPES, VERIFICATION_LABELS
from .canonical import sha256_hex


AUDIT_RULE_REGISTRY_CONTRACT = AUDIT_RULES_VERSION
PASS6B_IMPLEMENTATION_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS6B-0.1"
INITIAL_TRANCHE = "STAGE6_PASS6B_INITIAL_SEVEN_RULE_TRANCHE"
LIVE_VERIFICATION_NOT_REQUIRED = "NOT_REQUIRED_OFFLINE_SYNTHETIC_COVERAGE"
EXPECTED_RULE_ORDER: Final[tuple[str, ...]] = (
    "ADMINISTRATOR_GRANT",
    "BROAD_MANAGEMENT_AUTHORITY",
    "TRACE_BACKED_INEFFECTIVE_PERMISSION",
    "NON_SYNCED_CATEGORY_CHILD",
    "MEMBER_OVERWRITE_PRESENCE",
    "IDENTICAL_ROLE_PROFILES",
    "INCOMPLETE_EVIDENCE",
)


@dataclass(frozen=True, slots=True)
class AuditRuleDefinition:
    rule_id: str
    title: str
    finding_class: str
    rule_contract_version: str
    evaluator_id: str
    required_normalized_inputs: tuple[str, ...]
    required_completeness: tuple[str, ...]
    allowed_trace_dependency: str | None
    severity_method: str
    confidence_method: str
    verification_label: str
    affected_object_kinds: tuple[str, ...]
    false_positive_controls: tuple[str, ...]
    grouping_key_method: str
    stable_sort_method: str
    beginner_template_id: str
    technical_evidence_fields: tuple[str, ...]
    implementation_tranche: str = INITIAL_TRANCHE
    read_only: bool = True
    live_verification_requirement: str = LIVE_VERIFICATION_NOT_REQUIRED
    enabled: bool = True

    def as_dict(self) -> dict[str, object]:
        return asdict(self)


def _rule(
    rule_id: str,
    title: str,
    finding_class: str,
    evaluator_id: str,
    *,
    inputs: tuple[str, ...],
    completeness: tuple[str, ...],
    trace: str | None,
    severity: str,
    confidence: str,
    verification: str,
    objects: tuple[str, ...],
    controls: tuple[str, ...],
    grouping: str,
    template: str,
    evidence: tuple[str, ...],
) -> AuditRuleDefinition:
    return AuditRuleDefinition(
        rule_id=rule_id,
        title=title,
        finding_class=finding_class,
        rule_contract_version=f"GUILD-DOCTOR-AUDIT-RULE-{rule_id}-0.1",
        evaluator_id=evaluator_id,
        required_normalized_inputs=inputs,
        required_completeness=completeness,
        allowed_trace_dependency=trace,
        severity_method=severity,
        confidence_method=confidence,
        verification_label=verification,
        affected_object_kinds=objects,
        false_positive_controls=controls,
        grouping_key_method=grouping,
        stable_sort_method="PASS6A_FINDING_STABLE_SORT_KEY",
        beginner_template_id=template,
        technical_evidence_fields=evidence,
    )


AUDIT_RULES: Final[tuple[AuditRuleDefinition, ...]] = (
    _rule(
        "ADMINISTRATOR_GRANT", "Role directly grants Administrator", "SECURITY_AUTHORITY", "evaluate_administrator_grant",
        inputs=("roles",), completeness=("structural_completeness", "collections.roles"), trace=None,
        severity="ADMINISTRATOR_SCOPE_V1", confidence="STRUCTURAL_EVIDENCE_V1", verification="VERIFIED_DISCORD_BEHAVIOR",
        objects=("ROLE",), controls=("EXCLUDE_EVERYONE", "PRESERVE_MANAGED_ROLE_STATE", "NO_HOLDER_OR_OWNER_INTENT_INFERENCE"),
        grouping="ONE_FINDING_PER_ROLE", template="AUDIT_ADMINISTRATOR_GRANT_BEGINNER_V1",
        evidence=("roles.permissions_decimal", "roles.managed", "roles.is_everyone", "roles.role_tags"),
    ),
    _rule(
        "BROAD_MANAGEMENT_AUTHORITY", "Role has broad management authority", "SECURITY_AUTHORITY", "evaluate_broad_management_authority",
        inputs=("roles", "permission_definition"), completeness=("structural_completeness", "collections.roles"), trace=None,
        severity="MANAGEMENT_GRANT_COUNT_V1", confidence="STRUCTURAL_EVIDENCE_V1", verification="VERIFIED_DISCORD_BEHAVIOR",
        objects=("ROLE",), controls=("ADMINISTRATOR_EXCLUDED_FROM_MANAGEMENT_SET", "MINIMUM_THREE_EXACT_GRANTS", "PRESERVE_MANAGED_ROLE_STATE"),
        grouping="ONE_GROUPED_FINDING_PER_ROLE", template="AUDIT_BROAD_MANAGEMENT_BEGINNER_V1",
        evidence=("roles.permissions_decimal", "permission_definition.management_flags", "roles.managed", "roles.role_tags"),
    ),
    _rule(
        "TRACE_BACKED_INEFFECTIVE_PERMISSION", "Granted permission or capability is ineffective", "CONFLICTS_INEFFECTIVENESS", "evaluate_trace_backed_ineffective_permission",
        inputs=("approved_ineffective_trace_projections",), completeness=("trace_projection.complete",), trace="FROZEN_STAGE3_CAPABILITY_TRACE",
        severity="TRACE_SCOPE_V1", confidence="AUTHORITATIVE_TRACE_V1", verification="VERIFIED_DISCORD_BEHAVIOR",
        objects=("ROLE", "GUILD", "CHANNEL", "CATEGORY", "THREAD"), controls=("TRACE_REQUIRED", "INEFFECTIVE_NOT_DENIED", "NO_PREREQUISITE_RECALCULATION", "TRACE_SCOPE_PRESERVED", "AFFECTED_OBJECTS_MUST_EXIST"),
        grouping="TRACE_SCOPE_AND_TARGET", template="AUDIT_INEFFECTIVE_PERMISSION_BEGINNER_V1",
        evidence=("trace.final_result", "trace.target_kind", "trace.target_key", "trace.missing_prerequisites", "trace.trace_event_reference"),
    ),
    _rule(
        "NON_SYNCED_CATEGORY_CHILD", "Category child is not permission-synced", "SYNCHRONIZATION_EXCEPTIONS", "evaluate_non_synced_category_child",
        inputs=("channels",), completeness=("structural_completeness", "collections.channels"), trace=None,
        severity="MAINTAINABILITY_EXCEPTION_V1", confidence="STRUCTURAL_EVIDENCE_V1", verification="GUILD_DOCTOR_DOCTRINE",
        objects=("CATEGORY", "CHANNEL"), controls=("SUPPORTED_CHILD_TYPES_ONLY", "NOT_LABELED_DISCORD_ERROR", "NO_INTENT_INFERENCE"),
        grouping="ONE_FINDING_PER_CATEGORY", template="AUDIT_NON_SYNCED_CHILD_BEGINNER_V1",
        evidence=("channels.parent_id", "channels.type_key", "channels.sync_state", "channels.sync_evidence"),
    ),
    _rule(
        "MEMBER_OVERWRITE_PRESENCE", "Member-specific permission overwrite is present", "MAINTAINABILITY_PERMISSION_DEBT", "evaluate_member_overwrite_presence",
        inputs=("channels.permission_overwrites",), completeness=("structural_completeness", "collections.channels"), trace=None,
        severity="PRESENCE_ONLY_LOW_V1", confidence="OVERWRITE_RECORD_V1", verification="GUILD_DOCTOR_DOCTRINE",
        objects=("CATEGORY", "CHANNEL", "MEMBER"), controls=("PRESENCE_NOT_WRONGDOING", "NO_POPULATION_REQUIRED", "RAW_MEMBER_IDS_NEVER_SERIALIZED"),
        grouping="ONE_FINDING_PER_CHANNEL_OR_CATEGORY", template="AUDIT_MEMBER_OVERWRITE_BEGINNER_V1",
        evidence=("channels.permission_overwrites.target_type", "channels.permission_overwrites.allow_decimal", "channels.permission_overwrites.deny_decimal", "member_completeness"),
    ),
    _rule(
        "IDENTICAL_ROLE_PROFILES", "Distinct roles have identical authority-significant profiles", "MAINTAINABILITY_PERMISSION_DEBT", "evaluate_identical_role_profiles",
        inputs=("roles",), completeness=("structural_completeness", "collections.roles"), trace=None,
        severity="IDENTICAL_PROFILE_LOW_V1", confidence="STRUCTURAL_EVIDENCE_V1", verification="GUILD_DOCTOR_DOCTRINE",
        objects=("ROLE",), controls=("EXCLUDE_EVERYONE", "INCLUDE_POSITION_MANAGED_AND_BINDING_METADATA", "NEAR_MATCHES_EXCLUDED", "NO_AUTOMATIC_MERGE"),
        grouping="CANONICAL_PROFILE_FINGERPRINT", template="AUDIT_IDENTICAL_ROLE_PROFILE_BEGINNER_V1",
        evidence=("roles.permissions_decimal", "roles.position", "roles.managed", "roles.is_everyone", "roles.role_tags"),
    ),
    _rule(
        "INCOMPLETE_EVIDENCE", "Audit evidence is incomplete", "NEEDS_REVIEW_INCOMPLETE_DATA", "evaluate_incomplete_evidence",
        inputs=("snapshot_completeness", "collection_health"), completeness=("explicit_states",), trace=None,
        severity="INCOMPLETE_EVIDENCE_NEEDS_REVIEW_V1", confidence="COMPLETENESS_STATE_V1", verification="PROPOSED_PRODUCT_BEHAVIOR",
        objects=("GUILD", "COLLECTION"), controls=("ONE_GROUPED_FINDING", "STATE_PRESERVED", "ABSENCE_NOT_CONVERTED_TO_NOT_FOUND"),
        grouping="MISSING_EVIDENCE_STATE_SET", template="AUDIT_INCOMPLETE_EVIDENCE_BEGINNER_V1",
        evidence=("structural_completeness", "member_completeness", "thread_completeness", "collections.status"),
    ),
)

AUDIT_RULES_BY_ID: Final[MappingProxyType[str, AuditRuleDefinition]] = MappingProxyType(
    {rule.rule_id: rule for rule in AUDIT_RULES}
)


def registry_payload() -> dict[str, object]:
    return {
        "registry_contract": AUDIT_RULE_REGISTRY_CONTRACT,
        "pass6b_contract": PASS6B_IMPLEMENTATION_CONTRACT,
        "rules": [rule.as_dict() for rule in AUDIT_RULES],
    }


def registry_fingerprint() -> str:
    return sha256_hex(registry_payload())


def validate_audit_rule_registry(rules: tuple[AuditRuleDefinition, ...] = AUDIT_RULES) -> tuple[str, ...]:
    errors: list[str] = []
    if len(rules) != 7:
        errors.append("AUDIT_RULE_COUNT_INVALID")
    ids = [rule.rule_id for rule in rules]
    evaluators = [rule.evaluator_id for rule in rules]
    if len(set(ids)) != len(ids):
        errors.append("AUDIT_RULE_ID_DUPLICATE")
    if len(set(evaluators)) != len(evaluators):
        errors.append("AUDIT_RULE_EVALUATOR_DUPLICATE")
    if tuple(ids) != EXPECTED_RULE_ORDER:
        errors.append("AUDIT_RULE_ORDER_NONDETERMINISTIC")
    for rule in rules:
        if rule.finding_class not in FINDING_CLASSES:
            errors.append(f"AUDIT_RULE_CLASS_INVALID:{rule.rule_id}")
        if rule.verification_label not in VERIFICATION_LABELS:
            errors.append(f"AUDIT_RULE_VERIFICATION_INVALID:{rule.rule_id}")
        if any(kind not in OBJECT_TYPES for kind in rule.affected_object_kinds):
            errors.append(f"AUDIT_RULE_OBJECT_KIND_INVALID:{rule.rule_id}")
        if not rule.read_only or not rule.enabled:
            errors.append(f"AUDIT_RULE_NOT_ENABLED_READ_ONLY:{rule.rule_id}")
        if rule.implementation_tranche != INITIAL_TRANCHE:
            errors.append(f"AUDIT_RULE_TRANCHE_INVALID:{rule.rule_id}")
        if rule.live_verification_requirement != LIVE_VERIFICATION_NOT_REQUIRED:
            errors.append(f"AUDIT_RULE_LIVE_REQUIREMENT_INVALID:{rule.rule_id}")
    return tuple(sorted(set(errors)))


__all__ = [
    "AUDIT_RULE_REGISTRY_CONTRACT", "AUDIT_RULES", "AUDIT_RULES_BY_ID",
    "AuditRuleDefinition", "EXPECTED_RULE_ORDER", "INITIAL_TRANCHE", "PASS6B_IMPLEMENTATION_CONTRACT",
    "registry_fingerprint", "registry_payload", "validate_audit_rule_registry",
]
