"""Guild-only Pass 5 synchronization with exact capture and verified rollback."""
from __future__ import annotations

import asyncio
import inspect
from typing import Any, Mapping, Sequence

from .discord_command_manifest import COMMAND_MANIFEST, manifest_fingerprint, validate_manifest
from .discord_command_schema import (
    compare_live_schema,
    expected_live_schema,
    normalize_live_commands,
    schema_fingerprint,
)
from .discord_secure_token import HiddenTokenProvider, TokenInputError
from .discord_sync_guard import CONFIRMATION_PHRASE, evaluate_sync_guard
from .discord_sync_safeguards import (
    PRE_SYNC_APPROVED_12,
    PRE_SYNC_HISTORICAL_10,
    PRE_SYNC_MALFORMED,
    PRE_SYNC_UNRELATED,
    capture_rollback_snapshot,
    rollback_snapshot_matches,
)


DISPOSABLE_SYNC_CONTRACT = "GUILD-DOCTOR-DISPOSABLE-SYNC-0.2"
SYNC_NOT_ATTEMPTED = "SYNC_NOT_ATTEMPTED"
SYNC_REQUEST_ATTEMPTED = "SYNC_REQUEST_ATTEMPTED"
SYNC_CONFIRMED_BY_RESPONSE = "SYNC_CONFIRMED_BY_RESPONSE"
SYNC_RESPONSE_RECEIVED_SCHEMA_PENDING = "SYNC_RESPONSE_RECEIVED_SCHEMA_PENDING"
SYNC_SCHEMA_VERIFIED = "SYNC_SCHEMA_VERIFIED"
SYNC_STATE_UNCERTAIN = "SYNC_STATE_UNCERTAIN"
ALREADY_SYNCHRONIZED = "ALREADY_SYNCHRONIZED"
ROLLBACK_NOT_REQUIRED = "ROLLBACK_NOT_REQUIRED"
ROLLBACK_REQUIRED = "ROLLBACK_REQUIRED"
ROLLBACK_VERIFIED = "ROLLBACK_VERIFIED"
ROLLBACK_CRITICAL_FAILURE = "ROLLBACK_CRITICAL_FAILURE"


class SchemaRetrievalError(Exception):
    def __init__(self, reason: str = "SCHEMA_RETRIEVAL_FAILED", status: int | None = None):
        super().__init__(reason)
        self.reason = reason
        self.status = status


class GuildCommandScopeError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


class PreSyncRegistrationError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


class RollbackVerificationError(Exception):
    pass


def _local_candidate_valid() -> bool:
    expected_names = tuple(item["name"] for item in expected_live_schema()["subcommands"])
    manifest_names = tuple(item.key for item in COMMAND_MANIFEST)
    return (
        not validate_manifest()
        and len(manifest_names) == 12
        and len(set(manifest_names)) == 12
        and manifest_names == expected_names
        and "compare-roles" not in manifest_names
    )


def dry_run(*, guild_id: str | None, confirmation: str | None, network_enabled: bool) -> dict[str, Any]:
    local_valid = _local_candidate_valid()
    state = evaluate_sync_guard(
        confirmation=confirmation,
        guild_id=guild_id,
        authorized_mode=True,
        provenance_pass=True,
        manifest_match=local_valid,
        version_match=True,
        readiness_pass=True,
        network_enabled=network_enabled,
        protected_evidence_pass=True,
        scope_clean=True,
    )
    return {
        "state": state,
        "command_count": len(COMMAND_MANIFEST),
        "command_count_semantics": "guild_doctor_subcommand_count",
        "command_keys": [item.key for item in COMMAND_MANIFEST],
        "manifest_fingerprint": manifest_fingerprint(),
        "schema_fingerprint": schema_fingerprint(),
        "local_candidate_valid": local_valid,
        "global_sync": False,
        "production_sync": False,
        "request_count": 0,
        "write_count": 0,
        "confirmation_phrase": CONFIRMATION_PHRASE,
    }


def _exception_category(exc: BaseException) -> str:
    if isinstance(exc, SchemaRetrievalError):
        return "SchemaRetrievalError"
    if isinstance(exc, PreSyncRegistrationError):
        return "PreSyncRegistrationError"
    try:
        import discord

        if isinstance(exc, discord.errors.LoginFailure):
            return "LoginFailure"
        if isinstance(exc, discord.errors.Forbidden):
            return "Forbidden"
        if isinstance(exc, discord.errors.NotFound):
            return "NotFound"
        if isinstance(exc, discord.HTTPException):
            return "HTTPException"
    except ImportError:
        pass
    return type(exc).__name__


def _status(exc: BaseException) -> int | None:
    value = getattr(exc, "status", None)
    return value if isinstance(value, int) and 100 <= value <= 599 else None


async def _invoke(transport: Any, async_name: str, sync_name: str, *args: Any) -> Any:
    method = getattr(transport, async_name, None)
    result = method(*args) if method is not None else getattr(transport, sync_name)(*args)
    return await result if inspect.isawaitable(result) else result


def _schema_is_exact_approved(commands: Sequence[Any]) -> tuple[bool, dict[str, Any]]:
    normalized = normalize_live_commands(commands)
    comparison = compare_live_schema(normalized, expected=expected_live_schema())
    exact = (
        comparison["state"] == "COMMANDS_PRESENT_EXACT"
        and normalized["unrelated_top_level_command_count"] == 0
        and normalized["guild_doctor_root_count"] == 1
        and normalized["guild_doctor_subcommand_count"] == 12
    )
    return exact, normalized


def _safe_rollback_summary(snapshot: Mapping[str, Any] | None) -> dict[str, Any] | None:
    if snapshot is None:
        return None
    return {
        "snapshot_contract": snapshot["snapshot_contract"],
        "guild_id": snapshot["guild_id"],
        "pre_sync_state": snapshot["pre_sync_state"],
        "top_level_command_names": snapshot["top_level_command_names"],
        "command_types": snapshot["command_types"],
        "guild_doctor_subcommand_names": snapshot["guild_doctor_subcommand_names"],
        "pre_sync_route_count": snapshot["pre_sync_route_count"],
        "unrelated_top_level_command_count": snapshot["unrelated_top_level_command_count"],
        "normalized_fingerprint": snapshot["normalized_fingerprint"],
        "token_redacted": True,
        "credentials_retained": False,
    }


async def _restore_and_verify(
    *,
    transport: Any,
    guild_id: str,
    snapshot: Mapping[str, Any],
    timeout_seconds: float,
) -> dict[str, Any]:
    restored = await asyncio.wait_for(
        _invoke(
            transport,
            "async_restore_guild_commands",
            "restore_guild_commands",
            guild_id,
            list(snapshot["commands"]),
        ),
        timeout_seconds,
    )
    restored_matches = rollback_snapshot_matches(snapshot, restored, guild_id=guild_id)
    observed = await asyncio.wait_for(
        _invoke(
            transport,
            "async_fetch_rollback_verification_commands",
            "fetch_rollback_verification_commands",
            guild_id,
        ),
        timeout_seconds,
    )
    fetched_matches = rollback_snapshot_matches(snapshot, observed, guild_id=guild_id)
    if not restored_matches or not fetched_matches:
        raise RollbackVerificationError("PASS5_ROLLBACK_VERIFICATION_FAILED")
    return {
        "rollback_status": ROLLBACK_VERIFIED,
        "rollback_write_count": 1,
        "rollback_verification_fetch_count": 1,
        "rollback_fingerprint": snapshot["normalized_fingerprint"],
    }


async def execute_sync_async(
    *,
    transport: Any,
    token_provider: Any = None,
    guild_id: str | None,
    confirmation: str | None,
    network_enabled: bool,
    timeout_seconds: float = 30,
) -> dict[str, Any]:
    plan = dry_run(guild_id=guild_id, confirmation=confirmation, network_enabled=network_enabled)
    if plan["state"] != "SYNC_READY_FOR_DISPOSABLE_GUILD":
        return {
            **plan,
            "status": "FAIL",
            "token_prompted": False,
            "sync_lifecycle": SYNC_NOT_ATTEMPTED,
            "client_cleanup": "NOT_ATTEMPTED",
            "attempted_write_count": 0,
            "confirmed_write_count": 0,
            "rollback_status": ROLLBACK_NOT_REQUIRED,
        }

    token_provider = token_provider or HiddenTokenProvider()
    token = None
    operation = "local_preflight"
    request_count = 0
    primary: BaseException | None = None
    result: dict[str, Any] | None = None
    lifecycle = SYNC_NOT_ATTEMPTED
    attempted_write_count = 0
    confirmed_write_count = 0
    bulk_sync_request_count = 0
    rollback_snapshot: dict[str, Any] | None = None
    rollback_result = {
        "rollback_status": ROLLBACK_NOT_REQUIRED,
        "rollback_write_count": 0,
        "rollback_verification_fetch_count": 0,
    }
    normalized_counts = {
        "top_level_command_count": 0,
        "guild_doctor_root_count": 0,
        "guild_doctor_subcommand_count": 0,
        "unrelated_top_level_command_count": 0,
    }
    guild_scope_state = "GUILD_SCOPE_NOT_PREPARED"

    try:
        operation = "open_client"
        await asyncio.wait_for(_invoke(transport, "async_open_client", "open_client"), timeout_seconds)

        operation = "prepare_guild_scope"
        try:
            scope = await asyncio.wait_for(
                _invoke(transport, "async_prepare_guild_scope", "prepare_guild_scope", guild_id),
                timeout_seconds,
            )
        except Exception as exc:
            code = "PASS5_GUILD_COMMAND_SCOPE_EMPTY" if "SCOPE_EMPTY" in str(exc) else "PASS5_GUILD_SCOPE_PRECHECK_FAILED"
            raise GuildCommandScopeError(code) from None
        if scope.get("state") != "GUILD_SCOPE_READY_FOR_SYNC":
            raise GuildCommandScopeError("PASS5_GUILD_COMMAND_SCOPE_EMPTY")
        guild_scope_state = "GUILD_SCOPE_READY_FOR_SYNC"
        normalized_counts = {key: scope[key] for key in normalized_counts}
        candidate_commands = scope["commands"]

        token = token_provider.get()
        operation = "authenticate_bot"
        request_count += 1
        await asyncio.wait_for(
            _invoke(transport, "async_authenticate_bot", "authenticate_bot", token),
            timeout_seconds,
        )

        operation = "fetch_guild_metadata"
        request_count += 1
        metadata = await asyncio.wait_for(
            _invoke(transport, "async_fetch_guild_metadata", "fetch_guild_metadata", guild_id),
            timeout_seconds,
        )
        if str(metadata.get("id")) != str(guild_id):
            raise PreSyncRegistrationError("PASS5_GUILD_BINDING_MISMATCH")

        operation = "fetch_pre_sync_registration"
        request_count += 1
        pre_sync_commands = await asyncio.wait_for(
            _invoke(
                transport,
                "async_fetch_pre_sync_guild_commands",
                "fetch_pre_sync_guild_commands",
                guild_id,
            ),
            timeout_seconds,
        )
        rollback_snapshot = capture_rollback_snapshot(pre_sync_commands, guild_id=str(guild_id))
        pre_sync_state = rollback_snapshot["pre_sync_state"]
        normalized_counts["unrelated_top_level_command_count"] = rollback_snapshot["unrelated_top_level_command_count"]
        if pre_sync_state == PRE_SYNC_UNRELATED:
            raise PreSyncRegistrationError("PASS5_UNRELATED_GUILD_COMMANDS_PRESENT")
        if pre_sync_state == PRE_SYNC_MALFORMED:
            raise PreSyncRegistrationError("PASS5_PRE_SYNC_REGISTRATION_INVALID")
        if pre_sync_state == PRE_SYNC_APPROVED_12:
            lifecycle = SYNC_SCHEMA_VERIFIED
            result = {
                **plan,
                "status": "PASS",
                "sync_status": ALREADY_SYNCHRONIZED,
                "token_prompted": True,
                "pre_sync_state": pre_sync_state,
                "pre_sync_route_count": rollback_snapshot["pre_sync_route_count"],
                "rollback_snapshot": _safe_rollback_summary(rollback_snapshot),
                "request_count": request_count,
                "write_count": 0,
                "attempted_write_count": 0,
                "confirmed_write_count": 0,
                "bulk_sync_request_count": 0,
                "sync_lifecycle": lifecycle,
                "guild_scope_state": guild_scope_state,
                "token_redacted": True,
                "client_cleanup": "CLEANUP_PENDING",
                **rollback_result,
                **normalized_counts,
            }
        elif pre_sync_state != PRE_SYNC_HISTORICAL_10:
            raise PreSyncRegistrationError("PASS5_PRE_SYNC_REGISTRATION_INVALID")
        else:
            operation = "synchronize_guild_commands"
            request_count += 1
            bulk_sync_request_count = 1
            attempted_write_count = 1
            lifecycle = SYNC_REQUEST_ATTEMPTED
            synced = await asyncio.wait_for(
                _invoke(
                    transport,
                    "async_synchronize_guild_commands",
                    "synchronize_guild_commands",
                    guild_id,
                    candidate_commands,
                ),
                timeout_seconds,
            )
            confirmed_write_count = 1
            lifecycle = SYNC_RESPONSE_RECEIVED_SCHEMA_PENDING
            returned_exact, normalized_sync = _schema_is_exact_approved(synced)
            if not returned_exact:
                lifecycle = SYNC_STATE_UNCERTAIN
                raise SchemaRetrievalError("RETURNED_SCHEMA_MISMATCH")
            lifecycle = SYNC_CONFIRMED_BY_RESPONSE

            operation = "fetch_synchronized_schema"
            request_count += 1
            lifecycle = SYNC_RESPONSE_RECEIVED_SCHEMA_PENDING
            try:
                observed = await asyncio.wait_for(
                    _invoke(
                        transport,
                        "async_fetch_post_sync_guild_commands",
                        "fetch_post_sync_guild_commands",
                        guild_id,
                    ),
                    timeout_seconds,
                )
            except Exception as exc:
                raise SchemaRetrievalError("SCHEMA_RETRIEVAL_FAILED", _status(exc)) from None
            fetched_exact, normalized_observed = _schema_is_exact_approved(observed)
            if not fetched_exact:
                lifecycle = SYNC_STATE_UNCERTAIN
                raise SchemaRetrievalError("FETCHED_SCHEMA_MISMATCH")
            normalized_counts = {key: normalized_observed[key] for key in normalized_counts}
            lifecycle = SYNC_SCHEMA_VERIFIED
            result = {
                **plan,
                "status": "PASS",
                "sync_status": "SYNCHRONIZED_AND_VERIFIED",
                "token_prompted": True,
                "pre_sync_state": pre_sync_state,
                "pre_sync_route_count": rollback_snapshot["pre_sync_route_count"],
                "rollback_snapshot": _safe_rollback_summary(rollback_snapshot),
                "synced_count": normalized_observed["guild_doctor_subcommand_count"],
                "synced_count_semantics": "guild_doctor_subcommand_count",
                "returned_top_level_root_count": normalized_sync["top_level_command_count"],
                "returned_guild_doctor_root_count": normalized_sync["guild_doctor_root_count"],
                "returned_guild_doctor_subcommand_count": normalized_sync["guild_doctor_subcommand_count"],
                "request_count": request_count,
                "bulk_sync_request_count": bulk_sync_request_count,
                "write_count": confirmed_write_count,
                "attempted_write_count": attempted_write_count,
                "confirmed_write_count": confirmed_write_count,
                "sync_lifecycle": lifecycle,
                "guild_scope_state": guild_scope_state,
                "token_redacted": True,
                "client_cleanup": "CLEANUP_PENDING",
                **rollback_result,
                **normalized_counts,
            }
    except BaseException as exc:
        primary = exc
        category = _exception_category(exc)
        status = _status(exc)
        code = "PASS5_TRANSPORT_INTERNAL_ERROR"
        if isinstance(exc, TokenInputError):
            code = "PASS5_TOKEN_INPUT_FAILED"
        elif isinstance(exc, GuildCommandScopeError):
            code = exc.code
        elif isinstance(exc, PreSyncRegistrationError):
            code = exc.code
        elif isinstance(exc, SchemaRetrievalError):
            code = "PASS5_SCHEMA_RETRIEVAL_FAILED" if exc.reason == "SCHEMA_RETRIEVAL_FAILED" else "PASS5_SCHEMA_MISMATCH"
        elif category == "LoginFailure" or status == 401:
            code = "PASS5_AUTHENTICATION_FAILED"
        elif status == 403 and operation == "fetch_guild_metadata":
            code = "PASS5_GUILD_ACCESS_DENIED"
        elif status == 404 and operation == "fetch_guild_metadata":
            code = "PASS5_GUILD_NOT_FOUND"
        elif operation == "synchronize_guild_commands":
            code = "PASS5_GUILD_SYNC_FAILED"

        if attempted_write_count and rollback_snapshot is not None:
            try:
                rollback_result = await _restore_and_verify(
                    transport=transport,
                    guild_id=str(guild_id),
                    snapshot=rollback_snapshot,
                    timeout_seconds=timeout_seconds,
                )
                request_count += 2
            except BaseException:
                rollback_result = {
                    "rollback_status": ROLLBACK_CRITICAL_FAILURE,
                    "rollback_write_count": 1,
                    "rollback_verification_fetch_count": 1,
                }
                code = "PASS5_ROLLBACK_CRITICAL_FAILURE"

        result = {
            **plan,
            "status": "FAIL",
            "stable_error": code,
            "operation": operation,
            "exception_category": category,
            "http_status": status,
            "request_phase": "DISCORD_REQUEST" if request_count else "LOCAL_SETUP",
            "guild_scope_state": guild_scope_state,
            "request_count": request_count,
            "bulk_sync_request_count": bulk_sync_request_count,
            "write_count": confirmed_write_count,
            "attempted_write_count": attempted_write_count,
            "confirmed_write_count": confirmed_write_count,
            "sync_lifecycle": lifecycle,
            "token_prompted": token is not None,
            "token_redacted": True,
            "rollback_snapshot": _safe_rollback_summary(rollback_snapshot),
            "client_cleanup": "CLEANUP_PENDING",
            **rollback_result,
            **normalized_counts,
        }
    finally:
        try:
            await _invoke(transport, "async_close_client", "close_client")
        except Exception as close_exc:
            if primary is None:
                result = {
                    **plan,
                    "status": "FAIL",
                    "stable_error": "PASS5_CLIENT_CLOSE_FAILED",
                    "operation": "close_client",
                    "exception_category": _exception_category(close_exc),
                    "http_status": _status(close_exc),
                    "request_phase": "CLEANUP",
                    "request_count": request_count,
                    "write_count": confirmed_write_count,
                    "attempted_write_count": attempted_write_count,
                    "confirmed_write_count": confirmed_write_count,
                    "sync_lifecycle": lifecycle,
                    "token_prompted": token is not None,
                    "token_redacted": True,
                    "rollback_snapshot": _safe_rollback_summary(rollback_snapshot),
                    "client_cleanup": "CLOSE_FAILED",
                    **rollback_result,
                }
            elif result is not None:
                result["client_cleanup"] = "CLOSE_FAILED"
        else:
            if result is not None:
                result["client_cleanup"] = "CLOSED"
        token = None

    assert result is not None
    return result


def execute_sync(
    *,
    transport: Any,
    token_provider: Any = None,
    guild_id: str | None,
    confirmation: str | None,
    network_enabled: bool,
) -> dict[str, Any]:
    return asyncio.run(
        execute_sync_async(
            transport=transport,
            token_provider=token_provider,
            guild_id=guild_id,
            confirmation=confirmation,
            network_enabled=network_enabled,
        )
    )
