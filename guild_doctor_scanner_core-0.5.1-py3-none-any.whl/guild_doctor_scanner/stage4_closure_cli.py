"""CLI for evaluating the local Stage 4 closure evidence directory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .explanation_runtime import (
    RUNTIME_EXIT_CLOSURE_PENDING,
    RUNTIME_EXIT_INPUT_FAILURE,
    RUNTIME_EXIT_OUTPUT_FAILURE,
    _safe_path,
    write_json,
)
from .stage4_closure import assess_stage4_closure, verification_backlog


def _progress(message: str) -> None:
    print(f"[Guild Doctor] {message}", flush=True)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="guild-doctor-stage4-closure")
    parser.add_argument("--evidence-directory", required=True)
    parser.add_argument("--source-directory", default="Guild_Doctor_Project_Sources")
    parser.add_argument("--package-version", default="0.5.1")
    return parser


def _load(directory: Path, name: str) -> dict[str, Any] | None:
    path = directory / name
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_bytes().decode("utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
        evidence_directory = _safe_path(args.evidence_directory, label="evidence directory")
        evidence_directory.mkdir(parents=True, exist_ok=True)
        _progress("created/confirmed closure evidence directory")
        runtime = _load(evidence_directory, "runtime_verification_report.json")
        live = _load(evidence_directory, "live_derived_explanations.json")
        golden = _load(evidence_directory, "runtime_golden_results.json")
        environment = _load(evidence_directory, "canonical_environment_report.json")
        wheel = _load(evidence_directory, "clean_wheel_report.json")
        console = _load(evidence_directory, "console_compatibility_report.json")
        integrity = _load(evidence_directory, "evidence_integrity_report.json")
        manifest = _load(evidence_directory, "runtime_output_manifest.json")
        tests = _load(evidence_directory, "complete_test_suite_report.json")
        source_pack = _load(evidence_directory, "source_pack_report.json")
        audit = _load(evidence_directory, "read_only_audit_report.json")
        checks = {
            "canonical_environment": environment,
            "complete_test_suite": tests,
            "clean_wheel": wheel,
            "console_compatibility": console,
            "evidence_integrity": integrity,
            "live_derived_runtime": live,
            "read_only_audit": audit,
            "runtime_golden": golden,
            "source_pack": source_pack,
            "runtime_contract_version": runtime.get("runtime_contract_version") if runtime else None,
            "source_markdown_file_count": source_pack.get("markdown_file_count") if source_pack else None,
            "live_derived_presentation_count": manifest.get("output_count") if manifest else (live.get("presentation_count") if live else None),
            "token_disclosure_status": (live or runtime or {}).get("token_disclosure_status"),
            "network_contacted": any(item and item.get("network_contacted") is True for item in (runtime, live, manifest)),
            "discord_write_requests": max([item.get("discord_write_requests", 0) for item in (runtime, live, manifest) if item] or [0]),
            "future_stage_started": False,
            "package_version": args.package_version,
        }
        assessment = assess_stage4_closure(checks)
        write_json(evidence_directory / "stage4_closure_assessment.json", assessment, overwrite=True)
        write_json(evidence_directory / "verification_backlog.json", verification_backlog(assessment), overwrite=True)
        _progress(f"closure decision={assessment['decision']} status={assessment['status']}")
        return 0 if assessment["stage4_pass4_complete"] else RUNTIME_EXIT_CLOSURE_PENDING
    except SystemExit as exc:
        return int(exc.code)
    except OSError as exc:
        _progress(f"filesystem failure: {type(exc).__name__}")
        return RUNTIME_EXIT_OUTPUT_FAILURE
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        _progress(f"closure input failure: {type(exc).__name__}")
        return RUNTIME_EXIT_INPUT_FAILURE


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())


__all__ = ["build_parser", "main"]
