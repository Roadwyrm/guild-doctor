"""Immutable Stage 5 Pass 3 role-comparison query contracts.

Role subjects are finite, explicit, and hypothetical.  This module validates
the request and reads frozen registry metadata only; it does not evaluate a
permission or call a Stage 3 engine.
"""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .action_registry import ACTION_RULES_BY_KEY, ACTION_RULES_VERSION
from .capability_registry import CAPABILITY_REGISTRY_VERSION, DEFAULT_CAPABILITY_REGISTRY, KNOWN_PERMISSION_FLAGS
from .constants import KNOWN_PERMISSION_MASK, PERMISSION_DEFINITION_VERSION
from .doctor_query import DOCTOR_QUERY_CONTRACT_VERSION, STAGE5_PASS1_CONTRACT_VERSION
from .doctor_source_query import (
    ROLE_COMPARISON_QUERY_CONTRACT_VERSION,
    STAGE5_PASS3_CONTRACT_VERSION,
)


RAW_PERMISSION = "RAW_PERMISSION"
CAPABILITY = "CAPABILITY"
CAPABILITY_SET = "CAPABILITY_SET"
ACTION = "ACTION"
ROLE_COMPARISON_TARGET_KINDS = frozenset({RAW_PERMISSION, CAPABILITY, CAPABILITY_SET, ACTION})

COMPARE_RAW_ROLE_PERMISSIONS = "COMPARE_RAW_ROLE_PERMISSIONS"
COMPARE_CONTEXT_CAPABILITY = "COMPARE_CONTEXT_CAPABILITY"
COMPARE_CAPABILITY_SET = "COMPARE_CAPABILITY_SET"
COMPARE_ACTION_AUTHORITY = "COMPARE_ACTION_AUTHORITY"
ENUMERATE_ROLE_DIFFERENCES = "ENUMERATE_ROLE_DIFFERENCES"
ROLE_COMPARISON_INTENTS = frozenset(
    {
        COMPARE_RAW_ROLE_PERMISSIONS,
        COMPARE_CONTEXT_CAPABILITY,
        COMPARE_CAPABILITY_SET,
        COMPARE_ACTION_AUTHORITY,
        ENUMERATE_ROLE_DIFFERENCES,
    }
)

ROLE_CONTEXT_TYPES = frozenset(
    {
        "GUILD",
        "CATEGORY",
        "TEXT",
        "ANNOUNCEMENT",
        "VOICE",
        "STAGE",
        "FORUM",
        "MEDIA",
        "PUBLIC_THREAD",
        "PRIVATE_THREAD",
        "ANNOUNCEMENT_THREAD",
    }
)

DEFAULT_PROJECTION_ASSUMPTIONS = MappingProxyType(
    {
        "projection_member_kind": "HYPOTHETICAL_ROLE_SET",
        "timeout_state": "UNKNOWN",
        "membership_state": "UNKNOWN",
        "actor_mfa_state": "UNKNOWN",
        "guild_mfa_level": "UNKNOWN",
        "voice_state": "UNKNOWN",
        "owner_state": "FALSE",
        "member_overwrite_policy": "EXCLUDED",
        "hierarchy_evidence": "UNKNOWN",
        "object_state": "UNKNOWN",
        "execution_mode": "PRE_EXECUTION_MODEL",
    }
)

_TOKEN_SHAPE = re.compile(r"^[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{8,}$")
_SECRET_FRAGMENTS = ("token", "authorization", "access_token", "client_secret", "password", "api_key", "credential")
_FORBIDDEN_KEYS = frozenset(
    {
        "question",
        "natural_language_question",
        "prompt",
        "recommendation",
        "recommendations",
        "remediation",
        "repair",
        "output_path",
        "interaction",
        "command",
        "callback",
        "connection",
        "member_enumeration",
    }
)


class RoleComparisonQueryError(ValueError):
    """Raised by strict role-comparison query construction."""


def _text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def _upper(value: Any) -> str | None:
    value = _text(value)
    return value.upper() if value else None


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(child) for key, child in sorted(value.items(), key=lambda item: str(item[0]))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(child) for child in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(child) for child in sorted(value, key=str))
    return deepcopy(value)


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _thaw(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [_thaw(child) for child in value]
    return deepcopy(value)


def _scan_forbidden(value: Any, path: str = "role_comparison_query") -> tuple[str, ...]:
    errors: list[str] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            lower = key_text.lower()
            child_path = f"{path}.{key_text}"
            if any(fragment in lower for fragment in _SECRET_FRAGMENTS):
                errors.append(f"ROLE_QUERY_CREDENTIAL_FIELD:{child_path}")
            if lower in _FORBIDDEN_KEYS:
                errors.append(f"ROLE_QUERY_FORBIDDEN_FIELD:{child_path}")
            errors.extend(_scan_forbidden(child, child_path))
    elif isinstance(value, (list, tuple, set, frozenset)):
        for index, child in enumerate(value):
            errors.extend(_scan_forbidden(child, f"{path}[{index}]"))
    elif isinstance(value, str):
        lower = value.lower()
        if "bot " in lower or _TOKEN_SHAPE.fullmatch(value.strip()):
            errors.append(f"ROLE_QUERY_CREDENTIAL_VALUE:{path}")
    return tuple(sorted(set(errors)))


def _safe_label(value: Any, fallback: str) -> str:
    text = _text(value) or fallback
    text = " ".join(text.replace("@", "@​").split())
    return text[:160]


@dataclass(frozen=True, slots=True)
class RoleComparisonSubject:
    """One explicit finite role-set subject."""

    comparison_subject_id: str
    role_ids: tuple[str, ...]
    input_role_ids: tuple[str, ...] = ()
    duplicate_role_ids: tuple[str, ...] = ()
    display_safe_label: str | None = None
    evidence_classification: str = "SYNTHETIC_ROLE_PROJECTION"
    input_index: int = 0

    def __post_init__(self) -> None:
        raw = tuple(str(item).strip() for item in (self.input_role_ids or self.role_ids) if str(item).strip())
        normalized = tuple(sorted({_snowflake(item) or str(item) for item in raw}, key=lambda item: (not item.isdecimal(), int(item) if item.isdecimal() else item)))
        duplicates = tuple(sorted({item for item in raw if raw.count(item) > 1}, key=lambda item: (not item.isdecimal(), int(item) if item.isdecimal() else item)))
        object.__setattr__(self, "comparison_subject_id", _text(self.comparison_subject_id) or "")
        object.__setattr__(self, "input_role_ids", raw)
        object.__setattr__(self, "role_ids", normalized)
        object.__setattr__(self, "duplicate_role_ids", tuple(self.duplicate_role_ids) or duplicates)
        object.__setattr__(self, "display_safe_label", _safe_label(self.display_safe_label, self.comparison_subject_id))
        object.__setattr__(self, "evidence_classification", _text(self.evidence_classification) or "SYNTHETIC_ROLE_PROJECTION")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any], *, input_index: int = 0) -> "RoleComparisonSubject":
        if not isinstance(value, Mapping):
            raise RoleComparisonQueryError("ROLE_SUBJECT_NOT_MAPPING")
        role_ids = value.get("role_ids", value.get("roles", ()))
        if isinstance(role_ids, str):
            role_ids = (role_ids,)
        if not isinstance(role_ids, Sequence) or isinstance(role_ids, (bytes, bytearray)):
            role_ids = ()
        return cls(
            comparison_subject_id=value.get("comparison_subject_id", value.get("subject_id", "")),
            role_ids=tuple(str(item) for item in role_ids),
            input_role_ids=tuple(str(item) for item in role_ids),
            display_safe_label=value.get("display_safe_label", value.get("label")),
            evidence_classification=value.get("evidence_classification", "SYNTHETIC_ROLE_PROJECTION"),
            input_index=int(value.get("input_index", input_index)),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "comparison_subject_id": self.comparison_subject_id,
            "role_ids": list(self.role_ids),
            "input_role_ids": list(self.input_role_ids),
            "duplicate_role_ids": list(self.duplicate_role_ids),
            "display_safe_label": self.display_safe_label,
            "evidence_classification": self.evidence_classification,
            "input_index": self.input_index,
        }


@dataclass(frozen=True, slots=True)
class RoleComparisonQuery:
    """One immutable comparison request over explicit role-set projections."""

    query_id: str
    comparison_intent: str
    guild_id: str
    compared_subjects: tuple[RoleComparisonSubject, ...]
    target_kind: str
    target_key: str | None = None
    capability_keys: tuple[str, ...] = ()
    context_type: str = "GUILD"
    context_id: str | None = None
    parent_id: str | None = None
    thread_id: str | None = None
    thread_type: str | None = None
    target_type: str | None = None
    target_id: str | None = None
    snapshot: Mapping[str, Any] | None = None
    projection_assumptions: Mapping[str, Any] | None = None
    explanation_mode: str = "SIMPLE"
    presentation_profile: str = "SIMPLE_CARD"
    disclosure_policy: str = "SAFE_DEFAULT"
    labels: Mapping[str, str] | None = None
    evidence_classifications: tuple[str, ...] = ("SYNTHETIC_ROLE_PROJECTION",)
    verification_statuses: tuple[str, ...] = ("SYNTHETIC_ROLE_PROJECTION",)
    source_references: tuple[str, ...] = ()
    stage5_pass3_contract_version: str = STAGE5_PASS3_CONTRACT_VERSION
    role_comparison_query_contract_version: str = ROLE_COMPARISON_QUERY_CONTRACT_VERSION
    expected_stage5_pass1_contract: str = STAGE5_PASS1_CONTRACT_VERSION
    expected_doctor_query_contract: str = DOCTOR_QUERY_CONTRACT_VERSION
    permission_definition_version: str = PERMISSION_DEFINITION_VERSION
    capability_registry_version: str = CAPABILITY_REGISTRY_VERSION
    action_rules_version: str = ACTION_RULES_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "query_id", _text(self.query_id) or "")
        object.__setattr__(self, "comparison_intent", _upper(self.comparison_intent) or "")
        object.__setattr__(self, "guild_id", _snowflake(self.guild_id) or str(self.guild_id))
        object.__setattr__(self, "target_kind", _upper(self.target_kind) or "")
        object.__setattr__(self, "target_key", _text(self.target_key))
        object.__setattr__(self, "capability_keys", tuple(sorted({str(item).strip() for item in self.capability_keys if str(item).strip()})))
        object.__setattr__(self, "context_type", _upper(self.context_type) or "GUILD")
        for field_name in ("context_id", "parent_id", "thread_id", "target_id"):
            object.__setattr__(self, field_name, _snowflake(getattr(self, field_name)))
        for field_name in ("thread_type", "target_type", "explanation_mode", "presentation_profile", "disclosure_policy"):
            object.__setattr__(self, field_name, _upper(getattr(self, field_name)))
        assumptions = dict(DEFAULT_PROJECTION_ASSUMPTIONS)
        if isinstance(self.projection_assumptions, Mapping):
            assumptions.update({str(key): value for key, value in self.projection_assumptions.items()})
        ordered_subjects = tuple(
            sorted(
                self.compared_subjects,
                key=lambda item: (
                    tuple((0, int(role)) if role.isdecimal() else (1, role) for role in item.role_ids),
                    item.comparison_subject_id,
                ),
            )
        )
        object.__setattr__(self, "compared_subjects", ordered_subjects)
        object.__setattr__(self, "projection_assumptions", _freeze(assumptions))
        object.__setattr__(self, "snapshot", _freeze(self.snapshot) if self.snapshot is not None else None)
        object.__setattr__(self, "labels", _freeze(self.labels or {}))
        object.__setattr__(self, "evidence_classifications", tuple(sorted({str(item) for item in self.evidence_classifications if str(item)})))
        object.__setattr__(self, "verification_statuses", tuple(sorted({str(item) for item in self.verification_statuses if str(item)})))
        object.__setattr__(self, "source_references", tuple(sorted({str(item) for item in self.source_references if str(item)})))

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "RoleComparisonQuery":
        if not isinstance(value, Mapping):
            raise RoleComparisonQueryError("ROLE_QUERY_NOT_MAPPING")
        raw_subjects = value.get("compared_subjects", value.get("subjects", ()))
        if isinstance(raw_subjects, Mapping):
            raw_subjects = tuple(raw_subjects.values())
        if isinstance(raw_subjects, str) or not isinstance(raw_subjects, Sequence):
            raw_subjects = ()
        subjects = tuple(
            item if isinstance(item, RoleComparisonSubject) else RoleComparisonSubject.from_mapping(item, input_index=index)
            for index, item in enumerate(raw_subjects)
        )
        capability_keys = value.get("capability_keys", value.get("target_keys", ()))
        if isinstance(capability_keys, str):
            capability_keys = (capability_keys,)
        if not isinstance(capability_keys, Sequence):
            capability_keys = ()
        return cls(
            query_id=value.get("query_id", ""),
            comparison_intent=value.get("comparison_intent", value.get("intent", "")),
            guild_id=value.get("guild_id"),
            compared_subjects=subjects,
            target_kind=value.get("target_kind", ""),
            target_key=value.get("target_key"),
            capability_keys=tuple(str(item) for item in capability_keys),
            context_type=value.get("context_type", "GUILD"),
            context_id=value.get("context_id"),
            parent_id=value.get("parent_id"),
            thread_id=value.get("thread_id"),
            thread_type=value.get("thread_type"),
            target_type=value.get("target_type"),
            target_id=value.get("target_id"),
            snapshot=value.get("snapshot"),
            projection_assumptions=value.get("projection_assumptions"),
            explanation_mode=value.get("explanation_mode", "SIMPLE"),
            presentation_profile=value.get("presentation_profile", "SIMPLE_CARD"),
            disclosure_policy=value.get("disclosure_policy", "SAFE_DEFAULT"),
            labels=value.get("labels", {}),
            evidence_classifications=value.get("evidence_classifications", ("SYNTHETIC_ROLE_PROJECTION",)),
            verification_statuses=value.get("verification_statuses", ("SYNTHETIC_ROLE_PROJECTION",)),
            source_references=value.get("source_references", ()),
            stage5_pass3_contract_version=value.get("stage5_pass3_contract_version", STAGE5_PASS3_CONTRACT_VERSION),
            role_comparison_query_contract_version=value.get("role_comparison_query_contract_version", ROLE_COMPARISON_QUERY_CONTRACT_VERSION),
            expected_stage5_pass1_contract=value.get("expected_stage5_pass1_contract", STAGE5_PASS1_CONTRACT_VERSION),
            expected_doctor_query_contract=value.get("expected_doctor_query_contract", DOCTOR_QUERY_CONTRACT_VERSION),
            permission_definition_version=value.get("permission_definition_version", PERMISSION_DEFINITION_VERSION),
            capability_registry_version=value.get("capability_registry_version", CAPABILITY_REGISTRY_VERSION),
            action_rules_version=value.get("action_rules_version", ACTION_RULES_VERSION),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "stage5_pass3_contract_version": self.stage5_pass3_contract_version,
            "role_comparison_query_contract_version": self.role_comparison_query_contract_version,
            "expected_stage5_pass1_contract": self.expected_stage5_pass1_contract,
            "expected_doctor_query_contract": self.expected_doctor_query_contract,
            "permission_definition_version": self.permission_definition_version,
            "capability_registry_version": self.capability_registry_version,
            "action_rules_version": self.action_rules_version,
            "query_id": self.query_id,
            "comparison_intent": self.comparison_intent,
            "guild_id": self.guild_id,
            "compared_subjects": [subject.as_dict() for subject in self.compared_subjects],
            "target_kind": self.target_kind,
            "target_key": self.target_key,
            "capability_keys": list(self.capability_keys),
            "context_type": self.context_type,
            "context_id": self.context_id,
            "parent_id": self.parent_id,
            "thread_id": self.thread_id,
            "thread_type": self.thread_type,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "snapshot": _thaw(self.snapshot),
            "projection_assumptions": _thaw(self.projection_assumptions),
            "explanation_mode": self.explanation_mode,
            "presentation_profile": self.presentation_profile,
            "disclosure_policy": self.disclosure_policy,
            "labels": _thaw(self.labels),
            "evidence_classifications": list(self.evidence_classifications),
            "verification_statuses": list(self.verification_statuses),
            "source_references": list(self.source_references),
        }


def _snapshot_roles(snapshot: Mapping[str, Any] | None) -> tuple[Mapping[str, Any], ...]:
    if not isinstance(snapshot, Mapping):
        return ()
    roles = snapshot.get("roles", ())
    if isinstance(roles, Mapping):
        roles = tuple(roles.values())
    if not isinstance(roles, Sequence) or isinstance(roles, (str, bytes, bytearray)):
        return ()
    return tuple(item for item in roles if isinstance(item, Mapping))


def _guild_id(snapshot: Mapping[str, Any] | None) -> str | None:
    if not isinstance(snapshot, Mapping):
        return None
    direct = _snowflake(snapshot.get("guild_id"))
    if direct:
        return direct
    guild = snapshot.get("guild")
    return _snowflake(guild.get("id")) if isinstance(guild, Mapping) else None


def _everyone_id(snapshot: Mapping[str, Any] | None, roles: Sequence[Mapping[str, Any]]) -> str | None:
    guild = _guild_id(snapshot)
    for role in roles:
        if role.get("is_everyone") is True:
            return _snowflake(role.get("id"))
    return guild


def _role_keys() -> tuple[set[str], set[str], set[str]]:
    raw = {flag.name for flag in KNOWN_PERMISSION_FLAGS}
    capabilities = {definition.capability_key for definition in DEFAULT_CAPABILITY_REGISTRY.capabilities}
    actions = set(ACTION_RULES_BY_KEY)
    return raw, capabilities, actions


def validate_role_comparison_query(value: RoleComparisonQuery | Mapping[str, Any]) -> tuple[str, ...]:
    if isinstance(value, RoleComparisonQuery):
        query = value
        raw = query.as_dict()
    elif isinstance(value, Mapping):
        raw = deepcopy(dict(value))
        try:
            query = RoleComparisonQuery.from_mapping(value)
        except (RoleComparisonQueryError, TypeError, ValueError) as exc:
            return (f"ROLE_QUERY_CONSTRUCTION:{exc}",)
    else:
        return ("ROLE_QUERY_NOT_MAPPING",)

    errors = list(_scan_forbidden(raw))
    if not query.query_id:
        errors.append("ROLE_QUERY_ID_MISSING")
    if query.stage5_pass3_contract_version != STAGE5_PASS3_CONTRACT_VERSION:
        errors.append("STAGE5_PASS3_CONTRACT_UNSUPPORTED")
    if query.role_comparison_query_contract_version != ROLE_COMPARISON_QUERY_CONTRACT_VERSION:
        errors.append("ROLE_COMPARISON_QUERY_CONTRACT_UNSUPPORTED")
    if query.expected_stage5_pass1_contract != STAGE5_PASS1_CONTRACT_VERSION:
        errors.append("STAGE5_PASS1_EXPECTATION_MISMATCH")
    if query.expected_doctor_query_contract != DOCTOR_QUERY_CONTRACT_VERSION:
        errors.append("DOCTOR_QUERY_EXPECTATION_MISMATCH")
    if query.permission_definition_version != PERMISSION_DEFINITION_VERSION:
        errors.append("PERMISSION_DEFINITION_MISMATCH")
    if query.capability_registry_version != CAPABILITY_REGISTRY_VERSION:
        errors.append("CAPABILITY_REGISTRY_MISMATCH")
    if query.action_rules_version != ACTION_RULES_VERSION:
        errors.append("ACTION_RULES_VERSION_MISMATCH")
    if query.comparison_intent not in ROLE_COMPARISON_INTENTS:
        errors.append("ROLE_COMPARISON_INTENT_UNSUPPORTED")
    if query.target_kind not in ROLE_COMPARISON_TARGET_KINDS:
        errors.append("ROLE_COMPARISON_TARGET_KIND_UNSUPPORTED")
    if not _snowflake(query.guild_id):
        errors.append("ROLE_GUILD_ID_INVALID")
    if len(query.compared_subjects) < 2:
        errors.append("ROLE_SUBJECT_COUNT_TOO_SMALL")
    if len(query.compared_subjects) > 10:
        errors.append("ROLE_SUBJECT_COUNT_TOO_LARGE")
    subject_ids = [subject.comparison_subject_id for subject in query.compared_subjects]
    if any(not item for item in subject_ids):
        errors.append("ROLE_SUBJECT_ID_MISSING")
    if len(set(subject_ids)) != len(subject_ids):
        errors.append("ROLE_SUBJECT_ID_DUPLICATE")
    if query.context_type not in ROLE_CONTEXT_TYPES:
        errors.append("ROLE_CONTEXT_TYPE_UNSUPPORTED")
    if query.context_type != "GUILD" and not query.context_id:
        errors.append("ROLE_CONTEXT_ID_MISSING")
    if query.target_kind == RAW_PERMISSION and query.comparison_intent not in {COMPARE_RAW_ROLE_PERMISSIONS, ENUMERATE_ROLE_DIFFERENCES}:
        errors.append("RAW_PERMISSION_INTENT_MISMATCH")
    if query.target_kind == CAPABILITY and query.comparison_intent not in {COMPARE_CONTEXT_CAPABILITY, ENUMERATE_ROLE_DIFFERENCES}:
        errors.append("CAPABILITY_INTENT_MISMATCH")
    if query.target_kind == CAPABILITY_SET and query.comparison_intent not in {COMPARE_CAPABILITY_SET, ENUMERATE_ROLE_DIFFERENCES}:
        errors.append("CAPABILITY_SET_INTENT_MISMATCH")
    if query.target_kind == ACTION and query.comparison_intent not in {COMPARE_ACTION_AUTHORITY, ENUMERATE_ROLE_DIFFERENCES}:
        errors.append("ACTION_INTENT_MISMATCH")
    raw_keys, capability_keys, action_keys = _role_keys()
    if query.target_kind == RAW_PERMISSION and query.target_key not in raw_keys:
        errors.append("RAW_PERMISSION_UNREGISTERED")
    if query.target_kind == CAPABILITY and query.target_key not in capability_keys:
        errors.append("CAPABILITY_UNREGISTERED")
    if query.target_kind == CAPABILITY_SET:
        if not query.capability_keys:
            errors.append("CAPABILITY_SET_EMPTY")
        if len(query.capability_keys) > 52:
            errors.append("CAPABILITY_SET_TOO_LARGE")
        if any(key not in capability_keys for key in query.capability_keys):
            errors.append("CAPABILITY_SET_UNREGISTERED")
    if query.target_kind == ACTION:
        rule = ACTION_RULES_BY_KEY.get(query.target_key or "")
        if rule is None:
            errors.append("ACTION_UNREGISTERED")
        else:
            if query.target_type not in rule.target_types:
                errors.append("ACTION_TARGET_TYPE_INCOMPATIBLE")
            if query.context_type not in {"GUILD", "CATEGORY", "PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"} and query.context_type not in rule.context_types:
                errors.append("ACTION_CONTEXT_TYPE_INCOMPATIBLE")
    roles = _snapshot_roles(query.snapshot)
    by_id = {_snowflake(role.get("id")): role for role in roles if _snowflake(role.get("id"))}
    if _guild_id(query.snapshot) is not None and _guild_id(query.snapshot) != query.guild_id:
        errors.append("ROLE_SNAPSHOT_GUILD_MISMATCH")
    everyone_id = _everyone_id(query.snapshot, roles)
    for subject in query.compared_subjects:
        if not subject.role_ids:
            errors.append(f"ROLE_SET_EMPTY:{subject.comparison_subject_id}")
        for role_id in subject.role_ids:
            if not _snowflake(role_id):
                errors.append(f"ROLE_ID_INVALID:{subject.comparison_subject_id}")
            elif role_id not in by_id:
                errors.append(f"ROLE_ID_UNKNOWN:{role_id}")
        if everyone_id is None:
            errors.append("EVERYONE_ROLE_UNRESOLVED")
    if not isinstance(query.projection_assumptions, Mapping):
        errors.append("PROJECTION_ASSUMPTIONS_MISSING")
    return tuple(sorted(set(errors)))


__all__ = [
    "ACTION",
    "CAPABILITY",
    "CAPABILITY_SET",
    "COMPARE_ACTION_AUTHORITY",
    "COMPARE_CAPABILITY_SET",
    "COMPARE_CONTEXT_CAPABILITY",
    "COMPARE_RAW_ROLE_PERMISSIONS",
    "DEFAULT_PROJECTION_ASSUMPTIONS",
    "ENUMERATE_ROLE_DIFFERENCES",
    "RAW_PERMISSION",
    "ROLE_COMPARISON_INTENTS",
    "ROLE_COMPARISON_TARGET_KINDS",
    "ROLE_CONTEXT_TYPES",
    "RoleComparisonQuery",
    "RoleComparisonQueryError",
    "RoleComparisonSubject",
    "validate_role_comparison_query",
]
