"""Pure bounded GET policy; this module never performs acquisition."""
TARGETED_MEMBER_POLICY_CONTRACT='GUILD-DOCTOR-DISCORD-TARGETED-MEMBER-POLICY-0.1'
def decide_targeted_fetch(*, authorized:bool, selected_member_id:str|None, requested_count:int)->str:
    if not authorized:return 'DENY_NOT_OWNER'
    if not selected_member_id:return 'NOT_REQUIRED'
    return 'PERMIT_ONE_READ_ONLY_GET' if requested_count==1 else 'DENY_UNBOUNDED_MEMBER_ACQUISITION'
