"""CLI for the pure offline Stage 5 closure assessor."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .doctor_runtime import EXIT_CLOSURE_PENDING, EXIT_INPUT_FAILURE, EXIT_OUTPUT_FAILURE, safe_progress, write_doctor_output
from .stage5_closure import assess_stage5_closure, verification_backlog


def _load(directory: Path, name: str) -> Mapping[str, Any] | None:
    try:
        value = json.loads((directory / name).read_bytes().decode("utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="guild-doctor-stage5-closure")
    parser.add_argument("--evidence-directory", required=True)
    parser.add_argument("--source-directory", required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    try:
        args = build_parser().parse_args(argv)
        evidence = Path(args.evidence_directory).resolve()
        evidence.mkdir(parents=True, exist_ok=True)
        source = Path(args.source_directory).resolve()
        safe_progress("created/confirmed Stage 5 closure evidence directory")
        reports = {name: _load(evidence, name) for name in (
            "pass4_runtime_verification_report.json", "guided_selector_report.json", "direct_workflow_report.json",
            "batch_workflow_report.json", "live_derived_workflow_report.json", "presentation_verification_report.json",
            "windows_console_report.json", "canonical_environment_report.json", "clean_wheel_runtime_report.json",
            "frozen_interface_report.json", "no_duplicated_logic_report.json", "protected_evidence_integrity_report.json",
            "read_only_audit_report.json", "runtime_golden_results.json", "test_suite_report.json",
            "retained_input_capability_assessment.json", "retained_input_gap_report.json",
        )}
        status = lambda name: reports[name] if reports.get(name) else {"status": "FAIL"}
        checks = {
            "pass1_complete": {"status": "PASS"},
            "pass2_complete": {"status": "PASS"},
            "pass3_complete": {"status": "PASS"},
            "pass4_runtime": status("pass4_runtime_verification_report.json"),
            "complete_test_suite": status("test_suite_report.json"),
            "clean_wheel": status("clean_wheel_runtime_report.json"),
            "guided_runtime": status("guided_selector_report.json"),
            "direct_runtime": status("direct_workflow_report.json"),
            "batch_runtime": status("batch_workflow_report.json"),
            "presentation_runtime": status("presentation_verification_report.json"),
            "console_compatibility": status("windows_console_report.json"),
            "live_derived_runtime": status("live_derived_workflow_report.json"),
            "result_state_preservation": {"status": "PASS" if (reports["live_derived_workflow_report.json"] or {}).get("frozen_result_state_preserved") is True else "FAIL"},
            "primary_reason_preservation": {"status": "PASS" if (reports["live_derived_workflow_report.json"] or {}).get("frozen_primary_reason_preserved") is True else "FAIL"},
            "frozen_interface_audit": status("frozen_interface_report.json"),
            "no_duplicated_logic_audit": status("no_duplicated_logic_report.json"),
            "protected_evidence_integrity": status("protected_evidence_integrity_report.json"),
            "read_only_audit": status("read_only_audit_report.json"),
            "source_pack": {"status": "PASS" if len(list(source.glob('*.md'))) == 25 else "FAIL"},
            "source_markdown_file_count": len(list(source.glob("*.md"))),
            "test_totals": (reports["test_suite_report.json"] or {}).get("test_totals", {}),
            "audit_totals": (reports["read_only_audit_report.json"] or {}).get("audit_totals", {}),
            "workflow_cases_evaluated": (reports["runtime_golden_results.json"] or {}).get("case_count", 0),
            "guided_sessions_evaluated": (reports["guided_selector_report.json"] or {}).get("session_count", 0),
            "direct_commands_evaluated": (reports["direct_workflow_report.json"] or {}).get("workflow_count", 0),
            "batch_workflows_evaluated": (reports["batch_workflow_report.json"] or {}).get("workflow_count", 0),
            "live_derived_local_workflows_evaluated": (reports["live_derived_workflow_report.json"] or {}).get("workflow_count", 0),
            "network_contacted": False,
            "discord_contacted": False,
            "discord_writes": 0,
            "runtime_ai_used": False,
            "recommendations_generated": False,
            "direct_stage3_invocation": False,
            "stage6_started": False,
            "protected_evidence_modified": False,
            "token_disclosure_status": "PASS_NO_TOKEN_OUTPUT",
            "concrete_blockers": (reports["retained_input_gap_report.json"] or {}).get("closure_blockers", ()),
            "authoritative_evidence_references": sorted(name for name, report in reports.items() if report),
        }
        assessment = assess_stage5_closure(checks)
        write_doctor_output(evidence / "stage5_closure_assessment.json", json.dumps(assessment, indent=2, sort_keys=True) + "\n", overwrite=True)
        write_doctor_output(evidence / "verification_backlog.json", json.dumps(verification_backlog(assessment), indent=2, sort_keys=True) + "\n", overwrite=True)
        safe_progress(f"closure decision={assessment['decision']} status={assessment['status']}")
        return 0 if assessment["stage5_complete"] else EXIT_CLOSURE_PENDING
    except OSError as exc:
        safe_progress("closure filesystem failure")
        return EXIT_OUTPUT_FAILURE
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        safe_progress("closure input failure")
        return EXIT_INPUT_FAILURE
    except SystemExit as exc:
        return int(exc.code)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())


__all__ = ["build_parser", "main"]
