"""Pure deterministic population extraction and candidate normalization."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from .canonical import canonical_json
from .doctor_enumeration_query import (
    BOT,
    COMPLETE_GUILD_MEMBERS,
    DoctorEnumerationQuery,
    EXPLICIT_CANDIDATES,
    HUMAN,
    SNAPSHOT_MEMBERS,
)


EVALUATED = "EVALUATED"
EXCLUDED_BY_POLICY = "EXCLUDED_BY_POLICY"
DUPLICATE_INPUT = "DUPLICATE_INPUT"
INVALID_CANDIDATE = "INVALID_CANDIDATE"
MISSING_MATERIAL_DATA = "MISSING_MATERIAL_DATA"
CANDIDATE_STATUSES = frozenset({EVALUATED, EXCLUDED_BY_POLICY, DUPLICATE_INPUT, INVALID_CANDIDATE, MISSING_MATERIAL_DATA})


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        from types import MappingProxyType

        return MappingProxyType({str(k): _freeze(v) for k, v in sorted(value.items(), key=lambda item: str(item[0]))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(v) for v in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(v) for v in sorted(value, key=str))
    return value


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _thaw(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_thaw(v) for v in value]
    return value


def _record_health(record: Mapping[str, Any]) -> tuple[bool, tuple[str, ...]]:
    health = record.get("member_health", record.get("health", record.get("input_health")))
    missing: list[str] = []
    partial = False
    if isinstance(health, Mapping):
        status = str(health.get("status", health.get("data_completeness", health.get("completeness", "")))).upper()
        partial = status in {"PARTIAL", "INCOMPLETE", "UNKNOWN", "NOT_REQUESTED"}
        values = health.get("missing_fields", health.get("missing_evidence", ()))
        if isinstance(values, Sequence) and not isinstance(values, (str, bytes, bytearray)):
            missing.extend(str(v) for v in values)
    elif health is not None:
        partial = True
    if "bot" not in record:
        partial = True
        missing.append("bot")
    if "role_ids" not in record and "assigned_role_ids" not in record:
        partial = True
        missing.append("assigned_role_ids")
    if "timeout_state" not in record:
        partial = True
        missing.append("timeout_state")
    return partial, tuple(sorted(set(missing)))


def _role_ids(record: Mapping[str, Any]) -> tuple[str, ...] | None:
    values = record.get("assigned_role_ids", record.get("role_ids"))
    if values is None:
        return None
    if isinstance(values, str) or not isinstance(values, Sequence):
        return None
    normalized: list[str] = []
    for value in values:
        identifier = _snowflake(value)
        if identifier is None:
            return None
        normalized.append(identifier)
    return tuple(sorted(set(normalized)))


def _snapshot_member_records(query: DoctorEnumerationQuery) -> tuple[Mapping[str, Any], ...] | None:
    if query.population_source == EXPLICIT_CANDIDATES:
        return tuple(item for item in query.candidates if isinstance(item, Mapping))
    if not isinstance(query.snapshot, Mapping):
        return None
    for key in ("members", "member_records", "member_data"):
        value = query.snapshot.get(key)
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            return tuple(item for item in value if isinstance(item, Mapping))
    return None


def _guild_owner_id(query: DoctorEnumerationQuery) -> str | None:
    if not isinstance(query.snapshot, Mapping):
        return None
    direct = _snowflake(query.snapshot.get("owner_id"))
    if direct:
        return direct
    guild = query.snapshot.get("guild")
    return _snowflake(guild.get("owner_id")) if isinstance(guild, Mapping) else None


def _label(query: DoctorEnumerationQuery, record: Mapping[str, Any], identifier: str, ordinal: int) -> str:
    supplied = query.display_safe_labels or {}
    value = supplied.get(identifier) if isinstance(supplied, Mapping) else None
    if not isinstance(value, str) or not value.strip():
        for key in ("display_label", "display_name", "username", "name"):
            value = record.get(key)
            if isinstance(value, str) and value.strip():
                break
        else:
            value = f"member-{ordinal}"
    return str(value).replace("<", "").replace(">", "").replace("@", "")[:100] or f"member-{ordinal}"


@dataclass(frozen=True, slots=True)
class CandidateDisposition:
    candidate_id: str | None
    candidate_kind: str | None
    record: Mapping[str, Any]
    original_indexes: tuple[int, ...]
    status: str
    reason: str | None
    display_label: str
    partial_data: bool
    missing_fields: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "candidate_kind": self.candidate_kind,
            "record": _thaw(self.record),
            "original_indexes": list(self.original_indexes),
            "status": self.status,
            "reason": self.reason,
            "display_label": self.display_label,
            "partial_data": self.partial_data,
            "missing_fields": list(self.missing_fields),
        }


@dataclass(frozen=True, slots=True)
class PopulationNormalization:
    source_records: tuple[Mapping[str, Any], ...]
    dispositions: tuple[CandidateDisposition, ...]
    evaluable: tuple[CandidateDisposition, ...]
    owner_id: str | None
    population_fingerprint: str
    coverage_complete: bool
    coverage_reasons: tuple[str, ...]
    member_collection_status: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_records": [_thaw(v) for v in self.source_records],
            "dispositions": [v.as_dict() for v in self.dispositions],
            "evaluable": [v.as_dict() for v in self.evaluable],
            "owner_id": self.owner_id,
            "population_fingerprint": self.population_fingerprint,
            "coverage_complete": self.coverage_complete,
            "coverage_reasons": list(self.coverage_reasons),
            "member_collection_status": self.member_collection_status,
        }


def normalize_population(query: DoctorEnumerationQuery) -> PopulationNormalization:
    """Normalize every supplied record, retaining every disposition."""

    source_records = _snapshot_member_records(query) or ()
    owner_id = _guild_owner_id(query)
    policy = query.candidate_inclusion_policy or {}
    exclusions = set(query.explicit_exclusion_ids)
    by_id: dict[str, list[tuple[int, Mapping[str, Any], str | None]]] = {}
    for index, record in enumerate(source_records):
        identifier = _snowflake(record.get("id", record.get("member_id")))
        kind = None if "bot" not in record else BOT if record.get("bot") is True else HUMAN if record.get("bot") is False else None
        by_id.setdefault(identifier or f"__invalid__{index}", []).append((index, record, kind))

    dispositions: list[CandidateDisposition] = []
    unique_records: list[tuple[str, int, Mapping[str, Any], str | None]] = []
    duplicate_ids: set[str] = set()
    contradictory_ids: set[str] = set()
    for identifier, entries in by_id.items():
        if identifier.startswith("__invalid__"):
            continue
        normalized = []
        for _, record, _ in entries:
            normalized_record = dict(record)
            for key in ("display_label", "display_name", "username", "name"):
                normalized_record.pop(key, None)
            normalized.append(canonical_json(_thaw(normalized_record)))
        if len(set(normalized)) > 1:
            contradictory_ids.add(identifier)
        elif len(entries) > 1:
            duplicate_ids.add(identifier)
        first_index, first_record, first_kind = entries[0]
        unique_records.append((identifier, first_index, first_record, first_kind))

    unique_records.sort(key=lambda item: int(item[0]))
    ordinal_by_id = {identifier: index + 1 for index, (identifier, _, _, _) in enumerate(unique_records)}

    for index, record in enumerate(source_records):
        identifier = _snowflake(record.get("id", record.get("member_id")))
        partial, missing_fields = _record_health(record)
        kind = None if "bot" not in record else BOT if record.get("bot") is True else HUMAN if record.get("bot") is False else None
        label = _label(query, record, identifier or "", ordinal_by_id.get(identifier or "", index + 1))
        status = EVALUATED
        reason: str | None = None
        if identifier is None:
            status, reason = INVALID_CANDIDATE, "MEMBER_ID_INVALID"
        elif identifier in contradictory_ids:
            status, reason = INVALID_CANDIDATE, "DUPLICATE_CONTRADICTORY_STATE"
        elif identifier in duplicate_ids:
            first_index = min(item[0] for item in by_id[identifier])
            if index != first_index:
                status, reason = DUPLICATE_INPUT, "DUPLICATE_IDENTICAL_RECORD"
        if status == EVALUATED:
            supplied_guild_id = _snowflake(record.get("guild_id"))
            if supplied_guild_id is not None and supplied_guild_id != query.guild_id:
                status, reason = INVALID_CANDIDATE, "GUILD_MISMATCH"
            elif _role_ids(record) is None and ("role_ids" in record or "assigned_role_ids" in record):
                status, reason = INVALID_CANDIDATE, "ROLE_ID_INVALID"
            elif kind is None:
                status, reason = MISSING_MATERIAL_DATA, "BOT_FLAG_MISSING_OR_INVALID"
            elif identifier in exclusions:
                status, reason = EXCLUDED_BY_POLICY, "EXPLICIT_EXCLUSION"
            elif kind == HUMAN and policy.get("include_humans") is not True:
                status, reason = EXCLUDED_BY_POLICY, "HUMAN_POLICY_EXCLUDED"
            elif kind == BOT and policy.get("include_bots") is not True:
                status, reason = EXCLUDED_BY_POLICY, "BOT_POLICY_EXCLUDED"
            elif owner_id == identifier and policy.get("include_owner") is not True:
                status, reason = EXCLUDED_BY_POLICY, "OWNER_POLICY_EXCLUDED"
            elif str(record.get("timeout_state", "")).upper() in {"ACTIVE", "TIMED_OUT"} and policy.get("include_timed_out_members") is not True:
                status, reason = EXCLUDED_BY_POLICY, "TIMEOUT_POLICY_EXCLUDED"
            elif partial and policy.get("include_members_with_partial_data") is not True:
                status, reason = EXCLUDED_BY_POLICY, "PARTIAL_DATA_POLICY_EXCLUDED"
        dispositions.append(
            CandidateDisposition(
                candidate_id=identifier,
                candidate_kind=kind,
                record=_freeze(record),
                original_indexes=(index,),
                status=status,
                reason=reason,
                display_label=label,
                partial_data=partial,
                missing_fields=missing_fields,
            )
        )

    # A contradictory duplicate is represented on each supplied occurrence;
    # identical duplicates remain visible but only the first is evaluated.
    dispositions.sort(key=lambda item: item.original_indexes[0])
    evaluable = tuple(
        sorted(
            (item for item in dispositions if item.status == EVALUATED),
            key=lambda item: int(item.candidate_id) if item.candidate_id and item.candidate_id.isdecimal() else 0,
        )
    )
    health = query.member_collection_health or {}
    health_status = str(health.get("status", health.get("structural_completeness", "UNKNOWN"))).upper() if isinstance(health, Mapping) else "UNKNOWN"
    expected_agrees = query.expected_member_count is None or query.retrieved_member_count == query.expected_member_count
    no_exclusions = not any(item.status in {EXCLUDED_BY_POLICY, INVALID_CANDIDATE, DUPLICATE_INPUT, MISSING_MATERIAL_DATA} for item in dispositions)
    complete, reasons = True, []
    if query.population_coverage != COMPLETE_GUILD_MEMBERS:
        complete = False
        reasons.append("POPULATION_COVERAGE_NOT_COMPLETE")
    if health_status != "COMPLETE":
        complete = False
        reasons.append("MEMBER_COLLECTION_NOT_COMPLETE")
    if not expected_agrees:
        complete = False
        reasons.append("EXPECTED_RETRIEVED_COUNT_MISMATCH")
    if not no_exclusions:
        complete = False
        reasons.append("CANDIDATE_NOT_EVALUATED")
    if query.expected_member_count is not None and query.expected_member_count != len(source_records):
        complete = False
        reasons.append("EXPECTED_SUPPLIED_COUNT_MISMATCH")
    canonical_records = []
    for item in sorted(dispositions, key=lambda value: (value.candidate_id is None, int(value.candidate_id) if value.candidate_id and value.candidate_id.isdecimal() else 0, value.status)):
        record = dict(item.as_dict())
        record.pop("original_indexes", None)
        record.pop("display_label", None)
        canonical_records.append(record)
    population_fingerprint = canonical_json(
        {
            "guild_id": query.guild_id,
            "coverage": query.population_coverage,
            "records": canonical_records,
            "expected_member_count": query.expected_member_count,
            "retrieved_member_count": query.retrieved_member_count,
        }
    )
    import hashlib

    fingerprint = hashlib.sha256(population_fingerprint.encode("utf-8")).hexdigest()
    return PopulationNormalization(
        source_records=tuple(_freeze(v) for v in source_records),
        dispositions=tuple(dispositions),
        evaluable=evaluable,
        owner_id=owner_id,
        population_fingerprint=fingerprint,
        coverage_complete=complete,
        coverage_reasons=tuple(sorted(set(reasons))),
        member_collection_status=health_status,
    )


__all__ = [
    "CANDIDATE_STATUSES",
    "DUPLICATE_INPUT",
    "EVALUATED",
    "EXCLUDED_BY_POLICY",
    "INVALID_CANDIDATE",
    "MISSING_MATERIAL_DATA",
    "CandidateDisposition",
    "PopulationNormalization",
    "normalize_population",
]
