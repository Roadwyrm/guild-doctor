"""Versioned, additive server-map report artifact."""

from __future__ import annotations

from typing import Any, Mapping

from .canonical import sha256_hex
from .server_map import build_server_map


SERVER_MAP_REPORT_CONTRACT = "GUILD-DOCTOR-SERVER-MAP-0.1"


def build_server_map_report(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    """Build a privacy-safe, independently versioned visual-report payload."""
    server_map = build_server_map(snapshot)
    payload = {
        "artifact_contract": SERVER_MAP_REPORT_CONTRACT,
        "artifact_type": "SERVER_MAP",
        "map": server_map,
        "privacy_policy": "NAMES_AND_STATES_ONLY",
    }
    return {**payload, "artifact_fingerprint": sha256_hex(payload)}


def build_report_bundle(report: Mapping[str, Any], snapshot: Mapping[str, Any]) -> dict[str, Any]:
    """Attach the additive map artifact without altering the base report."""
    if not isinstance(report, Mapping):
        raise TypeError("report must be a mapping")
    map_report = build_server_map_report(snapshot)
    bundle = {
        "bundle_contract": "GUILD-DOCTOR-REPORT-BUNDLE-0.1",
        "base_report": dict(report),
        "artifacts": {"server_map": map_report},
    }
    return {**bundle, "bundle_fingerprint": sha256_hex(bundle)}


__all__ = ["SERVER_MAP_REPORT_CONTRACT", "build_report_bundle", "build_server_map_report"]
