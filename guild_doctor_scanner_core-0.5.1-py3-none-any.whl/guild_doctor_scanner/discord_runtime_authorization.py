"""Runtime wiring delegates exactly to the frozen owner authorization contract."""
from .discord_authorization_contract import AuthorizationInput,authorize
RUNTIME_AUTHORIZATION_CONTRACT="GUILD-DOCTOR-DISCORD-RUNTIME-AUTHORIZATION-0.1"
def authorize_runtime(*,guild_present:bool,guild_id:str|None,actor_id:str|None,owner_id:str|None)->str:return authorize(AuthorizationInput("GUILD" if guild_present else "DM",guild_id,actor_id,owner_id))
