"""Development CLI for Stage 2 Pass 3 member acquisition.

Targeted mode may write a normalized selected-member snapshot. Exhaustive mode
never writes member profiles; it writes only aggregate acquisition health and a
retention receipt after disposal.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

from .acquisition import ReadOnlyAcquisitionAdapter
from .canonical import canonical_json
from .discordpy_adapter import DiscordLibraryCompatibilityError, DiscordPyReadTransport
from .member_acquisition import ReadOnlyMemberAcquisitionAdapter


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run strictly read-only Guild Doctor member acquisition")
    sub = parser.add_subparsers(dest="mode", required=True)

    targeted = sub.add_parser("targeted", help="Acquire explicitly selected guild members")
    targeted.add_argument("guild_id")
    targeted.add_argument("member_ids", nargs="+")
    targeted.add_argument("--output", "-o", type=Path, required=True)
    targeted.add_argument("--envelope-output", type=Path)
    targeted.add_argument("--pretty", action="store_true")

    exhaustive = sub.add_parser("enumerate", help="Temporarily enumerate all available guild members")
    exhaustive.add_argument("guild_id")
    exhaustive.add_argument("--receipt-output", type=Path, required=True)
    exhaustive.add_argument("--health-output", type=Path)
    return parser


async def _login_transport() -> tuple[object, DiscordPyReadTransport]:
    token = os.environ.get("GUILD_DOCTOR_DISCORD_TOKEN")
    if not token:
        raise RuntimeError("GUILD_DOCTOR_DISCORD_TOKEN is not set")
    try:
        import discord
    except ImportError as exc:
        raise RuntimeError("discord.py 2.7.1 is not installed") from exc

    client = discord.Client(intents=discord.Intents.none(), max_messages=None)
    await client.__aenter__()
    try:
        await client.login(token)
        return client, DiscordPyReadTransport.from_client(client)
    except Exception:
        await client.__aexit__(None, None, None)
        raise


async def _run(args: argparse.Namespace) -> int:
    client = None
    try:
        client, transport = await _login_transport()
        structure = ReadOnlyAcquisitionAdapter(transport)
        members = ReadOnlyMemberAcquisitionAdapter(transport, structure)

        if args.mode == "targeted":
            acquisition = await members.acquire_targeted_members(args.guild_id, args.member_ids)
            if args.envelope_output:
                envelope = {
                    "guild_id": acquisition.guild_id,
                    "scan_profile": acquisition.scan_profile,
                    "normalization_error": acquisition.normalization_error,
                    "capability_report": acquisition.capability_report.as_dict(),
                    "results": {name: result.as_dict() for name, result in acquisition.results.items()},
                }
                args.envelope_output.write_text(
                    json.dumps(envelope, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                    encoding="utf-8",
                )
            if acquisition.snapshot is None:
                print(
                    f"guild-doctor-member-scan: no canonical snapshot produced: {acquisition.normalization_error}",
                    file=sys.stderr,
                )
                return 2
            data = acquisition.snapshot.as_dict()
            text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) if args.pretty else canonical_json(data)
            args.output.write_text(text + "\n", encoding="utf-8")
            return 0 if acquisition.snapshot.member_completeness == "COMPLETE" else 2

        lease = await members.enumerate_members_temporary(args.guild_id)
        try:
            acquisition = lease.acquisition
            health = {
                "guild_id": acquisition.guild_id,
                "scan_profile": acquisition.scan_profile,
                "normalization_error": acquisition.normalization_error,
                "capability_report": acquisition.capability_report.as_dict(),
                "member_collection": acquisition.results["members"].health_dict(),
                "member_completeness": (
                    acquisition.snapshot.member_completeness if acquisition.snapshot is not None else "UNKNOWN"
                ),
            }
            exit_code = 0 if health["member_completeness"] == "COMPLETE" else 2
            if args.health_output:
                args.health_output.write_text(
                    json.dumps(health, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                    encoding="utf-8",
                )
        finally:
            receipt = lease.dispose()
            args.receipt_output.write_text(
                json.dumps(receipt.as_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                encoding="utf-8",
            )
        return exit_code
    except DiscordLibraryCompatibilityError as exc:
        print(f"guild-doctor-member-scan: compatibility error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        message = " ".join(str(exc).split())[:500] or exc.__class__.__name__
        print(f"guild-doctor-member-scan: authentication/acquisition error: {message}", file=sys.stderr)
        return 1
    finally:
        if client is not None:
            await client.__aexit__(None, None, None)


def main(argv: list[str] | None = None) -> int:
    return asyncio.run(_run(build_parser().parse_args(argv)))


if __name__ == "__main__":
    raise SystemExit(main())
