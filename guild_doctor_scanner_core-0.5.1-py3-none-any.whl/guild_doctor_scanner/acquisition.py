"""Strictly read-only structural acquisition orchestration.

This module is library-independent.  A transport supplies four GET-only read
operations and this layer wraps them in Guild Doctor's acquisition envelopes before
passing the resulting bundle to the pure normalizer.
"""

from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import math
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Protocol, TypeVar

from .enums import CollectionStatus
from .errors import SnapshotError
from .normalizer import normalize_bundle

_JSON = dict[str, Any]
_T = TypeVar("_T")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def payload_sha256(payload: Any) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Bounded adapter retry policy.

    discord.py already handles route-level rate limits.  This policy exists for
    transient transport and server failures only; it never retries authorization,
    validation, not-found, or unsupported failures.
    """

    max_attempts: int = 3
    base_delay_seconds: float = 0.25
    max_delay_seconds: float = 2.0

    def delay_for_attempt(self, completed_attempts: int) -> float:
        if completed_attempts < 1:
            return 0.0
        return min(self.base_delay_seconds * (2 ** (completed_attempts - 1)), self.max_delay_seconds)


@dataclass(slots=True)
class ScanError:
    code: str
    error_type: str
    message: str
    retryable: bool
    attempt: int
    status: int | None = None
    entity_id: str | None = None


@dataclass(slots=True)
class AcquisitionResult:
    resource: str
    status: str
    requested_at: str
    completed_at: str | None
    records: Any
    expected_count: int | None
    received_count: int | None
    page_count: int | None
    cursor_complete: bool | None
    source_interface: str
    source_version: str
    http_or_library_status: str | None
    errors: list[ScanError] = field(default_factory=list)
    raw_payload_hashes: list[str] = field(default_factory=list)
    attempt_count: int = 1

    def health_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "expected_count": self.expected_count,
            "received_count": self.received_count,
            "page_count": self.page_count,
            "cursor_complete": self.cursor_complete,
            "started_at": self.requested_at,
            "completed_at": self.completed_at,
            "source_interface": self.source_interface,
            "error_codes": [error.code for error in self.errors],
        }

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class StructureAcquisition:
    guild_id: str
    started_at: str
    completed_at: str
    results: dict[str, AcquisitionResult]
    bundle: dict[str, Any]
    snapshot: Any | None
    normalization_error: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.snapshot is not None


class ReadOnlyDiscordTransport(Protocol):
    """Minimal transport surface accepted by the scanner path.

    No generic request function and no create/edit/delete methods are exposed.
    """

    source_library: str
    source_library_version: str
    source_api_version: str

    async def read_guild(self, guild_id: int) -> _JSON: ...

    async def read_roles(self, guild_id: int) -> list[_JSON]: ...

    async def read_channels(self, guild_id: int) -> list[_JSON]: ...

    async def read_active_threads(self, guild_id: int) -> _JSON: ...


class ReadOnlyAcquisitionAdapter:
    """Acquire the STRUCTURE_BASELINE profile through a GET-only transport.

    ``discord.py`` owns the underlying HTTP calls, so the adapter applies an
    explicit timeout around every transport operation.  This also bounds a
    custom or test transport that does not provide its own timeout.
    """

    __slots__ = ("_transport", "_retry", "_sleep", "_operation_timeout_seconds")

    def __init__(
        self,
        transport: ReadOnlyDiscordTransport,
        *,
        retry_policy: RetryPolicy | None = None,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
        operation_timeout_seconds: float = 30.0,
    ) -> None:
        timeout = float(operation_timeout_seconds)
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("operation_timeout_seconds must be a finite positive number")
        self._transport = transport
        self._retry = retry_policy or RetryPolicy()
        self._sleep = sleep
        self._operation_timeout_seconds = timeout

    async def acquire_structure(self, guild_id: int | str) -> StructureAcquisition:
        guild_int = self._parse_guild_id(guild_id)
        started_at = utc_now()

        # Sequential acquisition keeps request pressure low and creates an easy-to-audit path.
        guild_result = await self._acquire("guild", lambda: self._transport.read_guild(guild_int))
        roles_result = await self._acquire("roles", lambda: self._transport.read_roles(guild_int))
        channels_result = await self._acquire("channels", lambda: self._transport.read_channels(guild_int))
        threads_result = await self._acquire(
            "active_threads", lambda: self._transport.read_active_threads(guild_int)
        )

        results = {
            "guild": guild_result,
            "roles": roles_result,
            "channels": channels_result,
            "active_threads": threads_result,
        }
        completed_at = utc_now()
        bundle = self._build_bundle(str(guild_int), started_at, completed_at, results)

        snapshot = None
        normalization_error = None
        try:
            snapshot = normalize_bundle(bundle)
        except SnapshotError as exc:
            normalization_error = str(exc)

        return StructureAcquisition(
            guild_id=str(guild_int),
            started_at=started_at,
            completed_at=completed_at,
            results=results,
            bundle=bundle,
            snapshot=snapshot,
            normalization_error=normalization_error,
        )

    async def _acquire(self, resource: str, operation: Callable[[], Awaitable[_T]]) -> AcquisitionResult:
        requested_at = utc_now()
        errors: list[ScanError] = []
        attempts = 0

        while attempts < self._retry.max_attempts:
            attempts += 1
            try:
                payload = await asyncio.wait_for(operation(), timeout=self._operation_timeout_seconds)
                hashes = self._attach_hashes(payload)
                records, expected_count, received_count = self._extract_resource(resource, payload)
                return AcquisitionResult(
                    resource=resource,
                    status=CollectionStatus.COMPLETE.value,
                    requested_at=requested_at,
                    completed_at=utc_now(),
                    records=records,
                    expected_count=expected_count,
                    received_count=received_count,
                    page_count=1,
                    cursor_complete=True,
                    source_interface="REST",
                    source_version=self._source_version,
                    http_or_library_status="OK",
                    errors=errors,
                    raw_payload_hashes=hashes,
                    attempt_count=attempts,
                )
            except Exception as exc:  # classification is deliberately centralized
                classified = classify_exception(exc, attempt=attempts)
                errors.append(classified)
                if not classified.retryable or attempts >= self._retry.max_attempts:
                    status = (
                        CollectionStatus.UNAVAILABLE.value
                        if classified.code in {"AUTHORIZATION_DENIED", "RESOURCE_NOT_FOUND", "AUTHENTICATION_FAILED"}
                        else CollectionStatus.FAILED.value
                    )
                    return AcquisitionResult(
                        resource=resource,
                        status=status,
                        requested_at=requested_at,
                        completed_at=utc_now(),
                        records=None,
                        expected_count=None,
                        received_count=None,
                        page_count=None,
                        cursor_complete=False,
                        source_interface="REST",
                        source_version=self._source_version,
                        http_or_library_status=(str(classified.status) if classified.status is not None else None),
                        errors=errors,
                        raw_payload_hashes=[],
                        attempt_count=attempts,
                    )
                await self._sleep(self._retry.delay_for_attempt(attempts))

        raise AssertionError("retry loop exited without a result")

    @property
    def _source_version(self) -> str:
        return (
            f"{self._transport.source_library}/{self._transport.source_library_version} "
            f"Discord-API/{self._transport.source_api_version}"
        )

    @staticmethod
    def _parse_guild_id(guild_id: int | str) -> int:
        if isinstance(guild_id, bool):
            raise ValueError("guild_id must be a positive decimal snowflake")
        text = str(guild_id).strip()
        if not text.isdecimal() or int(text) <= 0:
            raise ValueError("guild_id must be a positive decimal snowflake")
        return int(text)

    @staticmethod
    def _attach_hashes(payload: Any) -> list[str]:
        hashes = [payload_sha256(payload)]
        if isinstance(payload, dict):
            if "threads" in payload and isinstance(payload["threads"], list):
                for item in payload["threads"]:
                    if isinstance(item, dict):
                        item["_payload_sha256"] = payload_sha256(item)
                        hashes.append(item["_payload_sha256"])
                for item in payload.get("members", []):
                    if isinstance(item, dict):
                        item["_payload_sha256"] = payload_sha256(item)
                        hashes.append(item["_payload_sha256"])
            else:
                payload["_payload_sha256"] = payload_sha256(payload)
        elif isinstance(payload, list):
            for item in payload:
                if isinstance(item, dict):
                    item["_payload_sha256"] = payload_sha256(item)
                    hashes.append(item["_payload_sha256"])
        return hashes

    @staticmethod
    def _extract_resource(resource: str, payload: Any) -> tuple[Any, int | None, int | None]:
        if resource == "guild":
            if not isinstance(payload, dict):
                raise TypeError("guild response must be an object")
            return payload, 1, 1
        if resource in {"roles", "channels"}:
            if not isinstance(payload, list):
                raise TypeError(f"{resource} response must be a list")
            return payload, len(payload), len(payload)
        if resource == "active_threads":
            if not isinstance(payload, dict) or not isinstance(payload.get("threads"), list):
                raise TypeError("active_threads response must contain a threads list")
            records = payload["threads"]
            return records, len(records), len(records)
        raise ValueError(f"unsupported acquisition resource: {resource}")

    def _build_bundle(
        self,
        guild_id: str,
        started_at: str,
        completed_at: str,
        results: dict[str, AcquisitionResult],
    ) -> dict[str, Any]:
        bundle: dict[str, Any] = {
            "scan_profile": "STRUCTURE_BASELINE",
            "started_at": started_at,
            "completed_at": completed_at,
            "source_api_version": self._transport.source_api_version,
            "source_library": self._transport.source_library,
            "source_library_version": self._transport.source_library_version,
            "source_adapter_version": getattr(self._transport, "adapter_version", None),
            "gateway_connected": False,
            "collection_health": {
                name: result.health_dict() for name, result in results.items()
            },
        }

        for name, result in results.items():
            bundle[name] = copy.deepcopy(result.records)

        # The active-thread endpoint also returns membership records for threads
        # joined by the current bot.  Preserve those records when present, but do
        # not imply complete thread membership.
        raw_threads_result = results["active_threads"]
        raw_payload = getattr(raw_threads_result, "_raw_payload", None)
        del raw_payload  # reserved for future envelope storage; canonical bundles stay minimized

        # Guild identity is still retained in the envelope even if the guild GET failed.
        bundle["requested_guild_id"] = guild_id
        return bundle


def classify_exception(exc: Exception, *, attempt: int) -> ScanError:
    """Map library/transport exceptions into stable scanner error codes."""

    status = getattr(exc, "status", None)
    if status == 401:
        code, retryable = "AUTHENTICATION_FAILED", False
    elif status == 403:
        code, retryable = "AUTHORIZATION_DENIED", False
    elif status == 404:
        code, retryable = "RESOURCE_NOT_FOUND", False
    elif status in {500, 502, 503, 504}:
        code, retryable = "REMOTE_SERVER_ERROR", True
    elif status == 429:
        # discord.py performs route-level rate-limit waiting internally.  A 429
        # escaping that layer is reported rather than blindly retried here.
        code, retryable = "RATE_LIMIT_UNRESOLVED", False
    elif isinstance(exc, (asyncio.TimeoutError, TimeoutError, OSError)):
        code, retryable = "TRANSIENT_TRANSPORT_ERROR", True
    elif isinstance(exc, (TypeError, ValueError)):
        code, retryable = "RESPONSE_SHAPE_INVALID", False
    else:
        code, retryable = "ACQUISITION_FAILED", False

    message = str(exc).strip() or exc.__class__.__name__
    # Never copy tokens or headers into errors.  Library exceptions used here do
    # not include the token, but cap length and normalize line breaks defensively.
    message = " ".join(message.split())[:500]
    return ScanError(
        code=code,
        error_type=exc.__class__.__name__,
        message=message,
        retryable=retryable,
        attempt=attempt,
        status=int(status) if isinstance(status, int) else None,
    )
