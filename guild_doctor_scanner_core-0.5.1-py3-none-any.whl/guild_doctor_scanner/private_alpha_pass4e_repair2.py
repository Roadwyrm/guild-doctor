"""Replacement Pass 4E readiness and bounded snapshot refresh.

This module creates no live-session authority and exposes no Gateway operation.
Its only network-capable function performs the six reviewed GET operations used
to refresh the operator-local normalized snapshot.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any, Mapping

from .acquisition import ReadOnlyAcquisitionAdapter, RetryPolicy
from .canonical import exact_fingerprint
from .discord_normalized_snapshot_loader import load_authorized_normalized_snapshot
from .private_alpha_bounded_autocomplete import (
    DISCORD_CHOICE_LIMIT,
    SESSION_AUTOCOMPLETE_RESPONSE_LIMIT,
)
from .private_alpha_configuration import PrivateAlphaConfiguration, decide_allowlist
from .private_alpha_live_transport import BoundedExecutor, BoundedOperationLedger
from .private_alpha_pass4e_runtime_receipt import (
    APPROVED_RECEIPT_BASENAME,
    RuntimeReceiptWriter,
)


REPLACEMENT_READINESS_CONTRACT = (
    "GUILD-DOCTOR-STAGE8-PASS4E-REPLACEMENT-SESSION-READINESS-0.1"
)
REPAIR1_SOURCE_FINGERPRINT = (
    "07cd2a9d6742711e987197e85a668c5347284cdd27184963edcb8b580c63ac25"
)
APPROVED_SNAPSHOT_BASENAME = "authorized_normalized_snapshot.json"
APPROVED_GET_OPERATIONS = (
    "AUTHENTICATED_IDENTITY",
    "EXACT_GUILD_METADATA",
    "GUILD_ROLE_INVENTORY",
    "GUILD_CHANNEL_INVENTORY",
    "ACTIVE_THREAD_INVENTORY",
    "EXACT_OWNER_MEMBER",
)
APPLICATION_COMMAND_ROUTES = (
    "compare-role-permission",
    "compare-role-capability",
    "compare-role-action",
    "server-report",
)
AUTOCOMPLETE_ROUTES = (
    ("compare-role-permission", "permission"),
    ("compare-role-capability", "capability"),
    ("compare-role-action", "action"),
)
REPLACEMENT_BUDGET = {
    "gateway_sessions": 1,
    "reconnect_attempts": 0,
    "maximum_session_duration_seconds": 600,
    "accepted_application_command_invocations": 4,
    "each_planned_command_maximum": 1,
    "autocomplete_responses": 12,
    "initial_or_defer_responses_per_command": 1,
    "original_response_edits_per_deferred_command": 1,
    "follow_ups": 0,
    "attachments": 0,
    "components": 0,
    "modals": 0,
    "public_responses": 0,
    "ordinary_channel_messages": 0,
    "registrations_or_synchronizations": 0,
    "guild_server_object_writes": 0,
}


class Repair2Error(RuntimeError):
    """Stable fail-closed Repair 2 error."""


@dataclass(frozen=True, slots=True)
class SnapshotRefreshResult:
    status: str
    request_count: int
    operation_classes: tuple[str, ...]
    structural_completeness: str
    member_completeness: str
    thread_completeness: str
    guild_state: str
    roles_state: str
    channels_state: str
    active_threads_state: str
    snapshot_fingerprint: str | None
    output_basename: str
    atomic_write: str
    client_cleanup: str
    gateway_connection_count: int = 0
    interaction_response_write_count: int = 0
    autocomplete_response_write_count: int = 0
    command_registration_count: int = 0
    guild_server_object_write_count: int = 0

    def as_dict(self) -> dict[str, Any]:
        return {
            name: list(value) if isinstance(value, tuple) else value
            for name, value in ((field, getattr(self, field)) for field in self.__dataclass_fields__)
        }


def _atomic_json_write(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    encoded = json.dumps(dict(value), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_SNAPSHOT_ATOMIC_WRITE_FAILED") from None


class _LedgeredReadTransport:
    """Narrow four-operation scanner facade over the bounded REST executor."""

    def __init__(self, transport: Any, executor: BoundedExecutor):
        self._transport = transport
        self._executor = executor
        self.source_library = "discord.py"
        self.source_library_version = "2.7.1"
        self.source_api_version = "10"
        self.adapter_version = "GUILD-DOCTOR-DISCORDPY-ADAPTER-0.2"

    async def read_guild(self, guild_id: int) -> Any:
        return await self._executor.get(
            "EXACT_GUILD_METADATA", lambda: self._transport.read_guild(str(guild_id))
        )

    async def read_roles(self, guild_id: int) -> Any:
        return await self._executor.get(
            "GUILD_ROLE_INVENTORY", lambda: self._transport.read_roles(str(guild_id))
        )

    async def read_channels(self, guild_id: int) -> Any:
        return await self._executor.get(
            "GUILD_CHANNEL_INVENTORY", lambda: self._transport.read_channels(str(guild_id))
        )

    async def read_active_threads(self, guild_id: int) -> Any:
        return await self._executor.get(
            "ACTIVE_THREAD_INVENTORY", lambda: self._transport.read_active_threads(str(guild_id))
        )


async def refresh_authorized_snapshot(
    *,
    transport: Any,
    configuration: PrivateAlphaConfiguration,
    secret: str,
    output_path: Path,
    request_timeout_seconds: float = 20.0,
    total_timeout_seconds: float = 120.0,
) -> SnapshotRefreshResult:
    """Perform exactly six bounded GETs and atomically replace the snapshot."""
    output_path = Path(output_path)
    if output_path.name != APPROVED_SNAPSHOT_BASENAME:
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_SNAPSHOT_PATH_INVALID")
    if len(configuration.guild_allowlist) != 1:
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_ALLOWLIST_INVALID")
    if not isinstance(secret, str) or not secret:
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_SECRET_UNAVAILABLE")
    if not transport.network_policy_valid():
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_NETWORK_POLICY_INVALID")

    ledger = BoundedOperationLedger()
    executor = BoundedExecutor(
        ledger, timeout_seconds=request_timeout_seconds, get_retry_limit=0
    )
    guild_id = configuration.guild_allowlist[0]
    cleanup = "NOT_ATTEMPTED"
    result: SnapshotRefreshResult | None = None
    try:
        async with asyncio.timeout(total_timeout_seconds):
            await transport.open_client()
            identity = await executor.get(
                "AUTHENTICATED_IDENTITY", lambda: transport.authenticate(secret)
            )
            if not isinstance(identity, Mapping) or not identity.get("identity_available"):
                raise Repair2Error("STAGE8_PASS4E_REPAIR2_AUTHENTICATION_FAILED")

            scanner_transport = _LedgeredReadTransport(transport, executor)
            acquisition = await ReadOnlyAcquisitionAdapter(
                scanner_transport,
                retry_policy=RetryPolicy(max_attempts=1),
                operation_timeout_seconds=request_timeout_seconds,
            ).acquire_structure(guild_id)
            if acquisition.snapshot is None:
                raise Repair2Error("STAGE8_PASS4E_REPAIR2_SNAPSHOT_NORMALIZATION_FAILED")
            snapshot = acquisition.snapshot
            if snapshot.guild_id != guild_id or decide_allowlist(configuration, snapshot.guild_id).state != "ALLOWED":
                raise Repair2Error("STAGE8_PASS4E_REPAIR2_GUILD_BINDING_MISMATCH")
            if snapshot.guild is None or not snapshot.guild.owner_id:
                raise Repair2Error("STAGE8_PASS4E_REPAIR2_OWNER_IDENTITY_UNAVAILABLE")

            owner = await executor.get(
                "EXACT_OWNER_MEMBER",
                lambda: transport.read_member(guild_id, snapshot.guild.owner_id),
            )
            owner_user = owner.get("user") if isinstance(owner, Mapping) else None
            if not isinstance(owner_user, Mapping) or str(owner_user.get("id", "")) != snapshot.guild.owner_id:
                raise Repair2Error("STAGE8_PASS4E_REPAIR2_OWNER_MEMBER_MISMATCH")

            value = snapshot.as_dict()
            if value.get("member_completeness") != "NOT_REQUESTED" or value.get("members") is not None:
                raise Repair2Error("STAGE8_PASS4E_REPAIR2_MEMBER_SCOPE_BROADENED")
            if exact_fingerprint(value) != value.get("snapshot_fingerprint_sha256"):
                raise Repair2Error("STAGE8_PASS4E_REPAIR2_SNAPSHOT_FINGERPRINT_INVALID")
            operations = tuple(item.operation_class for item in ledger.records)
            if operations != APPROVED_GET_OPERATIONS:
                raise Repair2Error("STAGE8_PASS4E_REPAIR2_UNDECLARED_DISCORD_OPERATION")
            _atomic_json_write(output_path, value)
            loaded = load_authorized_normalized_snapshot(path=output_path, guild_id=guild_id)
            if not loaded.loaded:
                raise Repair2Error("STAGE8_PASS4E_REPAIR2_SNAPSHOT_POST_WRITE_INVALID")
            collections = value.get("collections", {})
            result = SnapshotRefreshResult(
                status="PASS",
                request_count=len(operations),
                operation_classes=operations,
                structural_completeness=value["structural_completeness"],
                member_completeness=value["member_completeness"],
                thread_completeness=value["thread_completeness"],
                guild_state=collections["guild"]["status"],
                roles_state=collections["roles"]["status"],
                channels_state=collections["channels"]["status"],
                active_threads_state=collections["active_threads"]["status"],
                snapshot_fingerprint=value["snapshot_fingerprint_sha256"],
                output_basename=output_path.name,
                atomic_write="PASS",
                client_cleanup="CLOSED",
            )
    except asyncio.CancelledError:
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_CANCELLED") from None
    except (asyncio.TimeoutError, TimeoutError):
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_TIMEOUT") from None
    except Repair2Error:
        raise
    except Exception:
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_ACQUISITION_FAILED") from None
    finally:
        secret = ""
        try:
            await transport.close()
        except Exception:
            cleanup = "FAILED"
        else:
            cleanup = "CLOSED"
        # A close failure is fatal even after a successful atomic write.
        if cleanup == "FAILED":
            raise Repair2Error("STAGE8_PASS4E_REPAIR2_CLIENT_CLOSE_FAILED")
    if result is None:
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_ACQUISITION_FAILED")
    return result


def validate_receipt_preflight(*, receipt_path: Path, project_root: Path) -> dict[str, Any]:
    """Exercise the atomic receipt writer without touching the designated receipt."""
    receipt_path = Path(receipt_path).resolve()
    project_root = Path(project_root).resolve()
    if receipt_path.name != APPROVED_RECEIPT_BASENAME:
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_RECEIPT_PATH_INVALID")
    if receipt_path == project_root or project_root in receipt_path.parents:
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_RECEIPT_PATH_INSIDE_PROJECT")
    if not receipt_path.parent.is_dir():
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_RECEIPT_PARENT_MISSING")

    test_directory = Path(tempfile.mkdtemp(prefix=".pass4e-receipt-preflight-", dir=receipt_path.parent))
    test_path = test_directory / APPROVED_RECEIPT_BASENAME
    try:
        writer = RuntimeReceiptWriter(test_path)
        writer.cleanup_started("PREFLIGHT_ONLY")
        writer.terminal("PREFLIGHT_ONLY")
        value = json.loads(test_path.read_text(encoding="utf-8"))
        privacy = all(
            value.get(key) is False
            for key in (
                "raw_interaction_retained", "identifier_retained", "option_value_retained",
                "token_retained", "absolute_path_retained",
            )
        )
        if value.get("terminal_completion_state") != "PREFLIGHT_ONLY" or not privacy:
            raise Repair2Error("STAGE8_PASS4E_REPAIR2_RECEIPT_PRIVACY_INVALID")
    finally:
        shutil.rmtree(test_directory, ignore_errors=True)
    return {
        "status": "PASS",
        "approved_basename": APPROVED_RECEIPT_BASENAME,
        "outside_project": True,
        "parent_exists": True,
        "atomic_temporary_write_flush_fsync_replace": "PASS",
        "preflight_artifact_removed": not test_directory.exists(),
        "designated_receipt_overwritten": False,
        "privacy_contract": "PASS",
        "receipt_failure_blocks_startup": True,
    }


def validate_replacement_budget() -> dict[str, Any]:
    valid = (
        REPLACEMENT_BUDGET["gateway_sessions"] == 1
        and REPLACEMENT_BUDGET["reconnect_attempts"] == 0
        and REPLACEMENT_BUDGET["maximum_session_duration_seconds"] == 600
        and REPLACEMENT_BUDGET["accepted_application_command_invocations"] == len(APPLICATION_COMMAND_ROUTES) == 4
        and REPLACEMENT_BUDGET["autocomplete_responses"] == SESSION_AUTOCOMPLETE_RESPONSE_LIMIT == 12
        and DISCORD_CHOICE_LIMIT == 25
        and all(REPLACEMENT_BUDGET[key] == 0 for key in (
            "follow_ups", "attachments", "components", "modals", "public_responses",
            "ordinary_channel_messages", "registrations_or_synchronizations",
            "guild_server_object_writes",
        ))
    )
    if not valid:
        raise Repair2Error("STAGE8_PASS4E_REPAIR2_BUDGET_INVALID")
    return {
        "status": "PASS",
        **REPLACEMENT_BUDGET,
        "maximum_choices_per_autocomplete_response": DISCORD_CHOICE_LIMIT,
        "application_command_routes": list(APPLICATION_COMMAND_ROUTES),
        "autocomplete_routes": [list(item) for item in AUTOCOMPLETE_ROUTES],
        "replacement_authority_created": False,
        "prior_failed_authority_reused": False,
    }


__all__ = [
    "APPLICATION_COMMAND_ROUTES", "APPROVED_GET_OPERATIONS", "AUTOCOMPLETE_ROUTES",
    "REPAIR1_SOURCE_FINGERPRINT", "REPLACEMENT_BUDGET", "REPLACEMENT_READINESS_CONTRACT",
    "Repair2Error", "SnapshotRefreshResult", "refresh_authorized_snapshot",
    "validate_receipt_preflight", "validate_replacement_budget",
]
