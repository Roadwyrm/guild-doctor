"""Versioned input and output schema for Stage 4 Pass 1 explanations.

The schema intentionally treats Stage 3 values as opaque authoritative
evidence.  It provides validation and deterministic serialization, but it does
not calculate permissions, capabilities, authority, thread state, or actions.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any


STAGE4_PASS1_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE4-PASS1-0.1"
EXPLANATION_SCHEMA_VERSION = "GUILD-DOCTOR-EXPLANATION-SCHEMA-0.1"
EXPLANATION_RULES_VERSION = "GUILD-DOCTOR-EXPLANATION-RULES-0.1"
EXPLANATION_GOLDEN_VERSION = "GUILD-DOCTOR-EXPLANATION-GOLDEN-0.1"

EXPLANATION_MODES = frozenset({"SIMPLE", "DETAILED", "TECHNICAL"})
RESULT_FAMILIES = frozenset(
    {
        "GUILD_PERMISSION",
        "CONTEXT_PERMISSION",
        "CAPABILITY",
        "THREAD",
        "AUTHORITY",
        "ACTION",
    }
)


class ExplanationInputError(ValueError):
    """Raised when a request cannot be interpreted as a Stage 4 request."""


def _normal_text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    return text or None


def _normal_id(value: Any) -> str | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str):
        text = value.strip()
        return text or None
    return None


def _tuple_text(values: Any) -> tuple[str, ...]:
    if values is None:
        return ()
    if isinstance(values, str):
        return (values.strip(),) if values.strip() else ()
    if isinstance(values, Mapping):
        values = values.values()
    if not isinstance(values, Sequence) and not hasattr(values, "__iter__"):
        return ()
    return tuple(sorted({str(item).strip() for item in values if str(item).strip()}))


def _copy_mapping(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        return {}
    return {str(key): value[key] for key in sorted(value, key=lambda item: str(item))}


@dataclass(frozen=True, slots=True)
class ExplanationRequest:
    """Pure request for explaining one frozen Stage 3 result."""

    mode: str
    result_family: str
    result: Any
    trace: Sequence[Any] | None = None
    source_stage3_contract_versions: Mapping[str, str] | None = None
    permission_definition_version: str | None = None
    registry_versions: Mapping[str, str] | None = None
    guild_id: str | int | None = None
    subject_id: str | int | None = None
    actor_id: str | int | None = None
    target_id: str | int | None = None
    context_id: str | int | None = None
    thread_id: str | int | None = None
    evidence_classifications: Sequence[str] = ()
    completeness_state: str | None = None
    verification_statuses: Sequence[str] = ()
    source_references: Sequence[str] = ()
    labels: Mapping[str, Any] | None = None
    include_ids_in_simple: bool = False
    # Optional Pass 2 presentation controls.  They do not alter the source
    # result, explanation meaning, or any frozen Stage 4 Pass 1 identifier.
    include_raw_bits_in_detailed: bool = False
    include_full_trace_in_technical: bool = False

    def __post_init__(self) -> None:
        mode = _normal_text(self.mode)
        family = _normal_text(self.result_family)
        if mode is None or mode.upper() not in EXPLANATION_MODES:
            raise ExplanationInputError(f"Unsupported explanation mode: {self.mode!r}")
        if family is None or family.upper() not in RESULT_FAMILIES:
            raise ExplanationInputError(f"Unsupported result family: {self.result_family!r}")
        object.__setattr__(self, "mode", mode.upper())
        object.__setattr__(self, "result_family", family.upper())
        for field_name in (
            "guild_id",
            "subject_id",
            "actor_id",
            "target_id",
            "context_id",
            "thread_id",
        ):
            object.__setattr__(self, field_name, _normal_id(getattr(self, field_name)))
        object.__setattr__(self, "source_stage3_contract_versions", _copy_mapping(self.source_stage3_contract_versions))
        object.__setattr__(self, "registry_versions", _copy_mapping(self.registry_versions))
        object.__setattr__(self, "evidence_classifications", _tuple_text(self.evidence_classifications))
        object.__setattr__(self, "verification_statuses", _tuple_text(self.verification_statuses))
        object.__setattr__(self, "source_references", _tuple_text(self.source_references))
        completeness = _normal_text(self.completeness_state)
        object.__setattr__(self, "completeness_state", completeness.upper() if completeness else None)
        object.__setattr__(self, "permission_definition_version", _normal_text(self.permission_definition_version))
        object.__setattr__(self, "labels", _copy_mapping(self.labels))

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "ExplanationRequest":
        if not isinstance(value, Mapping):
            raise ExplanationInputError("Explanation request must be a mapping or ExplanationRequest")
        versions = value.get("source_stage3_contract_versions", value.get("contract_versions", {}))
        registry_versions = value.get("registry_versions", {})
        result = value.get("result", value.get("authoritative_result"))
        if "mode" not in value or "result_family" not in value or result is None:
            raise ExplanationInputError("mode, result_family, and result are required")
        return cls(
            mode=value["mode"],
            result_family=value["result_family"],
            result=result,
            trace=value.get("trace"),
            source_stage3_contract_versions=versions,
            permission_definition_version=value.get("permission_definition_version"),
            registry_versions=registry_versions,
            guild_id=value.get("guild_id"),
            subject_id=value.get("subject_id", value.get("subject_or_actor_id")),
            actor_id=value.get("actor_id"),
            target_id=value.get("target_id"),
            context_id=value.get("context_id"),
            thread_id=value.get("thread_id"),
            evidence_classifications=value.get("evidence_classifications", ()),
            completeness_state=value.get("completeness_state"),
            verification_statuses=value.get("verification_statuses", ()),
            source_references=value.get("source_references", ()),
            labels=value.get("labels", {}),
            include_ids_in_simple=bool(value.get("include_ids_in_simple", False)),
            include_raw_bits_in_detailed=bool(value.get("include_raw_bits_in_detailed", False)),
            include_full_trace_in_technical=bool(value.get("include_full_trace_in_technical", False)),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "stage4_pass1_contract_version": STAGE4_PASS1_CONTRACT_VERSION,
            "explanation_schema_version": EXPLANATION_SCHEMA_VERSION,
            "explanation_rules_version": EXPLANATION_RULES_VERSION,
            "mode": self.mode,
            "result_family": self.result_family,
            "guild_id": self.guild_id,
            "subject_id": self.subject_id,
            "actor_id": self.actor_id,
            "target_id": self.target_id,
            "context_id": self.context_id,
            "thread_id": self.thread_id,
            "evidence_classifications": list(self.evidence_classifications),
            "completeness_state": self.completeness_state,
            "verification_statuses": list(self.verification_statuses),
            "source_references": list(self.source_references),
            "source_stage3_contract_versions": dict(self.source_stage3_contract_versions or {}),
            "permission_definition_version": self.permission_definition_version,
            "registry_versions": dict(self.registry_versions or {}),
            "include_ids_in_simple": self.include_ids_in_simple,
            "include_raw_bits_in_detailed": self.include_raw_bits_in_detailed,
            "include_full_trace_in_technical": self.include_full_trace_in_technical,
        }


@dataclass(frozen=True, slots=True)
class ExplanationOutput:
    """Structured deterministic explanation returned by the rendering core."""

    stage4_pass1_contract_version: str
    explanation_schema_version: str
    explanation_rules_version: str
    source_stage3_contract_versions: Mapping[str, str]
    permission_definition_version: str | None
    registry_versions: Mapping[str, str]
    result_family: str
    explanation_mode: str
    guild_id: str | None
    subject_id: str | None
    actor_id: str | None
    target_id: str | None
    context_id: str | None
    thread_id: str | None
    result_state: str
    short_answer: str
    summary: str
    confidence_or_completeness_statement: str
    pre_execution_disclaimer: str | None
    primary_reason: str
    contributing_reasons: tuple[str, ...]
    blocking_reasons: tuple[str, ...]
    uncertainty_reasons: tuple[str, ...]
    bypass_reasons: tuple[str, ...]
    ineffective_grants: tuple[str, ...]
    applicable_permission_sources: tuple[str, ...]
    ignored_or_inapplicable_sources: tuple[str, ...]
    raw_vs_effective: tuple[str, ...]
    trace_references: tuple[Mapping[str, Any], ...]
    source_rule_ids: tuple[str, ...]
    verification_statuses: tuple[str, ...]
    source_result_fingerprint: str | None
    source_references: tuple[str, ...]
    ordered_sections: tuple[Mapping[str, Any], ...]
    ordered_explanation_lines: tuple[str, ...]
    one_line: str
    explanation_fingerprint: str

    def as_dict(self) -> dict[str, Any]:
        versioning = {
            "stage4_pass1_contract_version": self.stage4_pass1_contract_version,
            "explanation_schema_version": self.explanation_schema_version,
            "explanation_rules_version": self.explanation_rules_version,
            "source_stage3_contract_versions": dict(self.source_stage3_contract_versions),
            "permission_definition_version": self.permission_definition_version,
            "registry_versions": dict(self.registry_versions),
        }
        identity = {
            "result_family": self.result_family,
            "explanation_mode": self.explanation_mode,
            "guild_id": self.guild_id,
            "subject_id": self.subject_id,
            "actor_id": self.actor_id,
            "target_id": self.target_id,
            "context_id": self.context_id,
            "thread_id": self.thread_id,
        }
        core = {
            "result_state": self.result_state,
            "short_answer": self.short_answer,
            "summary": self.summary,
            "confidence_or_completeness_statement": self.confidence_or_completeness_statement,
            "pre_execution_disclaimer": self.pre_execution_disclaimer,
        }
        evidence = {
            "primary_reason": self.primary_reason,
            "contributing_reasons": list(self.contributing_reasons),
            "blocking_reasons": list(self.blocking_reasons),
            "uncertainty_reasons": list(self.uncertainty_reasons),
            "bypass_reasons": list(self.bypass_reasons),
            "ineffective_grants": list(self.ineffective_grants),
            "applicable_permission_sources": list(self.applicable_permission_sources),
            "ignored_or_inapplicable_sources": list(self.ignored_or_inapplicable_sources),
            "raw_vs_effective": list(self.raw_vs_effective),
            "trace_references": [dict(item) for item in self.trace_references],
            "source_rule_ids": list(self.source_rule_ids),
            "verification_statuses": list(self.verification_statuses),
        }
        provenance = {
            "source_result_fingerprint": self.source_result_fingerprint,
            "trace_event_ids": [item.get("trace_event_id") for item in self.trace_references],
            "registry_versions": dict(self.registry_versions),
            "source_references": list(self.source_references),
            "explanation_fingerprint": self.explanation_fingerprint,
        }
        formatting = {
            "ordered_sections": [dict(item) for item in self.ordered_sections],
            "ordered_explanation_lines": list(self.ordered_explanation_lines),
            "one_line": self.one_line,
            "machine_readable": True,
        }
        return {
            "versioning": versioning,
            "identity": identity,
            "core_result": core,
            "evidence": evidence,
            "technical_provenance": provenance,
            "formatting": formatting,
            # Direct aliases keep the JSON convenient for callers and preserve
            # the names used by the Pass 1 contract.
            **versioning,
            **identity,
            **core,
            **evidence,
            **provenance,
            **formatting,
        }


def validate_explanation_request(value: ExplanationRequest | Mapping[str, Any]) -> tuple[str, ...]:
    """Return deterministic schema violations without contacting anything."""

    request = value if isinstance(value, ExplanationRequest) else ExplanationRequest.from_mapping(value)
    violations: list[str] = []
    if request.result is None:
        violations.append("RESULT_MISSING")
    if not isinstance(request.result_family, str) or request.result_family not in RESULT_FAMILIES:
        violations.append("RESULT_FAMILY_INVALID")
    for field_name in ("guild_id", "subject_id", "actor_id", "target_id", "context_id", "thread_id"):
        value = getattr(request, field_name)
        if value is not None and (not value.isdecimal() or int(value) <= 0):
            violations.append(f"{field_name.upper()}_NOT_DECIMAL_SNOWFLAKE")
    if request.labels is not None and not isinstance(request.labels, Mapping):
        violations.append("LABEL_MAP_INVALID")
    return tuple(sorted(set(violations)))


__all__ = [
    "EXPLANATION_GOLDEN_VERSION",
    "EXPLANATION_MODES",
    "EXPLANATION_RULES_VERSION",
    "EXPLANATION_SCHEMA_VERSION",
    "ExplanationInputError",
    "ExplanationOutput",
    "ExplanationRequest",
    "RESULT_FAMILIES",
    "STAGE4_PASS1_CONTRACT_VERSION",
    "validate_explanation_request",
]
