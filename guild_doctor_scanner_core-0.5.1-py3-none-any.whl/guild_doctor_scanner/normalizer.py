"""Discord-shaped fixture normalization and snapshot validation."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Iterable
from uuid import uuid4

from .canonical import exact_fingerprint, structural_fingerprint
from .constants import (
    CATEGORY_TYPE_CODE,
    CHANNEL_TYPE_KEYS,
    KNOWN_PERMISSION_MASK,
    PERMISSION_DEFINITION_VERSION,
    REQUIRED_COLLECTIONS_BY_PROFILE,
    SCANNER_CONTRACT_VERSION,
    SNAPSHOT_SCHEMA_VERSION,
    THREAD_TYPE_CODES,
)
from .enums import CollectionStatus, Completeness, Materiality, Severity, SyncState
from .errors import SnapshotValidationError
from .models import (
    CollectionHealth,
    ManagedBinding,
    NormalizedChannel,
    NormalizedForumTag,
    NormalizedGuild,
    NormalizedMember,
    NormalizedOverwrite,
    NormalizedRole,
    NormalizedSnapshot,
    NormalizedThread,
    NormalizedThreadMembership,
    RoleTags,
    SnapshotIssue,
)
from .util import (
    bigint,
    bool_or_none,
    canonical_id_sort,
    decimal_string,
    nonnegative_int,
    optional_snowflake,
    optional_timestamp,
    snowflake,
    utc_timestamp,
)


_ALLOWED_PROFILES = set(REQUIRED_COLLECTIONS_BY_PROFILE)
_COLLECTION_KEYS = (
    "guild",
    "roles",
    "channels",
    "active_threads",
    "archived_threads",
    "members",
    "thread_memberships",
)


class _IssueCollector:
    def __init__(self) -> None:
        self.items: list[SnapshotIssue] = []
        self._counter = 0

    def add(
        self,
        code: str,
        severity: Severity,
        materiality: Materiality,
        entity_type: str,
        entity_id: str | None = None,
        *,
        related_ids: Iterable[str] = (),
        details: dict[str, Any] | None = None,
        source_status: str = "DOCUMENTED",
    ) -> None:
        self._counter += 1
        self.items.append(
            SnapshotIssue(
                issue_id=f"SI-{self._counter:04d}",
                code=code,
                severity=severity.value,
                materiality=materiality.value,
                entity_type=entity_type,
                entity_id=entity_id,
                related_ids=sorted(set(related_ids), key=canonical_id_sort),
                message_key=code.lower(),
                details=details or {},
                source_status=source_status,
            )
        )


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _collection_health(bundle: dict[str, Any], key: str, records: Any) -> CollectionHealth:
    supplied = bundle.get("collection_health", {}).get(key, {})
    if supplied:
        try:
            status = CollectionStatus(str(supplied.get("status", "COMPLETE"))).value
        except ValueError as exc:
            raise SnapshotValidationError(f"collection_health.{key}.status is invalid") from exc
    else:
        if key not in bundle:
            status = CollectionStatus.NOT_REQUESTED.value
        elif records is None:
            status = CollectionStatus.UNAVAILABLE.value
        else:
            status = CollectionStatus.COMPLETE.value

    received_count: int | None
    if records is None:
        received_count = None
    elif isinstance(records, list):
        received_count = len(records)
    else:
        received_count = 1

    expected = supplied.get("expected_count")
    page_count = supplied.get("page_count")
    return CollectionHealth(
        resource=key,
        status=status,
        expected_count=nonnegative_int(expected, f"collection_health.{key}.expected_count") if expected is not None else None,
        received_count=nonnegative_int(supplied.get("received_count"), f"collection_health.{key}.received_count")
        if supplied.get("received_count") is not None
        else received_count,
        page_count=nonnegative_int(page_count, f"collection_health.{key}.page_count") if page_count is not None else None,
        cursor_complete=bool_or_none(supplied.get("cursor_complete")),
        started_at=optional_timestamp(supplied.get("started_at"), f"collection_health.{key}.started_at"),
        completed_at=optional_timestamp(supplied.get("completed_at"), f"collection_health.{key}.completed_at"),
        source_interface=supplied.get("source_interface"),
        error_codes=[str(x) for x in supplied.get("error_codes", [])],
    )


def _unique_map(items: list[Any], entity_name: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for item in items:
        if item.id in result:
            raise SnapshotValidationError(f"duplicate {entity_name} id: {item.id}")
        result[item.id] = item
    return dict(sorted(result.items(), key=lambda kv: canonical_id_sort(kv[0])))


def _normalize_guild(raw: dict[str, Any], observed_at: str) -> NormalizedGuild:
    mfa_raw = raw.get("mfa_level")
    if mfa_raw in (0, "0", "NONE", "none"):
        mfa = "NONE"
    elif mfa_raw in (1, "1", "ELEVATED", "elevated"):
        mfa = "ELEVATED"
    else:
        mfa = "UNKNOWN"

    member_count = raw.get("member_count", raw.get("approximate_member_count"))
    return NormalizedGuild(
        id=snowflake(raw.get("id"), "guild.id"),
        name=str(raw.get("name", "")),
        owner_id=snowflake(raw.get("owner_id"), "guild.owner_id"),
        features=sorted({str(x) for x in raw.get("features", [])}),
        mfa_level=mfa,
        reported_member_count=nonnegative_int(member_count, "guild.member_count") if member_count is not None else None,
        large=bool_or_none(raw.get("large")),
        unavailable=bool_or_none(raw.get("unavailable")),
        source_observed_at=observed_at,
        source_payload_hash=raw.get("_payload_sha256"),
    )


def _normalize_role(raw: dict[str, Any], guild_id: str, observed_at: str) -> NormalizedRole:
    tags_raw = raw.get("tags") or {}
    tags = RoleTags(
        bot_id=optional_snowflake(tags_raw.get("bot_id"), "role.tags.bot_id"),
        integration_id=optional_snowflake(tags_raw.get("integration_id"), "role.tags.integration_id"),
        subscription_listing_id=optional_snowflake(
            tags_raw.get("subscription_listing_id"), "role.tags.subscription_listing_id"
        ),
        available_for_purchase=True if "available_for_purchase" in tags_raw else None,
        guild_connections=True if "guild_connections" in tags_raw else None,
    )
    role_id = snowflake(raw.get("id"), "role.id")
    return NormalizedRole(
        id=role_id,
        guild_id=guild_id,
        name=str(raw.get("name", "")),
        position=nonnegative_int(raw.get("position", 0), "role.position"),
        permissions_decimal=decimal_string(raw.get("permissions", "0"), "role.permissions"),
        managed=bool(raw.get("managed", False)),
        mentionable=bool_or_none(raw.get("mentionable")),
        hoist=bool_or_none(raw.get("hoist")),
        is_everyone=role_id == guild_id,
        role_tags=tags,
        source_observed_at=observed_at,
        source_payload_hash=raw.get("_payload_sha256"),
    )


def _overwrite_type(value: Any) -> tuple[str, int | str]:
    if value in (0, "0", "role", "ROLE"):
        return "ROLE", value
    if value in (1, "1", "member", "MEMBER"):
        return "MEMBER", value
    return "UNKNOWN", value if isinstance(value, (int, str)) else str(value)


def _normalize_overwrites(
    raw_items: list[dict[str, Any]],
    issues: _IssueCollector,
    channel_id: str,
) -> list[NormalizedOverwrite]:
    result: list[NormalizedOverwrite] = []
    seen: set[tuple[str, str]] = set()
    for index, raw in enumerate(raw_items):
        target_id = snowflake(raw.get("id"), f"channel.{channel_id}.overwrites[{index}].id")
        target_type, raw_type = _overwrite_type(raw.get("type"))
        if target_type == "UNKNOWN":
            issues.add(
                "OVERWRITE_TARGET_TYPE_UNKNOWN",
                Severity.ERROR,
                Materiality.STRUCTURAL,
                "overwrite",
                target_id,
                related_ids=[channel_id],
                details={"raw_type": raw_type},
            )
        key = (target_type, target_id)
        if key in seen:
            issues.add(
                "OVERWRITE_DUPLICATE_TARGET",
                Severity.ERROR,
                Materiality.STRUCTURAL,
                "overwrite",
                target_id,
                related_ids=[channel_id],
                details={"target_type": target_type},
            )
        seen.add(key)
        result.append(
            NormalizedOverwrite(
                target_id=target_id,
                target_type=target_type,
                raw_target_type=raw_type,
                allow_decimal=decimal_string(raw.get("allow", "0"), "overwrite.allow"),
                deny_decimal=decimal_string(raw.get("deny", "0"), "overwrite.deny"),
                source_index=index,
            )
        )
    return sorted(result, key=lambda x: (x.target_type, canonical_id_sort(x.target_id), x.source_index))


def _normalize_forum_tags(raw_items: list[dict[str, Any]]) -> list[NormalizedForumTag]:
    result = []
    for raw in raw_items:
        result.append(
            NormalizedForumTag(
                id=snowflake(raw.get("id"), "channel.available_tags.id"),
                name=str(raw.get("name", "")),
                moderated=bool(raw.get("moderated", False)),
                emoji_id=optional_snowflake(raw.get("emoji_id"), "channel.available_tags.emoji_id"),
                emoji_name=str(raw["emoji_name"]) if raw.get("emoji_name") is not None else None,
            )
        )
    return sorted(result, key=lambda x: canonical_id_sort(x.id))


def _optional_nonnegative(raw: dict[str, Any], key: str, field: str) -> int | None:
    value = raw.get(key)
    return nonnegative_int(value, field) if value is not None else None


def _normalize_channel(
    raw: dict[str, Any], guild_id: str, observed_at: str, issues: _IssueCollector
) -> NormalizedChannel:
    channel_id = snowflake(raw.get("id"), "channel.id")
    type_code = nonnegative_int(raw.get("type"), "channel.type")
    type_key = CHANNEL_TYPE_KEYS.get(type_code, f"UNKNOWN_{type_code}")
    if type_code not in CHANNEL_TYPE_KEYS:
        issues.add(
            "UNKNOWN_CHANNEL_TYPE",
            Severity.WARNING,
            Materiality.FUTURE_ANALYSIS,
            "channel",
            channel_id,
            details={"type_code": type_code},
            source_status="NEEDS_REVIEW",
        )
    overwrites = _normalize_overwrites(raw.get("permission_overwrites", []), issues, channel_id)
    flags = raw.get("flags")
    return NormalizedChannel(
        id=channel_id,
        guild_id=guild_id,
        type_code=type_code,
        type_key=type_key,
        name=str(raw.get("name", "")),
        position=nonnegative_int(raw.get("position", 0), "channel.position"),
        parent_id=optional_snowflake(raw.get("parent_id"), "channel.parent_id"),
        topic=str(raw["topic"]) if raw.get("topic") is not None else None,
        nsfw=bool_or_none(raw.get("nsfw")),
        flags_decimal=decimal_string(flags, "channel.flags") if flags is not None else None,
        rate_limit_per_user=_optional_nonnegative(raw, "rate_limit_per_user", "channel.rate_limit_per_user"),
        bitrate=_optional_nonnegative(raw, "bitrate", "channel.bitrate"),
        user_limit=_optional_nonnegative(raw, "user_limit", "channel.user_limit"),
        rtc_region=str(raw["rtc_region"]) if raw.get("rtc_region") is not None else None,
        video_quality_mode=_optional_nonnegative(raw, "video_quality_mode", "channel.video_quality_mode"),
        default_auto_archive_duration=_optional_nonnegative(
            raw, "default_auto_archive_duration", "channel.default_auto_archive_duration"
        ),
        default_thread_rate_limit_per_user=_optional_nonnegative(
            raw, "default_thread_rate_limit_per_user", "channel.default_thread_rate_limit_per_user"
        ),
        available_tags=_normalize_forum_tags(raw.get("available_tags", [])),
        default_reaction_emoji=raw.get("default_reaction_emoji"),
        default_sort_order=_optional_nonnegative(raw, "default_sort_order", "channel.default_sort_order"),
        default_forum_layout=_optional_nonnegative(raw, "default_forum_layout", "channel.default_forum_layout"),
        permission_overwrites=overwrites,
        sync_state=SyncState.UNKNOWN.value,
        sync_parent_id=None,
        sync_evidence=[],
        source_observed_at=observed_at,
        source_payload_hash=raw.get("_payload_sha256"),
    )


def _normalize_thread(raw: dict[str, Any], guild_id: str, observed_at: str, source_scope: str) -> NormalizedThread:
    thread_id = snowflake(raw.get("id"), "thread.id")
    type_code = nonnegative_int(raw.get("type"), "thread.type")
    metadata = raw.get("thread_metadata") or {}
    type_key = CHANNEL_TYPE_KEYS.get(type_code, f"UNKNOWN_{type_code}")
    return NormalizedThread(
        id=thread_id,
        guild_id=guild_id,
        parent_id=optional_snowflake(raw.get("parent_id"), "thread.parent_id"),
        owner_id=optional_snowflake(raw.get("owner_id"), "thread.owner_id"),
        type_code=type_code,
        type_key=type_key,
        name=str(raw.get("name", "")),
        archived=bool_or_none(metadata.get("archived")),
        locked=bool_or_none(metadata.get("locked")),
        invitable=bool_or_none(metadata.get("invitable")),
        auto_archive_duration=nonnegative_int(metadata.get("auto_archive_duration"), "thread.auto_archive_duration")
        if metadata.get("auto_archive_duration") is not None
        else None,
        archive_timestamp=optional_timestamp(metadata.get("archive_timestamp"), "thread.archive_timestamp"),
        create_timestamp=optional_timestamp(raw.get("thread_metadata", {}).get("create_timestamp"), "thread.create_timestamp"),
        flags_decimal=decimal_string(raw.get("flags"), "thread.flags") if raw.get("flags") is not None else None,
        applied_tag_ids=sorted(
            [snowflake(x, "thread.applied_tags") for x in raw.get("applied_tags", [])], key=canonical_id_sort
        ),
        message_count=nonnegative_int(raw.get("message_count"), "thread.message_count")
        if raw.get("message_count") is not None
        else None,
        member_count=nonnegative_int(raw.get("member_count"), "thread.member_count")
        if raw.get("member_count") is not None
        else None,
        source_scope=source_scope,
        source_observed_at=observed_at,
        source_payload_hash=raw.get("_payload_sha256"),
    )


def _normalize_member(
    raw: dict[str, Any], guild_id: str, observed_at: str, source_scope: str
) -> NormalizedMember:
    user = raw.get("user") or {}
    member_id = snowflake(raw.get("id", user.get("id")), "member.id")
    role_ids = sorted({snowflake(x, "member.roles") for x in raw.get("roles", [])}, key=canonical_id_sort)
    timeout_until = optional_timestamp(raw.get("communication_disabled_until"), "member.communication_disabled_until")
    timeout_state = "UNKNOWN"
    if timeout_until is None:
        timeout_state = "INACTIVE"
    else:
        parsed = datetime.fromisoformat(timeout_until.replace("Z", "+00:00"))
        timeout_state = "ACTIVE" if parsed > datetime.now(timezone.utc) else "INACTIVE"
    mfa = str(raw.get("mfa_state", "UNKNOWN")).upper()
    if mfa not in {"ENABLED", "DISABLED", "UNKNOWN"}:
        mfa = "UNKNOWN"
    return NormalizedMember(
        id=member_id,
        guild_id=guild_id,
        role_ids=role_ids,
        highest_role_id=None,
        highest_role_position=None,
        timeout_until=timeout_until,
        timeout_state=timeout_state,
        bot=bool_or_none(user.get("bot")),
        pending=bool_or_none(raw.get("pending")),
        mfa_state=mfa,
        source_scope=source_scope,
        source_observed_at=observed_at,
        source_payload_hash=raw.get("_payload_sha256"),
    )


def _normalize_membership(raw: dict[str, Any], observed_at: str) -> NormalizedThreadMembership:
    thread_id = snowflake(raw.get("thread_id"), "thread_membership.thread_id")
    member_id = snowflake(raw.get("user_id", raw.get("member_id")), "thread_membership.member_id")
    state = str(raw.get("membership_state", "MEMBER")).upper()
    if state not in {"MEMBER", "NOT_MEMBER", "UNKNOWN"}:
        state = "UNKNOWN"
    return NormalizedThreadMembership(
        thread_id=thread_id,
        member_id=member_id,
        joined_at=optional_timestamp(raw.get("join_timestamp"), "thread_membership.join_timestamp"),
        flags=nonnegative_int(raw.get("flags"), "thread_membership.flags") if raw.get("flags") is not None else None,
        membership_state=state,
        source_observed_at=observed_at,
    )


def _overwrite_comparison_key(items: list[NormalizedOverwrite]) -> tuple[tuple[str, str, str, str], ...] | None:
    seen: set[tuple[str, str]] = set()
    result = []
    for item in items:
        if item.target_type == "UNKNOWN":
            return None
        key = (item.target_type, item.target_id)
        if key in seen:
            return None
        seen.add(key)
        result.append((item.target_type, item.target_id, item.allow_decimal, item.deny_decimal))
    return tuple(sorted(result))


def _classify_sync(channels: dict[str, NormalizedChannel], issues: _IssueCollector) -> None:
    for channel in channels.values():
        if channel.type_code == CATEGORY_TYPE_CODE or channel.parent_id is None:
            channel.sync_state = SyncState.NOT_APPLICABLE.value
            channel.sync_parent_id = channel.parent_id
            channel.sync_evidence = ["CATEGORY_OR_NO_PARENT"]
            continue
        parent = channels.get(channel.parent_id)
        channel.sync_parent_id = channel.parent_id
        if parent is None:
            channel.sync_state = SyncState.UNKNOWN.value
            channel.sync_evidence = ["PARENT_REFERENCE_MISSING"]
            issues.add(
                "PARENT_REFERENCE_MISSING",
                Severity.ERROR,
                Materiality.STRUCTURAL,
                "channel",
                channel.id,
                related_ids=[channel.parent_id],
            )
            continue
        if parent.type_code != CATEGORY_TYPE_CODE:
            channel.sync_state = SyncState.UNKNOWN.value
            channel.sync_evidence = ["PARENT_NOT_CATEGORY"]
            issues.add(
                "PARENT_NOT_CATEGORY",
                Severity.ERROR,
                Materiality.STRUCTURAL,
                "channel",
                channel.id,
                related_ids=[parent.id],
            )
            continue
        child_key = _overwrite_comparison_key(channel.permission_overwrites)
        parent_key = _overwrite_comparison_key(parent.permission_overwrites)
        if child_key is None or parent_key is None:
            channel.sync_state = SyncState.UNKNOWN.value
            channel.sync_evidence = ["MALFORMED_OVERWRITE_SET"]
        elif child_key == parent_key:
            channel.sync_state = SyncState.SYNCED.value
            channel.sync_evidence = ["EXACT_OVERWRITE_MAP_EQUALITY"]
        else:
            channel.sync_state = SyncState.NOT_SYNCED.value
            channel.sync_evidence = ["OVERWRITE_MAP_DIFFERS"]


def _derive_member_highest_roles(
    members: dict[str, NormalizedMember] | None,
    roles: dict[str, NormalizedRole] | None,
    guild_id: str,
    issues: _IssueCollector,
) -> None:
    if members is None:
        return
    if roles is None:
        for member in members.values():
            issues.add(
                "ROLE_REFERENCE_MISSING",
                Severity.ERROR,
                Materiality.MEMBER_QUERY,
                "member",
                member.id,
                details={"reason": "roles collection unavailable"},
            )
        return
    for member in members.values():
        refs = [guild_id, *member.role_ids]
        missing = [role_id for role_id in refs if role_id not in roles]
        if missing:
            issues.add(
                "ROLE_REFERENCE_MISSING",
                Severity.ERROR,
                Materiality.MEMBER_QUERY,
                "member",
                member.id,
                related_ids=missing,
            )
            continue
        candidates = [roles[role_id] for role_id in refs]
        max_position = max(role.position for role in candidates)
        at_max = [role for role in candidates if role.position == max_position]
        if len(at_max) > 1:
            issues.add(
                "ROLE_POSITION_AMBIGUOUS",
                Severity.WARNING,
                Materiality.MEMBER_QUERY,
                "member",
                member.id,
                related_ids=[role.id for role in at_max],
                details={"position": max_position},
                source_status="NEEDS_REVIEW",
            )
            continue
        member.highest_role_id = at_max[0].id
        member.highest_role_position = at_max[0].position


def _validate_overwrite_references(
    channels: dict[str, NormalizedChannel] | None,
    roles: dict[str, NormalizedRole] | None,
    members: dict[str, NormalizedMember] | None,
    member_collection_authoritative: bool,
    issues: _IssueCollector,
) -> None:
    if channels is None:
        return
    for channel in channels.values():
        for overwrite in channel.permission_overwrites:
            if overwrite.target_type == "ROLE" and roles is not None and overwrite.target_id not in roles:
                issues.add(
                    "OVERWRITE_ROLE_REFERENCE_MISSING",
                    Severity.ERROR,
                    Materiality.STRUCTURAL,
                    "overwrite",
                    overwrite.target_id,
                    related_ids=[channel.id],
                )
            elif (
                overwrite.target_type == "MEMBER"
                and member_collection_authoritative
                and (members is None or overwrite.target_id not in members)
            ):
                issues.add(
                    "OVERWRITE_MEMBER_TARGET_NOT_LOADED",
                    Severity.WARNING,
                    Materiality.MEMBER_QUERY,
                    "overwrite",
                    overwrite.target_id,
                    related_ids=[channel.id],
                )


def _bindings(roles: dict[str, NormalizedRole] | None) -> list[ManagedBinding]:
    if roles is None:
        return []
    result: list[ManagedBinding] = []
    for role in roles.values():
        tags = role.role_tags
        if tags.bot_id:
            result.append(ManagedBinding(role.id, "BOT", tags.bot_id, "VERIFIED_FROM_ROLE_TAG"))
        if tags.integration_id:
            result.append(ManagedBinding(role.id, "INTEGRATION", tags.integration_id, "VERIFIED_FROM_ROLE_TAG"))
        if tags.subscription_listing_id:
            result.append(
                ManagedBinding(role.id, "SUBSCRIPTION_LISTING", tags.subscription_listing_id, "VERIFIED_FROM_ROLE_TAG")
            )
        if tags.available_for_purchase:
            result.append(ManagedBinding(role.id, "PURCHASABLE", None, "VERIFIED_FROM_ROLE_TAG"))
        if tags.guild_connections:
            result.append(ManagedBinding(role.id, "GUILD_CONNECTIONS", None, "VERIFIED_FROM_ROLE_TAG"))
    return sorted(result, key=lambda item: (canonical_id_sort(item.role_id), item.binding_type))


def _collection_issues(collections: dict[str, CollectionHealth], issues: _IssueCollector) -> None:
    for key, health in collections.items():
        if health.status == CollectionStatus.PARTIAL.value:
            issues.add(
                "COLLECTION_PARTIAL",
                Severity.WARNING,
                Materiality.STRUCTURAL if key in {"guild", "roles", "channels"} else Materiality.FUTURE_ANALYSIS,
                "collection",
                details={"resource": key, "errors": health.error_codes},
            )
        elif health.status == CollectionStatus.UNAVAILABLE.value:
            issues.add(
                "COLLECTION_UNAVAILABLE",
                Severity.WARNING,
                Materiality.STRUCTURAL if key in {"guild", "roles", "channels"} else Materiality.FUTURE_ANALYSIS,
                "collection",
                details={"resource": key, "errors": health.error_codes},
            )
        elif health.status == CollectionStatus.FAILED.value:
            issues.add(
                "COLLECTION_FAILED",
                Severity.ERROR,
                Materiality.STRUCTURAL if key in {"guild", "roles", "channels"} else Materiality.FUTURE_ANALYSIS,
                "collection",
                details={"resource": key, "errors": health.error_codes},
            )
        if (
            health.expected_count is not None
            and health.received_count is not None
            and health.expected_count != health.received_count
        ):
            issues.add(
                "COUNT_MISMATCH",
                Severity.WARNING,
                Materiality.MEMBER_QUERY if key == "members" else Materiality.FUTURE_ANALYSIS,
                "collection",
                details={
                    "resource": key,
                    "expected_count": health.expected_count,
                    "received_count": health.received_count,
                },
            )


def _completeness(
    profile: str,
    collections: dict[str, CollectionHealth],
    issues: list[SnapshotIssue],
) -> tuple[str, str, str]:
    structural_keys = ["guild", "roles", "channels"]
    if profile in {"STRUCTURE_BASELINE", "TARGETED_MEMBER", "WHO_CAN_TEMPORARY", "THREAD_TARGETED"}:
        structural_keys.append("active_threads")
    statuses = [collections[key].status for key in structural_keys]
    structural_material_errors = any(
        issue.severity == Severity.ERROR.value and issue.materiality == Materiality.STRUCTURAL.value for issue in issues
    )
    structural_count_incomplete = any(
        (health.expected_count is not None and health.received_count is not None and health.expected_count != health.received_count)
        or health.cursor_complete is False
        for key, health in collections.items()
        if key in structural_keys
    )
    if any(status in {CollectionStatus.FAILED.value, CollectionStatus.UNAVAILABLE.value, CollectionStatus.UNSUPPORTED.value} for status in statuses):
        structural = Completeness.UNKNOWN.value
    elif (
        any(status in {CollectionStatus.PARTIAL.value, CollectionStatus.NOT_REQUESTED.value} for status in statuses)
        or structural_material_errors
        or structural_count_incomplete
    ):
        structural = Completeness.PARTIAL.value
    else:
        structural = Completeness.COMPLETE.value

    member_health = collections["members"]
    member_count_incomplete = (
        member_health.expected_count is not None
        and member_health.received_count is not None
        and member_health.expected_count != member_health.received_count
    ) or member_health.cursor_complete is False
    if member_health.status == CollectionStatus.NOT_REQUESTED.value:
        member = Completeness.NOT_REQUESTED.value
    elif member_health.status == CollectionStatus.COMPLETE.value:
        member = Completeness.PARTIAL.value if member_count_incomplete else Completeness.COMPLETE.value
    elif member_health.status == CollectionStatus.PARTIAL.value:
        member = Completeness.PARTIAL.value
    elif member_health.status in {CollectionStatus.UNAVAILABLE.value, CollectionStatus.FAILED.value, CollectionStatus.UNSUPPORTED.value}:
        member = Completeness.UNKNOWN.value
    else:
        member = Completeness.UNKNOWN.value
    if any(issue.materiality == Materiality.MEMBER_QUERY.value and issue.severity == Severity.ERROR.value for issue in issues):
        member = Completeness.UNKNOWN.value if member != Completeness.NOT_REQUESTED.value else member

    active_health = collections["active_threads"]
    archived_health = collections["archived_threads"]
    if active_health.status == CollectionStatus.NOT_REQUESTED.value and archived_health.status == CollectionStatus.NOT_REQUESTED.value:
        thread = Completeness.NOT_REQUESTED.value
    elif any(
        health.status in {CollectionStatus.FAILED.value, CollectionStatus.UNAVAILABLE.value, CollectionStatus.UNSUPPORTED.value}
        for health in (active_health, archived_health)
        if health.status != CollectionStatus.NOT_REQUESTED.value
    ):
        thread = Completeness.UNKNOWN.value
    elif any(health.status == CollectionStatus.PARTIAL.value for health in (active_health, archived_health)):
        thread = Completeness.PARTIAL.value
    elif any(
        (health.expected_count is not None and health.received_count is not None and health.expected_count != health.received_count)
        or health.cursor_complete is False
        for health in (active_health, archived_health)
        if health.status != CollectionStatus.NOT_REQUESTED.value
    ):
        thread = Completeness.PARTIAL.value
    else:
        thread = Completeness.COMPLETE.value
    if any(issue.materiality == Materiality.THREAD_QUERY.value and issue.severity == Severity.ERROR.value for issue in issues):
        thread = Completeness.UNKNOWN.value
    return structural, member, thread


def normalize_bundle(bundle: dict[str, Any]) -> NormalizedSnapshot:
    """Normalize a Discord-shaped fixture bundle into a canonical snapshot.

    The function performs no network or Discord write operations.
    """

    if not isinstance(bundle, dict):
        raise SnapshotValidationError("input bundle must be a JSON object")
    profile = str(bundle.get("scan_profile", "FIXTURE_IMPORT")).upper()
    if profile not in _ALLOWED_PROFILES:
        raise SnapshotValidationError(f"unsupported scan_profile: {profile}")

    started_at = utc_timestamp(bundle.get("started_at", _now()), "started_at")
    completed_at = utc_timestamp(bundle.get("completed_at", _now()), "completed_at")
    observed_at = completed_at

    raw_records = {key: bundle.get(key) for key in _COLLECTION_KEYS}
    collections = {key: _collection_health(bundle, key, raw_records[key]) for key in _COLLECTION_KEYS}
    issues = _IssueCollector()
    _collection_issues(collections, issues)
    for key, records in raw_records.items():
        if isinstance(records, list) and collections[key].received_count is not None and collections[key].received_count != len(records):
            issues.add(
                "COUNT_MISMATCH",
                Severity.WARNING,
                Materiality.MEMBER_QUERY if key == "members" else Materiality.FUTURE_ANALYSIS,
                "collection",
                details={
                    "resource": key,
                    "declared_received_count": collections[key].received_count,
                    "input_record_count": len(records),
                },
            )

    if raw_records["guild"] is None:
        raise SnapshotValidationError("guild record is required")
    if not isinstance(raw_records["guild"], dict):
        raise SnapshotValidationError("guild must be an object")
    guild = _normalize_guild(raw_records["guild"], observed_at)

    roles: dict[str, NormalizedRole] | None = None
    if raw_records["roles"] is not None:
        if not isinstance(raw_records["roles"], list):
            raise SnapshotValidationError("roles must be a list or null")
        roles = _unique_map(
            [_normalize_role(raw, guild.id, observed_at) for raw in raw_records["roles"]], "role"
        )
        everyone = roles.get(guild.id)
        if everyone is None:
            issues.add(
                "EVERYONE_ROLE_MISSING",
                Severity.ERROR,
                Materiality.STRUCTURAL,
                "guild",
                guild.id,
            )
        elif not everyone.is_everyone:
            issues.add(
                "EVERYONE_ROLE_ID_MISMATCH",
                Severity.ERROR,
                Materiality.STRUCTURAL,
                "role",
                everyone.id,
            )
        for role in roles.values():
            unknown = bigint(role.permissions_decimal, "role.permissions") & ~KNOWN_PERMISSION_MASK
            if unknown:
                issues.add(
                    "UNKNOWN_PERMISSION_BIT_PRESENT",
                    Severity.INFORMATIONAL,
                    Materiality.FUTURE_ANALYSIS,
                    "role",
                    role.id,
                    details={"unknown_bits_hex": hex(unknown)},
                    source_status="UNKNOWN",
                )

    channels: dict[str, NormalizedChannel] | None = None
    if raw_records["channels"] is not None:
        if not isinstance(raw_records["channels"], list):
            raise SnapshotValidationError("channels must be a list or null")
        channels = _unique_map(
            [_normalize_channel(raw, guild.id, observed_at, issues) for raw in raw_records["channels"]],
            "channel",
        )
        _classify_sync(channels, issues)

    thread_items: list[NormalizedThread] = []
    for key, scope in (("active_threads", "ACTIVE_GUILD"), ("archived_threads", "ARCHIVED_PUBLIC")):
        raw = raw_records[key]
        if raw is not None:
            if not isinstance(raw, list):
                raise SnapshotValidationError(f"{key} must be a list or null")
            thread_items.extend(_normalize_thread(item, guild.id, observed_at, str(item.get("_source_scope", scope))) for item in raw)
    threads = _unique_map(thread_items, "thread") if thread_items else ({} if any(raw_records[k] == [] for k in ("active_threads", "archived_threads")) else None)
    if threads is not None:
        for thread in threads.values():
            if thread.type_code not in THREAD_TYPE_CODES:
                issues.add(
                    "UNKNOWN_CHANNEL_TYPE",
                    Severity.WARNING,
                    Materiality.THREAD_QUERY,
                    "thread",
                    thread.id,
                    details={"type_code": thread.type_code},
                    source_status="NEEDS_REVIEW",
                )
            if channels is None or thread.parent_id is None or thread.parent_id not in channels:
                issues.add(
                    "THREAD_PARENT_MISSING",
                    Severity.ERROR,
                    Materiality.THREAD_QUERY,
                    "thread",
                    thread.id,
                    related_ids=[thread.parent_id] if thread.parent_id else [],
                )
            else:
                parent = channels[thread.parent_id]
                if parent.type_code not in {0, 5, 15, 16}:
                    issues.add(
                        "THREAD_PARENT_UNSUPPORTED",
                        Severity.ERROR,
                        Materiality.THREAD_QUERY,
                        "thread",
                        thread.id,
                        related_ids=[parent.id],
                        details={"parent_type_code": parent.type_code},
                    )

    members: dict[str, NormalizedMember] | None = None
    if raw_records["members"] is not None:
        if not isinstance(raw_records["members"], list):
            raise SnapshotValidationError("members must be a list or null")
        member_items = [
            _normalize_member(
                raw,
                guild.id,
                observed_at,
                "WHO_CAN_TEMPORARY" if profile == "WHO_CAN_TEMPORARY" else "TARGETED",
            )
            for raw in raw_records["members"]
        ]
        members = _unique_map(member_items, "member")
        _derive_member_highest_roles(members, roles, guild.id, issues)

    memberships: dict[str, NormalizedThreadMembership] | None = None
    if raw_records["thread_memberships"] is not None:
        if not isinstance(raw_records["thread_memberships"], list):
            raise SnapshotValidationError("thread_memberships must be a list or null")
        membership_items = [_normalize_membership(raw, observed_at) for raw in raw_records["thread_memberships"]]
        membership_map: dict[str, NormalizedThreadMembership] = {}
        for item in membership_items:
            key = f"{item.thread_id}:{item.member_id}"
            if key in membership_map:
                raise SnapshotValidationError(f"duplicate thread membership id: {key}")
            membership_map[key] = item
            if threads is not None and item.thread_id not in threads:
                issues.add(
                    "THREAD_PARENT_MISSING",
                    Severity.WARNING,
                    Materiality.THREAD_QUERY,
                    "thread_membership",
                    key,
                    related_ids=[item.thread_id],
                    details={"reason": "thread record unavailable"},
                )
        memberships = dict(sorted(membership_map.items()))

    member_health = collections["members"]
    member_collection_authoritative = (
        profile == "WHO_CAN_TEMPORARY"
        and member_health.status == CollectionStatus.COMPLETE.value
        and member_health.cursor_complete is not False
        and not (
            member_health.expected_count is not None
            and member_health.received_count is not None
            and member_health.expected_count != member_health.received_count
        )
    )
    _validate_overwrite_references(
        channels, roles, members, member_collection_authoritative, issues
    )

    # Stable issue ordering makes structural fingerprints independent of input ordering.
    issues.items.sort(
        key=lambda issue: (
            issue.code,
            issue.entity_type,
            issue.entity_id or "",
            tuple(issue.related_ids),
            json.dumps(issue.details, sort_keys=True, separators=(",", ":")),
        )
    )
    for index, issue in enumerate(issues.items, start=1):
        issue.issue_id = f"SI-{index:04d}"

    structural, member_comp, thread_comp = _completeness(profile, collections, issues.items)

    counts = {
        "roles": len(roles) if roles is not None else None,
        "channels": len(channels) if channels is not None else None,
        "threads": len(threads) if threads is not None else None,
        "members": len(members) if members is not None else None,
        "thread_memberships": len(memberships) if memberships is not None else None,
        "issues": len(issues.items),
    }

    snapshot = NormalizedSnapshot(
        schema_version=SNAPSHOT_SCHEMA_VERSION,
        scanner_contract_version=SCANNER_CONTRACT_VERSION,
        permission_definition_version=PERMISSION_DEFINITION_VERSION,
        snapshot_id=str(uuid4()),
        snapshot_fingerprint_sha256=None,
        structural_fingerprint_sha256=None,
        scan_profile=profile,
        guild_id=guild.id,
        started_at=started_at,
        completed_at=completed_at,
        source_api_version=bundle.get("source_api_version"),
        source_library=bundle.get("source_library"),
        source_library_version=bundle.get("source_library_version"),
        structural_completeness=structural,
        member_completeness=member_comp,
        thread_completeness=thread_comp,
        collections=collections,
        guild=guild,
        roles=roles,
        channels=channels,
        threads=threads,
        members=members,
        thread_memberships=memberships,
        bindings=_bindings(roles),
        issues=issues.items,
        counts=counts,
        metadata={
            "message_content_collected": False,
            "write_operations_available": False,
            "fixture_import": profile == "FIXTURE_IMPORT",
            "source_adapter_version": bundle.get("source_adapter_version"),
            "gateway_connected": bool(bundle.get("gateway_connected", False)),
            "member_acquisition": bundle.get("member_acquisition"),
        },
    )
    data = snapshot.as_dict()
    snapshot.snapshot_fingerprint_sha256 = exact_fingerprint(data)
    data = snapshot.as_dict()
    snapshot.structural_fingerprint_sha256 = structural_fingerprint(data)
    return snapshot
