"""Atomic privacy-safe receipt for a future authorized Pass 4E session."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import time
from typing import Any, Callable
from .private_alpha_pass4e_session_artifacts import SessionArtifactPaths, SessionArtifactPathError


HISTORICAL_RUNTIME_RECEIPT_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-RUNTIME-RECEIPT-0.1"
AUTOCOMPLETE_RUNTIME_RECEIPT_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-RUNTIME-RECEIPT-0.2"
RUNTIME_RECEIPT_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-RUNTIME-RECEIPT-0.3"
APPROVED_RECEIPT_BASENAME = "stage8_pass4e_runtime_receipt.json"

# Additive 0.3 fields.  Historical receipts remain readable without migration;
# current writers persist only these symbolic startup boundaries and never an
# exception message, traceback, object representation, or credential material.
RUNTIME_STARTUP_STAGES = (
    "RECEIPT_INITIALIZATION", "RECEIPT_DURABILITY", "TOKEN_BOUNDARY_ENTRY",
    "CLIENT_INPUT_ASSEMBLY", "COMMAND_MANIFEST_BUILD", "COMMAND_TREE_CONSTRUCTION",
    "VALIDATION_ROUTE_BINDING", "EVENT_HANDLER_REGISTRATION", "CLIENT_CONSTRUCTION",
    "CLIENT_START_PREPARATION", "CLIENT_START_INVOCATION", "GATEWAY_CONNECT_PENDING",
    "GATEWAY_SESSION_OPEN", "READY_EVENT",
)
RUNTIME_STARTUP_EXCEPTION_FAMILIES = {
    "ATTRIBUTE_ERROR", "TYPE_ERROR", "VALUE_ERROR", "RUNTIME_ERROR", "OS_ERROR",
    "TIMEOUT_ERROR", "CANCELLED_ERROR", "UNKNOWN",
}


class RuntimeReceiptError(RuntimeError):
    pass


def read_runtime_receipt(path: Path) -> dict[str, Any]:
    """Read a current or historical receipt without rewriting or migrating it."""
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_READ_FAILED") from None
    if not isinstance(value, dict) or value.get("receipt_contract") not in {
        HISTORICAL_RUNTIME_RECEIPT_CONTRACT, AUTOCOMPLETE_RUNTIME_RECEIPT_CONTRACT,
        RUNTIME_RECEIPT_CONTRACT,
    }:
        raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_CONTRACT_INVALID")
    return value


def record_cleanup_sync_in_receipt(
    path: Path, *, verified: bool, temporary_route_removed: bool,
    total_sync_writes: int, global_sync_writes: int, other_guild_sync_writes: int,
) -> dict[str, Any]:
    """Atomically append bounded cleanup facts to a terminal current receipt."""
    value = read_runtime_receipt(path)
    if value.get("receipt_contract") != RUNTIME_RECEIPT_CONTRACT or value.get("terminal_completion_state") not in {"PASS", "FAILED_CLOSED"}:
        raise RuntimeReceiptError("STAGE8_PASS4E_CLEANUP_SYNC_RECEIPT_INVALID")
    if value.get("cleanup_sync_verified") or not value.get("cleanup_sync_required"):
        raise RuntimeReceiptError("STAGE8_PASS4E_CLEANUP_SYNC_BINDING_INVALID")
    if not verified or not temporary_route_removed or total_sync_writes != 2 or global_sync_writes or other_guild_sync_writes:
        raise RuntimeReceiptError("STAGE8_PASS4E_CLEANUP_SYNC_INCOMPLETE")
    value.update({
        "cleanup_sync_verified": True, "temporary_route_removed": True,
        "total_sync_writes": 2, "global_sync_writes": 0, "other_guild_sync_writes": 0,
    })
    target = Path(path); temporary = target.with_suffix(target.suffix + ".cleanup.tmp")
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary, target)
    except OSError:
        temporary.unlink(missing_ok=True)
        raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_WRITE_FAILED") from None
    return read_runtime_receipt(target)


def recover_interrupted_receipt(path: Path, *, reason: str = "OPERATOR_SESSION_INTERRUPTED") -> dict[str, Any]:
    """Close an orphaned current receipt before attaching cleanup evidence."""
    value = read_runtime_receipt(path)
    if value.get("receipt_contract") != RUNTIME_RECEIPT_CONTRACT or value.get("terminal_completion_state") != "IN_PROGRESS":
        raise RuntimeReceiptError("STAGE8_PASS4E_INTERRUPTED_RECEIPT_NOT_RECOVERABLE")
    if not isinstance(reason, str) or not re.fullmatch(r"[A-Z0-9_]{3,128}", reason):
        raise RuntimeReceiptError("STAGE8_PASS4E_INTERRUPTED_RECEIPT_REASON_INVALID")
    value.update({
        "cleanup_reason": reason,
        "lifecycle_state": "FAILED_CLOSED",
        "terminal_completion_state": "FAILED_CLOSED",
        "runtime_startup_exception_family": "TIMEOUT_ERROR",
        "runtime_startup_failure_code": "STAGE8_PASS4E_RUNTIME_STARTUP_FAILURE",
        "runtime_startup_failure_stage": "GATEWAY_CONNECT_PENDING",
    })
    target = Path(path); temporary = target.with_suffix(target.suffix + ".recovery.tmp")
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary, target)
    except OSError:
        temporary.unlink(missing_ok=True)
        raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_RECOVERY_WRITE_FAILED") from None
    return read_runtime_receipt(target)


class RuntimeReceiptWriter:
    """Writes only frozen route names, classifications, and bounded counters."""

    def __init__(self, path: Path, *, clock: Callable[[], float] = time.monotonic, session_artifacts: SessionArtifactPaths | None = None):
        self._path = Path(path)
        if session_artifacts is None:
            if self._path.name != APPROVED_RECEIPT_BASENAME:
                raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_PATH_INVALID")
        else:
            try:
                validated = session_artifacts.validated()
            except SessionArtifactPathError as exc:
                raise RuntimeReceiptError(str(exc)) from None
            if self._path.resolve(strict=False) != validated.receipt_path:
                raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_SESSION_PATH_MISMATCH")
            self._path = validated.receipt_path
        if self._path.exists():
            raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_ALREADY_EXISTS")
        self._clock = clock
        self._started = clock()
        self._terminal = False
        self._value: dict[str, Any] = {
            "receipt_contract": RUNTIME_RECEIPT_CONTRACT,
            "lifecycle_state": "RECEIPT_CREATED",
            "terminal_completion_state": "IN_PROGRESS",
            "invocations": [],
            "accepted_invocation_count": 0,
            "rejected_invocation_count": 0,
            "autocomplete_request_count": 0,
            "autocomplete_response_count": 0,
            "autocomplete_requests_received": 0,
            "autocomplete_responses_attempted": 0,
            "autocomplete_responses_completed": 0,
            "autocomplete_response_failures": 0,
            "autocomplete_last_failure_classification": None,
            "autocomplete_events": [],
            "defer_count": 0,
            "original_response_edit_count": 0,
            "initial_ephemeral_error_count": 0,
            "other_prohibited_response_attempt_count": 0,
            "discord_login_get_count": 0,
            "gateway_connection_count": 0,
            "reconnect_count": 0,
            "interaction_response_write_count": 0,
            "command_registration_count": 0,
            "guild_server_object_write_count": 0,
            "cleanup_reason": None,
            "client_close_count": 0,
            "elapsed_seconds": 0.0,
            "privacy_validation_state": "PASS",
            "raw_interaction_retained": False,
            "identifier_retained": False,
            "option_value_retained": False,
            "token_retained": False,
            "absolute_path_retained": False,
            "exact_route_plan_validated": False,
            "all_required_routes_completed": False,
            "duplicate_route_admission_count": 0,
            "route_plan_rejection_count": 0,
            "canonical_option_rejection_count": 0,
            "unexpected_route_admission_count": 0,
            "unexpected_route_rejection_count": 0,
            "role_pair_rejection_count": 0,
            "malformed_invocation_rejection_count": 0,
            "last_route_plan_rejection_classification": None,
            "pair_established": False,
            "pair_consistent": False,
            "canonical_plan_validated": False,
            "exact_route_plan": [],
            "validation_surface_used": False,
            "validation_surface_version": None,
            "validation_surface_case_classifications": [],
            "internal_route_mapping_validated": False,
            "canonical_mapping_validated": False,
            "validation_manifest_binding_validated": False,
            "pre_live_sync_verified": False,
            "cleanup_sync_required": False,
            "cleanup_sync_verified": False,
            "temporary_route_removed": False,
            "total_sync_writes": 0,
            "global_sync_writes": 0,
            "other_guild_sync_writes": 0,
            "runtime_startup_last_completed_stage": None,
            "runtime_startup_failure_stage": None,
            "runtime_startup_failure_code": None,
            "runtime_startup_exception_family": None,
            "token_boundary_entered": False,
            "client_construction_attempted": False,
            "client_constructed": False,
            "client_start_invoked": False,
            "gateway_connect_invoked": False,
            "gateway_session_opened": False,
            "ready_event_observed": False,
        }
        self._persist()

    def _persist(self) -> None:
        self._value["elapsed_seconds"] = round(max(0.0, self._clock() - self._started), 6)
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self._path.with_suffix(self._path.suffix + ".tmp")
            encoded = json.dumps(self._value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
            with temporary.open("w", encoding="utf-8", newline="\n") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self._path)
        except Exception:
            raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_WRITE_FAILED") from None

    def transition(self, state: str) -> None:
        if self._terminal:
            raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_ALREADY_TERMINAL")
        self._value["lifecycle_state"] = str(state)
        self._persist()

    def startup_checkpoint(self, stage: str) -> None:
        """Durably record one monotonic, completed pre-Gateway boundary."""
        if stage not in RUNTIME_STARTUP_STAGES:
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_STAGE_INVALID")
        current = self._value["runtime_startup_last_completed_stage"]
        if current is not None and RUNTIME_STARTUP_STAGES.index(stage) < RUNTIME_STARTUP_STAGES.index(current):
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_STAGE_REGRESSION")
        if self._value["runtime_startup_failure_stage"] is not None:
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_ALREADY_FAILED")
        self._value["runtime_startup_last_completed_stage"] = stage
        flags = {
            "TOKEN_BOUNDARY_ENTRY": "token_boundary_entered",
            "CLIENT_CONSTRUCTION": "client_constructed",
            "CLIENT_START_INVOCATION": "client_start_invoked",
            "GATEWAY_CONNECT_PENDING": "gateway_connect_invoked",
            "GATEWAY_SESSION_OPEN": "gateway_session_opened",
            "READY_EVENT": "ready_event_observed",
        }
        if stage in flags:
            self._value[flags[stage]] = True
        self._persist()

    def startup_construction_attempted(self) -> None:
        if self._value["runtime_startup_failure_stage"] is not None:
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_ALREADY_FAILED")
        self._value["client_construction_attempted"] = True
        self._persist()

    def startup_failure(self, *, stage: str, code: str, exception_family: str) -> None:
        """Persist a restricted, privacy-safe failure classification before terminal state."""
        if stage not in RUNTIME_STARTUP_STAGES:
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_STAGE_INVALID")
        if not isinstance(code, str) or re.fullmatch(r"STAGE8_PASS4E_[A-Z0-9_]+", code) is None:
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_FAILURE_CODE_INVALID")
        if exception_family not in RUNTIME_STARTUP_EXCEPTION_FAMILIES:
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_EXCEPTION_FAMILY_INVALID")
        if self._value["runtime_startup_failure_stage"] is not None:
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_ALREADY_FAILED")
        self._value.update({
            "runtime_startup_failure_stage": stage,
            "runtime_startup_failure_code": code,
            "runtime_startup_exception_family": exception_family,
        })
        self._persist()

    def gateway_connected(self) -> None:
        if self._value["gateway_connection_count"]:
            self._value["reconnect_count"] += 1
            self._persist()
            raise RuntimeReceiptError("STAGE8_PASS4E_RECONNECT_PROHIBITED")
        self._value["discord_login_get_count"] = 2
        self._value["gateway_connection_count"] = 1
        self.transition("GATEWAY_CONNECTED")

    def invocation(self, *, ordinal: int, route_name: str | None, accepted: bool, stable_error: str | None = None) -> None:
        item = {
            "invocation_ordinal": int(ordinal),
            "route_name": route_name,
            "classification": "ACCEPTED" if accepted else "REJECTED",
            "envelope_branch": None,
            "report_subtype": None,
            "stable_error": stable_error,
            "defer_count": 0,
            "original_response_edit_count": 0,
            "other_prohibited_response_attempt_count": 0,
            "completion_state": "IN_PROGRESS" if accepted else "REJECTED",
        }
        self._value["invocations"].append(item)
        key = "accepted_invocation_count" if accepted else "rejected_invocation_count"
        self._value[key] += 1
        self.transition("INVOCATION_ACCEPTED" if accepted else "INVOCATION_REJECTED")

    def _invocation(self, ordinal: int) -> dict[str, Any]:
        item = next((item for item in self._value["invocations"] if item["invocation_ordinal"] == ordinal), None)
        if item is None:
            raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_INVOCATION_MISSING")
        return item

    def response_deferred(self, ordinal: int) -> None:
        self._invocation(ordinal)["defer_count"] += 1
        self._value["defer_count"] += 1
        self._value["interaction_response_write_count"] += 1
        self.transition("RESPONSE_DEFERRED")

    def original_response_edited(self, ordinal: int) -> None:
        self._invocation(ordinal)["original_response_edit_count"] += 1
        self._value["original_response_edit_count"] += 1
        self._value["interaction_response_write_count"] += 1
        self.transition("ORIGINAL_RESPONSE_EDITED")

    def initial_error_sent(self) -> None:
        self._value["initial_ephemeral_error_count"] += 1
        self._value["interaction_response_write_count"] += 1
        self.transition("INITIAL_EPHEMERAL_ERROR_SENT")

    def route_completed(self, ordinal: int, *, envelope_branch: str | None, report_subtype: str | None, stable_error: str | None) -> None:
        item = self._invocation(ordinal)
        item.update({"envelope_branch": envelope_branch, "report_subtype": report_subtype, "stable_error": stable_error, "completion_state": "COMPLETE"})
        self.transition("ROUTE_COMPLETED")

    def route_plan_updated(self, value: dict[str, Any]) -> None:
        """Persist only public plan state; symbolic bindings never reach disk."""
        routes = value.get("routes")
        if not isinstance(routes, list):
            raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_ROUTE_PLAN_INVALID")
        self._value.update({
            "exact_route_plan_validated": bool(value.get("exact_route_plan_validated")),
            "all_required_routes_completed": bool(value.get("all_required_routes_completed")),
            "duplicate_route_admission_count": int(value.get("duplicate_route_admission_count", 0)),
            "route_plan_rejection_count": int(value.get("route_plan_rejection_count", 0)),
            "canonical_option_rejection_count": int(value.get("canonical_option_rejection_count", 0)),
            "unexpected_route_admission_count": int(value.get("unexpected_route_admission_count", 0)),
            "unexpected_route_rejection_count": int(value.get("unexpected_route_rejection_count", 0)),
            "role_pair_rejection_count": int(value.get("role_pair_rejection_count", 0)),
            "malformed_invocation_rejection_count": int(value.get("malformed_invocation_rejection_count", 0)),
            "last_route_plan_rejection_classification": value.get("last_route_plan_rejection_classification"),
            "pair_established": bool(value.get("pair_established")),
            "pair_consistent": bool(value.get("pair_consistent")),
            "canonical_plan_validated": bool(value.get("exact_route_plan_validated")),
            "exact_route_plan": routes,
        })
        self.transition("EXACT_ROUTE_PLAN_UPDATED")

    def validation_surface_mapped(
        self, *, version: str, selected_case_classification: str | None,
        internal_route_mapping_validated: bool, canonical_mapping_validated: bool,
    ) -> None:
        """Persist only bounded symbolic validation-surface classifications."""
        allowed = {"PERMISSION_VIEW_CHANNEL", "CAPABILITY_MESSAGE_SEND", "ACTION_MEMBER_KICK"}
        if selected_case_classification not in allowed:
            raise RuntimeReceiptError("STAGE8_PASS4E_VALIDATION_SURFACE_CLASSIFICATION_INVALID")
        self._value["validation_surface_used"] = True
        self._value["validation_surface_version"] = str(version)
        self._value["validation_surface_case_classifications"].append(selected_case_classification)
        self._value["internal_route_mapping_validated"] = bool(internal_route_mapping_validated)
        self._value["canonical_mapping_validated"] = bool(canonical_mapping_validated)
        self.transition("VALIDATION_SURFACE_MAPPED")

    def pre_live_sync_bound(self, *, validation_manifest_binding_validated: bool) -> None:
        if not validation_manifest_binding_validated or self._value["pre_live_sync_verified"]:
            raise RuntimeReceiptError("STAGE8_PASS4E_PRE_LIVE_SYNC_BINDING_INVALID")
        self._value["validation_manifest_binding_validated"] = True
        self._value["pre_live_sync_verified"] = True
        self._value["cleanup_sync_required"] = True
        self._value["total_sync_writes"] = 1
        self.transition("PRE_LIVE_SYNC_BOUND")

    def cleanup_sync_recorded(
        self, *, verified: bool, temporary_route_removed: bool,
        total_sync_writes: int, global_sync_writes: int, other_guild_sync_writes: int,
    ) -> None:
        """Append one post-runtime cleanup fact without altering terminal truth."""
        if self._value["cleanup_sync_verified"] or not self._value["cleanup_sync_required"]:
            raise RuntimeReceiptError("STAGE8_PASS4E_CLEANUP_SYNC_BINDING_INVALID")
        if not verified or not temporary_route_removed or total_sync_writes != 2 or global_sync_writes or other_guild_sync_writes:
            raise RuntimeReceiptError("STAGE8_PASS4E_CLEANUP_SYNC_INCOMPLETE")
        self._value["cleanup_sync_verified"] = True
        self._value["temporary_route_removed"] = True
        self._value["total_sync_writes"] = 2
        self._value["global_sync_writes"] = 0
        self._value["other_guild_sync_writes"] = 0
        self._persist()

    def _autocomplete_event(self, sequence: int) -> dict[str, Any]:
        item = next((item for item in self._value["autocomplete_events"] if item["sequence"] == sequence), None)
        if item is None:
            raise RuntimeReceiptError("STAGE8_PASS4E_AUTOCOMPLETE_EVENT_MISSING")
        return item

    def autocomplete_received(
        self, *, route_name: str | None, option_name: str | None,
        query_length_classification: str,
    ) -> int:
        sequence = self._value["autocomplete_requests_received"] + 1
        self._value["autocomplete_requests_received"] = sequence
        self._value["autocomplete_request_count"] = sequence
        self._value["autocomplete_events"].append({
            "sequence": sequence,
            "route_name": route_name,
            "option_name": option_name,
            "query_length_classification": str(query_length_classification),
            "choice_count": None,
            "response_state": "REQUEST_RECEIVED",
            "failure_classification": None,
        })
        self.transition("AUTOCOMPLETE_REQUEST_RECEIVED")
        return sequence

    def autocomplete_attempted(self, sequence: int, *, choice_count: int) -> None:
        item = self._autocomplete_event(sequence)
        if item["response_state"] != "REQUEST_RECEIVED":
            raise RuntimeReceiptError("STAGE8_PASS4E_AUTOCOMPLETE_ATTEMPT_ORDER_INVALID")
        self._value["autocomplete_responses_attempted"] += 1
        item.update({"choice_count": int(choice_count), "response_state": "RESPONSE_ATTEMPTED"})
        self.transition("AUTOCOMPLETE_RESPONSE_ATTEMPTED")

    def autocomplete_completed(self, sequence: int, *, accepted: bool) -> None:
        item = self._autocomplete_event(sequence)
        if item["response_state"] != "RESPONSE_ATTEMPTED":
            raise RuntimeReceiptError("STAGE8_PASS4E_AUTOCOMPLETE_COMPLETION_ORDER_INVALID")
        self._value["autocomplete_responses_completed"] += 1
        self._value["autocomplete_response_count"] = self._value["autocomplete_responses_completed"]
        self._value["interaction_response_write_count"] += 1
        item["response_state"] = "RESPONSE_COMPLETED" if accepted else "RESPONSE_COMPLETED_REJECTED"
        self.transition("AUTOCOMPLETE_RESPONDED" if accepted else "AUTOCOMPLETE_REJECTED")

    def autocomplete_failed(self, sequence: int, *, classification: str) -> None:
        item = self._autocomplete_event(sequence)
        self._value["autocomplete_response_failures"] += 1
        self._value["autocomplete_last_failure_classification"] = str(classification)
        item.update({"response_state": "FAILED", "failure_classification": str(classification)})
        self.transition("AUTOCOMPLETE_FAILED")

    def autocomplete(self, *, route_name: str | None, accepted: bool, responded: bool) -> None:
        """Compatibility helper for pre-0.2 callers and focused historical tests."""
        sequence = self.autocomplete_received(
            route_name=route_name, option_name=None, query_length_classification="UNAVAILABLE",
        )
        if responded:
            self.autocomplete_attempted(sequence, choice_count=0)
            self.autocomplete_completed(sequence, accepted=accepted)
        else:
            self.autocomplete_failed(sequence, classification="AUTOCOMPLETE_RESPONSE_EXCEPTION")

    def cleanup_started(self, reason: str) -> None:
        if self._terminal:
            return
        self._value["cleanup_reason"] = str(reason)
        self.transition("CLEANUP_STARTED")

    def client_closed(self) -> None:
        if self._value["client_close_count"] == 0:
            self._value["client_close_count"] = 1
        if not self._terminal:
            self.transition("CLIENT_CLOSED")

    def terminal(self, state: str) -> None:
        if self._terminal:
            return
        reason = self._value.get("cleanup_reason")
        if not isinstance(reason, str) or not reason.strip():
            raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_CLEANUP_REASON_REQUIRED")
        self._value["terminal_completion_state"] = str(state)
        self._value["lifecycle_state"] = "TERMINAL"
        self._terminal = True
        self._persist()

    @property
    def public_value(self) -> dict[str, Any]:
        return json.loads(json.dumps(self._value))


__all__ = [
    "APPROVED_RECEIPT_BASENAME", "AUTOCOMPLETE_RUNTIME_RECEIPT_CONTRACT",
    "HISTORICAL_RUNTIME_RECEIPT_CONTRACT", "RUNTIME_RECEIPT_CONTRACT",
    "RuntimeReceiptError", "RuntimeReceiptWriter", "read_runtime_receipt",
    "record_cleanup_sync_in_receipt",
]
