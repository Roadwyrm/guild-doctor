"""Stage 6 Pass 1 command catalog declaration only."""
from .discord_engine_routing_contract import ROUTES
COMMAND_CATALOG_CONTRACT="GUILD-DOCTOR-DISCORD-COMMAND-CONTRACT-0.1"
# Keep the catalog aligned with the authoritative 13-command runtime manifest.
# Legacy scanner controls (status/scan/scan-health/server-summary) and the
# retired diagnose entry are not part of the current public command contract.
NAMES=('why-can','why-cannot','who-can','who-cannot','who-unknown','find-setting','explain-role','explain-category','explain-channel','compare-role-permission','compare-role-capability','compare-role-action','server-report')
COMMANDS={name:{'key':f'guild_doctor.{name.replace("-","_")}','guild_only':True,'owner_only':True,'visibility':'EPHEMERAL','argument_types':('DISCORD_SELECTED_OBJECT','ENUM_OR_FIXED_OPTION'),'route':ROUTES.get(name,'EXISTING_SCANNER'),'implementation_pass':'PASS2' if name!='diagnose' else 'PASS3'} for name in NAMES}
