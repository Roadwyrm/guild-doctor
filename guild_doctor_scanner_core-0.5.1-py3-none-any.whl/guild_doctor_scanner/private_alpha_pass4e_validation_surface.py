"""Offline-first deterministic command surface for Pass 4E validation.

The temporary surface is never part of ``COMMAND_MANIFEST``.  Callers must
select the validation mode explicitly, and the only supported live deployment
plan is one authorized-guild synchronization followed by an exact cleanup
synchronization.  This module performs no Discord, token, client, Gateway, or
network operation.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
import hashlib
import json
from types import MappingProxyType
from typing import Any, Mapping

from .discord_command_manifest import (
    COMMAND_MANIFEST,
    CommandOption,
    RuntimeCommand,
    manifest_fingerprint,
)


VALIDATION_SURFACE_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-VALIDATION-SURFACE-0.1"
VALIDATION_SURFACE_VERSION = "PASS4E_DETERMINISTIC_CHOICES_0.1"
TEMPORARY_COMMAND_NAME = "pass4e-compare"


class ValidationSurfaceMode(str, Enum):
    NORMAL = "NORMAL"
    PASS4E_VALIDATION = "PASS4E_VALIDATION"
    CLEANUP = "CLEANUP"


@dataclass(frozen=True, slots=True)
class ValidationCase:
    choice_token: str
    classification: str
    internal_route: str
    option_name: str
    canonical_value: str


@dataclass(frozen=True, slots=True)
class ValidationSurfaceDecision:
    state: str
    stable_error: str | None
    selected_case_classification: str | None
    internal_route_mapping_validated: bool
    canonical_mapping_validated: bool
    mapped_source: Any | None


@dataclass(frozen=True, slots=True)
class ValidationSurfaceMappedSource:
    interaction_type: int
    command_type: int
    guild_id: str
    actor_id: str
    route_name: str
    options: Mapping[str, Any]
    is_direct_message: bool
    is_private_channel: bool
    has_attachments: bool = False
    has_message_content: bool = False


class ValidationSurfaceSession:
    """Process-only role-pair guard and dispatcher for three fixed cases."""

    __slots__ = ("mode", "_ordered_pair")

    def __init__(self, mode: ValidationSurfaceMode):
        if not isinstance(mode, ValidationSurfaceMode):
            raise TypeError("STAGE8_PASS4E_VALIDATION_SURFACE_MODE_INVALID")
        self.mode = mode
        self._ordered_pair: tuple[str, str] | None = None

    @staticmethod
    def _identifier(value: Any) -> str | None:
        candidate = getattr(value, "id", None)
        rendered = str(candidate) if candidate is not None else ""
        return rendered if rendered.isdecimal() else None

    async def dispatch(
        self, *, source: Any, response_transport: Any, orchestrator: Any,
        case_mapping: Mapping[str, ValidationCase] | None = None,
    ):
        mapping = CASE_MAPPING if case_mapping is None else case_mapping
        decision = map_validation_surface_source(source, mode=self.mode, case_mapping=mapping)
        if decision.state != "ACCEPTED":
            return await orchestrator.reject_pre_admission(
                stable_error=decision.stable_error or "STAGE8_PASS4E_VALIDATION_SURFACE_MAPPING_INVALID",
                response_transport=response_transport,
            )
        first = self._identifier(decision.mapped_source.options.get("first-role"))
        second = self._identifier(decision.mapped_source.options.get("second-role"))
        snapshot = getattr(getattr(orchestrator, "bound_snapshot", None), "snapshot", None)
        roles = snapshot.get("roles") if isinstance(snapshot, Mapping) else None
        pair_valid = (
            first is not None and second is not None and first != second
            and isinstance(roles, Mapping) and first in roles and second in roles
        )
        if not pair_valid:
            return await orchestrator.reject_pre_admission(
                stable_error="STAGE8_PASS4E_VALIDATION_SURFACE_ROLE_PAIR_INVALID",
                response_transport=response_transport,
                rejection_category="ROLE_PAIR",
            )
        pair = (first, second)
        if self._ordered_pair is not None and pair != self._ordered_pair:
            return await orchestrator.reject_pre_admission(
                stable_error="STAGE8_PASS4E_VALIDATION_SURFACE_ROLE_PAIR_INCONSISTENT",
                response_transport=response_transport,
                rejection_category="ROLE_PAIR",
            )
        if orchestrator.runtime_receipt is not None:
            orchestrator.runtime_receipt.validation_surface_mapped(
                version=VALIDATION_SURFACE_VERSION,
                selected_case_classification=decision.selected_case_classification,
                internal_route_mapping_validated=decision.internal_route_mapping_validated,
                canonical_mapping_validated=decision.canonical_mapping_validated,
            )
        outcome = await orchestrator.handle(decision.mapped_source, response_transport)
        if outcome.state == "COMPLETED" and self._ordered_pair is None:
            self._ordered_pair = pair
        return outcome

    def clear(self) -> None:
        self._ordered_pair = None


CASE_CHOICES = (
    ("Permission — VIEW_CHANNEL", "permission_view_channel"),
    ("Capability — message.send", "capability_message_send"),
    ("Action — member.kick", "action_member_kick"),
)

_CASES = (
    ValidationCase("permission_view_channel", "PERMISSION_VIEW_CHANNEL", "compare-role-permission", "permission", "VIEW_CHANNEL"),
    ValidationCase("capability_message_send", "CAPABILITY_MESSAGE_SEND", "compare-role-capability", "capability", "message.send"),
    ValidationCase("action_member_kick", "ACTION_MEMBER_KICK", "compare-role-action", "action", "member.kick"),
)
CASE_MAPPING: Mapping[str, ValidationCase] = MappingProxyType({item.choice_token: item for item in _CASES})

TEMPORARY_VALIDATION_COMMAND = RuntimeCommand(
    key=TEMPORARY_COMMAND_NAME,
    slash_name=TEMPORARY_COMMAND_NAME,
    description="Temporarily validate the frozen Pass 4E role-comparison paths.",
    options=(
        CommandOption("first-role", "Choose the first snapshot-backed role.", "role"),
        CommandOption("second-role", "Choose the second snapshot-backed role.", "role"),
        CommandOption(
            "case",
            "Choose the exact frozen Pass 4E comparison case.",
            "string",
            required=True,
            autocomplete=False,
            choices=CASE_CHOICES,
        ),
    ),
    acknowledgement="IMMEDIATE_RESPONSE",
    pagination=False,
    export=False,
    guild_only=True,
    owner_only=True,
    visibility="EPHEMERAL",
    synchronization_status="NOT_AUTHORIZED",
)


def build_validation_manifest(mode: ValidationSurfaceMode) -> tuple[RuntimeCommand, ...]:
    """Compose a manifest only from an explicit typed mode."""
    if not isinstance(mode, ValidationSurfaceMode):
        raise TypeError("STAGE8_PASS4E_VALIDATION_SURFACE_MODE_INVALID")
    if mode is ValidationSurfaceMode.PASS4E_VALIDATION:
        return COMMAND_MANIFEST + (TEMPORARY_VALIDATION_COMMAND,)
    return COMMAND_MANIFEST


def validation_manifest_fingerprint(mode: ValidationSurfaceMode) -> str:
    return manifest_fingerprint(build_validation_manifest(mode))


def serialized_validation_schema(mode: ValidationSurfaceMode) -> dict[str, Any]:
    manifest = build_validation_manifest(mode)
    return {
        "root_name": "guild-doctor",
        "serialized_application_command_object_count": 1,
        "logical_route_definition_count": len(manifest),
        "commands": [
            {
                "name": command.slash_name,
                "description": command.description,
                "options": [asdict(option) for option in command.options],
                "guild_only": command.guild_only,
                "owner_only": command.owner_only,
                "visibility": command.visibility,
            }
            for command in manifest
        ],
    }


def serialized_validation_schema_fingerprint(mode: ValidationSurfaceMode) -> str:
    payload = serialized_validation_schema(mode)
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=list).encode()).hexdigest()


def build_validation_command_group(*, transport: Any, mode: ValidationSurfaceMode, discord: Any, app_commands: Any) -> Any:
    """Build one local command group without constructing a Discord client."""
    if not isinstance(mode, ValidationSurfaceMode):
        raise TypeError("STAGE8_PASS4E_VALIDATION_SURFACE_MODE_INVALID")
    return transport._command_group(build_validation_manifest(mode), discord, app_commands)


def validate_manifest_composition(mode: ValidationSurfaceMode) -> tuple[str, ...]:
    manifest = build_validation_manifest(mode)
    errors: list[str] = []
    keys = tuple(item.key for item in manifest)
    production_keys = tuple(item.key for item in COMMAND_MANIFEST)
    if keys[: len(production_keys)] != production_keys:
        errors.append("VALIDATION_SURFACE_PRODUCTION_MANIFEST_CHANGED")
    expected_count = 14 if mode is ValidationSurfaceMode.PASS4E_VALIDATION else 13
    if len(manifest) != expected_count:
        errors.append("VALIDATION_SURFACE_ROUTE_COUNT_INVALID")
    temporary_count = keys.count(TEMPORARY_COMMAND_NAME)
    if temporary_count != (1 if mode is ValidationSurfaceMode.PASS4E_VALIDATION else 0):
        errors.append("VALIDATION_SURFACE_TEMPORARY_ROUTE_COUNT_INVALID")
    if any(not item.guild_only or not item.owner_only or item.visibility != "EPHEMERAL" for item in manifest):
        errors.append("VALIDATION_SURFACE_PRIVATE_ALPHA_POLICY_INVALID")
    return tuple(errors)


def map_validation_surface_source(
    source: Any,
    *,
    mode: ValidationSurfaceMode,
    case_mapping: Mapping[str, ValidationCase] = CASE_MAPPING,
) -> ValidationSurfaceDecision:
    """Map one fixed choice into a normal internal comparison source.

    No normalization, label parsing, string splitting, or heuristics are used.
    Authorization and resolved-role validation remain the responsibility of the
    normal interaction intake after this deterministic projection.
    """
    if not isinstance(mode, ValidationSurfaceMode) or mode is not ValidationSurfaceMode.PASS4E_VALIDATION:
        return ValidationSurfaceDecision("REJECTED", "STAGE8_PASS4E_VALIDATION_SURFACE_DISABLED", None, False, False, None)
    if str(getattr(source, "route_name", "") or "") != TEMPORARY_COMMAND_NAME:
        return ValidationSurfaceDecision("REJECTED", "STAGE8_PASS4E_VALIDATION_SURFACE_CONTEXT_INVALID", None, False, False, None)
    options = getattr(source, "options", None)
    if not isinstance(options, Mapping):
        return ValidationSurfaceDecision("REJECTED", "STAGE8_PASS4E_VALIDATION_SURFACE_MAPPING_INVALID", None, False, False, None)
    if set(options) != {"first-role", "second-role", "case"}:
        return ValidationSurfaceDecision("REJECTED", "STAGE8_PASS4E_VALIDATION_SURFACE_MAPPING_INVALID", None, False, False, None)
    token = options.get("case")
    if not isinstance(token, str) or token not in case_mapping:
        return ValidationSurfaceDecision("REJECTED", "STAGE8_PASS4E_VALIDATION_SURFACE_UNKNOWN_CASE", None, False, False, None)
    case = case_mapping[token]
    expected = CASE_MAPPING.get(token)
    if not isinstance(case, ValidationCase) or case != expected:
        return ValidationSurfaceDecision("REJECTED", "STAGE8_PASS4E_VALIDATION_SURFACE_MAPPING_INVALID", None, False, False, None)
    mapped_options = {
        "first-role": options.get("first-role"),
        "second-role": options.get("second-role"),
        case.option_name: case.canonical_value,
    }
    mapped = ValidationSurfaceMappedSource(
        interaction_type=getattr(source, "interaction_type", getattr(source, "type", None)),
        command_type=getattr(source, "command_type", 1),
        guild_id=str(getattr(source, "guild_id", "") or ""),
        actor_id=str(getattr(source, "actor_id", "") or ""),
        route_name=case.internal_route,
        options=MappingProxyType(mapped_options),
        is_direct_message=bool(getattr(source, "is_direct_message", False)),
        is_private_channel=bool(getattr(source, "is_private_channel", False)),
        has_attachments=bool(getattr(source, "has_attachments", False)),
        has_message_content=bool(getattr(source, "has_message_content", False)),
    )
    return ValidationSurfaceDecision("ACCEPTED", None, case.classification, True, True, mapped)


async def dispatch_validation_surface(
    *,
    source: Any,
    response_transport: Any,
    orchestrator: Any,
    mode: ValidationSurfaceMode,
    case_mapping: Mapping[str, ValidationCase] = CASE_MAPPING,
    session: ValidationSurfaceSession | None = None,
):
    """Use the production orchestrator after one deterministic projection."""
    active_session = session or ValidationSurfaceSession(mode)
    if active_session.mode is not mode:
        return await orchestrator.reject_pre_admission(
            stable_error="STAGE8_PASS4E_VALIDATION_SURFACE_MODE_INVALID",
            response_transport=response_transport,
        )
    return await active_session.dispatch(
        source=source, response_transport=response_transport,
        orchestrator=orchestrator, case_mapping=case_mapping,
    )


def build_guild_scoped_sync_plan(*, authorized_configuration_validated: bool) -> dict[str, Any]:
    if authorized_configuration_validated is not True:
        raise ValueError("STAGE8_PASS4E_VALIDATION_SYNC_CONFIGURATION_INVALID")
    return {
        "contract": "GUILD-DOCTOR-STAGE8-PASS4E-VALIDATION-SYNC-PLAN-0.1",
        "target": "AUTHORIZED_PRIVATE_ALPHA_GUILD",
        "production_manifest_fingerprint": validation_manifest_fingerprint(ValidationSurfaceMode.NORMAL),
        "temporary_manifest_fingerprint": validation_manifest_fingerprint(ValidationSurfaceMode.PASS4E_VALIDATION),
        "cleanup_manifest_fingerprint": validation_manifest_fingerprint(ValidationSurfaceMode.CLEANUP),
        "pre_sync": {
            "authorized_guild_identity_required": True,
            "global_operations": 0,
            "other_guild_targets": 0,
            "authority_before_validation": False,
        },
        "sync": {
            "maximum_guild_scoped_synchronizations": 1,
            "preserve_production_routes": True,
            "add_temporary_route_exactly_once": True,
            "global_synchronization": False,
            "gateway_required": False,
        },
        "post_sync": {
            "exact_manifest_required": True,
            "temporary_route_count": 1,
            "unexpected_routes_allowed": False,
            "global_registrations": 0,
        },
        "cleanup": {
            "maximum_guild_scoped_synchronizations": 1,
            "remove_only_temporary_route": True,
            "restore_exact_production_manifest": True,
            "global_synchronization": False,
        },
        "executed": False,
    }


__all__ = [
    "CASE_CHOICES",
    "CASE_MAPPING",
    "TEMPORARY_COMMAND_NAME",
    "TEMPORARY_VALIDATION_COMMAND",
    "VALIDATION_SURFACE_CONTRACT",
    "VALIDATION_SURFACE_VERSION",
    "ValidationCase",
    "ValidationSurfaceDecision",
    "ValidationSurfaceMappedSource",
    "ValidationSurfaceMode",
    "ValidationSurfaceSession",
    "build_guild_scoped_sync_plan",
    "build_validation_command_group",
    "build_validation_manifest",
    "dispatch_validation_surface",
    "map_validation_surface_source",
    "serialized_validation_schema",
    "serialized_validation_schema_fingerprint",
    "validate_manifest_composition",
    "validation_manifest_fingerprint",
]
