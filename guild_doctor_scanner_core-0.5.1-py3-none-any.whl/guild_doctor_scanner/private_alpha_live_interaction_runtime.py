"""Production core for one future Pass 4E-authorized bounded Gateway session.

Importing this module performs no Discord, network, token, client, or event-loop
operation.  The live entry point fails closed before every such boundary unless
an independently issued Pass 4E authority is supplied.
"""
from __future__ import annotations

import asyncio
from dataclasses import asdict, dataclass
import hashlib
import inspect
import json
from pathlib import Path
from typing import Any, Callable, Mapping

from .canonical import exact_fingerprint
from .discord_normalized_snapshot_loader import AuthorizedNormalizedSnapshot, load_authorized_normalized_snapshot
from .discord_response_renderer import render_plain_text
from .private_alpha_configuration import PrivateAlphaConfiguration
from .private_alpha_interaction_intake import (
    AUTHORIZED_LIVE_ROUTES, IntakeDecision, LiveAuthorizationContext,
    ResolvedSelectionBinding, project_application_command,
)
from .private_alpha_interaction_response_controller import (
    InteractionResponseController, ResponseBudgetError,
)
from .private_alpha_bounded_autocomplete import (
    AutocompleteBoundaryError, AutocompleteDecision, AutocompleteResponseBudget,
    AutocompleteSource, evaluate_autocomplete, query_length_classification,
    validate_choice_payload,
)
from .private_alpha_live_interaction_preflight import READY_STATE, LiveInteractionPreflightResult
from .private_alpha_live_session_budget import LiveSessionBudget, SessionBudgetError
from .private_alpha_live_validation_configuration import (
    APPROVED_SNAPSHOT_BASENAME, LiveValidationConfiguration, validate_snapshot_path,
)
from .private_alpha_offline_workflow import (
    ALLOWLISTED_GUILD, OWNER_ACTOR, OfflineInteractionRequest,
    execute_offline_workflow,
)
from .private_alpha_pass4e_runtime_receipt import (
    RUNTIME_STARTUP_EXCEPTION_FAMILIES, RUNTIME_STARTUP_STAGES,
    RuntimeReceiptError, RuntimeReceiptWriter,
)
from .private_alpha_pass4e_exact_route_plan import ExactRoutePlan
from .private_alpha_pass4e_session_artifacts import SessionArtifactPaths
from .runtime_provenance import _source_tree_fingerprint
from .discord_command_manifest import COMMAND_MANIFEST


PASS4D_RUNTIME_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4D-BOUNDED-RUNTIME-IMPLEMENTATION-0.1"
LIVE_INTERACTION_RUNTIME_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-LIVE-INTERACTION-RUNTIME-0.1"
LIVE_EXECUTION_AUTHORITY_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-LIVE-EXECUTION-AUTHORIZATION-0.1"
PASS4E_AUTHORITY_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-LIVE-AUTHORITY-0.1"
SNAPSHOT_RECEIPT_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-SNAPSHOT-BINDING-RECEIPT-0.1"

DISCORD_OPERATION_INVENTORY = {
    "gateway": (
        "ONE_WSS_GATEWAY_CONNECTION_TO_DISCORD_DEFAULT_GATEWAY",
        "AUTHENTICATION_IDENTIFY_READY_AND_APPLICATION_COMMAND_RECEIPT",
        "DETERMINISTIC_CLOSE",
    ),
    "implicit_login_rest_gets": (
        "GET /users/@me via HTTPClient.static_login",
        "GET /oauth2/applications/@me via Client.application_info",
    ),
    "interaction_callback_writes": (
        "POST EPHEMERAL_INITIAL_OR_DEFER_CALLBACK",
        "PATCH ORIGINAL_EPHEMERAL_RESPONSE_MAXIMUM_ONE_AFTER_DEFER",
        "POST AUTOCOMPLETE_RESPONSE_SEPARATE_BOUNDED_CLASS",
    ),
    "prohibited": (
        "COMMAND_REGISTRATION", "COMMAND_SYNCHRONIZATION", "GLOBAL_COMMAND_INSPECTION",
        "GUILD_SERVER_OBJECT_WRITE", "FOLLOW_UP", "ATTACHMENT", "PUBLIC_RESPONSE",
        "MESSAGE_HISTORY", "MEMBER_ENUMERATION", "BACKGROUND_SCAN", "RECONNECT",
    ),
    "client_login_get_count": 2,
    "gateway_connection_maximum": 1,
    "command_registration_count": 0,
    "guild_server_object_write_count": 0,
}


class LiveRuntimeError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class LiveExecutionAuthority:
    authority_contract: str
    authorization_state: str
    preflight_fingerprint: str
    source_tree_fingerprint: str
    active_configuration_fingerprint: str
    live_configuration_fingerprint: str
    snapshot_fingerprint: str
    maximum_gateway_sessions: int
    maximum_live_command_invocations: int
    maximum_session_duration_seconds: int
    interactions_endpoint_absence_confirmed: bool
    session_artifact_binding_fingerprint: str = "0" * 64


@dataclass(frozen=True, slots=True)
class SnapshotBindingReceipt:
    receipt_contract: str
    approved_basename: str
    binding_state: str
    snapshot_contract_state: str
    guild_binding_state: str
    fingerprint_state: str
    snapshot_fingerprint: str
    completeness_states: tuple[tuple[str, str], ...]
    absolute_path_retained: bool = False

    def as_dict(self):
        return asdict(self)


class BoundSnapshot:
    """Process-only snapshot reference with no serializable path or identity API."""
    __slots__ = ("snapshot", "receipt", "_path")

    def __init__(self, snapshot: Mapping[str, Any], receipt: SnapshotBindingReceipt, path: Path | None = None):
        self.snapshot = snapshot
        self.receipt = receipt
        self._path = path

    def clear(self) -> None:
        self.snapshot = None
        self._path = None

    def __repr__(self) -> str:
        return "BoundSnapshot(REDACTED)"


@dataclass(frozen=True, slots=True)
class InvocationOutcome:
    state: str
    route_name: str | None
    stable_error: str | None
    envelope_branch: str | None
    response_sequence: str
    authorization_before_domain: bool
    defer_before_domain: bool
    domain_invocation_count: int
    raw_interaction_retained: bool
    identifier_retained: bool


@dataclass(frozen=True, slots=True)
class RuntimeStartResult:
    state: str
    stable_error: str | None
    authority_validated: bool
    token_retrieval_count: int
    client_construction_count: int
    gateway_connection_count: int
    cleanup_state: str


class _RuntimeStartupTracker:
    """Process-only stage tracker; the receipt retains only approved symbols."""

    __slots__ = ("_receipt", "pending_stage")

    def __init__(self, receipt: RuntimeReceiptWriter):
        self._receipt = receipt
        self.pending_stage: str | None = None

    def attempt(self, stage: str) -> None:
        if stage not in RUNTIME_STARTUP_STAGES:
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_STAGE_INVALID")
        self.pending_stage = stage
        if stage == "CLIENT_CONSTRUCTION":
            self._receipt.startup_construction_attempted()

    def complete(self, stage: str) -> None:
        if self.pending_stage not in {None, stage}:
            raise RuntimeReceiptError("STAGE8_PASS4E_RUNTIME_STARTUP_STAGE_ORDER_INVALID")
        self._receipt.startup_checkpoint(stage)
        self.pending_stage = None

    def failure(self, error: BaseException, *, fallback_stage: str) -> None:
        stage = self.pending_stage or fallback_stage
        name = type(error).__name__.upper()
        family = {
            "ATTRIBUTEERROR": "ATTRIBUTE_ERROR", "TYPEERROR": "TYPE_ERROR",
            "VALUEERROR": "VALUE_ERROR", "RUNTIMEERROR": "RUNTIME_ERROR",
            "OSERROR": "OS_ERROR", "TIMEOUTERROR": "TIMEOUT_ERROR",
            "CANCELLEDERROR": "CANCELLED_ERROR",
        }.get(name, "UNKNOWN")
        if family not in RUNTIME_STARTUP_EXCEPTION_FAMILIES:
            family = "UNKNOWN"
        codes = {
            "TOKEN_BOUNDARY_ENTRY": "STAGE8_PASS4E_LIVE_TOKEN_BOUNDARY_FAILURE",
            "CLIENT_INPUT_ASSEMBLY": "STAGE8_PASS4E_DISCORD_CLIENT_INPUT_INVALID",
            "CLIENT_CONSTRUCTION": "STAGE8_PASS4E_DISCORD_CLIENT_CONSTRUCTION_FAILURE",
            "COMMAND_MANIFEST_BUILD": "STAGE8_PASS4E_COMMAND_MANIFEST_BUILD_FAILURE",
            "COMMAND_TREE_CONSTRUCTION": "STAGE8_PASS4E_COMMAND_TREE_CONSTRUCTION_FAILURE",
            "VALIDATION_ROUTE_BINDING": "STAGE8_PASS4E_VALIDATION_ROUTE_BINDING_FAILURE",
            "EVENT_HANDLER_REGISTRATION": "STAGE8_PASS4E_EVENT_HANDLER_REGISTRATION_FAILURE",
            "CLIENT_START_PREPARATION": "STAGE8_PASS4E_CLIENT_START_PREPARATION_FAILURE",
            "CLIENT_START_INVOCATION": "STAGE8_PASS4E_CLIENT_START_INVOCATION_FAILURE",
            "GATEWAY_CONNECT_PENDING": "STAGE8_PASS4E_GATEWAY_CONNECT_PRECONDITION_FAILURE",
            "GATEWAY_SESSION_OPEN": "STAGE8_PASS4E_GATEWAY_READY_FAILURE",
            "READY_EVENT": "STAGE8_PASS4E_GATEWAY_READY_FAILURE",
            "RECEIPT_INITIALIZATION": "STAGE8_PASS4E_RUNTIME_RECEIPT_INITIALIZATION_FAILURE",
            "RECEIPT_DURABILITY": "STAGE8_PASS4E_RUNTIME_RECEIPT_DURABILITY_FAILURE",
        }
        self._receipt.startup_failure(
            stage=stage, code=codes.get(stage, "STAGE8_PASS4E_RUNTIME_STARTUP_UNKNOWN_FAILURE"),
            exception_family=family,
        )


def validate_live_authority(
    authority: LiveExecutionAuthority | None, *, preflight: LiveInteractionPreflightResult,
    active_configuration: PrivateAlphaConfiguration,
    live_configuration: LiveValidationConfiguration,
    current_source_fingerprint: str,
) -> tuple[str, ...]:
    if not isinstance(authority, LiveExecutionAuthority):
        return ("STAGE8_PASS4D_PASS4E_AUTHORITY_REQUIRED",)
    errors: list[str] = []
    if authority.authority_contract != PASS4E_AUTHORITY_CONTRACT or authority.authorization_state != "PASS4E_AUTHORIZED":
        errors.append("STAGE8_PASS4D_PASS4E_AUTHORITY_INVALID")
    checks = (
        (preflight.overall_state == READY_STATE, "STAGE8_PASS4D_PREFLIGHT_NOT_READY"),
        (authority.preflight_fingerprint == preflight.preflight_fingerprint, "STAGE8_PASS4D_PREFLIGHT_RECEIPT_MISMATCH"),
        (authority.source_tree_fingerprint == current_source_fingerprint, "STAGE8_PASS4D_SOURCE_FINGERPRINT_MISMATCH"),
        (authority.active_configuration_fingerprint == active_configuration.fingerprint, "STAGE8_PASS4D_ACTIVE_CONFIGURATION_MISMATCH"),
        (authority.live_configuration_fingerprint == live_configuration.fingerprint, "STAGE8_PASS4D_LIVE_CONFIGURATION_MISMATCH"),
        (authority.snapshot_fingerprint == preflight.snapshot_fingerprint, "STAGE8_PASS4D_SNAPSHOT_RECEIPT_MISMATCH"),
        (authority.maximum_gateway_sessions == live_configuration.maximum_gateway_sessions == 1, "STAGE8_PASS4D_GATEWAY_BUDGET_MISMATCH"),
        (authority.maximum_live_command_invocations == live_configuration.maximum_live_command_invocations <= 4, "STAGE8_PASS4D_INVOCATION_BUDGET_MISMATCH"),
        (authority.maximum_session_duration_seconds == live_configuration.maximum_session_duration_seconds <= 600, "STAGE8_PASS4D_SESSION_BUDGET_MISMATCH"),
        (authority.interactions_endpoint_absence_confirmed and live_configuration.interactions_endpoint_url_absent_confirmed, "STAGE8_PASS4D_INTERACTION_ENDPOINT_UNCONFIRMED"),
        (preflight.protected_baseline_state == preflight.route_schema_state == preflight.envelope_schema_state == "PASS", "STAGE8_PASS4D_PROTECTED_STATE_INVALID"),
        (preflight.secret_presence_state == "PRESENT", "STAGE8_PASS4D_SECRET_NOT_PRESENT"),
    )
    errors.extend(reason for passed, reason in checks if not passed)
    return tuple(sorted(set(errors)))


def bind_snapshot(
    *, path: Path, project_root: Path, configuration: PrivateAlphaConfiguration,
    preflight: LiveInteractionPreflightResult,
) -> BoundSnapshot:
    if validate_snapshot_path(path, project_root):
        raise LiveRuntimeError("STAGE8_PASS4D_SNAPSHOT_PATH_INVALID")
    if len(configuration.guild_allowlist) != 1:
        raise LiveRuntimeError("STAGE8_PASS4D_GUILD_BINDING_INVALID")
    loaded = load_authorized_normalized_snapshot(path=path, guild_id=configuration.guild_allowlist[0])
    codes = {
        "SNAPSHOT_NOT_FOUND": "STAGE8_PASS4D_SNAPSHOT_MISSING",
        "SNAPSHOT_GUILD_MISMATCH": "STAGE8_PASS4D_SNAPSHOT_GUILD_MISMATCH",
        "SNAPSHOT_PROVENANCE_FAILED": "STAGE8_PASS4D_SNAPSHOT_FINGERPRINT_MISMATCH",
    }
    if not loaded.loaded:
        raise LiveRuntimeError(codes.get(loaded.outcome, "STAGE8_PASS4D_SNAPSHOT_INVALID"))
    fingerprint = str((loaded.snapshot or {}).get("snapshot_fingerprint_sha256", ""))
    if fingerprint != preflight.snapshot_fingerprint:
        raise LiveRuntimeError("STAGE8_PASS4D_SNAPSHOT_CHANGED_AFTER_PREFLIGHT")
    states = {
        "structural": str(loaded.snapshot.get("structural_completeness", "UNKNOWN")),
        "member": str(loaded.snapshot.get("member_completeness", "UNKNOWN")),
        "thread": str(loaded.snapshot.get("thread_completeness", "UNKNOWN")),
    }
    collections = loaded.snapshot.get("collections")
    if isinstance(collections, Mapping):
        for key, value in collections.items():
            states[f"collection:{key}"] = str(value.get("status", "UNKNOWN")) if isinstance(value, Mapping) else "UNKNOWN"
    receipt = SnapshotBindingReceipt(
        SNAPSHOT_RECEIPT_CONTRACT, APPROVED_SNAPSHOT_BASENAME, "BOUND",
        "PASS", "ALLOWLIST_EXACT_MATCH", "PASS", fingerprint,
        tuple(sorted(states.items())),
    )
    return BoundSnapshot(loaded.snapshot, receipt, path)


def _symbolic_snapshot(bound: BoundSnapshot, selections: ResolvedSelectionBinding) -> AuthorizedNormalizedSnapshot:
    source = bound.snapshot
    if not isinstance(source, Mapping):
        raise LiveRuntimeError("STAGE8_PASS4D_SNAPSHOT_RELEASED")
    guild_id = str(source.get("guild_id", ""))
    roles_source = source.get("roles") or {}
    channels_source = source.get("channels") or {}
    if not isinstance(roles_source, Mapping) or not isinstance(channels_source, Mapping):
        raise LiveRuntimeError("STAGE8_PASS4D_SNAPSHOT_INVALID")
    role_ids = list(sorted((str(key) for key in roles_source), key=lambda item: int(item) if item.isdecimal() else item))
    selected_first, selected_second = selections.get("ROLE_ALPHA"), selections.get("ROLE_BETA")
    role_map: dict[str, str] = {}
    if guild_id in role_ids:
        role_map[guild_id] = "100"
    for source_id, symbol in ((selected_first, "400"), (selected_second, "401")):
        if source_id:
            if source_id not in roles_source:
                raise LiveRuntimeError("STAGE8_PASS4D_RESOLVED_ENTITY_NOT_IN_SNAPSHOT")
            role_map[source_id] = symbol
    next_role = 402
    for source_id in role_ids:
        if source_id not in role_map:
            role_map[source_id] = str(next_role); next_role += 1
    category_ids = [str(key) for key, value in channels_source.items() if isinstance(value, Mapping) and str(value.get("type_key")) == "CATEGORY"]
    other_ids = [str(key) for key in channels_source if str(key) not in category_ids]
    channel_map = {source_id: str(501 + index) for index, source_id in enumerate(sorted(category_ids))}
    channel_map.update({source_id: str(600 + index) for index, source_id in enumerate(sorted(other_ids))})
    roles: dict[str, dict[str, Any]] = {}
    for index, source_id in enumerate(role_ids):
        record = dict(roles_source[source_id]); symbolic = role_map[source_id]
        roles[symbolic] = {
            **{key: value for key, value in record.items() if key not in {"id", "guild_id", "name", "source_observed_at", "source_payload_hash", "role_tags"}},
            "id": symbolic, "guild_id": "100", "name": "Everyone" if symbolic == "100" else f"Role {index + 1}",
            "is_everyone": symbolic == "100" or bool(record.get("is_everyone")),
        }
    channels: dict[str, dict[str, Any]] = {}
    for index, source_id in enumerate(sorted(channels_source)):
        record = dict(channels_source[source_id]); symbolic = channel_map[source_id]
        parent = record.get("parent_id")
        channels[symbolic] = {
            **{key: value for key, value in record.items() if key not in {"id", "guild_id", "name", "topic", "source_observed_at", "source_payload_hash", "permission_overwrites", "parent_id"}},
            "id": symbolic, "guild_id": "100", "name": f"Channel {index + 1}",
            "parent_id": channel_map.get(str(parent)) if parent is not None else None,
            "permission_overwrites": (),
        }
    value = {
        **{key: child for key, child in source.items() if key not in {"guild_id", "guild", "roles", "channels", "threads", "members", "thread_memberships", "snapshot_fingerprint_sha256", "structural_fingerprint_sha256"}},
        "guild_id": "100", "guild": {"id": "100", "name": "Sanitized Guild"},
        "roles": roles, "channels": channels, "threads": {}, "members": None,
        "snapshot_fingerprint_sha256": None, "structural_fingerprint_sha256": None,
    }
    value["snapshot_fingerprint_sha256"] = exact_fingerprint(value)
    categories = {key: record for key, record in channels.items() if record.get("type_key") == "CATEGORY"}
    ordinary = {key: record for key, record in channels.items() if record.get("type_key") != "CATEGORY"}
    return AuthorizedNormalizedSnapshot("SNAPSHOT_LOADED", value, Path(APPROVED_SNAPSHOT_BASENAME), roles, categories, ordinary, None)


class BoundedInteractionOrchestrator:
    """Production domain orchestration, usable offline with transport-only doubles."""

    def __init__(
        self, *, context: LiveAuthorizationContext, bound_snapshot: BoundSnapshot,
        maximum_invocations: int = 4, maximum_duration_seconds: float = 600,
        clock: Callable[[], float] | None = None,
        runtime_receipt: RuntimeReceiptWriter | None = None,
    ):
        self.context = context
        self.bound_snapshot = bound_snapshot
        kwargs = {} if clock is None else {"clock": clock}
        self.budget = LiveSessionBudget(maximum_invocations=maximum_invocations, maximum_duration_seconds=maximum_duration_seconds, **kwargs)
        self.runtime_receipt = runtime_receipt
        self.autocomplete_budget = AutocompleteResponseBudget()
        self.route_plan = ExactRoutePlan()
        self._sequence = 0
        self._closed = False
        self.autocomplete_failure_classification: str | None = None

    def _autocomplete_fail(self, sequence: int | None, classification: str) -> None:
        self.autocomplete_failure_classification = classification
        self.autocomplete_budget.fail_response(classification)
        if self.runtime_receipt is not None and sequence is not None:
            try:
                self.runtime_receipt.autocomplete_failed(sequence, classification=classification)
            except RuntimeReceiptError:
                self.autocomplete_failure_classification = "AUTOCOMPLETE_RECEIPT_PERSISTENCE_FAILURE"
        self.cleanup("AUTOCOMPLETE_RESPONSE_FAILURE")

    async def handle_autocomplete(self, source: AutocompleteSource, response: Any) -> AutocompleteDecision:
        """Evaluate and respond once, preserving request/attempt/completion boundaries."""
        if self._closed:
            raise LiveRuntimeError("STAGE8_PASS4D_RUNTIME_CLOSED")
        self.autocomplete_budget.receive_request()
        sequence: int | None = None
        if self.runtime_receipt is not None:
            try:
                sequence = self.runtime_receipt.autocomplete_received(
                    route_name=source.route_name or None,
                    option_name=source.focused_option_name or None,
                    query_length_classification=query_length_classification(source.current_value),
                )
            except RuntimeReceiptError:
                self._autocomplete_fail(None, "AUTOCOMPLETE_RECEIPT_PERSISTENCE_FAILURE")
                raise LiveRuntimeError("AUTOCOMPLETE_RECEIPT_PERSISTENCE_FAILURE") from None
        decision = evaluate_autocomplete(source, context=self.context)
        if decision.state != "ACCEPTED":
            self._autocomplete_fail(sequence, "AUTOCOMPLETE_ROUTE_OPTION_INVALID")
            raise LiveRuntimeError("AUTOCOMPLETE_ROUTE_OPTION_INVALID")
        try:
            validate_choice_payload(decision.choices)
        except AutocompleteBoundaryError:
            self._autocomplete_fail(sequence, "AUTOCOMPLETE_CHOICE_PAYLOAD_INVALID")
            raise LiveRuntimeError("AUTOCOMPLETE_CHOICE_PAYLOAD_INVALID") from None
        if bool(response.is_done()):
            self._autocomplete_fail(sequence, "AUTOCOMPLETE_RESPONSE_ALREADY_COMPLETED")
            raise LiveRuntimeError("AUTOCOMPLETE_RESPONSE_ALREADY_COMPLETED")
        try:
            self.autocomplete_budget.begin_response()
        except AutocompleteBoundaryError as exc:
            self._autocomplete_fail(sequence, exc.classification)
            raise LiveRuntimeError(exc.classification) from None
        if self.runtime_receipt is not None:
            try:
                self.runtime_receipt.autocomplete_attempted(sequence, choice_count=len(decision.choices))
            except RuntimeReceiptError:
                self._autocomplete_fail(sequence, "AUTOCOMPLETE_RECEIPT_PERSISTENCE_FAILURE")
                raise LiveRuntimeError("AUTOCOMPLETE_RECEIPT_PERSISTENCE_FAILURE") from None
        try:
            await response.autocomplete(decision.choices)
        except Exception as exc:
            classification = (
                "AUTOCOMPLETE_RESPONSE_ALREADY_COMPLETED"
                if exc.__class__.__name__ == "InteractionResponded"
                else "AUTOCOMPLETE_RESPONSE_EXCEPTION"
            )
            self._autocomplete_fail(sequence, classification)
            raise LiveRuntimeError(classification) from None
        self.autocomplete_budget.complete_response()
        if self.runtime_receipt is not None:
            try:
                self.runtime_receipt.autocomplete_completed(sequence, accepted=True)
            except RuntimeReceiptError:
                self._autocomplete_fail(sequence, "AUTOCOMPLETE_RECEIPT_PERSISTENCE_FAILURE")
                raise LiveRuntimeError("AUTOCOMPLETE_RECEIPT_PERSISTENCE_FAILURE") from None
        return decision

    async def handle(self, source: Any, response_transport: Any) -> InvocationOutcome:
        if self._closed:
            raise LiveRuntimeError("STAGE8_PASS4D_RUNTIME_CLOSED")
        self._sequence += 1
        decision, selections = project_application_command(source, context=self.context, invocation_identifier=f"LIVE-INVOCATION-{self._sequence}")
        controller = InteractionResponseController(response_transport)
        supplied_route = str(getattr(source, "route_name", "") or "")
        frozen_routes = {item.key for item in COMMAND_MANIFEST}
        route = decision.projection.route_name if decision.projection else supplied_route if supplied_route in frozen_routes else None
        try:
            if decision.state != "ACCEPTED":
                if decision.stable_error and (
                    decision.stable_error.startswith("STAGE8_PASS4E_CANONICAL_OPTION_")
                    or decision.stable_error == "STAGE8_PASS4D_OPTIONS_MALFORMED"
                ):
                    self.route_plan.record_malformed_invocation(decision.stable_error)
                self.budget.reject()
                if self.runtime_receipt is not None:
                    self.runtime_receipt.invocation(ordinal=self._sequence, route_name=route, accepted=False, stable_error=decision.stable_error)
                    self.runtime_receipt.route_plan_updated(self.route_plan.public_value())
                if decision.response_policy == "ONE_EPHEMERAL_INITIAL_ERROR":
                    await controller.send_initial("Guild Doctor could not safely accept this private-alpha invocation.")
                    self.budget.record_initial()
                    if self.runtime_receipt is not None:
                        self.runtime_receipt.initial_error_sent()
                return InvocationOutcome("REJECTED", route, decision.stable_error, "ERROR_RESULT", controller.snapshot.state, True, False, 0, False, False)
            plan_decision = self.route_plan.admit(
                decision.projection.route_name, decision.projection.normalized_options,
                selections_present=bool(selections.get("ROLE_ALPHA") and selections.get("ROLE_BETA")),
            )
            if not plan_decision.accepted:
                self.budget.reject()
                if self.runtime_receipt is not None:
                    self.runtime_receipt.invocation(ordinal=self._sequence, route_name=route, accepted=False, stable_error=plan_decision.stable_error)
                    self.runtime_receipt.route_plan_updated(self.route_plan.public_value())
                await controller.send_initial("Guild Doctor could not safely accept this private-alpha invocation.")
                self.budget.record_initial()
                if self.runtime_receipt is not None:
                    self.runtime_receipt.initial_error_sent()
                return InvocationOutcome("REJECTED", route, plan_decision.stable_error, "ERROR_RESULT", controller.snapshot.state, True, False, 0, False, False)
            self.budget.accept()
            if self.runtime_receipt is not None:
                self.runtime_receipt.invocation(ordinal=self._sequence, route_name=route, accepted=True)
            await controller.defer(ephemeral=True)
            self.budget.record_defer()
            if self.runtime_receipt is not None:
                self.runtime_receipt.response_deferred(self._sequence)
            symbolic = _symbolic_snapshot(self.bound_snapshot, selections)
            projection = decision.projection
            request = OfflineInteractionRequest(
                projection.route_name, projection.normalized_options,
                ALLOWLISTED_GUILD, OWNER_ACTOR, projection.authorization_classification,
                APPROVED_SNAPSHOT_BASENAME, projection.invocation_identifier,
            )
            rendered = []
            execution = execute_offline_workflow(
                request, fixture_root=Path("."), authorized_snapshot_override=symbolic,
                response_observer=rendered.append,
            )
            if not rendered:
                raise LiveRuntimeError("STAGE8_PASS4D_RENDERER_RESULT_MISSING")
            await controller.edit_original(render_plain_text(rendered[0]))
            self.budget.record_edit()
            if self.runtime_receipt is not None:
                self.runtime_receipt.original_response_edited(self._sequence)
                self.runtime_receipt.route_completed(
                    self._sequence, envelope_branch=execution.envelope_branch,
                    report_subtype=execution.report_subtype, stable_error=execution.stable_error,
                )
            completion = self.route_plan.complete(
                projection.route_name, envelope_branch=execution.envelope_branch,
                stable_error=execution.stable_error,
            )
            if not completion.accepted:
                raise LiveRuntimeError(completion.stable_error or "STAGE8_PASS4E_ROUTE_PLAN_OUTCOME_INVALID")
            if self.runtime_receipt is not None:
                self.runtime_receipt.route_plan_updated(self.route_plan.public_value())
            if self.route_plan.all_required_routes_completed:
                self.budget.invocation_complete()
            if self.budget.snapshot.closed and self.route_plan.all_required_routes_completed:
                self.cleanup("INVOCATION_BUDGET_COMPLETE")
            return InvocationOutcome(
                "COMPLETED", projection.route_name, execution.stable_error,
                execution.envelope_branch, controller.snapshot.state,
                True, True, execution.domain_invocation_count, False, False,
            )
        except (ResponseBudgetError, SessionBudgetError, LiveRuntimeError):
            self.cleanup("CLASSIFIED_FAILURE")
            raise
        except Exception as exc:
            self.cleanup("UNEXPECTED_EXCEPTION")
            raise LiveRuntimeError("STAGE8_PASS4D_RUNTIME_FAILURE") from None
        finally:
            selections.clear()
            controller.terminate()

    async def reject_pre_admission(
        self, *, stable_error: str, response_transport: Any,
        rejection_category: str = "MALFORMED",
    ) -> InvocationOutcome:
        """Apply the existing bounded rejection response before normal intake.

        This is intentionally narrow: validation-surface mapping failures have
        no internal route, cannot defer, and never reach domain execution.
        """
        if self._closed:
            raise LiveRuntimeError("STAGE8_PASS4D_RUNTIME_CLOSED")
        self._sequence += 1
        controller = InteractionResponseController(response_transport)
        try:
            if rejection_category == "ROLE_PAIR":
                self.route_plan.record_role_pair_rejection(str(stable_error))
            else:
                self.route_plan.record_malformed_invocation(str(stable_error))
            self.budget.reject()
            if self.runtime_receipt is not None:
                self.runtime_receipt.invocation(
                    ordinal=self._sequence, route_name=None, accepted=False,
                    stable_error=str(stable_error),
                )
                self.runtime_receipt.route_plan_updated(self.route_plan.public_value())
            await controller.send_initial("Guild Doctor could not safely accept this private-alpha invocation.")
            self.budget.record_initial()
            if self.runtime_receipt is not None:
                self.runtime_receipt.initial_error_sent()
            return InvocationOutcome(
                "REJECTED", None, str(stable_error), "ERROR_RESULT",
                controller.snapshot.state, True, False, 0, False, False,
            )
        finally:
            controller.terminate()

    def cleanup(self, reason: str) -> bool:
        existing_reason = self.budget.snapshot.cleanup_reason
        first = self.budget.cleanup(reason)
        persisted_reason = str(reason) if first else existing_reason
        if self.runtime_receipt is not None:
            receipt_reason = self.runtime_receipt.public_value.get("cleanup_reason")
            if not receipt_reason:
                if not persisted_reason:
                    raise RuntimeReceiptError("STAGE8_PASS4E_RECEIPT_CLEANUP_REASON_REQUIRED")
                self.runtime_receipt.cleanup_started(persisted_reason)
        self._closed = True
        self.context = None
        if self.bound_snapshot is not None:
            self.bound_snapshot.clear()
        self.bound_snapshot = None
        return first


class _DiscordResponseTransport:
    __slots__ = ("_interaction",)
    def __init__(self, interaction): self._interaction = interaction
    async def send_initial_ephemeral(self, content): await self._interaction.response.send_message(content, ephemeral=True)
    async def defer_ephemeral(self): await self._interaction.response.defer(ephemeral=True, thinking=True)
    async def edit_original_ephemeral(self, content): await self._interaction.edit_original_response(content=content, attachments=[], view=None)
    def clear(self): self._interaction = None


class _DiscordInteractionSource:
    __slots__ = ("_interaction", "interaction_type", "command_type", "guild_id", "actor_id", "route_name", "options", "is_direct_message", "is_private_channel", "has_attachments", "has_message_content")
    def __init__(self, interaction, *, command_manifest=COMMAND_MANIFEST):
        self._interaction = interaction
        self.interaction_type = getattr(interaction, "type", None)
        data = getattr(interaction, "data", None)
        data = data if isinstance(data, Mapping) else {}
        self.command_type = data.get("type", 1)
        self.guild_id = str(getattr(interaction, "guild_id", "") or "")
        self.actor_id = str(getattr(getattr(interaction, "user", None), "id", "") or "")
        root_options = data.get("options")
        root_options = root_options if isinstance(root_options, list) else []
        subcommand = root_options[0] if len(root_options) == 1 and isinstance(root_options[0], Mapping) and root_options[0].get("type") == 1 else {}
        self.route_name = str(subcommand.get("name", "")) if data.get("name") == "guild-doctor" else ""
        supplied_options = subcommand.get("options")
        supplied_options = supplied_options if isinstance(supplied_options, list) else []
        definition = next((item for item in command_manifest if item.key == self.route_name), None)
        definitions = {} if definition is None else {item.name: item for item in definition.options}
        resolved = data.get("resolved")
        resolved = resolved if isinstance(resolved, Mapping) else {}
        parsed: dict[str, Any] = {}
        for option in supplied_options:
            if not isinstance(option, Mapping):
                parsed["MALFORMED"] = None
                continue
            name = str(option.get("name", ""))
            expected = definitions.get(name)
            value = option.get("value")
            if expected is not None and expected.type in {"role", "channel", "user"}:
                family = {"role": "roles", "channel": "channels", "user": "users"}[expected.type]
                collection = resolved.get(family)
                collection = collection if isinstance(collection, Mapping) else {}
                identifier = str(value or "")
                value = _ResolvedEntity(identifier, self.guild_id) if identifier in collection else None
            parsed[name] = value
        self.options = parsed
        self.is_direct_message = interaction.guild_id is None
        self.is_private_channel = self.is_direct_message
        self.has_attachments = False
        self.has_message_content = False
    def clear(self): self._interaction = None; self.options = {}


class _ResolvedEntity:
    """Minimal process-only resolved-object projection with redacted repr."""
    __slots__ = ("id", "guild_id")
    def __init__(self, identifier: str, guild_id: str):
        self.id = identifier
        self.guild_id = guild_id
    def __repr__(self): return "_ResolvedEntity(REDACTED)"


class _DiscordAutocompleteSource:
    __slots__ = ("interaction_type", "command_type", "guild_id", "actor_id", "route_name", "focused_option_name", "current_value")
    def __init__(self, interaction):
        interaction_type = getattr(interaction, "type", None)
        self.interaction_type = getattr(interaction_type, "value", interaction_type)
        data = getattr(interaction, "data", None)
        data = data if isinstance(data, Mapping) else {}
        self.command_type = data.get("type", 1)
        self.guild_id = str(getattr(interaction, "guild_id", "") or "")
        self.actor_id = str(getattr(getattr(interaction, "user", None), "id", "") or "")
        root_options = data.get("options")
        root_options = root_options if isinstance(root_options, list) else []
        subcommand = root_options[0] if len(root_options) == 1 and isinstance(root_options[0], Mapping) and root_options[0].get("type") == 1 else {}
        self.route_name = str(subcommand.get("name", "")) if data.get("name") == "guild-doctor" else ""
        options = subcommand.get("options")
        options = options if isinstance(options, list) else []
        focused = [item for item in options if isinstance(item, Mapping) and item.get("focused") is True]
        self.focused_option_name = str(focused[0].get("name", "")) if len(focused) == 1 else ""
        value = focused[0].get("value", "") if len(focused) == 1 else ""
        self.current_value = str(value) if isinstance(value, str) else ""

    def projection(self) -> AutocompleteSource:
        return AutocompleteSource(
            self.interaction_type, self.command_type, self.guild_id, self.actor_id,
            self.route_name, self.focused_option_name, self.current_value,
        )


async def dispatch_gateway_interaction(
    *, orchestrator: BoundedInteractionOrchestrator, interaction: Any,
    validation_surface_mode=None, validation_session=None,
):
    """Parse and dispatch one real Gateway interaction through the bound mode.

    This helper deliberately performs no client construction.  Keeping parsing
    and dispatch here lets offline acceptance exercise the exact production
    path with Discord-compatible fakes.
    """
    from .private_alpha_pass4e_validation_surface import (
        TEMPORARY_COMMAND_NAME, ValidationSurfaceMode, ValidationSurfaceSession,
        build_validation_manifest, dispatch_validation_surface,
    )
    mode = ValidationSurfaceMode.NORMAL if validation_surface_mode is None else validation_surface_mode
    if not isinstance(mode, ValidationSurfaceMode):
        raise LiveRuntimeError("STAGE8_PASS4E_VALIDATION_SURFACE_MODE_INVALID")
    session = validation_session or ValidationSurfaceSession(mode)
    source = _DiscordInteractionSource(interaction, command_manifest=build_validation_manifest(mode))
    transport = _DiscordResponseTransport(interaction)
    try:
        if source.route_name == TEMPORARY_COMMAND_NAME:
            return await dispatch_validation_surface(
                source=source, response_transport=transport, orchestrator=orchestrator,
                mode=mode, session=session,
            )
        return await orchestrator.handle(source, transport)
    finally:
        source.clear(); transport.clear(); interaction = None


def _build_discord_client(
    orchestrator: BoundedInteractionOrchestrator, *, validation_surface_mode=None,
    startup_tracker: _RuntimeStartupTracker | None = None, discord_module=None,
    ready_observer: Callable[[], None] | None = None,
):
    """Build the bounded client without external listener registration.

    ``discord_module`` exists solely for controlled offline compatibility tests;
    production leaves it unset and imports discord.py normally.
    """
    discord = discord_module
    if discord is None:
        import discord as discord_module
        discord = discord_module
    from .private_alpha_pass4e_validation_surface import (
        TEMPORARY_COMMAND_NAME, ValidationSurfaceMode, ValidationSurfaceSession,
        build_validation_manifest,
    )
    if startup_tracker is not None:
        startup_tracker.attempt("CLIENT_INPUT_ASSEMBLY")
    mode = ValidationSurfaceMode.NORMAL if validation_surface_mode is None else validation_surface_mode
    if not isinstance(mode, ValidationSurfaceMode):
        raise LiveRuntimeError("STAGE8_PASS4E_VALIDATION_SURFACE_MODE_INVALID")
    if startup_tracker is not None:
        startup_tracker.complete("CLIENT_INPUT_ASSEMBLY")
        startup_tracker.attempt("COMMAND_MANIFEST_BUILD")
    manifest = build_validation_manifest(mode)
    if startup_tracker is not None:
        startup_tracker.complete("COMMAND_MANIFEST_BUILD")
        startup_tracker.attempt("COMMAND_TREE_CONSTRUCTION")
    validation_session = ValidationSurfaceSession(mode)
    if startup_tracker is not None:
        startup_tracker.complete("COMMAND_TREE_CONSTRUCTION")
        startup_tracker.attempt("VALIDATION_ROUTE_BINDING")
    temporary_count = sum(item.key == TEMPORARY_COMMAND_NAME for item in manifest)
    if (mode.value == "PASS4E_VALIDATION" and temporary_count != 1) or (mode.value != "PASS4E_VALIDATION" and temporary_count != 0):
        raise LiveRuntimeError("STAGE8_PASS4E_VALIDATION_ROUTE_BINDING_INVALID")
    if startup_tracker is not None:
        startup_tracker.complete("VALIDATION_ROUTE_BINDING")
        startup_tracker.attempt("EVENT_HANDLER_REGISTRATION")
    class BoundedClient(discord.Client):
        async def setup_hook(self):
            application = self.application
            if application is None or application.interactions_endpoint_url is not None:
                raise LiveRuntimeError("STAGE8_PASS4D_INTERACTION_ENDPOINT_PRESENT")
        async def on_ready(self):
            if startup_tracker is not None:
                startup_tracker.attempt("GATEWAY_SESSION_OPEN")
            if orchestrator.runtime_receipt is not None:
                orchestrator.runtime_receipt.gateway_connected()
            if startup_tracker is not None:
                startup_tracker.complete("GATEWAY_SESSION_OPEN")
                startup_tracker.attempt("READY_EVENT")
            if ready_observer is not None:
                ready_observer()
            if startup_tracker is not None:
                startup_tracker.complete("READY_EVENT")
        async def on_interaction(self, interaction):
            interaction_type = getattr(getattr(interaction, "type", None), "value", getattr(interaction, "type", None))
            if interaction_type == 4:
                source = _DiscordAutocompleteSource(interaction)
                try:
                    class DiscordAutocompleteResponse:
                        def is_done(self):
                            return interaction.response.is_done()
                        async def autocomplete(self, choices):
                            payload = [discord.app_commands.Choice(name=name, value=value) for name, value in choices]
                            await interaction.response.autocomplete(payload)
                    await orchestrator.handle_autocomplete(source.projection(), DiscordAutocompleteResponse())
                except Exception:
                    if not self.is_closed():
                        await self.close()
                    raise
                finally:
                    interaction = None
                return
            try:
                await dispatch_gateway_interaction(
                    orchestrator=orchestrator, interaction=interaction,
                    validation_surface_mode=mode, validation_session=validation_session,
                )
            finally:
                interaction = None
                if orchestrator.budget.snapshot.closed and not self.is_closed():
                    await self.close()
    if startup_tracker is not None:
        startup_tracker.complete("EVENT_HANDLER_REGISTRATION")
        startup_tracker.attempt("CLIENT_CONSTRUCTION")
    client = BoundedClient(intents=discord.Intents.none())
    if startup_tracker is not None:
        startup_tracker.complete("CLIENT_CONSTRUCTION")
    return client


async def start_bounded_gateway_runtime(
    *, authority: LiveExecutionAuthority | None,
    preflight: LiveInteractionPreflightResult,
    active_configuration: PrivateAlphaConfiguration,
    live_configuration: LiveValidationConfiguration,
    project_root: Path, snapshot_path: Path,
    runtime_receipt_path: Path | None = None,
    session_artifacts: SessionArtifactPaths | None = None,
    token_provider: Callable[[], str],
    client_factory: Callable[[BoundedInteractionOrchestrator], Any] | None = None,
    runtime_receipt_initializer: Callable[[RuntimeReceiptWriter], None] | None = None,
    validation_surface_mode=None,
    ready_observer: Callable[[], None] | None = None,
    discord_module=None,
) -> RuntimeStartResult:
    """Future live entry point. Pass 4D supplies no valid Pass 4E authority."""
    current = _source_tree_fingerprint(project_root.resolve())
    errors = validate_live_authority(
        authority, preflight=preflight, active_configuration=active_configuration,
        live_configuration=live_configuration, current_source_fingerprint=current,
    )
    if errors:
        return RuntimeStartResult("BLOCKED", errors[0], False, 0, 0, 0, "NOT_STARTED")
    if runtime_receipt_path is None:
        return RuntimeStartResult("BLOCKED", "STAGE8_PASS4E_RUNTIME_RECEIPT_REQUIRED", True, 0, 0, 0, "NOT_STARTED")
    if session_artifacts is not None:
        try:
            artifacts = session_artifacts.validated()
        except Exception:
            return RuntimeStartResult("BLOCKED", "STAGE8_PASS4E_SESSION_ARTIFACT_PATH_INVALID", True, 0, 0, 0, "NOT_STARTED")
        if authority.session_artifact_binding_fingerprint != artifacts.binding_fingerprint or Path(runtime_receipt_path).resolve(strict=False) != artifacts.receipt_path:
            return RuntimeStartResult("BLOCKED", "STAGE8_PASS4E_SESSION_ARTIFACT_BINDING_MISMATCH", True, 0, 0, 0, "NOT_STARTED")
    try:
        runtime_receipt = RuntimeReceiptWriter(runtime_receipt_path, session_artifacts=session_artifacts)
        tracker = _RuntimeStartupTracker(runtime_receipt)
        tracker.complete("RECEIPT_INITIALIZATION")
        runtime_receipt.transition("PREFLIGHT_ACCEPTED")
        runtime_receipt.transition("LIVE_AUTHORITY_ACCEPTED")
        if runtime_receipt_initializer is not None:
            runtime_receipt_initializer(runtime_receipt)
        tracker.complete("RECEIPT_DURABILITY")
    except RuntimeReceiptError:
        return RuntimeStartResult("BLOCKED", "STAGE8_PASS4E_RECEIPT_WRITE_FAILED", True, 0, 0, 0, "NOT_STARTED")
    try:
        bound = bind_snapshot(path=snapshot_path, project_root=project_root, configuration=active_configuration, preflight=preflight)
    except Exception:
        runtime_receipt.cleanup_started("SNAPSHOT_BINDING_FAILURE")
        runtime_receipt.terminal("FAILED_CLOSED")
        return RuntimeStartResult("BLOCKED", "STAGE8_PASS4D_SNAPSHOT_INVALID", True, 0, 0, 0, "CLOSED")
    if bound.receipt.snapshot_fingerprint != authority.snapshot_fingerprint:
        bound.clear()
        runtime_receipt.cleanup_started("SNAPSHOT_CHANGED_AFTER_PREFLIGHT")
        runtime_receipt.terminal("FAILED_CLOSED")
        return RuntimeStartResult("BLOCKED", "STAGE8_PASS4D_SNAPSHOT_CHANGED_AFTER_PREFLIGHT", True, 0, 0, 0, "CLOSED")
    guild_id = active_configuration.guild_allowlist[0]
    owner_id = str(((bound.snapshot.get("guild") or {}) if isinstance(bound.snapshot, Mapping) else {}).get("owner_id", ""))
    if not owner_id.isdecimal():
        bound.clear()
        runtime_receipt.cleanup_started("OWNER_UNAVAILABLE")
        runtime_receipt.terminal("FAILED_CLOSED")
        return RuntimeStartResult("BLOCKED", "STAGE8_PASS4D_OWNER_UNAVAILABLE", True, 0, 0, 0, "CLOSED")
    orchestrator = BoundedInteractionOrchestrator(
        context=LiveAuthorizationContext(guild_id, owner_id), bound_snapshot=bound,
        maximum_invocations=live_configuration.maximum_live_command_invocations,
        maximum_duration_seconds=live_configuration.maximum_session_duration_seconds,
        runtime_receipt=runtime_receipt,
    )
    token = None; client = None
    state = "BLOCKED"
    stable_error: str | None = None
    token_retrieval_count = 0
    client_construction_count = 0
    cancelled = False
    receipt_persistence_failed = False
    client_cleanup_failed = False

    def cleanup(reason: str) -> None:
        nonlocal receipt_persistence_failed, state, stable_error
        try:
            orchestrator.cleanup(reason)
        except RuntimeReceiptError:
            receipt_persistence_failed = True
            state = "BLOCKED"
            stable_error = "STAGE8_PASS4E_RECEIPT_WRITE_FAILED"

    try:
        tracker.attempt("TOKEN_BOUNDARY_ENTRY")
        token_retrieval_count = 1
        token = token_provider()
        tracker.complete("TOKEN_BOUNDARY_ENTRY")
        if client_factory is None:
            client = _build_discord_client(
                orchestrator, validation_surface_mode=validation_surface_mode,
                startup_tracker=tracker, ready_observer=ready_observer, discord_module=discord_module,
            )
        else:
            tracker.attempt("CLIENT_CONSTRUCTION")
            client = client_factory(orchestrator)
            tracker.complete("CLIENT_CONSTRUCTION")
        client_construction_count = 1
        runtime_receipt.transition("CLIENT_CONSTRUCTED")
        tracker.attempt("CLIENT_START_PREPARATION")
        start_result = client.start(token, reconnect=False)
        if not inspect.isawaitable(start_result):
            raise LiveRuntimeError("STAGE8_PASS4E_CLIENT_START_NOT_AWAITABLE")
        tracker.complete("CLIENT_START_PREPARATION")
        tracker.attempt("CLIENT_START_INVOCATION")
        tracker.complete("CLIENT_START_INVOCATION")
        tracker.attempt("GATEWAY_CONNECT_PENDING")
        await asyncio.wait_for(
            start_result,
            timeout=live_configuration.maximum_session_duration_seconds,
        )
        state = "COMPLETE"
    except asyncio.CancelledError as exc:
        try:
            tracker.failure(exc, fallback_stage="CLIENT_START_INVOCATION")
        except RuntimeReceiptError:
            receipt_persistence_failed = True
        cleanup("OPERATOR_CANCELLATION")
        cancelled = True
    except asyncio.TimeoutError as exc:
        try:
            tracker.failure(exc, fallback_stage="GATEWAY_CONNECT_PENDING")
        except RuntimeReceiptError:
            receipt_persistence_failed = True
        cleanup("SESSION_TIMEOUT")
        stable_error = "STAGE8_PASS4D_SESSION_TIMEOUT"
    except RuntimeReceiptError:
        cleanup("RECEIPT_PERSISTENCE_FAILURE")
        receipt_persistence_failed = True
        stable_error = "STAGE8_PASS4E_RECEIPT_WRITE_FAILED"
    except Exception as exc:
        try:
            tracker.failure(exc, fallback_stage="CLIENT_CONSTRUCTION")
        except RuntimeReceiptError:
            receipt_persistence_failed = True
        cleanup("RUNTIME_FAILURE")
        stable_error = "STAGE8_PASS4D_RUNTIME_FAILURE"
    finally:
        token = None
        if client is not None and not client.is_closed():
            try:
                await client.close()
            except Exception:
                client_cleanup_failed = True
                state = "BLOCKED"
                stable_error = "STAGE8_PASS4E_CLIENT_CLEANUP_FAILED"
        if client_cleanup_failed:
            try:
                runtime_receipt.cleanup_started("CLIENT_CLEANUP_FAILURE")
            except RuntimeReceiptError:
                receipt_persistence_failed = True
                stable_error = "STAGE8_PASS4E_RECEIPT_WRITE_FAILED"
        else:
            cleanup("RUNTIME_FINALIZATION")
            if client is not None:
                try:
                    runtime_receipt.client_closed()
                except RuntimeReceiptError:
                    receipt_persistence_failed = True
                    state = "BLOCKED"
                    stable_error = "STAGE8_PASS4E_RECEIPT_WRITE_FAILED"
        terminal_state = (
            "PASS"
            if state == "COMPLETE"
            and not client_cleanup_failed
            and not receipt_persistence_failed
            and orchestrator.budget.snapshot.cleanup_reason == "INVOCATION_BUDGET_COMPLETE"
            and orchestrator.route_plan.all_required_routes_completed
            else "FAILED_CLOSED"
        )
        if state == "COMPLETE" and terminal_state != "PASS":
            state = "BLOCKED"
            stable_error = stable_error or "STAGE8_PASS4E_INCOMPLETE_VERIFICATION"
        try:
            runtime_receipt.terminal(terminal_state)
        except RuntimeReceiptError:
            receipt_persistence_failed = True
            state = "BLOCKED"
            stable_error = "STAGE8_PASS4E_RECEIPT_WRITE_FAILED"
    if cancelled:
        raise asyncio.CancelledError
    gateway_count = runtime_receipt.public_value.get("gateway_connection_count", 0)
    return RuntimeStartResult(
        state, stable_error, True, token_retrieval_count,
        client_construction_count, int(gateway_count),
        "FAILED" if client_cleanup_failed or receipt_persistence_failed else "CLOSED",
    )


__all__ = [
    "BoundSnapshot", "BoundedInteractionOrchestrator", "DISCORD_OPERATION_INVENTORY",
    "LIVE_EXECUTION_AUTHORITY_CONTRACT", "LIVE_INTERACTION_RUNTIME_CONTRACT",
    "LiveExecutionAuthority", "LiveRuntimeError", "PASS4D_RUNTIME_CONTRACT",
    "PASS4E_AUTHORITY_CONTRACT", "RuntimeStartResult", "SNAPSHOT_RECEIPT_CONTRACT",
    "SnapshotBindingReceipt", "bind_snapshot", "dispatch_gateway_interaction", "start_bounded_gateway_runtime",
    "validate_live_authority",
]
