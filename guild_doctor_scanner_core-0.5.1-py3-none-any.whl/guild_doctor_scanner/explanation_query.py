"""Immutable, explicit Stage 4 Pass 3 explanation queries."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .explanation_adapters import (
    ADAPTER_REGISTRY_BY_CONTRACT,
    ADAPTER_REGISTRY_BY_FAMILY,
    EXPLANATION_ADAPTERS_VERSION,
    PERMISSION_DEFINITION_VERSION,
    SNAPSHOT_SCHEMA_VERSION,
)
from .explanation_schema import EXPLANATION_MODES, EXPLANATION_RULES_VERSION, EXPLANATION_SCHEMA_VERSION, RESULT_FAMILIES
from .presentation_profiles import (
    OUTPUT_FORMATS,
    PRESENTATION_PROFILE_VERSION,
    PRESENTATION_PROFILES_BY_KEY,
    DisclosurePolicy,
    PresentationProfileError,
    PRESENTATION_SECTIONS,
    get_presentation_profile,
)


STAGE4_PASS3_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE4-PASS3-0.1"
EXPLANATION_QUERY_CONTRACT_VERSION = "GUILD-DOCTOR-EXPLANATION-QUERY-0.1"
EXPLANATION_ORCHESTRATION_VERSION = "GUILD-DOCTOR-EXPLANATION-ORCHESTRATION-0.1"
EXPLANATION_QUERY_GOLDEN_VERSION = "GUILD-DOCTOR-EXPLANATION-QUERY-GOLDEN-0.1"

QUERY_TYPES = frozenset(
    {
        "EXPLAIN_GUILD_PERMISSION",
        "EXPLAIN_CONTEXT_PERMISSION",
        "EXPLAIN_CAPABILITY",
        "EXPLAIN_THREAD_RESULT",
        "EXPLAIN_AUTHORITY_RESULT",
        "EXPLAIN_ACTION_RESULT",
    }
)
QUERY_TYPE_TO_FAMILY = MappingProxyType(
    {
        "EXPLAIN_GUILD_PERMISSION": "GUILD_PERMISSION",
        "EXPLAIN_CONTEXT_PERMISSION": "CONTEXT_PERMISSION",
        "EXPLAIN_CAPABILITY": "CAPABILITY",
        "EXPLAIN_THREAD_RESULT": "THREAD",
        "EXPLAIN_AUTHORITY_RESULT": "AUTHORITY",
        "EXPLAIN_ACTION_RESULT": "ACTION",
    }
)
_SECRET_KEY_FRAGMENTS = ("token", "authorization", "access_token", "client_secret", "password", "api_key")
_FORBIDDEN_QUERY_KEYS = frozenset(
    {
        "environment",
        "env",
        "database",
        "database_connection",
        "connection",
        "command_interaction",
        "interaction",
        "callback",
        "executable_callback",
        "question",
        "natural_language_question",
        "prompt",
        "runtime_url",
        "network_url",
        "endpoint_url",
        "live_discord_object",
    }
)
_ID_FIELDS = ("guild_id", "subject_id", "actor_id", "target_id", "context_id", "thread_id")
_EVIDENCE_EXACT = {
    "DOCUMENTED_EXPECTATION",
    "HISTORICAL_EVIDENCE",
    "AUTHORITATIVE_CLOSURE",
    "ACCEPTED_READ_ONLY_LIMITATION",
    "NEEDS_LIVE_TEST",
    "MODELED_RESULT",
    "SYNTHETIC_INTEGRATION",
    "LIVE_DERIVED_RESULT",
}
_EVIDENCE_PREFIXES = ("LIVE_DERIVED_", "SYNTHETIC_", "HISTORICAL_", "AUTHORITATIVE_", "ACCEPTED_")
_STATUS_EXACT = {"VERIFIED", "COMPLETE", "UNKNOWN", "INCOMPLETE"}
_STATUS_PREFIXES = ("VERIFIED_", "READ_ONLY_", "LIVE_", "SYNTHETIC_", "UNKNOWN_", "INCOMPLETE_", "NEEDS_")


class ExplanationQueryError(ValueError):
    """Raised when strict query construction or validation is requested."""


def _text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def _upper(value: Any) -> str | None:
    text = _text(value)
    return text.upper() if text else None


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _tuple_text(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (value.strip(),) if value.strip() else ()
    if isinstance(value, Mapping):
        value = value.values()
    if isinstance(value, Sequence) or isinstance(value, (set, frozenset)):
        return tuple(str(item).strip() for item in value if str(item).strip())
    return ()


def _copy_json(value: Any, key: str = "") -> Any:
    lower = key.lower()
    if any(fragment in lower for fragment in _SECRET_KEY_FRAGMENTS):
        return None
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _copy_json(method(), key)
    if isinstance(value, Mapping):
        return {
            str(item_key): _copy_json(item_value, str(item_key))
            for item_key, item_value in sorted(value.items(), key=lambda item: str(item[0]))
            if not any(fragment in str(item_key).lower() for fragment in _SECRET_KEY_FRAGMENTS)
        }
    if isinstance(value, (list, tuple)):
        return [_copy_json(item, key) for item in value]
    if isinstance(value, (set, frozenset)):
        return [_copy_json(item, key) for item in sorted(value, key=str)]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _scan_forbidden(value: Any, path: str = "query") -> list[str]:
    errors: list[str] = []
    if callable(value):
        errors.append(f"QUERY_FORBIDDEN_EXECUTABLE:{path}")
        return errors
    if isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            lower = key_text.lower()
            child_path = f"{path}.{key_text}"
            if any(fragment in lower for fragment in _SECRET_KEY_FRAGMENTS):
                errors.append(f"QUERY_CREDENTIAL_FIELD:{child_path}")
            if lower in _FORBIDDEN_QUERY_KEYS:
                errors.append(f"QUERY_FORBIDDEN_FIELD:{child_path}")
            errors.extend(_scan_forbidden(child, child_path))
    elif isinstance(value, (list, tuple, set, frozenset)):
        for index, child in enumerate(value):
            errors.extend(_scan_forbidden(child, f"{path}[{index}]"))
    elif hasattr(value, "__class__") and value.__class__.__module__.startswith("discord"):
        errors.append(f"QUERY_LIVE_DISCORD_OBJECT:{path}")
    return errors


@dataclass(frozen=True, slots=True)
class QueryRegistryRecord:
    query_type: str
    result_family: str
    source_contract: str
    adapter_key: str
    required_identity_fields: tuple[str, ...]
    order: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "query_type": self.query_type,
            "result_family": self.result_family,
            "source_contract": self.source_contract,
            "adapter_key": self.adapter_key,
            "required_identity_fields": list(self.required_identity_fields),
            "order": self.order,
        }


def _query_record(query_type: str, family: str, order: int, required: tuple[str, ...]) -> QueryRegistryRecord:
    adapter = ADAPTER_REGISTRY_BY_FAMILY[family]
    return QueryRegistryRecord(query_type, family, adapter.source_contract, adapter.adapter_key, required, order)


QUERY_REGISTRY = (
    _query_record("EXPLAIN_GUILD_PERMISSION", "GUILD_PERMISSION", 1, ("guild_id", "subject_id")),
    _query_record("EXPLAIN_CONTEXT_PERMISSION", "CONTEXT_PERMISSION", 2, ("guild_id", "subject_id", "context_id")),
    _query_record("EXPLAIN_CAPABILITY", "CAPABILITY", 3, ("guild_id", "subject_id", "context_id")),
    _query_record("EXPLAIN_THREAD_RESULT", "THREAD", 4, ("guild_id", "subject_id", "thread_id")),
    _query_record("EXPLAIN_AUTHORITY_RESULT", "AUTHORITY", 5, ("guild_id", "actor_id", "target_id")),
    _query_record("EXPLAIN_ACTION_RESULT", "ACTION", 6, ("guild_id", "actor_id")),
)
QUERY_REGISTRY_BY_TYPE = MappingProxyType({item.query_type: item for item in QUERY_REGISTRY})


def validate_query_registry() -> tuple[str, ...]:
    errors: list[str] = []
    types: set[str] = set()
    families: set[str] = set()
    orders: set[int] = set()
    for item in QUERY_REGISTRY:
        if item.query_type in types:
            errors.append(f"DUPLICATE_QUERY_TYPE:{item.query_type}")
        if item.result_family in families:
            errors.append(f"DUPLICATE_QUERY_FAMILY:{item.result_family}")
        if item.order in orders:
            errors.append(f"DUPLICATE_QUERY_ORDER:{item.order}")
        if item.query_type not in QUERY_TYPES:
            errors.append(f"UNKNOWN_QUERY_TYPE:{item.query_type}")
        if item.result_family not in RESULT_FAMILIES:
            errors.append(f"UNKNOWN_RESULT_FAMILY:{item.result_family}")
        if ADAPTER_REGISTRY_BY_CONTRACT.get(item.source_contract) is None:
            errors.append(f"UNKNOWN_ADAPTER_CONTRACT:{item.source_contract}")
        types.add(item.query_type)
        families.add(item.result_family)
        orders.add(item.order)
    if types != set(QUERY_TYPES) or families != set(RESULT_FAMILIES):
        errors.append("QUERY_REGISTRY_COVERAGE_INCOMPLETE")
    return tuple(sorted(set(errors)))


@dataclass(frozen=True, slots=True)
class SectionSelectionPolicy:
    include_sections: tuple[str, ...] | None = None
    optional_sections: tuple[str, ...] = ()

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any] | "SectionSelectionPolicy" | None) -> "SectionSelectionPolicy":
        if value is None:
            return cls()
        if isinstance(value, cls):
            return value
        if not isinstance(value, Mapping):
            raise ExplanationQueryError("SECTION_POLICY_NOT_MAPPING")
        unknown = set(value) - {"include_sections", "optional_sections"}
        if unknown:
            raise ExplanationQueryError(f"SECTION_POLICY_UNKNOWN_FIELDS:{','.join(sorted(map(str, unknown)))}")
        raw_include = value.get("include_sections")
        include = None if raw_include is None else tuple(item.strip().upper() for item in _tuple_text(raw_include))
        optional = tuple(item.strip().upper() for item in _tuple_text(value.get("optional_sections")))
        return cls(include, optional)

    def as_dict(self) -> dict[str, Any]:
        return {"include_sections": None if self.include_sections is None else list(self.include_sections), "optional_sections": list(self.optional_sections)}


@dataclass(frozen=True, slots=True)
class ExplanationQuery:
    query_id: str
    query_type: str
    result_family: str
    source_contract: str
    source_result: Any
    source_trace: Sequence[Any] | None
    guild_id: str | int | None = None
    subject_id: str | int | None = None
    actor_id: str | int | None = None
    target_type: str | None = None
    target_id: str | int | None = None
    context_id: str | int | None = None
    context_type: str | None = None
    thread_id: str | int | None = None
    thread_type: str | None = None
    query_contract_version: str = EXPLANATION_QUERY_CONTRACT_VERSION
    requested_stage4_pass3_contract: str = STAGE4_PASS3_CONTRACT_VERSION
    expected_adapter_registry_version: str = EXPLANATION_ADAPTERS_VERSION
    expected_explanation_schema_version: str = EXPLANATION_SCHEMA_VERSION
    expected_explanation_rules_version: str = EXPLANATION_RULES_VERSION
    expected_presentation_profile_version: str = PRESENTATION_PROFILE_VERSION
    source_stage3_contract_versions: Mapping[str, str] | None = None
    registry_versions: Mapping[str, str] | None = None
    permission_definition_version: str | None = PERMISSION_DEFINITION_VERSION
    completeness_state: str | None = None
    evidence_classifications: Sequence[str] = ()
    verification_statuses: Sequence[str] = ()
    source_references: Sequence[str] = ()
    explanation_mode: str | None = None
    presentation_profile: str = "SIMPLE_CARD"
    output_format: str | None = None
    labels: Mapping[str, Any] | None = None
    disclosure_policy: DisclosurePolicy | Mapping[str, Any] | None = None
    section_policy: SectionSelectionPolicy | Mapping[str, Any] | None = None
    presentation_limits: Mapping[str, Any] | None = None
    title: str | None = None
    explicit_id_disclosure_allowed: bool = False
    authoritative_closure: Mapping[str, Any] | None = None
    historical_evidence: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        for field in ("query_id", "query_type", "result_family", "source_contract", "presentation_profile"):
            value = _text(getattr(self, field))
            if value is not None:
                object.__setattr__(self, field, value.upper() if field != "query_id" else value)
        object.__setattr__(self, "guild_id", _snowflake(self.guild_id))
        object.__setattr__(self, "subject_id", _snowflake(self.subject_id))
        object.__setattr__(self, "actor_id", _snowflake(self.actor_id))
        object.__setattr__(self, "target_id", _snowflake(self.target_id))
        object.__setattr__(self, "context_id", _snowflake(self.context_id))
        object.__setattr__(self, "thread_id", _snowflake(self.thread_id))
        for field in ("target_type", "context_type", "thread_type", "explanation_mode", "output_format", "completeness_state"):
            value = _text(getattr(self, field))
            if value is not None:
                object.__setattr__(self, field, value.upper())
        object.__setattr__(self, "source_result", deepcopy(self.source_result))
        object.__setattr__(self, "source_trace", None if self.source_trace is None else deepcopy(tuple(self.source_trace)))
        object.__setattr__(self, "source_stage3_contract_versions", MappingProxyType(dict(self.source_stage3_contract_versions or {})))
        object.__setattr__(self, "registry_versions", MappingProxyType(dict(self.registry_versions or {})))
        object.__setattr__(self, "labels", MappingProxyType(dict(self.labels or {})) if self.labels is None or isinstance(self.labels, Mapping) else self.labels)
        object.__setattr__(self, "evidence_classifications", _tuple_text(self.evidence_classifications))
        object.__setattr__(self, "verification_statuses", _tuple_text(self.verification_statuses))
        object.__setattr__(self, "source_references", _tuple_text(self.source_references))
        object.__setattr__(self, "disclosure_policy", DisclosurePolicy.from_mapping(self.disclosure_policy) if self.disclosure_policy is not None else None)
        object.__setattr__(self, "section_policy", SectionSelectionPolicy.from_mapping(self.section_policy))
        object.__setattr__(self, "presentation_limits", MappingProxyType(dict(self.presentation_limits or {})))

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "ExplanationQuery":
        if not isinstance(value, Mapping):
            raise ExplanationQueryError("QUERY_NOT_MAPPING")
        result = value.get("source_result", value.get("result"))
        return cls(
            query_id=value.get("query_id", ""),
            query_type=value.get("query_type", ""),
            result_family=value.get("result_family", ""),
            source_contract=value.get("source_contract", ""),
            source_result=result,
            source_trace=value.get("source_trace", value.get("trace")),
            guild_id=value.get("guild_id"),
            subject_id=value.get("subject_id", value.get("subject_or_actor_id")),
            actor_id=value.get("actor_id"),
            target_type=value.get("target_type"),
            target_id=value.get("target_id"),
            context_id=value.get("context_id"),
            context_type=value.get("context_type"),
            thread_id=value.get("thread_id"),
            thread_type=value.get("thread_type"),
            query_contract_version=value.get("query_contract_version", EXPLANATION_QUERY_CONTRACT_VERSION),
            requested_stage4_pass3_contract=value.get("requested_stage4_pass3_contract", STAGE4_PASS3_CONTRACT_VERSION),
            expected_adapter_registry_version=value.get("expected_adapter_registry_version", EXPLANATION_ADAPTERS_VERSION),
            expected_explanation_schema_version=value.get("expected_explanation_schema_version", EXPLANATION_SCHEMA_VERSION),
            expected_explanation_rules_version=value.get("expected_explanation_rules_version", EXPLANATION_RULES_VERSION),
            expected_presentation_profile_version=value.get("expected_presentation_profile_version", PRESENTATION_PROFILE_VERSION),
            source_stage3_contract_versions=value.get("source_stage3_contract_versions", value.get("contract_versions", {})),
            registry_versions=value.get("registry_versions", {}),
            permission_definition_version=value.get("permission_definition_version", PERMISSION_DEFINITION_VERSION),
            completeness_state=value.get("completeness_state"),
            evidence_classifications=value.get("evidence_classifications", ()),
            verification_statuses=value.get("verification_statuses", ()),
            source_references=value.get("source_references", ()),
            explanation_mode=value.get("explanation_mode", value.get("mode")),
            presentation_profile=value.get("presentation_profile", "SIMPLE_CARD"),
            output_format=value.get("output_format"),
            labels=value.get("labels", {}),
            disclosure_policy=value.get("disclosure_policy"),
            section_policy=value.get("section_policy"),
            presentation_limits=value.get("presentation_limits", {}),
            title=value.get("title"),
            explicit_id_disclosure_allowed=value.get("explicit_id_disclosure_allowed", False),
            authoritative_closure=value.get("authoritative_closure", value.get("closure_evidence")),
            historical_evidence=value.get("historical_evidence"),
        )

    def as_dict(self, *, include_source: bool = True) -> dict[str, Any]:
        data: dict[str, Any] = {
            "query_contract_version": self.query_contract_version,
            "requested_stage4_pass3_contract": self.requested_stage4_pass3_contract,
            "expected_adapter_registry_version": self.expected_adapter_registry_version,
            "expected_explanation_schema_version": self.expected_explanation_schema_version,
            "expected_explanation_rules_version": self.expected_explanation_rules_version,
            "expected_presentation_profile_version": self.expected_presentation_profile_version,
            "query_id": self.query_id,
            "query_type": self.query_type,
            "result_family": self.result_family,
            "source_contract": self.source_contract,
            "guild_id": self.guild_id,
            "subject_id": self.subject_id,
            "actor_id": self.actor_id,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "context_id": self.context_id,
            "context_type": self.context_type,
            "thread_id": self.thread_id,
            "thread_type": self.thread_type,
            "source_stage3_contract_versions": dict(self.source_stage3_contract_versions),
            "registry_versions": dict(self.registry_versions),
            "permission_definition_version": self.permission_definition_version,
            "completeness_state": self.completeness_state,
            "evidence_classifications": list(self.evidence_classifications),
            "verification_statuses": list(self.verification_statuses),
            "source_references": list(self.source_references),
            "explanation_mode": self.explanation_mode,
            "presentation_profile": self.presentation_profile,
            "output_format": self.output_format,
            "labels": _copy_json(self.labels),
            "disclosure_policy": None if self.disclosure_policy is None else self.disclosure_policy.as_dict(),
            "section_policy": self.section_policy.as_dict(),
            "presentation_limits": _copy_json(self.presentation_limits),
            "title": self.title,
            "explicit_id_disclosure_allowed": self.explicit_id_disclosure_allowed,
            "authoritative_closure": _copy_json(self.authoritative_closure),
            "historical_evidence": _copy_json(self.historical_evidence),
        }
        if include_source:
            data["source_result"] = _copy_json(self.source_result)
            data["source_trace"] = _copy_json(self.source_trace)
        return data


def _source_contract_value(result: Any, family: str) -> str | None:
    if isinstance(result, Mapping):
        key = "pass6_contract_version" if family == "ACTION" else "engine_contract_version"
        return _text(result.get(key))
    method = getattr(result, "as_dict", None)
    if callable(method):
        return _source_contract_value(method(), family)
    return None


def _result_value(result: Any, key: str) -> Any:
    if isinstance(result, Mapping):
        return result.get(key)
    method = getattr(result, "as_dict", None)
    if callable(method):
        return method().get(key)
    return None


def _valid_evidence(value: str) -> bool:
    upper = value.upper()
    return upper in _EVIDENCE_EXACT or upper.startswith(_EVIDENCE_PREFIXES)


def _valid_status(value: str) -> bool:
    upper = value.upper()
    return upper in _STATUS_EXACT or upper.startswith(_STATUS_PREFIXES)


def validate_explanation_query(value: ExplanationQuery | Mapping[str, Any]) -> tuple[str, ...]:
    """Return deterministic validation codes without contacting anything."""

    errors: list[str] = []
    if isinstance(value, ExplanationQuery):
        query = value
        raw = query.as_dict()
        errors.extend(_scan_forbidden(query.source_result, "query.source_result"))
        errors.extend(_scan_forbidden(query.source_trace, "query.source_trace"))
    elif isinstance(value, Mapping):
        raw = _copy_json(value)
        errors.extend(_scan_forbidden(value))
        try:
            query = ExplanationQuery.from_mapping(value)
        except (ExplanationQueryError, TypeError, ValueError) as exc:
            errors.append(f"QUERY_CONSTRUCTION:{exc}")
            return tuple(sorted(set(errors)))
    else:
        return ("QUERY_NOT_MAPPING",)
    if validate_query_registry():
        errors.extend(f"QUERY_REGISTRY:{item}" for item in validate_query_registry())
    if not query.query_id:
        errors.append("QUERY_ID_MISSING")
    if query.query_contract_version != EXPLANATION_QUERY_CONTRACT_VERSION:
        errors.append("QUERY_CONTRACT_UNSUPPORTED")
    if query.requested_stage4_pass3_contract != STAGE4_PASS3_CONTRACT_VERSION:
        errors.append("STAGE4_PASS3_CONTRACT_UNSUPPORTED")
    if query.expected_adapter_registry_version != EXPLANATION_ADAPTERS_VERSION:
        errors.append("ADAPTER_REGISTRY_VERSION_UNSUPPORTED")
    if query.expected_explanation_schema_version != EXPLANATION_SCHEMA_VERSION:
        errors.append("EXPLANATION_SCHEMA_VERSION_UNSUPPORTED")
    if query.expected_explanation_rules_version != EXPLANATION_RULES_VERSION:
        errors.append("EXPLANATION_RULES_VERSION_UNSUPPORTED")
    if query.expected_presentation_profile_version != PRESENTATION_PROFILE_VERSION:
        errors.append("PRESENTATION_PROFILE_VERSION_UNSUPPORTED")
    record = QUERY_REGISTRY_BY_TYPE.get(query.query_type)
    if record is None:
        errors.append("QUERY_TYPE_UNKNOWN")
    else:
        if query.result_family != record.result_family:
            errors.append("QUERY_TYPE_RESULT_FAMILY_MISMATCH")
        if query.source_contract != record.source_contract:
            errors.append("RESULT_FAMILY_SOURCE_CONTRACT_MISMATCH")
    if query.result_family not in RESULT_FAMILIES:
        errors.append("RESULT_FAMILY_UNKNOWN")
    adapter = ADAPTER_REGISTRY_BY_FAMILY.get(query.result_family)
    if adapter is None:
        errors.append("ADAPTER_FAMILY_UNKNOWN")
    elif query.source_contract != adapter.source_contract:
        errors.append("ADAPTER_CONTRACT_MISMATCH")
    if query.source_result is None:
        errors.append("SOURCE_RESULT_MISSING")
    if query.source_trace is None or not tuple(query.source_trace):
        errors.append("SOURCE_TRACE_MISSING")
    if _snowflake(query.guild_id) is None:
        errors.append("GUILD_ID_MISSING_OR_INVALID")
    if record is not None:
        for field in record.required_identity_fields:
            if field == "actor_id" and query.actor_id is None and query.subject_id is None:
                errors.append("ACTOR_ID_MISSING")
            elif field != "actor_id" and _snowflake(getattr(query, field, None)) is None:
                errors.append(f"{field.upper()}_MISSING_OR_INVALID")
    if query.target_type not in {None, "NONE"} and _snowflake(query.target_id) is None:
        errors.append("TARGET_ID_MISSING_OR_INVALID")
    if query.context_id is not None and _snowflake(query.context_id) is None:
        errors.append("CONTEXT_ID_INVALID")
    if query.thread_id is not None and _snowflake(query.thread_id) is None:
        errors.append("THREAD_ID_INVALID")
    if query.source_result is not None and adapter is not None:
        source_contract = _source_contract_value(query.source_result, query.result_family)
        if source_contract != query.source_contract:
            errors.append("SOURCE_RESULT_CONTRACT_MISMATCH")
        for field in _ID_FIELDS:
            supplied = getattr(query, field, None)
            source = _result_value(query.source_result, field)
            if supplied is not None and source is not None and _snowflake(supplied) != _snowflake(source):
                errors.append(f"{field.upper()}_MISMATCH")
    if not isinstance(query.explicit_id_disclosure_allowed, bool):
        errors.append("EXPLICIT_ID_DISCLOSURE_FLAG_INVALID")
    if query.completeness_state is not None and _upper(query.completeness_state) not in {"COMPLETE", "PARTIAL", "UNKNOWN", "INCOMPLETE", "FAILED"}:
        errors.append("COMPLETENESS_INVALID")
    for item in query.evidence_classifications:
        if not _valid_evidence(item):
            errors.append(f"EVIDENCE_CLASSIFICATION_INVALID:{item}")
    for item in query.verification_statuses:
        if not _valid_status(item):
            errors.append(f"VERIFICATION_STATUS_INVALID:{item}")
    if not isinstance(query.labels, Mapping):
        errors.append("LABEL_MAP_INVALID")
    elif any(not isinstance(key, str) or not isinstance(label, str) for key, label in query.labels.items()):
        errors.append("LABEL_MAP_VALUES_INVALID")
    profile = get_presentation_profile(query.presentation_profile)
    if profile is None:
        errors.append("PRESENTATION_PROFILE_UNKNOWN")
    else:
        if query.explanation_mode is not None and query.explanation_mode not in EXPLANATION_MODES:
            errors.append("EXPLANATION_MODE_UNSUPPORTED")
        if query.explanation_mode is not None and query.explanation_mode not in profile.allowed_modes:
            errors.append("EXPLANATION_MODE_PROFILE_MISMATCH")
        if query.output_format is not None and query.output_format not in OUTPUT_FORMATS:
            errors.append("OUTPUT_FORMAT_UNSUPPORTED")
        if query.output_format is not None and query.output_format not in profile.allowed_output_formats:
            errors.append("OUTPUT_FORMAT_PROFILE_MISMATCH")
        if query.disclosure_policy is not None:
            try:
                policy = DisclosurePolicy.from_mapping(query.disclosure_policy)
                default = profile.default_disclosure
                for field in policy.__dataclass_fields__:
                    if getattr(policy, field) and not getattr(default, field):
                        # A detailed report may explicitly opt into raw
                        # permission values.  This is a documented, bounded
                        # disclosure choice; all other profile escalations
                        # remain rejected and technical profiles remain
                        # governed by their complete disclosure policy.
                        if field == "include_raw_permission_values" and profile.profile_key == "DETAILED_REPORT":
                            continue
                        if field == "include_ids" and profile.profile_key in {"SIMPLE_CARD", "DISCORD_SAFE_SIMPLE"} and query.explicit_id_disclosure_allowed:
                            continue
                        errors.append(f"DISCLOSURE_ESCALATION:{field}")
                if policy.include_ids and query.presentation_profile in {"SIMPLE_CARD", "DISCORD_SAFE_SIMPLE"} and not query.explicit_id_disclosure_allowed:
                    errors.append("SIMPLE_ID_DISCLOSURE_NOT_EXPLICITLY_ALLOWED")
                if profile.default_mode == "TECHNICAL" and not policy.include_unknown_bits and _has_unknown_bits(query.source_result):
                    errors.append("TECHNICAL_UNKNOWN_BITS_CANNOT_BE_HIDDEN")
            except PresentationProfileError as exc:  # type: ignore[name-defined]
                errors.append(f"DISCLOSURE_POLICY_INVALID:{exc}")
        section = query.section_policy
        if section.include_sections is not None:
            selected = set(section.include_sections)
            if "RESULT" not in selected:
                errors.append("MANDATORY_SECTION_RESULT_SUPPRESSED")
            if "PRIMARY_REASON" not in selected:
                errors.append("MANDATORY_SECTION_PRIMARY_REASON_SUPPRESSED")
            unknown = selected - set(PRESENTATION_SECTIONS)
            if unknown:
                errors.extend(f"SECTION_UNKNOWN:{item}" for item in sorted(unknown))
            unsupported = selected - set(profile.supported_sections)
            for item in sorted(unsupported - set(section.optional_sections)):
                errors.append(f"SECTION_UNSUPPORTED:{item}")
    if query.title is not None and (not isinstance(query.title, str) or len(query.title) > 200):
        errors.append("TITLE_INVALID")
    for key, raw_limit in query.presentation_limits.items():
        if key not in {"max_characters", "max_lines"} or isinstance(raw_limit, bool) or not isinstance(raw_limit, int) or raw_limit <= 0:
            errors.append(f"PRESENTATION_LIMIT_INVALID:{key}")
    if query.result_family == "ACTION":
        execution_attempted = _result_value(query.source_result, "execution_attempted")
        execution_guarantee = _result_value(query.source_result, "execution_guarantee")
        selected = set(query.section_policy.include_sections or ())
        if selected and (execution_attempted is False or execution_guarantee is False) and "PRE_EXECUTION_DISCLAIMER" not in selected:
            errors.append("PRE_EXECUTION_DISCLAIMER_CANNOT_BE_SUPPRESSED")
    selected = set(query.section_policy.include_sections or ())
    if selected and _has_material_uncertainty(query.source_result) and "UNCERTAINTIES" not in selected:
        errors.append("MATERIAL_UNCERTAINTY_CANNOT_BE_SUPPRESSED")
    return tuple(sorted(set(errors)))


def _has_unknown_bits(result: Any) -> bool:
    for key in ("unknown_permission_bits_decimal", "unknown_context_permission_bits_decimal", "unknown_bits_decimal"):
        value = _result_value(result, key)
        if value not in (None, "", "0", 0):
            return True
    return False


def _has_material_uncertainty(result: Any) -> bool:
    for key in ("material_uncertainties", "uncertainties", "unknown_capability_records", "dependency_uncertainties", "missing_components"):
        value = _result_value(result, key)
        if value:
            return True
    return False


__all__ = [
    "EXPLANATION_ORCHESTRATION_VERSION",
    "EXPLANATION_QUERY_CONTRACT_VERSION",
    "EXPLANATION_QUERY_GOLDEN_VERSION",
    "ExplanationQuery",
    "ExplanationQueryError",
    "QUERY_REGISTRY",
    "QUERY_REGISTRY_BY_TYPE",
    "QUERY_TYPES",
    "QUERY_TYPE_TO_FAMILY",
    "QueryRegistryRecord",
    "SectionSelectionPolicy",
    "STAGE4_PASS3_CONTRACT_VERSION",
    "validate_explanation_query",
    "validate_query_registry",
]
