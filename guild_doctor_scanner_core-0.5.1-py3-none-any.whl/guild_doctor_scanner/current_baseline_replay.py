"""Token-free exact calculation and replay for privacy-safe baselines."""

from __future__ import annotations

import copy
from collections.abc import Mapping
from typing import Any

from .authority_live_verifier import model_read_only_scenario
from .canonical import canonical_json
from .current_baseline_schema import (
    CURRENT_BASELINE_REPLAY_CONTRACT_VERSION,
    CurrentBaselineError,
    fingerprint,
    validate_capsule,
)
from .doctor_engine import execute_doctor_query
from .explanation_integration import integrate_stage3_result
from .normalizer import normalize_bundle
from .scenario_manifest import LiveScenario


_REPLAY_IDENTIFIER_KEYS = frozenset({"id", "guild_id", "owner_id", "parent_id", "user_id", "bot_id", "integration_id", "subscription_listing_id", "actor_member_id", "target_id", "context_id", "thread_id"})
_REPLAY_IDENTIFIER_LIST_KEYS = frozenset({"roles", "role_ids", "applied_tags"})


def _replay_surrogates(capsule: Mapping[str, Any]) -> dict[str, Any]:
    """Derive short decimal keys in memory only; never serialize a public mapping."""
    symbols: set[str] = set()

    def collect(value: Any, key: str = "") -> None:
        if isinstance(value, Mapping):
            for child_key, child in value.items():
                collect(child, str(child_key))
        elif isinstance(value, (list, tuple)):
            for child in value:
                collect(child, key)
        elif (key in _REPLAY_IDENTIFIER_KEYS or key.endswith("_id") or key in _REPLAY_IDENTIFIER_LIST_KEYS) and isinstance(value, str) and value.startswith("gd:"):
            symbols.add(value)

    collect(capsule)
    mapping = {symbol: str(index) for index, symbol in enumerate(sorted(symbols), start=1)}

    def replace(value: Any, key: str = "") -> Any:
        if isinstance(value, Mapping):
            return {str(child_key): replace(child, str(child_key)) for child_key, child in value.items()}
        if isinstance(value, list):
            return [replace(child, key) for child in value]
        if isinstance(value, tuple):
            return [replace(child, key) for child in value]
        if (key in _REPLAY_IDENTIFIER_KEYS or key.endswith("_id") or key in _REPLAY_IDENTIFIER_LIST_KEYS) and isinstance(value, str):
            return mapping.get(value, value)
        return value

    return replace(copy.deepcopy(capsule))


def _member_map(bundle: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    result: dict[str, Mapping[str, Any]] = {}
    for member in bundle.get("members", ()):
        if isinstance(member, Mapping) and isinstance(member.get("user"), Mapping):
            member_id = str(member["user"].get("id", ""))
            if member_id.isdecimal():
                result[member_id] = member
    return result


def _doctor_query(scenario: LiveScenario, snapshot: Any, members: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    actor = members[scenario.actor_member_id]
    channels = snapshot.channels or {}
    context_id = scenario.context_id or (scenario.target_id if scenario.target_type == "CHANNEL" else None)
    channel = channels.get(context_id or "")
    return {
        "query_id": f"current-baseline-{scenario.operation_key.replace('.', '-')}",
        "query_intent": "EXPLAIN_ACTUAL_RESULT",
        "target_kind": "ACTION",
        "target_key": scenario.operation_key,
        "guild_id": snapshot.guild_id,
        "subject_id": scenario.actor_member_id,
        "actor_id": scenario.actor_member_id,
        "target_type": scenario.target_type,
        "target_id": scenario.target_id,
        "context_id": context_id,
        "context_type": getattr(channel, "type_key", "GUILD") if channel else "GUILD",
        "parent_id": getattr(channel, "parent_id", None) if channel else None,
        "assigned_role_ids": list(actor.get("roles", ())),
        "actor_mfa_state": "UNKNOWN_NOT_EXPOSED",
        "guild_mfa_level": snapshot.guild.mfa_level,
        "snapshot": snapshot.as_dict(),
        "member_record": None,
        "target_record": None,
        "input_health": {"state": "COMPLETE", "source": "CURRENT_GET_ONLY_BASELINE"},
        "snapshot_or_fixture_version": snapshot.schema_version,
        "explanation_mode": "TECHNICAL",
        "presentation_profile": "TECHNICAL_RECORD",
        "output_format": "STRUCTURED_JSON",
        "evidence_classifications": ["CURRENT_GET_ONLY_BASELINE", "MODELED_RESULT"],
        "verification_statuses": ["CURRENT_BASELINE_EXACT_REPLAY"],
        "authoritative_closure": {"status": "CURRENT_GET_ONLY_BASELINE"},
        "historical_evidence": {"historical_replay_status": "NOT_REPLAYABLE_MISSING_RETAINED_INPUT"},
    }


def calculate_capsule(capsule: Mapping[str, Any]) -> dict[str, Any]:
    """Run frozen Stage 3, Stage 4, and Stage 5 public interfaces."""

    errors = validate_capsule(capsule)
    if errors:
        raise CurrentBaselineError(";".join(errors))
    replay_capsule_data = _replay_surrogates(capsule)
    bundle = replay_capsule_data["bundle"]
    snapshot = normalize_bundle(dict(bundle))
    scenario = LiveScenario.from_mapping(replay_capsule_data["scenario"], index=0)
    members = _member_map(bundle)
    action = model_read_only_scenario(
        scenario,
        snapshot,
        members,
        actor_mfa_state="UNKNOWN_NOT_EXPOSED",
        publicize_result=False,
    )
    explanation = integrate_stage3_result(action, result_family="ACTION", strict=False).as_dict()
    doctor = execute_doctor_query(_doctor_query(scenario, snapshot, members), strict=False).as_dict()
    doctor_case = doctor.get("case", {})
    doctor_projection = {
        "status": doctor_case.get("status"),
        "result_state": doctor_case.get("actual_result", {}).get("result_state"),
        "primary_reason": doctor_case.get("diagnostic_answer", {}).get("primary_reason"),
        "material_uncertainty_retained": doctor_case.get("diagnostic_answer", {}).get("material_uncertainty_retained"),
        "pre_execution_disclaimer_retained": doctor_case.get("diagnostic_answer", {}).get("pre_execution_disclaimer_retained"),
        "errors": doctor_case.get("errors", ()),
    }
    reasons = list(action.get("reason_codes", ()))
    projection = {
        "operation_key": scenario.operation_key,
        "result_state": action.get("final_result"),
        "primary_reason": reasons[0] if reasons else None,
        "material_uncertainties": list(action.get("material_uncertainties", ())),
        "completeness": action.get("analysis_completeness"),
        "decision_basis": action.get("decision_basis"),
        "execution_attempted": action.get("execution_attempted"),
        "execution_guarantee": action.get("execution_guarantee"),
        "endpoint_success_verified": action.get("endpoint_success_verified"),
        "source_result_fingerprint": fingerprint(action),
        "source_trace_fingerprint": fingerprint({"trace": action.get("trace", ())}),
        "explanation_fingerprint": explanation.get("integration_fingerprint"),
        "explanation_status": "PASS" if not explanation.get("integration_errors") and explanation.get("explanation_output") is not None else "INCOMPLETE",
        "doctor_projection_fingerprint": fingerprint(doctor_projection),
        "doctor_status": doctor_case.get("status"),
        "mfa_observation": "UNKNOWN_NOT_EXPOSED",
        "raw_payload_retained": False,
        "discord_write_requests": 0,
    }
    projection["calculation_fingerprint"] = fingerprint(projection)
    return projection


def replay_capsule(capsule: Mapping[str, Any], source: Mapping[str, Any]) -> dict[str, Any]:
    try:
        calculated = calculate_capsule(capsule)
    except (CurrentBaselineError, TypeError, ValueError) as exc:
        return {
            "contract": CURRENT_BASELINE_REPLAY_CONTRACT_VERSION,
            "status": "INVALID_CURRENT_BASELINE_CAPSULE",
            "error_type": type(exc).__name__,
            "network_contacted": False,
            "discord_contacted": False,
            "discord_write_requests": 0,
        }
    matches = canonical_json(calculated) == canonical_json(dict(source))
    return {
        "contract": CURRENT_BASELINE_REPLAY_CONTRACT_VERSION,
        "operation_key": calculated["operation_key"],
        "status": "EXACT_CURRENT_BASELINE_REPLAY" if matches else "CURRENT_BASELINE_REPLAY_MISMATCH",
        "exact_match": matches,
        "source_calculation_fingerprint": source.get("calculation_fingerprint"),
        "replay_calculation_fingerprint": calculated.get("calculation_fingerprint"),
        "field_comparisons": {
            key: calculated.get(key) == source.get(key)
            for key in sorted(set(calculated) | set(source))
        },
        "network_contacted": False,
        "discord_contacted": False,
        "discord_write_requests": 0,
    }


__all__ = ["calculate_capsule", "replay_capsule"]
