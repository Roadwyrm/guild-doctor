"""Fatal input and schema errors."""


class SnapshotError(Exception):
    """Base snapshot error."""


class SnapshotValidationError(SnapshotError):
    """Raised when a canonical snapshot cannot be produced safely."""
