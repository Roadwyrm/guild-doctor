"""Exact-ID-only selected-object bridge for the frozen direct adapters."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .discord_normalized_snapshot_loader import AuthorizedNormalizedSnapshot

EXACT_ID_BRIDGE_CONTRACT = "GUILD-DOCTOR-STAGE6-EXACT-ID-BRIDGE-0.1"

@dataclass(frozen=True)
class ExactResolution:
    outcome: str
    object_id: str | None = None
    record: Mapping[str, Any] | None = None


def selected_object_id(value: object) -> str | None:
    """Narrow a native selector to its ID only; never stringify the object."""
    if value is None:
        return None
    candidate = getattr(value, "id", value)
    rendered = str(candidate)
    return rendered if rendered.isdecimal() else None


def resolve_exact(snapshot: AuthorizedNormalizedSnapshot, *, kind: str, selected: object, guild_id: str) -> ExactResolution:
    object_id = selected_object_id(selected)
    if not snapshot.loaded:
        return ExactResolution("SNAPSHOT_MISSING" if snapshot.outcome == "SNAPSHOT_NOT_FOUND" else snapshot.outcome)
    if object_id is None:
        return ExactResolution("UNSUPPORTED_OBJECT_TYPE")
    if kind == "MEMBER" and snapshot.members_by_id is None:
        return ExactResolution("MEMBER_DATA_REQUIRED", object_id)
    index = {"ROLE": snapshot.roles_by_id, "CATEGORY": snapshot.categories_by_id, "CHANNEL": snapshot.channels_by_id, "MEMBER": snapshot.members_by_id}.get(kind)
    if index is None:
        return ExactResolution("UNSUPPORTED_OBJECT_TYPE", object_id)
    record = (index or {}).get(object_id)
    if record is None:
        # A category passed to a channel route (and vice versa) is a type error,
        # not a name lookup or an object-drift inference.
        other = (snapshot.channels_by_id or {}).get(object_id) or (snapshot.categories_by_id or {}).get(object_id)
        return ExactResolution("OBJECT_TYPE_MISMATCH" if other is not None else "NOT_IN_SNAPSHOT", object_id)
    if str(record.get("guild_id", "")) != guild_id:
        return ExactResolution("OBJECT_DRIFT", object_id)
    return ExactResolution("RESOLVED_EXACT", object_id, record)
