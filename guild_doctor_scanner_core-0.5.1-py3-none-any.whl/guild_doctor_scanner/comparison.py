"""Pass 5 provenance and snapshot comparison utilities."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Iterable

from .acquisition import StructureAcquisition
from .canonical import structural_fingerprint


@dataclass(frozen=True, slots=True)
class ComparisonFinding:
    code: str
    severity: str
    path: str
    expected: Any = None
    observed: Any = None


@dataclass(slots=True)
class SourceSnapshotComparison:
    status: str
    findings: list[ComparisonFinding] = field(default_factory=list)
    compared_collections: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return self.status == "PASS"

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "compared_collections": list(self.compared_collections),
            "findings": [asdict(item) for item in self.findings],
        }


@dataclass(slots=True)
class SnapshotDriftComparison:
    status: str
    first_structural_fingerprint: str | None
    second_structural_fingerprint: str | None
    changed_paths: list[str]

    @property
    def structurally_equal(self) -> bool:
        return self.status == "STABLE"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def compare_acquisition_to_snapshot(acquisition: StructureAcquisition) -> SourceSnapshotComparison:
    """Prove that successful raw collections were represented by the snapshot.

    The comparison intentionally operates on IDs, counts, bitfields, parent
    relationships, and thread state.  It does not compare mutable display names
    as a correctness requirement.
    """

    snapshot = acquisition.snapshot
    if snapshot is None:
        return SourceSnapshotComparison(
            status="UNKNOWN",
            findings=[
                ComparisonFinding(
                    "SNAPSHOT_MISSING",
                    "ERROR",
                    "snapshot",
                    expected="canonical snapshot",
                    observed=acquisition.normalization_error,
                )
            ],
        )

    findings: list[ComparisonFinding] = []
    compared: list[str] = []

    requested = str(acquisition.guild_id)
    if snapshot.guild_id != requested:
        findings.append(
            ComparisonFinding("GUILD_ID_MISMATCH", "ERROR", "guild_id", requested, snapshot.guild_id)
        )

    _compare_guild(acquisition, findings)
    compared.append("guild")
    _compare_map_collection(acquisition, "roles", snapshot.roles, findings, _role_projection)
    compared.append("roles")
    _compare_map_collection(acquisition, "channels", snapshot.channels, findings, _channel_projection)
    compared.append("channels")
    _compare_map_collection(acquisition, "active_threads", snapshot.threads, findings, _thread_projection)
    compared.append("active_threads")

    error_count = sum(1 for item in findings if item.severity == "ERROR")
    return SourceSnapshotComparison(
        status="PASS" if error_count == 0 else "FAIL",
        findings=findings,
        compared_collections=compared,
    )


def compare_snapshots(first: Any, second: Any) -> SnapshotDriftComparison:
    """Compare two normalized snapshots for structural stability."""

    if first is None or second is None:
        return SnapshotDriftComparison("UNKNOWN", None, None, ["snapshot_missing"])

    first_data = first.as_dict() if hasattr(first, "as_dict") else dict(first)
    second_data = second.as_dict() if hasattr(second, "as_dict") else dict(second)
    # Recalculate from current content rather than trusting a possibly stale
    # stored fingerprint. Canonical persisted snapshots are immutable, but this
    # also detects accidental in-memory mutation during verification.
    first_fp = structural_fingerprint(first_data)
    second_fp = structural_fingerprint(second_data)
    if first_fp == second_fp:
        return SnapshotDriftComparison("STABLE", str(first_fp), str(second_fp), [])

    left = _structural_view(first_data)
    right = _structural_view(second_data)
    paths: list[str] = []
    _recursive_diff(left, right, "", paths)
    return SnapshotDriftComparison(
        "DRIFTED" if paths else "STABLE",
        str(first_fp) if first_fp else None,
        str(second_fp) if second_fp else None,
        paths[:500],
    )


def _compare_guild(acquisition: StructureAcquisition, findings: list[ComparisonFinding]) -> None:
    result = acquisition.results.get("guild")
    snapshot = acquisition.snapshot
    if result is None or snapshot is None:
        return
    if result.status != "COMPLETE":
        return
    if not isinstance(result.records, dict) or snapshot.guild is None:
        findings.append(ComparisonFinding("GUILD_RECORD_NOT_NORMALIZED", "ERROR", "guild"))
        return
    raw_id = str(result.records.get("id"))
    if raw_id != snapshot.guild.id:
        findings.append(ComparisonFinding("GUILD_ID_NOT_PRESERVED", "ERROR", "guild.id", raw_id, snapshot.guild.id))
    raw_owner = str(result.records.get("owner_id"))
    if raw_owner != snapshot.guild.owner_id:
        findings.append(
            ComparisonFinding("OWNER_ID_NOT_PRESERVED", "ERROR", "guild.owner_id", raw_owner, snapshot.guild.owner_id)
        )


def _compare_map_collection(
    acquisition: StructureAcquisition,
    resource: str,
    normalized: dict[str, Any] | None,
    findings: list[ComparisonFinding],
    projector: Any,
) -> None:
    result = acquisition.results.get(resource)
    if result is None or result.status != "COMPLETE":
        return
    raw_records = result.records
    if not isinstance(raw_records, list):
        findings.append(ComparisonFinding("RAW_COLLECTION_SHAPE_INVALID", "ERROR", resource))
        return
    if normalized is None:
        findings.append(
            ComparisonFinding("COMPLETE_COLLECTION_NORMALIZED_AS_NULL", "ERROR", resource, "map", None)
        )
        return

    raw_map: dict[str, dict[str, Any]] = {}
    for item in raw_records:
        if not isinstance(item, dict) or item.get("id") is None:
            findings.append(ComparisonFinding("RAW_ENTITY_ID_MISSING", "ERROR", resource))
            continue
        raw_map[str(item["id"])] = item

    raw_ids = set(raw_map)
    normalized_ids = set(normalized)
    if raw_ids != normalized_ids:
        findings.append(
            ComparisonFinding(
                "ENTITY_ID_SET_MISMATCH",
                "ERROR",
                resource,
                sorted(raw_ids),
                sorted(normalized_ids),
            )
        )

    for entity_id in sorted(raw_ids & normalized_ids, key=int):
        expected = projector(raw_map[entity_id])
        observed = projector(normalized[entity_id])
        if expected != observed:
            findings.append(
                ComparisonFinding(
                    "ENTITY_PROJECTION_MISMATCH",
                    "ERROR",
                    f"{resource}.{entity_id}",
                    expected,
                    observed,
                )
            )


def _role_projection(value: Any) -> dict[str, Any]:
    if hasattr(value, "permissions_decimal"):
        return {
            "id": value.id,
            "position": value.position,
            "permissions": value.permissions_decimal,
            "managed": value.managed,
        }
    return {
        "id": str(value.get("id")),
        "position": int(value.get("position", 0)),
        "permissions": str(int(str(value.get("permissions", "0")))),
        "managed": bool(value.get("managed", False)),
    }


def _overwrite_projection(items: Iterable[Any]) -> list[tuple[str, str, str, str]]:
    output = []
    for item in items:
        if hasattr(item, "target_id"):
            target_type = item.target_type
            target_id = item.target_id
            allow = item.allow_decimal
            deny = item.deny_decimal
        else:
            raw_type = item.get("type")
            target_type = "ROLE" if raw_type in (0, "0", "role", "ROLE") else "MEMBER" if raw_type in (1, "1", "member", "MEMBER") else "UNKNOWN"
            target_id = str(item.get("id"))
            allow = str(int(str(item.get("allow", "0"))))
            deny = str(int(str(item.get("deny", "0"))))
        output.append((target_type, target_id, allow, deny))
    return sorted(output)


def _channel_projection(value: Any) -> dict[str, Any]:
    if hasattr(value, "type_code"):
        return {
            "id": value.id,
            "type": value.type_code,
            "parent_id": value.parent_id,
            "position": value.position,
            "overwrites": _overwrite_projection(value.permission_overwrites),
        }
    return {
        "id": str(value.get("id")),
        "type": int(value.get("type")),
        "parent_id": str(value["parent_id"]) if value.get("parent_id") is not None else None,
        "position": int(value.get("position", 0)),
        "overwrites": _overwrite_projection(value.get("permission_overwrites", [])),
    }


def _thread_projection(value: Any) -> dict[str, Any]:
    if hasattr(value, "type_code"):
        return {
            "id": value.id,
            "type": value.type_code,
            "parent_id": value.parent_id,
            "archived": value.archived,
            "locked": value.locked,
        }
    metadata = value.get("thread_metadata") or {}
    return {
        "id": str(value.get("id")),
        "type": int(value.get("type")),
        "parent_id": str(value["parent_id"]) if value.get("parent_id") is not None else None,
        "archived": metadata.get("archived"),
        "locked": metadata.get("locked"),
    }


def _structural_view(data: dict[str, Any]) -> dict[str, Any]:
    return {
        "guild": data.get("guild"),
        "roles": data.get("roles"),
        "channels": data.get("channels"),
        "threads": data.get("threads"),
        "bindings": data.get("bindings"),
        "structural_completeness": data.get("structural_completeness"),
        "thread_completeness": data.get("thread_completeness"),
    }


def _recursive_diff(left: Any, right: Any, path: str, output: list[str]) -> None:
    if type(left) is not type(right):
        output.append(path or "$")
        return
    if isinstance(left, dict):
        keys = sorted(set(left) | set(right))
        for key in keys:
            child = f"{path}.{key}" if path else str(key)
            if key not in left or key not in right:
                output.append(child)
            else:
                _recursive_diff(left[key], right[key], child, output)
        return
    if isinstance(left, list):
        if left != right:
            output.append(path or "$")
        return
    if left != right:
        output.append(path or "$")
