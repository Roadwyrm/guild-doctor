"""Offline sequencing of frozen Pass 1/2 contracts into neutral responses."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any

from .discord_authorization_contract import AuthorizationInput, authorize
from .discord_engine_routing_contract import ROUTES
from .discord_interaction_policy import acknowledgement_for, visibility_for
from .discord_interaction_request import InteractionRequest, validate_request
from .discord_query_adapter import DIRECT_COMMANDS, adapt
from .discord_response_renderer import render_result
from .discord_snapshot_gate import evaluate_snapshot
from .discord_targeted_member_policy import decide_targeted_fetch
from .discord_user_error_renderer import render_error
from .discord_interaction_envelope import (
    COMPARISON_RESULT, ERROR_RESULT, PERMISSION_RESULT, ComparisonResultPayload,
    ErrorResultPayload, InteractionEnvelope,
)


DIRECT_INTERACTION_ADAPTER_CONTRACT = "GUILD-DOCTOR-DISCORD-DIRECT-INTERACTION-ADAPTER-0.1"
STAGE6_PASS3_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS3-0.1"


@dataclass(frozen=True)
class EnvelopeAdapterResult:
    """Typed renderer seam for validated envelope results.

    The comparison and error branches are deliberately not rendered here.
    """

    response_kind: str
    permission_result: Any = None
    comparison_result: ComparisonResultPayload | None = None
    error_result: ErrorResultPayload | None = None


def adapt_interaction_envelope(envelope: InteractionEnvelope) -> EnvelopeAdapterResult:
    """Preserve a validated envelope without coercing comparison into permission state."""
    if not isinstance(envelope, InteractionEnvelope):
        raise ValueError("STAGE6_COMPARISON_ENVELOPE_KIND_INVALID")
    if envelope.response_kind == PERMISSION_RESULT:
        if envelope.permission_result is None or envelope.comparison_result is not None or envelope.error_result is not None:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH")
        return EnvelopeAdapterResult(PERMISSION_RESULT, permission_result=envelope.permission_result)
    if envelope.response_kind == COMPARISON_RESULT:
        payload = envelope.comparison_result
        if payload is None or envelope.permission_result is not None or envelope.error_result is not None:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH")
        # Intentionally never inspect a comparison result_state: it does not exist.
        return EnvelopeAdapterResult(COMPARISON_RESULT, comparison_result=payload)
    if envelope.response_kind == ERROR_RESULT:
        if envelope.error_result is None or envelope.permission_result is not None or envelope.comparison_result is not None:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH")
        return EnvelopeAdapterResult(ERROR_RESULT, error_result=envelope.error_result)
    raise ValueError("STAGE6_COMPARISON_ENVELOPE_KIND_INVALID")


def handle_direct_interaction(request: InteractionRequest, engine_result: dict | InteractionEnvelope, *, requested_member_count: int = 0):
    request_errors = validate_request(request)
    if request_errors:
        return render_error(correlation_id=request.correlation_id, command_key=request.command_key, code="STAGE6_ENGINE_INTERNAL_ERROR")
    authorization = authorize(AuthorizationInput("GUILD" if request.guild_context_present else "DM", request.guild_id, request.actor_member_id, request.owner_member_id))
    is_owner = authorization == "ALLOW"
    acknowledgement = acknowledgement_for(authorized=is_owner, interaction_age_seconds=request.interaction_age_seconds, estimated_work="ENUMERATION" if request.command_key.startswith("who-") else "STANDARD")
    if acknowledgement == "INTERACTION_EXPIRED":
        return render_error(correlation_id=request.correlation_id, command_key=request.command_key, code="STAGE6_INTERACTION_TIMEOUT", acknowledgement_class=acknowledgement)
    if not request.guild_context_present:
        return render_error(correlation_id=request.correlation_id, command_key=request.command_key, code="STAGE6_DM_NOT_SUPPORTED", acknowledgement_class=acknowledgement)
    if not is_owner:
        return render_error(correlation_id=request.correlation_id, command_key=request.command_key, code="STAGE6_OWNER_ONLY", acknowledgement_class=acknowledgement)
    if request.command_key not in DIRECT_COMMANDS:
        return render_error(correlation_id=request.correlation_id, command_key=request.command_key, code="STAGE6_ACTION_UNKNOWN", acknowledgement_class=acknowledgement)
    if request.input_resolution_state != "RESOLVED":
        not_in_snapshot = {
            "explain-role": "STAGE6_ROLE_NOT_FOUND", "compare-roles": "STAGE6_ROLE_NOT_FOUND",
            "explain-category": "STAGE6_CATEGORY_NOT_FOUND",
        }.get(request.command_key, "STAGE6_CHANNEL_NOT_FOUND")
        resolution_errors = {
            "SNAPSHOT_MISSING": "STAGE6_SNAPSHOT_MISSING",
            "SNAPSHOT_GUILD_MISMATCH": "STAGE6_SNAPSHOT_MISSING",
            "SNAPSHOT_SCHEMA_MISMATCH": "STAGE6_SNAPSHOT_SCHEMA_MISMATCH",
            "SNAPSHOT_STALE": "STAGE6_SNAPSHOT_STALE",
            "SNAPSHOT_INCOMPLETE": "STAGE6_SNAPSHOT_PARTIAL",
            "NOT_IN_SNAPSHOT": not_in_snapshot,
            "OBJECT_TYPE_MISMATCH": "STAGE6_UNSUPPORTED_OBJECT_TYPE",
            "OBJECT_DRIFT": "STAGE6_OBJECT_STALE",
            "MEMBER_DATA_REQUIRED": "STAGE6_MEMBER_DATA_REQUIRED",
            "UNSUPPORTED_OBJECT_TYPE": "STAGE6_UNSUPPORTED_OBJECT_TYPE",
        }
        return render_error(correlation_id=request.correlation_id, command_key=request.command_key, code=resolution_errors.get(request.input_resolution_state, "STAGE6_OBJECT_STALE"), acknowledgement_class=acknowledgement)
    member_required = request.selected_member_id is not None
    snapshot_gate = evaluate_snapshot(request.snapshot_state, member_required, request.member_health)
    snapshot_errors = {"RETURN_INCOMPLETE": "STAGE6_SNAPSHOT_MISSING", "REQUIRE_FRESH_SCAN": "STAGE6_SNAPSHOT_STALE", "REFUSE_SCHEMA_MISMATCH": "STAGE6_SNAPSHOT_SCHEMA_MISMATCH", "REFUSE_OBJECT_DRIFT": "STAGE6_OBJECT_STALE"}
    if snapshot_gate in snapshot_errors:
        return render_error(correlation_id=request.correlation_id, command_key=request.command_key, code=snapshot_errors[snapshot_gate], acknowledgement_class=acknowledgement)
    member_policy = decide_targeted_fetch(authorized=True, selected_member_id=request.selected_member_id, requested_count=requested_member_count)
    if member_policy == "DENY_UNBOUNDED_MEMBER_ACQUISITION":
        return render_error(correlation_id=request.correlation_id, command_key=request.command_key, code="STAGE6_MEMBER_DATA_REQUIRED", acknowledgement_class=acknowledgement)
    if isinstance(engine_result, InteractionEnvelope):
        return adapt_interaction_envelope(engine_result)
    if engine_result.get("stable_error"):
        return render_error(correlation_id=request.correlation_id, command_key=request.command_key, code=engine_result["stable_error"], acknowledgement_class=acknowledgement)
    adapted = {**engine_result, **adapt(request.command_key, engine_result, request.correlation_id), "engine_contract_id": ROUTES[request.command_key], "engine_result_fingerprint": engine_result.get("engine_result_fingerprint")}
    return render_result(correlation_id=request.correlation_id, command_key=request.command_key, visibility=visibility_for(authorized=True, requested_visibility=request.requested_visibility, command_key=request.command_key), acknowledgement_class=acknowledgement, adapted=adapted, export_available=True)
