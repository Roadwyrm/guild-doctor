"""Stage 5 Pass 1 single-subject Doctor orchestration.

This module assembles explicit immutable inputs and delegates every decision to
the frozen Stage 3 public engines.  It contains no Discord import, transport,
storage, mutation, natural-language parser, or duplicated permission rule.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from .action_engine import ActionOrchestrationRequest, ActionOrchestrationResult, evaluate_action_orchestration
from .action_registry import ACTION_RULES_BY_KEY, ACTION_RULES_VERSION
from .authority_engine import AuthorityAnalysisRequest, AuthorityAnalysisResult, evaluate_authority_analysis
from .capability_engine import (
    CapabilityExpansionRequest,
    CapabilityExpansionResult,
    evaluate_capability_expansion,
)
from .capability_registry import CAPABILITY_REGISTRY_VERSION, DEFAULT_CAPABILITY_REGISTRY
from .canonical import canonical_json
from .constants import PERMISSION_DEFINITION_VERSION, SNAPSHOT_SCHEMA_VERSION
from .doctor_case import DoctorCase, build_doctor_case
from .doctor_query import (
    ACTION,
    CAPABILITY,
    EXPECTED_REGISTRY_VERSIONS,
    EXPECTED_STAGE3_CONTRACT_VERSIONS,
    EXPLAIN_ACTUAL_RESULT,
    DoctorQuery,
    DoctorQueryError,
    STAGE5_PASS1_CONTRACT_VERSION,
    thaw,
    validate_doctor_query,
)
from .doctor_rules import (
    RULE_PREMISE_ALIGNMENT,
    align_premise,
    causal_chain,
    direct_answer,
    material_reasons,
    primary_reason,
    source_locations,
    validate_doctor_rules,
)
from .explanation_adapters import EXPLANATION_ADAPTERS_VERSION
from .explanation_orchestrator import orchestrate_explanation
from .explanation_query import EXPLANATION_QUERY_CONTRACT_VERSION
from .explanation_schema import EXPLANATION_SCHEMA_VERSION
from .fixture_export import STAGE3_FIXTURE_VERSION
from .mfa_rules import MFA_RULES_VERSION
from .object_preconditions import OBJECT_PRECONDITIONS_VERSION
from .permission_engine import PermissionEvaluationRequest, evaluate_guild_permissions
from .permission_overwrite_engine import PermissionOverwriteEvaluationRequest, evaluate_context_permissions
from .thread_engine import ThreadResolutionRequest, evaluate_thread_permissions
from .thread_rules import THREAD_RULES_VERSION


class DoctorEngineError(RuntimeError):
    """Raised only when strict execution is requested."""


@dataclass(frozen=True, slots=True)
class DoctorExecution:
    """Execution envelope retaining the Doctor case and all stage outputs."""

    case: DoctorCase
    stage_results: Mapping[str, Any]

    @property
    def passed(self) -> bool:
        return self.case.status == "PASS"

    def as_dict(self) -> dict[str, Any]:
        return {
            "case": self.case.as_dict(),
            "stage_results": {key: _as_dict(value) for key, value in sorted(self.stage_results.items())},
        }


def _as_dict(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        return method()
    if isinstance(value, Mapping):
        return {str(key): _as_dict(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [_as_dict(child) for child in value]
    return deepcopy(value)


def _read(value: Any, key: str, default: Any = None) -> Any:
    if isinstance(value, Mapping):
        return value.get(key, default)
    return getattr(value, key, default)


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _records(value: Any) -> tuple[Any, ...] | None:
    if value is None:
        return None
    if isinstance(value, Mapping):
        if "id" in value or "target_id" in value:
            return (value,)
        return tuple(value[key] for key in sorted(value, key=lambda item: str(item)))
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return tuple(value)
    return (value,)


def _find(value: Any, identifier: str | None) -> Any:
    if identifier is None:
        return None
    for record in _records(value) or ():
        if _snowflake(_read(record, "id", _read(record, "target_id"))) == identifier:
            return record
    return None


def _snapshot(query: DoctorQuery) -> dict[str, Any]:
    return thaw(query.snapshot) if query.snapshot is not None else {}


def _guild(snapshot: Mapping[str, Any]) -> Mapping[str, Any] | None:
    value = snapshot.get("guild")
    return value if isinstance(value, Mapping) else None


def _guild_id(snapshot: Mapping[str, Any]) -> str | None:
    direct = _snowflake(snapshot.get("guild_id"))
    if direct:
        return direct
    guild = _guild(snapshot)
    return _snowflake(guild.get("id")) if guild else None


def _owner_id(snapshot: Mapping[str, Any]) -> str | None:
    guild = _guild(snapshot)
    return _snowflake(guild.get("owner_id")) if guild else None


def _source_version(query: DoctorQuery, snapshot: Mapping[str, Any]) -> str | None:
    if query.snapshot_or_fixture_version:
        return query.snapshot_or_fixture_version
    value = snapshot.get("schema_version") or snapshot.get("fixture_version")
    if value:
        return str(value)
    source = snapshot.get("source")
    if isinstance(source, Mapping):
        return source.get("snapshot_schema_version") or source.get("fixture_version")
    return None


def _permission_version(query: DoctorQuery, snapshot: Mapping[str, Any]) -> str | None:
    if query.permission_definition_version:
        return query.permission_definition_version
    source = snapshot.get("source")
    if isinstance(source, Mapping):
        return source.get("permission_definition_version")
    return snapshot.get("permission_definition_version") or PERMISSION_DEFINITION_VERSION


def _health(query: DoctorQuery, snapshot: Mapping[str, Any]) -> dict[str, Any]:
    if query.input_health is not None:
        return thaw(query.input_health)
    for key in ("structural_completeness", "source_structural_completeness", "completeness"):
        if snapshot.get(key) is not None:
            return {"structural_completeness": snapshot[key]}
    source = snapshot.get("source")
    if isinstance(source, Mapping) and source.get("source_structural_completeness") is not None:
        return {"structural_completeness": source["source_structural_completeness"]}
    return {}


def _members(snapshot: Mapping[str, Any]) -> Any:
    return snapshot.get("members")


def _member(query: DoctorQuery, snapshot: Mapping[str, Any], identifier: str | None) -> Any:
    if identifier == query.subject_id and query.member_record is not None:
        return thaw(query.member_record)
    return _find(_members(snapshot), identifier)


def _roles(snapshot: Mapping[str, Any]) -> Any:
    return snapshot.get("roles")


def _channels(snapshot: Mapping[str, Any]) -> Any:
    return snapshot.get("channels")


def _threads(snapshot: Mapping[str, Any]) -> Any:
    return snapshot.get("threads")


def _assigned_role_ids(query: DoctorQuery, member: Any) -> Sequence[str] | None:
    if query.assigned_role_ids is not None:
        return query.assigned_role_ids
    value = _read(member, "role_ids")
    if value is None:
        return None
    return tuple(str(item) for item in value)


def _timeout_state(query: DoctorQuery, member: Any) -> str:
    value = query.timeout_state or _read(member, "timeout_state")
    return str(value).upper() if value else "UNKNOWN"


def _member_health(query: DoctorQuery, snapshot: Mapping[str, Any]) -> Mapping[str, Any]:
    if query.explicitly_supplied_member_health is not None:
        return thaw(query.explicitly_supplied_member_health) or {}
    collections = snapshot.get("collections")
    if isinstance(collections, Mapping):
        member_health = collections.get("members")
        if isinstance(member_health, Mapping):
            status = member_health.get("status")
            return {"status": status} if status is not None else {}
    return _health(query, snapshot)


def _role_health(query: DoctorQuery, snapshot: Mapping[str, Any]) -> Mapping[str, Any]:
    if query.explicitly_supplied_role_reference_health is not None:
        return thaw(query.explicitly_supplied_role_reference_health) or {}
    return _health(query, snapshot)


def _pass1(query: DoctorQuery, snapshot: Mapping[str, Any], *, member: Any = None) -> Any:
    guild_id = query.guild_id
    guild_owner_id = _owner_id(snapshot)
    return evaluate_guild_permissions(
        PermissionEvaluationRequest(
            guild_id=guild_id,
            guild_owner_id=guild_owner_id,
            subject_id=query.subject_id,
            assigned_role_ids=_assigned_role_ids(query, member),
            role_records=_roles(snapshot),
            permission_definition_version=_permission_version(query, snapshot),
            snapshot_or_fixture_version=_source_version(query, snapshot),
            input_health=_role_health(query, snapshot),
        )
    )


def _context_record(query: DoctorQuery, snapshot: Mapping[str, Any]) -> Any:
    if query.context_id is None or query.context_type == "GUILD":
        return None
    if (query.target_kind == ACTION and query.target_type == "THREAD" or query.context_type in {"PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"}) and query.parent_id:
        return _find(_channels(snapshot), query.parent_id)
    return query.target_record if query.target_record is not None and query.context_id == _snowflake(_read(query.target_record, "id")) else _find(_channels(snapshot), query.context_id)


def _context_type(query: DoctorQuery, context: Any) -> str | None:
    if query.context_type in {"PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"}:
        return _read(context, "type_key") or _read(context, "type_code")
    return query.context_type or _read(context, "type_key") or _read(context, "type_code")


def _pass2(query: DoctorQuery, snapshot: Mapping[str, Any], pass1: Any) -> Any:
    context = _context_record(query, snapshot)
    context_id = query.context_id or _snowflake(_read(context, "id"))
    context_type = _context_type(query, context)
    if context_id is None or context_type == "GUILD":
        return None
    parent_id = query.parent_id if query.parent_id is not None else _snowflake(_read(context, "parent_id"))
    return evaluate_context_permissions(
        PermissionOverwriteEvaluationRequest(
            guild_id=query.guild_id,
            subject_id=query.subject_id,
            assigned_role_ids=_assigned_role_ids(query, _member(query, snapshot, query.subject_id)),
            guild_permission_result=pass1,
            context_id=context_id,
            context_type=context_type,
            context_guild_id=_snowflake(_read(context, "guild_id")) or query.guild_id,
            context_parent_id=parent_id,
            context_sync_state=_read(context, "sync_state") or ("NOT_APPLICABLE" if context_type == "CATEGORY" else None),
            context_permission_overwrites=_read(context, "permission_overwrites"),
            normalized_roles=_roles(snapshot),
            permission_definition_version=_permission_version(query, snapshot),
            snapshot_or_fixture_version=_source_version(query, snapshot),
            input_health=_role_health(query, snapshot),
        )
    )


def _pass3(query: DoctorQuery, snapshot: Mapping[str, Any], pass2: Any, pass1: Any, member: Any) -> Any:
    timeout = _timeout_state(query, member)
    if pass2 is None:
        return evaluate_capability_expansion(
            CapabilityExpansionRequest(
                pass2_result=None,
                guild_id=query.guild_id,
                subject_id=query.subject_id,
                context_id=query.context_id,
                context_type=query.context_type,
                bypass_state=_read(pass1, "bypass_state"),
                timeout_state=timeout,
                permission_definition_version=_permission_version(query, snapshot),
                snapshot_or_fixture_version=_source_version(query, snapshot),
                input_health=_health(query, snapshot),
                capability_registry=DEFAULT_CAPABILITY_REGISTRY,
            )
        )
    return evaluate_capability_expansion(
        CapabilityExpansionRequest.from_pass2_result(
            pass2,
            timeout_state=timeout,
            input_health=_health(query, snapshot),
            capability_registry=DEFAULT_CAPABILITY_REGISTRY,
        )
    )


def _select_capability(result: Any, key: str) -> Any:
    for field in (
        "effective_capability_records",
        "ineffective_grant_records",
        "denied_capability_records",
        "unknown_capability_records",
        "inapplicable_capability_records",
        "policy_only_category_records",
    ):
        for record in _read(result, field, ()) or ():
            if _read(record, "capability_key") == key:
                return record
    return None


def _select_thread(result: Any, key: str) -> Any:
    key = {
        "message.send": "thread.message_send",
        "message.read_history": "thread.read_history",
        "view.channel": "thread.visibility",
    }.get(key, key)
    for field in ("inherited_capability_records", "blocked_or_ineffective_records", "unknown_records", "unsupported_records"):
        for record in _read(result, field, ()) or ():
            if _read(record, "capability_key") == key:
                return record
    return None


def _pass4(query: DoctorQuery, snapshot: Mapping[str, Any], pass1: Any, pass2: Any, pass3: Any, member: Any) -> Any:
    thread = query.target_record if query.target_type == "THREAD" and query.target_record is not None else _find(_threads(snapshot), query.thread_id or query.target_id)
    thread_id = query.thread_id or query.target_id or _snowflake(_read(thread, "id"))
    parent_id = query.parent_id or _snowflake(_read(thread, "parent_id"))
    parent = _find(_channels(snapshot), parent_id)
    membership_records = snapshot.get("thread_memberships")
    membership_state = query.membership_state
    if membership_state is None and membership_records is not None:
        found = None
        for record in _records(membership_records) or ():
            if _snowflake(_read(record, "thread_id")) == thread_id and _snowflake(_read(record, "member_id")) == query.subject_id:
                found = record
                break
        membership_state = _read(found, "membership_state") if found is not None else "UNKNOWN"
    return evaluate_thread_permissions(
        ThreadResolutionRequest(
            pass2_parent_result=pass2,
            pass3_parent_result=pass3,
            parent_channel_id=parent_id,
            parent_channel_type=query.context_type if query.context_type in {"TEXT", "ANNOUNCEMENT", "VOICE", "STAGE", "FORUM", "MEDIA"} else _read(parent, "type_key"),
            parent_guild_id=_snowflake(_read(parent, "guild_id")) or query.guild_id,
            thread_id=thread_id,
            thread_guild_id=_snowflake(_read(thread, "guild_id")) or query.guild_id,
            thread_parent_id=parent_id,
            thread_type=query.thread_type or _read(thread, "type_key") or _read(thread, "type_code"),
            thread_owner_id=_snowflake(_read(thread, "owner_id")),
            archived_state=_read(thread, "archived"),
            locked_state=_read(thread, "locked"),
            invitable_state=_read(thread, "invitable"),
            auto_archive_duration=_read(thread, "auto_archive_duration"),
            archive_timestamp=_read(thread, "archive_timestamp"),
            thread_record=thread,
            parent_channel_record=parent,
            thread_source_health=_health(query, snapshot),
            subject_id=query.subject_id,
            bypass_state=_read(pass1, "bypass_state"),
            timeout_state=_timeout_state(query, member),
            membership_state=membership_state,
            membership_source_health=_member_health(query, snapshot),
            membership_records=membership_records,
            thread_permission_overwrites=_read(thread, "permission_overwrites"),
            input_health=_health(query, snapshot),
            pass1_contract_version=_read(pass2, "pass1_contract_version"),
            pass2_contract_version=_read(pass2, "engine_contract_version"),
            pass3_contract_version=_read(pass3, "engine_contract_version"),
            capability_registry_version=_read(pass3, "capability_registry_version"),
            permission_definition_version=_permission_version(query, snapshot),
            snapshot_or_fixture_version=_source_version(query, snapshot),
        )
    )


def _target_member_pass1(query: DoctorQuery, snapshot: Mapping[str, Any], target_member: Any) -> Any:
    if target_member is None:
        return None
    assigned = _read(target_member, "role_ids")
    if assigned is None:
        return None
    return evaluate_guild_permissions(
        PermissionEvaluationRequest(
            guild_id=query.guild_id,
            guild_owner_id=_owner_id(snapshot),
            subject_id=_snowflake(_read(target_member, "id")) or query.target_id,
            assigned_role_ids=assigned,
            role_records=_roles(snapshot),
            permission_definition_version=_permission_version(query, snapshot),
            snapshot_or_fixture_version=_source_version(query, snapshot),
            input_health=_member_health(query, snapshot),
        )
    )


def _authority(query: DoctorQuery, snapshot: Mapping[str, Any], pass1: Any, pass2: Any, pass3: Any, pass4: Any, actor: Any, target: Any) -> Any:
    rule = ACTION_RULES_BY_KEY[query.target_key]
    from .authority_registry import AUTHORITY_OPERATIONS_BY_KEY

    operation = AUTHORITY_OPERATIONS_BY_KEY.get(query.target_key)
    target_member = target if query.target_type == "MEMBER" else None
    target_role = target if query.target_type == "ROLE" else None
    target_member_pass1 = _target_member_pass1(query, snapshot, target_member)
    actor_role_id = query.actor_highest_role_id or _snowflake(_read(actor, "highest_role_id"))
    actor_position = query.actor_highest_role_position if query.actor_highest_role_position is not None else _read(actor, "highest_role_position")
    target_role_id = query.target_highest_role_id or _snowflake(_read(target_role, "id"))
    target_position = query.target_highest_role_position if query.target_highest_role_position is not None else _read(target_role, "position")
    actor_raw_context = _read(pass2, "raw_context_permission_decimal")
    actor_raw_guild = _read(pass1, "raw_guild_permission_decimal")
    actor_member_mfa = query.actor_mfa_state or _read(actor, "mfa_state")
    guild = _guild(snapshot) or {}
    context = _context_record(query, snapshot)
    actor_kind = "BOT" if _read(actor, "bot") is True else "HUMAN"
    return evaluate_authority_analysis(
        AuthorityAnalysisRequest(
            operation_key=query.target_key,
            guild_id=query.guild_id,
            guild_owner_id=_owner_id(snapshot),
            actor_id=query.actor_id or query.subject_id,
            actor_kind=actor_kind,
            target_type=query.target_type,
            target_id=query.target_id,
            permission_definition_version=_permission_version(query, snapshot),
            pass1_contract_version=_read(pass1, "engine_contract_version"),
            pass2_contract_version=_read(pass2, "engine_contract_version"),
            pass3_contract_version=_read(pass3, "engine_contract_version"),
            pass4_contract_version=_read(pass4, "engine_contract_version"),
            snapshot_or_fixture_version=_source_version(query, snapshot),
            capability_permission_result=_select_capability(pass3, operation.capability_key if operation else None) if pass3 is not None and operation else None,
            capability_result=pass3,
            capability_record=_select_capability(pass3, operation.capability_key if operation else "") if pass3 is not None and operation else None,
            source_capability_key=operation.capability_key if operation else None,
            required_source_permission_flags=operation.required_source_permission_flags if operation else (),
            actor_raw_guild_permissions_decimal=actor_raw_guild,
            actor_raw_context_permissions_decimal=actor_raw_context,
            actor_bypass_state=_read(pass1, "bypass_state"),
            actor_highest_role_id=actor_role_id,
            actor_highest_role_position=actor_position,
            actor_role_order_health=_member_health(query, snapshot),
            actor_is_guild_owner=(query.actor_id or query.subject_id) == _owner_id(snapshot),
            actor_is_bot=_read(actor, "bot"),
            actor_mfa_state=actor_member_mfa,
            target_is_guild_owner=query.target_id == _owner_id(snapshot),
            target_has_administrator=(_read(target_member_pass1, "bypass_state") == "ADMINISTRATOR") if target_member_pass1 is not None else None,
            target_highest_role_id=target_role_id or _snowflake(_read(target_member, "highest_role_id")),
            target_highest_role_position=target_position if target_position is not None else _read(target_member, "highest_role_position"),
            target_role_managed=query.target_role_managed if query.target_role_managed is not None else _read(target_role, "managed"),
            target_role_tags=_read(target_role, "role_tags"),
            target_role_is_everyone=query.target_role_is_everyone if query.target_role_is_everyone is not None else _read(target_role, "is_everyone"),
            target_role_source_health=_role_health(query, snapshot),
            requested_permission_bits=query.requested_permission_bits,
            requested_overwrite_allow_bits=query.requested_overwrite_allow_bits,
            requested_overwrite_deny_bits=query.requested_overwrite_deny_bits,
            actor_authorized_permission_bits=actor_raw_context if actor_raw_context is not None else actor_raw_guild,
            permission_authority_scope="TARGET_CHANNEL" if query.context_id else "GUILD",
            context_guild_id=_snowflake(_read(context, "guild_id")) or query.guild_id,
            parent_channel_id=query.parent_id,
            target_channel_id=query.context_id if query.target_type == "CHANNEL" else None,
            overwrite_guild_id=query.guild_id if query.target_type == "OVERWRITE" else None,
            overwrite_target_id=query.target_id if query.target_type == "OVERWRITE" else None,
            overwrite_target_type=_read(target, "target_type") if query.target_type == "OVERWRITE" else None,
            guild_mfa_level=query.guild_mfa_level or _read(guild, "mfa_level"),
            relevant_elevated_permission_flag=operation.mfa_permission_flag if operation else None,
            mfa_source_health=_member_health(query, snapshot),
            actor_has_effective_manage_roles_in_target_channel=None,
            assigned_or_removed_role_id=query.target_id if query.target_type == "ROLE" else None,
            target_member_id=query.target_id if query.target_type == "MEMBER" else None,
            target_member_is_guild_owner=query.target_id == _owner_id(snapshot) if query.target_type == "MEMBER" else None,
            target_member_has_administrator=(_read(target_member_pass1, "bypass_state") == "ADMINISTRATOR") if target_member_pass1 is not None else None,
            target_member_highest_role_position=_read(target_member, "highest_role_position") if target_member is not None else None,
            target_member_role_order_health=_member_health(query, snapshot),
            target_member_hierarchy_result=None,
            input_health=_health(query, snapshot),
            evidence_classification=(query.evidence_classifications[0] if query.evidence_classifications else "SYNTHETIC_DOCTOR_QUERY"),
            verification_status=(query.verification_statuses[0] if query.verification_statuses else "SYNTHETIC_DOCTOR_QUERY"),
            source_references=query.source_references,
        )
    )


def _action(query: DoctorQuery, snapshot: Mapping[str, Any], pass1: Any, pass2: Any, pass3: Any, pass4: Any, pass5: Any) -> Any:
    rule = ACTION_RULES_BY_KEY.get(query.target_key)
    operation_capability = rule.required_capability_keys[0] if rule and rule.required_capability_keys else None
    return evaluate_action_orchestration(
        ActionOrchestrationRequest(
            operation_key=query.target_key,
            guild_id=query.guild_id,
            actor_id=query.actor_id or query.subject_id,
            subject_id=query.subject_id,
            target_type=query.target_type,
            target_id=query.target_id,
            context_id=query.context_id,
            context_type=query.context_type,
            thread_id=query.thread_id,
            thread_type=query.thread_type,
            bypass_state=_read(pass1, "bypass_state"),
            capability_result=pass3,
            thread_result=pass4,
            authority_result=pass5,
            input_health=_health(query, snapshot),
            evidence_classifications=tuple(query.evidence_classifications or ("SYNTHETIC_DOCTOR_QUERY",)),
            verification_statuses=tuple(query.verification_statuses or ("SYNTHETIC_DOCTOR_QUERY",)),
            source_references=query.source_references,
            pass1_contract_version=_read(pass1, "engine_contract_version"),
            pass2_contract_version=_read(pass2, "engine_contract_version"),
            pass3_contract_version=_read(pass3, "engine_contract_version"),
            pass4_contract_version=_read(pass4, "engine_contract_version"),
            pass5_contract_version=_read(pass5, "engine_contract_version"),
            capability_registry_version=_read(pass3, "capability_registry_version"),
            thread_rules_version=_read(pass4, "thread_rules_version"),
            authority_rules_version=_read(pass5, "authority_rules_version"),
            object_preconditions_version=_read(pass5, "object_preconditions_version"),
            mfa_rules_version=_read(pass5, "mfa_rules_version"),
            permission_definition_version=_permission_version(query, snapshot),
            snapshot_or_fixture_version=_source_version(query, snapshot),
        )
    )


def _result_state(query: DoctorQuery, *, capability_record: Any, thread_record: Any, action_result: Any) -> str:
    if query.target_kind == ACTION:
        return str(_read(action_result, "final_result", "UNKNOWN")).upper()
    record = thread_record or capability_record
    return str(_read(record, "final_result", _read(record, "result_state", "UNKNOWN"))).upper() if record is not None else "UNKNOWN"


def _stage_contracts(stage_results: Mapping[str, Any]) -> dict[str, str]:
    values: dict[str, str] = {}
    for key, result in stage_results.items():
        mapping = _as_dict(result)
        if not isinstance(mapping, Mapping):
            continue
        for field, value in mapping.items():
            if field.endswith("_contract_version") and isinstance(value, str):
                values[field] = value
    return dict(sorted(values.items()))


def _stage_fingerprint(result: Any) -> str:
    mapping = _as_dict(result)
    for key in ("result_fingerprint", "input_fingerprint"):
        if mapping.get(key):
            return str(mapping[key])
    return hashlib.sha256(canonical_json(mapping).encode("utf-8")).hexdigest()


def _explanation(query: DoctorQuery, *, source_result: Any, result_family: str, source_contract: str, stage_results: Mapping[str, Any]) -> Any:
    source = _as_dict(source_result)
    trace = source.get("trace") or ()
    query_type = {
        "CAPABILITY": "EXPLAIN_CAPABILITY",
        "THREAD": "EXPLAIN_THREAD_RESULT",
        "ACTION": "EXPLAIN_ACTION_RESULT",
    }[result_family if result_family in {"CAPABILITY", "THREAD", "ACTION"} else "ACTION"]
    stage_contracts = _stage_contracts(stage_results)
    registry_versions = {
        key: value
        for key, value in (
            ("capability_registry_version", _read(source_result, "capability_registry_version")),
            ("thread_rules_version", _read(source_result, "thread_rules_version")),
            ("authority_rules_version", _read(source_result, "authority_rules_version")),
            ("object_preconditions_version", _read(source_result, "object_preconditions_version")),
            ("mfa_rules_version", _read(source_result, "mfa_rules_version")),
            ("action_rules_version", _read(source_result, "action_rules_version")),
        )
        if value
    }
    mapping = {
        "query_id": f"DOCTOR-{query.query_id}",
        "query_type": query_type,
        "result_family": result_family,
        "source_contract": source_contract,
        "source_result": source,
        "source_trace": trace,
        "guild_id": query.guild_id,
        "subject_id": query.subject_id,
        "actor_id": query.actor_id,
        "target_type": query.target_type,
        "target_id": query.target_id,
        "context_id": query.context_id,
        "context_type": query.context_type,
        "thread_id": query.thread_id,
        "thread_type": query.thread_type,
        "source_stage3_contract_versions": stage_contracts,
        "registry_versions": registry_versions,
        "permission_definition_version": query.permission_definition_version,
        "completeness_state": _read(source_result, "analysis_completeness", _read(source_result, "completeness_state")),
        "evidence_classifications": query.evidence_classifications or ("SYNTHETIC_DOCTOR_QUERY",),
        "verification_statuses": query.verification_statuses or ("SYNTHETIC_DOCTOR_QUERY",),
        "source_references": query.source_references,
        "explanation_mode": query.explanation_mode,
        "presentation_profile": query.presentation_profile,
        "output_format": query.output_format,
        "labels": thaw(query.labels) or {},
        "authoritative_closure": thaw(query.authoritative_closure),
        "historical_evidence": thaw(query.historical_evidence),
    }
    return orchestrate_explanation(mapping)


def _invalid_case(query: DoctorQuery, errors: Sequence[str]) -> DoctorExecution:
    actual = {"result_state": "UNKNOWN", "source_result": None, "decision_basis": "VALIDATION_FAILED"}
    answer = {
        "direct_answer": "The Doctor query is invalid and no diagnostic result was produced.",
        "primary_reason": sorted(errors)[0] if errors else "QUERY_INVALID",
        "causal_chain": (),
        "source_locations": (),
        "material_uncertainty_retained": True,
    }
    case = build_doctor_case(
        query,
        premise_alignment="UNKNOWN",
        actual_result=actual,
        diagnostic_answer=answer,
        explanation=None,
        provenance={"validation_only": True, "stage_results": {}},
        integrity={"snapshot_unchanged": True, "source_objects_unchanged": True},
        status="INVALID",
        errors=tuple(errors),
    )
    return DoctorExecution(case=case, stage_results={})


def execute_doctor_query(query: DoctorQuery | Mapping[str, Any], *, strict: bool = False) -> DoctorExecution:
    """Run one deterministic Doctor query over immutable supplied data."""

    try:
        parsed = query if isinstance(query, DoctorQuery) else DoctorQuery.from_mapping(query)
    except (DoctorQueryError, TypeError, ValueError) as exc:
        parsed = DoctorQuery("invalid", "WHY_UNKNOWN", "CAPABILITY", "", "1", "1")
        result = _invalid_case(parsed, (f"QUERY_CONSTRUCTION:{exc}",))
        if strict:
            raise DoctorEngineError(str(exc))
        return result
    violations = validate_doctor_query(parsed)
    if violations:
        result = _invalid_case(parsed, violations)
        if strict:
            raise DoctorEngineError("; ".join(violations))
        return result

    snapshot = _snapshot(parsed)
    before = canonical_json(_as_dict(snapshot))
    actor = _member(parsed, snapshot, parsed.actor_id or parsed.subject_id)
    target = parsed.target_record if parsed.target_record is not None else _find(_members(snapshot) if parsed.target_type == "MEMBER" else _roles(snapshot) if parsed.target_type == "ROLE" else _channels(snapshot) if parsed.target_type == "CHANNEL" else _threads(snapshot) if parsed.target_type == "THREAD" else None, parsed.target_id)
    pass1 = _pass1(parsed, snapshot, member=_member(parsed, snapshot, parsed.subject_id))
    pass2 = _pass2(parsed, snapshot, pass1)
    pass3 = _pass3(parsed, snapshot, pass2, pass1, _member(parsed, snapshot, parsed.subject_id))
    pass4 = None
    pass5 = None
    pass6 = None
    if parsed.context_type in {"PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"} or parsed.target_type == "THREAD" or parsed.thread_id:
        pass4 = _pass4(parsed, snapshot, pass1, pass2, pass3, _member(parsed, snapshot, parsed.subject_id))
    if parsed.target_kind == ACTION and parsed.target_key in ACTION_RULES_BY_KEY:
        rule = ACTION_RULES_BY_KEY[parsed.target_key]
        if rule.source_engine in {"COMBINED", "PASS5"}:
            pass5 = _authority(parsed, snapshot, pass1, pass2, pass3, pass4, actor, target)
        pass6 = _action(parsed, snapshot, pass1, pass2, pass3, pass4, pass5)

    selected_thread = _select_thread(pass4, parsed.target_key) if parsed.target_kind == CAPABILITY and pass4 is not None and parsed.context_type in {"PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"} else None
    selected_capability = _select_capability(pass3, parsed.target_key) if parsed.target_kind == CAPABILITY and selected_thread is None else None
    selected_source = pass6 if parsed.target_kind == ACTION else pass4 if selected_thread is not None else pass3
    family = "ACTION" if parsed.target_kind == ACTION else "THREAD" if selected_thread is not None else "CAPABILITY"
    source_contract = _read(selected_source, "pass6_contract_version", _read(selected_source, "engine_contract_version", ""))
    explanation_result = _explanation(parsed, source_result=selected_source, result_family=family, source_contract=source_contract, stage_results={"PASS1": pass1, "PASS2": pass2, "PASS3": pass3, "PASS4": pass4, "PASS5": pass5, "PASS6": pass6}) if selected_source is not None else None
    stage_results = {key: value for key, value in (("PASS1", pass1), ("PASS2", pass2), ("PASS3", pass3), ("PASS4", pass4), ("PASS5", pass5), ("PASS6", pass6)) if value is not None}
    state = _result_state(parsed, capability_record=selected_capability, thread_record=selected_thread, action_result=pass6)
    reasons = material_reasons(pass6 if parsed.target_kind == ACTION else selected_source, selected_record=selected_capability or selected_thread)
    alignment = align_premise(parsed.query_intent, state)
    answer = {
        "direct_answer": direct_answer(parsed.query_intent, parsed.target_key, state, reasons),
        "primary_reason": primary_reason(reasons, state),
        "causal_chain": causal_chain(family, stage_results=stage_results, selected_record=selected_capability or selected_thread),
        "source_locations": source_locations(family, query=parsed, stage_results=stage_results),
        "blocking_sources": list(reasons["blocking"]),
        "ineffective_grants": list(reasons["ineffective"]),
        "dependencies": list(reasons["uncertain"]),
        "missing_evidence": list(reasons["missing"]),
        "material_uncertainty_retained": bool(reasons["uncertain"] or reasons["missing"] or state == "UNKNOWN"),
        "pre_execution_disclaimer_retained": bool(parsed.target_kind == ACTION),
        "no_recommendations": True,
        "rule_id": RULE_PREMISE_ALIGNMENT,
    }
    after = canonical_json(_as_dict(snapshot))
    explanation_dict = explanation_result.as_dict() if explanation_result is not None else None
    integrity = {
        "snapshot_unchanged": before == after,
        "member_input_unchanged": True,
        "stage3_results_unchanged": True,
        "stage4_outputs_unchanged": bool(explanation_result is None or explanation_result.source_objects_unchanged),
        "registry_objects_unchanged": True,
        "source_objects_unchanged": before == after,
    }
    provenance = {
        "query_fingerprint": hashlib.sha256(canonical_json(parsed.as_dict(include_source=False)).encode("utf-8")).hexdigest(),
        "snapshot_fingerprint": _read(snapshot, "snapshot_fingerprint_sha256", _read(snapshot, "structural_fingerprint_sha256", None)),
        "stage_result_fingerprints": {key: _stage_fingerprint(value) for key, value in stage_results.items()},
        "trace_fingerprints": {key: _stage_fingerprint({"trace": _read(value, "trace", ())}) for key, value in stage_results.items()},
        "source_stage3_contract_versions": _stage_contracts(stage_results),
        "registry_versions": dict(EXPECTED_REGISTRY_VERSIONS),
        "evidence_classifications": list(parsed.evidence_classifications or ("SYNTHETIC_DOCTOR_QUERY",)),
        "verification_statuses": list(parsed.verification_statuses or ("SYNTHETIC_DOCTOR_QUERY",)),
    }
    actual = {
        "result_family": family,
        "result_state": state,
        "source_result": _as_dict(selected_source),
        "selected_record": _as_dict(selected_capability or selected_thread),
        "decision_basis": _read(pass6, "decision_basis", "STAGE3_AUTHORITATIVE_RESULT"),
        "completeness": _read(selected_source, "analysis_completeness", _read(selected_source, "completeness_state", "UNKNOWN")),
        "bypass_state": _read(pass1, "bypass_state"),
        "raw_permission_bits_unchanged": all(_read(value, "raw_permission_bits_unchanged", True) is not False for value in stage_results.values()),
    }
    case = build_doctor_case(
        parsed,
        premise_alignment=alignment,
        actual_result=actual,
        diagnostic_answer=answer,
        explanation=explanation_dict,
        provenance=provenance,
        integrity=integrity,
        status="PASS",
        warnings=tuple(getattr(explanation_result, "warnings", ()) if explanation_result is not None else ()),
    )
    return DoctorExecution(case=case, stage_results=stage_results)


def diagnose(query: DoctorQuery | Mapping[str, Any], *, strict: bool = False) -> DoctorCase:
    return execute_doctor_query(query, strict=strict).case


evaluate_doctor_query = execute_doctor_query
run_doctor_query = execute_doctor_query


__all__ = [
    "DoctorEngineError",
    "DoctorExecution",
    "diagnose",
    "evaluate_doctor_query",
    "execute_doctor_query",
    "run_doctor_query",
]
