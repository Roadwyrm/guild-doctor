"""Versioned object-precondition definitions for Stage 3 Pass 5."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .authority_registry import CHANNEL_SOURCE_URL, GUILD_SOURCE_URL, PERMISSION_SOURCE_URL

OBJECT_PRECONDITIONS_VERSION = "GUILD-DOCTOR-OBJECT-PRECONDITIONS-0.1"


@dataclass(frozen=True, slots=True)
class ObjectPreconditionDefinition:
    key: str
    rule_id: str
    applies_to: tuple[str, ...]
    verification_status: str
    source_references: tuple[str, ...]
    notes: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "rule_id": self.rule_id,
            "applies_to": list(self.applies_to),
            "verification_status": self.verification_status,
            "source_references": list(self.source_references),
            "notes": self.notes,
        }


OBJECT_PRECONDITIONS: tuple[ObjectPreconditionDefinition, ...] = tuple(
    sorted(
        (
            ObjectPreconditionDefinition("target_owner_protection", "DEP-TARGET-OWNER-001", ("member.kick", "member.ban", "nickname.manage_other", "member.timeout"), "VERIFIED", (PERMISSION_SOURCE_URL, GUILD_SOURCE_URL), "Guild-owner targets are protected for these operations."),
            ObjectPreconditionDefinition("target_administrator_timeout_protection", "DEP-TARGET-ADMIN-TIMEOUT-001", ("member.timeout",), "VERIFIED", (PERMISSION_SOURCE_URL,), "Administrator targets are protected from timeout analysis."),
            ObjectPreconditionDefinition("managed_role", "DEP-MANAGED-ROLE-001", ("role.edit", "role.delete", "role.permission_change", "role.reorder"), "VERIFIED", (PERMISSION_SOURCE_URL, GUILD_SOURCE_URL), "Managed integration-controlled roles are not ordinary editable roles."),
            ObjectPreconditionDefinition("everyone_role", "DEP-EVERYONE-ROLE-001", ("role.edit", "role.delete", "role.permission_change", "role.reorder"), "VERIFIED", (PERMISSION_SOURCE_URL, GUILD_SOURCE_URL), "The @everyone role is not an ordinary editable target."),
            ObjectPreconditionDefinition("proposed_role_position", "DEP-ROLE-POSITION-001", ("role.create", "role.reorder"), "VERIFIED", (PERMISSION_SOURCE_URL,), "A new or moved role must remain strictly below the actor highest role."),
            ObjectPreconditionDefinition("voice_connection", "DEP-VOICE-CONNECTION-001", ("voice.member_move", "voice.member_mute", "voice.member_deafen"), "VERIFIED", (CHANNEL_SOURCE_URL,), "Voice object operations require explicit target connection state."),
            ObjectPreconditionDefinition("voice_authority", "DEP-VOICE-AUTHORITY-001", ("voice.member_move",), "NEEDS_TEST", (PERMISSION_SOURCE_URL, CHANNEL_SOURCE_URL), "Source and destination connection authority are supplied evidence; target hierarchy remains unresolved."),
            ObjectPreconditionDefinition("target_member_hierarchy", "DEP-TARGET-MEMBER-HIERARCHY-NEEDS-TEST", ("member.role_assign", "member.role_remove"), "NEEDS_TEST", (PERMISSION_SOURCE_URL,), "The target-member interaction for role assignment/removal remains explicitly unresolved."),
            ObjectPreconditionDefinition("context_consistency", "DEP-CONTEXT-CONSISTENCY-001", ("channel.manage", "overwrite.permission_change"), "VERIFIED", (CHANNEL_SOURCE_URL,), "Guild, parent, target, and overwrite context identifiers must agree."),
        ),
        key=lambda item: item.key,
    )
)

OBJECT_PRECONDITIONS_BY_KEY = {item.key: item for item in OBJECT_PRECONDITIONS}


def validate_object_preconditions() -> tuple[str, ...]:
    reasons: list[str] = []
    keys = [item.key for item in OBJECT_PRECONDITIONS]
    if len(keys) != len(set(keys)):
        reasons.append("DUPLICATE_OBJECT_PRECONDITION_KEY")
    if any(not item.key or not item.rule_id or not item.applies_to for item in OBJECT_PRECONDITIONS):
        reasons.append("MALFORMED_OBJECT_PRECONDITION")
    if OBJECT_PRECONDITIONS_VERSION != "GUILD-DOCTOR-OBJECT-PRECONDITIONS-0.1":
        reasons.append("OBJECT_PRECONDITIONS_VERSION_MISMATCH")
    return tuple(sorted(set(reasons)))


__all__ = [
    "OBJECT_PRECONDITIONS", "OBJECT_PRECONDITIONS_BY_KEY", "OBJECT_PRECONDITIONS_VERSION",
    "ObjectPreconditionDefinition", "validate_object_preconditions",
]
