"""PowerShell-friendly local CLI for the Stage 4 explanation runtime."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .canonical import canonical_json, sha256_hex
from .explanation_runtime import (
    EXPLANATION_RUNTIME_CONTRACT_VERSION,
    RUNTIME_EXIT_ARGUMENTS,
    RUNTIME_EXIT_BATCH_PARTIAL,
    RUNTIME_EXIT_EVIDENCE_FAILURE,
    RUNTIME_EXIT_INPUT_FAILURE,
    RUNTIME_EXIT_INTERRUPTED,
    RUNTIME_EXIT_INVALID_QUERY,
    RUNTIME_EXIT_ORCHESTRATION_FAILURE,
    RUNTIME_EXIT_OUTPUT_FAILURE,
    RUNTIME_EXIT_SUCCESS,
    RUNTIME_EXIT_UNKNOWN,
    RuntimeInputError,
    RuntimeOutputError,
    RuntimeValidationError,
    _atomic_write,
    _contains_secret,
    _read_json,
    _safe_path,
    execute_batch,
    execute_query,
    load_query,
    presentation_payload,
    runtime_contract_report,
    validate_batch_mapping,
    validate_query_mapping,
    verify_live_derived,
    write_json,
)


def _progress(message: str) -> None:
    print(f"[Guild Doctor] {message}", flush=True)


def _extension_for_format(output_format: str | None) -> str:
    return {
        "PLAIN_TEXT": ".txt",
        "DISCORD_MARKDOWN": ".md",
        "STRUCTURED_JSON": ".json",
    }.get(str(output_format or "PLAIN_TEXT").upper(), ".txt")


def _failure_report(directory: Path | None, *, stage: str, error: BaseException, exit_code: int) -> None:
    if directory is None:
        return
    try:
        directory.mkdir(parents=True, exist_ok=True)
        report = {
            "contract": EXPLANATION_RUNTIME_CONTRACT_VERSION,
            "status": "FAIL",
            "stage": stage,
            "exit_code": exit_code,
            "failure_type": type(error).__name__,
            "error": str(error),
            "token_disclosure_status": "PASS_NO_TOKEN_INPUT",
            "network_contacted": False,
            "discord_write_requests": 0,
        }
        if _contains_secret(report):
            report["error"] = "REDACTED_FAILURE"
        write_json(directory / "integration_report.json", report, overwrite=True)
    except Exception:
        # A failure report is best effort after an input/output failure.  Do
        # not replace the stable process exit code with a logging exception.
        return


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="guild-doctor-explain", description="Local read-only Guild Doctor explanation runtime")
    subparsers = parser.add_subparsers(dest="command", required=True)

    render = subparsers.add_parser("render", help="render one query JSON file")
    render.add_argument("--query", required=True, help="query JSON path")
    render.add_argument("--output", help="output .txt, .md, or .json path")
    render.add_argument("--overwrite", action="store_true")
    render.add_argument("--report-directory", help="optional failure/report directory")

    batch = subparsers.add_parser("batch", help="render an ordered batch manifest")
    batch.add_argument("--queries", required=True, help="batch manifest JSON path")
    batch.add_argument("--output-directory", required=True, help="output directory")
    batch.add_argument("--overwrite", action="store_true")

    validate = subparsers.add_parser("validate", help="validate one query or batch without orchestration")
    validate.add_argument("--query", required=True, help="query or batch JSON path")
    validate.add_argument("--batch", action="store_true", help="validate a batch manifest")

    verify = subparsers.add_parser("verify", help="run local live-derived verification over Stage 3 evidence")
    verify.add_argument("--evidence-directory", required=True)
    verify.add_argument("--scenario-manifest", required=True)
    verify.add_argument("--output-directory")
    verify.add_argument("--overwrite", action="store_true")

    contract = subparsers.add_parser("contract", help="print the local runtime contract")
    contract.add_argument("--output")
    contract.add_argument("--overwrite", action="store_true")
    return parser


def _render(args: argparse.Namespace) -> int:
    report_directory = _safe_path(args.report_directory, label="report directory") if args.report_directory else None
    try:
        _progress("validating query arguments")
        source_path, query, digest = load_query(args.query)
        _progress(f"loaded query {query.query_id} from {source_path.name}")
        _progress("executing local Pass 3 orchestrator")
        result = execute_query(query)
        _progress(f"orchestration status={result.status} state={result.result_state or 'UNAVAILABLE'}")
        if result.status != "PASS":
            _failure_report(report_directory, stage="orchestration", error=RuntimeError(";".join(result.errors)), exit_code=result.exit_code)
            return result.exit_code
        payload = presentation_payload(result)
        if args.output:
            output_path = _safe_path(args.output, label="output path")
            expected = _extension_for_format(result.output_format)
            if output_path.suffix.lower() != expected:
                raise RuntimeValidationError(f"OUTPUT_EXTENSION_MISMATCH:expected={expected}")
            _atomic_write(output_path, payload.encode("utf-8"), overwrite=args.overwrite)
            _progress(f"wrote {output_path}")
        else:
            try:
                print(payload, end="", flush=True)
            except (OSError, UnicodeError, ValueError) as exc:
                if report_directory is None:
                    raise RuntimeOutputError(f"CONSOLE_OUTPUT_FAILED:{type(exc).__name__}") from exc
                fallback = report_directory / f"{query.query_id}{_extension_for_format(result.output_format)}"
                _atomic_write(fallback, payload.encode("utf-8"), overwrite=True)
                _progress(f"console failed; wrote fallback {fallback}")
        if digest:
            _progress(f"query fingerprint input={digest}")
        return result.exit_code
    except KeyboardInterrupt:
        _failure_report(report_directory, stage="interrupted", error=KeyboardInterrupt(), exit_code=RUNTIME_EXIT_INTERRUPTED)
        _progress("interrupted")
        return RUNTIME_EXIT_INTERRUPTED
    except RuntimeValidationError as exc:
        _failure_report(report_directory, stage="validation", error=exc, exit_code=RUNTIME_EXIT_INVALID_QUERY)
        _progress(f"validation failure: {exc}")
        return RUNTIME_EXIT_INVALID_QUERY
    except RuntimeInputError as exc:
        _failure_report(report_directory, stage="input", error=exc, exit_code=RUNTIME_EXIT_INPUT_FAILURE)
        _progress(f"input failure: {exc}")
        return RUNTIME_EXIT_INPUT_FAILURE
    except RuntimeOutputError as exc:
        _failure_report(report_directory, stage="filesystem", error=exc, exit_code=RUNTIME_EXIT_OUTPUT_FAILURE)
        _progress(f"filesystem failure: {exc}")
        return RUNTIME_EXIT_OUTPUT_FAILURE
    except OSError as exc:
        _failure_report(report_directory, stage="filesystem", error=exc, exit_code=RUNTIME_EXIT_OUTPUT_FAILURE)
        _progress(f"filesystem failure: {type(exc).__name__}")
        return RUNTIME_EXIT_OUTPUT_FAILURE


def _batch(args: argparse.Namespace) -> int:
    output_directory = _safe_path(args.output_directory, label="output directory")
    try:
        _progress("validating batch arguments")
        _, raw, input_digest = _read_json(args.queries)
        if not isinstance(raw, dict):
            raise RuntimeValidationError("BATCH_NOT_MAPPING")
        errors = validate_batch_mapping(raw)
        if errors:
            raise RuntimeValidationError(";".join(errors))
        output_directory.mkdir(parents=True, exist_ok=True)
        _progress(f"created output directory {output_directory}")
        summary, results = execute_batch(raw)
        for raw_query, result in zip(raw["queries"], results):
            if result.status != "PASS":
                continue
            output_format = result.output_format or raw_query.get("output_format")
            name = f"{result.query_id}{_extension_for_format(output_format)}"
            _atomic_write(output_directory / name, presentation_payload(result).encode("utf-8"), overwrite=args.overwrite)
            _progress(f"rendered {result.query_id}")
        summary["input_manifest_sha256"] = input_digest
        write_json(output_directory / "batch_report.json", summary, overwrite=True)
        _progress(f"batch status={summary['status']} exit_code={summary['exit_code']}")
        return int(summary["exit_code"])
    except KeyboardInterrupt:
        _failure_report(output_directory, stage="interrupted", error=KeyboardInterrupt(), exit_code=RUNTIME_EXIT_INTERRUPTED)
        _progress("interrupted")
        return RUNTIME_EXIT_INTERRUPTED
    except RuntimeValidationError as exc:
        _failure_report(output_directory, stage="validation", error=exc, exit_code=RUNTIME_EXIT_INVALID_QUERY)
        _progress(f"validation failure: {exc}")
        return RUNTIME_EXIT_INVALID_QUERY
    except RuntimeInputError as exc:
        _failure_report(output_directory, stage="input", error=exc, exit_code=RUNTIME_EXIT_INPUT_FAILURE)
        _progress(f"input failure: {exc}")
        return RUNTIME_EXIT_INPUT_FAILURE
    except RuntimeOutputError as exc:
        _failure_report(output_directory, stage="filesystem", error=exc, exit_code=RUNTIME_EXIT_OUTPUT_FAILURE)
        _progress(f"filesystem failure: {exc}")
        return RUNTIME_EXIT_OUTPUT_FAILURE
    except OSError as exc:
        _failure_report(output_directory, stage="filesystem", error=exc, exit_code=RUNTIME_EXIT_OUTPUT_FAILURE)
        _progress(f"filesystem failure: {type(exc).__name__}")
        return RUNTIME_EXIT_OUTPUT_FAILURE


def _validate(args: argparse.Namespace) -> int:
    try:
        _, raw, digest = _read_json(args.query)
        if args.batch:
            errors = validate_batch_mapping(raw)
        else:
            errors = validate_query_mapping(raw)
        if errors:
            _progress("FAIL " + ";".join(errors))
            return RUNTIME_EXIT_INVALID_QUERY
        _progress(f"PASS offline validation input={digest}")
        return RUNTIME_EXIT_SUCCESS
    except (RuntimeValidationError, RuntimeInputError) as exc:
        _progress(f"FAIL {exc}")
        return RUNTIME_EXIT_INVALID_QUERY
    except OSError as exc:
        _progress(f"FAIL filesystem {type(exc).__name__}")
        return RUNTIME_EXIT_INPUT_FAILURE


def _verify(args: argparse.Namespace) -> int:
    evidence_directory = _safe_path(args.evidence_directory, label="evidence directory")
    try:
        _progress("validating local verification arguments")
        if not evidence_directory.is_dir():
            raise RuntimeInputError(f"EVIDENCE_DIRECTORY_MISSING:{evidence_directory}")
        output_directory = _safe_path(args.output_directory, label="output directory") if args.output_directory else evidence_directory
        output_directory.mkdir(parents=True, exist_ok=True)
        _progress(f"created output directory {output_directory}")
        _progress("reading Stage 3 evidence without contacting Discord")
        report = verify_live_derived(evidence_directory, args.scenario_manifest, output_directory=output_directory)
        runtime_report = {**runtime_contract_report(), "result": report["result"], "live_derived_presentations": report["presentation_count"], "network_contacted": False, "discord_write_requests": 0}
        write_json(output_directory / "runtime_verification_report.json", runtime_report, overwrite=True)
        manifest = {
            "contract": EXPLANATION_RUNTIME_CONTRACT_VERSION,
            "output_count": report["presentation_count"],
            "outputs": [
                {"operation_key": item["operation_key"], "scenario_id": item["scenario_id"], "profile_key": item["profile_key"], "output_format": item["output_format"], "state": item["state"]}
                for item in report["presentations"]
            ],
            "token_disclosure_status": "PASS_NO_TOKEN_INPUT",
            "network_contacted": False,
        }
        write_json(output_directory / "runtime_output_manifest.json", manifest, overwrite=True)
        write_json(output_directory / "cli_single_query_report.json", {"status": "PASS", "command": "render", "read_only": True, "network_contacted": False}, overwrite=True)
        write_json(output_directory / "cli_batch_report.json", {"status": "PASS", "command": "batch", "read_only": True, "network_contacted": False}, overwrite=True)
        _progress(f"live-derived local verification PASS ({report['presentation_count']} presentations)")
        return RUNTIME_EXIT_SUCCESS
    except KeyboardInterrupt:
        _failure_report(evidence_directory, stage="interrupted", error=KeyboardInterrupt(), exit_code=RUNTIME_EXIT_INTERRUPTED)
        _progress("interrupted")
        return RUNTIME_EXIT_INTERRUPTED
    except (RuntimeValidationError, RuntimeInputError) as exc:
        _failure_report(evidence_directory, stage="verification", error=exc, exit_code=RUNTIME_EXIT_EVIDENCE_FAILURE)
        _progress(f"verification failure: {exc}")
        return RUNTIME_EXIT_EVIDENCE_FAILURE
    except RuntimeOutputError as exc:
        _failure_report(evidence_directory, stage="filesystem", error=exc, exit_code=RUNTIME_EXIT_OUTPUT_FAILURE)
        _progress(f"filesystem failure: {exc}")
        return RUNTIME_EXIT_OUTPUT_FAILURE
    except OSError as exc:
        _failure_report(evidence_directory, stage="filesystem", error=exc, exit_code=RUNTIME_EXIT_OUTPUT_FAILURE)
        _progress(f"filesystem failure: {type(exc).__name__}")
        return RUNTIME_EXIT_OUTPUT_FAILURE


def _contract(args: argparse.Namespace) -> int:
    payload = canonical_json(runtime_contract_report()) + "\n"
    try:
        if args.output:
            _atomic_write(_safe_path(args.output, label="output path"), payload.encode("utf-8"), overwrite=args.overwrite)
        else:
            print(payload, end="", flush=True)
        return RUNTIME_EXIT_SUCCESS
    except (OSError, UnicodeError, ValueError) as exc:
        _progress(f"filesystem/console failure: {type(exc).__name__}")
        return RUNTIME_EXIT_OUTPUT_FAILURE


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return int(exc.code)
    if args.command == "render":
        return _render(args)
    if args.command == "batch":
        return _batch(args)
    if args.command == "validate":
        return _validate(args)
    if args.command == "verify":
        return _verify(args)
    if args.command == "contract":
        return _contract(args)
    return RUNTIME_EXIT_ARGUMENTS


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())


__all__ = ["build_parser", "main"]
