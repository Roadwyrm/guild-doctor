"""Pure deterministic evaluation boundary for Stage 6 Pass 6B audit rules."""
from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Final

from .audit_contract import EVALUATION_STATES, scan_private
from .audit_finding import AuditFinding, validate_audit_finding
from .audit_rule_registry import (
    AUDIT_RULES,
    PASS6B_IMPLEMENTATION_CONTRACT,
    AuditRuleDefinition,
    registry_fingerprint,
    validate_audit_rule_registry,
)
from .audit_rules_initial import AuditRuleInputError, EVALUATORS, RuleEvaluation
from .canonical import sha256_hex
from .constants import SCANNER_CONTRACT_VERSION, SNAPSHOT_SCHEMA_VERSION


AUDIT_RULE_EVALUATOR_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS6B-PURE-EVALUATOR-0.1"
NORMALIZED_INPUT_CONTRACTS: Final[tuple[str, ...]] = (
    SCANNER_CONTRACT_VERSION,
    SNAPSHOT_SCHEMA_VERSION,
)


class AuditEvaluationError(ValueError):
    """Stable top-level evaluator input or contract failure."""


@dataclass(frozen=True, slots=True)
class AuditEvaluationResult:
    snapshot_fingerprint: str
    registry_fingerprint: str
    rule_evaluations: tuple[RuleEvaluation, ...]
    findings: tuple[AuditFinding, ...]
    implementation_contract: str = PASS6B_IMPLEMENTATION_CONTRACT
    evaluator_contract: str = AUDIT_RULE_EVALUATOR_CONTRACT
    normalized_input_contracts: tuple[str, ...] = NORMALIZED_INPUT_CONTRACTS
    no_action: bool = True
    no_write: bool = True
    result_fingerprint: str = ""

    def __post_init__(self) -> None:
        if self.no_action is not True or self.no_write is not True:
            raise AuditEvaluationError("AUDIT_EVALUATION_READ_ONLY_REQUIRED")
        if self.registry_fingerprint != registry_fingerprint():
            raise AuditEvaluationError("AUDIT_EVALUATION_REGISTRY_FINGERPRINT_MISMATCH")
        if len(self.rule_evaluations) != len(AUDIT_RULES):
            raise AuditEvaluationError("AUDIT_EVALUATION_RULE_COUNT_INVALID")
        expected_order = tuple(rule.rule_id for rule in AUDIT_RULES)
        if tuple(item.rule_id for item in self.rule_evaluations) != expected_order:
            raise AuditEvaluationError("AUDIT_EVALUATION_RULE_ORDER_INVALID")
        expected_findings = tuple(sorted(self.findings, key=lambda item: item.stable_sort_key))
        if self.findings != expected_findings:
            raise AuditEvaluationError("AUDIT_EVALUATION_FINDING_ORDER_INVALID")
        payload = self._payload(include_fingerprint=False)
        if scan_private(payload, "audit_evaluation"):
            raise AuditEvaluationError("AUDIT_EVALUATION_PRIVATE_DATA_FORBIDDEN")
        expected = sha256_hex(payload)
        if self.result_fingerprint and self.result_fingerprint != expected:
            raise AuditEvaluationError("AUDIT_EVALUATION_FINGERPRINT_MISMATCH")
        object.__setattr__(self, "result_fingerprint", expected)

    def _payload(self, *, include_fingerprint: bool) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "implementation_contract": self.implementation_contract,
            "evaluator_contract": self.evaluator_contract,
            "normalized_input_contracts": list(self.normalized_input_contracts),
            "snapshot_fingerprint": self.snapshot_fingerprint,
            "registry_fingerprint": self.registry_fingerprint,
            "rule_evaluations": [item.as_dict() for item in self.rule_evaluations],
            "findings": [finding.as_dict() for finding in self.findings],
            "no_action": self.no_action,
            "no_write": self.no_write,
        }
        if include_fingerprint:
            payload["result_fingerprint"] = self.result_fingerprint
        return payload

    def as_dict(self) -> dict[str, Any]:
        return self._payload(include_fingerprint=True)


def _snapshot_payload(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    payload = {str(key): value for key, value in snapshot.items()}
    schema = payload.get("schema_version")
    if schema is not None and schema != SNAPSHOT_SCHEMA_VERSION:
        raise AuditEvaluationError("AUDIT_SNAPSHOT_SCHEMA_UNSUPPORTED")
    scanner = payload.get("scanner_contract_version")
    if scanner is not None and scanner != SCANNER_CONTRACT_VERSION:
        raise AuditEvaluationError("AUDIT_SCANNER_CONTRACT_UNSUPPORTED")
    return payload


def _fingerprint_snapshot(payload: Mapping[str, Any]) -> str:
    """Fingerprint normalized entity sets without treating source list order as data."""
    def normalize(value: Any, key: str | None = None) -> Any:
        if isinstance(value, Mapping):
            return {str(child_key): normalize(child, str(child_key)) for child_key, child in sorted(value.items(), key=lambda item: str(item[0]))}
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            items = [normalize(child) for child in value]
            if key in {"roles", "channels", "threads", "members", "thread_memberships"}:
                items.sort(key=lambda child: str(child.get("id", "")) if isinstance(child, Mapping) else "")
            elif key == "permission_overwrites":
                items.sort(key=lambda child: (str(child.get("target_type", child.get("type", ""))), str(child.get("target_id", child.get("id", "")))) if isinstance(child, Mapping) else ("", ""))
            return items
        return value

    return sha256_hex(normalize(payload))


def _classified_rule_failure(rule: AuditRuleDefinition, exc: Exception) -> RuleEvaluation:
    if isinstance(exc, AuditRuleInputError):
        code = str(exc)
        if not code.startswith("AUDIT_"):
            code = "AUDIT_RULE_INPUT_INVALID"
    elif isinstance(exc, AuditEvaluationError):
        code = str(exc)
    else:
        code = "AUDIT_RULE_EVALUATION_FAILED"
    return RuleEvaluation(rule.rule_id, "RULE_ERROR", errors=(code,))


def _validate_rule_result(rule: AuditRuleDefinition, result: RuleEvaluation) -> None:
    if not isinstance(result, RuleEvaluation):
        raise AuditEvaluationError("AUDIT_RULE_RESULT_TYPE_INVALID")
    if result.rule_id != rule.rule_id:
        raise AuditEvaluationError("AUDIT_RULE_RESULT_ID_MISMATCH")
    if result.evaluation_state not in EVALUATION_STATES:
        raise AuditEvaluationError("AUDIT_RULE_RESULT_STATE_INVALID")
    for finding in result.findings:
        if finding.rule_id != rule.rule_id:
            raise AuditEvaluationError("AUDIT_RULE_FINDING_ID_MISMATCH")
        errors = validate_audit_finding(finding)
        if errors:
            raise AuditEvaluationError(errors[0])


def _canonical_rule_result(result: RuleEvaluation) -> RuleEvaluation:
    by_fingerprint = {finding.finding_fingerprint: finding for finding in result.findings}
    return RuleEvaluation(
        rule_id=result.rule_id,
        evaluation_state=result.evaluation_state,
        findings=tuple(sorted(by_fingerprint.values(), key=lambda item: item.stable_sort_key)),
        missing_evidence=tuple(sorted(set(result.missing_evidence))),
        errors=tuple(sorted(set(result.errors))),
    )


def evaluate_audit_rules(
    snapshot: Mapping[str, Any],
    *,
    frozen_traces: Sequence[Mapping[str, Any]] = (),
    evaluator_overrides: Mapping[str, Callable[[Mapping[str, Any], Sequence[Mapping[str, Any]]], RuleEvaluation]] | None = None,
) -> AuditEvaluationResult:
    """Evaluate exactly the immutable seven-rule registry over explicit data."""
    if not isinstance(snapshot, Mapping):
        raise AuditEvaluationError("AUDIT_SNAPSHOT_NOT_MAPPING")
    if isinstance(frozen_traces, (str, bytes, bytearray)) or not isinstance(frozen_traces, Sequence):
        raise AuditEvaluationError("AUDIT_TRACE_COLLECTION_INVALID")
    if any(not isinstance(item, Mapping) for item in frozen_traces):
        raise AuditEvaluationError("AUDIT_TRACE_RECORD_INVALID")
    registry_errors = validate_audit_rule_registry()
    if registry_errors:
        raise AuditEvaluationError(registry_errors[0])

    payload = _snapshot_payload(snapshot)
    evaluators = dict(EVALUATORS)
    if evaluator_overrides:
        for key, evaluator in evaluator_overrides.items():
            if key not in evaluators or not callable(evaluator):
                raise AuditEvaluationError("AUDIT_EVALUATOR_OVERRIDE_INVALID")
            evaluators[key] = evaluator

    evaluations: list[RuleEvaluation] = []
    findings: list[AuditFinding] = []
    for rule in AUDIT_RULES:
        evaluator = evaluators.get(rule.evaluator_id)
        if evaluator is None:
            result = RuleEvaluation(rule.rule_id, "RULE_ERROR", errors=("AUDIT_RULE_EVALUATOR_MISSING",))
        else:
            try:
                result = evaluator(payload, frozen_traces)
                _validate_rule_result(rule, result)
                result = _canonical_rule_result(result)
            except Exception as exc:  # each rule fails closed without corrupting siblings
                result = _classified_rule_failure(rule, exc)
        evaluations.append(result)
        findings.extend(result.findings)

    return AuditEvaluationResult(
        snapshot_fingerprint=_fingerprint_snapshot(payload),
        registry_fingerprint=registry_fingerprint(),
        rule_evaluations=tuple(evaluations),
        findings=tuple(sorted(findings, key=lambda item: item.stable_sort_key)),
    )


EVALUATOR_BOUNDARY: Final[MappingProxyType[str, object]] = MappingProxyType({
    "contract": AUDIT_RULE_EVALUATOR_CONTRACT,
    "registry_fingerprint": registry_fingerprint(),
    "normalized_input_contracts": NORMALIZED_INPUT_CONTRACTS,
    "network_access": False,
    "discord_access": False,
    "permission_recalculation": False,
    "writes": False,
})


__all__ = [
    "AUDIT_RULE_EVALUATOR_CONTRACT", "AuditEvaluationError", "AuditEvaluationResult",
    "EVALUATOR_BOUNDARY", "NORMALIZED_INPUT_CONTRACTS", "evaluate_audit_rules",
]
