"""Validated Stage 6 interaction-envelope model seam.

This module is intentionally not wired into transport, callbacks, providers, or
rendering.  It only validates the three response payload branches.
"""
from __future__ import annotations

from dataclasses import dataclass
import re
from collections.abc import Mapping
from typing import Any
from .audit_contract import freeze, scan_report_private
from .action_registry import ACTION_RULES_BY_KEY
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY, KNOWN_PERMISSION_FLAGS
from .doctor_role_comparison_query import ACTION, CAPABILITY, RAW_PERMISSION
from .export_receipt_validation import validate_export_receipt_metadata


INTERACTION_ENVELOPE_CONTRACT = "GUILD-DOCTOR-INTERACTION-ENVELOPE-0.2"
PERMISSION_RESULT = "PERMISSION_RESULT"
COMPARISON_RESULT = "COMPARISON_RESULT"
ERROR_RESULT = "ERROR_RESULT"
REPORT_RESULT = "REPORT_RESULT"
RESPONSE_KINDS = frozenset({PERMISSION_RESULT, COMPARISON_RESULT, ERROR_RESULT, REPORT_RESULT})
COMPARISON_OUTCOMES = frozenset({"NOT_COMPARABLE", "SAME", "DIFFERENT"})
COMPARISON_CONTRACT_ID = "GUILD-DOCTOR-STAGE6-COMPARISON-OUTCOME-0.1"
SUPPORTED_SOURCE_CONTRACTS = frozenset({
    COMPARISON_CONTRACT_ID,
    "GUILD-DOCTOR-STAGE5-ROLE-COMPARISON-QUERY-0.1",
    "GUILD-DOCTOR-ROLE-COMPARISON-QUERY-0.1",
    "GUILD-DOCTOR-STAGE5-PASS3-0.1",
})
ENVELOPE_ERRORS = (
    "STAGE6_COMPARISON_PAYLOAD_INVALID",
    "STAGE6_COMPARISON_CONTRACT_UNSUPPORTED",
    "STAGE6_COMPARISON_FINGERPRINT_INVALID",
    "STAGE6_COMPARISON_ENVELOPE_KIND_INVALID",
    "STAGE6_COMPARISON_ENVELOPE_MULTIPLE_PAYLOADS",
    "STAGE6_COMPARISON_ENVELOPE_PAYLOAD_MISSING",
    "STAGE6_COMPARISON_CONTRACT_MISMATCH",
    "STAGE6_ACTION_CONTEXT_REQUIRED",
    "REPORT_UNAVAILABLE",
    "REPORT_CONTRACT_INVALID",
    "REPORT_FINGERPRINT_MISMATCH",
    "ATLAS_FINGERPRINT_MISMATCH",
    "REPORT_GUILD_INCOMPATIBLE",
    "REPORT_SNAPSHOT_INCOMPATIBLE",
    "REPORT_PROVIDER_RESULT_MISSING",
    "REPORT_SECTION_INVALID",
    "REPORT_CONTINUATION_INVALID",
    "REPORT_PAGINATION_FAILED",
    "REPORT_RESULT_MALFORMED",
    "REPORT_PRIVACY_FAILED",
    "EXPORT_RECEIPT_UNAVAILABLE",
    "EXPORT_PRIVACY_FAILED",
    "EXPORT_TARGET_EXISTS",
    "EXPORT_FILESYSTEM_FAILED",
    "EXPORT_FORMAT_UNSUPPORTED",
    "EXPORT_RECEIPT_REASON_INVALID",
    "EXPORT_RECEIPT_BASENAME_INVALID",
    "EXPORT_RECEIPT_TEMPORARY_BASENAME",
    "EXPORT_RECEIPT_STATUS_MISMATCH",
    "EXPORT_RECEIPT_EXTENSION_MISMATCH",
)
_FINGERPRINT = re.compile(r"^[0-9a-f]{64}$")
_REPORT_CONTRACT = "GUILD-DOCTOR-REPORT-0.1"
_REPORT_STATES = frozenset({
    "COMPLETE", "PARTIAL", "ESTIMATED", "UNKNOWN", "INCOMPLETE",
    "NOT_REQUESTED", "UNAVAILABLE", "FAILED", "UNSUPPORTED",
    "RULE_ERROR", "NOT_APPLICABLE",
})


def _require_bool(name: str, value: Any) -> bool:
    if type(value) is not bool:
        raise ValueError(f"STAGE6_COMPARISON_PAYLOAD_INVALID: {name} must be boolean")
    return value


@dataclass(frozen=True, slots=True)
class ComparisonResultPayload:
    comparison_outcome: str
    comparable: bool
    results_differ: bool | None
    primary_reason: str | None
    case_fingerprint: str
    source_contract_id: str
    source_contract_version: str
    target_kind: str
    target_key: str

    def __post_init__(self) -> None:
        comparable = _require_bool("comparable", self.comparable)
        if self.results_differ is not None:
            _require_bool("results_differ", self.results_differ)
        if self.comparison_outcome not in COMPARISON_OUTCOMES:
            raise ValueError("STAGE6_COMPARISON_PAYLOAD_INVALID: unsupported outcome")
        if not _FINGERPRINT.fullmatch(self.case_fingerprint):
            raise ValueError("STAGE6_COMPARISON_FINGERPRINT_INVALID")
        if self.source_contract_id not in SUPPORTED_SOURCE_CONTRACTS:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_UNSUPPORTED")
        if not self.source_contract_version:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH")
        if not isinstance(self.target_kind, str) or not self.target_kind.strip():
            raise ValueError("STAGE6_COMPARISON_PAYLOAD_INVALID: target_kind missing")
        if not isinstance(self.target_key, str) or not self.target_key.strip():
            raise ValueError("STAGE6_COMPARISON_PAYLOAD_INVALID: target_key missing")
        target_kind = self.target_kind.strip()
        target_key = self.target_key.strip()
        if target_kind not in {RAW_PERMISSION, CAPABILITY, ACTION}:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH: target_kind unsupported")
        if target_kind == RAW_PERMISSION and target_key not in {flag.name for flag in KNOWN_PERMISSION_FLAGS}:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH: raw permission key unregistered")
        if target_kind == CAPABILITY and target_key not in {item.capability_key for item in DEFAULT_CAPABILITY_REGISTRY.capabilities}:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH: capability key unregistered")
        if target_kind == ACTION and target_key not in ACTION_RULES_BY_KEY:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH: action key unregistered")
        object.__setattr__(self, "target_kind", target_kind)
        object.__setattr__(self, "target_key", target_key)
        expected = derive_comparison_outcome(comparable, self.results_differ)
        if self.comparison_outcome != expected:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH")


def derive_comparison_outcome(comparable: bool, results_differ: bool | None) -> str:
    """Apply the frozen comparison precedence without permission semantics."""
    comparable = _require_bool("comparable", comparable)
    if not comparable:
        return "NOT_COMPARABLE"
    if results_differ is None:
        raise ValueError("STAGE6_COMPARISON_PAYLOAD_INVALID: results_differ is required")
    results_differ = _require_bool("results_differ", results_differ)
    return "DIFFERENT" if results_differ else "SAME"


@dataclass(frozen=True, slots=True)
class ErrorResultPayload:
    stable_error: str
    safe_message: str
    correlation_id: str | None = None
    no_action: bool = True
    no_write: bool = True
    action_key: str | None = None

    def __post_init__(self) -> None:
        if self.stable_error not in ENVELOPE_ERRORS:
            raise ValueError("STAGE6_COMPARISON_PAYLOAD_INVALID: unsupported stable error")
        if not self.safe_message or not self.no_action or not self.no_write:
            raise ValueError("STAGE6_COMPARISON_PAYLOAD_INVALID: unsafe error payload")
        if self.action_key is not None and self.action_key not in ACTION_RULES_BY_KEY:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH: action key unregistered")
        if self.stable_error == "STAGE6_ACTION_CONTEXT_REQUIRED" and self.action_key is None:
            raise ValueError("STAGE6_COMPARISON_PAYLOAD_INVALID: action key missing")

@dataclass(frozen=True, slots=True)
class ReportResultPayload:
    """Frozen Pass 5 report-page or export-receipt presentation payload."""

    subtype: str
    report_fingerprint: str
    atlas_fingerprint: str
    source_snapshot_reference: str
    report_contract: str
    section_identifier: str | None = None
    section_ordinal: int | None = None
    section_state: str | None = None
    completeness_state: str | None = None
    page_index: int | None = None
    total_page_count: int | None = None
    total_section_count: int | None = None
    total_section_item_count: int | None = None
    displayed_item_count: int | None = None
    ordered_items: tuple[Mapping[str, Any], ...] = ()
    continuation_identifier: str | None = None
    previous_available: bool | None = None
    next_available: bool | None = None
    safe_provenance: tuple[Mapping[str, Any], ...] = ()
    format: str | None = None
    source_report_fingerprint: str | None = None
    content_fingerprint: str | None = None
    byte_count: int | None = None
    write_status: str | None = None
    replacement_status: str | None = None
    privacy_validation_status: str | None = None
    safe_basename: str | None = None
    stable_reason: str | None = None

    def __post_init__(self) -> None:
        if self.subtype not in {"REPORT_PAGE", "EXPORT_RECEIPT"}:
            raise ValueError("REPORT_RESULT_MALFORMED")
        if not _FINGERPRINT.fullmatch(self.report_fingerprint) or not _FINGERPRINT.fullmatch(self.atlas_fingerprint):
            raise ValueError("REPORT_RESULT_MALFORMED")
        if not _FINGERPRINT.fullmatch(self.source_snapshot_reference):
            raise ValueError("REPORT_RESULT_MALFORMED")
        if self.report_contract != _REPORT_CONTRACT:
            raise ValueError("REPORT_CONTRACT_INVALID")
        object.__setattr__(self, "ordered_items", tuple(freeze(dict(item)) for item in self.ordered_items))
        object.__setattr__(self, "safe_provenance", tuple(freeze(dict(item)) for item in self.safe_provenance))

        if self.subtype == "REPORT_PAGE":
            if scan_report_private(self.as_dict(), "report_result"):
                raise ValueError("REPORT_PRIVACY_FAILED")
            required_text = (self.section_identifier, self.section_state, self.completeness_state, self.continuation_identifier)
            if any(not isinstance(value, str) or not value for value in required_text):
                raise ValueError("REPORT_RESULT_MALFORMED")
            if self.section_state not in _REPORT_STATES or self.completeness_state not in _REPORT_STATES:
                raise ValueError("REPORT_RESULT_MALFORMED")
            counts = (
                self.section_ordinal, self.page_index, self.total_page_count,
                self.total_section_count, self.total_section_item_count,
                self.displayed_item_count,
            )
            if any(type(value) is not int or value < 0 for value in counts):
                raise ValueError("REPORT_RESULT_MALFORMED")
            if self.section_ordinal < 1 or self.page_index < 1 or self.total_page_count < 1 or self.total_section_count < 1:
                raise ValueError("REPORT_RESULT_MALFORMED")
            if self.page_index > self.total_page_count or self.section_ordinal > self.total_section_count:
                raise ValueError("REPORT_RESULT_MALFORMED")
            if self.displayed_item_count != len(self.ordered_items):
                raise ValueError("REPORT_RESULT_MALFORMED")
            if self.displayed_item_count > self.total_section_item_count:
                raise ValueError("REPORT_RESULT_MALFORMED")
            if type(self.previous_available) is not bool or type(self.next_available) is not bool:
                raise ValueError("REPORT_RESULT_MALFORMED")
            if self.previous_available != (self.page_index > 1) or self.next_available != (self.page_index < self.total_page_count):
                raise ValueError("REPORT_RESULT_MALFORMED")
            receipt_values = (
                self.format, self.source_report_fingerprint, self.content_fingerprint,
                self.byte_count, self.write_status, self.replacement_status,
                self.privacy_validation_status, self.safe_basename, self.stable_reason,
            )
            if any(value is not None for value in receipt_values):
                raise ValueError("REPORT_RESULT_MALFORMED")
        else:
            if self.source_report_fingerprint != self.report_fingerprint or not _FINGERPRINT.fullmatch(self.content_fingerprint or ""):
                raise ValueError("REPORT_FINGERPRINT_MISMATCH")
            if type(self.byte_count) is not int or self.byte_count < 0:
                raise ValueError("REPORT_RESULT_MALFORMED")
            receipt_text = (self.write_status, self.replacement_status, self.privacy_validation_status, self.safe_basename, self.stable_reason)
            if any(not isinstance(value, str) or not value for value in receipt_text):
                raise ValueError("REPORT_RESULT_MALFORMED")
            validate_export_receipt_metadata(
                format=self.format,
                write_status=self.write_status,
                replacement_status=self.replacement_status,
                privacy_validation_status=self.privacy_validation_status,
                safe_basename=self.safe_basename,
                stable_reason=self.stable_reason,
            )
            if scan_report_private(self.as_dict(), "report_result"):
                raise ValueError("REPORT_PRIVACY_FAILED")
            page_values = (
                self.section_identifier, self.section_ordinal, self.section_state,
                self.completeness_state, self.page_index, self.total_page_count,
                self.total_section_count, self.total_section_item_count,
                self.displayed_item_count, self.continuation_identifier,
                self.previous_available, self.next_available,
            )
            if any(value is not None for value in page_values) or self.ordered_items or self.safe_provenance:
                raise ValueError("REPORT_RESULT_MALFORMED")

    def as_dict(self) -> dict[str, Any]:
        from .audit_contract import thaw

        return {
            name: thaw(getattr(self, name))
            for name in self.__dataclass_fields__
        }


@dataclass(frozen=True, slots=True)
class InteractionEnvelope:
    response_kind: str
    permission_result: Any = None
    comparison_result: ComparisonResultPayload | None = None
    error_result: ErrorResultPayload | None = None
    report_result: ReportResultPayload | None = None

    def __post_init__(self) -> None:
        if self.response_kind not in RESPONSE_KINDS:
            raise ValueError("STAGE6_COMPARISON_ENVELOPE_KIND_INVALID")
        payloads = tuple(x is not None for x in (
            self.permission_result, self.comparison_result, self.error_result, self.report_result
        ))
        if sum(payloads) == 0:
            raise ValueError("STAGE6_COMPARISON_ENVELOPE_PAYLOAD_MISSING")
        if sum(payloads) > 1:
            raise ValueError("STAGE6_COMPARISON_ENVELOPE_MULTIPLE_PAYLOADS")
        expected = {
            PERMISSION_RESULT: self.permission_result,
            COMPARISON_RESULT: self.comparison_result,
            ERROR_RESULT: self.error_result,
            REPORT_RESULT: self.report_result,
        }[self.response_kind]
        if expected is None:
            raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH")


__all__ = [
    "COMPARISON_CONTRACT_ID", "COMPARISON_OUTCOMES", "COMPARISON_RESULT",
    "ENVELOPE_ERRORS", "ERROR_RESULT", "ErrorResultPayload",
    "InteractionEnvelope", "INTERACTION_ENVELOPE_CONTRACT", "PERMISSION_RESULT",
    "REPORT_RESULT", "ReportResultPayload",
    "RESPONSE_KINDS", "SUPPORTED_SOURCE_CONTRACTS", "ComparisonResultPayload",
    "derive_comparison_outcome",
]
