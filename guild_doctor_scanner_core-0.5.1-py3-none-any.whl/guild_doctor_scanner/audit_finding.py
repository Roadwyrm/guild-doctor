"""Stage 6 Pass 6A immutable finding schema; no audit rules are implemented here."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from .audit_contract import (
    AUDIT_CONFIDENCE,
    AUDIT_FINDING_CONTRACT_VERSION,
    AUDIT_RULES_VERSION,
    AUDIT_SEVERITIES,
    EVALUATION_STATES,
    FINDING_CLASSES,
    FINDING_STATUSES,
    OBJECT_TYPES,
    SAFE_OPTIONS,
    VERIFICATION_LABELS,
    AuditContractError,
    freeze,
    reference_key,
    safe_label,
    scan_private,
    text,
    thaw,
    upper,
)
from .canonical import sha256_hex


def _identifier(name: str, value: Any) -> str:
    result = upper(value) or ""
    import re

    if not re.fullmatch(r"[A-Z][A-Z0-9_.-]{2,127}", result):
        raise AuditContractError(f"AUDIT_FINDING_{name}_INVALID")
    return result


def _string_items(value: Sequence[Any] | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise AuditContractError("AUDIT_FINDING_SEQUENCE_INVALID")
    return tuple(sorted({text(item) for item in value if text(item)}))


@dataclass(frozen=True, slots=True)
class AffectedObjectReference:
    """Internal object identity with a public representation that hides raw IDs."""

    object_type: str
    object_id: str
    safe_label: str | None = None
    source_path: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "object_type", upper(self.object_type) or "")
        object.__setattr__(self, "object_id", text(self.object_id) or "")
        object.__setattr__(self, "safe_label", safe_label(self.safe_label, self.object_type.title() or "Object"))
        object.__setattr__(self, "source_path", text(self.source_path))
        if self.object_type not in OBJECT_TYPES:
            raise AuditContractError("AUDIT_OBJECT_TYPE_UNSUPPORTED")
        if not self.object_id.isdecimal():
            raise AuditContractError("AUDIT_OBJECT_ID_INVALID")
        if self.source_path and scan_private(self.source_path, "affected_object.source_path"):
            raise AuditContractError("AUDIT_OBJECT_SOURCE_PATH_UNSAFE")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "AffectedObjectReference":
        if not isinstance(value, Mapping):
            raise AuditContractError("AUDIT_OBJECT_NOT_MAPPING")
        return cls(
            object_type=value.get("object_type", ""),
            object_id=value.get("object_id", value.get("id", "")),
            safe_label=value.get("safe_label", value.get("label")),
            source_path=value.get("source_path"),
        )

    @property
    def opaque_reference_key(self) -> str:
        return reference_key(object_type=self.object_type, object_id=self.object_id)

    def as_dict(self) -> dict[str, str | None]:
        return {
            "object_type": self.object_type,
            "reference_key": self.opaque_reference_key,
            "safe_label": self.safe_label,
            "source_path": self.source_path,
        }

    def fingerprint_identity(self) -> dict[str, str]:
        return {"object_type": self.object_type, "object_id": self.object_id}


@dataclass(frozen=True, slots=True)
class EvidenceReference:
    """Safe field/trace provenance; values and object identifiers are excluded."""

    source_type: str
    source_contract: str
    field_path: str
    source_fingerprint: str | None = None
    trace_event_reference: str | None = None

    def __post_init__(self) -> None:
        for field_name in ("source_type", "source_contract", "field_path"):
            object.__setattr__(self, field_name, text(getattr(self, field_name)) or "")
        object.__setattr__(self, "source_fingerprint", text(self.source_fingerprint))
        object.__setattr__(self, "trace_event_reference", text(self.trace_event_reference))
        if not self.source_type or not self.source_contract or not self.field_path:
            raise AuditContractError("AUDIT_EVIDENCE_REFERENCE_MISSING")
        if scan_private(self.as_dict(), "evidence_reference"):
            raise AuditContractError("AUDIT_EVIDENCE_REFERENCE_UNSAFE")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "EvidenceReference":
        if not isinstance(value, Mapping):
            raise AuditContractError("AUDIT_EVIDENCE_REFERENCE_NOT_MAPPING")
        return cls(
            source_type=value.get("source_type", ""),
            source_contract=value.get("source_contract", ""),
            field_path=value.get("field_path", ""),
            source_fingerprint=value.get("source_fingerprint"),
            trace_event_reference=value.get("trace_event_reference"),
        )

    def as_dict(self) -> dict[str, str | None]:
        return {
            "source_type": self.source_type,
            "source_contract": self.source_contract,
            "field_path": self.field_path,
            "source_fingerprint": self.source_fingerprint,
            "trace_event_reference": self.trace_event_reference,
        }


@dataclass(frozen=True, slots=True)
class AuditFinding:
    """One deterministic, read-only audit result.

    This is a schema and validation boundary. Future Pass 6B rules will create
    findings; this module does not inspect permissions or evaluate a server.
    """

    finding_id: str
    rule_id: str
    title: str
    finding_class: str
    severity: str
    confidence: str
    verification_label: str
    evaluation_state: str
    completeness_state: str
    affected_objects: tuple[AffectedObjectReference, ...]
    observed_condition: Mapping[str, Any]
    practical_importance: str
    evidence_references: tuple[EvidenceReference, ...]
    causal_trace_references: tuple[EvidenceReference, ...]
    missing_evidence: tuple[str, ...]
    beginner_explanation: str
    technical_explanation: str
    safe_options: tuple[str, ...]
    tradeoffs: tuple[str, ...]
    duplicate_grouping_key: str
    status: str
    finding_contract_version: str = AUDIT_FINDING_CONTRACT_VERSION
    rule_registry_version: str = AUDIT_RULES_VERSION
    no_action: bool = True
    no_write: bool = True
    finding_fingerprint: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "finding_id", _identifier("ID", self.finding_id))
        object.__setattr__(self, "rule_id", _identifier("RULE_ID", self.rule_id))
        object.__setattr__(self, "title", safe_label(self.title, "Audit finding"))
        for field_name, allowed in (
            ("finding_class", FINDING_CLASSES),
            ("severity", AUDIT_SEVERITIES),
            ("confidence", AUDIT_CONFIDENCE),
            ("verification_label", VERIFICATION_LABELS),
            ("evaluation_state", EVALUATION_STATES),
            ("status", FINDING_STATUSES),
        ):
            value = upper(getattr(self, field_name)) or ""
            object.__setattr__(self, field_name, value)
            if value not in allowed:
                raise AuditContractError(f"AUDIT_FINDING_{field_name.upper()}_INVALID")
        object.__setattr__(self, "completeness_state", upper(self.completeness_state) or "UNKNOWN")
        objects = tuple(sorted(self.affected_objects, key=lambda item: (item.object_type, item.object_id)))
        object.__setattr__(self, "affected_objects", objects)
        evidence = tuple(sorted(self.evidence_references, key=lambda item: (item.source_type, item.source_contract, item.field_path, item.trace_event_reference or "")))
        traces = tuple(sorted(self.causal_trace_references, key=lambda item: (item.source_type, item.source_contract, item.field_path, item.trace_event_reference or "")))
        object.__setattr__(self, "evidence_references", evidence)
        object.__setattr__(self, "causal_trace_references", traces)
        object.__setattr__(self, "observed_condition", freeze(dict(self.observed_condition)))
        object.__setattr__(self, "missing_evidence", _string_items(self.missing_evidence))
        object.__setattr__(self, "beginner_explanation", safe_label(self.beginner_explanation, "Evidence requires review."))
        object.__setattr__(self, "technical_explanation", safe_label(self.technical_explanation, "Audit contract evidence is incomplete."))
        options = _string_items(self.safe_options)
        if any(item not in SAFE_OPTIONS for item in options):
            raise AuditContractError("AUDIT_FINDING_SAFE_OPTION_UNSUPPORTED")
        object.__setattr__(self, "safe_options", options)
        object.__setattr__(self, "tradeoffs", _string_items(self.tradeoffs))
        object.__setattr__(self, "duplicate_grouping_key", _identifier("GROUPING_KEY", self.duplicate_grouping_key))
        if self.finding_contract_version != AUDIT_FINDING_CONTRACT_VERSION:
            raise AuditContractError("AUDIT_FINDING_CONTRACT_UNSUPPORTED")
        if self.rule_registry_version != AUDIT_RULES_VERSION:
            raise AuditContractError("AUDIT_RULE_REGISTRY_UNSUPPORTED")
        if self.no_action is not True or self.no_write is not True:
            raise AuditContractError("AUDIT_FINDING_READ_ONLY_REQUIRED")
        if scan_private(self._public_payload(include_fingerprint=False), "finding"):
            raise AuditContractError("AUDIT_FINDING_PRIVATE_DATA_FORBIDDEN")
        expected = sha256_hex(self._fingerprint_payload())
        if self.finding_fingerprint and self.finding_fingerprint != expected:
            raise AuditContractError("AUDIT_FINDING_FINGERPRINT_MISMATCH")
        object.__setattr__(self, "finding_fingerprint", expected)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "AuditFinding":
        if not isinstance(value, Mapping):
            raise AuditContractError("AUDIT_FINDING_NOT_MAPPING")
        objects = value.get("affected_objects", value.get("affected_object_references", ()))
        evidence = value.get("evidence_references", ())
        traces = value.get("causal_trace_references", ())
        if not isinstance(objects, Sequence) or isinstance(objects, (str, bytes, bytearray)):
            raise AuditContractError("AUDIT_FINDING_OBJECTS_INVALID")
        if not isinstance(evidence, Sequence) or isinstance(evidence, (str, bytes, bytearray)):
            raise AuditContractError("AUDIT_FINDING_EVIDENCE_INVALID")
        if not isinstance(traces, Sequence) or isinstance(traces, (str, bytes, bytearray)):
            raise AuditContractError("AUDIT_FINDING_TRACE_INVALID")
        return cls(
            finding_id=value.get("finding_id", ""),
            rule_id=value.get("rule_id", ""),
            title=value.get("title", ""),
            finding_class=value.get("finding_class", ""),
            severity=value.get("severity", ""),
            confidence=value.get("confidence", ""),
            verification_label=value.get("verification_label", ""),
            evaluation_state=value.get("evaluation_state", ""),
            completeness_state=value.get("completeness_state", "UNKNOWN"),
            affected_objects=tuple(item if isinstance(item, AffectedObjectReference) else AffectedObjectReference.from_mapping(item) for item in objects),
            observed_condition=value.get("observed_condition", {}),
            practical_importance=value.get("practical_importance", ""),
            evidence_references=tuple(item if isinstance(item, EvidenceReference) else EvidenceReference.from_mapping(item) for item in evidence),
            causal_trace_references=tuple(item if isinstance(item, EvidenceReference) else EvidenceReference.from_mapping(item) for item in traces),
            missing_evidence=tuple(value.get("missing_evidence", ())),
            beginner_explanation=value.get("beginner_explanation", ""),
            technical_explanation=value.get("technical_explanation", ""),
            safe_options=tuple(value.get("safe_options", ())),
            tradeoffs=tuple(value.get("tradeoffs", ())),
            duplicate_grouping_key=value.get("duplicate_grouping_key", ""),
            status=value.get("status", ""),
            finding_contract_version=value.get("finding_contract_version", AUDIT_FINDING_CONTRACT_VERSION),
            rule_registry_version=value.get("rule_registry_version", AUDIT_RULES_VERSION),
            no_action=value.get("no_action", True),
            no_write=value.get("no_write", True),
            finding_fingerprint=value.get("finding_fingerprint", ""),
        )

    def _public_payload(self, *, include_fingerprint: bool) -> dict[str, Any]:
        payload = {
            "finding_id": self.finding_id,
            "rule_id": self.rule_id,
            "finding_contract_version": self.finding_contract_version,
            "rule_registry_version": self.rule_registry_version,
            "title": self.title,
            "finding_class": self.finding_class,
            "severity": self.severity,
            "confidence": self.confidence,
            "verification_label": self.verification_label,
            "evaluation_state": self.evaluation_state,
            "completeness_state": self.completeness_state,
            "affected_object_references": [item.as_dict() for item in self.affected_objects],
            "observed_condition": thaw(self.observed_condition),
            "practical_importance": self.practical_importance,
            "evidence_references": [item.as_dict() for item in self.evidence_references],
            "causal_trace_references": [item.as_dict() for item in self.causal_trace_references],
            "missing_evidence": list(self.missing_evidence),
            "beginner_explanation": self.beginner_explanation,
            "technical_explanation": self.technical_explanation,
            "safe_options": list(self.safe_options),
            "tradeoffs": list(self.tradeoffs),
            "no_action": self.no_action,
            "no_write": self.no_write,
            "duplicate_grouping_key": self.duplicate_grouping_key,
            "stable_sort_key": list(self.stable_sort_key),
            "status": self.status,
        }
        if include_fingerprint:
            payload["finding_fingerprint"] = self.finding_fingerprint
        return payload

    def _fingerprint_payload(self) -> dict[str, Any]:
        payload = self._public_payload(include_fingerprint=False)
        payload["affected_object_references"] = [item.fingerprint_identity() for item in self.affected_objects]
        payload.pop("stable_sort_key", None)
        return payload

    @property
    def stable_sort_key(self) -> tuple[int, int, str, str, str]:
        severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFORMATIONAL": 4, "NEEDS_REVIEW": 5}
        class_rank = {name: index for index, name in enumerate(sorted(FINDING_CLASSES))}
        return (
            severity_rank[self.severity],
            class_rank[self.finding_class],
            self.rule_id,
            self.duplicate_grouping_key,
            self.finding_fingerprint,
        )

    def as_dict(self) -> dict[str, Any]:
        return self._public_payload(include_fingerprint=True)


def validate_audit_finding(value: AuditFinding | Mapping[str, Any]) -> tuple[str, ...]:
    if isinstance(value, AuditFinding):
        finding = value
    elif isinstance(value, Mapping):
        try:
            finding = AuditFinding.from_mapping(value)
        except AuditContractError as exc:
            return (str(exc),)
        except (TypeError, ValueError, AttributeError):
            return ("AUDIT_FINDING_CONSTRUCTION_FAILED",)
    else:
        return ("AUDIT_FINDING_NOT_MAPPING",)
    errors: list[str] = []
    if finding.evaluation_state == "FINDING" and finding.status != "PASS":
        errors.append("AUDIT_FINDING_STATUS_STATE_MISMATCH")
    if finding.evaluation_state == "INCOMPLETE" and finding.status != "INCOMPLETE":
        errors.append("AUDIT_FINDING_STATUS_STATE_MISMATCH")
    if finding.evaluation_state == "NOT_APPLICABLE" and finding.status != "NOT_APPLICABLE":
        errors.append("AUDIT_FINDING_STATUS_STATE_MISMATCH")
    if finding.evaluation_state == "RULE_ERROR" and finding.status != "RULE_ERROR":
        errors.append("AUDIT_FINDING_STATUS_STATE_MISMATCH")
    if finding.evaluation_state in {"INCOMPLETE", "NEEDS_REVIEW"} and not finding.missing_evidence:
        errors.append("AUDIT_FINDING_MISSING_EVIDENCE_REQUIRED")
    if finding.evaluation_state == "FINDING" and not finding.affected_objects:
        errors.append("AUDIT_FINDING_AFFECTED_OBJECT_REQUIRED")
    if scan_private(finding.as_dict(), "finding"):
        errors.append("AUDIT_FINDING_PRIVATE_DATA_FORBIDDEN")
    return tuple(sorted(set(errors)))


__all__ = [
    "AffectedObjectReference", "AuditFinding", "EvidenceReference", "validate_audit_finding",
]
