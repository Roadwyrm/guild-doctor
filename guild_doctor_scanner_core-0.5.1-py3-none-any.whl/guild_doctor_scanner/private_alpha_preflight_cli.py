"""Preflight-only local invocation for the read-only private alpha."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from .private_alpha_configuration import (
    SECRET_ENVIRONMENT_VARIABLE,
    PrivateAlphaConfigurationError,
    check_secret_presence,
    load_configuration,
)
from .private_alpha_preflight import PREFLIGHT_CONTRACT, run_preflight


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="guild-doctor-private-alpha-preflight",
        description="Run the Guild Doctor private-alpha offline preflight only.",
    )
    parser.add_argument("--config", required=True, help="Explicit local JSON configuration path")
    parser.add_argument("--project-root", default=".", help=argparse.SUPPRESS)
    return parser


def _safe_blocked(code: str) -> dict[str, Any]:
    return {
        "preflight_contract": PREFLIGHT_CONTRACT,
        "overall_state": "BLOCKED_CONFIGURATION",
        "reason_codes": [code],
        "deployment_authorized": False,
        "discord_contact_count": 0,
        "network_request_count": 0,
        "token_prompt_count": 0,
        "synchronization_count": 0,
        "gateway_connection_count": 0,
        "discord_write_count": 0,
    }


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        configuration = load_configuration(args.config)
        secret = check_secret_presence(os.environ, SECRET_ENVIRONMENT_VARIABLE)
        result = run_preflight(configuration, secret, Path(args.project_root))
        print(json.dumps(result.as_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        return 0 if result.overall_state == "READY_OFFLINE" else 2
    except PrivateAlphaConfigurationError as exc:
        print(json.dumps(_safe_blocked(exc.code), sort_keys=True, separators=(",", ":")))
        return 2
    except Exception:
        payload = {
            **_safe_blocked("STAGE8_PREFLIGHT_INTERNAL_VALIDATION_FAILED"),
            "overall_state": "FAILED_INTERNAL_VALIDATION",
        }
        print(json.dumps(payload, sort_keys=True, separators=(",", ":")))
        return 3


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["build_parser", "main"]
