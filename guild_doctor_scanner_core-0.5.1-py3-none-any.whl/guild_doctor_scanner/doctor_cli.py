"""Installed local-only CLI for the Stage 5 Pass 4 Permission Doctor."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .doctor_guided_selector import execute_interactive_guided_session, execute_scripted_guided_session
from .doctor_runtime import (
    DOCTOR_BATCH_CONTRACT_VERSION,
    DoctorRuntimeInputError,
    DoctorRuntimeOutputError,
    EXIT_ARGUMENTS,
    EXIT_BATCH_PARTIAL,
    EXIT_CANCELLED,
    EXIT_CLOSURE_PENDING,
    EXIT_EXECUTION_FAILURE,
    EXIT_INPUT_FAILURE,
    EXIT_INTERRUPTED,
    EXIT_INVALID_WORKFLOW,
    EXIT_OUTPUT_FAILURE,
    EXIT_SUCCESS,
    execute_doctor_workflow,
    execute_doctor_workflow_batch,
    render_workflow_result_for_format,
    safe_progress,
    validate_doctor_batch,
    verify_doctor_runtime,
    write_doctor_output,
)
from .doctor_workflow import (
    DIRECT_QUERY,
    DoctorWorkflowPlan,
    ENUMERATION,
    ROLE_COMPARISON,
    SOURCE_LOCATION,
    STRUCTURED_JSON,
    WHY,
    build_workflow_plan,
    validate_doctor_workflow,
)


ROOT = Path(__file__).resolve().parents[1]


def _read_json(path: str | Path) -> Any:
    source = Path(path)
    try:
        return json.loads(source.read_bytes().decode("utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise DoctorRuntimeInputError(f"INPUT_JSON_INVALID:{source.name}") from exc


def _failure_report(directory: str | Path | None, *, stage: str, error: BaseException | str, exit_code: int) -> None:
    if directory is None:
        return
    try:
        destination = Path(directory).resolve()
        destination.mkdir(parents=True, exist_ok=True)
        message = str(error)
        if any(part in message.lower() for part in ("token", "authorization", "password", "credential")):
            message = "REDACTED_DIAGNOSTIC"
        payload = {
            "contract": "GUILD-DOCTOR-DOCTOR-CLI-0.1",
            "status": "FAIL",
            "stage": stage,
            "exit_code": exit_code,
            "error_type": type(error).__name__ if not isinstance(error, str) else "RuntimeError",
            "error": message[:500],
            "discord_contacted": False,
            "network_contacted": False,
            "discord_writes": 0,
            "token_disclosure_status": "PASS_NO_TOKEN_OUTPUT",
        }
        write_doctor_output(destination / "integration_report.json", json.dumps(payload, indent=2, sort_keys=True) + "\n", overwrite=True)
    except Exception:
        pass


def _extension_for(output_format: str) -> str:
    return {"PLAIN_TEXT": ".txt", "DISCORD_MARKDOWN": ".md", "STRUCTURED_JSON": ".json"}.get(str(output_format).upper(), ".txt")


def _build_direct(kind: str, query_path: str, *, output_format: str | None = None) -> DoctorWorkflowPlan:
    raw = _read_json(query_path)
    if not isinstance(raw, dict):
        raise DoctorRuntimeInputError("QUERY_NOT_MAPPING")
    if output_format:
        raw["output_format"] = output_format
    return build_workflow_plan(
        workflow_id=f"cli-{kind.lower()}-{raw.get('query_id', 'query')}",
        workflow_kind=kind,
        normalized_query=raw,
        source_mode=DIRECT_QUERY,
        confirmed=True,
        require_review_confirmation=False,
    )


def _execute_and_emit(plan: DoctorWorkflowPlan, *, output: str | None, overwrite: bool) -> int:
    safe_progress(f"validating {plan.workflow_kind} workflow")
    result = execute_doctor_workflow(plan)
    if not result.passed:
        safe_progress(f"workflow failed exit={result.exit_code}")
        print(json.dumps(result.as_dict(), indent=2, sort_keys=True))
        return result.exit_code
    safe_progress(f"executed frozen {plan.workflow_kind} interface")
    text = render_workflow_result_for_format(result, plan.output_format)
    if output:
        expected = _extension_for(plan.output_format)
        if Path(output).suffix.lower() != expected:
            raise DoctorRuntimeOutputError(f"OUTPUT_EXTENSION_MISMATCH:expected={expected}")
        path, digest = write_doctor_output(output, text, overwrite=overwrite)
        safe_progress(f"wrote local output sha256={digest} path={path}")
    else:
        print(text, end="")
    safe_progress(f"complete exit={result.exit_code}")
    return result.exit_code


def _guided(args: argparse.Namespace) -> int:
    snapshot = _read_json(args.snapshot)
    if not isinstance(snapshot, dict):
        raise DoctorRuntimeInputError("SELECTOR_SNAPSHOT_NOT_MAPPING")
    if args.scripted_session:
        script = _read_json(args.scripted_session)
        if not isinstance(script, dict):
            raise DoctorRuntimeInputError("SCRIPTED_SESSION_NOT_MAPPING")
        session, plan = execute_scripted_guided_session(snapshot, script)
    else:
        query_path = args.query
        if not query_path:
            if not sys.stdin.isatty():
                safe_progress("guided interactive mode requires --query when stdin is redirected; no workflow was executed")
                return EXIT_ARGUMENTS
            try:
                query_path = input("Structured normalized query JSON file (or CANCEL): ").strip()
            except EOFError as exc:
                raise DoctorRuntimeInputError("GUIDED_INPUT_UNAVAILABLE") from exc
            if query_path.upper() == "CANCEL":
                safe_progress("guided session cancelled before execution")
                return EXIT_CANCELLED
        query = _read_json(query_path)
        if not isinstance(query, dict):
            raise DoctorRuntimeInputError("GUIDED_QUERY_NOT_MAPPING")

        def _reader(prompt: str) -> str:
            try:
                return input(prompt)
            except EOFError as exc:
                raise DoctorRuntimeInputError("GUIDED_INPUT_UNAVAILABLE") from exc

        session, plan = execute_interactive_guided_session(snapshot, query, reader=_reader, writer=safe_progress)
    review = {"session": session.as_dict(), "review": __import__("guild_doctor_scanner.doctor_guided_selector", fromlist=["review_guided_session"]).review_guided_session(session)}
    if args.review_output:
        write_doctor_output(args.review_output, json.dumps(review, indent=2, sort_keys=True) + "\n", overwrite=args.overwrite)
    if session.state == "CANCELLED":
        safe_progress("guided session cancelled before execution")
        return EXIT_CANCELLED
    if plan is None:
        safe_progress("guided session invalid or incomplete")
        return EXIT_INVALID_WORKFLOW
    return _execute_and_emit(plan, output=args.output, overwrite=args.overwrite)


def _batch(args: argparse.Namespace) -> int:
    raw = _read_json(args.workflows)
    if not isinstance(raw, dict):
        raise DoctorRuntimeInputError("BATCH_NOT_MAPPING")
    errors = validate_doctor_batch(raw)
    if errors:
        print(json.dumps({"status": "FAIL", "errors": list(errors)}, indent=2, sort_keys=True))
        return EXIT_INVALID_WORKFLOW
    safe_progress("executing ordered local workflow batch")
    summary, results = execute_doctor_workflow_batch(raw)
    if args.output_directory:
        destination = Path(args.output_directory)
        destination.mkdir(parents=True, exist_ok=True)
        for result, plan_raw in zip(results, raw["workflows"]):
            plan = DoctorWorkflowPlan.from_mapping(plan_raw)
            name = f"{plan.workflow_id}{_extension_for(plan.output_format)}"
            write_doctor_output(destination / name, render_workflow_result_for_format(result, plan.output_format), overwrite=args.overwrite)
        write_doctor_output(destination / "batch_manifest.json", json.dumps(summary, indent=2, sort_keys=True) + "\n", overwrite=args.overwrite)
        safe_progress(f"wrote {len(results)} ordered batch outputs")
    else:
        print(json.dumps(summary, indent=2, sort_keys=True))
    return int(summary["exit_code"])


def _verify(args: argparse.Namespace) -> int:
    evidence = Path(args.evidence_directory)
    evidence.mkdir(parents=True, exist_ok=True)
    safe_progress("created/confirmed Stage 5 Pass 4 evidence directory")
    report = verify_doctor_runtime(ROOT, evidence)
    safe_progress(f"offline live-derived runtime verification status={report['status']}")
    return EXIT_SUCCESS if report["status"] == "PASS" else EXIT_EXECUTION_FAILURE


def _close_stage5(args: argparse.Namespace) -> int:
    from .stage5_closure_cli import main as closure_main

    return closure_main(["--evidence-directory", args.evidence_directory, "--source-directory", args.source_directory])


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="guild-doctor-doctor", description="Guild Doctor local-only Permission Doctor runtime")
    commands = parser.add_subparsers(dest="command", required=True)
    guided = commands.add_parser("guided")
    guided.add_argument("--snapshot", required=True)
    guided.add_argument("--query")
    guided.add_argument("--scripted-session")
    guided.add_argument("--output")
    guided.add_argument("--review-output")
    guided.add_argument("--overwrite", action="store_true")
    for name, kind in (("why", WHY), ("who", ENUMERATION), ("find-setting", SOURCE_LOCATION), ("compare-roles", ROLE_COMPARISON)):
        item = commands.add_parser(name)
        item.add_argument("--query", required=True)
        item.add_argument("--output")
        item.add_argument("--output-format", choices=("PLAIN_TEXT", "DISCORD_MARKDOWN", "STRUCTURED_JSON"))
        item.add_argument("--overwrite", action="store_true")
        item.set_defaults(workflow_kind=kind)
    run = commands.add_parser("run")
    run.add_argument("--workflow", required=True)
    run.add_argument("--output")
    run.add_argument("--overwrite", action="store_true")
    batch = commands.add_parser("batch")
    batch.add_argument("--workflows", required=True)
    batch.add_argument("--output-directory")
    batch.add_argument("--overwrite", action="store_true")
    validate = commands.add_parser("validate")
    validate.add_argument("--workflow", required=True)
    verify = commands.add_parser("verify")
    verify.add_argument("--evidence-directory", required=True)
    closure = commands.add_parser("close-stage5")
    closure.add_argument("--evidence-directory", required=True)
    closure.add_argument("--source-directory", default=str(ROOT / "Guild_Doctor_Project_Sources"))
    return parser


def main(argv: list[str] | None = None) -> int:
    report_directory: str | None = None
    try:
        args = build_parser().parse_args(argv)
        report_directory = getattr(args, "evidence_directory", None) or (str(Path(getattr(args, "output", "")).parent) if getattr(args, "output", None) else None)
        if args.command == "guided":
            return _guided(args)
        if args.command in {"why", "who", "find-setting", "compare-roles"}:
            plan = _build_direct(args.workflow_kind, args.query, output_format=args.output_format)
            return _execute_and_emit(plan, output=args.output, overwrite=args.overwrite)
        if args.command == "run":
            raw = _read_json(args.workflow)
            if not isinstance(raw, dict):
                raise DoctorRuntimeInputError("WORKFLOW_NOT_MAPPING")
            plan = DoctorWorkflowPlan.from_mapping(raw)
            return _execute_and_emit(plan, output=args.output, overwrite=args.overwrite)
        if args.command == "batch":
            return _batch(args)
        if args.command == "validate":
            raw = _read_json(args.workflow)
            errors = validate_doctor_workflow(raw) if isinstance(raw, dict) else ("WORKFLOW_NOT_MAPPING",)
            print(json.dumps({"status": "PASS" if not errors else "FAIL", "errors": list(errors)}, indent=2, sort_keys=True))
            return EXIT_SUCCESS if not errors else EXIT_INVALID_WORKFLOW
        if args.command == "verify":
            return _verify(args)
        if args.command == "close-stage5":
            return _close_stage5(args)
        return EXIT_ARGUMENTS
    except KeyboardInterrupt:
        safe_progress("interrupted")
        _failure_report(report_directory, stage="interrupted", error="KeyboardInterrupt", exit_code=EXIT_INTERRUPTED)
        return EXIT_INTERRUPTED
    except DoctorRuntimeOutputError as exc:
        safe_progress("output failure")
        _failure_report(report_directory, stage="output", error=exc, exit_code=EXIT_OUTPUT_FAILURE)
        return EXIT_OUTPUT_FAILURE
    except DoctorRuntimeInputError as exc:
        safe_progress("input failure")
        _failure_report(report_directory, stage="input", error=exc, exit_code=EXIT_INPUT_FAILURE)
        return EXIT_INPUT_FAILURE
    except (ValueError, TypeError) as exc:
        safe_progress("validation failure")
        _failure_report(report_directory, stage="validation", error=exc, exit_code=EXIT_INVALID_WORKFLOW)
        return EXIT_INVALID_WORKFLOW
    except SystemExit as exc:
        return int(exc.code)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())


__all__ = ["build_parser", "main"]
