"""Versioned immutable snapshot persistence for Project Guild Doctor Stage 2.

The repository stores canonical normalized snapshots and scan-health envelopes.
It never stores Discord tokens, raw payload bodies, message content, or temporary
WHO_CAN member collections.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from uuid import uuid4

from .acquisition import StructureAcquisition, utc_now
from .canonical import canonical_json

PERSISTENCE_SCHEMA_VERSION = "GUILD-DOCTOR-PERSISTENCE-0.1"


class PersistenceError(RuntimeError):
    """Base persistence failure."""


class PersistenceVersionError(PersistenceError):
    """Raised when the on-disk schema is newer or otherwise unsupported."""


@dataclass(frozen=True, slots=True)
class PersistOutcome:
    run_id: str
    snapshot_id: str | None
    snapshot_inserted: bool
    persisted_at: str


@dataclass(frozen=True, slots=True)
class ScanRunRecord:
    run_id: str
    guild_id: str
    started_at: str
    completed_at: str
    scan_profile: str
    succeeded: bool
    snapshot_id: str | None
    structural_completeness: str
    normalization_error: str | None
    collection_health: dict[str, Any]
    created_at: str


@dataclass(frozen=True, slots=True)
class SnapshotRecord:
    snapshot_id: str
    guild_id: str
    schema_version: str
    scanner_contract_version: str
    permission_definition_version: str
    scan_profile: str
    structural_completeness: str
    member_completeness: str
    thread_completeness: str
    started_at: str
    completed_at: str
    exact_fingerprint: str
    structural_fingerprint: str | None
    issue_count: int
    snapshot: dict[str, Any]
    created_at: str


@dataclass(frozen=True, slots=True)
class RepositoryStatus:
    schema_version: str
    database_path: str
    snapshot_count: int
    scan_run_count: int
    integrity: str


class SQLiteSnapshotRepository:
    """SQLite-backed immutable snapshot repository.

    A new SQLite connection is opened inside each worker-thread operation. This
    avoids sharing sqlite3 connections across the Discord event-loop thread and
    worker threads. Writes are serialized by an asyncio lock and committed in a
    single transaction.
    """

    __slots__ = ("_path", "_lock")

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path).expanduser().resolve()
        self._lock = asyncio.Lock()

    @property
    def path(self) -> Path:
        return self._path

    async def initialize(self) -> None:
        async with self._lock:
            await asyncio.to_thread(self._initialize_sync)

    async def persist_acquisition(self, acquisition: StructureAcquisition) -> PersistOutcome:
        """Persist one scan attempt and its canonical snapshot, when available."""

        async with self._lock:
            return await asyncio.to_thread(self._persist_sync, acquisition)

    async def latest_scan(self, guild_id: int | str) -> ScanRunRecord | None:
        return await asyncio.to_thread(self._latest_scan_sync, self._guild_id(guild_id))

    async def latest_snapshot(self, guild_id: int | str) -> SnapshotRecord | None:
        return await asyncio.to_thread(self._latest_snapshot_sync, self._guild_id(guild_id))

    async def repository_status(self) -> RepositoryStatus:
        return await asyncio.to_thread(self._status_sync)

    def _connect(self) -> sqlite3.Connection:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self._path, timeout=10.0)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA synchronous = FULL")
        connection.execute("PRAGMA busy_timeout = 10000")
        return connection

    def _initialize_sync(self) -> None:
        with closing(self._connect()) as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS schema_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                """
            )
            connection.execute(
                "INSERT OR IGNORE INTO schema_meta(key, value) VALUES('persistence_schema_version', ?)",
                (PERSISTENCE_SCHEMA_VERSION,),
            )
            existing = connection.execute(
                "SELECT value FROM schema_meta WHERE key = 'persistence_schema_version'"
            ).fetchone()
            if existing is None or existing["value"] != PERSISTENCE_SCHEMA_VERSION:
                found = existing["value"] if existing is not None else "missing"
                raise PersistenceVersionError(
                    f"unsupported persistence schema {found}; expected {PERSISTENCE_SCHEMA_VERSION}"
                )

            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS snapshots (
                    snapshot_id TEXT PRIMARY KEY,
                    guild_id TEXT NOT NULL,
                    schema_version TEXT NOT NULL,
                    scanner_contract_version TEXT NOT NULL,
                    permission_definition_version TEXT NOT NULL,
                    scan_profile TEXT NOT NULL,
                    structural_completeness TEXT NOT NULL,
                    member_completeness TEXT NOT NULL,
                    thread_completeness TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    completed_at TEXT NOT NULL,
                    exact_fingerprint TEXT NOT NULL,
                    structural_fingerprint TEXT,
                    issue_count INTEGER NOT NULL CHECK(issue_count >= 0),
                    snapshot_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_snapshots_guild_completed
                    ON snapshots(guild_id, completed_at DESC, created_at DESC);

                CREATE TABLE IF NOT EXISTS scan_runs (
                    run_id TEXT PRIMARY KEY,
                    guild_id TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    completed_at TEXT NOT NULL,
                    scan_profile TEXT NOT NULL,
                    succeeded INTEGER NOT NULL CHECK(succeeded IN (0, 1)),
                    snapshot_id TEXT,
                    structural_completeness TEXT NOT NULL,
                    normalization_error TEXT,
                    collection_health_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(snapshot_id) REFERENCES snapshots(snapshot_id)
                );

                CREATE INDEX IF NOT EXISTS idx_scan_runs_guild_completed
                    ON scan_runs(guild_id, completed_at DESC, created_at DESC);
                """
            )
            connection.commit()

    def _persist_sync(self, acquisition: StructureAcquisition) -> PersistOutcome:
        self._initialize_sync()
        created_at = utc_now()
        run_id = str(uuid4())
        snapshot = acquisition.snapshot
        snapshot_id: str | None = None
        snapshot_inserted = False

        health = {
            name: {
                **result.health_dict(),
                "attempt_count": result.attempt_count,
                "http_or_library_status": result.http_or_library_status,
                "errors": [
                    {
                        "code": error.code,
                        "error_type": error.error_type,
                        "retryable": error.retryable,
                        "attempt": error.attempt,
                        "status": error.status,
                        "entity_id": error.entity_id,
                    }
                    for error in result.errors
                ],
            }
            for name, result in sorted(acquisition.results.items())
        }
        health_json = canonical_json(health)

        with closing(self._connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            if snapshot is not None:
                data = snapshot.as_dict()
                snapshot_id = str(data["snapshot_id"])
                exact = data.get("snapshot_fingerprint_sha256")
                if not exact:
                    raise PersistenceError("canonical snapshot is missing its exact fingerprint")
                encoded = canonical_json(data)
                existing = connection.execute(
                    "SELECT exact_fingerprint, snapshot_json FROM snapshots WHERE snapshot_id = ?",
                    (snapshot_id,),
                ).fetchone()
                if existing is not None:
                    if existing["exact_fingerprint"] != str(exact) or existing["snapshot_json"] != encoded:
                        raise PersistenceError(
                            f"immutable snapshot ID conflict for {snapshot_id}"
                        )
                else:
                    connection.execute(
                        """
                        INSERT INTO snapshots(
                            snapshot_id, guild_id, schema_version, scanner_contract_version,
                            permission_definition_version, scan_profile,
                            structural_completeness, member_completeness, thread_completeness,
                            started_at, completed_at, exact_fingerprint,
                            structural_fingerprint, issue_count, snapshot_json, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            snapshot_id,
                            str(data["guild_id"]),
                            str(data["schema_version"]),
                            str(data["scanner_contract_version"]),
                            str(data["permission_definition_version"]),
                            str(data["scan_profile"]),
                            str(data["structural_completeness"]),
                            str(data["member_completeness"]),
                            str(data["thread_completeness"]),
                            str(data["started_at"]),
                            str(data["completed_at"]),
                            str(exact),
                            data.get("structural_fingerprint_sha256"),
                            len(data.get("issues", [])),
                            encoded,
                            created_at,
                        ),
                    )
                    snapshot_inserted = True

            profile = (
                snapshot.scan_profile
                if snapshot is not None
                else str(acquisition.bundle.get("scan_profile", "STRUCTURE_BASELINE"))
            )
            structural = snapshot.structural_completeness if snapshot is not None else "UNKNOWN"
            connection.execute(
                """
                INSERT INTO scan_runs(
                    run_id, guild_id, started_at, completed_at, scan_profile,
                    succeeded, snapshot_id, structural_completeness,
                    normalization_error, collection_health_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    acquisition.guild_id,
                    acquisition.started_at,
                    acquisition.completed_at,
                    profile,
                    1 if snapshot is not None else 0,
                    snapshot_id,
                    structural,
                    acquisition.normalization_error,
                    health_json,
                    created_at,
                ),
            )
            connection.commit()

        return PersistOutcome(
            run_id=run_id,
            snapshot_id=snapshot_id,
            snapshot_inserted=snapshot_inserted,
            persisted_at=created_at,
        )

    def _latest_scan_sync(self, guild_id: str) -> ScanRunRecord | None:
        self._initialize_sync()
        with closing(self._connect()) as connection:
            row = connection.execute(
                """
                SELECT * FROM scan_runs
                WHERE guild_id = ?
                ORDER BY completed_at DESC, created_at DESC
                LIMIT 1
                """,
                (guild_id,),
            ).fetchone()
        if row is None:
            return None
        return ScanRunRecord(
            run_id=row["run_id"],
            guild_id=row["guild_id"],
            started_at=row["started_at"],
            completed_at=row["completed_at"],
            scan_profile=row["scan_profile"],
            succeeded=bool(row["succeeded"]),
            snapshot_id=row["snapshot_id"],
            structural_completeness=row["structural_completeness"],
            normalization_error=row["normalization_error"],
            collection_health=json.loads(row["collection_health_json"]),
            created_at=row["created_at"],
        )

    def _latest_snapshot_sync(self, guild_id: str) -> SnapshotRecord | None:
        self._initialize_sync()
        with closing(self._connect()) as connection:
            row = connection.execute(
                """
                SELECT * FROM snapshots
                WHERE guild_id = ?
                ORDER BY completed_at DESC, created_at DESC
                LIMIT 1
                """,
                (guild_id,),
            ).fetchone()
        if row is None:
            return None
        return SnapshotRecord(
            snapshot_id=row["snapshot_id"],
            guild_id=row["guild_id"],
            schema_version=row["schema_version"],
            scanner_contract_version=row["scanner_contract_version"],
            permission_definition_version=row["permission_definition_version"],
            scan_profile=row["scan_profile"],
            structural_completeness=row["structural_completeness"],
            member_completeness=row["member_completeness"],
            thread_completeness=row["thread_completeness"],
            started_at=row["started_at"],
            completed_at=row["completed_at"],
            exact_fingerprint=row["exact_fingerprint"],
            structural_fingerprint=row["structural_fingerprint"],
            issue_count=row["issue_count"],
            snapshot=json.loads(row["snapshot_json"]),
            created_at=row["created_at"],
        )

    def _status_sync(self) -> RepositoryStatus:
        self._initialize_sync()
        with closing(self._connect()) as connection:
            snapshots = connection.execute("SELECT COUNT(*) AS n FROM snapshots").fetchone()["n"]
            runs = connection.execute("SELECT COUNT(*) AS n FROM scan_runs").fetchone()["n"]
            integrity = connection.execute("PRAGMA quick_check").fetchone()[0]
        return RepositoryStatus(
            schema_version=PERSISTENCE_SCHEMA_VERSION,
            database_path=str(self._path),
            snapshot_count=int(snapshots),
            scan_run_count=int(runs),
            integrity=str(integrity),
        )

    @staticmethod
    def _guild_id(value: int | str) -> str:
        text = str(value).strip()
        if not text.isdigit() or int(text) <= 0:
            raise ValueError("guild_id must be a positive Discord snowflake")
        return str(int(text))
