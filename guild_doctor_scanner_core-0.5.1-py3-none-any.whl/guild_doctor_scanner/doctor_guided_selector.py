"""Deterministic, local guided selector for Stage 5 Pass 4.

The selector works only with exact structured registry keys and exact decimal
object IDs from a supplied immutable snapshot.  It deliberately has no name
matching, natural-language input, network access, or implicit execution.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from types import MappingProxyType
from typing import Any

from .action_registry import ACTION_RULES_BY_KEY
from .canonical import canonical_json
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY
from .doctor_enumeration_query import ENUMERATE_ACTUAL_RESULTS, WHO_CAN, WHO_CANNOT, WHO_UNKNOWN
from .doctor_query import EXPLAIN_ACTUAL_RESULT, WHY_CAN, WHY_CANNOT, WHY_UNKNOWN
from .doctor_role_comparison_query import (
    COMPARE_ACTION_AUTHORITY,
    COMPARE_CAPABILITY_SET,
    COMPARE_CONTEXT_CAPABILITY,
    COMPARE_RAW_ROLE_PERMISSIONS,
    ENUMERATE_ROLE_DIFFERENCES,
)
from .doctor_source_query import EXPLAIN_SOURCE_OBJECT, FIND_CONTROLLING_SOURCE, LIST_MATERIAL_SOURCES, TRACE_SOURCE_CHAIN
from .doctor_workflow import (
    DIRECT_QUERY,
    GUIDED_SELECTION,
    SCRIPTED_GUIDED_SELECTION,
    DoctorWorkflowError,
    DoctorWorkflowPlan,
    ENUMERATION,
    ROLE_COMPARISON,
    SOURCE_LOCATION,
    WHY,
    build_workflow_plan,
    thaw_workflow,
)


DOCTOR_GUIDED_SELECTOR_CONTRACT_VERSION = "GUILD-DOCTOR-DOCTOR-GUIDED-SELECTOR-0.1"
SCRIPTED_GUIDED_SESSION_CONTRACT_VERSION = "GUILD-DOCTOR-DOCTOR-GUIDED-SESSION-0.1"

CREATED = "CREATED"
SELECTING = "SELECTING"
REVIEW_READY = "REVIEW_READY"
CONFIRMED = "CONFIRMED"
EXECUTING = "EXECUTING"
COMPLETE = "COMPLETE"
CANCELLED = "CANCELLED"
INVALID = "INVALID"
FAILED = "FAILED"
SESSION_STATES = frozenset({CREATED, SELECTING, REVIEW_READY, CONFIRMED, EXECUTING, COMPLETE, CANCELLED, INVALID, FAILED})

QUESTION_OPTIONS = (
    ("WHY_CAN", WHY, WHY_CAN),
    ("WHY_CANNOT", WHY, WHY_CANNOT),
    ("WHY_UNKNOWN", WHY, WHY_UNKNOWN),
    ("EXPLAIN_ACTUAL_RESULT", WHY, EXPLAIN_ACTUAL_RESULT),
    ("WHO_CAN", ENUMERATION, WHO_CAN),
    ("WHO_CANNOT", ENUMERATION, WHO_CANNOT),
    ("WHO_UNKNOWN", ENUMERATION, WHO_UNKNOWN),
    ("ENUMERATE_ACTUAL_RESULTS", ENUMERATION, ENUMERATE_ACTUAL_RESULTS),
    ("FIND_CONTROLLING_SOURCE", SOURCE_LOCATION, FIND_CONTROLLING_SOURCE),
    ("TRACE_SOURCE_CHAIN", SOURCE_LOCATION, TRACE_SOURCE_CHAIN),
    ("LIST_MATERIAL_SOURCES", SOURCE_LOCATION, LIST_MATERIAL_SOURCES),
    ("EXPLAIN_SOURCE_OBJECT", SOURCE_LOCATION, EXPLAIN_SOURCE_OBJECT),
    ("COMPARE_RAW_ROLE_PERMISSIONS", ROLE_COMPARISON, COMPARE_RAW_ROLE_PERMISSIONS),
    ("COMPARE_CONTEXT_CAPABILITY", ROLE_COMPARISON, COMPARE_CONTEXT_CAPABILITY),
    ("COMPARE_CAPABILITY_SET", ROLE_COMPARISON, COMPARE_CAPABILITY_SET),
    ("COMPARE_ACTION_AUTHORITY", ROLE_COMPARISON, COMPARE_ACTION_AUTHORITY),
    ("ENUMERATE_ROLE_DIFFERENCES", ROLE_COMPARISON, ENUMERATE_ROLE_DIFFERENCES),
)


class GuidedSelectorError(ValueError):
    """Raised when an interactive selector response is malformed."""


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int) and value > 0:
        return str(value)
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(value[key]) for key in sorted(value, key=lambda item: str(item))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    return value


def _records(snapshot: Mapping[str, Any], key: str) -> tuple[Mapping[str, Any], ...]:
    value = snapshot.get(key, ())
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return ()
    return tuple(item for item in value if isinstance(item, Mapping))


def _id_options(records: Sequence[Mapping[str, Any]], *, type_keys: tuple[str, ...] = ()) -> list[dict[str, Any]]:
    values = []
    for record in records:
        identifier = _snowflake(record.get("id"))
        if identifier is None:
            continue
        record_type = str(record.get("type_key", "")).upper()
        if type_keys and record_type not in type_keys:
            continue
        values.append({"key": identifier, "id": identifier, "type": record_type or None})
    return sorted(values, key=lambda item: int(item["id"]))


def build_selector_catalog(snapshot: Mapping[str, Any], *, candidate_records: Sequence[Mapping[str, Any]] = ()) -> dict[str, list[dict[str, Any]]]:
    """Build stable structured options from an immutable local snapshot only."""

    if not isinstance(snapshot, Mapping):
        raise GuidedSelectorError("SELECTOR_SNAPSHOT_NOT_MAPPING")
    roles = _id_options(_records(snapshot, "roles"))
    for role, record in zip(roles, sorted(_records(snapshot, "roles"), key=lambda item: int(_snowflake(item.get("id")) or "0"))):
        role["is_everyone"] = bool(record.get("is_everyone"))
        role["managed"] = bool(record.get("managed"))
    channels = _id_options(_records(snapshot, "channels"))
    categories = [item for item in channels if item.get("type") == "CATEGORY"]
    text_channels = [item for item in channels if item.get("type") in {"TEXT", "ANNOUNCEMENT", "FORUM", "MEDIA"}]
    threads = _id_options(_records(snapshot, "threads"))
    members = _id_options(tuple(candidate_records) or _records(snapshot, "members"))
    permission_keys = []
    for capability in DEFAULT_CAPABILITY_REGISTRY.capabilities:
        permission_keys.append({"key": capability.capability_key, "kind": "CAPABILITY"})
    raw_permissions = [flag.name for flag in DEFAULT_CAPABILITY_REGISTRY.permission_flags]
    return {
        "question_type": [{"key": key, "workflow_kind": workflow, "intent": intent} for key, workflow, intent in QUESTION_OPTIONS],
        "members": members,
        "roles": roles,
        "categories": categories,
        "channels": channels,
        "text_channels": text_channels,
        "threads": threads,
        "capabilities": permission_keys,
        "actions": [{"key": key, "kind": "ACTION"} for key in sorted(ACTION_RULES_BY_KEY)],
        "raw_permissions": [{"key": key, "kind": "RAW_PERMISSION"} for key in raw_permissions],
        "explanation_modes": [{"key": key} for key in ("SIMPLE", "DETAILED", "TECHNICAL")],
        "output_formats": [{"key": key} for key in ("PLAIN_TEXT", "DISCORD_MARKDOWN", "STRUCTURED_JSON")],
    }


def select_exact(options: Sequence[Mapping[str, Any]], response: str | int) -> Mapping[str, Any]:
    """Select one option by position, exact key, or exact decimal ID only."""

    if isinstance(response, int) or (isinstance(response, str) and response.strip().isdecimal() and int(response.strip()) <= len(options)):
        index = int(response)
        if 1 <= index <= len(options):
            return options[index - 1]
    text = str(response).strip()
    matches = [item for item in options if text == str(item.get("key")) or text == str(item.get("id"))]
    if len(matches) != 1:
        raise GuidedSelectorError("SELECTOR_OPTION_NOT_EXACT_OR_AMBIGUOUS")
    return matches[0]


@dataclass(frozen=True, slots=True)
class GuidedSelectorSession:
    session_id: str
    snapshot: Mapping[str, Any]
    catalog: Mapping[str, Any]
    state: str = CREATED
    selections: Mapping[str, Any] | None = None
    transitions: tuple[Mapping[str, Any], ...] = ()
    errors: tuple[str, ...] = ()
    selector_contract_version: str = DOCTOR_GUIDED_SELECTOR_CONTRACT_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "snapshot", _freeze(self.snapshot))
        object.__setattr__(self, "catalog", _freeze(self.catalog))
        object.__setattr__(self, "selections", _freeze(self.selections or {}))
        object.__setattr__(self, "transitions", tuple(_freeze(item) for item in self.transitions))
        object.__setattr__(self, "errors", tuple(sorted(set(self.errors))))

    @property
    def session_fingerprint(self) -> str:
        payload = self.as_dict()
        payload.pop("session_fingerprint", None)
        return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()

    def as_dict(self) -> dict[str, Any]:
        return {
            "selector_contract_version": self.selector_contract_version,
            "session_id": self.session_id,
            "state": self.state,
            "selections": thaw_workflow(self.selections),
            "transitions": thaw_workflow(self.transitions),
            "errors": list(self.errors),
            "session_fingerprint": hashlib.sha256(canonical_json({"session_id": self.session_id, "state": self.state, "selections": thaw_workflow(self.selections), "transitions": thaw_workflow(self.transitions), "errors": list(self.errors)}).encode("utf-8")).hexdigest(),
        }


def create_guided_session(session_id: str, snapshot: Mapping[str, Any], *, candidate_records: Sequence[Mapping[str, Any]] = ()) -> GuidedSelectorSession:
    """Create a non-executing local selector session."""

    if not isinstance(session_id, str) or not session_id.strip():
        raise GuidedSelectorError("SESSION_ID_INVALID")
    catalog = build_selector_catalog(snapshot, candidate_records=candidate_records)
    return GuidedSelectorSession(session_id.strip(), snapshot, catalog, CREATED, {}, ({"from": None, "to": CREATED, "event": "CREATE"},))


def _next(session: GuidedSelectorSession, state: str, event: str, *, selections: Mapping[str, Any] | None = None, error: str | None = None) -> GuidedSelectorSession:
    transition = {"from": session.state, "to": state, "event": event}
    errors = tuple(session.errors) + ((error,) if error else ())
    return GuidedSelectorSession(
        session.session_id,
        session.snapshot,
        session.catalog,
        state,
        dict(session.selections if selections is None else selections),
        tuple(session.transitions) + (transition,),
        errors,
    )


def apply_guided_response(session: GuidedSelectorSession, response: Mapping[str, Any]) -> GuidedSelectorSession:
    """Apply one structured response; invalid input remains non-executing."""

    if session.state in {CANCELLED, COMPLETE, FAILED}:
        return _next(session, INVALID, "RESPONSE_AFTER_TERMINAL", error="SELECTOR_TERMINAL")
    if not isinstance(response, Mapping) or len(response) != 1:
        return _next(session, INVALID, "INVALID_RESPONSE", error="SELECTOR_RESPONSE_INVALID")
    key, value = next(iter(response.items()))
    key = str(key)
    selections = thaw_workflow(session.selections)
    if key == "cancel" and value is True:
        return _next(session, CANCELLED, "CANCEL", selections=selections)
    if key == "confirm":
        if value is not True:
            return _next(session, CANCELLED, "DECLINE", selections=selections)
        if session.state != REVIEW_READY:
            return _next(session, INVALID, "CONFIRM_TOO_EARLY", selections=selections, error="SELECTOR_REVIEW_REQUIRED")
        selections["confirmed"] = True
        return _next(session, CONFIRMED, "CONFIRM", selections=selections)
    if key == "normalized_query":
        if not isinstance(value, Mapping):
            return _next(session, INVALID, "QUERY_INVALID", selections=selections, error="SELECTOR_QUERY_NOT_MAPPING")
        selections[key] = thaw_workflow(value)
        return _next(session, SELECTING, "QUERY_SELECTED", selections=selections)
    if key == "question_type":
        try:
            option = select_exact(thaw_workflow(session.catalog["question_type"]), value)
        except GuidedSelectorError as exc:
            return _next(session, SELECTING, "QUESTION_INVALID", selections=selections, error=str(exc))
        selections["question_type"] = option["key"]
        selections["workflow_kind"] = option["workflow_kind"]
        selections["intent"] = option["intent"]
        return _next(session, SELECTING, "QUESTION_SELECTED", selections=selections)
    if key in {"subject_id", "context_id", "thread_id", "role_id", "target_id"}:
        catalog_key = {"subject_id": "members", "context_id": "channels", "thread_id": "threads", "role_id": "roles", "target_id": "members"}[key]
        try:
            option = select_exact(thaw_workflow(session.catalog[catalog_key]), value)
        except GuidedSelectorError as exc:
            return _next(session, SELECTING, "OBJECT_INVALID", selections=selections, error=str(exc))
        selections[key] = option["id"]
        return _next(session, SELECTING, "OBJECT_SELECTED", selections=selections)
    if key in {"target_key", "explanation_mode", "output_format"}:
        catalog_key = {"explanation_mode": "explanation_modes", "output_format": "output_formats"}.get(key)
        options = tuple(thaw_workflow(session.catalog[catalog_key])) if catalog_key else tuple(thaw_workflow(session.catalog["capabilities"])) + tuple(thaw_workflow(session.catalog["actions"]))
        selector_value = value
        if key == "target_key" and isinstance(value, str) and ":" in value:
            requested_kind, selector_value = value.split(":", 1)
            options = tuple(item for item in options if str(item.get("kind", "")).upper() == requested_kind.strip().upper())
        try:
            option = select_exact(options, selector_value)
        except GuidedSelectorError as exc:
            return _next(session, SELECTING, "KEY_INVALID", selections=selections, error=str(exc))
        selections[key] = option["key"]
        return _next(session, SELECTING, "KEY_SELECTED", selections=selections)
    if key == "role_ids":
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
            return _next(session, INVALID, "ROLE_SET_INVALID", selections=selections, error="SELECTOR_ROLE_SET_INVALID")
        selected: list[str] = []
        try:
            for item in value:
                selected.append(str(select_exact(thaw_workflow(session.catalog["roles"]), item)["id"]))
        except GuidedSelectorError as exc:
            return _next(session, SELECTING, "ROLE_SET_INVALID", selections=selections, error=str(exc))
        selections[key] = tuple(selected)
        return _next(session, SELECTING, "ROLE_SET_SELECTED", selections=selections)
    if key == "review":
        if value is not True or not selections.get("workflow_kind") or not isinstance(selections.get("normalized_query"), Mapping):
            return _next(session, INVALID, "REVIEW_INVALID", selections=selections, error="SELECTOR_REVIEW_INCOMPLETE")
        return _next(session, REVIEW_READY, "REVIEW_READY", selections=selections)
    return _next(session, INVALID, "FIELD_UNKNOWN", selections=selections, error=f"SELECTOR_FIELD_UNKNOWN:{key}")


def review_guided_session(session: GuidedSelectorSession) -> dict[str, Any]:
    """Return a non-recommendation review record before execution."""

    selections = thaw_workflow(session.selections)
    query = selections.get("normalized_query", {})
    return {
        "selector_contract_version": DOCTOR_GUIDED_SELECTOR_CONTRACT_VERSION,
        "session_id": session.session_id,
        "state": session.state,
        "workflow_kind": selections.get("workflow_kind"),
        "question_intent": selections.get("intent"),
        "normalized_query_type": {WHY: "DoctorQuery", ENUMERATION: "DoctorEnumerationQuery", SOURCE_LOCATION: "SourceLocationQuery", ROLE_COMPARISON: "RoleComparisonQuery"}.get(selections.get("workflow_kind")),
        "selected_subject_id": selections.get("subject_id") or query.get("subject_id"),
        "selected_target_key": selections.get("target_key") or query.get("target_key"),
        "selected_context_id": selections.get("context_id") or query.get("context_id"),
        "explanation_mode": selections.get("explanation_mode") or query.get("explanation_mode") or query.get("aggregate_explanation_mode"),
        "output_format": selections.get("output_format") or query.get("output_format"),
        "pre_execution_model": str(query.get("target_kind", "")).upper() == "ACTION",
        "known_limitations": ["Structured selection only; labels are not identity.", "No Discord request or command execution occurs in the selector."],
        "recommendations_generated": False,
        "session_fingerprint": session.session_fingerprint,
    }


def build_plan_from_guided_session(session: GuidedSelectorSession, *, source_mode: str = SCRIPTED_GUIDED_SELECTION) -> DoctorWorkflowPlan:
    if session.state != CONFIRMED:
        raise GuidedSelectorError("SELECTOR_CONFIRMATION_REQUIRED")
    selections = thaw_workflow(session.selections)
    query = selections.get("normalized_query")
    workflow_kind = selections.get("workflow_kind")
    if not isinstance(query, Mapping) or workflow_kind not in {WHY, ENUMERATION, SOURCE_LOCATION, ROLE_COMPARISON}:
        raise GuidedSelectorError("SELECTOR_NORMALIZED_QUERY_MISSING")
    return build_workflow_plan(
        workflow_id=f"guided-{session.session_id}",
        workflow_kind=str(workflow_kind),
        normalized_query=query,
        source_mode=source_mode,
        confirmed=True,
        selector_session_fingerprint=session.session_fingerprint,
        require_review_confirmation=True,
        evidence_classifications=("SYNTHETIC_GUIDED_WORKFLOW",),
        verification_statuses=("SYNTHETIC_GUIDED_WORKFLOW",),
    )


def execute_interactive_guided_session(
    snapshot: Mapping[str, Any],
    normalized_query: Mapping[str, Any],
    *,
    reader: Any,
    writer: Any,
    session_id: str = "interactive-guided",
) -> tuple[GuidedSelectorSession, DoctorWorkflowPlan | None]:
    """Run an exact-option terminal review over a structured local query.

    Full member and evidence records must come from the supplied structured
    query because a snapshot alone may intentionally omit member data.  The
    terminal flow never accepts a natural-language question: it selects an
    exact question type, revalidates selected IDs/keys from the query against
    local catalogs, shows the review record, and requires confirmation.
    """

    if not isinstance(normalized_query, Mapping):
        raise GuidedSelectorError("INTERACTIVE_QUERY_NOT_MAPPING")
    child = normalized_query.get("doctor_query") if isinstance(normalized_query.get("doctor_query"), Mapping) else normalized_query
    candidates: list[Mapping[str, Any]] = []
    if isinstance(child.get("member_record"), Mapping):
        candidates.append(child["member_record"])
    if isinstance(normalized_query.get("candidates"), Sequence) and not isinstance(normalized_query.get("candidates"), (str, bytes)):
        candidates.extend(item for item in normalized_query["candidates"] if isinstance(item, Mapping))
    session = create_guided_session(session_id, snapshot, candidate_records=tuple(candidates))
    while True:
        options = thaw_workflow(session.catalog["question_type"])
        writer("Question type options: " + ", ".join(f"{index + 1}={item['key']}" for index, item in enumerate(options)))
        response = str(reader("Question type (number/key; CANCEL to stop): ")).strip()
        if response.upper() == "CANCEL":
            return apply_guided_response(session, {"cancel": True}), None
        session = apply_guided_response(session, {"question_type": response})
        if session.state != INVALID:
            break
        writer("Invalid question type; retry with an exact numbered option or key.")
    selections = thaw_workflow(session.selections)
    workflow_kind = str(selections.get("workflow_kind"))
    intent_field = {WHY: "query_intent", ENUMERATION: "enumeration_intent", SOURCE_LOCATION: "source_intent", ROLE_COMPARISON: "comparison_intent"}[workflow_kind]
    intent_source = normalized_query if workflow_kind == SOURCE_LOCATION else child
    if str(intent_source.get(intent_field, "")) != str(selections.get("intent")):
        return _next(session, INVALID, "TEMPLATE_INTENT_MISMATCH", error="SELECTOR_TEMPLATE_INTENT_MISMATCH"), None

    def reselect(key: str, expected: str, label: str, *, response_expected: str | None = None) -> GuidedSelectorSession:
        current = session
        display_value = response_expected or expected
        while True:
            response = str(reader(f"{label} ({display_value}; CANCEL to stop): ")).strip()
            if response.upper() == "CANCEL":
                return apply_guided_response(current, {"cancel": True})
            updated = apply_guided_response(current, {key: response})
            if updated.state != INVALID and thaw_workflow(updated.selections).get(key) == expected:
                return updated
            writer("Invalid or mismatched structured selection; retry with the exact ID or key.")
            current = updated

    subject_id = _snowflake(child.get("subject_id"))
    if subject_id and thaw_workflow(session.catalog["members"]):
        session = reselect("subject_id", subject_id, "Subject member ID")
    context_id = _snowflake(child.get("context_id"))
    if session.state != CANCELLED and context_id:
        session = reselect("context_id", context_id, "Context ID")
    target_key = child.get("target_key") or normalized_query.get("target_key")
    if session.state != CANCELLED and target_key:
        target_kind = str(child.get("target_kind") or normalized_query.get("target_kind") or "").upper()
        typed_target = f"{target_kind}:{target_key}" if target_kind in {"CAPABILITY", "ACTION"} else str(target_key)
        session = reselect("target_key", str(target_key), "Capability or action key", response_expected=typed_target)
    explanation_mode = child.get("explanation_mode") or normalized_query.get("aggregate_explanation_mode") or normalized_query.get("explanation_mode")
    if session.state != CANCELLED and explanation_mode:
        session = reselect("explanation_mode", str(explanation_mode), "Explanation mode")
    output_format = child.get("output_format") or normalized_query.get("aggregate_output_format") or normalized_query.get("output_format")
    if session.state != CANCELLED and output_format:
        session = reselect("output_format", str(output_format), "Output format")
    if session.state == CANCELLED:
        return session, None
    session = apply_guided_response(session, {"normalized_query": normalized_query})
    session = apply_guided_response(session, {"review": True})
    if session.state != REVIEW_READY:
        return session, None
    writer(canonical_json(review_guided_session(session)))
    confirmation = str(reader("Confirm structured plan (CONFIRM/CANCEL): ")).strip().upper()
    session = apply_guided_response(session, {"confirm": confirmation == "CONFIRM"})
    if session.state != CONFIRMED:
        return session, None
    return session, build_plan_from_guided_session(session, source_mode=GUIDED_SELECTION)


def execute_scripted_guided_session(snapshot: Mapping[str, Any], script: Mapping[str, Any]) -> tuple[GuidedSelectorSession, DoctorWorkflowPlan | None]:
    """Run a deterministic scripted session for offline verification."""

    if not isinstance(script, Mapping) or script.get("contract") != SCRIPTED_GUIDED_SESSION_CONTRACT_VERSION:
        raise GuidedSelectorError("SCRIPTED_SESSION_CONTRACT_UNSUPPORTED")
    responses = script.get("responses")
    if not isinstance(responses, Sequence) or isinstance(responses, (str, bytes)):
        raise GuidedSelectorError("SCRIPTED_SESSION_RESPONSES_INVALID")
    session = create_guided_session(str(script.get("session_id", "")), snapshot, candidate_records=script.get("candidate_records", ()))
    for response in responses:
        session = apply_guided_response(session, response)
        if session.state in {CANCELLED, INVALID, FAILED}:
            return session, None
    if session.state != CONFIRMED:
        return session, None
    plan = build_plan_from_guided_session(session)
    expected_kind = script.get("expected_workflow_kind")
    if expected_kind and expected_kind != plan.workflow_kind:
        raise GuidedSelectorError("SCRIPTED_SESSION_WORKFLOW_MISMATCH")
    return session, plan


__all__ = [
    "CANCELLED", "COMPLETE", "CONFIRMED", "CREATED", "DOCTOR_GUIDED_SELECTOR_CONTRACT_VERSION", "EXECUTING", "FAILED",
    "GuidedSelectorError", "GuidedSelectorSession", "INVALID", "REVIEW_READY", "SCRIPTED_GUIDED_SESSION_CONTRACT_VERSION",
    "SELECTING", "SESSION_STATES", "apply_guided_response", "build_plan_from_guided_session", "build_selector_catalog",
    "create_guided_session", "execute_interactive_guided_session", "execute_scripted_guided_session", "review_guided_session", "select_exact",
]
