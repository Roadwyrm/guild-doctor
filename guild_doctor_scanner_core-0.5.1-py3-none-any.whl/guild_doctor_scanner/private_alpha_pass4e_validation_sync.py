"""Typed, one-guild synchronization and verification for Pass 4E."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import inspect
import json
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

from .discord_command_manifest import RuntimeCommand, manifest_fingerprint
from .discord_command_schema import LIVE_ROOT_DESCRIPTION, LIVE_ROOT_NAME, normalize_channel_type
from .discord_live_runtime import DiscordPyTransport
from .private_alpha_configuration import PrivateAlphaConfiguration
from .private_alpha_pass4e_validation_surface import (
    TEMPORARY_COMMAND_NAME,
    ValidationSurfaceMode,
    build_validation_manifest,
    serialized_validation_schema_fingerprint,
    validation_manifest_fingerprint,
)


VALIDATION_SYNC_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-VALIDATION-SYNC-0.1"
SYNC_PROOF_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-SYNC-PROOF-0.1"
SYNC_SCOPE = "ONE_CONFIGURED_PRIVATE_ALPHA_GUILD"


class ValidationSyncError(ValueError):
    pass


@dataclass(slots=True)
class SyncOperationBudget:
    validation_write_count: int = 0
    cleanup_write_count: int = 0
    global_write_count: int = 0
    other_guild_write_count: int = 0

    @property
    def total_write_count(self) -> int:
        return self.validation_write_count + self.cleanup_write_count

    def authorize(self, mode: ValidationSurfaceMode) -> None:
        if mode is ValidationSurfaceMode.PASS4E_VALIDATION:
            if self.validation_write_count != 0:
                raise ValidationSyncError("STAGE8_PASS4E_VALIDATION_SYNC_BUDGET_EXHAUSTED")
            self.validation_write_count += 1
        elif mode is ValidationSurfaceMode.CLEANUP:
            if self.cleanup_write_count != 0:
                raise ValidationSyncError("STAGE8_PASS4E_CLEANUP_SYNC_BUDGET_EXHAUSTED")
            self.cleanup_write_count += 1
        else:
            raise ValidationSyncError("STAGE8_PASS4E_SYNC_MODE_NOT_WRITABLE")


@dataclass(frozen=True, slots=True)
class SyncVerification:
    state: str
    stable_error: str | None
    mode: str
    serialized_application_command_object_count: int
    logical_route_count: int
    production_route_count: int
    temporary_route_count: int
    unexpected_route_count: int
    fixed_choice_count: int
    temporary_autocomplete: bool | None


@dataclass(frozen=True, slots=True)
class SyncProof:
    proof_contract: str
    mode: str
    authorized_sync_scope: str
    authorized_target_binding_fingerprint: str
    guild_scoped_sync_count: int
    post_sync_verification_state: str
    manifest_fingerprint: str
    serialized_schema_fingerprint: str
    global_sync_count: int
    other_guild_sync_count: int
    temporary_route_count: int
    logical_route_count: int
    serialized_application_command_object_count: int
    proof_fingerprint: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _get(value: Any, name: str, default: Any = None) -> Any:
    return value.get(name, default) if isinstance(value, Mapping) else getattr(value, name, default)


def _type_name(value: Any, default: str = "unknown") -> str:
    raw = getattr(value, "value", value)
    if isinstance(raw, str):
        return raw.lower()
    return {1:"subcommand",2:"subcommand_group",3:"string",4:"integer",5:"boolean",6:"user",7:"channel",8:"role",9:"mentionable",10:"number",11:"attachment"}.get(raw, default)


def _option_schema(option: Any) -> dict[str, Any]:
    choices = []
    for choice in _get(option, "choices", ()) or ():
        if isinstance(choice, (tuple, list)) and len(choice) == 2:
            choices.append({"name": choice[0], "value": choice[1]})
        else:
            choices.append({"name": _get(choice, "name", _get(choice, "display_name")), "value": _get(choice, "value")})
    channel_types = []
    for item in _get(option, "channel_types", ()) or ():
        channel_types.append(normalize_channel_type(item))
    return {
        "name": _get(option, "display_name", _get(option, "name")),
        "description": _get(option, "description", ""),
        "type": _type_name(_get(option, "type")),
        "required": bool(_get(option, "required", False)),
        "choices": choices,
        "autocomplete": bool(_get(option, "autocomplete", False)),
        "channel_types": channel_types,
        "options": [],
    }


def expected_remote_schema(mode: ValidationSurfaceMode) -> dict[str, Any]:
    if not isinstance(mode, ValidationSurfaceMode):
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_MODE_INVALID")
    manifest = build_validation_manifest(mode)
    return {
        "serialized_application_command_object_count": 1,
        "root_name": LIVE_ROOT_NAME,
        "root_description": LIVE_ROOT_DESCRIPTION,
        "subcommands": [
            {"name": item.slash_name, "description": item.description, "options": [_option_schema(option) for option in item.options]}
            for item in manifest
        ],
    }


def normalize_remote_schema(commands: Any) -> dict[str, Any]:
    if isinstance(commands, Mapping) and set(("serialized_application_command_object_count", "root_name", "root_description", "subcommands")).issubset(commands):
        return {key: commands[key] for key in ("serialized_application_command_object_count", "root_name", "root_description", "subcommands")}
    values = list(commands) if isinstance(commands, Sequence) and not isinstance(commands, (str, bytes, bytearray)) else []
    roots = [item for item in values if _get(item, "name") == LIVE_ROOT_NAME]
    if len(roots) != 1:
        return {"serialized_application_command_object_count": len(values), "root_name": None, "root_description": None, "subcommands": []}
    root = roots[0]
    children = _get(root, "options", None)
    if children is None:
        children = _get(root, "commands", ())
    return {
        "serialized_application_command_object_count": len(values),
        "root_name": _get(root, "name"),
        "root_description": _get(root, "description", ""),
        "subcommands": [
            {
                "name": _get(item, "name"), "description": _get(item, "description", ""),
                "options": [_option_schema(option) for option in (_get(item, "options", None) if _get(item, "options", None) is not None else _get(item, "parameters", ()) or ())],
            }
            for item in (children or ())
        ],
    }


def verify_remote_schema(commands: Any, mode: ValidationSurfaceMode) -> SyncVerification:
    expected = expected_remote_schema(mode)
    actual = normalize_remote_schema(commands)
    actual_names = [item.get("name") for item in actual.get("subcommands", ())]
    expected_names = [item["name"] for item in expected["subcommands"]]
    temporary = [item for item in actual.get("subcommands", ()) if item.get("name") == TEMPORARY_COMMAND_NAME]
    production = [name for name in actual_names if name != TEMPORARY_COMMAND_NAME and name in expected_names]
    unexpected = [name for name in actual_names if name not in expected_names]
    fixed_count = 0
    autocomplete = None
    if len(temporary) == 1:
        case = [item for item in temporary[0].get("options", ()) if item.get("name") == "case"]
        if len(case) == 1:
            fixed_count = len(case[0].get("choices", ()))
            autocomplete = bool(case[0].get("autocomplete"))
    exact = actual == expected
    if mode is ValidationSurfaceMode.PASS4E_VALIDATION:
        shape = len(actual_names) == 14 and len(production) == 13 and len(temporary) == 1 and fixed_count == 3 and autocomplete is False
    else:
        shape = len(actual_names) == 13 and len(production) == 13 and len(temporary) == 0
    return SyncVerification(
        "PASS" if exact and shape and not unexpected else "FAIL",
        None if exact and shape and not unexpected else "STAGE8_PASS4E_REMOTE_SCHEMA_MISMATCH",
        mode.value, int(actual.get("serialized_application_command_object_count", 0)), len(actual_names),
        len(production), len(temporary), len(unexpected), fixed_count, autocomplete,
    )


def _proof_payload(*, mode: ValidationSurfaceMode, target_fingerprint: str, verification: SyncVerification) -> dict[str, Any]:
    return {
        "proof_contract": SYNC_PROOF_CONTRACT,
        "mode": mode.value,
        "authorized_sync_scope": SYNC_SCOPE,
        "authorized_target_binding_fingerprint": target_fingerprint,
        "guild_scoped_sync_count": 1,
        "post_sync_verification_state": verification.state,
        "manifest_fingerprint": validation_manifest_fingerprint(mode),
        "serialized_schema_fingerprint": serialized_validation_schema_fingerprint(mode),
        "global_sync_count": 0,
        "other_guild_sync_count": 0,
        "temporary_route_count": verification.temporary_route_count,
        "logical_route_count": verification.logical_route_count,
        "serialized_application_command_object_count": verification.serialized_application_command_object_count,
    }


def build_sync_proof(*, mode: ValidationSurfaceMode, target_fingerprint: str, verification: SyncVerification) -> SyncProof:
    payload = _proof_payload(mode=mode, target_fingerprint=target_fingerprint, verification=verification)
    fingerprint = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return SyncProof(**payload, proof_fingerprint=fingerprint)


def validate_sync_proof(proof: SyncProof, *, mode: ValidationSurfaceMode, configuration: PrivateAlphaConfiguration) -> None:
    if not isinstance(proof, SyncProof) or proof.proof_contract != SYNC_PROOF_CONTRACT or proof.mode != mode.value:
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_PROOF_INVALID")
    if proof.authorized_target_binding_fingerprint != configuration.fingerprint or len(configuration.guild_allowlist) != 1:
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_PROOF_TARGET_MISMATCH")
    if proof.post_sync_verification_state != "PASS" or proof.guild_scoped_sync_count != 1 or proof.global_sync_count or proof.other_guild_sync_count:
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_PROOF_INCOMPLETE")
    expected = build_sync_proof(mode=mode, target_fingerprint=configuration.fingerprint, verification=SyncVerification(
        "PASS", None, mode.value, proof.serialized_application_command_object_count, proof.logical_route_count,
        13, proof.temporary_route_count, 0, 3 if mode is ValidationSurfaceMode.PASS4E_VALIDATION else 0,
        False if mode is ValidationSurfaceMode.PASS4E_VALIDATION else None,
    ))
    if expected.proof_fingerprint != proof.proof_fingerprint:
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_PROOF_FINGERPRINT_MISMATCH")


class SyncProofStore:
    def __init__(self, path: Path):
        self.path = Path(path)

    def write_once(self, proof: SyncProof) -> None:
        if self.path.exists() or not self.path.parent.is_dir():
            raise ValidationSyncError("STAGE8_PASS4E_SYNC_PROOF_ALREADY_EXISTS")
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        try:
            with temporary.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(json.dumps(proof.as_dict(), sort_keys=True, separators=(",", ":")) + "\n")
                stream.flush(); os.fsync(stream.fileno())
            os.replace(temporary, self.path)
        except OSError:
            temporary.unlink(missing_ok=True)
            raise ValidationSyncError("STAGE8_PASS4E_SYNC_PROOF_WRITE_FAILED") from None

    def ensure_available(self) -> None:
        """Fail before a write when this one-use operation already completed."""
        if self.path.exists():
            raise ValidationSyncError("STAGE8_PASS4E_SYNC_PROOF_ALREADY_EXISTS")
        if not self.path.parent.is_dir():
            raise ValidationSyncError("STAGE8_PASS4E_SYNC_PROOF_WRITE_FAILED")

    def load(self) -> SyncProof:
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
            if set(value) != set(SyncProof.__dataclass_fields__):
                raise ValueError
            return SyncProof(**value)
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            raise ValidationSyncError("STAGE8_PASS4E_SYNC_PROOF_INVALID") from None


async def _invoke(transport: Any, name: str, *args: Any) -> Any:
    method = getattr(transport, name, None)
    if method is None:
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_TRANSPORT_UNSUPPORTED")
    result = method(*args)
    return await result if inspect.isawaitable(result) else result


async def execute_typed_guild_sync(
    *, transport: Any, configuration: PrivateAlphaConfiguration, mode: ValidationSurfaceMode,
    budget: SyncOperationBudget, proof_store: SyncProofStore,
    expected_manifest_fingerprint: str,
    expected_schema_fingerprint: str,
) -> SyncProof:
    if not isinstance(mode, ValidationSurfaceMode):
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_MODE_INVALID")
    if mode not in (ValidationSurfaceMode.PASS4E_VALIDATION, ValidationSurfaceMode.CLEANUP):
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_MODE_NOT_WRITABLE")
    if not isinstance(configuration, PrivateAlphaConfiguration) or len(configuration.guild_allowlist) != 1:
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_TARGET_INVALID")
    if budget.global_write_count or budget.other_guild_write_count:
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_SCOPE_VIOLATION")
    manifest = build_validation_manifest(mode)
    actual_manifest_fingerprint = manifest_fingerprint(manifest)
    actual_schema_fingerprint = serialized_validation_schema_fingerprint(mode)
    if actual_manifest_fingerprint != expected_manifest_fingerprint:
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_MANIFEST_MISMATCH")
    if actual_schema_fingerprint != expected_schema_fingerprint:
        raise ValidationSyncError("STAGE8_PASS4E_SYNC_SCHEMA_MISMATCH")
    guild_id = configuration.guild_allowlist[0]
    proof_store.ensure_available()
    budget.authorize(mode)
    returned = await _invoke(transport, "synchronize_guild_commands", guild_id, mode, manifest)
    returned_verification = verify_remote_schema(returned, mode)
    if returned_verification.state != "PASS":
        raise ValidationSyncError(returned_verification.stable_error or "STAGE8_PASS4E_REMOTE_SCHEMA_MISMATCH")
    observed = await _invoke(transport, "fetch_guild_commands", guild_id)
    verification = verify_remote_schema(observed, mode)
    if verification.state != "PASS":
        raise ValidationSyncError(verification.stable_error or "STAGE8_PASS4E_REMOTE_SCHEMA_MISMATCH")
    proof = build_sync_proof(mode=mode, target_fingerprint=configuration.fingerprint, verification=verification)
    proof_store.write_once(proof)
    return proof


class DiscordValidationSyncTransport:
    """Production Discord adapter; D20 tests use fake transports only."""
    def __init__(self, base: DiscordPyTransport | None = None):
        self.base = base or DiscordPyTransport()
        self.mode: ValidationSurfaceMode | None = None
        self.manifest: tuple[RuntimeCommand, ...] = ()

    async def initialize(self, token: str, mode: ValidationSurfaceMode) -> None:
        if not isinstance(mode, ValidationSurfaceMode):
            raise ValidationSyncError("STAGE8_PASS4E_SYNC_MODE_INVALID")
        self.mode = mode; self.manifest = build_validation_manifest(mode)
        await self.base.async_open_client_for_manifest(self.manifest)
        await self.base.async_authenticate_bot(token)

    async def synchronize_guild_commands(self, guild_id: str, mode: ValidationSurfaceMode, manifest: tuple[RuntimeCommand, ...]) -> Any:
        if mode is not self.mode or tuple(manifest) != self.manifest:
            raise ValidationSyncError("STAGE8_PASS4E_SYNC_TRANSPORT_MODE_MISMATCH")
        await self.base.async_bind_manifest_to_guild_scope(guild_id, manifest)
        return await self.base.async_synchronize_guild_commands(guild_id, list(manifest))

    async def fetch_guild_commands(self, guild_id: str) -> Any:
        return await self.base.async_fetch_guild_commands(guild_id)

    async def close(self) -> None:
        await self.base.async_close_client()
        self.mode = None; self.manifest = ()


__all__ = [
    "DiscordValidationSyncTransport", "SYNC_PROOF_CONTRACT", "SYNC_SCOPE",
    "SyncOperationBudget", "SyncProof", "SyncProofStore", "SyncVerification",
    "VALIDATION_SYNC_CONTRACT", "ValidationSyncError", "build_sync_proof",
    "execute_typed_guild_sync", "expected_remote_schema", "normalize_remote_schema",
    "validate_sync_proof", "verify_remote_schema",
]
