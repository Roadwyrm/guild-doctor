"""Strict normalization helpers."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from .errors import SnapshotValidationError


def snowflake(value: Any, field: str) -> str:
    if isinstance(value, bool):
        raise SnapshotValidationError(f"{field} must be a decimal snowflake string")
    text = str(value).strip() if value is not None else ""
    if not text or not text.isdecimal():
        raise SnapshotValidationError(f"{field} must be a decimal snowflake string")
    return str(int(text))


def optional_snowflake(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return snowflake(value, field)


def nonnegative_int(value: Any, field: str) -> int:
    if isinstance(value, bool):
        raise SnapshotValidationError(f"{field} must be a non-negative integer")
    try:
        result = int(value)
    except (TypeError, ValueError) as exc:
        raise SnapshotValidationError(f"{field} must be a non-negative integer") from exc
    if result < 0:
        raise SnapshotValidationError(f"{field} must be a non-negative integer")
    return result


def bigint(value: Any, field: str) -> int:
    return nonnegative_int(value, field)


def decimal_string(value: Any, field: str) -> str:
    return str(bigint(value, field))


def utc_timestamp(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SnapshotValidationError(f"{field} must be an RFC 3339 timestamp")
    text = value.strip()
    candidate = text[:-1] + "+00:00" if text.endswith("Z") else text
    try:
        parsed = datetime.fromisoformat(candidate)
    except ValueError as exc:
        raise SnapshotValidationError(f"{field} must be an RFC 3339 timestamp") from exc
    if parsed.tzinfo is None:
        raise SnapshotValidationError(f"{field} must include an explicit timezone")
    normalized = parsed.astimezone(timezone.utc).isoformat(timespec="milliseconds")
    return normalized.replace("+00:00", "Z")


def optional_timestamp(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return utc_timestamp(value, field)


def bool_or_none(value: Any) -> bool | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    raise SnapshotValidationError("expected boolean or null")


def canonical_id_sort(value: str) -> tuple[int, str]:
    return (int(value), value)
