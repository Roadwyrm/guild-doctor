"""Closed validation for the public Stage 7 export-receipt projection."""
from __future__ import annotations

from dataclasses import dataclass
import re

from .audit_contract import scan_report_private


EXPORT_RECEIPT_BOUNDARY_REPAIR_CONTRACT = (
    "GUILD-DOCTOR-STAGE7-EXPORT-RECEIPT-BOUNDARY-REPAIR-0.1"
)

EXPORT_RECEIPT_REASONS = frozenset({
    "EXPORT_PREPARED_NO_DELIVERY",
    "EXPORT_COMPLETED",
    "EXPORT_PRIVACY_FAILED",
    "EXPORT_TARGET_EXISTS",
    "EXPORT_FILESYSTEM_FAILED",
    "EXPORT_FORMAT_UNSUPPORTED",
})

# One authority for the status/reason relationships represented by the frozen
# receipt fields. The first two outcomes are established by executable Pass 5
# contracts. The failure outcomes preserve the frozen Pass 5A distinctions
# without exposing exception or path data.
EXPORT_RECEIPT_OUTCOMES = frozenset({
    ("PREPARED", "NOT_REQUESTED", "PASS", "EXPORT_PREPARED_NO_DELIVERY"),
    ("WRITTEN", "NOT_REPLACED", "PASS", "EXPORT_COMPLETED"),
    ("WRITTEN", "REPLACED", "PASS", "EXPORT_COMPLETED"),
    ("FAILED", "NOT_REPLACED", "PASS", "EXPORT_TARGET_EXISTS"),
    ("FAILED", "NOT_REQUESTED", "FAILED", "EXPORT_PRIVACY_FAILED"),
    ("FAILED", "NOT_REQUESTED", "PASS", "EXPORT_FILESYSTEM_FAILED"),
    ("FAILED", "NOT_REQUESTED", "PASS", "EXPORT_FORMAT_UNSUPPORTED"),
})

# Rendering remains byte-compatible for existing valid receipts while going
# through a closed mapping rather than interpolating caller-controlled prose.
EXPORT_RECEIPT_REASON_TEXT = {
    reason: reason for reason in sorted(EXPORT_RECEIPT_REASONS)
}

_FORMAT_EXTENSION = {"json": ".json", "markdown": ".md"}
_URI_SCHEME = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*:")
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")
_WINDOWS_DEVICE = re.compile(
    r"^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$", re.IGNORECASE
)
_TEMP_SUFFIXES = (
    ".tmp", ".temp", ".partial", ".part", ".download", ".crdownload",
    ".swp", ".swo", ".bak", ".backup", ".orig", ".rej",
)


class ExportReceiptValidationError(ValueError):
    """Value-free, stable receipt validation failure."""


@dataclass(frozen=True, slots=True)
class ValidatedExportReceipt:
    format: str
    write_status: str
    replacement_status: str
    privacy_validation_status: str
    safe_basename: str
    stable_reason: str


def _validate_basename(value: object, format: object) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ExportReceiptValidationError("EXPORT_RECEIPT_BASENAME_INVALID")
    if (
        value in {".", ".."}
        or "/" in value
        or "\\" in value
        or ":" in value
        or "?" in value
        or "#" in value
        or _CONTROL.search(value)
        or _URI_SCHEME.match(value)
        or _WINDOWS_DEVICE.match(value)
        or value.endswith((" ", "."))
    ):
        raise ExportReceiptValidationError("EXPORT_RECEIPT_BASENAME_INVALID")

    lowered = value.lower()
    if (
        lowered.endswith(_TEMP_SUFFIXES)
        or lowered.endswith("~")
        or lowered.startswith(("~$", ".~", ".#"))
        or (lowered.startswith("#") and lowered.endswith("#"))
    ):
        raise ExportReceiptValidationError("EXPORT_RECEIPT_TEMPORARY_BASENAME")

    expected = _FORMAT_EXTENSION.get(format)
    if expected is None:
        raise ExportReceiptValidationError("EXPORT_FORMAT_UNSUPPORTED")
    if not lowered.endswith(expected) or lowered == expected:
        raise ExportReceiptValidationError("EXPORT_RECEIPT_EXTENSION_MISMATCH")
    return value


def validate_export_receipt_metadata(
    *,
    format: object,
    write_status: object,
    replacement_status: object,
    privacy_validation_status: object,
    safe_basename: object,
    stable_reason: object,
) -> ValidatedExportReceipt:
    """Validate receipt-only metadata without normalization or filesystem access."""
    if not isinstance(format, str) or format not in _FORMAT_EXTENSION:
        raise ExportReceiptValidationError("EXPORT_FORMAT_UNSUPPORTED")
    basename = _validate_basename(safe_basename, format)
    if not isinstance(stable_reason, str) or stable_reason not in EXPORT_RECEIPT_REASONS:
        raise ExportReceiptValidationError("EXPORT_RECEIPT_REASON_INVALID")
    if any(not isinstance(value, str) for value in (
        write_status, replacement_status, privacy_validation_status
    )):
        raise ExportReceiptValidationError("EXPORT_RECEIPT_STATUS_MISMATCH")
    outcome = (
        write_status,
        replacement_status,
        privacy_validation_status,
        stable_reason,
    )
    if outcome not in EXPORT_RECEIPT_OUTCOMES:
        raise ExportReceiptValidationError("EXPORT_RECEIPT_STATUS_MISMATCH")
    public_metadata = {
        "format": format,
        "write_status": write_status,
        "replacement_status": replacement_status,
        "privacy_validation_status": privacy_validation_status,
        "safe_basename": basename,
        "stable_reason": stable_reason,
    }
    if scan_report_private(public_metadata, "export_receipt.metadata"):
        raise ExportReceiptValidationError("EXPORT_PRIVACY_FAILED")
    return ValidatedExportReceipt(**public_metadata)


__all__ = [
    "EXPORT_RECEIPT_BOUNDARY_REPAIR_CONTRACT",
    "EXPORT_RECEIPT_OUTCOMES",
    "EXPORT_RECEIPT_REASONS",
    "EXPORT_RECEIPT_REASON_TEXT",
    "ExportReceiptValidationError",
    "ValidatedExportReceipt",
    "validate_export_receipt_metadata",
]
