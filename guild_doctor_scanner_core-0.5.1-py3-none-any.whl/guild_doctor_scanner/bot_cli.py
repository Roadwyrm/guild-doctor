"""Run the Stage 2 owner-only Guild Doctor command client."""

from __future__ import annotations

import sys

from .runtime import runtime_from_environment


def main() -> int:
    try:
        client, token = runtime_from_environment()
    except Exception as exc:
        print(f"guild-doctor-bot: {exc}", file=sys.stderr)
        return 1

    client.run(token, log_handler=None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
