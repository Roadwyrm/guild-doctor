"""Pure Stage 4 Pass 3 query, adapter, renderer, and presentation orchestration."""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from .canonical import canonical_json
from .explanation_adapters import (
    ADAPTER_REGISTRY_BY_FAMILY,
    AdaptedExplanationInput,
    EXPLANATION_ADAPTERS_VERSION,
    Stage3ExplanationAdapterRequest,
    adapt_stage3_result,
)
from .explanation_engine import render_explanation, sanitize_display_label
from .explanation_integration import ExplanationIntegrationResult, integrate_stage3_result
from .explanation_query import (
    EXPLANATION_ORCHESTRATION_VERSION,
    EXPLANATION_QUERY_CONTRACT_VERSION,
    ExplanationQuery,
    ExplanationQueryError,
    QUERY_REGISTRY_BY_TYPE,
    STAGE4_PASS3_CONTRACT_VERSION,
    validate_explanation_query,
)
from .explanation_schema import ExplanationOutput
from .presentation_profiles import (
    OUTPUT_FORMATS,
    PRESENTATION_PROFILE_VERSION,
    PRESENTATION_SECTIONS,
    DisclosurePolicy,
    PresentationProfile,
    get_presentation_profile,
)


ORCHESTRATION_RULE_QUERY = "EXPLAIN-ORCHESTRATE-QUERY-001"
ORCHESTRATION_RULE_ADAPTER = "EXPLAIN-ORCHESTRATE-ADAPTER-001"
ORCHESTRATION_RULE_PRESENTATION = "EXPLAIN-ORCHESTRATE-PRESENTATION-001"
ORCHESTRATION_RULE_DISCLOSURE = "EXPLAIN-ORCHESTRATE-DISCLOSURE-001"
ORCHESTRATION_RULE_TRUNCATION = "EXPLAIN-ORCHESTRATE-TRUNCATION-001"
ORCHESTRATION_RULE_SAFETY = "EXPLAIN-ORCHESTRATE-SAFETY-001"


class ExplanationOrchestrationError(ValueError):
    """Raised only when strict orchestration is requested."""


def _safe_json(value: Any, key: str = "") -> Any:
    lower = key.lower()
    if any(fragment in lower for fragment in ("token", "authorization", "access_token", "client_secret", "password", "api_key")):
        return None
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _safe_json(method(), key)
    if isinstance(value, Mapping):
        return {
            str(item_key): _safe_json(item_value, str(item_key))
            for item_key, item_value in sorted(value.items(), key=lambda item: str(item[0]))
            if not any(fragment in str(item_key).lower() for fragment in ("token", "authorization", "access_token", "client_secret", "password", "api_key"))
        }
    if isinstance(value, (list, tuple)):
        return [_safe_json(item, key) for item in value]
    if isinstance(value, (set, frozenset)):
        return [_safe_json(item, key) for item in sorted(value, key=str)]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _fingerprint(value: Any) -> str:
    payload = _safe_json(value)
    if not isinstance(payload, Mapping):
        payload = {"value": payload}
    return hashlib.sha256(canonical_json(dict(payload)).encode("utf-8")).hexdigest()


def _source_mapping(value: Any) -> dict[str, Any]:
    method = getattr(value, "as_dict", None)
    if callable(method):
        value = method()
    return dict(_safe_json(value)) if isinstance(value, Mapping) else {}


def _text(value: Any) -> str:
    return str(value) if value is not None else ""


def _canonical_value(value: Any) -> str:
    safe = _safe_json(value)
    if isinstance(safe, Mapping):
        return canonical_json(dict(safe))
    return str(safe)


def _safe_presentation_text(value: Any, *, include_ids: bool, markdown: bool) -> str:
    """Reuse Pass 1 label safety, then neutralize remaining Markdown controls."""

    text = sanitize_display_label(_text(value), hide_ids=not include_ids)
    if not markdown:
        # Plain text should not contain Markdown escape characters.  Mention
        # neutralization remains in place, so a plain-text export is still
        # safe to copy into a Discord surface later.
        text = re.sub(r"\\([\\`*_~>|])", r"\1", text)
        return text
    if markdown:
        text = text.replace("```", r"\`\`\`").replace("`", r"\`")
        text = text.replace("||", r"\|\|")
        text = text.replace("[", r"\[").replace("]", r"\]")
        text = text.replace("(", r"\(").replace(")", r"\)")
        text = re.sub(r"(?m)^(\s*)([#>])", r"\1\\\2", text)
    return text


def _safe_lines(values: Sequence[Any], *, include_ids: bool, markdown: bool) -> tuple[str, ...]:
    return tuple(_safe_presentation_text(item, include_ids=include_ids, markdown=markdown) for item in values if _text(item))


def _display_field_lines(source: Mapping[str, Any], names: Sequence[str], *, include_ids: bool, markdown: bool) -> tuple[str, ...]:
    lines: list[str] = []
    for name in names:
        if name in source and source[name] is not None:
            value = "[hidden]" if not include_ids and (name.lower().endswith("_id") or name.lower() == "id") else _canonical_value(source[name])
            lines.append(_safe_presentation_text(f"{name}={value}", include_ids=include_ids, markdown=markdown))
    return tuple(lines)


def _raw_lines(source: Mapping[str, Any], policy: DisclosurePolicy, *, include_ids: bool, markdown: bool) -> tuple[str, ...]:
    lines: list[str] = []
    for key in sorted(source):
        lower = key.lower()
        is_raw = lower.endswith("_decimal") or lower.endswith("_hex")
        is_unknown = "unknown" in lower and (lower.endswith("_bits") or lower.endswith("_decimal") or lower.endswith("_hex"))
        if is_raw and (policy.include_raw_permission_values or (is_unknown and policy.include_unknown_bits)):
            lines.append(_safe_presentation_text(f"{key}={_canonical_value(source[key])}", include_ids=include_ids, markdown=markdown))
    return tuple(lines)


def _build_sections(
    output: ExplanationOutput,
    source: Mapping[str, Any],
    profile: PresentationProfile,
    policy: DisclosurePolicy,
    selected_sections: Sequence[str],
    *,
    include_ids: bool,
    markdown: bool,
    query_fingerprint: str,
    adapter_result: AdaptedExplanationInput,
    integration_result: ExplanationIntegrationResult,
) -> tuple[dict[str, Any], ...]:
    sections: dict[str, tuple[str, ...]] = {
        "RESULT": (_text(output.short_answer),),
        "SUMMARY": (_text(output.summary),),
        "PRIMARY_REASON": (_text(output.primary_reason),),
        "SUPPORTING_REASONS": tuple(output.contributing_reasons) + tuple(output.applicable_permission_sources),
        "BLOCKERS": tuple(output.blocking_reasons),
        "UNCERTAINTIES": tuple(output.uncertainty_reasons),
        "BYPASS": tuple(output.bypass_reasons),
        "RAW_VERSUS_EFFECTIVE": tuple(output.raw_vs_effective) + _raw_lines(source, policy, include_ids=include_ids, markdown=markdown),
        "THREAD_STATE": _display_field_lines(
            source,
            tuple(key for key in sorted(source) if any(token in key.lower() for token in ("thread", "membership", "archived", "locked", "parent", "invitable", "unarchive"))),
            include_ids=include_ids,
            markdown=markdown,
        ),
        "AUTHORITY": _display_field_lines(
            source,
            ("target_type", "operation_key", "capability_permission", "target_authority", "hierarchy_result", "permission_subset_result", "managed_object_precondition"),
            include_ids=include_ids,
            markdown=markdown,
        ),
        "MFA": _display_field_lines(
            source,
            ("mfa_precondition", "mfa_state", "guild_mfa_level", "bot_installation_2fa"),
            include_ids=include_ids,
            markdown=markdown,
        ),
        "PRECONDITIONS": _display_field_lines(
            source,
            tuple(key for key in sorted(source) if "precondition" in key.lower()),
            include_ids=include_ids,
            markdown=markdown,
        ),
        "PRE_EXECUTION_DISCLAIMER": (output.pre_execution_disclaimer,) if output.pre_execution_disclaimer else (),
        "PROVENANCE": (),
        "TRACE": (),
    }
    provenance: list[str] = []
    if policy.include_contract_versions:
        provenance.extend(f"source_contract:{key}={value}" for key, value in sorted(output.source_stage3_contract_versions.items()))
        provenance.extend(
            (
                f"stage4_pass1_contract:{output.stage4_pass1_contract_version}",
                f"explanation_schema:{output.explanation_schema_version}",
                f"explanation_rules:{output.explanation_rules_version}",
                f"stage4_pass2_contract:{integration_result.stage4_pass2_contract_version}",
            )
        )
    if policy.include_registry_versions:
        provenance.extend(f"registry:{key}={value}" for key, value in sorted(output.registry_versions.items()))
    if policy.include_rule_ids:
        provenance.extend(f"rule_id:{value}" for value in output.source_rule_ids)
    if policy.include_source_references:
        provenance.extend(f"source_reference:{value}" for value in output.source_references)
    if policy.include_evidence_classifications:
        provenance.extend(f"evidence_classification:{value}" for value in source.get("evidence_classifications", ()))
    if policy.include_verification_statuses:
        provenance.extend(f"verification_status:{value}" for value in output.verification_statuses)
    if policy.include_fingerprints:
        provenance.extend(
            (
                f"query_fingerprint:{query_fingerprint}",
                f"source_result_fingerprint:{adapter_result.source_result_fingerprint}",
                f"source_trace_fingerprint:{adapter_result.source_trace_fingerprint}",
                f"adapter_fingerprint:{adapter_result.adapter_fingerprint}",
                f"explanation_fingerprint:{output.explanation_fingerprint}",
            )
        )
    if policy.include_ids:
        identity_lines = tuple(
            f"{field}:{getattr(output, field)}"
            for field in ("guild_id", "subject_id", "actor_id", "target_id", "context_id", "thread_id")
            if getattr(output, field) is not None
        )
        provenance.extend(identity_lines)
        if profile.profile_key in {"SIMPLE_CARD", "DISCORD_SAFE_SIMPLE"}:
            sections["SUMMARY"] = tuple(sections["SUMMARY"]) + identity_lines
    sections["PROVENANCE"] = tuple(provenance)
    if policy.include_trace_summary:
        trace_lines = [f"trace_event:{item.get('trace_event_id', item.get('adapter_trace_event_id'))}" for item in output.trace_references]
        if policy.include_full_trace:
            trace_lines.extend(_canonical_value(item) for item in output.trace_references)
        sections["TRACE"] = tuple(trace_lines)
    result: list[dict[str, Any]] = []
    for section_id in profile.section_order:
        if section_id not in selected_sections:
            continue
        values = _safe_lines(sections.get(section_id, ()), include_ids=include_ids, markdown=markdown)
        if values:
            result.append({"section_id": section_id, "title": section_id.replace("_", " ").title(), "lines": list(values)})
    return tuple(result)


def _mandatory_section_ids(output: ExplanationOutput, source: Mapping[str, Any]) -> set[str]:
    mandatory = {"RESULT", "PRIMARY_REASON"}
    if output.uncertainty_reasons or any(source.get(key) for key in ("material_uncertainties", "dependency_uncertainties", "missing_components", "unknown_capability_records")):
        mandatory.add("UNCERTAINTIES")
    if output.pre_execution_disclaimer:
        mandatory.add("PRE_EXECUTION_DISCLAIMER")
    return mandatory


def _render_section_lines(sections: Sequence[Mapping[str, Any]], *, markdown: bool, simple: bool) -> list[str]:
    lines: list[str] = []
    for section in sections:
        title = str(section["title"])
        values = [str(item) for item in section.get("lines", ())]
        if simple and section["section_id"] == "RESULT":
            continue
        if simple and section["section_id"] == "SUMMARY":
            lines.extend(values)
            continue
        if simple and section["section_id"] == "PRIMARY_REASON":
            lines.extend(f"Reason: {item}" for item in values)
            continue
        if markdown:
            lines.append(f"**{title}**")
        else:
            lines.append(f"{title}:")
        lines.extend(f"- {item}" for item in values)
    return lines


def _truncate_sections(
    sections: Sequence[Mapping[str, Any]],
    mandatory_ids: set[str],
    *,
    max_characters: int | None,
    max_lines: int | None,
    markdown: bool,
    simple: bool,
) -> tuple[tuple[dict[str, Any], ...], bool, int, int]:
    if max_characters is None and max_lines is None:
        return tuple(dict(item) for item in sections), False, 0, 0
    rendered = _render_section_lines(sections, markdown=markdown, simple=simple)
    if (max_characters is None or len("\n".join(rendered)) <= max_characters) and (max_lines is None or len(rendered) <= max_lines):
        return tuple(dict(item) for item in sections), False, 0, 0
    retained: list[dict[str, Any]] = []
    omitted_sections = 0
    omitted_lines = 0
    used_lines: list[str] = []

    def within(candidate: list[str]) -> bool:
        return (max_lines is None or len(candidate) <= max_lines) and (max_characters is None or len("\n".join(candidate)) <= max_characters)

    for section in sections:
        section_id = str(section["section_id"])
        if section_id in mandatory_ids:
            retained.append({"section_id": section_id, "title": section["title"], "lines": list(section.get("lines", ()))})
            used_lines.extend(_render_section_lines((section,), markdown=markdown, simple=False))
    for section in sections:
        section_id = str(section["section_id"])
        if section_id in mandatory_ids:
            continue
        candidate = {"section_id": section_id, "title": section["title"], "lines": list(section.get("lines", ()))}
        candidate_lines = _render_section_lines((candidate,), markdown=markdown, simple=False)
        if candidate_lines and within(used_lines + candidate_lines):
            retained.append(candidate)
            used_lines.extend(candidate_lines)
        else:
            omitted_sections += 1
            omitted_lines += len(candidate.get("lines", ()))
    if omitted_sections:
        marker = "Additional technical details omitted."
        if within(used_lines + [marker]):
            used_lines.append(marker)
        elif not used_lines:
            used_lines = [marker]
    order = {str(section["section_id"]): index for index, section in enumerate(sections)}
    retained.sort(key=lambda item: order.get(str(item["section_id"]), 999))
    return tuple(retained), True, omitted_sections, omitted_lines


@dataclass(frozen=True, slots=True)
class PresentationResult:
    presentation_profile_version: str
    profile_key: str
    output_format: str
    result_state: str
    headline: str
    ordered_sections: tuple[Mapping[str, Any], ...]
    ordered_lines: tuple[str, ...]
    plain_text: str | None
    discord_markdown: str | None
    structured_json: Mapping[str, Any] | None
    truncated: bool
    omitted_section_count: int
    omitted_line_count: int
    disclosure_policy: DisclosurePolicy
    disclosure_status: str
    mention_neutralization_status: str
    markdown_safety_status: str
    presentation_fingerprint: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "presentation_profile_version": self.presentation_profile_version,
            "profile_key": self.profile_key,
            "output_format": self.output_format,
            "result_state": self.result_state,
            "headline": self.headline,
            "ordered_sections": [_safe_json(item) for item in self.ordered_sections],
            "ordered_lines": list(self.ordered_lines),
            "plain_text": self.plain_text,
            "discord_markdown": self.discord_markdown,
            "structured_json": _safe_json(self.structured_json),
            "truncated": self.truncated,
            "omitted_section_count": self.omitted_section_count,
            "omitted_line_count": self.omitted_line_count,
            "disclosure_policy": self.disclosure_policy.as_dict(),
            "disclosure_status": self.disclosure_status,
            "mention_neutralization_status": self.mention_neutralization_status,
            "markdown_safety_status": self.markdown_safety_status,
            "presentation_fingerprint": self.presentation_fingerprint,
        }


def _build_presentation(
    query: ExplanationQuery,
    profile: PresentationProfile,
    policy: DisclosurePolicy,
    output: ExplanationOutput,
    source: Mapping[str, Any],
    adapter_result: AdaptedExplanationInput,
    integration_result: ExplanationIntegrationResult,
    query_fingerprint: str,
) -> PresentationResult:
    output_format = query.output_format or profile.default_output_format
    include_ids = policy.include_ids
    markdown = output_format == "DISCORD_MARKDOWN"
    selected = query.section_policy.include_sections or profile.section_order
    sections = _build_sections(
        output,
        source,
        profile,
        policy,
        selected,
        include_ids=include_ids,
        markdown=markdown,
        query_fingerprint=query_fingerprint,
        adapter_result=adapter_result,
        integration_result=integration_result,
    )
    if profile.profile_key in {"SIMPLE_CARD", "DISCORD_SAFE_SIMPLE"}:
        sections = tuple(
            dict(item, lines=list(item["lines"][:3])) if item["section_id"] == "SUPPORTING_REASONS" else dict(item)
            for item in sections
        )
    headline = _safe_presentation_text(
        f"{output.result_state}: {query.title}" if query.title else f"{output.result_state} — {output.short_answer}",
        include_ids=include_ids,
        markdown=markdown,
    )
    limits = dict(profile.max_characters and {"max_characters": profile.max_characters} or {})
    if profile.max_lines is not None:
        limits["max_lines"] = profile.max_lines
    limits.update({key: value for key, value in query.presentation_limits.items() if key in {"max_characters", "max_lines"}})
    if output_format == "STRUCTURED_JSON":
        effective_sections, truncated, omitted_sections, omitted_lines = sections, False, 0, 0
    else:
        # The headline is part of the bounded text output but is not a
        # section. Reserve its space before selecting sections so the final
        # serialization cannot exceed the requested/profile limit.
        headline_prefix = len(headline) + (4 if markdown else 0) + 1
        bounded_characters = limits.get("max_characters")
        bounded_lines = limits.get("max_lines")
        if bounded_characters is not None:
            bounded_characters = max(1, bounded_characters - headline_prefix)
        if bounded_lines is not None:
            bounded_lines = max(1, bounded_lines - 1)
        effective_sections, truncated, omitted_sections, omitted_lines = _truncate_sections(
            sections,
            _mandatory_section_ids(output, source),
            max_characters=bounded_characters,
            max_lines=bounded_lines,
            markdown=markdown,
            simple=profile.profile_key in {"SIMPLE_CARD", "DISCORD_SAFE_SIMPLE"},
        )
    simple = profile.profile_key in {"SIMPLE_CARD", "DISCORD_SAFE_SIMPLE"}
    lines = tuple(_render_section_lines(effective_sections, markdown=markdown, simple=simple))
    if output_format == "PLAIN_TEXT":
        plain_lines = [headline] + list(lines)
        plain_text = "\n".join(plain_lines)
        discord_markdown = None
        structured_json = None
    elif output_format == "DISCORD_MARKDOWN":
        discord_lines = [f"**{headline}**"] + list(lines)
        discord_markdown = "\n".join(discord_lines)
        plain_text = None
        structured_json = None
    else:
        plain_text = None
        discord_markdown = None
        structured_json = {
            "explanation": _safe_json(output.as_dict()),
            "query": query.as_dict(),
            "adapter": adapter_result.as_dict(),
            "integration": integration_result.as_dict(),
            "presentation": {
                "profile_key": profile.profile_key,
                "output_format": output_format,
                "disclosure_policy": policy.as_dict(),
                "ordered_sections": [_safe_json(item) for item in effective_sections],
                "truncated": False,
            },
        }
    payload = {
        "presentation_profile_version": PRESENTATION_PROFILE_VERSION,
        "profile_key": profile.profile_key,
        "output_format": output_format,
        "result_state": output.result_state,
        "headline": headline,
        "ordered_sections": [_safe_json(item) for item in effective_sections],
        "ordered_lines": list(lines),
        "plain_text": plain_text,
        "discord_markdown": discord_markdown,
        "structured_json": structured_json,
        "truncated": truncated,
        "omitted_section_count": omitted_sections,
        "omitted_line_count": omitted_lines,
        "disclosure_policy": policy.as_dict(),
    }
    return PresentationResult(
        presentation_profile_version=PRESENTATION_PROFILE_VERSION,
        profile_key=profile.profile_key,
        output_format=output_format,
        result_state=output.result_state,
        headline=headline,
        ordered_sections=tuple(dict(item) for item in effective_sections),
        ordered_lines=lines,
        plain_text=plain_text,
        discord_markdown=discord_markdown,
        structured_json=structured_json,
        truncated=truncated,
        omitted_section_count=omitted_sections,
        omitted_line_count=omitted_lines,
        disclosure_policy=policy,
        disclosure_status="APPLIED_DETERMINISTICALLY",
        mention_neutralization_status="PASS",
        markdown_safety_status="PASS" if markdown else "NOT_APPLICABLE",
        presentation_fingerprint=_fingerprint(payload),
    )


@dataclass(frozen=True, slots=True)
class ExplanationOrchestrationResult:
    stage4_pass3_contract_version: str
    query_contract_version: str
    orchestration_contract_version: str
    presentation_profile_version: str
    adapter_registry_version: str
    query_id: str | None
    query_type: str | None
    result_family: str | None
    explanation_mode: str | None
    presentation_profile: str | None
    output_format: str | None
    query_fingerprint: str | None
    source_result_fingerprint: str | None
    source_trace_fingerprint: str | None
    adapter_fingerprint: str | None
    explanation_fingerprint: str | None
    presentation_fingerprint: str | None
    orchestration_fingerprint: str
    query: ExplanationQuery | None
    adapter_result: AdaptedExplanationInput | None
    explanation_request: Any
    explanation_result: ExplanationOutput | None
    presentation_result: PresentationResult | None
    orchestration_completeness: str
    warnings: tuple[str, ...]
    errors: tuple[str, ...]
    missing_mandatory_evidence: tuple[str, ...]
    source_objects_unchanged: bool
    adapter_objects_unchanged: bool
    explanation_objects_unchanged: bool
    deterministic_provenance: Mapping[str, Any]

    @property
    def passed(self) -> bool:
        return not self.errors and self.orchestration_completeness == "COMPLETE" and self.presentation_result is not None

    def as_dict(self) -> dict[str, Any]:
        return {
            "stage4_pass3_contract_version": self.stage4_pass3_contract_version,
            "query_contract_version": self.query_contract_version,
            "orchestration_contract_version": self.orchestration_contract_version,
            "presentation_profile_version": self.presentation_profile_version,
            "adapter_registry_version": self.adapter_registry_version,
            "query_id": self.query_id,
            "query_type": self.query_type,
            "result_family": self.result_family,
            "explanation_mode": self.explanation_mode,
            "presentation_profile": self.presentation_profile,
            "output_format": self.output_format,
            "query_fingerprint": self.query_fingerprint,
            "source_result_fingerprint": self.source_result_fingerprint,
            "source_trace_fingerprint": self.source_trace_fingerprint,
            "adapter_fingerprint": self.adapter_fingerprint,
            "explanation_fingerprint": self.explanation_fingerprint,
            "presentation_fingerprint": self.presentation_fingerprint,
            "orchestration_fingerprint": self.orchestration_fingerprint,
            "query": None if self.query is None else self.query.as_dict(),
            "adapter_result": None if self.adapter_result is None else self.adapter_result.as_dict(),
            "explanation_request": _safe_json(self.explanation_request),
            "explanation_result": None if self.explanation_result is None else _safe_json(self.explanation_result.as_dict()),
            "presentation_result": None if self.presentation_result is None else self.presentation_result.as_dict(),
            "orchestration_completeness": self.orchestration_completeness,
            "warnings": list(self.warnings),
            "errors": list(self.errors),
            "missing_mandatory_evidence": list(self.missing_mandatory_evidence),
            "source_objects_unchanged": self.source_objects_unchanged,
            "adapter_objects_unchanged": self.adapter_objects_unchanged,
            "explanation_objects_unchanged": self.explanation_objects_unchanged,
            "deterministic_provenance": _safe_json(self.deterministic_provenance),
            "passed": self.passed,
        }


def _invalid_result(query: ExplanationQuery | None, errors: Sequence[str], *, strict: bool) -> ExplanationOrchestrationResult:
    if strict:
        raise ExplanationOrchestrationError("; ".join(errors))
    payload = {
        "stage4_pass3_contract_version": STAGE4_PASS3_CONTRACT_VERSION,
        "query_id": query.query_id if query else None,
        "errors": list(errors),
    }
    return ExplanationOrchestrationResult(
        stage4_pass3_contract_version=STAGE4_PASS3_CONTRACT_VERSION,
        query_contract_version=query.query_contract_version if query else EXPLANATION_QUERY_CONTRACT_VERSION,
        orchestration_contract_version=EXPLANATION_ORCHESTRATION_VERSION,
        presentation_profile_version=PRESENTATION_PROFILE_VERSION,
        adapter_registry_version=EXPLANATION_ADAPTERS_VERSION,
        query_id=query.query_id if query else None,
        query_type=query.query_type if query else None,
        result_family=query.result_family if query else None,
        explanation_mode=None,
        presentation_profile=query.presentation_profile if query else None,
        output_format=None,
        query_fingerprint=_fingerprint(query.as_dict(include_source=False)) if query else None,
        source_result_fingerprint=None,
        source_trace_fingerprint=None,
        adapter_fingerprint=None,
        explanation_fingerprint=None,
        presentation_fingerprint=None,
        orchestration_fingerprint=_fingerprint(payload),
        query=query,
        adapter_result=None,
        explanation_request=None,
        explanation_result=None,
        presentation_result=None,
        orchestration_completeness="UNKNOWN",
        warnings=(),
        errors=tuple(dict.fromkeys(str(item) for item in errors)),
        missing_mandatory_evidence=tuple(item for item in errors if "MISSING" in item or "INVALID" in item),
        source_objects_unchanged=True,
        adapter_objects_unchanged=True,
        explanation_objects_unchanged=True,
        deterministic_provenance={"representation_only": True, "rendering_performed": False},
    )


def orchestrate_explanation(
    query: ExplanationQuery | Mapping[str, Any],
    *,
    strict: bool = False,
) -> ExplanationOrchestrationResult:
    """Run the explicit query -> adapter -> Pass 1 -> profile pipeline."""

    parsed: ExplanationQuery | None
    try:
        parsed = query if isinstance(query, ExplanationQuery) else ExplanationQuery.from_mapping(query)
    except (ExplanationQueryError, TypeError, ValueError) as exc:
        return _invalid_result(None, (f"{ORCHESTRATION_RULE_QUERY}:{exc}",), strict=strict)
    violations = validate_explanation_query(parsed)
    if violations:
        return _invalid_result(parsed, violations, strict=strict)
    profile = get_presentation_profile(parsed.presentation_profile)
    if profile is None:
        return _invalid_result(parsed, ("PRESENTATION_PROFILE_UNKNOWN",), strict=strict)
    selected_mode = parsed.explanation_mode or profile.default_mode
    selected_format = parsed.output_format or profile.default_output_format
    policy = parsed.disclosure_policy or profile.default_disclosure
    query_fingerprint = _fingerprint(parsed.as_dict(include_source=False))
    source_before = _safe_json(parsed.source_result)
    record = QUERY_REGISTRY_BY_TYPE[parsed.query_type]
    if record.result_family != parsed.result_family or record.source_contract != parsed.source_contract:
        return _invalid_result(parsed, (ORCHESTRATION_RULE_ADAPTER + ":ADAPTER_SELECTION_MISMATCH",), strict=strict)
    try:
        adapter_result = adapt_stage3_result(
            Stage3ExplanationAdapterRequest(
                source_result=parsed.source_result,
                source_trace=parsed.source_trace,
                result_family=parsed.result_family,
                source_contract=parsed.source_contract,
                mode=selected_mode,
                labels=parsed.labels,
                source_stage3_contract_versions=parsed.source_stage3_contract_versions,
                permission_definition_version=parsed.permission_definition_version,
                registry_versions=parsed.registry_versions,
                evidence_classifications=parsed.evidence_classifications,
                verification_statuses=parsed.verification_statuses,
                source_references=parsed.source_references,
                guild_id=parsed.guild_id,
                subject_id=parsed.subject_id,
                actor_id=parsed.actor_id,
                target_id=parsed.target_id,
                context_id=parsed.context_id,
                thread_id=parsed.thread_id,
                include_ids_in_simple=policy.include_ids,
                include_raw_bits_in_detailed=policy.include_raw_permission_values,
                include_full_trace_in_technical=policy.include_full_trace,
                authoritative_closure=parsed.authoritative_closure,
                historical_evidence=parsed.historical_evidence,
            )
        )
        adapter_before = adapter_result.as_dict()
        integration_result = integrate_stage3_result(
            parsed.source_result,
            result_family=parsed.result_family,
            source_contract=parsed.source_contract,
            source_trace=parsed.source_trace,
            mode=selected_mode,
            labels=parsed.labels,
            source_stage3_contract_versions=parsed.source_stage3_contract_versions,
            permission_definition_version=parsed.permission_definition_version,
            registry_versions=parsed.registry_versions,
            evidence_classifications=parsed.evidence_classifications,
            verification_statuses=parsed.verification_statuses,
            source_references=parsed.source_references,
            guild_id=parsed.guild_id,
            subject_id=parsed.subject_id,
            actor_id=parsed.actor_id,
            target_id=parsed.target_id,
            context_id=parsed.context_id,
            thread_id=parsed.thread_id,
            include_ids_in_simple=policy.include_ids,
            include_raw_bits_in_detailed=policy.include_raw_permission_values,
            include_full_trace_in_technical=policy.include_full_trace,
            authoritative_closure=parsed.authoritative_closure,
            historical_evidence=parsed.historical_evidence,
        )
    except Exception as exc:
        return _invalid_result(parsed, (f"{ORCHESTRATION_RULE_ADAPTER}:{type(exc).__name__}:{exc}",), strict=strict)
    errors = list(integration_result.integration_errors)
    warnings = list(integration_result.integration_warnings)
    if errors or integration_result.explanation_output is None:
        return _invalid_result(parsed, errors or ("EXPLANATION_RESULT_MISSING",), strict=strict)
    explanation = integration_result.explanation_output
    explanation_before = _safe_json(explanation.as_dict())
    source = _source_mapping(parsed.source_result)
    try:
        presentation = _build_presentation(
            parsed,
            profile,
            policy,
            explanation,
            source,
            adapter_result,
            integration_result,
            query_fingerprint,
        )
    except Exception as exc:
        return _invalid_result(parsed, (f"{ORCHESTRATION_RULE_PRESENTATION}:{type(exc).__name__}:{exc}",), strict=strict)
    adapter_unchanged = adapter_before == adapter_result.as_dict()
    explanation_unchanged = explanation_before == _safe_json(explanation.as_dict())
    source_unchanged = source_before == _safe_json(parsed.source_result)
    provenance = {
        "query_type": parsed.query_type,
        "selected_adapter_key": record.adapter_key,
        "source_contract": parsed.source_contract,
        "renderer": "guild_doctor_scanner.explanation_engine.render_explanation",
        "presentation_profile": profile.profile_key,
        "output_format": selected_format,
        "disclosure_policy": policy.as_dict(),
        "source_objects_unchanged": source_unchanged,
        "adapter_objects_unchanged": adapter_unchanged,
        "explanation_objects_unchanged": explanation_unchanged,
        "closure": integration_result.deterministic_provenance.get("closure", {}),
        "representation_only": True,
    }
    orchestration_payload = {
        "stage4_pass3_contract_version": STAGE4_PASS3_CONTRACT_VERSION,
        "query_contract_version": EXPLANATION_QUERY_CONTRACT_VERSION,
        "orchestration_contract_version": EXPLANATION_ORCHESTRATION_VERSION,
        "query_fingerprint": query_fingerprint,
        "source_result_fingerprint": integration_result.source_result_fingerprint,
        "source_trace_fingerprint": integration_result.source_trace_fingerprint,
        "adapter_fingerprint": adapter_result.adapter_fingerprint,
        "explanation_fingerprint": explanation.explanation_fingerprint,
        "presentation_fingerprint": presentation.presentation_fingerprint,
        "provenance": provenance,
    }
    return ExplanationOrchestrationResult(
        stage4_pass3_contract_version=STAGE4_PASS3_CONTRACT_VERSION,
        query_contract_version=EXPLANATION_QUERY_CONTRACT_VERSION,
        orchestration_contract_version=EXPLANATION_ORCHESTRATION_VERSION,
        presentation_profile_version=PRESENTATION_PROFILE_VERSION,
        adapter_registry_version=EXPLANATION_ADAPTERS_VERSION,
        query_id=parsed.query_id,
        query_type=parsed.query_type,
        result_family=parsed.result_family,
        explanation_mode=selected_mode,
        presentation_profile=profile.profile_key,
        output_format=selected_format,
        query_fingerprint=query_fingerprint,
        source_result_fingerprint=integration_result.source_result_fingerprint,
        source_trace_fingerprint=integration_result.source_trace_fingerprint,
        adapter_fingerprint=adapter_result.adapter_fingerprint,
        explanation_fingerprint=explanation.explanation_fingerprint,
        presentation_fingerprint=presentation.presentation_fingerprint,
        orchestration_fingerprint=_fingerprint(orchestration_payload),
        query=parsed,
        adapter_result=adapter_result,
        explanation_request=integration_result.explanation_request,
        explanation_result=explanation,
        presentation_result=presentation,
        orchestration_completeness="COMPLETE",
        warnings=tuple(dict.fromkeys(warnings)),
        errors=(),
        missing_mandatory_evidence=(),
        source_objects_unchanged=source_unchanged,
        adapter_objects_unchanged=adapter_unchanged,
        explanation_objects_unchanged=explanation_unchanged,
        deterministic_provenance=provenance,
    )


run_explanation_orchestration = orchestrate_explanation


__all__ = [
    "ExplanationOrchestrationError",
    "ExplanationOrchestrationResult",
    "ORCHESTRATION_RULE_ADAPTER",
    "ORCHESTRATION_RULE_DISCLOSURE",
    "ORCHESTRATION_RULE_PRESENTATION",
    "ORCHESTRATION_RULE_QUERY",
    "ORCHESTRATION_RULE_SAFETY",
    "ORCHESTRATION_RULE_TRUNCATION",
    "PresentationResult",
    "STAGE4_PASS3_CONTRACT_VERSION",
    "orchestrate_explanation",
    "run_explanation_orchestration",
]
