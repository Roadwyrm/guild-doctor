"""One-shot, REST-only writer for the designated Pass 5 interaction snapshot."""
from __future__ import annotations

import argparse, asyncio, json, os, sys, tempfile
from pathlib import Path

from .acquisition import ReadOnlyAcquisitionAdapter
from .canonical import canonical_json
from .discord_exact_id_bridge import resolve_exact
from .discord_normalized_snapshot_loader import load_authorized_normalized_snapshot
from .discord_secure_token import HiddenTokenProvider
from .discordpy_adapter import DiscordPyReadTransport

TARGET_GUILD_ID = "1450145794224033804"
MARKER = "STAGE6_PASS5_DISPOSABLE_GUILD_ONLY"
OUTPUT = Path("stage6-pass5-evidence/authorized_normalized_snapshot.json")

def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Guild Doctor read-only Pass 5 snapshot acquisition")
    p.add_argument("--guild-id", required=True); p.add_argument("--network-enabled", action="store_true")
    return p

def _write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False, suffix=".tmp") as stream:
        stream.write(canonical_json(data) + "\n"); temporary = Path(stream.name)
    try: os.replace(temporary, path)
    finally: temporary.unlink(missing_ok=True)

async def acquire(*, root: Path, guild_id: str, token_provider=None) -> tuple[int, dict]:
    report = {"marker": MARKER, "guild_target": "DISPOSABLE_GUILD", "guild_id_confirmed": guild_id == TARGET_GUILD_ID, "scanner_mode": "READ_ONLY", "synchronization_count": 0, "discord_write_count": 0, "gateway_connection_count": 0, "token_redacted": True, "raw_payload_retained": False, "permitted_get_templates": ["/users/@me", "/guilds/{guild_id}", "/guilds/{guild_id}/roles", "/guilds/{guild_id}/channels", "/guilds/{guild_id}/threads/active"]}
    if guild_id != TARGET_GUILD_ID: return 10, {**report, "status":"FAIL", "stable_error":"PASS5_GUILD_SCOPE_INVALID"}
    if not (root / "pyproject.toml").is_file() or not (root / ".venv/Scripts/python.exe").is_file(): return 19, {**report, "status":"FAIL", "stable_error":"PASS5_AUTHORITATIVE_CHECKOUT_INVALID"}
    token = None; temporary: Path | None = None
    try:
        import discord
        token = (token_provider or HiddenTokenProvider()).get()
        client = discord.Client(intents=discord.Intents.none(), max_messages=None)
        async with client:
            await client.login(token)
            acquisition = await ReadOnlyAcquisitionAdapter(DiscordPyReadTransport.from_client(client)).acquire_structure(guild_id)
        if acquisition.snapshot is None: return 2, {**report, "status":"FAIL", "stable_error":"PASS5_NORMALIZATION_FAILED"}
        output = root / OUTPUT; temporary = output.with_suffix(".candidate.json")
        _write(temporary, acquisition.snapshot.as_dict())
        loaded = load_authorized_normalized_snapshot(path=temporary, guild_id=guild_id)
        if not loaded.loaded: return 2, {**report, "status":"FAIL", "loader_outcome":loaded.outcome}
        role = next(iter(loaded.roles_by_id), None); category = next(iter(loaded.categories_by_id), None); channel = next(iter(loaded.channels_by_id), None)
        bridge = {"role": resolve_exact(loaded, kind="ROLE", selected=role, guild_id=guild_id).outcome if role else "NOT_AVAILABLE", "category": resolve_exact(loaded, kind="CATEGORY", selected=category, guild_id=guild_id).outcome if category else "NOT_AVAILABLE", "channel": resolve_exact(loaded, kind="CHANNEL", selected=channel, guild_id=guild_id).outcome if channel else "NOT_AVAILABLE"}
        os.replace(temporary, output)
        collections = acquisition.snapshot.collections
        return 0, {**report, "status":"PASS", "loader_outcome":loaded.outcome, "snapshot_fingerprint": acquisition.snapshot.snapshot_fingerprint_sha256, "atomic_write":"PASS", "request_count":4, "exact_id_bridge":bridge, "roles_discovered":len(loaded.roles_by_id), "channels_discovered":len(loaded.channels_by_id), "categories_discovered":len(loaded.categories_by_id), "active_threads_discovered":len(acquisition.snapshot.threads or {}), "member_data_state":acquisition.snapshot.member_completeness, "population_completeness":acquisition.snapshot.member_completeness, "active_thread_completeness":acquisition.snapshot.thread_completeness, "client_cleanup":"CLOSED"}
    except Exception as exc:
        return 1, {**report, "status":"FAIL", "stable_error":"PASS5_SNAPSHOT_ACQUISITION_FAILED", "exception_category":type(exc).__name__}
    finally:
        token = None
        if temporary is not None: temporary.unlink(missing_ok=True)

def main(argv=None) -> int:
    args = _parser().parse_args(argv)
    if not args.network_enabled: print("NetworkEnabled is required.", file=sys.stderr); return 10
    root = Path.cwd().resolve(); code, report = asyncio.run(acquire(root=root, guild_id=args.guild_id));
    evidence = root / "stage6-pass5-evidence" / "snapshot_acquisition_report.json"; evidence.parent.mkdir(exist_ok=True); evidence.write_text(json.dumps(report, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print(json.dumps({key:value for key,value in report.items() if key not in {"guild_id"}}, indent=2, sort_keys=True)); return code
if __name__ == "__main__": raise SystemExit(main())
