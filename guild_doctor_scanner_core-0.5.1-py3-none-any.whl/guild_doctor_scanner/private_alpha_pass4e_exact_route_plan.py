"""Process-local exact route-plan admission for the bounded Pass 4E session.

This module deliberately retains no Discord identifiers or option values.  It
receives the already-symbolic intake projection and makes every terminal
coverage decision from frozen public route names and canonical option keys.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from threading import RLock
from typing import Iterable


EXACT_ROUTE_PLAN_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-REPAIR4C-EXACT-ROUTE-PLAN-0.1"
EXACT_ROUTE_PLAN = (
    ("compare-role-permission", "permission", "VIEW_CHANNEL", "COMPARISON_RESULT", None),
    ("compare-role-capability", "capability", "message.send", "COMPARISON_RESULT", None),
    ("compare-role-action", "action", "member.kick", "ERROR_RESULT", "STAGE6_ACTION_CONTEXT_REQUIRED"),
    ("server-report", None, None, "REPORT_RESULT", None),
)
EXACT_ROUTE_NAMES = tuple(item[0] for item in EXACT_ROUTE_PLAN)
_CANONICAL_VALUES = frozenset(item[2] for item in EXACT_ROUTE_PLAN if item[2] is not None)
_CANONICAL_LABELS = {
    "VIEW_CHANNEL": "View Channel",
    "message.send": "Message Send",
    "member.kick": "Member Kick",
}


def exact_route_plan_fingerprint() -> str:
    payload = json.dumps({"contract": EXACT_ROUTE_PLAN_CONTRACT, "routes": EXACT_ROUTE_PLAN}, separators=(",", ":"), sort_keys=True)
    return sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class RoutePlanDecision:
    accepted: bool
    stable_error: str | None
    route_name: str | None


class ExactRoutePlan:
    """Concurrency-safe, fail-closed plan with transient symbolic pair binding."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._states = {name: "PENDING" for name in EXACT_ROUTE_NAMES}
        self._pair: tuple[str, str] | None = None
        self._route_plan_rejections = 0
        self._duplicates = 0
        self._canonical_rejections = 0
        self._unexpected = 0
        self._role_pair_rejections = 0
        self._malformed_rejections = 0
        self._last_rejection_classification: str | None = None

    def _reject(self, category: str, code: str, route_name: str | None) -> RoutePlanDecision:
        self._route_plan_rejections += 1
        self._last_rejection_classification = code
        if category == "DUPLICATE":
            self._duplicates += 1
        elif category == "CANONICAL":
            self._canonical_rejections += 1
        elif category == "UNEXPECTED":
            self._unexpected += 1
        elif category == "ROLE_PAIR":
            self._role_pair_rejections += 1
        else:
            self._malformed_rejections += 1
        return RoutePlanDecision(False, code, route_name)

    def record_malformed_invocation(self, classification: str) -> None:
        """Account for intake failures without retaining submitted values."""
        with self._lock:
            self._reject("MALFORMED", classification, None)

    def record_role_pair_rejection(self, classification: str) -> None:
        """Account for a process-only pair guard without retaining identities."""
        with self._lock:
            self._reject("ROLE_PAIR", classification, None)

    @staticmethod
    def _canonical_error(value: object, canonical: str) -> str | None:
        if not isinstance(value, str):
            return "STAGE8_PASS4E_ROUTE_PLAN_CANONICAL_OPTION_TYPE_INVALID"
        if value == "":
            return "STAGE8_PASS4E_ROUTE_PLAN_CANONICAL_OPTION_EMPTY"
        if value != value.strip():
            return "STAGE8_PASS4E_ROUTE_PLAN_CANONICAL_OPTION_WHITESPACE"
        if value == canonical:
            return None
        if value == _CANONICAL_LABELS.get(canonical):
            return None
        if value.casefold() == canonical.casefold():
            return "STAGE8_PASS4E_ROUTE_PLAN_CANONICAL_OPTION_WRONG_CASE"
        if canonical in value or value.endswith(f"({canonical})"):
            return "STAGE8_PASS4E_ROUTE_PLAN_CANONICAL_OPTION_DISPLAY_LABEL_SUPPLIED"
        if value in _CANONICAL_VALUES:
            return "STAGE8_PASS4E_ROUTE_PLAN_CANONICAL_OPTION_FAMILY_MISMATCH"
        return "STAGE8_PASS4E_ROUTE_PLAN_CANONICAL_OPTION_UNKNOWN_VALUE"

    def admit(self, route_name: str, options: Iterable[tuple[str, str]], *, selections_present: bool) -> RoutePlanDecision:
        with self._lock:
            try:
                pairs = tuple(options)
            except (TypeError, ValueError):
                return self._reject("MALFORMED", "STAGE8_PASS4E_ROUTE_PLAN_INVOCATION_MALFORMED", route_name)
            if any(not isinstance(item, tuple) or len(item) != 2 or not isinstance(item[0], str) for item in pairs):
                return self._reject("MALFORMED", "STAGE8_PASS4E_ROUTE_PLAN_INVOCATION_MALFORMED", route_name)
            keys = tuple(item[0] for item in pairs)
            if len(set(keys)) != len(keys):
                return self._reject("MALFORMED", "STAGE8_PASS4E_ROUTE_PLAN_INVOCATION_MALFORMED", route_name)
            values = dict(pairs)
            if route_name not in self._states:
                return self._reject("UNEXPECTED", "STAGE8_PASS4E_ROUTE_PLAN_UNEXPECTED_ROUTE", route_name)
            if self._states[route_name] != "PENDING":
                return self._reject("DUPLICATE", "STAGE8_PASS4E_ROUTE_PLAN_DUPLICATE_ROUTE", route_name)
            required = next(item for item in EXACT_ROUTE_PLAN if item[0] == route_name)
            _, option_name, canonical, _, _ = required
            if option_name is None:
                if values:
                    return self._reject("MALFORMED", "STAGE8_PASS4E_ROUTE_PLAN_SERVER_REPORT_OPTIONS_INVALID", route_name)
            else:
                expected_keys = {"first-role", "second-role", option_name}
                if set(values) != expected_keys:
                    code = (
                        "STAGE8_PASS4E_ROUTE_PLAN_CANONICAL_OPTION_MISSING"
                        if option_name not in values
                        else "STAGE8_PASS4E_ROUTE_PLAN_CANONICAL_OPTION_FIELD_MISMATCH"
                    )
                    return self._reject("MALFORMED", code, route_name)
                canonical_error = self._canonical_error(values[option_name], canonical)
                if canonical_error is not None:
                    return self._reject("CANONICAL", canonical_error, route_name)
            if route_name != "server-report":
                pair = (values.get("first-role", ""), values.get("second-role", ""))
                if not selections_present or pair != ("ROLE_ALPHA", "ROLE_BETA"):
                    return self._reject("ROLE_PAIR", "STAGE8_PASS4E_ROUTE_PLAN_ROLE_PAIR_INVALID", route_name)
                if self._pair is None:
                    self._pair = pair
                elif self._pair != pair:
                    return self._reject("ROLE_PAIR", "STAGE8_PASS4E_ROUTE_PLAN_ROLE_PAIR_INCONSISTENT", route_name)
            self._states[route_name] = "IN_PROGRESS"
            return RoutePlanDecision(True, None, route_name)

    def complete(self, route_name: str, *, envelope_branch: str | None, stable_error: str | None) -> RoutePlanDecision:
        with self._lock:
            required = next((item for item in EXACT_ROUTE_PLAN if item[0] == route_name), None)
            if required is None or self._states.get(route_name) != "IN_PROGRESS":
                return RoutePlanDecision(False, "STAGE8_PASS4E_ROUTE_PLAN_COMPLETION_INVALID", route_name)
            _, _, _, expected_branch, expected_error = required
            if envelope_branch != expected_branch or stable_error != expected_error:
                self._states[route_name] = "PENDING"
                return RoutePlanDecision(False, "STAGE8_PASS4E_ROUTE_PLAN_OUTCOME_INVALID", route_name)
            self._states[route_name] = "COMPLETED"
            return RoutePlanDecision(True, None, route_name)

    @property
    def all_required_routes_completed(self) -> bool:
        with self._lock:
            return all(state == "COMPLETED" for state in self._states.values())

    def public_value(self) -> dict[str, object]:
        with self._lock:
            return {
                "exact_route_plan_contract": EXACT_ROUTE_PLAN_CONTRACT,
                "exact_route_plan_fingerprint": exact_route_plan_fingerprint(),
                "exact_route_plan_validated": True,
                "all_required_routes_completed": self.all_required_routes_completed,
                "route_plan_rejection_count": self._route_plan_rejections,
                "duplicate_route_admission_count": self._duplicates,
                "canonical_option_rejection_count": self._canonical_rejections,
                "unexpected_route_admission_count": self._unexpected,
                "unexpected_route_rejection_count": self._unexpected,
                "role_pair_rejection_count": self._role_pair_rejections,
                "malformed_invocation_rejection_count": self._malformed_rejections,
                "last_route_plan_rejection_classification": self._last_rejection_classification,
                "pair_established": self._pair is not None,
                "pair_consistent": True,
                "routes": [{"route_name": name, "state": self._states[name]} for name in EXACT_ROUTE_NAMES],
            }


__all__ = ["EXACT_ROUTE_NAMES", "EXACT_ROUTE_PLAN", "EXACT_ROUTE_PLAN_CONTRACT", "ExactRoutePlan", "RoutePlanDecision", "exact_route_plan_fingerprint"]
