"""discord.py runtime for Stage 2 owner-only read-only commands."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from .acquisition import ReadOnlyAcquisitionAdapter
from .commands import GuildDoctorCommandGroupFactory, GuildDoctorCommandService
from .discordpy_adapter import DiscordPyReadTransport
from .persistence import SQLiteSnapshotRepository


def build_runtime_intents() -> Any:
    """Return minimal intents for guild-scoped application commands.

    No message content, member, or presence privileged intent is enabled.
    """

    import discord

    intents = discord.Intents.none()
    intents.guilds = True
    return intents


class GuildDoctorRuntimeClient:
    """Factory namespace used to avoid importing discord.py at package import time."""

    @staticmethod
    def create(
        *,
        database_path: str | Path,
        sync_commands: bool = False,
        sync_guild_id: int | None = None,
    ) -> Any:
        import discord
        from discord import app_commands

        repository = SQLiteSnapshotRepository(database_path)

        class RuntimeClient(discord.Client):
            def __init__(self) -> None:
                super().__init__(intents=build_runtime_intents(), max_messages=None)
                self.tree = app_commands.CommandTree(self)
                self.guild_doctor_repository = repository

            async def setup_hook(self) -> None:
                await self.guild_doctor_repository.initialize()
                transport = DiscordPyReadTransport.from_client(self)
                scanner = ReadOnlyAcquisitionAdapter(transport)
                service = GuildDoctorCommandService(scanner, self.guild_doctor_repository)

                async def owner_lookup(guild_id: int) -> int:
                    payload = await transport.read_guild(guild_id)
                    owner = payload.get("owner_id")
                    if owner is None or not str(owner).isdigit():
                        raise RuntimeError("guild owner ID is unavailable")
                    return int(owner)

                self.tree.add_command(GuildDoctorCommandGroupFactory.create(service, owner_lookup))

                if sync_commands:
                    if sync_guild_id is not None:
                        guild = discord.Object(id=sync_guild_id)
                        self.tree.copy_global_to(guild=guild)
                        await self.tree.sync(guild=guild)
                    else:
                        await self.tree.sync()

        return RuntimeClient()


def runtime_from_environment() -> tuple[Any, str]:
    token = os.environ.get("GUILD_DOCTOR_DISCORD_TOKEN")
    if not token:
        raise RuntimeError("GUILD_DOCTOR_DISCORD_TOKEN is not set")

    database = os.environ.get("GUILD_DOCTOR_SNAPSHOT_DB", "data/guild_doctor_snapshots.sqlite3")
    sync = os.environ.get("GUILD_DOCTOR_SYNC_COMMANDS", "0").strip().lower() in {"1", "true", "yes", "on"}
    sync_guild_raw = os.environ.get("GUILD_DOCTOR_COMMAND_SYNC_GUILD_ID")
    sync_guild = None
    if sync_guild_raw:
        if not sync_guild_raw.isdigit() or int(sync_guild_raw) <= 0:
            raise RuntimeError("GUILD_DOCTOR_COMMAND_SYNC_GUILD_ID must be a positive Discord snowflake")
        sync_guild = int(sync_guild_raw)

    client = GuildDoctorRuntimeClient.create(
        database_path=database,
        sync_commands=sync,
        sync_guild_id=sync_guild,
    )
    return client, token
