"""Deterministic privacy-minimized Stage 3 fixture export."""

from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from .canonical import canonical_json

STAGE3_FIXTURE_VERSION = "GUILD-DOCTOR-STAGE3-FIXTURE-0.1"


@dataclass(frozen=True, slots=True)
class FixtureExport:
    fixture: dict[str, Any]
    sha256: str


def export_stage3_fixture(snapshot: Any, *, anonymize: bool = True) -> FixtureExport:
    data = snapshot.as_dict() if hasattr(snapshot, "as_dict") else deepcopy(snapshot)
    if not isinstance(data, dict):
        raise TypeError("snapshot must be a mapping or expose as_dict()")
    if not data.get("structural_fingerprint_sha256"):
        raise ValueError("snapshot must contain a structural fingerprint")

    fixture = {
        "fixture_version": STAGE3_FIXTURE_VERSION,
        "source": {
            "snapshot_schema_version": data.get("schema_version"),
            "scanner_contract_version": data.get("scanner_contract_version"),
            "permission_definition_version": data.get("permission_definition_version"),
            "source_structural_fingerprint_sha256": data.get("structural_fingerprint_sha256"),
            "source_structural_completeness": data.get("structural_completeness"),
            "source_thread_completeness": data.get("thread_completeness"),
        },
        "guild": _guild_record(data.get("guild")),
        "roles": _roles(data.get("roles")),
        "channels": _channels(data.get("channels")),
        "threads": _threads(data.get("threads")),
        "bindings": _bindings(data.get("bindings")),
        "export_policy": {
            "message_content_included": False,
            "member_profiles_included": False,
            "display_names_included": False,
            "source_payload_hashes_included": False,
            "volatile_timestamps_included": False,
            "anonymized_ids": bool(anonymize),
        },
    }

    if anonymize:
        fixture = _anonymize_fixture(fixture)

    encoded = canonical_json(fixture).encode("utf-8")
    digest = hashlib.sha256(encoded).hexdigest()
    fixture["fixture_sha256"] = digest
    return FixtureExport(fixture=fixture, sha256=digest)


def _guild_record(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    return {
        "id": value.get("id"),
        "owner_id": value.get("owner_id"),
        "mfa_level": value.get("mfa_level"),
        "features": sorted(value.get("features") or []),
    }


def _roles(value: Any) -> list[dict[str, Any]] | None:
    if not isinstance(value, dict):
        return None
    output = []
    for role in value.values():
        output.append(
            {
                "id": role.get("id"),
                "position": role.get("position"),
                "permissions_decimal": role.get("permissions_decimal"),
                "managed": role.get("managed"),
                "is_everyone": role.get("is_everyone"),
                "role_tags": role.get("role_tags"),
            }
        )
    return sorted(output, key=lambda item: int(str(item["id"])))


def _channels(value: Any) -> list[dict[str, Any]] | None:
    if not isinstance(value, dict):
        return None
    output = []
    for channel in value.values():
        output.append(
            {
                "id": channel.get("id"),
                "type_code": channel.get("type_code"),
                "type_key": channel.get("type_key"),
                "position": channel.get("position"),
                "parent_id": channel.get("parent_id"),
                "flags_decimal": channel.get("flags_decimal"),
                "permission_overwrites": [
                    {
                        "target_id": item.get("target_id"),
                        "target_type": item.get("target_type"),
                        "allow_decimal": item.get("allow_decimal"),
                        "deny_decimal": item.get("deny_decimal"),
                    }
                    for item in channel.get("permission_overwrites", [])
                ],
                "sync_state": channel.get("sync_state"),
                "sync_parent_id": channel.get("sync_parent_id"),
            }
        )
    return sorted(output, key=lambda item: int(str(item["id"])))


def _threads(value: Any) -> list[dict[str, Any]] | None:
    if not isinstance(value, dict):
        return None
    output = []
    for thread in value.values():
        output.append(
            {
                "id": thread.get("id"),
                "parent_id": thread.get("parent_id"),
                "owner_id": thread.get("owner_id"),
                "type_code": thread.get("type_code"),
                "type_key": thread.get("type_key"),
                "archived": thread.get("archived"),
                "locked": thread.get("locked"),
                "invitable": thread.get("invitable"),
                "applied_tag_ids": thread.get("applied_tag_ids") or [],
                "source_scope": thread.get("source_scope"),
            }
        )
    return sorted(output, key=lambda item: int(str(item["id"])))


def _bindings(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return sorted(
        [
            {
                "role_id": item.get("role_id"),
                "binding_type": item.get("binding_type"),
                "external_id": item.get("external_id"),
                "confidence": item.get("confidence"),
            }
            for item in value
        ],
        key=lambda item: (str(item.get("role_id")), str(item.get("binding_type"))),
    )


def _anonymize_fixture(fixture: dict[str, Any]) -> dict[str, Any]:
    data = deepcopy(fixture)
    ids: set[str] = set()

    def collect(value: Any, key: str | None = None) -> None:
        if isinstance(value, dict):
            for child_key, child in value.items():
                collect(child, child_key)
        elif isinstance(value, list):
            for child in value:
                collect(child, key)
        elif key and (key == "id" or key.endswith("_id") or key.endswith("_ids")) and value is not None:
            text = str(value)
            if text.isdecimal():
                ids.add(text)

    collect(data)
    mapping = {
        original: str(900000000000000000 + index)
        for index, original in enumerate(sorted(ids, key=int), start=1)
    }

    def rewrite(value: Any, key: str | None = None) -> Any:
        if isinstance(value, dict):
            return {child_key: rewrite(child, child_key) for child_key, child in value.items()}
        if isinstance(value, list):
            if key and key.endswith("_ids"):
                return [mapping.get(str(child), child) for child in value]
            return [rewrite(child, key) for child in value]
        if key and (key == "id" or key.endswith("_id")) and value is not None:
            return mapping.get(str(value), value)
        return value

    return rewrite(data)
