"""Immutable Stage 3 Pass 6 action rules.

The registry describes only actions already represented by Pass 3, Pass 4, or
Pass 5 evidence.  It contains no Discord client, transport, persistence, or
mutation dependency.  The orchestrator consumes this data and never treats a
modeled result as proof that a Discord operation occurred.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .authority_registry import (
    CHANNEL_SOURCE_URL,
    GUILD_SOURCE_URL,
    OAUTH2_SOURCE_URL,
    PERMISSION_SOURCE_URL,
)
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY
from .thread_rules import THREADS_SOURCE_URL as THREAD_RULES_SOURCE_URL


STAGE3_PASS6_ENGINE_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE3-PASS6-0.1"
ACTION_RULES_VERSION = "GUILD-DOCTOR-ACTION-RULES-0.1"
ACTION_GOLDEN_VERSION = "GUILD-DOCTOR-ACTION-GOLDEN-0.1"
ACTION_SOURCE_REVIEW_DATE = "2026-07-15"

ACTION_SOURCE_URLS = (
    CHANNEL_SOURCE_URL,
    GUILD_SOURCE_URL,
    OAUTH2_SOURCE_URL,
    PERMISSION_SOURCE_URL,
    THREAD_RULES_SOURCE_URL,
)

SOURCE_ENGINES = frozenset({"PASS3", "PASS4", "PASS5", "COMBINED", "REQUEST"})
ACTION_TARGET_TYPES = frozenset(
    {"MEMBER", "ROLE", "GUILD", "CHANNEL", "OVERWRITE", "VOICE_STATE", "THREAD", "MESSAGE", "NONE"}
)
ACTION_CONTEXT_TYPES = frozenset(
    {"NONE", "GUILD", "TEXT", "FORUM", "MEDIA", "VOICE", "STAGE", "ANNOUNCEMENT"}
)
BYPASS_SOURCES = frozenset({"NONE", "OWNER", "ADMINISTRATOR"})
ACTION_COMPONENT_NAMES = frozenset(
    {
        "capability_permission",
        "thread_visibility",
        "thread_read_history",
        "thread_send_capability",
        "target_authority",
        "hierarchy_result",
        "mfa_precondition",
        "permission_subset_result",
        "managed_object_precondition",
        "target_owner_protection",
        "target_admin_timeout_protection",
        "target_member_hierarchy",
        "operation_object_preconditions",
        "context_consistency",
    }
)


@dataclass(frozen=True, slots=True)
class ActionComponentDefinition:
    """A normalized evidence component required by one action rule."""

    name: str
    source_engine: str
    source_fields: tuple[str, ...]
    required: bool = True
    allow_not_applicable: bool = False
    rule_id: str = "ACTION-COMPONENT-REQUIRED-001"
    evidence_requirements: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "source_engine": self.source_engine,
            "source_fields": list(self.source_fields),
            "required": self.required,
            "allow_not_applicable": self.allow_not_applicable,
            "rule_id": self.rule_id,
            "evidence_requirements": list(self.evidence_requirements),
        }


@dataclass(frozen=True, slots=True)
class ActionRule:
    """Immutable declaration for one modeled pre-execution action."""

    operation_key: str
    target_types: tuple[str, ...]
    context_types: tuple[str, ...]
    source_engine: str
    required_capability_keys: tuple[str, ...]
    components: tuple[ActionComponentDefinition, ...]
    allowed_bypass_sources: tuple[str, ...] = ("NONE", "OWNER", "ADMINISTRATOR")
    applicability_rules: tuple[str, ...] = ()
    rule_ids: tuple[str, ...] = ("ACTION-REGISTRY-001",)
    verification_status: str = "SYNTHETIC_ORCHESTRATION"
    source_references: tuple[str, ...] = ACTION_SOURCE_URLS
    evidence_requirements: tuple[str, ...] = ()
    unresolved_limitations: tuple[str, ...] = (
        "The result is a pre-execution model and does not verify an endpoint response.",
    )

    @property
    def required_components(self) -> tuple[str, ...]:
        return tuple(component.name for component in self.components if component.required)

    @property
    def optional_components(self) -> tuple[str, ...]:
        return tuple(component.name for component in self.components if not component.required)

    def as_dict(self) -> dict[str, Any]:
        return {
            "operation_key": self.operation_key,
            "target_types": list(self.target_types),
            "context_types": list(self.context_types),
            "source_engine": self.source_engine,
            "required_capability_keys": list(self.required_capability_keys),
            "required_components": list(self.required_components),
            "optional_components": list(self.optional_components),
            "components": [component.as_dict() for component in self.components],
            "allowed_bypass_sources": list(self.allowed_bypass_sources),
            "applicability_rules": list(self.applicability_rules),
            "rule_ids": list(self.rule_ids),
            "verification_status": self.verification_status,
            "source_references": list(self.source_references),
            "evidence_requirements": list(self.evidence_requirements),
            "unresolved_limitations": list(self.unresolved_limitations),
        }


@dataclass(frozen=True, slots=True)
class GoldenActionCase:
    case_id: str
    operation_key: str
    scenario: str
    expected_result: str
    evidence_classification: str
    expected_reason: str

    def as_dict(self) -> dict[str, str]:
        return {
            "case_id": self.case_id,
            "operation_key": self.operation_key,
            "scenario": self.scenario,
            "expected_result": self.expected_result,
            "evidence_classification": self.evidence_classification,
            "expected_reason": self.expected_reason,
        }


def _component(
    name: str,
    source_engine: str,
    *source_fields: str,
    required: bool = True,
    allow_not_applicable: bool = False,
    rule_id: str = "ACTION-COMPONENT-REQUIRED-001",
    evidence_requirements: tuple[str, ...] = (),
) -> ActionComponentDefinition:
    if name == "managed_object_precondition":
        allow_not_applicable = True
    return ActionComponentDefinition(
        name=name,
        source_engine=source_engine,
        source_fields=tuple(source_fields),
        required=required,
        allow_not_applicable=allow_not_applicable,
        rule_id=rule_id,
        evidence_requirements=evidence_requirements,
    )


_ALL_CONTEXTS = tuple(sorted(ACTION_CONTEXT_TYPES))
_GUILD_CONTEXTS = ("GUILD", "NONE", "TEXT", "FORUM", "MEDIA", "VOICE", "STAGE", "ANNOUNCEMENT")
_THREAD_CONTEXTS = ("ANNOUNCEMENT", "FORUM", "MEDIA", "TEXT")
_CAPABILITY_KEYS = frozenset(capability.capability_key for capability in DEFAULT_CAPABILITY_REGISTRY.capabilities)


def _capability_rule(
    operation_key: str,
    target_type: str,
    capability_key: str,
    *,
    contexts: tuple[str, ...] = _ALL_CONTEXTS,
    verification_status: str = "SYNTHETIC_ORCHESTRATION",
) -> ActionRule:
    return ActionRule(
        operation_key=operation_key,
        target_types=(target_type,),
        context_types=contexts,
        source_engine="PASS3",
        required_capability_keys=(capability_key,),
        components=(
            _component(
                "capability_permission",
                "PASS3",
                "effective_capability_records",
                "denied_capability_records",
                "unknown_capability_records",
                evidence_requirements=("Pass 3 capability expansion result",),
            ),
        ),
        applicability_rules=("The target and context must be represented by the Pass 3 request.",),
        verification_status=verification_status,
        evidence_requirements=("Pass 3 contract and input-health fields are complete.",),
    )


def _combined_authority_rule(
    operation_key: str,
    target_type: str,
    capability_key: str,
    *components: ActionComponentDefinition,
    contexts: tuple[str, ...] = _ALL_CONTEXTS,
    verification_status: str = "SYNTHETIC_ORCHESTRATION",
) -> ActionRule:
    return ActionRule(
        operation_key=operation_key,
        target_types=(target_type,),
        context_types=contexts,
        source_engine="COMBINED",
        required_capability_keys=(capability_key,),
        components=(
            _component("capability_permission", "PASS3", "effective_capability_records", "denied_capability_records"),
            *components,
        ),
        applicability_rules=("All declared Pass 3 and Pass 5 identities must agree.",),
        verification_status=verification_status,
        evidence_requirements=("Pass 3 and Pass 5 contract and input-health fields are complete.",),
    )


def _mfa_component(*, required: bool = True) -> ActionComponentDefinition:
    return _component(
        "mfa_precondition",
        "PASS5",
        "mfa_precondition",
        required=required,
        allow_not_applicable=True,
        evidence_requirements=("Guild MFA state and actor elevated-permission condition are known.",),
    )


def _object_component(*, required: bool = True) -> ActionComponentDefinition:
    return _component(
        "operation_object_preconditions",
        "PASS5",
        "operation_preconditions",
        required=required,
        evidence_requirements=("All operation-specific object preconditions are collected.",),
    )


ACTION_RULES: tuple[ActionRule, ...] = tuple(
    sorted(
        (
            ActionRule(
                operation_key="thread.read_history",
                target_types=("THREAD",),
                context_types=_THREAD_CONTEXTS,
                source_engine="PASS4",
                required_capability_keys=(),
                components=(_component("thread_read_history", "PASS4", "thread_read_history_result"),),
                applicability_rules=("The thread must be represented as the Pass 4 target thread.",),
            ),
            ActionRule(
                operation_key="thread.send_message",
                target_types=("THREAD",),
                context_types=_THREAD_CONTEXTS,
                source_engine="PASS4",
                required_capability_keys=("message.send",),
                components=(_component("thread_send_capability", "PASS4", "final_thread_send_capability_result"),),
                applicability_rules=("The thread parent must be represented and visible to the actor.",),
            ),
            ActionRule(
                operation_key="thread.view",
                target_types=("THREAD",),
                context_types=_THREAD_CONTEXTS,
                source_engine="PASS4",
                required_capability_keys=(),
                components=(_component("thread_visibility", "PASS4", "thread_visibility_result"),),
                applicability_rules=("The thread must be represented as the Pass 4 target thread.",),
            ),
            _combined_authority_rule(
                "channel.manage",
                "CHANNEL",
                "channel.manage",
                _mfa_component(),
                _component("target_authority", "PASS5", "target_authority"),
                contexts=_GUILD_CONTEXTS,
            ),
            _combined_authority_rule(
                "guild.manage",
                "GUILD",
                "guild.manage",
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "guild_expression.manage_all",
                "GUILD",
                "guild.expressions.manage",
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "member.ban",
                "MEMBER",
                "member.ban",
                _component("target_authority", "PASS5", "target_authority"),
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("target_owner_protection", "PASS5", "operation_preconditions"),
                _component("target_admin_timeout_protection", "PASS5", "operation_preconditions"),
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "member.kick",
                "MEMBER",
                "member.kick",
                _component("target_authority", "PASS5", "target_authority"),
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("target_owner_protection", "PASS5", "operation_preconditions"),
                _component("target_admin_timeout_protection", "PASS5", "operation_preconditions"),
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "member.role_assign",
                "ROLE",
                "role.manage",
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("target_member_hierarchy", "PASS5", "operation_preconditions"),
                _component("managed_object_precondition", "PASS5", "managed_object_precondition"),
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "member.role_remove",
                "ROLE",
                "role.manage",
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("target_member_hierarchy", "PASS5", "operation_preconditions"),
                _component("managed_object_precondition", "PASS5", "managed_object_precondition"),
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "member.timeout",
                "MEMBER",
                "member.moderate",
                _component("target_authority", "PASS5", "target_authority"),
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("target_owner_protection", "PASS5", "operation_preconditions"),
                _component("target_admin_timeout_protection", "PASS5", "operation_preconditions"),
                _object_component(),
                _mfa_component(required=False),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "monetization_analytics.view",
                "NONE",
                "creator_analytics.view",
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "message.manage",
                "NONE",
                "message.manage",
                _mfa_component(),
                contexts=_GUILD_CONTEXTS,
            ),
            _combined_authority_rule(
                "nickname.manage_other",
                "MEMBER",
                "member.manage_nicknames",
                _component("target_authority", "PASS5", "target_authority"),
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("target_owner_protection", "PASS5", "operation_preconditions"),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "overwrite.permission_change",
                "OVERWRITE",
                "overwrite.manage",
                _component("permission_subset_result", "PASS5", "permission_subset_result"),
                _component("context_consistency", "PASS5", "operation_preconditions"),
                _mfa_component(),
                contexts=_GUILD_CONTEXTS,
            ),
            _combined_authority_rule(
                "role.create",
                "NONE",
                "role.manage",
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("permission_subset_result", "PASS5", "permission_subset_result"),
                _component("managed_object_precondition", "PASS5", "managed_object_precondition"),
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "role.delete",
                "ROLE",
                "role.manage",
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("managed_object_precondition", "PASS5", "managed_object_precondition"),
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "role.edit",
                "ROLE",
                "role.manage",
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("permission_subset_result", "PASS5", "permission_subset_result"),
                _component("managed_object_precondition", "PASS5", "managed_object_precondition"),
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "role.permission_change",
                "ROLE",
                "role.manage",
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("permission_subset_result", "PASS5", "permission_subset_result"),
                _component("managed_object_precondition", "PASS5", "managed_object_precondition"),
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _combined_authority_rule(
                "role.reorder",
                "ROLE",
                "role.manage",
                _component("hierarchy_result", "PASS5", "hierarchy_result"),
                _component("managed_object_precondition", "PASS5", "managed_object_precondition"),
                _mfa_component(),
                contexts=("GUILD", "NONE"),
            ),
            _capability_rule("forum_media.create_post", "CHANNEL", "forum_media.create_post", contexts=("FORUM", "MEDIA")),
            _capability_rule("message.attach_files", "MESSAGE", "message.attach_files"),
            _capability_rule("message.embed_links", "MESSAGE", "message.embed_links"),
            _capability_rule("message.mention_everyone", "MESSAGE", "message.mention_everyone"),
            _capability_rule("message.send", "MESSAGE", "message.send"),
            _capability_rule("message.send_tts", "MESSAGE", "message.send_tts"),
            _capability_rule("thread.manage", "THREAD", "thread.manage", contexts=_THREAD_CONTEXTS),
            _capability_rule("voice.connect", "VOICE_STATE", "voice.connect", contexts=("VOICE", "STAGE")),
            _combined_authority_rule(
                "voice.member_deafen",
                "VOICE_STATE",
                "voice.deafen_members",
                _object_component(),
                contexts=("VOICE", "STAGE"),
            ),
            _combined_authority_rule(
                "voice.member_move",
                "VOICE_STATE",
                "voice.move_members",
                _object_component(),
                contexts=("VOICE", "STAGE"),
            ),
            _combined_authority_rule(
                "voice.member_mute",
                "VOICE_STATE",
                "voice.mute_members",
                _object_component(),
                contexts=("VOICE", "STAGE"),
            ),
            _combined_authority_rule(
                "webhook.manage",
                "NONE",
                "webhook.manage",
                _mfa_component(),
                contexts=_GUILD_CONTEXTS,
            ),
        ),
        key=lambda rule: rule.operation_key,
    )
)


# The tuple above intentionally exposes each operation once.  The definitions
# below are the stable lookup surface; duplicate construction is rejected at
# import-time by validate_action_rules.
ACTION_RULES_BY_KEY: dict[str, ActionRule] = {rule.operation_key: rule for rule in ACTION_RULES}


def validate_action_rules(rules: tuple[ActionRule, ...] = ACTION_RULES) -> tuple[str, ...]:
    """Return deterministic validation errors for an action-rule registry."""

    errors: list[str] = []
    if len({rule.operation_key for rule in rules}) != len(rules):
        errors.append("ACTION-REGISTRY-DUPLICATE-001")
    for rule in rules:
        if not rule.operation_key or rule.source_engine not in SOURCE_ENGINES:
            errors.append(f"ACTION-REGISTRY-SHAPE-001:{rule.operation_key}")
        if not rule.target_types or not set(rule.target_types).issubset(ACTION_TARGET_TYPES):
            errors.append(f"ACTION-REGISTRY-TARGET-001:{rule.operation_key}")
        if not rule.context_types or not set(rule.context_types).issubset(ACTION_CONTEXT_TYPES):
            errors.append(f"ACTION-REGISTRY-CONTEXT-001:{rule.operation_key}")
        if not set(rule.allowed_bypass_sources).issubset(BYPASS_SOURCES):
            errors.append(f"ACTION-REGISTRY-BYPASS-001:{rule.operation_key}")
        if len(set(rule.required_capability_keys)) != len(rule.required_capability_keys):
            errors.append(f"ACTION-REGISTRY-CAPABILITY-DUPLICATE-001:{rule.operation_key}")
        for capability_key in rule.required_capability_keys:
            if capability_key not in _CAPABILITY_KEYS:
                errors.append(f"ACTION-REGISTRY-CAPABILITY-UNKNOWN-001:{rule.operation_key}:{capability_key}")
        component_names = [component.name for component in rule.components]
        if len(set(component_names)) != len(component_names):
            errors.append(f"ACTION-REGISTRY-COMPONENT-DUPLICATE-001:{rule.operation_key}")
        if tuple(component.name for component in rule.components if component.required) != rule.required_components:
            errors.append(f"ACTION-REGISTRY-REQUIRED-COMPONENT-001:{rule.operation_key}")
        if not set(component_names).issubset(ACTION_COMPONENT_NAMES):
            errors.append(f"ACTION-REGISTRY-COMPONENT-UNKNOWN-001:{rule.operation_key}")
        for component in rule.components:
            if component.source_engine not in SOURCE_ENGINES or not component.source_fields:
                errors.append(f"ACTION-REGISTRY-COMPONENT-SOURCE-001:{rule.operation_key}:{component.name}")
        if len(set(rule.rule_ids)) != len(rule.rule_ids):
            errors.append(f"ACTION-REGISTRY-RULE-ID-DUPLICATE-001:{rule.operation_key}")
    return tuple(sorted(errors))


ACTION_REGISTRY_VALIDATION_ERRORS = validate_action_rules()
if ACTION_REGISTRY_VALIDATION_ERRORS:
    raise ValueError("Invalid action registry: " + ", ".join(ACTION_REGISTRY_VALIDATION_ERRORS))


ACTION_GOLDEN_CASES: tuple[GoldenActionCase, ...] = (
    GoldenActionCase("ACTION-GOLDEN-001", "message.send", "allowed_capability", "ALLOWED", "DOCUMENTED_EXPECTATION", "ACTION-ALLOW-001"),
    GoldenActionCase("ACTION-GOLDEN-002", "message.send", "denied_capability", "DENIED", "DOCUMENTED_EXPECTATION", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-003", "message.send", "unknown_capability", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-UNKNOWN-001"),
    GoldenActionCase("ACTION-GOLDEN-004", "message.send", "missing_capability", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-COMPONENT-REQUIRED-001"),
    GoldenActionCase("ACTION-GOLDEN-005", "message.send", "ineffective_capability", "DENIED", "SYNTHETIC_ORCHESTRATION", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-006", "message.send", "policy_only_capability", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-POLICY-ONLY-001"),
    GoldenActionCase("ACTION-GOLDEN-007", "message.send", "unsupported_capability", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-UNKNOWN-001"),
    GoldenActionCase("ACTION-GOLDEN-008", "thread.view", "thread_visible", "ALLOWED", "LIVE_DERIVED_INPUT", "ACTION-ALLOW-001"),
    GoldenActionCase("ACTION-GOLDEN-009", "thread.view", "thread_hidden", "DENIED", "LIVE_DERIVED_INPUT", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-010", "thread.read_history", "history_unknown", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-UNKNOWN-001"),
    GoldenActionCase("ACTION-GOLDEN-011", "thread.send_message", "send_allowed", "ALLOWED", "LIVE_DERIVED_INPUT", "ACTION-ALLOW-001"),
    GoldenActionCase("ACTION-GOLDEN-012", "thread.send_message", "send_denied", "DENIED", "LIVE_DERIVED_INPUT", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-013", "member.kick", "hierarchy_denied", "DENIED", "DOCUMENTED_EXPECTATION", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-014", "member.ban", "owner_protected", "DENIED", "DOCUMENTED_EXPECTATION", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-015", "member.timeout", "admin_protected", "DENIED", "DOCUMENTED_EXPECTATION", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-016", "role.create", "subset_unknown", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-UNKNOWN-001"),
    GoldenActionCase("ACTION-GOLDEN-017", "role.edit", "managed_role", "DENIED", "DOCUMENTED_EXPECTATION", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-018", "role.delete", "role_lower", "ALLOWED", "DOCUMENTED_EXPECTATION", "ACTION-ALLOW-001"),
    GoldenActionCase("ACTION-GOLDEN-019", "role.reorder", "role_equal", "DENIED", "DOCUMENTED_EXPECTATION", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-020", "member.role_assign", "target_member_unknown", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-UNKNOWN-001"),
    GoldenActionCase("ACTION-GOLDEN-021", "channel.manage", "mfa_required", "UNKNOWN", "NEEDS_LIVE_TEST", "ACTION-UNKNOWN-001"),
    GoldenActionCase("ACTION-GOLDEN-022", "overwrite.permission_change", "context_mismatch", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-CONTRACT-MISMATCH-001"),
    GoldenActionCase("ACTION-GOLDEN-023", "voice.member_move", "voice_precondition_failed", "DENIED", "DOCUMENTED_EXPECTATION", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-024", "voice.member_mute", "voice_precondition_unknown", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-UNKNOWN-001"),
    GoldenActionCase("ACTION-GOLDEN-025", "guild.manage", "owner_bypass", "ALLOWED", "DOCUMENTED_EXPECTATION", "ACTION-ALLOW-001"),
    GoldenActionCase("ACTION-GOLDEN-026", "message.manage", "admin_bypass", "ALLOWED", "DOCUMENTED_EXPECTATION", "ACTION-ALLOW-001"),
    GoldenActionCase("ACTION-GOLDEN-027", "webhook.manage", "mfa_disabled", "DENIED", "DOCUMENTED_EXPECTATION", "ACTION-BLOCKER-001"),
    GoldenActionCase("ACTION-GOLDEN-028", "guild_expression.manage_all", "mfa_unknown", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-UNKNOWN-001"),
    GoldenActionCase("ACTION-GOLDEN-029", "monetization_analytics.view", "not_applicable", "NOT_APPLICABLE", "DOCUMENTED_EXPECTATION", "ACTION-NOT-APPLICABLE-001"),
    GoldenActionCase("ACTION-GOLDEN-030", "thread.manage", "unsupported_context", "NOT_APPLICABLE", "DOCUMENTED_EXPECTATION", "ACTION-NOT-APPLICABLE-001"),
    GoldenActionCase("ACTION-GOLDEN-031", "message.send", "duplicate_component", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-UNKNOWN-001"),
    GoldenActionCase("ACTION-GOLDEN-032", "message.send", "contract_mismatch", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-CONTRACT-MISMATCH-001"),
    GoldenActionCase("ACTION-GOLDEN-033", "message.send", "identity_mismatch", "UNKNOWN", "SYNTHETIC_ORCHESTRATION", "ACTION-IDENTITY-MISMATCH-001"),
    GoldenActionCase("ACTION-GOLDEN-034", "not_registered.operation", "unregistered_operation", "UNSUPPORTED", "SYNTHETIC_ORCHESTRATION", "ACTION-UNSUPPORTED-001"),
    GoldenActionCase("ACTION-GOLDEN-035", "message.send", "interrupted_input", "UNKNOWN", "NEEDS_LIVE_TEST", "ACTION-UPSTREAM-INCOMPLETE-001"),
)


__all__ = [
    "ACTION_COMPONENT_NAMES",
    "ACTION_CONTEXT_TYPES",
    "ACTION_GOLDEN_CASES",
    "ACTION_GOLDEN_VERSION",
    "ACTION_REGISTRY_VALIDATION_ERRORS",
    "ACTION_RULES",
    "ACTION_RULES_VERSION",
    "ACTION_RULES_BY_KEY",
    "ACTION_SOURCE_REVIEW_DATE",
    "ACTION_SOURCE_URLS",
    "ACTION_TARGET_TYPES",
    "ActionComponentDefinition",
    "ActionRule",
    "GoldenActionCase",
    "STAGE3_PASS6_ENGINE_CONTRACT_VERSION",
    "validate_action_rules",
]
