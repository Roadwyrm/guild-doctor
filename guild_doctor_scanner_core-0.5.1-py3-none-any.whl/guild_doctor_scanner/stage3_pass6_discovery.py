"""GET-only discovery and manifest generation for Stage 3 Pass 6.

This module discovers only the objects required by the approved Pass 6
scenarios. It never exposes a generic Discord request surface and never calls a
Discord mutation endpoint. The returned discovery inventory and report redact
all entity identifiers; the generated scenario manifest is the private local
input required by the later verifier.
"""

from __future__ import annotations

import asyncio
import json
import math
import os
import re
import sys
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from .acquisition import ReadOnlyAcquisitionAdapter, utc_now
from .authority_live_verifier import ReadOnlyTransportAudit, _scenario_facts
from .constants import CHANNEL_TYPE_KEYS, THREAD_TYPE_CODES
from .discordpy_adapter import DiscordPyReadTransport
from .member_acquisition import member_id_from_payload, minimize_member_payload
from .scenario_manifest import (
    SCENARIO_MANIFEST_CONTRACT_VERSION,
    LiveScenario,
    hash_identifier,
    validate_scenario_manifest_data,
)


DISCOVERY_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE3-PASS6-DISCOVERY-0.1"
FIXED_GUILD_ID = "1450145794224033804"
FIXED_OWNER_MEMBER_ID = "125680395286085632"
FIXED_TARGET_MEMBER_ID = "1526723929337499688"
DEFAULT_NETWORK_TIMEOUT_SECONDS = 30.0
CONFIRMATION_VALUES = {"1", "true", "yes", "on"}
FAILURE_EXIT_CODE = 2
INTERRUPTED_EXIT_CODE = 130
_TOKEN_LIKE_RE = re.compile(
    r"(?i)(?:bot\s+)?[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{20,}"
)
_SUPPORTED_THREAD_PARENT_TYPES = {0, 5, 15, 16}


class DiscoveryError(RuntimeError):
    """Raised when the live guild cannot safely satisfy the discovery contract."""


def _progress(message: str, emit: Callable[[str], None]) -> None:
    emit(f"[Guild Doctor Stage 3 Pass 6 Discovery] {message}")


def _id(value: Any, field_name: str) -> str:
    text = str(value).strip()
    if not text.isdecimal() or int(text) <= 0:
        raise DiscoveryError(f"{field_name} is not a positive decimal snowflake")
    return str(int(text))


def _optional_id(value: Any, field_name: str) -> str | None:
    if value is None:
        return None
    return _id(value, field_name)


def _type_code(raw: Mapping[str, Any], field_name: str) -> int:
    value = raw.get("type")
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise DiscoveryError(f"{field_name}.type is not a non-negative integer")
    return value


def _role_binding(raw: Mapping[str, Any]) -> str | None:
    tags = raw.get("tags") or {}
    if not isinstance(tags, Mapping):
        return None
    if tags.get("bot_id"):
        return "BOT"
    if tags.get("integration_id"):
        return "INTEGRATION"
    if tags.get("subscription_listing_id"):
        return "SUBSCRIPTION"
    return None


def _raw_role_tags_public(raw: Mapping[str, Any]) -> dict[str, Any]:
    tags = raw.get("tags") or {}
    if not isinstance(tags, Mapping):
        tags = {}
    result: dict[str, Any] = {
        "binding_type": _role_binding(raw),
        "available_for_purchase": "available_for_purchase" in tags,
        "guild_connections": "guild_connections" in tags,
    }
    for key in ("bot_id", "integration_id", "subscription_listing_id"):
        if tags.get(key) is not None:
            result[key] = hash_identifier(_id(tags[key], f"role.tags.{key}"))
    return result


def _member_record(raw: Mapping[str, Any], expected_id: str) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        raise DiscoveryError(f"member {hash_identifier(expected_id)} response was not an object")
    actual_id = _id(member_id_from_payload(dict(raw)), "member.user.id")
    if actual_id != expected_id:
        raise DiscoveryError(
            f"member response identity mismatch for {hash_identifier(expected_id)}"
        )
    minimized, _ = minimize_member_payload(dict(raw))
    return minimized


async def _read_required_member(
    audit: ReadOnlyTransportAudit,
    guild_id: str,
    member_id: str,
    *,
    timeout_seconds: float,
    emit: Callable[[str], None],
) -> dict[str, Any]:
    _progress(f"GET targeted member {hash_identifier(member_id)}", emit)
    raw = await asyncio.wait_for(
        audit.read_member(int(guild_id), int(member_id)), timeout=timeout_seconds
    )
    return _member_record(raw, member_id)


def _select_role(
    raw_roles: list[Mapping[str, Any]], *, guild_id: str, target_member_id: str
) -> tuple[Mapping[str, Any], str]:
    candidates: list[tuple[Mapping[str, Any], str]] = []
    for raw in raw_roles:
        role_id = _id(raw.get("id"), "role.id")
        if role_id == guild_id or bool(raw.get("managed")) is False and role_id == guild_id:
            continue
        tags = raw.get("tags") or {}
        bot_id = tags.get("bot_id") if isinstance(tags, Mapping) else None
        if bool(raw.get("managed")) and bot_id is not None and _id(bot_id, "role.tags.bot_id") == target_member_id:
            candidates.append((raw, "GUILD_DOCTOR_MANAGED_BOT_ROLE"))
    if candidates:
        return sorted(
            candidates,
            key=lambda item: (-int(item[0].get("position", 0)), _id(item[0].get("id"), "role.id")),
        )[0]

    ordinary = [
        raw
        for raw in raw_roles
        if _id(raw.get("id"), "role.id") != guild_id and not bool(raw.get("managed"))
    ]
    if not ordinary:
        raise DiscoveryError("no existing ordinary or Guild Doctor managed role is available")
    selected = sorted(
        ordinary,
        key=lambda raw: (-int(raw.get("position", 0)), _id(raw.get("id"), "role.id")),
    )[0]
    return selected, "ORDINARY_NON_EVERYONE_ROLE"


def _select_text_channel(
    raw_channels: list[Mapping[str, Any]],
) -> tuple[Mapping[str, Any], str | None, dict[str, Mapping[str, Any]]]:
    channels: dict[str, Mapping[str, Any]] = {}
    for raw in raw_channels:
        channel_id = _id(raw.get("id"), "channel.id")
        channels[channel_id] = raw
    categories = {
        channel_id: raw
        for channel_id, raw in channels.items()
        if _type_code(raw, f"channel.{channel_id}") == 4
    }
    text_channels = [
        raw
        for raw in channels.values()
        if _type_code(raw, f"channel.{raw.get('id')}") == 0
    ]
    if not text_channels:
        raise DiscoveryError("no existing TEXT channel is available")

    def rank(raw: Mapping[str, Any]) -> tuple[int, int, int, str]:
        parent = _optional_id(raw.get("parent_id"), "channel.parent_id")
        valid_parent = int(parent is not None and parent in categories)
        overwrites = raw.get("permission_overwrites") or []
        overwrite_count = len(overwrites) if isinstance(overwrites, list) else 0
        return (
            -valid_parent,
            -int(overwrite_count > 0),
            -overwrite_count,
            _id(raw.get("id"), "channel.id"),
        )

    selected = sorted(text_channels, key=rank)[0]
    parent_id = _optional_id(selected.get("parent_id"), "channel.parent_id")
    if parent_id not in categories:
        parent_id = None
    return selected, parent_id, categories


def _select_active_thread(
    raw_threads: list[Mapping[str, Any]], channels: Mapping[str, Mapping[str, Any]]
) -> tuple[Mapping[str, Any], str] | None:
    candidates: list[tuple[Mapping[str, Any], str]] = []
    for raw in raw_threads:
        type_code = _type_code(raw, f"thread.{raw.get('id')}")
        if type_code not in THREAD_TYPE_CODES:
            continue
        metadata = raw.get("thread_metadata") or {}
        if isinstance(metadata, Mapping) and metadata.get("archived") is True:
            continue
        thread_id = _id(raw.get("id"), "thread.id")
        parent_id = _optional_id(raw.get("parent_id"), "thread.parent_id")
        parent = channels.get(parent_id or "")
        if parent is None or _type_code(parent, f"channel.{parent_id}") not in _SUPPORTED_THREAD_PARENT_TYPES:
            continue
        candidates.append((raw, thread_id))
    if not candidates:
        return None
    return sorted(candidates, key=lambda item: item[1])[0]


def _facts_for(
    *,
    scenario_id: str,
    operation_key: str,
    target_type: str,
    target_id: str | None,
    context_id: str | None,
    thread_id: str | None,
    guild_id: str,
    actor_member_id: str,
    snapshot: Any,
    members: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    scenario = LiveScenario(
        scenario_id=scenario_id,
        guild_id=guild_id,
        operation_key=operation_key,
        actor_member_id=actor_member_id,
        target_type=target_type,
        target_id=target_id,
        context_id=context_id,
        thread_id=thread_id,
        expected_evidence_classifications=(),
        expected_structural_facts={},
        expected_modeled_result=None,
        member_acquisition_explicitly_authorized=True,
        notes="discovery",
        verification_status="REQUESTED",
    )
    return _scenario_facts(scenario, snapshot, members)


def _member_expected_facts(facts: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "actor_is_guild_owner": facts["actor_is_guild_owner"],
        "target_is_guild_owner": facts["target_is_guild_owner"],
        "target_has_administrator": facts["target_has_administrator"],
        "target_highest_role_position": facts["target_highest_role_position"],
    }


def _role_expected_facts(facts: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "actor_is_guild_owner": facts["actor_is_guild_owner"],
        "target_role_managed": facts["target_role_managed"],
        "target_role_is_everyone": facts["target_role_is_everyone"],
        "target_role_position": facts["target_role_position"],
        "actor_highest_role_position": facts["actor_highest_role_position"],
        "target_role_binding_type": facts["target_role_binding_type"],
    }


def _channel_expected_facts(facts: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "actor_is_guild_owner": facts["actor_is_guild_owner"],
        "context_type": facts["context_type"],
        "context_parent_id": facts["context_parent_id"],
        "context_overwrite_count": facts["context_overwrite_count"],
    }


def _thread_expected_facts(facts: Mapping[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {
        "actor_is_guild_owner": facts["actor_is_guild_owner"],
        "thread_parent_id": facts["thread_parent_id"],
        "context_type": facts["context_type"],
    }
    if facts.get("thread_type") is not None:
        result["thread_type"] = facts["thread_type"]
    if isinstance(facts.get("thread_archived"), bool):
        result["thread_archived"] = facts["thread_archived"]
    return result


def _base_scenario(
    *,
    scenario_id: str,
    guild_id: str,
    operation_key: str,
    actor_member_id: str,
    target_type: str,
    target_id: str | None,
    context_id: str | None,
    thread_id: str | None,
    classifications: list[str],
    expected_facts: Mapping[str, Any],
    notes: str,
    verification_status: str = "REQUESTED",
) -> dict[str, Any]:
    return {
        "scenario_id": scenario_id,
        "guild_id": guild_id,
        "operation_key": operation_key,
        "actor_member_id": actor_member_id,
        "target_type": target_type,
        "target_id": target_id,
        "context_id": context_id,
        "thread_id": thread_id,
        "expected_evidence_classifications": classifications,
        "expected_structural_facts": dict(expected_facts),
        "expected_modeled_result": None,
        "member_acquisition_explicitly_authorized": True,
        "notes": notes,
        "verification_status": verification_status,
    }


def _public_member(member_id: str, record: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "member_id": hash_identifier(member_id),
        "exists": True,
        "bot": (record.get("user") or {}).get("bot"),
        "role_count": len(record.get("roles", []) or []),
        "role_ids": [hash_identifier(str(role_id)) for role_id in record.get("roles", [])],
    }


def _public_role(raw: Mapping[str, Any], *, guild_id: str, selected: bool) -> dict[str, Any]:
    role_id = _id(raw.get("id"), "role.id")
    return {
        "role_id": hash_identifier(role_id),
        "name": str(raw.get("name", "")),
        "position": int(raw.get("position", 0)),
        "managed": bool(raw.get("managed", False)),
        "is_everyone": role_id == guild_id,
        "tags": _raw_role_tags_public(raw),
        "selected": selected,
    }


def _public_channel(
    raw: Mapping[str, Any], *, parent_id: str | None, selected: bool
) -> dict[str, Any]:
    channel_id = _id(raw.get("id"), "channel.id")
    overwrites = raw.get("permission_overwrites") or []
    return {
        "channel_id": hash_identifier(channel_id),
        "name": str(raw.get("name", "")),
        "type": CHANNEL_TYPE_KEYS.get(_type_code(raw, f"channel.{channel_id}"), "UNKNOWN"),
        "parent_category_id": hash_identifier(parent_id) if parent_id else None,
        "overwrite_count": len(overwrites) if isinstance(overwrites, list) else 0,
        "selected": selected,
    }


def _public_thread(raw: Mapping[str, Any], *, selected: bool) -> dict[str, Any]:
    thread_id = _id(raw.get("id"), "thread.id")
    parent_id = _optional_id(raw.get("parent_id"), "thread.parent_id")
    metadata = raw.get("thread_metadata") or {}
    archived = metadata.get("archived") if isinstance(metadata, Mapping) else None
    return {
        "thread_id": hash_identifier(thread_id),
        "parent_channel_id": hash_identifier(parent_id) if parent_id else None,
        "type": CHANNEL_TYPE_KEYS.get(_type_code(raw, f"thread.{thread_id}"), "UNKNOWN"),
        "archived": archived,
        "selected": selected,
    }


def _public_error(exc: BaseException, secrets: Iterable[str] = ()) -> str:
    message = " ".join(str(exc).split()) or exc.__class__.__name__
    for secret in secrets:
        if secret:
            message = message.replace(secret, "[REDACTED]")
    message = _TOKEN_LIKE_RE.sub("[REDACTED]", message)
    return message[:500]


def _redact_value(value: Any, secrets: Iterable[str]) -> Any:
    secret_values = tuple(secret for secret in secrets if secret)
    if isinstance(value, Mapping):
        return {
            _redact_value(str(key), secret_values): _redact_value(item, secret_values)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_redact_value(item, secret_values) for item in value]
    if isinstance(value, tuple):
        return [_redact_value(item, secret_values) for item in value]
    if isinstance(value, str):
        result = value
        for secret in secret_values:
            result = result.replace(secret, "[REDACTED]")
        return result
    return value


async def discover_pass6_scenarios(
    transport: Any,
    *,
    guild_id: str = FIXED_GUILD_ID,
    owner_member_id: str = FIXED_OWNER_MEMBER_ID,
    target_member_id: str = FIXED_TARGET_MEMBER_ID,
    timeout_seconds: float = DEFAULT_NETWORK_TIMEOUT_SECONDS,
    emit: Callable[[str], None] | None = None,
    transport_audit: ReadOnlyTransportAudit | None = None,
) -> dict[str, Any]:
    """Discover the fixed Pass 6 objects and return manifest plus sanitized outputs."""

    timeout = float(timeout_seconds)
    if not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("timeout_seconds must be a finite positive number")
    guild_id = _id(guild_id, "guild_id")
    owner_member_id = _id(owner_member_id, "owner_member_id")
    target_member_id = _id(target_member_id, "target_member_id")
    if guild_id != FIXED_GUILD_ID:
        raise DiscoveryError("discovery is fixed to the approved disposable Guild ID")
    if owner_member_id != FIXED_OWNER_MEMBER_ID or target_member_id != FIXED_TARGET_MEMBER_ID:
        raise DiscoveryError("discovery is fixed to the approved owner and target member IDs")
    emit = emit or (lambda message: print(message, flush=True))
    audit = transport_audit or ReadOnlyTransportAudit(transport)

    _progress("structure: acquiring guild, roles, channels, and active threads", emit)
    structure = await ReadOnlyAcquisitionAdapter(
        audit, operation_timeout_seconds=timeout
    ).acquire_structure(guild_id)
    if structure.snapshot is None:
        raise DiscoveryError(
            "structure normalization failed: " + (structure.normalization_error or "unknown error")
        )
    if structure.snapshot.structural_completeness != "COMPLETE":
        raise DiscoveryError("structure snapshot is not COMPLETE; no manifest was generated")
    for resource, result in structure.results.items():
        if result.status != "COMPLETE":
            raise DiscoveryError(f"{resource} acquisition status is {result.status}")

    snapshot = structure.snapshot
    if snapshot.guild is None or snapshot.guild.id != guild_id:
        raise DiscoveryError("live guild identity did not match the fixed Guild ID")
    if snapshot.guild.owner_id != owner_member_id:
        raise DiscoveryError("live guild owner did not match the known owner member ID")

    members = {
        owner_member_id: await _read_required_member(
            audit, guild_id, owner_member_id, timeout_seconds=timeout, emit=emit
        ),
        target_member_id: await _read_required_member(
            audit, guild_id, target_member_id, timeout_seconds=timeout, emit=emit
        ),
    }

    raw_roles = [item for item in (structure.bundle.get("roles") or []) if isinstance(item, Mapping)]
    raw_channels = [item for item in (structure.bundle.get("channels") or []) if isinstance(item, Mapping)]
    raw_threads = [item for item in (structure.bundle.get("active_threads") or []) if isinstance(item, Mapping)]
    selected_role, role_reason = _select_role(
        raw_roles, guild_id=guild_id, target_member_id=target_member_id
    )
    selected_role_id = _id(selected_role.get("id"), "selected_role.id")
    selected_channel, category_id, categories = _select_text_channel(raw_channels)
    selected_channel_id = _id(selected_channel.get("id"), "selected_channel.id")
    selected_thread = _select_active_thread(raw_threads, { 
        _id(item.get("id"), "channel.id"): item for item in raw_channels
    })

    _progress(
        f"selection: role={hash_identifier(selected_role_id)} channel={hash_identifier(selected_channel_id)}",
        emit,
    )
    if selected_thread is None:
        _progress("selection: no active supported thread; recording NEEDS_LIVE_TEST", emit)
    else:
        _progress(f"selection: active thread {hash_identifier(selected_thread[1])}", emit)

    member_scenario_id = "member-timeout-owner-to-known-target"
    role_scenario_id = "role-edit-discovered-role"
    channel_scenario_id = "channel-manage-discovered-text-channel"
    member_facts = _facts_for(
        scenario_id=member_scenario_id,
        operation_key="member.timeout",
        target_type="MEMBER",
        target_id=target_member_id,
        context_id=None,
        thread_id=None,
        guild_id=guild_id,
        actor_member_id=owner_member_id,
        snapshot=snapshot,
        members=members,
    )
    role_facts = _facts_for(
        scenario_id=role_scenario_id,
        operation_key="role.edit",
        target_type="ROLE",
        target_id=selected_role_id,
        context_id=None,
        thread_id=None,
        guild_id=guild_id,
        actor_member_id=owner_member_id,
        snapshot=snapshot,
        members=members,
    )
    channel_facts = _facts_for(
        scenario_id=channel_scenario_id,
        operation_key="channel.manage",
        target_type="CHANNEL",
        target_id=selected_channel_id,
        context_id=selected_channel_id,
        thread_id=None,
        guild_id=guild_id,
        actor_member_id=owner_member_id,
        snapshot=snapshot,
        members=members,
    )
    scenarios: list[dict[str, Any]] = [
        _base_scenario(
            scenario_id=member_scenario_id,
            guild_id=guild_id,
            operation_key="member.timeout",
            actor_member_id=owner_member_id,
            target_type="MEMBER",
            target_id=target_member_id,
            context_id=None,
            thread_id=None,
            classifications=[
                "LIVE_DERIVED_STRUCTURE", "LIVE_DERIVED_ACTOR", "LIVE_DERIVED_TARGET",
                "LIVE_DERIVED_ROLE", "MODELED_RESULT",
            ],
            expected_facts=_member_expected_facts(member_facts),
            notes="Generated from the fixed owner and known non-owner target by the GET-only discovery workflow. No timeout is attempted.",
        ),
        _base_scenario(
            scenario_id=role_scenario_id,
            guild_id=guild_id,
            operation_key="role.edit",
            actor_member_id=owner_member_id,
            target_type="ROLE",
            target_id=selected_role_id,
            context_id=None,
            thread_id=None,
            classifications=[
                "LIVE_DERIVED_STRUCTURE", "LIVE_DERIVED_ACTOR", "LIVE_DERIVED_ROLE",
                "MODELED_RESULT", "NEEDS_LIVE_TEST",
            ],
            expected_facts=_role_expected_facts(role_facts),
            notes=f"Generated by discovery using selection {role_reason}. Human MFA is not observable from reviewed GETs; no role edit is attempted.",
        ),
        _base_scenario(
            scenario_id=channel_scenario_id,
            guild_id=guild_id,
            operation_key="channel.manage",
            actor_member_id=owner_member_id,
            target_type="CHANNEL",
            target_id=selected_channel_id,
            context_id=selected_channel_id,
            thread_id=None,
            classifications=[
                "LIVE_DERIVED_STRUCTURE", "LIVE_DERIVED_ACTOR", "LIVE_DERIVED_CONTEXT",
                "MODELED_RESULT", "NEEDS_LIVE_TEST",
            ],
            expected_facts=_channel_expected_facts(channel_facts),
            notes="Generated from the preferred existing TEXT channel. Human MFA is not observable from reviewed GETs; no channel change is attempted.",
        ),
    ]

    selected_thread_id: str | None = None
    selected_thread_parent_id: str | None = None
    if selected_thread is not None:
        raw_thread, selected_thread_id = selected_thread
        selected_thread_parent_id = _id(raw_thread.get("parent_id"), "selected_thread.parent_id")
        thread_scenario_id = "thread-view-discovered-active-thread"
        thread_facts = _facts_for(
            scenario_id=thread_scenario_id,
            operation_key="thread.view",
            target_type="THREAD",
            target_id=selected_thread_id,
            context_id=selected_thread_parent_id,
            thread_id=selected_thread_id,
            guild_id=guild_id,
            actor_member_id=owner_member_id,
            snapshot=snapshot,
            members=members,
        )
        scenarios.append(
            _base_scenario(
                scenario_id=thread_scenario_id,
                guild_id=guild_id,
                operation_key="thread.view",
                actor_member_id=owner_member_id,
                target_type="THREAD",
                target_id=selected_thread_id,
                context_id=selected_thread_parent_id,
                thread_id=selected_thread_id,
                classifications=[
                    "LIVE_DERIVED_STRUCTURE", "LIVE_DERIVED_ACTOR", "LIVE_DERIVED_CONTEXT",
                    "LIVE_DERIVED_THREAD", "MODELED_RESULT", "NEEDS_LIVE_TEST",
                ],
                expected_facts=_thread_expected_facts(thread_facts),
                notes="Generated only because an active supported thread was returned by the GET-only active-thread endpoint. No thread operation is attempted.",
                verification_status="OPTIONAL_IF_PRESENT",
            )
        )

    manifest_data: dict[str, Any] = {
        "contract": SCENARIO_MANIFEST_CONTRACT_VERSION,
        "notes": "Generated automatically by Guild Doctor Stage 3 Pass 6 GET-only discovery. Private local manifest; never add a token.",
        "known_limitations": {
            "human_member_mfa": "NEEDS_LIVE_TEST: the reviewed GET-only transport cannot observe human MFA state",
            "voice_state": "NEEDS_LIVE_TEST: the reviewed GET-only transport cannot establish live voice state",
            "active_thread_absent": "NEEDS_LIVE_TEST: no active supported thread was discovered" if selected_thread_id is None else "NOT_APPLICABLE: active supported thread discovered",
        },
        "scenarios": scenarios,
    }
    validated_scenarios = validate_scenario_manifest_data(manifest_data)

    role_public = [
        _public_role(
            raw,
            guild_id=guild_id,
            selected=_id(raw.get("id"), "role.id") == selected_role_id,
        )
        for raw in raw_roles
    ]
    channel_public = [
        _public_channel(
            raw,
            parent_id=(
                _optional_id(raw.get("parent_id"), "channel.parent_id")
                if _optional_id(raw.get("parent_id"), "channel.parent_id") in categories
                else None
            ),
            selected=_id(raw.get("id"), "channel.id") == selected_channel_id,
        )
        for raw in raw_channels
        if _type_code(raw, f"channel.{raw.get('id')}") in {0, 4}
    ]
    thread_public = [
        _public_thread(raw, selected=(selected_thread_id == _id(raw.get("id"), "thread.id")))
        for raw in raw_threads
        if _type_code(raw, f"thread.{raw.get('id')}") in THREAD_TYPE_CODES
    ]
    audit_data = audit.as_dict()
    existence = {
        "guild": snapshot.guild.id == guild_id,
        "owner_member": owner_member_id in members,
        "target_member": target_member_id in members,
        "selected_role": selected_role_id in (snapshot.roles or {}),
        "selected_text_channel": selected_channel_id in (snapshot.channels or {}),
        "selected_category": category_id is None or category_id in (snapshot.channels or {}),
        "selected_thread": selected_thread_id is None or selected_thread_id in (snapshot.threads or {}),
    }
    if not all(existence.values()):
        raise DiscoveryError("one or more selected objects were not present in the normalized live snapshot")

    inventory = {
        "contract": DISCOVERY_CONTRACT_VERSION,
        "sanitized": True,
        "live_execution": True,
        "guild_id": hash_identifier(guild_id),
        "guild_name": snapshot.guild.name,
        "guild_owner_member_id": hash_identifier(owner_member_id),
        "requested_members": [_public_member(member_id, members[member_id]) for member_id in sorted(members)],
        "roles": role_public,
        "categories": [
            {
                "channel_id": item["channel_id"],
                "name": item["name"],
                "exists": True,
            }
            for item in channel_public
            if item["type"] == "CATEGORY"
        ],
        "text_channels": [item for item in channel_public if item["type"] == "TEXT"],
        "active_threads": thread_public,
        "selected_objects": {
            "member_target_id": hash_identifier(target_member_id),
            "role_id": hash_identifier(selected_role_id),
            "text_channel_id": hash_identifier(selected_channel_id),
            "category_id": hash_identifier(category_id) if category_id else None,
            "active_thread_id": hash_identifier(selected_thread_id) if selected_thread_id else None,
            "active_thread_parent_channel_id": hash_identifier(selected_thread_parent_id) if selected_thread_parent_id else None,
        },
        "object_existence_checks": existence,
        "transport_audit": audit_data,
        "offline_manifest_validation": "PASS",
        "token_redaction": "PASS",
    }
    report = {
        "contract": DISCOVERY_CONTRACT_VERSION,
        "status": "PASS",
        "live_execution": True,
        "guild_id": hash_identifier(guild_id),
        "selected_member_target": hash_identifier(target_member_id),
        "selected_role": {
            "role_id": hash_identifier(selected_role_id),
            "name": str(selected_role.get("name", "")),
            "managed": bool(selected_role.get("managed", False)),
            "selection": role_reason,
        },
        "selected_text_channel": {
            "channel_id": hash_identifier(selected_channel_id),
            "name": str(selected_channel.get("name", "")),
            "parent_category_id": hash_identifier(category_id) if category_id else None,
            "overwrite_count": channel_facts["context_overwrite_count"],
        },
        "selected_category": hash_identifier(category_id) if category_id else None,
        "selected_active_thread": (
            {
                "thread_id": hash_identifier(selected_thread_id),
                "parent_channel_id": hash_identifier(selected_thread_parent_id),
            }
            if selected_thread_id
            else {"status": "NEEDS_LIVE_TEST", "reason": "NO_ACTIVE_SUPPORTED_THREAD"}
        ),
        "object_existence_checks": existence,
        "offline_manifest_validation": "PASS",
        "get_request_count": audit_data["http_method_counts"]["GET"],
        "write_request_count": audit_data["discord_write_requests"],
        "non_get_attempted": audit_data["non_get_attempted"],
        "token_redaction": "PASS",
        "actual_live_verifier_executed": False,
        "scenario_count": len(validated_scenarios),
        "known_limitations": manifest_data["known_limitations"],
        "generated_at": utc_now(),
    }
    return {"manifest": manifest_data, "inventory": inventory, "report": report}


def _write_json(path: Path, value: Any, secrets: Iterable[str]) -> None:
    safe = _redact_value(value, secrets)
    path.write_text(json.dumps(safe, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def write_discovery_outputs(
    output_dir: Path, result: Mapping[str, Any], *, secrets: Iterable[str] = ()
) -> dict[str, Path]:
    """Write the private manifest and sanitized discovery/report artifacts."""

    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "discovery": output_dir / "stage3-pass6-discovery.json",
        "manifest": output_dir / "stage3-pass6-scenarios.json",
        "report": output_dir / "stage3-pass6-discovery-report.json",
    }
    _write_json(paths["discovery"], result["inventory"], secrets)
    _write_json(paths["manifest"], result["manifest"], secrets)
    report = dict(result["report"])
    report["generated_files"] = {key: str(path) for key, path in paths.items()}
    _write_json(paths["report"], report, secrets)

    secret_values = tuple(secret for secret in secrets if secret)
    leaked = any(
        secret in path.read_text(encoding="utf-8")
        for path in paths.values()
        for secret in secret_values
    )
    report["token_redaction"] = "FAIL" if leaked else "PASS"
    _write_json(paths["report"], report, secrets)
    if leaked:
        raise DiscoveryError("token-redaction check failed for a generated output")
    return paths


def failure_report(
    *,
    stage: str,
    code: str,
    message: str,
    audit: ReadOnlyTransportAudit | None = None,
) -> dict[str, Any]:
    audit_data = audit.as_dict() if audit is not None else {
        "transport_contract": "GET_ONLY",
        "calls": [],
        "http_method_counts": {"GET": 0, "POST": 0, "PUT": 0, "PATCH": 0, "DELETE": 0},
        "discord_write_requests": 0,
        "non_get_attempted": False,
        "audit_status": "PASS",
    }
    return {
        "contract": DISCOVERY_CONTRACT_VERSION,
        "status": "FAILED",
        "stage": stage,
        "failure_code": code,
        "failure_message": message,
        "get_request_count": audit_data["http_method_counts"]["GET"],
        "write_request_count": audit_data["discord_write_requests"],
        "transport_audit": audit_data,
        "token_redaction": "PASS",
        "actual_live_verifier_executed": False,
    }


def build_parser() -> Any:
    import argparse

    parser = argparse.ArgumentParser(
        description="Discover Guild Doctor Stage 3 Pass 6 objects with reviewed GET operations"
    )
    parser.add_argument("--output-dir", type=Path, default=Path.cwd())
    parser.add_argument("--network-timeout-seconds", type=float, default=DEFAULT_NETWORK_TIMEOUT_SECONDS)
    return parser


def _error(message: str) -> None:
    print(f"guild-doctor-stage3-pass6-discover: {message}", file=sys.stderr, flush=True)


def _failure_code(exc: BaseException, stage: str) -> str:
    if isinstance(exc, (asyncio.CancelledError, KeyboardInterrupt)):
        return "INTERRUPTED"
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        return "NETWORK_TIMEOUT"
    status = getattr(exc, "status", None)
    if status == 401 or exc.__class__.__name__ in {"LoginFailure", "AuthenticationError"}:
        return "AUTHENTICATION_FAILED"
    if status == 403:
        return "AUTHORIZATION_DENIED"
    if stage == "preflight":
        return "DISCOVERY_PREFLIGHT_FAILED"
    if stage == "structure":
        return "DISCOVERY_STRUCTURE_FAILED"
    if stage == "member":
        return "DISCOVERY_MEMBER_FAILED"
    if stage == "selection":
        return "DISCOVERY_SELECTION_FAILED"
    if stage == "filesystem" or isinstance(exc, OSError):
        return "FILESYSTEM_FAILURE"
    return "DISCOVERY_FAILED"


async def _run_cli(args: Any) -> int:
    token = os.environ.get("GUILD_DOCTOR_DISCORD_TOKEN")
    secrets = (token or "",)
    stage = "preflight"
    audit: ReadOnlyTransportAudit | None = None
    client = None
    try:
        _progress(f"fixed guild: {hash_identifier(FIXED_GUILD_ID)}", print)
        if os.environ.get("GUILD_DOCTOR_DISPOSABLE_GUILD_CONFIRMED", "").strip().lower() not in CONFIRMATION_VALUES:
            raise DiscoveryError("disposable-guild confirmation is required")
        if not token:
            raise DiscoveryError("GUILD_DOCTOR_DISCORD_TOKEN is not set")

        stage = "authentication"
        _progress(f"authentication: bounded login ({args.network_timeout_seconds:g}s)", print)
        import discord

        client = discord.Client(intents=discord.Intents.none(), max_messages=None)
        await asyncio.wait_for(client.login(token), timeout=args.network_timeout_seconds)
        transport = DiscordPyReadTransport.from_client(client)
        audit = ReadOnlyTransportAudit(transport)
        audit.record_login(outcome="COMPLETE")
        _progress("transport: reviewed GET-only interface ready", print)

        stage = "discovery"
        result = await discover_pass6_scenarios(
            transport,
            timeout_seconds=args.network_timeout_seconds,
            emit=print,
            transport_audit=audit,
        )
        stage = "filesystem"
        _progress("filesystem: writing sanitized discovery and private scenario manifest", print)
        paths = write_discovery_outputs(args.output_dir, result, secrets=secrets)
        _progress(f"complete: GET requests={result['report']['get_request_count']}", print)
        _progress(f"complete: write requests={result['report']['write_request_count']}", print)
        _progress(f"complete: manifest={paths['manifest']}", print)
        return 0
    except (asyncio.CancelledError, KeyboardInterrupt) as exc:
        report = failure_report(stage=stage, code="INTERRUPTED", message="discovery was interrupted", audit=audit)
        _write_json(args.output_dir / "stage3-pass6-discovery-report.json", report, secrets)
        _error("interrupted; discovery report was written")
        return INTERRUPTED_EXIT_CODE
    except BaseException as exc:
        code = _failure_code(exc, stage)
        report = failure_report(stage=stage, code=code, message=_public_error(exc, secrets), audit=audit)
        try:
            _write_json(args.output_dir / "stage3-pass6-discovery-report.json", report, secrets)
        except OSError as report_exc:
            _error(f"{stage} failed with {code}; report write failed: {_public_error(report_exc, secrets)}")
        else:
            _error(f"{stage} failed with {code}: {_public_error(exc, secrets)}")
        return FAILURE_EXIT_CODE
    finally:
        if client is not None:
            try:
                await asyncio.wait_for(client.close(), timeout=args.network_timeout_seconds)
            except BaseException:
                pass


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not math.isfinite(float(args.network_timeout_seconds)) or float(args.network_timeout_seconds) <= 0:
        _error("--network-timeout-seconds must be a finite positive number")
        return FAILURE_EXIT_CODE
    if args.output_dir.exists() and not args.output_dir.is_dir():
        _error(f"output path exists and is not a directory: {args.output_dir}")
        return FAILURE_EXIT_CODE
    try:
        args.output_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        _error(f"filesystem failure creating output directory: {_public_error(exc)}")
        return FAILURE_EXIT_CODE
    _progress(f"output directory ready: {args.output_dir}", print)
    try:
        return asyncio.run(_run_cli(args))
    except KeyboardInterrupt:
        report = failure_report(stage="main", code="INTERRUPTED", message="discovery was interrupted")
        try:
            _write_json(args.output_dir / "stage3-pass6-discovery-report.json", report, ())
        except OSError:
            pass
        return INTERRUPTED_EXIT_CODE


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "CONFIRMATION_VALUES",
    "DISCOVERY_CONTRACT_VERSION",
    "DEFAULT_NETWORK_TIMEOUT_SECONDS",
    "FAILURE_EXIT_CODE",
    "FIXED_GUILD_ID",
    "FIXED_OWNER_MEMBER_ID",
    "FIXED_TARGET_MEMBER_ID",
    "DiscoveryError",
    "build_parser",
    "discover_pass6_scenarios",
    "failure_report",
    "main",
    "write_discovery_outputs",
]
