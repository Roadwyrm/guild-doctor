"""Pure-offline qualification for the Stage 8 Pass 4D bounded runtime."""
from __future__ import annotations

import asyncio
from dataclasses import asdict, dataclass
import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from .private_alpha_interaction_intake import LiveAuthorizationContext
from .private_alpha_live_interaction_runtime import (
    BoundSnapshot, BoundedInteractionOrchestrator, SNAPSHOT_RECEIPT_CONTRACT,
    SnapshotBindingReceipt,
)


PASS4D_QUALIFICATION_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4D-OFFLINE-QUALIFICATION-0.1"


class OfflineResponseTransport:
    """Transport-only double; it cannot construct a Discord client or use I/O."""

    def __init__(self, *, fail_operation: str | None = None):
        self.operations: list[str] = []
        self.contents: list[str] = []
        self.fail_operation = fail_operation

    async def _record(self, operation: str, content: str | None = None) -> None:
        if self.fail_operation == operation:
            raise RuntimeError("SANITIZED_TRANSPORT_FAILURE")
        self.operations.append(operation)
        if content is not None:
            self.contents.append(content)

    async def send_initial_ephemeral(self, content: str) -> None:
        await self._record("INITIAL_EPHEMERAL", content)

    async def defer_ephemeral(self) -> None:
        await self._record("DEFER_EPHEMERAL")

    async def edit_original_ephemeral(self, content: str) -> None:
        await self._record("EDIT_ORIGINAL_EPHEMERAL", content)


@dataclass(frozen=True, slots=True)
class OfflineInteractionSource:
    route_name: str
    options: dict[str, Any]
    interaction_type: int = 2
    command_type: int = 1
    guild_id: str = "100"
    actor_id: str = "200"
    is_direct_message: bool = False
    is_private_channel: bool = False
    has_attachments: bool = False
    has_message_content: bool = False


@dataclass(frozen=True, slots=True)
class Pass4DQualificationResult:
    artifact_contract: str
    status: str
    routes: tuple[dict[str, Any], ...]
    accepted_route_count: int
    rejected_route_count: int
    response_write_count: int
    domain_invocation_count: int
    real_pass4b_executor_used: bool
    real_renderer_used: bool
    discord_client_constructed: bool
    network_request_count: int
    discord_get_count: int
    gateway_connection_count: int
    token_prompt_count: int
    interaction_response_write_count: int
    guild_server_object_write_count: int
    raw_identifier_retained: bool

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _role(identifier: str) -> Any:
    return SimpleNamespace(id=int(identifier), guild=SimpleNamespace(id=100))


def _receipt(snapshot: dict[str, Any]) -> SnapshotBindingReceipt:
    return SnapshotBindingReceipt(
        SNAPSHOT_RECEIPT_CONTRACT, "authorized_normalized_snapshot.json", "BOUND",
        "PASS", "ALLOWLIST_EXACT_MATCH", "PASS",
        str(snapshot["snapshot_fingerprint_sha256"]),
        tuple(sorted({
            "structural": str(snapshot.get("structural_completeness", "UNKNOWN")),
            "member": str(snapshot.get("member_completeness", "UNKNOWN")),
            "thread": str(snapshot.get("thread_completeness", "UNKNOWN")),
        }.items())),
    )


async def qualify_snapshot(snapshot: dict[str, Any]) -> Pass4DQualificationResult:
    bound = BoundSnapshot(snapshot, _receipt(snapshot))
    runtime = BoundedInteractionOrchestrator(
        context=LiveAuthorizationContext("100", "200"), bound_snapshot=bound,
        maximum_invocations=4, maximum_duration_seconds=600,
    )
    cases = (
        ("compare-role-permission", {"first-role": _role("400"), "second-role": _role("401"), "permission": "VIEW_CHANNEL"}),
        ("compare-role-capability", {"first-role": _role("400"), "second-role": _role("401"), "capability": "message.send"}),
        ("compare-role-action", {"first-role": _role("400"), "second-role": _role("401"), "action": "member.kick"}),
        ("server-report", {}),
    )
    routes: list[dict[str, Any]] = []
    writes = domains = 0
    for route, options in cases:
        transport = OfflineResponseTransport()
        outcome = await runtime.handle(OfflineInteractionSource(route, options), transport)
        writes += len(transport.operations)
        domains += outcome.domain_invocation_count
        routes.append({
            "route_name": route,
            "state": outcome.state,
            "envelope_branch": outcome.envelope_branch,
            "stable_error": outcome.stable_error,
            "response_operations": tuple(transport.operations),
            "authorization_before_domain": outcome.authorization_before_domain,
            "defer_before_domain": outcome.defer_before_domain,
            "domain_invocation_count": outcome.domain_invocation_count,
        })
    passed = (
        all(item["state"] == "COMPLETED" for item in routes)
        and [item["envelope_branch"] for item in routes]
        == ["COMPARISON_RESULT", "COMPARISON_RESULT", "ERROR_RESULT", "REPORT_RESULT"]
        and all(item["response_operations"] == ("DEFER_EPHEMERAL", "EDIT_ORIGINAL_EPHEMERAL") for item in routes)
        and runtime.budget.snapshot.closed
    )
    return Pass4DQualificationResult(
        PASS4D_QUALIFICATION_CONTRACT, "PASS" if passed else "FAIL",
        tuple(routes), 4, 0, writes, domains, True, True, False,
        0, 0, 0, 0, 0, 0, False,
    )


def run_offline_qualification(snapshot_fixture: Path) -> Pass4DQualificationResult:
    value = json.loads(snapshot_fixture.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or value.get("guild_id") != "100":
        raise ValueError("STAGE8_PASS4D_SANITIZED_FIXTURE_REQUIRED")
    return asyncio.run(qualify_snapshot(value))


__all__ = [
    "OfflineInteractionSource", "OfflineResponseTransport",
    "PASS4D_QUALIFICATION_CONTRACT", "Pass4DQualificationResult",
    "qualify_snapshot", "run_offline_qualification",
]
