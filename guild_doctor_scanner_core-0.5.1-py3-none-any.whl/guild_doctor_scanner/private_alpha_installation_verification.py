"""Pure least-privilege installation checks for Stage 8 Pass 3."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import hashlib
import json
from typing import Any


INSTALLATION_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-INSTALLATION-VERIFICATION-0.1"

PROHIBITED_PERMISSION_BITS = {
    "KICK_MEMBERS": 1,
    "BAN_MEMBERS": 2,
    "ADMINISTRATOR": 3,
    "MANAGE_CHANNELS": 4,
    "MANAGE_GUILD": 5,
    "MANAGE_MESSAGES": 13,
    "MANAGE_NICKNAMES": 27,
    "MANAGE_ROLES": 28,
    "MANAGE_WEBHOOKS": 29,
    "MANAGE_THREADS": 34,
    "MODERATE_MEMBERS": 40,
    "CREATE_EVENTS": 44,
}
PROHIBITED_INTENTS = ("message_content", "presences", "members")


@dataclass(frozen=True, slots=True)
class InstallationVerification:
    state: str
    stable_reasons: tuple[str, ...]
    authenticated_identity_available: bool
    guild_reachable: bool
    owner_identity_available: bool
    bot_role_found: bool
    installation_identity_basis: str
    role_permission_evaluation: str
    prohibited_permissions: tuple[str, ...]
    prohibited_intents: tuple[str, ...]
    owner_authorization_prerequisite: str
    administrator_substitutes_for_owner: bool = False
    allowlist_substitutes_for_owner: bool = False
    installation_fingerprint: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "contract": INSTALLATION_CONTRACT,
            "state": self.state,
            "stable_reasons": list(self.stable_reasons),
            "authenticated_identity_available": self.authenticated_identity_available,
            "guild_reachable": self.guild_reachable,
            "owner_identity_available": self.owner_identity_available,
            "bot_role_found": self.bot_role_found,
            "installation_identity_basis": self.installation_identity_basis,
            "role_permission_evaluation": self.role_permission_evaluation,
            "prohibited_permissions": list(self.prohibited_permissions),
            "prohibited_intents": list(self.prohibited_intents),
            "owner_authorization_prerequisite": self.owner_authorization_prerequisite,
            "administrator_substitutes_for_owner": self.administrator_substitutes_for_owner,
            "allowlist_substitutes_for_owner": self.allowlist_substitutes_for_owner,
            "installation_fingerprint": self.installation_fingerprint,
        }


def _fingerprint(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(dict(value), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def verify_installation(
    *,
    guild: Mapping[str, Any],
    roles: Sequence[Mapping[str, Any]],
    authenticated_user_id: str | None,
    owner_member: Mapping[str, Any] | None,
    intents: Mapping[str, bool],
) -> InstallationVerification:
    guild_id = str(guild.get("id", ""))
    owner_id = str(guild.get("owner_id", ""))
    identity_available = bool(authenticated_user_id and str(authenticated_user_id).isdecimal())
    guild_reachable = bool(guild_id.isdecimal() and owner_id.isdecimal())
    owner_user = owner_member.get("user") if isinstance(owner_member, Mapping) else None
    owner_available = bool(
        isinstance(owner_user, Mapping)
        and str(owner_user.get("id", "")).isdecimal()
        and str(owner_user.get("id")) == owner_id
    )

    bot_roles: list[Mapping[str, Any]] = []
    everyone_roles: list[Mapping[str, Any]] = []
    for role in roles:
        if str(role.get("id", "")) == guild_id:
            everyone_roles.append(role)
        tags = role.get("tags")
        if identity_available and isinstance(tags, Mapping) and str(tags.get("bot_id", "")) == authenticated_user_id:
            bot_roles.append(role)
    # A zero-permission Guild Install can authenticate and access the exact
    # guild without Discord exposing a separate managed bot role. Managed role
    # tags are observations, not installation identity. Until exact bot-member
    # role assignments are acquired, scan the complete role inventory
    # conservatively so an unbound elevated role cannot be missed.
    effective_raw = 0
    malformed_permissions = False
    for role in roles:
        raw = role.get("permissions", "0")
        try:
            value = int(raw)
        except (TypeError, ValueError):
            malformed_permissions = True
            continue
        if value < 0:
            malformed_permissions = True
            continue
        effective_raw |= value
    prohibited_permissions = tuple(
        name for name, bit in PROHIBITED_PERMISSION_BITS.items() if effective_raw & (1 << bit)
    )
    prohibited_intents = tuple(name.upper() for name in PROHIBITED_INTENTS if intents.get(name, False))

    reasons: list[str] = []
    if not identity_available:
        reasons.append("STAGE8_INSTALLATION_IDENTITY_UNAVAILABLE")
    if not guild_reachable:
        reasons.append("STAGE8_INSTALLATION_GUILD_UNAVAILABLE")
    if not owner_available:
        reasons.append("STAGE8_INSTALLATION_OWNER_IDENTITY_UNAVAILABLE")
    if malformed_permissions:
        reasons.append("STAGE8_INSTALLATION_PERMISSION_VALUE_INVALID")
    if prohibited_permissions:
        reasons.append("STAGE8_INSTALLATION_EXCESSIVE_PERMISSION")
    if prohibited_intents:
        reasons.append("STAGE8_INSTALLATION_PROHIBITED_INTENT")
    reasons_tuple = tuple(sorted(set(reasons)))
    public = {
        "state": "PASS" if not reasons_tuple else "BLOCKED",
        "stable_reasons": list(reasons_tuple),
        "authenticated_identity_available": identity_available,
        "guild_reachable": guild_reachable,
        "owner_identity_available": owner_available,
        "bot_role_found": bool(bot_roles),
        "installation_identity_basis": "AUTHENTICATED_BOT_USER_AND_EXACT_GUILD_ACCESS",
        "role_permission_evaluation": "CONSERVATIVE_COMPLETE_ROLE_INVENTORY",
        "prohibited_permissions": list(prohibited_permissions),
        "prohibited_intents": list(prohibited_intents),
        "owner_authorization_prerequisite": "AUTHORITATIVE_GUILD_OWNER_EXACT_ACTOR_REQUIRED_IN_PASS4",
        "administrator_substitutes_for_owner": False,
        "allowlist_substitutes_for_owner": False,
    }
    return InstallationVerification(
        state=public["state"],
        stable_reasons=reasons_tuple,
        authenticated_identity_available=identity_available,
        guild_reachable=guild_reachable,
        owner_identity_available=owner_available,
        bot_role_found=bool(bot_roles),
        installation_identity_basis=public["installation_identity_basis"],
        role_permission_evaluation=public["role_permission_evaluation"],
        prohibited_permissions=prohibited_permissions,
        prohibited_intents=prohibited_intents,
        owner_authorization_prerequisite=public["owner_authorization_prerequisite"],
        installation_fingerprint=_fingerprint(public),
    )


__all__ = [
    "INSTALLATION_CONTRACT", "PROHIBITED_INTENTS", "PROHIBITED_PERMISSION_BITS",
    "InstallationVerification", "verify_installation",
]
