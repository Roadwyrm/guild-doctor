"""Offline Phase A CLI. Network-capable modes are intentionally pending until operator execution."""
from __future__ import annotations
import argparse,json,asyncio
from pathlib import Path
from .discord_live_runtime import EXIT_CODES,MODES,build_provenance,validate_provenance
from .discord_disposable_sync import dry_run
from .discord_disposable_sync import execute_sync
from .discord_disposable_verification import verify_commands,execute_verify_async
from .discord_disposable_rollback import execute_rollback
from .discord_live_runtime import DiscordPyTransport
from .discord_secure_token import HiddenTokenProvider
from .discord_command_manifest import COMMAND_MANIFEST
def main(argv=None)->int:
 p=argparse.ArgumentParser();p.add_argument("--mode",choices=MODES,required=True);p.add_argument("--guild-id");p.add_argument("--confirmation");p.add_argument("--network-enabled",action="store_true");p.add_argument("--project-root",default="C:\\GuildDoctor");a=p.parse_args(argv);provenance=build_provenance(Path(a.project_root));errors=validate_provenance(provenance)
 if errors:print(json.dumps({"status":"FAIL","errors":errors,"token_redacted":True}));return EXIT_CODES["RUNTIME_PROVENANCE_FAILED"]
 if a.mode=="PROVENANCE_ONLY":print(json.dumps({"status":"PASS","provenance":provenance.__dict__,"request_count":0,"token_redacted":True}));return 0
 if a.mode=="DRY_RUN":print(json.dumps({"status":"PASS","dry_run":dry_run(guild_id=a.guild_id,confirmation=a.confirmation,network_enabled=a.network_enabled),"token_redacted":True}));return 0
 if not a.guild_id:return EXIT_CODES["INVALID_ARGUMENT"]
 transport=DiscordPyTransport()
 if a.mode=="SYNC_DISPOSABLE":result=execute_sync(transport=transport,token_provider=HiddenTokenProvider(),guild_id=a.guild_id,confirmation=a.confirmation,network_enabled=a.network_enabled)
 elif a.mode=="VERIFY_DISPOSABLE":
  result=asyncio.run(execute_verify_async(transport=transport,token_provider=HiddenTokenProvider(),guild_id=a.guild_id,expected_names={x.slash_name for x in COMMAND_MANIFEST}))
 else:result=execute_rollback(transport=transport,guild_id=a.guild_id,confirmation=a.confirmation or '',command_names={x.slash_name for x in COMMAND_MANIFEST})
 print(json.dumps({"status":result.get('status'),'mode':a.mode,'token_redacted':True,'result':{k:v for k,v in result.items() if k not in {'token','raw_payload'}}}));return 0 if result.get('status')=='PASS' else EXIT_CODES['PASS5_PENDING']
if __name__=="__main__":raise SystemExit(main())
