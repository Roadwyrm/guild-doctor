"""Pure deterministic Stage 3 Pass 4 thread permission resolution.

The resolver consumes completed Pass 2 parent permission evidence and the
completed Pass 3 parent capability result.  It performs no Discord access,
networking, persistence, command, environment, token, or mutation work.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from .capability_engine import (
    FINAL_ALLOWED,
    FINAL_DENIED,
    FINAL_INEFFECTIVE,
    FINAL_NOT_APPLICABLE,
    FINAL_UNKNOWN,
    STAGE3_PASS3_ENGINE_CONTRACT_VERSION,
)
from .constants import CHANNEL_TYPE_KEYS, KNOWN_PERMISSION_MASK, PERMISSION_DEFINITION_VERSION, SNAPSHOT_SCHEMA_VERSION
from .fixture_export import STAGE3_FIXTURE_VERSION
from .permission_engine import (
    BYPASS_ADMINISTRATOR,
    BYPASS_NONE,
    BYPASS_OWNER,
    COMPLETENESS_COMPLETE,
    COMPLETENESS_PARTIAL,
    COMPLETENESS_UNKNOWN,
    STAGE3_PASS1_ENGINE_CONTRACT_VERSION,
)
from .permission_overwrite_engine import STAGE3_PASS2_ENGINE_CONTRACT_VERSION
from .thread_rules import (
    CHANNEL_SOURCE_URL,
    OFFICIAL_SOURCE_REVIEW_DATE,
    THREAD_ARCHIVE_RULE,
    THREAD_LOCK_RULE,
    THREAD_MEMBERSHIP_RULE,
    THREAD_MEMBERSHIP_UNKNOWN_RULE,
    THREAD_PARENT_RELATIONSHIP_RULE,
    THREAD_PERMISSIONS_SOURCE_URL,
    THREAD_RULES,
    THREAD_RULES_VERSION,
    THREAD_SEND_PERMISSION_RULE,
    THREAD_TIMEOUT_RULE,
    THREAD_TYPE_RULE,
    THREADS_SOURCE_URL,
    THREAD_VIEW_RULE,
    validate_thread_rules,
)


STAGE3_PASS4_ENGINE_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE3-PASS4-0.1"
THREAD_TYPE_PUBLIC = "PUBLIC_THREAD"
THREAD_TYPE_PRIVATE = "PRIVATE_THREAD"
THREAD_TYPE_ANNOUNCEMENT = "ANNOUNCEMENT_THREAD"
SUPPORTED_THREAD_TYPES = frozenset({THREAD_TYPE_PUBLIC, THREAD_TYPE_PRIVATE, THREAD_TYPE_ANNOUNCEMENT})
PUBLIC_THREAD_PARENTS = frozenset({"TEXT", "FORUM", "MEDIA"})
PRIVATE_THREAD_PARENTS = frozenset({"TEXT"})
ANNOUNCEMENT_THREAD_PARENTS = frozenset({"ANNOUNCEMENT"})
MEMBERSHIP_MEMBER = "MEMBER"
MEMBERSHIP_NOT_MEMBER = "NOT_MEMBER"
MEMBERSHIP_UNKNOWN = "UNKNOWN"
MEMBERSHIP_NOT_APPLICABLE = "NOT_APPLICABLE"
MEMBERSHIP_STATES = frozenset({MEMBERSHIP_MEMBER, MEMBERSHIP_NOT_MEMBER, MEMBERSHIP_UNKNOWN, MEMBERSHIP_NOT_APPLICABLE})
STATE_ACTIVE_UNLOCKED = "ACTIVE_UNLOCKED"
STATE_ACTIVE_LOCKED = "ACTIVE_LOCKED"
STATE_ARCHIVED_UNLOCKED = "ARCHIVED_UNLOCKED"
STATE_ARCHIVED_LOCKED = "ARCHIVED_LOCKED"
STATE_UNKNOWN = "UNKNOWN"
TRACE_STAGES = (
    "INPUT_VALIDATION", "PARENT_RESULT_INPUT", "THREAD_RELATIONSHIP", "PARENT_VISIBILITY",
    "THREAD_TYPE", "MEMBERSHIP", "MANAGE_THREADS", "SEND_PERMISSION", "ARCHIVED_STATE",
    "LOCKED_STATE", "TIMEOUT", "THREAD_VIEW_RESULT", "THREAD_HISTORY_RESULT",
    "THREAD_SEND_RESULT", "COMPLETENESS",
)
_MISSING = object()
_RESULT_STATES = frozenset({FINAL_ALLOWED, FINAL_DENIED, FINAL_INEFFECTIVE, FINAL_UNKNOWN, FINAL_NOT_APPLICABLE})
_SUPPORTED_SOURCE_VERSIONS = frozenset({SNAPSHOT_SCHEMA_VERSION, STAGE3_FIXTURE_VERSION})


@dataclass(frozen=True, slots=True)
class ThreadResolutionRequest:
    """Explicit pure input for one thread."""

    pass2_parent_result: Any = None
    pass3_parent_result: Any = None
    pass2_result: Any = None
    pass3_result: Any = None
    parent_channel_id: int | str | None = None
    parent_channel_type: int | str | None = None
    parent_guild_id: int | str | None = None
    thread_id: int | str | None = None
    thread_guild_id: int | str | None = None
    thread_parent_id: int | str | None = None
    thread_type: int | str | None = None
    thread_owner_id: int | str | None = None
    archived_state: bool | None = None
    locked_state: bool | None = None
    invitable_state: bool | None = None
    auto_archive_duration: int | None = None
    archive_timestamp: str | None = None
    thread_record: Any = None
    parent_channel_record: Any = None
    thread_source_health: Mapping[str, Any] | None = None
    subject_id: int | str | None = None
    bypass_state: str | None = None
    timeout_state: str | None = None
    membership_state: str | None = None
    membership_source_health: Mapping[str, Any] | None = None
    membership_records: Sequence[Any] | Mapping[str, Any] | None = None
    thread_permission_overwrites: Any = None
    input_health: Mapping[str, Any] | None = None
    pass1_contract_version: str | None = None
    pass2_contract_version: str | None = None
    pass3_contract_version: str | None = None
    capability_registry_version: str | None = None
    permission_definition_version: str | None = None
    snapshot_or_fixture_version: str | None = None

    @classmethod
    def from_parent_results(cls, pass2_parent_result: Any, pass3_parent_result: Any, **kwargs: Any) -> "ThreadResolutionRequest":
        return cls(pass2_parent_result=pass2_parent_result, pass3_parent_result=pass3_parent_result, **kwargs)


@dataclass(frozen=True, slots=True)
class ThreadCapabilityRecord:
    capability_key: str
    final_result: str
    source_permission_flag: str | None
    source_bypass: str | None
    inherited_parent_result: str
    blocking_rule_ids: tuple[str, ...]
    verification_status: str
    source_references: tuple[str, ...]
    notes: str

    @property
    def result_state(self) -> str:
        return self.final_result

    @property
    def source_refs(self) -> tuple[str, ...]:
        return self.source_references

    def as_dict(self) -> dict[str, Any]:
        return {
            "capability_key": self.capability_key,
            "final_result": self.final_result,
            "result_state": self.final_result,
            "source_permission_flag": self.source_permission_flag,
            "source_bypass": self.source_bypass,
            "inherited_parent_result": self.inherited_parent_result,
            "blocking_rule_ids": list(self.blocking_rule_ids),
            "verification_status": self.verification_status,
            "source_references": list(self.source_references),
            "source_refs": list(self.source_references),
            "notes": self.notes,
        }


@dataclass(frozen=True, slots=True)
class ThreadTraceEvent:
    sequence: int
    stage: str
    details: Mapping[str, Any]

    @property
    def code(self) -> str:
        return self.stage

    def as_dict(self) -> dict[str, Any]:
        return {"sequence": self.sequence, "stage": self.stage, "code": self.stage, "details": _canonicalize(self.details)}


@dataclass(frozen=True, slots=True)
class ThreadResolutionResult:
    engine_contract_version: str
    thread_rules_version: str
    pass3_contract_version: str
    pass2_contract_version: str
    pass1_contract_version: str
    capability_registry_version: str
    permission_definition_version: str | None
    snapshot_or_fixture_version: str | None
    guild_id: str | None
    subject_id: str | None
    thread_id: str | None
    thread_guild_id: str | None
    parent_channel_id: str | None
    parent_guild_id: str | None
    parent_channel_type: str | None
    thread_type: str | None
    thread_owner_id: str | None
    bypass_state: str | None
    timeout_state: str | None
    membership_state: str | None
    archived_state: bool | None
    locked_state: bool | None
    invitable_state: bool | None
    auto_archive_duration: int | None
    archive_timestamp: str | None
    inherited_parent_permission_decimal: str | None
    inherited_parent_permission_hex: str | None
    inherited_parent_known_permission_bits_decimal: str | None
    inherited_parent_known_permission_bits_hex: str | None
    inherited_parent_unknown_permission_bits_decimal: str | None
    inherited_parent_unknown_permission_bits_hex: str | None
    parent_visibility_result: str
    membership_gate_result: str
    manage_threads_gate_result: str
    thread_visibility_result: str
    thread_history_result: str
    thread_read_history_result: str
    thread_send_permission_result: str
    thread_state_result: str
    final_thread_send_capability_result: str
    auto_unarchive_on_send: bool | None
    inherited_capability_records: tuple[ThreadCapabilityRecord, ...]
    blocked_or_ineffective_records: tuple[ThreadCapabilityRecord, ...]
    unknown_records: tuple[ThreadCapabilityRecord, ...]
    unsupported_records: tuple[ThreadCapabilityRecord, ...]
    dependency_uncertainties: tuple[Mapping[str, Any], ...]
    completeness_state: str
    input_health_state: str
    raw_permission_bits_unchanged: bool
    reason_codes: tuple[str, ...]
    trace: tuple[ThreadTraceEvent, ...]

    @property
    def thread_view_result(self) -> str:
        return self.thread_visibility_result

    @property
    def thread_history_capability_result(self) -> str:
        return self.thread_history_result

    @property
    def thread_send_result(self) -> str:
        return self.final_thread_send_capability_result

    @property
    def effective_inherited_capability_records(self) -> tuple[ThreadCapabilityRecord, ...]:
        return self.inherited_capability_records

    @property
    def final_thread_send_result(self) -> str:
        return self.final_thread_send_capability_result

    @property
    def raw_parent_permission_decimal(self) -> str | None:
        return self.inherited_parent_permission_decimal

    @property
    def raw_parent_permission_hex(self) -> str | None:
        return self.inherited_parent_permission_hex

    @property
    def inherited_raw_parent_permission_decimal(self) -> str | None:
        return self.inherited_parent_permission_decimal

    @property
    def inherited_raw_parent_permission_hex(self) -> str | None:
        return self.inherited_parent_permission_hex

    def as_dict(self) -> dict[str, Any]:
        return {
            "engine_contract_version": self.engine_contract_version,
            "thread_rules_version": self.thread_rules_version,
            "pass3_contract_version": self.pass3_contract_version,
            "pass2_contract_version": self.pass2_contract_version,
            "pass1_contract_version": self.pass1_contract_version,
            "capability_registry_version": self.capability_registry_version,
            "permission_definition_version": self.permission_definition_version,
            "snapshot_or_fixture_version": self.snapshot_or_fixture_version,
            "guild_id": self.guild_id,
            "subject_id": self.subject_id,
            "thread_id": self.thread_id,
            "thread_guild_id": self.thread_guild_id,
            "parent_channel_id": self.parent_channel_id,
            "parent_guild_id": self.parent_guild_id,
            "parent_channel_type": self.parent_channel_type,
            "thread_type": self.thread_type,
            "thread_owner_id": self.thread_owner_id,
            "bypass_state": self.bypass_state,
            "timeout_state": self.timeout_state,
            "membership_state": self.membership_state,
            "archived_state": self.archived_state,
            "locked_state": self.locked_state,
            "invitable_state": self.invitable_state,
            "auto_archive_duration": self.auto_archive_duration,
            "archive_timestamp": self.archive_timestamp,
            "inherited_parent_permission_decimal": self.inherited_parent_permission_decimal,
            "inherited_parent_permission_hex": self.inherited_parent_permission_hex,
            "raw_parent_permission_decimal": self.inherited_parent_permission_decimal,
            "raw_parent_permission_hex": self.inherited_parent_permission_hex,
            "inherited_raw_parent_permission_decimal": self.inherited_parent_permission_decimal,
            "inherited_raw_parent_permission_hex": self.inherited_parent_permission_hex,
            "inherited_parent_known_permission_bits_decimal": self.inherited_parent_known_permission_bits_decimal,
            "inherited_parent_known_permission_bits_hex": self.inherited_parent_known_permission_bits_hex,
            "inherited_parent_unknown_permission_bits_decimal": self.inherited_parent_unknown_permission_bits_decimal,
            "inherited_parent_unknown_permission_bits_hex": self.inherited_parent_unknown_permission_bits_hex,
            "parent_visibility_result": self.parent_visibility_result,
            "membership_gate_result": self.membership_gate_result,
            "manage_threads_gate_result": self.manage_threads_gate_result,
            "thread_visibility_result": self.thread_visibility_result,
            "thread_history_result": self.thread_history_result,
            "thread_read_history_result": self.thread_read_history_result,
            "thread_send_permission_result": self.thread_send_permission_result,
            "thread_state_result": self.thread_state_result,
            "final_thread_send_capability_result": self.final_thread_send_capability_result,
            "auto_unarchive_on_send": self.auto_unarchive_on_send,
            "inherited_capability_records": [item.as_dict() for item in self.inherited_capability_records],
            "effective_inherited_capability_records": [item.as_dict() for item in self.inherited_capability_records],
            "blocked_or_ineffective_records": [item.as_dict() for item in self.blocked_or_ineffective_records],
            "unknown_records": [item.as_dict() for item in self.unknown_records],
            "unsupported_records": [item.as_dict() for item in self.unsupported_records],
            "dependency_uncertainties": [_canonicalize(item) for item in self.dependency_uncertainties],
            "completeness_state": self.completeness_state,
            "input_health_state": self.input_health_state,
            "raw_permission_bits_unchanged": self.raw_permission_bits_unchanged,
            "reason_codes": list(self.reason_codes),
            "trace": [event.as_dict() for event in self.trace],
            "official_source_review_date": OFFICIAL_SOURCE_REVIEW_DATE,
            "official_sources": [THREAD_PERMISSIONS_SOURCE_URL, THREADS_SOURCE_URL, CHANNEL_SOURCE_URL],
            "thread_rule_registry": [item.as_dict() for item in THREAD_RULES],
        }


def _canonicalize(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _canonicalize(value[key]) for key in sorted(value, key=lambda item: str(item))}
    if isinstance(value, (list, tuple)):
        return [_canonicalize(item) for item in value]
    return value


def _value(record: Any, name: str) -> Any:
    if record is None:
        return _MISSING
    if isinstance(record, Mapping):
        return record.get(name, _MISSING)
    return getattr(record, name, _MISSING)


def _pick(value: Any, record: Any, name: str) -> Any:
    if value is not None:
        return value
    found = _value(record, name)
    return None if found is _MISSING else found


def _parse_id(value: Any) -> str | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if not isinstance(value, str):
        return None
    text = value.strip()
    return str(int(text)) if text.isdecimal() and int(text) > 0 else None


def _parse_permission(value: Any) -> tuple[str | None, int | None]:
    if value is None or isinstance(value, bool):
        return None, None
    if isinstance(value, int):
        return (str(value), value) if value >= 0 else (None, None)
    if isinstance(value, str) and value.strip().isdecimal():
        parsed = int(value.strip())
        return str(parsed), parsed
    return None, None


def _normalize_type(value: Any) -> str | None:
    if isinstance(value, int) and not isinstance(value, bool):
        return CHANNEL_TYPE_KEYS.get(value, f"UNKNOWN_{value}")
    if not isinstance(value, str):
        return None
    text = value.strip().upper()
    aliases = {
        "GUILD_TEXT": "TEXT", "GUILD_ANNOUNCEMENT": "ANNOUNCEMENT", "GUILD_FORUM": "FORUM",
        "GUILD_MEDIA": "MEDIA", "PUBLIC": THREAD_TYPE_PUBLIC, "PRIVATE": THREAD_TYPE_PRIVATE,
    }
    if text in aliases:
        return aliases[text]
    return _normalize_type(int(text)) if text.isdecimal() else (text or None)


def _health_state(value: Mapping[str, Any] | None) -> tuple[str, str | None]:
    if value is None:
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_MISSING"
    if not isinstance(value, Mapping):
        return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID"
    candidates = [value[key] for key in ("status", "completeness", "structural_completeness") if key in value]
    if isinstance(value.get("complete"), bool):
        candidates.append(COMPLETENESS_COMPLETE if value["complete"] else COMPLETENESS_PARTIAL)
    for candidate in candidates:
        if isinstance(candidate, str):
            state = candidate.strip().upper()
            if state == COMPLETENESS_COMPLETE:
                return COMPLETENESS_COMPLETE, None
            if state in {COMPLETENESS_PARTIAL, "INCOMPLETE", "NOT_REQUESTED"}:
                return COMPLETENESS_PARTIAL, "INPUT_HEALTH_INCOMPLETE"
            if state == COMPLETENESS_UNKNOWN:
                return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INCOMPLETE"
    return COMPLETENESS_UNKNOWN, "INPUT_HEALTH_INVALID" if candidates else "INPUT_HEALTH_MISSING"


def _record_sequence(result: Any) -> list[Any]:
    output: list[Any] = []
    for name in ("effective_capability_records", "ineffective_grant_records", "denied_capability_records", "unknown_capability_records", "inapplicable_capability_records", "policy_only_category_records"):
        records = _value(result, name)
        if isinstance(records, Sequence) and not isinstance(records, (str, bytes)):
            output.extend(records)
    return output


def _find_record(result: Any, key: str) -> Any:
    return next((item for item in _record_sequence(result) if _value(item, "capability_key") == key), None)


def _record_result(record: Any) -> str:
    value = _value(record, "final_result")
    if value is _MISSING:
        value = _value(record, "result_state")
    return value if isinstance(value, str) and value in _RESULT_STATES else FINAL_UNKNOWN


def _record_source(record: Any) -> tuple[str | None, str | None, tuple[str, ...]]:
    flag = _value(record, "source_permission_flag")
    bypass = _value(record, "source_bypass")
    refs = _value(record, "source_references")
    if refs is _MISSING:
        refs = _value(record, "source_refs")
    return (
        flag if isinstance(flag, str) else None,
        bypass if isinstance(bypass, str) else None,
        tuple(sorted(str(item) for item in refs)) if isinstance(refs, (list, tuple, set)) else (),
    )


def _parent_state(result: Any, key: str, trusted: bool, reasons: set[str]) -> tuple[str, Any]:
    record = _find_record(result, key) if trusted else None
    if record is None:
        reasons.add(f"PARENT_CAPABILITY_MISSING_{key.upper().replace('.', '_')}")
        return FINAL_UNKNOWN, None
    return _record_result(record), record


def _membership_record_reasons(records: Any) -> set[str]:
    if records is None:
        return set()
    values = list(records.values()) if isinstance(records, Mapping) else list(records) if isinstance(records, Sequence) and not isinstance(records, (str, bytes)) else None
    if values is None:
        return {"MALFORMED_MEMBERSHIP_RECORD"}
    reasons: set[str] = set()
    seen: set[str] = set()
    for item in values:
        if not isinstance(item, Mapping):
            reasons.add("MALFORMED_MEMBERSHIP_RECORD")
            continue
        member_id = _parse_id(item.get("user_id", item.get("member_id", item.get("id"))))
        if member_id is None:
            reasons.add("MALFORMED_MEMBERSHIP_RECORD")
        elif member_id in seen:
            reasons.add("DUPLICATE_MEMBERSHIP_RECORD")
        else:
            seen.add(member_id)
    return reasons


def _thread_record(key: str, result: str, parent_result: str, *, flag: str | None, bypass: str | None, blocking: Sequence[str] = (), verification: str = "VERIFIED", notes: str = "", refs: Sequence[str] = ()) -> ThreadCapabilityRecord:
    return ThreadCapabilityRecord(key, result, flag, bypass, parent_result, tuple(sorted(set(blocking))), verification, tuple(sorted(set(refs or (THREADS_SOURCE_URL,)))), notes)


def _trace_event(stage: str, thread_id: str | None, parent_id: str | None, subject_id: str | None, capability: str | None, previous: str | None, new: str | None, rule_id: str | None, source: str, extra: Mapping[str, Any], raw_unchanged: bool) -> ThreadTraceEvent:
    details = {
        "thread_id": thread_id, "parent_id": parent_id, "subject_id": subject_id,
        "capability_key": capability, "previous_result": previous, "new_result": new,
        "rule_id": rule_id, "verification_status": "VERIFIED" if new != FINAL_UNKNOWN else "UNKNOWN",
        "source_input": source, "source": source, "raw_permission_bits_unchanged": raw_unchanged,
    }
    details.update(dict(extra))
    return ThreadTraceEvent(0, stage, details)


def evaluate_thread_permissions(request: ThreadResolutionRequest) -> ThreadResolutionResult:
    """Resolve one thread without recalculating or mutating parent results."""

    reasons: set[str] = set(validate_thread_rules())
    p2 = request.pass2_parent_result if request.pass2_parent_result is not None else request.pass2_result
    p3 = request.pass3_parent_result if request.pass3_parent_result is not None else request.pass3_result
    thread_record = request.thread_record
    parent_record = request.parent_channel_record

    parent_id = _parse_id(_pick(request.parent_channel_id, parent_record, "id"))
    parent_guild = _parse_id(_pick(request.parent_guild_id, parent_record, "guild_id"))
    parent_type = _normalize_type(_pick(request.parent_channel_type, parent_record, "type"))
    if parent_type is None:
        parent_type = _normalize_type(_pick(request.parent_channel_type, parent_record, "type_key"))
    thread_id = _parse_id(_pick(request.thread_id, thread_record, "id"))
    thread_guild = _parse_id(_pick(request.thread_guild_id, thread_record, "guild_id"))
    thread_parent = _parse_id(_pick(request.thread_parent_id, thread_record, "parent_id"))
    thread_type = _normalize_type(_pick(request.thread_type, thread_record, "type"))
    if thread_type is None:
        thread_type = _normalize_type(_pick(request.thread_type, thread_record, "type_key"))
    thread_owner = _parse_id(_pick(request.thread_owner_id, thread_record, "owner_id"))
    subject_id = _parse_id(request.subject_id)

    archived = _pick(request.archived_state, thread_record, "archived")
    locked = _pick(request.locked_state, thread_record, "locked")
    invitable = _pick(request.invitable_state, thread_record, "invitable")
    archive_duration = _pick(request.auto_archive_duration, thread_record, "auto_archive_duration")
    archive_timestamp = _pick(request.archive_timestamp, thread_record, "archive_timestamp")
    membership_input = _pick(request.membership_state, thread_record, "membership_state")
    membership_health = request.membership_source_health
    if membership_health is None:
        found = _value(thread_record, "membership_source_health")
        membership_health = None if found is _MISSING else found
    thread_health = request.thread_source_health
    if thread_health is None:
        found = _value(thread_record, "source_health")
        thread_health = None if found is _MISSING else found

    p2_contract = request.pass2_contract_version or _value(p2, "engine_contract_version")
    p3_contract = request.pass3_contract_version or _value(p3, "engine_contract_version")
    p1_contract = request.pass1_contract_version or _value(p3, "pass1_contract_version")
    if p1_contract is _MISSING:
        p1_contract = _value(p2, "pass1_contract_version")
    registry_version = request.capability_registry_version or _value(p3, "capability_registry_version")
    permission_version = request.permission_definition_version or _value(p3, "permission_definition_version")
    if permission_version is _MISSING:
        permission_version = _value(p2, "permission_definition_version")
    source_version = request.snapshot_or_fixture_version or _value(p3, "snapshot_or_fixture_version")
    if source_version is _MISSING:
        source_version = _value(p2, "snapshot_or_fixture_version")
    p1_out = p1_contract if isinstance(p1_contract, str) else STAGE3_PASS1_ENGINE_CONTRACT_VERSION
    p2_out = p2_contract if isinstance(p2_contract, str) else STAGE3_PASS2_ENGINE_CONTRACT_VERSION
    p3_out = p3_contract if isinstance(p3_contract, str) else STAGE3_PASS3_ENGINE_CONTRACT_VERSION
    registry_out = registry_version if isinstance(registry_version, str) else "GUILD-DOCTOR-CAPABILITY-REGISTRY-0.1"
    permission_out = permission_version if isinstance(permission_version, str) else None
    source_out = source_version if isinstance(source_version, str) else None

    bypass = request.bypass_state or _value(p3, "bypass_state")
    bypass = bypass.strip().upper() if isinstance(bypass, str) else None
    timeout = request.timeout_state or _value(p3, "timeout_state")
    timeout = timeout.strip().upper() if isinstance(timeout, str) else None
    input_health, input_health_reason = _health_state(request.input_health)
    thread_health_state, thread_health_reason = _health_state(thread_health)
    membership_health_state, membership_health_reason = _health_state(membership_health)
    for reason in (input_health_reason, thread_health_reason):
        if reason:
            reasons.add(reason)

    if p2 is None:
        reasons.add("PASS2_PARENT_RESULT_MISSING")
    if p3 is None:
        reasons.add("PASS3_PARENT_RESULT_MISSING")
    if p2_contract != STAGE3_PASS2_ENGINE_CONTRACT_VERSION:
        reasons.add("PASS2_CONTRACT_UNSUPPORTED")
    if p3_contract != STAGE3_PASS3_ENGINE_CONTRACT_VERSION:
        reasons.add("PASS3_CONTRACT_UNSUPPORTED")
    if p1_contract != STAGE3_PASS1_ENGINE_CONTRACT_VERSION:
        reasons.add("PASS1_CONTRACT_UNSUPPORTED")
    if registry_version != "GUILD-DOCTOR-CAPABILITY-REGISTRY-0.1":
        reasons.add("CAPABILITY_REGISTRY_VERSION_MISMATCH")
    if permission_out is None:
        reasons.add("PERMISSION_DEFINITION_VERSION_MISSING")
    elif permission_out != PERMISSION_DEFINITION_VERSION:
        reasons.add("PERMISSION_DEFINITION_VERSION_MISMATCH")
    if source_out is None:
        reasons.add("SNAPSHOT_OR_FIXTURE_VERSION_MISSING")
    elif source_out not in _SUPPORTED_SOURCE_VERSIONS:
        reasons.add("SNAPSHOT_OR_FIXTURE_VERSION_UNSUPPORTED")
    if request.input_health is None:
        reasons.add("INPUT_HEALTH_MISSING")
    if thread_health is None:
        reasons.add("THREAD_SOURCE_HEALTH_MISSING")
    if bypass not in {BYPASS_NONE, BYPASS_OWNER, BYPASS_ADMINISTRATOR}:
        reasons.add("BYPASS_STATE_INVALID")
    if timeout not in {"ACTIVE", "INACTIVE", "UNKNOWN"}:
        reasons.add("TIMEOUT_STATE_MISSING_OR_INVALID")
    p3_bypass = _value(p3, "bypass_state")
    p3_timeout = _value(p3, "timeout_state")
    if isinstance(p3_bypass, str) and bypass != p3_bypass.strip().upper():
        reasons.add("CONTRADICTORY_BYPASS_STATE")
    if isinstance(p3_timeout, str) and timeout != p3_timeout.strip().upper():
        reasons.add("PASS3_TIMEOUT_STATE_MISMATCH")

    p2_guild = _parse_id(_value(p2, "guild_id"))
    p3_guild = _parse_id(_value(p3, "guild_id"))
    p3_subject = _parse_id(_value(p3, "subject_id"))
    p3_parent = _parse_id(_value(p3, "context_id"))
    p3_parent_type = _normalize_type(_value(p3, "context_type"))
    for label, value in (("PARENT_CHANNEL_ID_INVALID", parent_id), ("PARENT_GUILD_ID_INVALID", parent_guild), ("THREAD_ID_INVALID", thread_id), ("THREAD_GUILD_ID_INVALID", thread_guild), ("THREAD_PARENT_ID_INVALID", thread_parent), ("SUBJECT_ID_INVALID", subject_id)):
        if value is None:
            reasons.add(label)
    if parent_type is None:
        reasons.add("PARENT_CHANNEL_TYPE_MISSING")
    if thread_type is None:
        reasons.add("THREAD_TYPE_MISSING")
    if p2_guild is not None and parent_guild is not None and p2_guild != parent_guild:
        reasons.add("PASS2_PARENT_GUILD_ID_MISMATCH")
    if p3_guild is not None and parent_guild is not None and p3_guild != parent_guild:
        reasons.add("PASS3_PARENT_GUILD_ID_MISMATCH")
    if p3_subject is not None and subject_id is not None and p3_subject != subject_id:
        reasons.add("PASS3_SUBJECT_ID_MISMATCH")
    if p3_parent is not None and parent_id is not None and p3_parent != parent_id:
        reasons.add("PASS3_PARENT_CHANNEL_ID_MISMATCH")
    if p3_parent_type is not None and parent_type is not None and p3_parent_type != parent_type:
        reasons.add("PASS3_PARENT_CHANNEL_TYPE_MISMATCH")
    if thread_guild is not None and parent_guild is not None and thread_guild != parent_guild:
        reasons.add("THREAD_GUILD_ID_MISMATCH")
    if thread_parent is not None and parent_id is not None and thread_parent != parent_id:
        reasons.add("THREAD_PARENT_ID_MISMATCH")
    if not isinstance(archived, bool):
        reasons.add("MISSING_OR_INVALID_ARCHIVED_STATE")
        archived = None
    if not isinstance(locked, bool):
        reasons.add("MISSING_OR_INVALID_LOCKED_STATE")
        locked = None
    if archive_duration is not None and (isinstance(archive_duration, bool) or not isinstance(archive_duration, int)):
        reasons.add("MALFORMED_THREAD_RECORD")
        archive_duration = None
    if request.thread_permission_overwrites not in (None, (), [], {}):
        reasons.add("THREAD_OVERWRITES_UNSUPPORTED")
    record_overwrites = _value(thread_record, "permission_overwrites")
    if record_overwrites not in (_MISSING, None, (), [], {}):
        reasons.add("THREAD_OVERWRITES_UNSUPPORTED")

    supported_relationship = (
        (thread_type == THREAD_TYPE_PUBLIC and parent_type in PUBLIC_THREAD_PARENTS)
        or (thread_type == THREAD_TYPE_PRIVATE and parent_type in PRIVATE_THREAD_PARENTS)
        or (thread_type == THREAD_TYPE_ANNOUNCEMENT and parent_type in ANNOUNCEMENT_THREAD_PARENTS)
    )
    if thread_type not in SUPPORTED_THREAD_TYPES:
        reasons.add("UNSUPPORTED_THREAD_TYPE")
    elif thread_type == THREAD_TYPE_PUBLIC and parent_type not in PUBLIC_THREAD_PARENTS:
        reasons.add("INVALID_PUBLIC_THREAD_PARENT_TYPE")
    elif thread_type == THREAD_TYPE_PRIVATE and parent_type not in PRIVATE_THREAD_PARENTS:
        reasons.add("INVALID_PRIVATE_THREAD_PARENT_TYPE")
    elif thread_type == THREAD_TYPE_ANNOUNCEMENT and parent_type not in ANNOUNCEMENT_THREAD_PARENTS:
        reasons.add("INVALID_ANNOUNCEMENT_THREAD_PARENT_TYPE")
    if parent_type not in {"TEXT", "ANNOUNCEMENT", "FORUM", "MEDIA"}:
        reasons.add("UNSUPPORTED_PARENT_CHANNEL_TYPE")

    membership = membership_input.strip().upper() if isinstance(membership_input, str) else None
    if thread_type in {THREAD_TYPE_PUBLIC, THREAD_TYPE_ANNOUNCEMENT} and membership is None:
        membership = MEMBERSHIP_NOT_APPLICABLE
    if membership not in MEMBERSHIP_STATES:
        reasons.add("MISSING_PRIVATE_THREAD_MEMBERSHIP" if thread_type == THREAD_TYPE_PRIVATE else "MEMBERSHIP_STATE_INVALID")
        membership = MEMBERSHIP_UNKNOWN
    reasons.update(_membership_record_reasons(request.membership_records))
    if thread_type == THREAD_TYPE_PRIVATE:
        if membership_health_state != COMPLETENESS_COMPLETE:
            reasons.add("INCOMPLETE_MEMBERSHIP_SOURCE")
            membership_effective = MEMBERSHIP_UNKNOWN
        else:
            membership_effective = membership
        if membership_health_reason:
            reasons.add(membership_health_reason)
    else:
        membership_effective = MEMBERSHIP_NOT_APPLICABLE

    pass2_complete = _value(p2, "completeness_state") == COMPLETENESS_COMPLETE
    pass3_complete = _value(p3, "completeness_state") == COMPLETENESS_COMPLETE
    pass3_health_complete = _value(p3, "input_health_state") == COMPLETENESS_COMPLETE
    p3_reason_codes = _value(p3, "reason_codes")
    p3_has_unrelated_unknown = isinstance(p3_reason_codes, Sequence) and "CAPABILITY_RESULT_UNKNOWN" in p3_reason_codes
    p3_required_records_known = p3 is not None and all(
        _find_record(p3, key) is not None and _record_result(_find_record(p3, key)) != FINAL_UNKNOWN
        for key in ("view.channel", "message.read_history", "thread.manage", "thread.message_send")
    )
    p3_partial_but_required_thread_evidence_trusted = not pass3_complete and p3_has_unrelated_unknown and p3_required_records_known
    trusted_parent = p2 is not None and p3 is not None and pass2_complete and (pass3_complete or p3_partial_but_required_thread_evidence_trusted) and pass3_health_complete and not reasons.intersection({"PASS2_CONTRACT_UNSUPPORTED", "PASS3_CONTRACT_UNSUPPORTED", "PASS1_CONTRACT_UNSUPPORTED", "CAPABILITY_REGISTRY_VERSION_MISMATCH", "PASS3_PARENT_CHANNEL_ID_MISMATCH", "PASS3_PARENT_CHANNEL_TYPE_MISMATCH", "PASS3_SUBJECT_ID_MISMATCH"})
    if p2 is not None and not pass2_complete:
        reasons.add("PASS2_PARENT_RESULT_INCOMPLETE")
    if p3 is not None and not pass3_complete and not p3_partial_but_required_thread_evidence_trusted:
        reasons.add("PASS3_PARENT_RESULT_INCOMPLETE")
    if p3 is not None and not pass3_health_complete:
        reasons.add("PASS3_PARENT_HEALTH_INCOMPLETE")

    p2_decimal, p2_raw = _parse_permission(_value(p2, "raw_context_permission_decimal"))
    p3_decimal, p3_raw = _parse_permission(_value(p3, "raw_context_permission_decimal"))
    p2_hex = _value(p2, "raw_context_permission_hex")
    p3_hex = _value(p3, "raw_context_permission_hex")
    if p2 is not None and p2_raw is None:
        reasons.add("MALFORMED_PARENT_PERMISSION_VALUES")
    if p3 is not None and p3_raw is None:
        reasons.add("MALFORMED_PARENT_PERMISSION_VALUES")
    if p2_raw is not None and p3_raw is not None and p2_raw != p3_raw:
        reasons.add("PASS2_PASS3_RAW_PERMISSION_MISMATCH")
    raw_parent = p2_raw if p2_raw is not None and p3_raw in (None, p2_raw) else None
    raw_hex = format(raw_parent, "#x") if raw_parent is not None else None
    if p2_raw is not None and p2_hex not in (_MISSING, None, raw_hex):
        reasons.add("PASS2_RAW_PERMISSION_HEX_MISMATCH")
    if p3_raw is not None and p3_hex not in (_MISSING, None, raw_hex):
        reasons.add("PASS3_RAW_PERMISSION_HEX_MISMATCH")
    known = raw_parent & KNOWN_PERMISSION_MASK if raw_parent is not None else None
    unknown = raw_parent & ~KNOWN_PERMISSION_MASK if raw_parent is not None else None
    for result, prefix in ((p2, "PASS2"), (p3, "PASS3")):
        supplied_known = _parse_permission(_value(result, "known_context_permission_bits_decimal"))[1]
        supplied_unknown = _parse_permission(_value(result, "unknown_context_permission_bits_decimal"))[1]
        if known is not None and supplied_known != known:
            reasons.add(f"{prefix}_KNOWN_PERMISSION_BITS_MISMATCH")
        if unknown is not None and supplied_unknown != unknown:
            reasons.add(f"{prefix}_UNKNOWN_PERMISSION_BITS_MISMATCH")
    if unknown not in (None, 0):
        reasons.add("UNKNOWN_PERMISSION_BITS_PRESENT")
    raw_unchanged = raw_parent is not None and raw_hex == format(raw_parent, "#x") and known == (raw_parent & KNOWN_PERMISSION_MASK) and unknown == (raw_parent & ~KNOWN_PERMISSION_MASK) and p2_raw == p3_raw

    trace: list[ThreadTraceEvent] = [
        _trace_event("INPUT_VALIDATION", thread_id, parent_id, subject_id, None, None, None, None, "input", {"reason_codes": sorted(reasons)}, raw_unchanged),
        _trace_event("PARENT_RESULT_INPUT", thread_id, parent_id, subject_id, None, None, None, None, "Pass 2 and Pass 3", {"trusted_parent": trusted_parent}, raw_unchanged),
        _trace_event("THREAD_RELATIONSHIP", thread_id, parent_id, subject_id, None, None, None, THREAD_PARENT_RELATIONSHIP_RULE, "thread record", {"guild_ids_match": thread_guild == parent_guild, "parent_ids_match": thread_parent == parent_id}, raw_unchanged),
        _trace_event("THREAD_TYPE", thread_id, parent_id, subject_id, None, None, None, THREAD_TYPE_RULE, "thread and parent records", {"supported": supported_relationship}, raw_unchanged),
    ]

    parent_view, parent_view_record = _parent_state(p3, "view.channel", trusted_parent, reasons)
    parent_history, parent_history_record = _parent_state(p3, "message.read_history", trusted_parent, reasons)
    manage_threads, manage_record = _parent_state(p3, "thread.manage", trusted_parent, reasons)
    send_permission, send_record = _parent_state(p3, "thread.message_send", trusted_parent, reasons)
    view_flag, view_bypass, view_refs = _record_source(parent_view_record)
    history_flag, history_bypass, history_refs = _record_source(parent_history_record)
    manage_flag, manage_bypass, manage_refs = _record_source(manage_record)
    send_flag, send_bypass, send_refs = _record_source(send_record)
    trace.extend([
        _trace_event("PARENT_VISIBILITY", thread_id, parent_id, subject_id, "view.channel", FINAL_UNKNOWN, parent_view, THREAD_VIEW_RULE, "Pass 3 parent result", {"parent_visibility": parent_view}, raw_unchanged),
        _trace_event("MEMBERSHIP", thread_id, parent_id, subject_id, "thread.membership", FINAL_UNKNOWN, membership_effective if thread_type == THREAD_TYPE_PRIVATE else MEMBERSHIP_NOT_APPLICABLE, THREAD_MEMBERSHIP_UNKNOWN_RULE if membership_effective == MEMBERSHIP_UNKNOWN else THREAD_MEMBERSHIP_RULE, "membership source", {"membership_state": membership_effective}, raw_unchanged),
        _trace_event("MANAGE_THREADS", thread_id, parent_id, subject_id, "thread.manage", FINAL_UNKNOWN, manage_threads, "MANAGE_THREADS", "Pass 3 parent result", {"manage_threads": manage_threads}, raw_unchanged),
        _trace_event("SEND_PERMISSION", thread_id, parent_id, subject_id, "thread.message_send", FINAL_UNKNOWN, send_permission, THREAD_SEND_PERMISSION_RULE, "Pass 3 parent result", {"send_permission": send_permission}, raw_unchanged),
    ])

    parent_visibility = parent_view if parent_view in _RESULT_STATES else FINAL_UNKNOWN
    if thread_type in {THREAD_TYPE_PUBLIC, THREAD_TYPE_ANNOUNCEMENT}:
        membership_gate = FINAL_NOT_APPLICABLE
        thread_visibility = parent_visibility if parent_visibility != FINAL_ALLOWED else FINAL_ALLOWED if supported_relationship else FINAL_UNKNOWN
    elif thread_type == THREAD_TYPE_PRIVATE and supported_relationship:
        membership_gate = {MEMBERSHIP_MEMBER: FINAL_ALLOWED, MEMBERSHIP_NOT_MEMBER: FINAL_DENIED, MEMBERSHIP_UNKNOWN: FINAL_UNKNOWN}.get(membership_effective, FINAL_UNKNOWN)
        if parent_visibility != FINAL_ALLOWED:
            thread_visibility = parent_visibility
        elif manage_threads == FINAL_ALLOWED or membership_gate == FINAL_ALLOWED:
            thread_visibility = FINAL_ALLOWED
        elif manage_threads in {FINAL_DENIED, FINAL_INEFFECTIVE} and membership_gate == FINAL_DENIED:
            thread_visibility = FINAL_DENIED
        else:
            thread_visibility = FINAL_UNKNOWN
    else:
        membership_gate = FINAL_UNKNOWN
        thread_visibility = FINAL_UNKNOWN
    trace.append(_trace_event("THREAD_VIEW_RESULT", thread_id, parent_id, subject_id, "thread.visibility", FINAL_UNKNOWN, thread_visibility, THREAD_VIEW_RULE, "parent visibility and membership", {"membership_gate": membership_gate}, raw_unchanged))
    thread_history = parent_history if thread_visibility == FINAL_ALLOWED else thread_visibility
    if thread_history not in _RESULT_STATES:
        thread_history = FINAL_UNKNOWN
    trace.append(_trace_event("THREAD_HISTORY_RESULT", thread_id, parent_id, subject_id, "thread.read_history", FINAL_UNKNOWN, thread_history, "READ_MESSAGE_HISTORY", "Pass 3 parent result", {"parent_history": parent_history}, raw_unchanged))

    send_rules: list[str] = []
    if not supported_relationship:
        final_send = FINAL_UNKNOWN
        send_rules.append(THREAD_TYPE_RULE)
    elif thread_visibility != FINAL_ALLOWED:
        final_send = thread_visibility
        if parent_visibility != FINAL_ALLOWED:
            send_rules.append(THREAD_VIEW_RULE)
        if thread_type == THREAD_TYPE_PRIVATE and membership_gate != FINAL_ALLOWED:
            send_rules.append(THREAD_MEMBERSHIP_RULE if membership_gate == FINAL_DENIED else THREAD_MEMBERSHIP_UNKNOWN_RULE)
    elif send_permission != FINAL_ALLOWED:
        final_send = send_permission
        if timeout == "ACTIVE" and bypass not in {BYPASS_OWNER, BYPASS_ADMINISTRATOR}:
            send_rules.append(THREAD_TIMEOUT_RULE)
        elif timeout == "UNKNOWN":
            send_rules.append(THREAD_TIMEOUT_RULE)
        else:
            send_rules.append(THREAD_SEND_PERMISSION_RULE)
    elif timeout == "ACTIVE" and bypass not in {BYPASS_OWNER, BYPASS_ADMINISTRATOR}:
        final_send = FINAL_INEFFECTIVE
        send_rules.append(THREAD_TIMEOUT_RULE)
    elif timeout == "UNKNOWN":
        final_send = FINAL_UNKNOWN
        send_rules.append(THREAD_TIMEOUT_RULE)
    elif locked is True and manage_threads == FINAL_UNKNOWN:
        final_send = FINAL_UNKNOWN
        send_rules.append(THREAD_LOCK_RULE)
    elif locked is True and manage_threads != FINAL_ALLOWED:
        final_send = FINAL_INEFFECTIVE
        send_rules.append(THREAD_LOCK_RULE)
    elif locked is None:
        final_send = FINAL_UNKNOWN
        send_rules.append(THREAD_LOCK_RULE)
    elif archived is None:
        final_send = FINAL_UNKNOWN
        send_rules.append(THREAD_ARCHIVE_RULE)
    else:
        final_send = FINAL_ALLOWED
    trace.extend([
        _trace_event("ARCHIVED_STATE", thread_id, parent_id, subject_id, "thread.archive", FINAL_UNKNOWN, FINAL_UNKNOWN if archived is None else FINAL_NOT_APPLICABLE if archived else FINAL_ALLOWED, THREAD_ARCHIVE_RULE, "thread record", {"archived": archived}, raw_unchanged),
        _trace_event("LOCKED_STATE", thread_id, parent_id, subject_id, "thread.lock", FINAL_UNKNOWN, FINAL_UNKNOWN if locked is None else FINAL_INEFFECTIVE if locked else FINAL_ALLOWED, THREAD_LOCK_RULE, "thread record", {"locked": locked, "manage_threads": manage_threads}, raw_unchanged),
        _trace_event("TIMEOUT", thread_id, parent_id, subject_id, "thread.message_send", FINAL_UNKNOWN, final_send if timeout in {"ACTIVE", "UNKNOWN"} else FINAL_ALLOWED, THREAD_TIMEOUT_RULE, "Pass 3 timeout result", {"timeout_state": timeout, "bypass_state": bypass}, raw_unchanged),
        _trace_event("THREAD_SEND_RESULT", thread_id, parent_id, subject_id, "thread.message_send", FINAL_UNKNOWN, final_send, send_rules[0] if send_rules else None, "parent gates and thread state", {"send_permission": send_permission}, raw_unchanged),
    ])

    auto_unarchive = None if archived is None else bool(archived) if final_send == FINAL_ALLOWED else False
    if archived is True and final_send == FINAL_ALLOWED:
        reasons.add("ARCHIVED_SEND_PREDICTS_AUTO_UNARCHIVE")
    if archived is None or locked is None:
        state = STATE_UNKNOWN
    elif archived and locked:
        state = STATE_ARCHIVED_LOCKED
    elif archived:
        state = STATE_ARCHIVED_UNLOCKED
    elif locked:
        state = STATE_ACTIVE_LOCKED
    else:
        state = STATE_ACTIVE_UNLOCKED

    verification = "VERIFIED" if trusted_parent and supported_relationship else "UNKNOWN"
    view_out = _thread_record("thread.visibility", thread_visibility, parent_view, flag=view_flag or "VIEW_CHANNEL", bypass=view_bypass, blocking=(THREAD_VIEW_RULE,) if thread_visibility != FINAL_ALLOWED else (), verification=verification, notes="Parent VIEW_CHANNEL is required for thread visibility.", refs=view_refs + (THREAD_PERMISSIONS_SOURCE_URL, THREADS_SOURCE_URL))
    history_out = _thread_record("thread.read_history", thread_history, parent_history, flag=history_flag or "READ_MESSAGE_HISTORY", bypass=history_bypass, blocking=("READ_MESSAGE_HISTORY",) if thread_history != FINAL_ALLOWED else (), verification=verification, notes="History requires thread visibility and inherited READ_MESSAGE_HISTORY.", refs=history_refs + (THREAD_PERMISSIONS_SOURCE_URL, THREADS_SOURCE_URL))
    send_out = _thread_record("thread.message_send", final_send, send_permission, flag=send_flag or "SEND_MESSAGES_IN_THREADS", bypass=send_bypass, blocking=send_rules, verification=verification, notes="SEND_MESSAGES has no effect in a thread; SEND_MESSAGES_IN_THREADS and all state gates are evaluated.", refs=send_refs + (THREAD_PERMISSIONS_SOURCE_URL, THREADS_SOURCE_URL))
    inherited = tuple(sorted((view_out, history_out, send_out), key=lambda item: item.capability_key))
    blocked = tuple(item for item in inherited if item.final_result in {FINAL_DENIED, FINAL_INEFFECTIVE})
    unknown_records = tuple(item for item in inherited if item.final_result == FINAL_UNKNOWN)
    unsupported = (_thread_record("thread.relationship", FINAL_UNKNOWN, FINAL_UNKNOWN, flag=None, bypass=None, blocking=(THREAD_TYPE_RULE,), verification="UNSUPPORTED", notes="Unsupported thread and parent relationship.", refs=(CHANNEL_SOURCE_URL, THREADS_SOURCE_URL)),) if not supported_relationship else ()

    if input_health != COMPLETENESS_COMPLETE:
        reasons.add("INPUT_HEALTH_INCOMPLETE")
    if thread_health_state != COMPLETENESS_COMPLETE:
        reasons.add("THREAD_SOURCE_HEALTH_INCOMPLETE")
    blockers = {
        "PASS2_PARENT_RESULT_MISSING", "PASS3_PARENT_RESULT_MISSING", "PASS2_CONTRACT_UNSUPPORTED", "PASS3_CONTRACT_UNSUPPORTED", "PASS1_CONTRACT_UNSUPPORTED", "CAPABILITY_REGISTRY_VERSION_MISMATCH", "PERMISSION_DEFINITION_VERSION_MISSING", "PERMISSION_DEFINITION_VERSION_MISMATCH", "SNAPSHOT_OR_FIXTURE_VERSION_MISSING", "SNAPSHOT_OR_FIXTURE_VERSION_UNSUPPORTED", "INPUT_HEALTH_MISSING", "INPUT_HEALTH_INVALID", "INPUT_HEALTH_INCOMPLETE", "THREAD_SOURCE_HEALTH_MISSING", "THREAD_SOURCE_HEALTH_INCOMPLETE", "INCOMPLETE_MEMBERSHIP_SOURCE", "MISSING_PRIVATE_THREAD_MEMBERSHIP", "MALFORMED_MEMBERSHIP_RECORD", "DUPLICATE_MEMBERSHIP_RECORD", "MISSING_OR_INVALID_ARCHIVED_STATE", "MISSING_OR_INVALID_LOCKED_STATE", "UNSUPPORTED_THREAD_TYPE", "UNSUPPORTED_PARENT_CHANNEL_TYPE", "THREAD_OVERWRITES_UNSUPPORTED", "INVALID_PUBLIC_THREAD_PARENT_TYPE", "INVALID_PRIVATE_THREAD_PARENT_TYPE", "INVALID_ANNOUNCEMENT_THREAD_PARENT_TYPE",
    }
    complete = not reasons.intersection(blockers) and trusted_parent and not p3_partial_but_required_thread_evidence_trusted and raw_parent is not None and unknown == 0 and supported_relationship and parent_view != FINAL_UNKNOWN and parent_history != FINAL_UNKNOWN and manage_threads != FINAL_UNKNOWN and send_permission != FINAL_UNKNOWN and thread_visibility != FINAL_UNKNOWN and thread_history != FINAL_UNKNOWN and final_send != FINAL_UNKNOWN and archived is not None and locked is not None and input_health == COMPLETENESS_COMPLETE and thread_health_state == COMPLETENESS_COMPLETE and (thread_type != THREAD_TYPE_PRIVATE or membership_health_state == COMPLETENESS_COMPLETE)
    completeness = COMPLETENESS_COMPLETE if complete else COMPLETENESS_UNKNOWN if p2 is None or p3 is None or raw_parent is None or request.input_health is None else COMPLETENESS_PARTIAL
    reasons.add("THREAD_RESOLUTION_COMPLETE" if completeness == COMPLETENESS_COMPLETE else "THREAD_RESOLUTION_INCOMPLETE")
    health_out = COMPLETENESS_UNKNOWN if COMPLETENESS_UNKNOWN in {input_health, thread_health_state} else COMPLETENESS_PARTIAL if COMPLETENESS_PARTIAL in {input_health, thread_health_state, membership_health_state if thread_type == THREAD_TYPE_PRIVATE else COMPLETENESS_COMPLETE} else COMPLETENESS_COMPLETE
    trace.append(_trace_event("COMPLETENESS", thread_id, parent_id, subject_id, None, None, None, None, "completeness", {"state": completeness, "reason_codes": sorted(reasons)}, raw_unchanged))
    trace.sort(key=lambda event: (TRACE_STAGES.index(event.stage), str(event.details.get("capability_key", "")), str(event.details.get("rule_id", "")), str(event.details.get("source", ""))))
    trace = [ThreadTraceEvent(index, event.stage, event.details) for index, event in enumerate(trace, start=1)]

    return ThreadResolutionResult(
        engine_contract_version=STAGE3_PASS4_ENGINE_CONTRACT_VERSION,
        thread_rules_version=THREAD_RULES_VERSION,
        pass3_contract_version=p3_out,
        pass2_contract_version=p2_out,
        pass1_contract_version=p1_out,
        capability_registry_version=registry_out,
        permission_definition_version=permission_out,
        snapshot_or_fixture_version=source_out,
        guild_id=parent_guild,
        subject_id=subject_id,
        thread_id=thread_id,
        thread_guild_id=thread_guild,
        parent_channel_id=parent_id,
        parent_guild_id=parent_guild,
        parent_channel_type=parent_type,
        thread_type=thread_type,
        thread_owner_id=thread_owner,
        bypass_state=bypass,
        timeout_state=timeout,
        membership_state=membership_effective,
        archived_state=archived,
        locked_state=locked,
        invitable_state=invitable if isinstance(invitable, bool) else None,
        auto_archive_duration=archive_duration,
        archive_timestamp=archive_timestamp if isinstance(archive_timestamp, str) else None,
        inherited_parent_permission_decimal=p2_decimal if raw_parent is not None else None,
        inherited_parent_permission_hex=raw_hex,
        inherited_parent_known_permission_bits_decimal=str(known) if known is not None else None,
        inherited_parent_known_permission_bits_hex=format(known, "#x") if known is not None else None,
        inherited_parent_unknown_permission_bits_decimal=str(unknown) if unknown is not None else None,
        inherited_parent_unknown_permission_bits_hex=format(unknown, "#x") if unknown is not None else None,
        parent_visibility_result=parent_visibility,
        membership_gate_result=membership_gate,
        manage_threads_gate_result=manage_threads,
        thread_visibility_result=thread_visibility,
        thread_history_result=thread_history,
        thread_read_history_result=thread_history,
        thread_send_permission_result=send_permission,
        thread_state_result=state,
        final_thread_send_capability_result=final_send,
        auto_unarchive_on_send=auto_unarchive,
        inherited_capability_records=inherited,
        blocked_or_ineffective_records=blocked,
        unknown_records=unknown_records,
        unsupported_records=unsupported,
        dependency_uncertainties=({"rule_id": THREAD_MEMBERSHIP_UNKNOWN_RULE, "state": FINAL_UNKNOWN, "notes": "Membership source was incomplete or explicitly unknown."},) if membership_effective == MEMBERSHIP_UNKNOWN else (),
        completeness_state=completeness,
        input_health_state=health_out,
        raw_permission_bits_unchanged=raw_unchanged,
        reason_codes=tuple(sorted(reasons)),
        trace=tuple(trace),
    )


resolve_thread_permissions = evaluate_thread_permissions
evaluate_thread_resolution = evaluate_thread_permissions


__all__ = [
    "ANNOUNCEMENT_THREAD_PARENTS", "MEMBERSHIP_MEMBER", "MEMBERSHIP_NOT_APPLICABLE", "MEMBERSHIP_NOT_MEMBER", "MEMBERSHIP_UNKNOWN",
    "PUBLIC_THREAD_PARENTS", "PRIVATE_THREAD_PARENTS", "STAGE3_PASS4_ENGINE_CONTRACT_VERSION", "SUPPORTED_THREAD_TYPES",
    "THREAD_TYPE_ANNOUNCEMENT", "THREAD_TYPE_PRIVATE", "THREAD_TYPE_PUBLIC", "TRACE_STAGES",
    "ThreadCapabilityRecord", "ThreadResolutionRequest", "ThreadResolutionResult", "ThreadTraceEvent",
    "evaluate_thread_permissions", "evaluate_thread_resolution", "resolve_thread_permissions",
]
