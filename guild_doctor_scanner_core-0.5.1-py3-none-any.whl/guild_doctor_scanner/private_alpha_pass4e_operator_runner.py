"""Fail-closed orchestration helpers for the Pass4E operator workflow.

This module deliberately contains no token retrieval and no ad-hoc Discord
calls.  Callers must provide the already-approved transport and token boundary;
all authority and configuration checks happen before a runtime handoff.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .private_alpha_configuration import PrivateAlphaConfiguration, load_configuration
from .private_alpha_live_interaction_preflight import (
    LiveInteractionPreflightResult,
    READY_STATE,
    run_live_interaction_preflight,
)
from .private_alpha_live_validation_configuration import (
    LiveValidationConfiguration,
    load_live_configuration,
)
from .private_alpha_pass4e_repair4_runner import EXACT_START_PHRASE
from .private_alpha_pass4e_session_artifacts import SessionArtifactPaths
from .private_alpha_pass4e_validation_lifecycle import (
    start_validation_gateway_runtime,
    validate_runtime_mode_binding,
)
from .private_alpha_pass4e_validation_authority import ValidationRuntimeAuthority
from .private_alpha_pass4e_validation_surface import ValidationSurfaceMode
from .private_alpha_pass4e_validation_sync import SyncProof


@dataclass(frozen=True, slots=True)
class OperatorRunContext:
    project_root: Path
    active_configuration: PrivateAlphaConfiguration
    live_configuration: LiveValidationConfiguration
    preflight: LiveInteractionPreflightResult
    snapshot_path: Path
    runtime_receipt_path: Path
    session_artifacts: SessionArtifactPaths
    sync_proof: SyncProof


def build_context(
    *,
    project_root: Path,
    active_configuration_path: Path,
    live_configuration_path: Path,
    snapshot_path: Path,
    runtime_receipt_path: Path,
    session_artifacts: SessionArtifactPaths,
    secret_presence: Any,
    sync_proof: SyncProof,
) -> OperatorRunContext:
    """Load and bind all local inputs without contacting Discord."""
    root = Path(project_root).resolve()
    active = load_configuration(active_configuration_path)
    live = load_live_configuration(live_configuration_path, project_root=root)
    preflight = run_live_interaction_preflight(
        root=root,
        active_configuration_path=Path(active_configuration_path),
        live_configuration_path=Path(live_configuration_path),
        snapshot_path=Path(snapshot_path),
        secret_presence=secret_presence,
    )
    if preflight.overall_state != READY_STATE:
        raise RuntimeError("STAGE8_PASS4E_OPERATOR_PREFLIGHT_NOT_READY")
    artifacts = session_artifacts.validated()
    receipt = Path(runtime_receipt_path).resolve()
    if receipt != artifacts.receipt_path:
        raise RuntimeError("STAGE8_PASS4E_OPERATOR_RECEIPT_BINDING_MISMATCH")
    return OperatorRunContext(
        root, active, live, preflight, Path(snapshot_path).resolve(), receipt,
        artifacts, sync_proof,
    )


async def run_authorized_session(
    *,
    context: OperatorRunContext,
    authority: ValidationRuntimeAuthority,
    start_phrase: str,
    token_provider: Callable[[], str],
    client_factory: Callable[[Any], Any] | None = None,
    discord_module: Any = None,
) -> Any:
    """Run only after the exact phrase and all current bindings validate."""
    if start_phrase != EXACT_START_PHRASE:
        raise RuntimeError("STAGE8_PASS4E_REPAIR4_START_PHRASE_REQUIRED")
    validate_runtime_mode_binding(
        authority,
        configuration=context.active_configuration,
        pre_live_sync_proof=context.sync_proof,
    )
    return await start_validation_gateway_runtime(
        authority=authority,
        preflight=context.preflight,
        active_configuration=context.active_configuration,
        live_configuration=context.live_configuration,
        pre_live_sync_proof=context.sync_proof,
        project_root=context.project_root,
        snapshot_path=context.snapshot_path,
        runtime_receipt_path=context.runtime_receipt_path,
        session_artifacts=context.session_artifacts,
        token_provider=token_provider,
        client_factory=client_factory,
        discord_module=discord_module,
    )


__all__ = ["OperatorRunContext", "build_context", "run_authorized_session"]
