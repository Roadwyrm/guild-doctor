"""Owner-only bounded autocomplete for the three frozen comparison catalogs."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .action_registry import ACTION_RULES_BY_KEY
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY
from .discord_command_manifest import COMMAND_MANIFEST
from .private_alpha_interaction_intake import AUTHORIZED_LIVE_ROUTES, LiveAuthorizationContext


BOUNDED_AUTOCOMPLETE_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-BOUNDED-AUTOCOMPLETE-0.2"
AUTOCOMPLETE_RESPONSE_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-AUTOCOMPLETE-RESPONSE-BOUNDARY-0.2"
DISCORD_CHOICE_LIMIT = 25
SESSION_AUTOCOMPLETE_RESPONSE_LIMIT = 12
DISCORD_CHOICE_TEXT_LIMIT = 100

_FOCUSED_OPTIONS = {
    item.key: tuple(option.name for option in item.options if option.autocomplete)
    for item in COMMAND_MANIFEST if item.key in AUTHORIZED_LIVE_ROUTES
}


@dataclass(frozen=True, slots=True)
class AutocompleteSource:
    interaction_type: int
    command_type: int
    guild_id: str
    actor_id: str
    route_name: str
    focused_option_name: str
    current_value: str


@dataclass(frozen=True, slots=True)
class AutocompleteDecision:
    state: str
    stable_error: str | None
    route_name: str | None
    option_name: str | None
    choices: tuple[tuple[str, str], ...]
    domain_invocation_count: int = 0
    raw_interaction_retained: bool = False


@dataclass(frozen=True, slots=True)
class AutocompleteBudgetSnapshot:
    requests_received: int
    responses_attempted: int
    responses_completed: int
    response_failures: int
    maximum_responses: int
    last_failure_classification: str | None


class AutocompleteBoundaryError(RuntimeError):
    """Stable, privacy-safe autocomplete boundary failure."""

    def __init__(self, classification: str):
        self.classification = classification
        super().__init__(classification)


def _catalog(route_name: str) -> tuple[tuple[str, str], ...]:
    if route_name == "compare-role-permission":
        values = tuple(flag.name for flag in DEFAULT_CAPABILITY_REGISTRY.permission_flags)
    elif route_name == "compare-role-capability":
        values = tuple(item.capability_key for item in DEFAULT_CAPABILITY_REGISTRY.capabilities)
    elif route_name == "compare-role-action":
        values = tuple(sorted(ACTION_RULES_BY_KEY))
    else:
        return ()
    # Discord presents the choice *name* to the operator and returns its value.
    # Showing the canonical value in the name removes ambiguity without changing
    # the frozen value delivered to the command callback.
    return tuple((f"{value.replace('_', ' ').replace('.', ' ').title()} ({value})", value) for value in values)


def _search_text(label: str, canonical_value: str) -> str:
    """Return a stable searchable form for labels, dots, and underscores."""
    return " ".join((
        label, canonical_value, canonical_value.replace("_", " "),
        canonical_value.replace(".", " "), canonical_value.replace(".", "_"),
    )).casefold()


def evaluate_autocomplete(source: AutocompleteSource, *, context: LiveAuthorizationContext) -> AutocompleteDecision:
    if source.interaction_type != 4 or source.command_type != 1:
        return AutocompleteDecision("REJECTED", "STAGE8_PASS4E_AUTOCOMPLETE_TYPE_INVALID", None, None, ())
    if source.guild_id != context.allowlisted_guild_id:
        return AutocompleteDecision("REJECTED", "STAGE8_PASS4D_GUILD_NOT_ALLOWLISTED", None, None, ())
    if source.actor_id != context.owner_member_id:
        return AutocompleteDecision("REJECTED", "STAGE6_OWNER_ONLY", None, None, ())
    if source.route_name not in AUTHORIZED_LIVE_ROUTES:
        return AutocompleteDecision("REJECTED", "STAGE8_PASS4D_ROUTE_NOT_AUTHORIZED", None, None, ())
    if source.focused_option_name not in _FOCUSED_OPTIONS.get(source.route_name, ()):
        return AutocompleteDecision("REJECTED", "STAGE8_PASS4E_AUTOCOMPLETE_OPTION_INVALID", source.route_name, None, ())
    catalog = _catalog(source.route_name)
    if not catalog:
        return AutocompleteDecision("REJECTED", "STAGE8_PASS4E_AUTOCOMPLETE_CATALOG_UNAVAILABLE", source.route_name, source.focused_option_name, ())
    needle = source.current_value.casefold().strip()
    matching = tuple(item for item in catalog if not needle or needle in _search_text(*item))
    ranked = sorted(matching, key=lambda item: (
        0 if item[1].casefold() == needle else 1 if item[1].casefold().startswith(needle) else 2,
        item[0].casefold(), item[1],
    ))
    # Catalogs are frozen and unique; retain this defensive check so a future
    # registry expansion cannot emit duplicate canonical choice values.
    choices: list[tuple[str, str]] = []
    seen: set[str] = set()
    for item in ranked:
        if item[1] not in seen:
            seen.add(item[1]); choices.append(item)
        if len(choices) == DISCORD_CHOICE_LIMIT:
            break
    return AutocompleteDecision("ACCEPTED", None, source.route_name, source.focused_option_name, tuple(choices))


def query_length_classification(value: str) -> str:
    if not isinstance(value, str) or not value:
        return "EMPTY"
    if value in {"VIEW_CHANNEL", "message.send", "member.kick"}:
        return "EXACT_CANONICAL"
    if len(value) <= 4:
        return "SHORT_PARTIAL"
    if len(value) <= DISCORD_CHOICE_TEXT_LIMIT:
        return "PARTIAL_OR_UNMATCHED"
    return "OVERSIZED"


def validate_choice_payload(choices: tuple[tuple[str, str], ...]) -> None:
    if not isinstance(choices, tuple) or len(choices) > DISCORD_CHOICE_LIMIT:
        raise AutocompleteBoundaryError("AUTOCOMPLETE_CHOICE_PAYLOAD_INVALID")
    seen: set[str] = set()
    for item in choices:
        if not isinstance(item, tuple) or len(item) != 2:
            raise AutocompleteBoundaryError("AUTOCOMPLETE_CHOICE_PAYLOAD_INVALID")
        name, value = item
        if (
            not isinstance(name, str) or not 1 <= len(name) <= DISCORD_CHOICE_TEXT_LIMIT
            or not isinstance(value, str) or not 1 <= len(value) <= DISCORD_CHOICE_TEXT_LIMIT
            or value in seen or value not in name
        ):
            raise AutocompleteBoundaryError("AUTOCOMPLETE_CHOICE_PAYLOAD_INVALID")
        seen.add(value)


class AutocompleteResponseBudget:
    def __init__(self, maximum: int = SESSION_AUTOCOMPLETE_RESPONSE_LIMIT):
        if maximum < 1 or maximum > SESSION_AUTOCOMPLETE_RESPONSE_LIMIT:
            raise ValueError("STAGE8_PASS4E_AUTOCOMPLETE_BUDGET_INVALID")
        self.maximum = maximum
        self.requests_received = 0
        self.responses_attempted = 0
        self.responses_completed = 0
        self.response_failures = 0
        self.last_failure_classification: str | None = None

    @property
    def response_count(self) -> int:
        """Compatibility alias: only successfully completed responses."""
        return self.responses_completed

    @property
    def snapshot(self) -> AutocompleteBudgetSnapshot:
        return AutocompleteBudgetSnapshot(
            self.requests_received, self.responses_attempted,
            self.responses_completed, self.response_failures,
            self.maximum, self.last_failure_classification,
        )

    def receive_request(self) -> int:
        self.requests_received += 1
        return self.requests_received

    def begin_response(self) -> None:
        if self.responses_completed >= self.maximum:
            raise AutocompleteBoundaryError("AUTOCOMPLETE_BUDGET_EXCEEDED")
        self.responses_attempted += 1

    def complete_response(self) -> None:
        if self.responses_completed >= self.responses_attempted:
            raise AutocompleteBoundaryError("AUTOCOMPLETE_RESPONSE_EXCEPTION")
        self.responses_completed += 1

    def fail_response(self, classification: str) -> None:
        self.response_failures += 1
        self.last_failure_classification = str(classification)

    def consume(self) -> None:
        """Compatibility helper modeling one complete successful callback."""
        self.receive_request()
        try:
            self.begin_response()
            self.complete_response()
        except AutocompleteBoundaryError as exc:
            self.fail_response(exc.classification)
            if exc.classification == "AUTOCOMPLETE_BUDGET_EXCEEDED":
                raise RuntimeError("STAGE8_PASS4E_AUTOCOMPLETE_BUDGET_EXHAUSTED") from None
            raise


__all__ = [
    "AUTOCOMPLETE_RESPONSE_CONTRACT", "BOUNDED_AUTOCOMPLETE_CONTRACT",
    "DISCORD_CHOICE_LIMIT", "DISCORD_CHOICE_TEXT_LIMIT", "SESSION_AUTOCOMPLETE_RESPONSE_LIMIT",
    "AutocompleteBoundaryError", "AutocompleteBudgetSnapshot", "AutocompleteDecision",
    "AutocompleteResponseBudget", "AutocompleteSource", "evaluate_autocomplete",
    "query_length_classification", "validate_choice_payload",
]
