"""Offline Stage 3 Pass 6 closure reassessment CLI."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .closure_assessment import assess_stage3_closure, verification_backlog_from_assessment


FAILURE_EXIT_CODE = 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Reassess existing Guild Doctor Stage 3 Pass 6 evidence without contacting Discord"
    )
    parser.add_argument(
        "--evidence-dir",
        type=Path,
        default=Path("stage3-pass6-evidence"),
        help="Existing Pass 6 evidence directory",
    )
    return parser


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    evidence_dir = args.evidence_dir
    try:
        authority_report = _read_json(evidence_dir / "authority_verification_report.json")
        source_backlog = _read_json(evidence_dir / "verification_backlog.json")
        action_results = _read_json(evidence_dir / "action_results.json")
        scenario_manifest = _read_json(evidence_dir / "scenario_manifest_redacted.json")
        live_snapshot = _read_json(evidence_dir / "authority_live_snapshot.json")
        repeated_snapshot = _read_json(evidence_dir / "repeated_authority_live_snapshot.json")
        transport_audit = _read_json(evidence_dir / "transport_audit.json")
        scenarios = scenario_manifest.get("scenarios", []) if isinstance(scenario_manifest, dict) else []
        assessment = assess_stage3_closure(
            authority_report=authority_report,
            verification_backlog=source_backlog,
            action_results=action_results,
            scenarios=scenarios,
            live_snapshot=live_snapshot,
            repeated_snapshot=repeated_snapshot,
            transport_audit=transport_audit,
            pass7_started=False,
        )
        _write_json(evidence_dir / "stage3_closure_assessment.json", assessment)
        _write_json(evidence_dir / "verification_backlog.json", verification_backlog_from_assessment(assessment))
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        print(f"guild-doctor-stage3-closure-reassess: failed: {str(exc).strip() or exc.__class__.__name__}", file=sys.stderr)
        return FAILURE_EXIT_CODE

    print("Guild Doctor Stage 3 Pass 6 offline closure reassessment")
    print(f"evidence_directory: {evidence_dir}")
    print(f"decision: {assessment['decision']}")
    print(f"status: {assessment['status']}")
    print(f"concrete_blockers: {len(assessment['concrete_blockers'])}")
    print("network: NOT_CONTACTED")
    print("discord_writes: 0")
    return 0 if assessment["status"] == "PASS" else FAILURE_EXIT_CODE


if __name__ == "__main__":
    raise SystemExit(main())
