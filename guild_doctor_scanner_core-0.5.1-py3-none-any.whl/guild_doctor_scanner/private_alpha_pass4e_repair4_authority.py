"""Persistent, fail-closed, single-use authority records for Repair 4B.

This module is local-only.  It never reads a token, imports Discord, opens a
network connection, or constructs a Discord client.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from datetime import UTC, datetime
import json
import os
from pathlib import Path
import re
import uuid
from typing import Any, Callable, Mapping
from .private_alpha_pass4e_exact_route_plan import exact_route_plan_fingerprint
from .private_alpha_pass4e_session_artifacts import (
    SessionArtifactPaths,
    SessionArtifactPathError,
    canonical_issuance_binding,
)


REPAIR4_AUTHORITY_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-REPAIR4-LIVE-AUTHORITY-0.2"
REPAIR4_AUTHORITY_BASENAME = "stage8_pass4e_repair4_authority.json"
REPAIR4_AUTHORITY_STATES = frozenset({"ISSUED", "CONSUMED", "INVALIDATED"})
APPROVED_REPAIR4_ROUTES = (
    "compare-role-permission",
    "compare-role-capability",
    "compare-role-action",
    "server-report",
)
_FINGERPRINT = re.compile(r"^[0-9a-f]{64}$")
_ISSUANCE_IDENTIFIER = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
_REASON = re.compile(r"^[A-Z0-9_]{3,128}$")


class Repair4AuthorityError(RuntimeError):
    """Stable, privacy-safe authority lifecycle error."""


@dataclass(frozen=True, slots=True)
class HistoricalAuthorityProjection:
    """Read-only historical evidence view; never accepted by lifecycle APIs."""
    authority_contract: str
    classification: str
    lifecycle_state: str
    issuance_timestamp: str | None
    consumption_timestamp: str | None
    invalidation_reason: str | None
    source_tree_fingerprint: str | None
    snapshot_fingerprint: str | None
    historical_read_supported: bool = True
    live_execution_supported: bool = False
    mutation_supported: bool = False
    runtime_conversion_supported: bool = False


@dataclass(frozen=True, slots=True)
class AuthorityBinding:
    source_tree_fingerprint: str
    snapshot_fingerprint: str
    preflight_fingerprint: str
    active_configuration_fingerprint: str
    live_configuration_fingerprint: str
    approved_routes: tuple[str, ...] = APPROVED_REPAIR4_ROUTES
    exact_route_plan_fingerprint: str = exact_route_plan_fingerprint()
    maximum_accepted_commands: int = 4
    maximum_autocomplete_responses: int = 12
    maximum_gateway_sessions: int = 1
    maximum_reconnects: int = 0
    maximum_duration_seconds: int = 600
    response_boundary: str = "EPHEMERAL_ONLY"
    command_registration_prohibited: bool = True
    guild_server_object_mutation_prohibited: bool = True
    interactions_endpoint_absence_confirmed: bool = True
    session_artifact_binding_fingerprint: str = "0" * 64
    issuance_reference: str | None = None
    session_namespace: str | None = None
    namespace_format_version: str | None = None
    authority_basename: str | None = None
    receipt_basename: str | None = None


@dataclass(frozen=True, slots=True, kw_only=True)
class AuthorityRecord:
    authority_contract: str
    issuance_identifier: str
    source_tree_fingerprint: str
    snapshot_fingerprint: str
    preflight_fingerprint: str
    active_configuration_fingerprint: str
    live_configuration_fingerprint: str
    approved_routes: tuple[str, ...]
    exact_route_plan_fingerprint: str
    maximum_accepted_commands: int
    maximum_autocomplete_responses: int
    maximum_gateway_sessions: int
    maximum_reconnects: int
    maximum_duration_seconds: int
    response_boundary: str
    command_registration_prohibited: bool
    guild_server_object_mutation_prohibited: bool
    interactions_endpoint_absence_confirmed: bool
    issuance_state: str
    issuance_timestamp: str
    consumption_state: str
    consumption_timestamp: str | None
    invalidation_reason: str | None
    session_artifact_binding_fingerprint: str
    issuance_reference: str | None
    session_namespace: str | None
    namespace_format_version: str | None
    authority_basename: str | None
    receipt_basename: str | None

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["approved_routes"] = list(self.approved_routes)
        return value


def _utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def read_authority_for_evidence(path: Path) -> HistoricalAuthorityProjection | AuthorityRecord:
    """Decode only known historical 0.1 shapes without locks or filesystem writes."""
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=_reject_duplicate_keys)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError):
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_MALFORMED") from None
    if not isinstance(value, Mapping):
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_MALFORMED")
    if value.get("authority_contract") == REPAIR4_AUTHORITY_CONTRACT:
        return _record_from_mapping(value)
    historical = "GUILD-DOCTOR-STAGE8-PASS4E-REPAIR4-LIVE-AUTHORITY-0.1"
    common = {"authority_contract","issuance_identifier","issuance_state","issuance_timestamp","consumption_state","consumption_timestamp","invalidation_reason","source_tree_fingerprint","snapshot_fingerprint"}
    if value.get("authority_contract") != historical or not common.issubset(value) or value.get("issuance_state") not in REPAIR4_AUTHORITY_STATES:
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_CONTRACT_UNSUPPORTED")
    return HistoricalAuthorityProjection(historical, "HISTORICAL_REPAIR4_0_1", str(value["issuance_state"]),
        value.get("issuance_timestamp"), value.get("consumption_timestamp"), value.get("invalidation_reason"),
        value.get("source_tree_fingerprint"), value.get("snapshot_fingerprint"))


def _validate_binding(binding: AuthorityBinding) -> None:
    if not isinstance(binding, AuthorityBinding):
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_BINDING_INVALID")
    if not all(isinstance(value, str) and _FINGERPRINT.fullmatch(value) for value in (
        binding.source_tree_fingerprint, binding.snapshot_fingerprint, binding.preflight_fingerprint,
        binding.active_configuration_fingerprint, binding.live_configuration_fingerprint,
    )):
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_FINGERPRINT_INVALID")
    if not isinstance(binding.approved_routes, tuple) or binding.approved_routes != APPROVED_REPAIR4_ROUTES:
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_ROUTE_SET_INVALID")
    if binding.exact_route_plan_fingerprint != exact_route_plan_fingerprint():
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_ROUTE_PLAN_CONTRACT_MISMATCH")
    if not isinstance(binding.session_artifact_binding_fingerprint, str) or not _FINGERPRINT.fullmatch(binding.session_artifact_binding_fingerprint):
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_SESSION_BINDING_INVALID")
    reference_fields = (
        binding.issuance_reference,
        binding.session_namespace,
        binding.namespace_format_version,
        binding.authority_basename,
        binding.receipt_basename,
    )
    if any(value is not None for value in reference_fields):
        if not all(value is not None for value in reference_fields):
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_REFERENCE_INVALID")
        try:
            expected = canonical_issuance_binding(binding.issuance_reference)
        except SessionArtifactPathError:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_REFERENCE_INVALID") from None
        if (
            binding.session_namespace,
            binding.namespace_format_version,
            binding.authority_basename,
            binding.receipt_basename,
        ) != (
            expected["session_namespace"],
            expected["namespace_format_version"],
            expected["authority_basename"],
            expected["receipt_basename"],
        ):
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_REFERENCE_BINDING_MISMATCH")
        if binding.session_artifact_binding_fingerprint != expected["binding_fingerprint"]:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_SESSION_BINDING_MISMATCH")
    if (
        any(type(value) is not int for value in (
            binding.maximum_accepted_commands, binding.maximum_autocomplete_responses,
            binding.maximum_gateway_sessions, binding.maximum_reconnects, binding.maximum_duration_seconds,
        ))
        or not isinstance(binding.response_boundary, str)
        or type(binding.command_registration_prohibited) is not bool
        or type(binding.guild_server_object_mutation_prohibited) is not bool
        or type(binding.interactions_endpoint_absence_confirmed) is not bool
        or binding.maximum_accepted_commands != 4
        or binding.maximum_autocomplete_responses != 12
        or binding.maximum_gateway_sessions != 1
        or binding.maximum_reconnects != 0
        or binding.maximum_duration_seconds != 600
        or binding.response_boundary != "EPHEMERAL_ONLY"
        or not binding.command_registration_prohibited
        or not binding.guild_server_object_mutation_prohibited
        or not binding.interactions_endpoint_absence_confirmed
    ):
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_BUDGET_INVALID")


def _record_from_mapping(value: Mapping[str, Any]) -> AuthorityRecord:
    required = tuple(AuthorityRecord.__dataclass_fields__)
    if not isinstance(value, Mapping) or set(value) != set(required):
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_MALFORMED")
    try:
        record = AuthorityRecord(
            authority_contract=value["authority_contract"],
            issuance_identifier=value["issuance_identifier"],
            source_tree_fingerprint=value["source_tree_fingerprint"],
            snapshot_fingerprint=value["snapshot_fingerprint"],
            preflight_fingerprint=value["preflight_fingerprint"],
            active_configuration_fingerprint=value["active_configuration_fingerprint"],
            live_configuration_fingerprint=value["live_configuration_fingerprint"],
            approved_routes=tuple(value["approved_routes"]),
            exact_route_plan_fingerprint=value["exact_route_plan_fingerprint"],
            maximum_accepted_commands=value["maximum_accepted_commands"],
            maximum_autocomplete_responses=value["maximum_autocomplete_responses"],
            maximum_gateway_sessions=value["maximum_gateway_sessions"],
            maximum_reconnects=value["maximum_reconnects"],
            maximum_duration_seconds=value["maximum_duration_seconds"],
            response_boundary=value["response_boundary"],
            command_registration_prohibited=value["command_registration_prohibited"],
            guild_server_object_mutation_prohibited=value["guild_server_object_mutation_prohibited"],
            interactions_endpoint_absence_confirmed=value["interactions_endpoint_absence_confirmed"],
            issuance_state=value["issuance_state"],
            issuance_timestamp=value["issuance_timestamp"],
            consumption_state=value["consumption_state"],
            consumption_timestamp=value["consumption_timestamp"],
            invalidation_reason=value["invalidation_reason"],
            session_artifact_binding_fingerprint=value["session_artifact_binding_fingerprint"],
            issuance_reference=value["issuance_reference"], session_namespace=value["session_namespace"],
            namespace_format_version=value["namespace_format_version"], authority_basename=value["authority_basename"], receipt_basename=value["receipt_basename"],
        )
    except (KeyError, TypeError, ValueError):
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_MALFORMED") from None
    _validate_record(record)
    return record


def _validate_record(record: AuthorityRecord) -> None:
    if record.authority_contract != REPAIR4_AUTHORITY_CONTRACT:
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_CONTRACT_UNSUPPORTED")
    if not _ISSUANCE_IDENTIFIER.fullmatch(record.issuance_identifier):
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_MALFORMED")
    _validate_binding(AuthorityBinding(
        source_tree_fingerprint=record.source_tree_fingerprint, snapshot_fingerprint=record.snapshot_fingerprint,
        preflight_fingerprint=record.preflight_fingerprint, active_configuration_fingerprint=record.active_configuration_fingerprint,
        live_configuration_fingerprint=record.live_configuration_fingerprint, approved_routes=record.approved_routes,
        exact_route_plan_fingerprint=record.exact_route_plan_fingerprint,
        maximum_accepted_commands=record.maximum_accepted_commands, maximum_autocomplete_responses=record.maximum_autocomplete_responses,
        maximum_gateway_sessions=record.maximum_gateway_sessions, maximum_reconnects=record.maximum_reconnects,
        maximum_duration_seconds=record.maximum_duration_seconds, response_boundary=record.response_boundary,
        command_registration_prohibited=record.command_registration_prohibited,
        guild_server_object_mutation_prohibited=record.guild_server_object_mutation_prohibited,
        interactions_endpoint_absence_confirmed=record.interactions_endpoint_absence_confirmed,
        session_artifact_binding_fingerprint=record.session_artifact_binding_fingerprint,
        issuance_reference=record.issuance_reference, session_namespace=record.session_namespace,
        namespace_format_version=record.namespace_format_version, authority_basename=record.authority_basename, receipt_basename=record.receipt_basename,
    ))
    if record.issuance_state not in REPAIR4_AUTHORITY_STATES or not isinstance(record.issuance_timestamp, str) or not record.issuance_timestamp:
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_MALFORMED")
    if record.issuance_state == "ISSUED":
        if record.consumption_state != "NOT_CONSUMED" or record.consumption_timestamp is not None or record.invalidation_reason is not None:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_CONTRADICTORY")
    elif record.issuance_state == "CONSUMED":
        if record.consumption_state != "CONSUMED" or not isinstance(record.consumption_timestamp, str) or not record.consumption_timestamp or record.invalidation_reason is not None:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_CONTRADICTORY")
    else:
        if record.consumption_state != "NOT_CONSUMED" or record.consumption_timestamp is not None or not isinstance(record.invalidation_reason, str) or not _REASON.fullmatch(record.invalidation_reason):
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_CONTRADICTORY")


class LocalAuthorityStore:
    """Atomic local record store using exclusive lock-file acquisition."""

    def __init__(self, path: Path, *, session_artifacts: SessionArtifactPaths | None = None):
        self.path = Path(path)
        self.session_artifacts = session_artifacts
        if session_artifacts is None:
            if self.path.name != REPAIR4_AUTHORITY_BASENAME:
                raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_PATH_INVALID")
        else:
            try:
                validated = session_artifacts.validated()
            except SessionArtifactPathError as exc:
                raise Repair4AuthorityError(str(exc)) from None
            if self.path.resolve(strict=False) != validated.authority_path:
                raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_SESSION_PATH_MISMATCH")
            self.path = validated.authority_path
        self._lock_path = self.path.with_suffix(self.path.suffix + ".lock")

    def _acquire_lock(self) -> None:
        if not self.path.parent.is_dir():
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_PERSISTENCE_FAILED")
        try:
            descriptor = os.open(self._lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(descriptor, "w", encoding="ascii") as stream:
                stream.write("LOCKED\n")
                stream.flush()
                os.fsync(stream.fileno())
        except FileExistsError:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_BUSY") from None
        except OSError:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_PERSISTENCE_FAILED") from None

    def _release_lock(self) -> None:
        try:
            self._lock_path.unlink(missing_ok=False)
        except OSError:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_PERSISTENCE_FAILED") from None

    def _locked(self, operation: Callable[[], AuthorityRecord]) -> AuthorityRecord:
        self._acquire_lock()
        try:
            return operation()
        finally:
            self._release_lock()

    def _load(self) -> AuthorityRecord:
        try:
            raw = self.path.read_text(encoding="utf-8")
        except FileNotFoundError:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_MISSING") from None
        except OSError:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_PERSISTENCE_FAILED") from None
        if len(raw.encode("utf-8")) > 65_536:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_MALFORMED")
        try:
            value = json.loads(raw, object_pairs_hook=_reject_duplicate_keys)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_MALFORMED") from None
        return _record_from_mapping(value)

    def read_for_evidence(self) -> HistoricalAuthorityProjection | AuthorityRecord:
        return read_authority_for_evidence(self.path)

    def _atomic_write(self, record: AuthorityRecord) -> None:
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        payload = json.dumps(record.as_dict(), sort_keys=True, separators=(",", ":")) + "\n"
        try:
            with temporary.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
        except (OSError, TypeError, ValueError):
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_PERSISTENCE_FAILED") from None

    def issue(self, binding: AuthorityBinding, *, identifier_factory: Callable[[], str] | None = None, clock: Callable[[], str] = _utc_now) -> AuthorityRecord:
        _validate_binding(binding)
        if self.session_artifacts is not None and binding.session_artifact_binding_fingerprint != self.session_artifacts.binding_fingerprint:
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_SESSION_BINDING_MISMATCH")
        if self.session_artifacts is not None and self.session_artifacts.issuance_identifier is not None:
            expected = self.session_artifacts
            if (binding.issuance_reference, binding.session_namespace, binding.authority_basename, binding.receipt_basename) != (expected.issuance_identifier, expected.session_namespace, expected.authority_path.name, expected.receipt_path.name):
                raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_REFERENCE_BINDING_MISMATCH")

        def operation() -> AuthorityRecord:
            if self.path.exists():
                raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_ALREADY_EXISTS")
            identifier = (identifier_factory or (lambda: str(uuid.uuid4())))()
            if not isinstance(identifier, str) or not _ISSUANCE_IDENTIFIER.fullmatch(identifier):
                raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_IDENTIFIER_INVALID")
            record = AuthorityRecord(
                authority_contract=REPAIR4_AUTHORITY_CONTRACT, issuance_identifier=identifier,
                source_tree_fingerprint=binding.source_tree_fingerprint, snapshot_fingerprint=binding.snapshot_fingerprint,
                preflight_fingerprint=binding.preflight_fingerprint, active_configuration_fingerprint=binding.active_configuration_fingerprint,
                live_configuration_fingerprint=binding.live_configuration_fingerprint, approved_routes=binding.approved_routes,
                exact_route_plan_fingerprint=binding.exact_route_plan_fingerprint, maximum_accepted_commands=binding.maximum_accepted_commands,
                maximum_autocomplete_responses=binding.maximum_autocomplete_responses, maximum_gateway_sessions=binding.maximum_gateway_sessions,
                maximum_reconnects=binding.maximum_reconnects, maximum_duration_seconds=binding.maximum_duration_seconds,
                response_boundary=binding.response_boundary, command_registration_prohibited=binding.command_registration_prohibited,
                guild_server_object_mutation_prohibited=binding.guild_server_object_mutation_prohibited,
                interactions_endpoint_absence_confirmed=binding.interactions_endpoint_absence_confirmed,
                issuance_state="ISSUED", issuance_timestamp=clock(), consumption_state="NOT_CONSUMED",
                consumption_timestamp=None, invalidation_reason=None, session_artifact_binding_fingerprint=binding.session_artifact_binding_fingerprint,
                issuance_reference=binding.issuance_reference, session_namespace=binding.session_namespace,
                namespace_format_version=binding.namespace_format_version, authority_basename=binding.authority_basename,
                receipt_basename=binding.receipt_basename,
            )
            _validate_record(record)
            self._atomic_write(record)
            return record

        return self._locked(operation)

    def validate(self, binding: AuthorityBinding) -> AuthorityRecord:
        _validate_binding(binding)

        def operation() -> AuthorityRecord:
            record = self._load()
            self._validate_binding_match(record, binding)
            return record

        return self._locked(operation)

    def consume(self, binding: AuthorityBinding, *, clock: Callable[[], str] = _utc_now) -> AuthorityRecord:
        _validate_binding(binding)

        def operation() -> AuthorityRecord:
            record = self._load()
            self._validate_binding_match(record, binding)
            if record.issuance_state == "CONSUMED":
                raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_ALREADY_CONSUMED")
            if record.issuance_state == "INVALIDATED":
                raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_INVALIDATED")
            updated = replace(
                record, issuance_state="CONSUMED", consumption_state="CONSUMED",
                consumption_timestamp=clock(),
            )
            _validate_record(updated)
            self._atomic_write(updated)
            return updated

        return self._locked(operation)

    def invalidate(self, binding: AuthorityBinding, reason: str) -> AuthorityRecord:
        _validate_binding(binding)
        if not isinstance(reason, str) or not _REASON.fullmatch(reason):
            raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_INVALIDATION_REASON_INVALID")

        def operation() -> AuthorityRecord:
            record = self._load()
            self._validate_binding_match(record, binding)
            if record.issuance_state != "ISSUED":
                raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_NOT_INVALIDATABLE")
            updated = replace(record, issuance_state="INVALIDATED", invalidation_reason=reason)
            _validate_record(updated)
            self._atomic_write(updated)
            return updated

        return self._locked(operation)

    @staticmethod
    def _validate_binding_match(record: AuthorityRecord, binding: AuthorityBinding) -> None:
        checks = (
            (record.source_tree_fingerprint == binding.source_tree_fingerprint, "STAGE8_PASS4E_REPAIR4_AUTHORITY_SOURCE_FINGERPRINT_MISMATCH"),
            (record.snapshot_fingerprint == binding.snapshot_fingerprint, "STAGE8_PASS4E_REPAIR4_AUTHORITY_SNAPSHOT_FINGERPRINT_MISMATCH"),
            (record.preflight_fingerprint == binding.preflight_fingerprint, "STAGE8_PASS4E_REPAIR4_AUTHORITY_PREFLIGHT_FINGERPRINT_MISMATCH"),
            (record.active_configuration_fingerprint == binding.active_configuration_fingerprint, "STAGE8_PASS4E_REPAIR4_AUTHORITY_ACTIVE_CONFIGURATION_MISMATCH"),
            (record.live_configuration_fingerprint == binding.live_configuration_fingerprint, "STAGE8_PASS4E_REPAIR4_AUTHORITY_LIVE_CONFIGURATION_MISMATCH"),
            (record.approved_routes == binding.approved_routes, "STAGE8_PASS4E_REPAIR4_AUTHORITY_ROUTE_SET_MISMATCH"),
            (record.exact_route_plan_fingerprint == binding.exact_route_plan_fingerprint, "STAGE8_PASS4E_REPAIR4_AUTHORITY_ROUTE_PLAN_CONTRACT_MISMATCH"),
            (record.session_artifact_binding_fingerprint == binding.session_artifact_binding_fingerprint, "STAGE8_PASS4E_REPAIR4_AUTHORITY_SESSION_BINDING_MISMATCH"),
        )
        for passed, code in checks:
            if not passed:
                raise Repair4AuthorityError(code)


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("duplicate key")
        value[key] = item
    return value


def as_frozen_runtime_authority(record: AuthorityRecord):
    """Convert only a durable, consumed record to the frozen runtime authority."""
    if not isinstance(record, AuthorityRecord) or record.issuance_state != "CONSUMED":
        raise Repair4AuthorityError("STAGE8_PASS4E_REPAIR4_AUTHORITY_NOT_CONSUMED")
    from .private_alpha_live_interaction_runtime import (
        PASS4E_AUTHORITY_CONTRACT, LiveExecutionAuthority,
    )
    return LiveExecutionAuthority(
        PASS4E_AUTHORITY_CONTRACT, "PASS4E_AUTHORIZED", record.preflight_fingerprint,
        record.source_tree_fingerprint, record.active_configuration_fingerprint,
        record.live_configuration_fingerprint, record.snapshot_fingerprint,
        record.maximum_gateway_sessions, record.maximum_accepted_commands,
        record.maximum_duration_seconds, record.interactions_endpoint_absence_confirmed,
        record.session_artifact_binding_fingerprint,
    )


__all__ = [
    "APPROVED_REPAIR4_ROUTES", "AuthorityBinding", "AuthorityRecord", "LocalAuthorityStore",
    "REPAIR4_AUTHORITY_BASENAME", "REPAIR4_AUTHORITY_CONTRACT", "REPAIR4_AUTHORITY_STATES",
    "Repair4AuthorityError", "as_frozen_runtime_authority",
    "HistoricalAuthorityProjection", "read_authority_for_evidence",
]
