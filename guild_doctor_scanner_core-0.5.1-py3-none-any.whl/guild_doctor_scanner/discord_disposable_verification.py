"""Read-only guild-scoped command verification; no synchronization is called."""
from __future__ import annotations
import asyncio,inspect
from .discord_secure_token import HiddenTokenProvider,TokenInputError
from .discord_command_schema import normalize_live_commands,compare_live_schema,expected_live_schema

DISPOSABLE_VERIFICATION_CONTRACT="GUILD-DOCTOR-DISPOSABLE-VERIFICATION-0.1"
NOT_EXECUTED_WITH_REASON="NOT_EXECUTED_WITH_REASON"

def offline_matrix()->dict:return {"command_count":"NOT_EXECUTED_WITH_REASON","owner_authorization":"NOT_EXECUTED_WITH_REASON","non_owner_denial":"NOT_EXECUTED_WITH_REASON","ephemeral_visibility":"NOT_EXECUTED_WITH_REASON","network_requests":0,"raw_payload_retained":False}

def _name(item):return item.get('name') if isinstance(item,dict) else getattr(item,'name',None)

def _classify(names:set[str],expected_names:set[str]):
 present=names & expected_names
 if not present:return 'COMMANDS_ABSENT'
 if present==expected_names:return 'COMMANDS_PRESENT_EXACT'
 if present<expected_names and not (names-expected_names - {'unrelated'}):return 'COMMANDS_PRESENT_PARTIAL'
 return 'COMMANDS_PRESENT_MISMATCH'

def verify_commands(*,transport,guild_id:str,expected_names:set[str])->dict:
 commands=transport.fetch_guild_commands(guild_id);return verify_command_records(commands,expected_names=expected_names)

def verify_command_records(commands,*,expected_names:set[str])->dict:
 normalized=normalize_live_commands(commands);comparison=compare_live_schema(normalized,expected=expected_live_schema());state=comparison['state']
 root=normalized.get('roots',[{}])[0] if normalized.get('roots') else {}
 names={item.get('name') for item in root.get('subcommands',[])}
 if expected_names!={item['name'] for item in expected_live_schema()['subcommands']}:state=_classify(names,expected_names)
 return {'status':'PASS' if state=='COMMANDS_PRESENT_EXACT' else 'FAIL','command_state':state,'top_level_command_count':normalized['top_level_command_count'],'guild_doctor_root_count':normalized['guild_doctor_root_count'],'guild_doctor_subcommand_count':normalized['guild_doctor_subcommand_count'],'unrelated_top_level_command_count':normalized['unrelated_top_level_command_count'],'command_count':normalized['guild_doctor_subcommand_count'],'command_count_semantics':'guild_doctor_subcommand_count','names':sorted(names & expected_names),'unrelated_preserved':normalized['unrelated_top_level_command_count']>0,'write_count':0,'synchronization_called':False,'schema_reason':comparison.get('reason')}

async def _invoke(transport,async_name,sync_name,*args):
 method=getattr(transport,async_name,None);result=method(*args) if method is not None else getattr(transport,sync_name)(*args)
 return await result if inspect.isawaitable(result) else result

async def execute_verify_async(*,transport,token_provider=None,guild_id:str,expected_names:set[str],timeout_seconds:float=30)->dict:
 token_provider=token_provider or HiddenTokenProvider();token=None;request_count=0;result=None;operation='token_provider';primary=None
 try:
  operation='open_client';await asyncio.wait_for(_invoke(transport,'async_open_client','open_client'),timeout_seconds)
  token=token_provider.get()
  operation='authenticate_bot';request_count+=1;await asyncio.wait_for(_invoke(transport,'async_authenticate_bot','authenticate_bot',token),timeout_seconds)
  operation='fetch_guild_commands';request_count+=1;commands=await asyncio.wait_for(_invoke(transport,'async_fetch_guild_commands','fetch_guild_commands',guild_id),timeout_seconds);result=verify_command_records(commands,expected_names=expected_names)
  result={**result,'request_count':request_count,'token_redacted':True,'client_cleanup':'CLEANUP_PENDING'}
 except Exception as exc:
  primary=exc;status=getattr(exc,'status',None) if isinstance(getattr(exc,'status',None),int) else None
  code='PASS5_AUTHENTICATION_FAILED' if type(exc).__name__=='LoginFailure' or status==401 else ('PASS5_CLIENT_START_FAILED' if operation=='open_client' else 'PASS5_VERIFICATION_FAILED')
  result={'status':'FAIL','stable_error':code,'operation':operation,'exception_category':type(exc).__name__,'http_status':status,'request_count':request_count,'write_count':0,'synchronization_called':False,'token_prompted':bool(token),'token_redacted':True,'client_cleanup':'CLEANUP_PENDING'}
 finally:
  try:await _invoke(transport,'async_close_client','close_client')
  except Exception as close_exc:
   if primary is None:result={'status':'FAIL','stable_error':'PASS5_CLIENT_CLOSE_FAILED','operation':'close_client','exception_category':type(close_exc).__name__,'request_count':request_count,'write_count':0,'token_redacted':True,'client_cleanup':'CLOSE_FAILED'}
   else:result['client_cleanup']='CLOSE_FAILED'
  else:
   if result is not None:result['client_cleanup']='CLOSED'
  token=None
 return result

def execute_verify(*,transport,token_provider=None,guild_id:str,expected_names:set[str])->dict:
 return asyncio.run(execute_verify_async(transport=transport,token_provider=token_provider,guild_id=guild_id,expected_names=expected_names))
