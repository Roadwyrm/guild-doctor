"""Pinned local deployment dependency declaration."""
RUNTIME_DEPENDENCY_CONTRACT="GUILD-DOCTOR-DISCORD-DEPENDENCIES-0.1"
DEPENDENCIES={"python":"3.14.5","discord.py":"2.7.1","package":"guild-doctor-scanner-core 0.5.1","powershell":"5.1","platform":"Windows","clean_wheel_install":"REQUIRED"}
