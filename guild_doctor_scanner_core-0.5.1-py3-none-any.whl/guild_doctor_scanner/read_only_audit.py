"""Static safety audit for the Stage 2 live scanner paths."""

from __future__ import annotations

import ast
from pathlib import Path

ALLOWED_TRANSPORT_METHODS = {
    "get_guild",
    "get_roles",
    "get_all_guild_channels",
    "get_active_threads",
    "get_member",
    "get_members",
}

BANNED_HTTP_VERBS = {"POST", "PUT", "PATCH", "DELETE"}
BANNED_DISCORD_METHOD_NAMES = {
    "create_channel",
    "create_role",
    "edit",
    "delete",
    "kick",
    "ban",
    "timeout",
    "add_roles",
    "remove_roles",
    "send",
    "send_message",
    "modify_guild",
    "bulk_channel_update",
    "move_role_position",
}


def audit_live_scanner_source(package_root: Path) -> list[str]:
    """Return violations found in modules reachable from live scanner CLIs."""

    violations: list[str] = []
    targets = [
        package_root / "acquisition.py",
        package_root / "member_acquisition.py",
        package_root / "discordpy_adapter.py",
        package_root / "live_cli.py",
        package_root / "member_cli.py",
    ]

    for path in targets:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                if node.value.upper() in BANNED_HTTP_VERBS:
                    violations.append(f"{path.name}:{node.lineno}: banned HTTP verb literal {node.value!r}")
            if isinstance(node, ast.Attribute):
                attr = node.attr.lower()
                if attr in BANNED_DISCORD_METHOD_NAMES:
                    violations.append(f"{path.name}:{node.lineno}: banned mutation-like attribute {node.attr!r}")

    return violations

BANNED_GUILD_MUTATION_ATTRIBUTES = {
    "create_text_channel",
    "create_voice_channel",
    "create_stage_channel",
    "create_forum",
    "create_category",
    "create_role",
    "edit_role_positions",
    "edit_channel_positions",
    "add_roles",
    "remove_roles",
    "kick",
    "ban",
    "unban",
    "timeout",
    "move",
    "set_permissions",
    "delete",
    "edit",
}


def audit_command_runtime_source(package_root: Path) -> list[str]:
    """Audit Pass 4 modules for guild-configuration mutation calls.

    Interaction responses and optional application-command synchronization are
    intentionally allowed; the prohibition is against mutating guild objects.
    """

    violations: list[str] = []
    targets = [
        package_root / "commands.py",
        package_root / "runtime.py",
        package_root / "bot_cli.py",
        package_root / "persistence.py",
    ]
    for path in targets:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Attribute) and node.attr.lower() in BANNED_GUILD_MUTATION_ATTRIBUTES:
                violations.append(
                    f"{path.name}:{node.lineno}: banned guild mutation attribute {node.attr!r}"
                )
    return violations


def audit_integration_runtime_source(package_root: Path) -> list[str]:
    """Audit Pass 5 integration modules for Discord/guild mutation calls."""

    violations: list[str] = []
    targets = [
        package_root / "integration.py",
        package_root / "integration_cli.py",
        package_root / "comparison.py",
        package_root / "fixture_export.py",
        package_root / "authorization.py",
    ]
    for path in targets:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                if node.value.upper() in BANNED_HTTP_VERBS:
                    violations.append(f"{path.name}:{node.lineno}: banned HTTP verb literal {node.value!r}")
            if isinstance(node, ast.Attribute) and node.attr.lower() in (
                BANNED_DISCORD_METHOD_NAMES | BANNED_GUILD_MUTATION_ATTRIBUTES
            ):
                violations.append(
                    f"{path.name}:{node.lineno}: banned mutation-like attribute {node.attr!r}"
                )
    return violations


def audit_stage3_pass1_source(package_root: Path) -> list[str]:
    """Audit the Pass 1 engine for external or mutation-capable dependencies.

    Pass 1 is intentionally a pure calculation boundary.  The audit keeps
    this guarantee machine-checkable while leaving channel-overwrite
    resolution and all Discord access to later, explicitly scoped work.
    """

    violations: list[str] = []
    path = package_root / "permission_engine.py"
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    banned_import_fragments = {
        "aiohttp",
        "asyncio",
        "discord",
        "http",
        "os",
        "requests",
        "sqlite",
        "urllib",
    }
    allowed_local_imports = {".constants", ".fixture_export"}

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                module = alias.name.lower()
                if any(fragment in module for fragment in banned_import_fragments):
                    violations.append(
                        f"{path.name}:{node.lineno}: banned external import {alias.name!r}"
                    )
        elif isinstance(node, ast.ImportFrom):
            module = (node.module or "").lower()
            if node.level == 0 and any(
                fragment in module for fragment in banned_import_fragments
            ):
                violations.append(
                    f"{path.name}:{node.lineno}: banned external import {node.module!r}"
                )
            if node.level and f"{'.' * node.level}{node.module or ''}" not in allowed_local_imports:
                violations.append(
                    f"{path.name}:{node.lineno}: unexpected local import {node.module!r}"
                )
        elif isinstance(node, ast.Attribute):
            if node.attr.lower() in BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES:
                violations.append(
                    f"{path.name}:{node.lineno}: banned mutation-like attribute {node.attr!r}"
                )

    return violations


def audit_stage3_pass2_source(package_root: Path) -> list[str]:
    """Audit the Pass 2 engine for pure, read-only calculation boundaries."""

    violations: list[str] = []
    path = package_root / "permission_overwrite_engine.py"
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    banned_import_fragments = {
        "aiohttp",
        "asyncio",
        "commands",
        "discord",
        "dotenv",
        "http",
        "os",
        "persistence",
        "requests",
        "sqlite",
        "urllib",
    }
    allowed_local_imports = {
        ".constants",
        ".fixture_export",
        ".permission_engine",
    }
    banned_attributes = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "open",
        "write_text",
        "write_bytes",
    }

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                module = alias.name.lower()
                if any(fragment in module for fragment in banned_import_fragments):
                    violations.append(
                        f"{path.name}:{node.lineno}: banned external import {alias.name!r}"
                    )
        elif isinstance(node, ast.ImportFrom):
            module = (node.module or "").lower()
            if node.level == 0 and any(
                fragment in module for fragment in banned_import_fragments
            ):
                violations.append(
                    f"{path.name}:{node.lineno}: banned external import {node.module!r}"
                )
            if node.level and f"{'.' * node.level}{node.module or ''}" not in allowed_local_imports:
                violations.append(
                    f"{path.name}:{node.lineno}: unexpected local import {node.module!r}"
                )
        elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attributes:
            violations.append(
                f"{path.name}:{node.lineno}: banned mutation-like attribute {node.attr!r}"
            )

    return violations


def audit_stage3_pass3_source(package_root: Path) -> list[str]:
    """Audit the Pass 3 registry/engine for a pure, read-only boundary."""

    violations: list[str] = []
    targets = [
        package_root / "capability_registry.py",
        package_root / "capability_engine.py",
    ]
    banned_import_fragments = {
        "aiohttp",
        "asyncio",
        "commands",
        "discord",
        "dotenv",
        "http",
        "os",
        "persistence",
        "requests",
        "sqlite",
        "urllib",
    }
    allowed_local_imports = {
        ".capability_registry",
        ".constants",
        ".fixture_export",
        ".permission_engine",
        ".permission_overwrite_engine",
    }
    banned_attributes = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "open",
        "write_text",
        "write_bytes",
        "unlink",
        "remove",
    }

    for path in targets:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module = alias.name.lower()
                    if any(fragment in module for fragment in banned_import_fragments):
                        violations.append(
                            f"{path.name}:{node.lineno}: banned external import {alias.name!r}"
                        )
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(
                    fragment in module for fragment in banned_import_fragments
                ):
                    violations.append(
                        f"{path.name}:{node.lineno}: banned external import {node.module!r}"
                    )
                if node.level and f"{'.' * node.level}{node.module or ''}" not in allowed_local_imports:
                    violations.append(
                        f"{path.name}:{node.lineno}: unexpected local import {node.module!r}"
                    )
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attributes:
                violations.append(
                    f"{path.name}:{node.lineno}: banned mutation-like attribute {node.attr!r}"
                )
    return violations


def audit_stage3_pass4_source(package_root: Path) -> list[str]:
    """Audit the Pass 4 thread resolver and rule registry for pure scope."""

    violations: list[str] = []
    targets = [package_root / "thread_rules.py", package_root / "thread_engine.py"]
    banned_import_fragments = {
        "aiohttp", "asyncio", "commands", "discord", "dotenv", "http", "os",
        "persistence", "requests", "sqlite", "urllib",
    }
    allowed_local_imports = {
        ".capability_engine", ".constants", ".fixture_export", ".permission_engine",
        ".permission_overwrite_engine", ".thread_rules",
    }
    banned_attributes = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "open", "write_text", "write_bytes", "unlink", "remove", "mkdir", "rmdir",
    }

    for path in targets:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module = alias.name.lower()
                    if any(fragment in module for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned external import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned external import {node.module!r}")
                if node.level and f"{'.' * node.level}{node.module or ''}" not in allowed_local_imports:
                    violations.append(f"{path.name}:{node.lineno}: unexpected local import {node.module!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attributes:
                violations.append(f"{path.name}:{node.lineno}: banned mutation-like attribute {node.attr!r}")
    return violations


def audit_stage3_pass5_source(package_root: Path) -> list[str]:
    """Audit Pass 5 registries and evaluator for pure component analysis."""

    violations: list[str] = []
    targets = [
        package_root / "authority_registry.py",
        package_root / "object_preconditions.py",
        package_root / "mfa_rules.py",
        package_root / "authority_engine.py",
    ]
    banned_import_fragments = {
        "aiohttp", "asyncio", "commands", "discord", "dotenv", "http", "os",
        "persistence", "requests", "sqlite", "urllib",
    }
    allowed_local_imports = {
        ".authority_registry", ".capability_engine", ".capability_registry",
        ".constants", ".fixture_export", ".mfa_rules", ".object_preconditions",
        ".permission_engine", ".permission_overwrite_engine", ".thread_engine",
    }
    banned_attributes = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "open", "write_text", "write_bytes", "unlink", "remove", "mkdir", "rmdir",
        "assign", "reorder", "mute", "deafen", "move", "send", "create", "delete",
    }
    forbidden_contract_markers = {"PASS6", "STAGE3_PASS6", "final_action", "action_result"}

    for path in targets:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        upper_source = source.upper()
        for marker in forbidden_contract_markers:
            if marker.upper() in upper_source:
                violations.append(f"{path.name}: forbidden later-stage or generic conclusion marker {marker!r}")
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module = alias.name.lower()
                    if any(fragment in module for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned external import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned external import {node.module!r}")
                if node.level and f"{'.' * node.level}{node.module or ''}" not in allowed_local_imports:
                    violations.append(f"{path.name}:{node.lineno}: unexpected local import {node.module!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attributes:
                violations.append(f"{path.name}:{node.lineno}: banned mutation-like attribute {node.attr!r}")
    return violations


def audit_stage3_pass6_source(package_root: Path) -> list[str]:
    """Audit Pass 6 orchestration and verification support for read-only scope."""

    violations: list[str] = []
    targets = [
        package_root / "action_registry.py",
        package_root / "action_engine.py",
        package_root / "authority_verification.py",
    ]
    banned_import_fragments = {
        "aiohttp", "asyncio", "commands", "discord", "dotenv", "http", "os",
        "persistence", "requests", "sqlite", "urllib",
    }
    allowed_local_imports = {
        ".action_engine", ".action_registry", ".authority_registry", ".canonical",
        ".capability_engine", ".capability_registry", ".constants", ".fixture_export",
        ".mfa_rules", ".object_preconditions", ".permission_engine",
        ".permission_overwrite_engine", ".thread_engine", ".thread_rules",
    }
    banned_attributes = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "open", "write_text", "write_bytes", "unlink", "remove", "mkdir", "rmdir",
        "create", "delete", "edit", "send", "kick", "ban", "timeout", "move",
        "mute", "deafen", "assign", "reorder",
    }
    forbidden_labels = {
        "EXECUTED", "VERIFIED_SUCCESS", "ENDPOINT_CONFIRMED", "WILL_SUCCEED", "ACTION_PERFORMED",
        "PASS7", "STAGE3_PASS7",
    }

    for path in targets:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        upper_source = source.upper()
        for label in forbidden_labels:
            if label in upper_source:
                violations.append(f"{path.name}: forbidden execution or later-stage label {label!r}")
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module = alias.name.lower()
                    if any(fragment in module for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned external import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned external import {node.module!r}")
                if node.level and f"{'.' * node.level}{node.module or ''}" not in allowed_local_imports:
                    violations.append(f"{path.name}:{node.lineno}: unexpected local import {node.module!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attributes:
                violations.append(f"{path.name}:{node.lineno}: banned mutation-like attribute {node.attr!r}")
    return violations


def audit_stage3_pass6_live_source(package_root: Path) -> list[str]:
    """Audit the Pass 6 live boundary for GET-only and non-execution scope."""

    violations: list[str] = []
    targets = [
        package_root / "authority_live_verifier.py",
        package_root / "authority_verification_cli.py",
        package_root / "stage3_pass6_discovery.py",
    ]
    forbidden_labels = {"LIVE_EXECUTION_VERIFIED", "ENDPOINT_CONFIRMED", "ACTION_SUCCEEDED", "WRITE_VERIFIED", "PASS7", "STAGE3_PASS7"}
    forbidden_attrs = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "request", "raw_request", "create", "edit", "delete", "send", "post", "put", "patch",
    }
    for path in targets:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        upper_source = source.upper()
        for label in forbidden_labels:
            if label in upper_source:
                violations.append(f"{path.name}: forbidden execution or later-stage label {label!r}")
        for node in ast.walk(tree):
            if isinstance(node, ast.Attribute) and node.attr.lower() in forbidden_attrs:
                # client.login/close are lifecycle operations, not guild writes.
                if node.attr.lower() not in {"login", "close"}:
                    violations.append(f"{path.name}:{node.lineno}: banned mutation-like attribute {node.attr!r}")
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in {"requests", "urlopen"}:
                violations.append(f"{path.name}:{node.lineno}: direct network client call is not allowed")
    return violations


def audit_stage4_pass1_source(package_root: Path) -> list[str]:
    """Audit the explanation layer for pure, downstream-only scope."""

    violations: list[str] = []
    targets = [
        package_root / "explanation_schema.py",
        package_root / "explanation_registry.py",
        package_root / "explanation_engine.py",
    ]
    banned_import_fragments = {
        "discord",
        "aiohttp",
        "requests",
        "urllib",
        "http",
        "sqlite",
        "persistence",
        "commands",
        "bot",
        "openai",
        "anthropic",
        "google",
    }
    banned_calls = {
        "evaluate_guild_permissions",
        "evaluate_context_permissions",
        "evaluate_capability_expansion",
        "evaluate_thread_permissions",
        "evaluate_authority_analysis",
        "evaluate_action_orchestration",
        "evaluate_pass6_action",
        "evaluate_pass5_authority",
        "evaluate_pass1",
        "evaluate_pass2",
        "evaluate_pass3",
        "evaluate_pass4",
        "evaluate_pass5",
        "evaluate_pass6",
    }
    for path in targets:
        if not path.exists():
            violations.append(f"{path.name}: missing Stage 4 Pass 1 source file")
            continue
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module = alias.name.lower()
                    if any(fragment in module for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned import {node.module!r}")
            elif isinstance(node, ast.Call):
                called = node.func.id if isinstance(node.func, ast.Name) else node.func.attr if isinstance(node.func, ast.Attribute) else None
                if called in banned_calls:
                    violations.append(f"{path.name}:{node.lineno}: Stage 3 recalculation call {called!r}")
            elif isinstance(node, ast.Attribute):
                if node.attr.lower() in {"request", "raw_request", "post", "put", "patch", "delete", "send", "create", "edit"}:
                    violations.append(f"{path.name}:{node.lineno}: network or mutation-like attribute {node.attr!r}")
    return sorted(set(violations))


def _audit_text(value: object) -> str:
    as_dict = getattr(value, "as_dict", None)
    if callable(as_dict):
        value = as_dict()
    if isinstance(value, dict):
        return " ".join(_audit_text(item) for item in value.values())
    if isinstance(value, (list, tuple, set, frozenset)):
        return " ".join(_audit_text(item) for item in value)
    return str(value)


def audit_stage4_pass1_wording(value: object) -> list[str]:
    """Reject wording that changes Stage 3 meaning or offers remediation."""

    text = _audit_text(value).lower()
    forbidden = {
        "higher role won": "role-order precedence wording",
        "category applied first": "category-layer wording",
        "administrator bypasses hierarchy": "administrator hierarchy claim",
        "administrator bypass hierarchy": "administrator hierarchy claim",
        "action will work": "endpoint guarantee wording",
        "action definitely will work": "endpoint guarantee wording",
        "discord executed the action": "execution claim",
        "you should": "recommendation wording",
        "how to fix": "remediation wording",
        "change the role": "configuration advice",
        "edit the channel": "configuration advice",
    }
    return sorted(f"{label}: {phrase!r}" for phrase, label in forbidden.items() if phrase in text)


def audit_stage4_pass1_determinism(first: object, second: object) -> list[str]:
    """Compare two rendered explanations without depending on object identity."""

    first_dict = first.as_dict() if hasattr(first, "as_dict") else first
    second_dict = second.as_dict() if hasattr(second, "as_dict") else second
    return [] if first_dict == second_dict else ["EXPLANATION_OUTPUT_NONDETERMINISTIC"]


def audit_stage4_pass2_source(package_root: Path) -> list[str]:
    """Audit Pass 2 adapters for representation-only, non-network scope."""

    violations: list[str] = []
    targets = [package_root / "explanation_adapters.py", package_root / "explanation_integration.py"]
    banned_import_fragments = {
        "discord", "aiohttp", "requests", "urllib", "http", "sqlite", "persistence",
        "commands", "bot", "openai", "anthropic", "google",
    }
    allowed_local_imports = {
        ".canonical", ".explanation_schema", ".explanation_engine", ".explanation_adapters",
    }
    banned_local_fragments = {
        "permission_engine", "permission_overwrite_engine", "capability_engine",
        "thread_engine", "authority_engine", "action_engine",
    }
    banned_attributes = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "request", "raw_request", "post", "put", "patch", "delete", "send", "create",
        "edit", "open", "write_text", "write_bytes", "mkdir", "unlink", "remove",
    }
    forbidden_markers = {"STAGE4_PASS3", "STAGE5", "PASS7", "STAGE3_PASS7"}

    for path in targets:
        if not path.exists():
            violations.append(f"{path.name}: missing Stage 4 Pass 2 source file")
            continue
        source = path.read_text(encoding="utf-8")
        upper_source = source.upper()
        for marker in forbidden_markers:
            if marker in upper_source:
                violations.append(f"{path.name}: forbidden later-stage marker {marker!r}")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module = alias.name.lower()
                    if any(fragment in module for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned import {node.module!r}")
                if node.level:
                    local_name = f"{'.' * node.level}{node.module or ''}"
                    if any(fragment in local_name for fragment in banned_local_fragments):
                        violations.append(f"{path.name}:{node.lineno}: Stage 3 engine import {local_name!r}")
                    if local_name not in allowed_local_imports:
                        violations.append(f"{path.name}:{node.lineno}: unexpected local import {local_name!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attributes:
                violations.append(f"{path.name}:{node.lineno}: banned network or mutation-like attribute {node.attr!r}")
    return sorted(set(violations))


def audit_stage4_pass2_determinism(first: object, second: object) -> list[str]:
    """Compare two Pass 2 integration results without object identity."""

    first_dict = first.as_dict() if hasattr(first, "as_dict") else first
    second_dict = second.as_dict() if hasattr(second, "as_dict") else second
    return [] if first_dict == second_dict else ["EXPLANATION_INTEGRATION_NONDETERMINISTIC"]


def audit_stage4_pass3_source(package_root: Path) -> list[str]:
    """Audit Pass 3 query and presentation orchestration for pure scope."""

    violations: list[str] = []
    targets = [
        package_root / "explanation_query.py",
        package_root / "presentation_profiles.py",
        package_root / "explanation_orchestrator.py",
    ]
    banned_import_fragments = {
        "discord", "aiohttp", "requests", "urllib", "http", "sqlite", "persistence",
        "commands", "bot", "openai", "anthropic", "google",
    }
    allowed_local_imports = {
        ".canonical", ".explanation_adapters", ".explanation_engine", ".explanation_integration",
        ".explanation_query", ".explanation_schema", ".presentation_profiles",
    }
    banned_local_fragments = {
        "permission_engine", "permission_overwrite_engine", "capability_engine",
        "thread_engine", "authority_engine", "action_engine",
    }
    banned_attributes = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "request", "raw_request", "post", "put", "patch", "delete", "send", "create",
        "edit", "open", "write_text", "write_bytes", "mkdir", "unlink", "remove",
    }
    forbidden_markers = {"STAGE4_PASS4", "STAGE5", "PASS7", "STAGE3_PASS7"}

    for path in targets:
        if not path.exists():
            violations.append(f"{path.name}: missing Stage 4 Pass 3 source file")
            continue
        source = path.read_text(encoding="utf-8")
        upper_source = source.upper()
        for marker in forbidden_markers:
            if marker in upper_source:
                violations.append(f"{path.name}: forbidden later-stage marker {marker!r}")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module = alias.name.lower()
                    if any(fragment in module for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned import {node.module!r}")
                if node.level:
                    local_name = f"{'.' * node.level}{node.module or ''}"
                    if any(fragment in local_name for fragment in banned_local_fragments):
                        violations.append(f"{path.name}:{node.lineno}: Stage 3 engine import {local_name!r}")
                    if local_name not in allowed_local_imports:
                        violations.append(f"{path.name}:{node.lineno}: unexpected local import {local_name!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attributes:
                violations.append(f"{path.name}:{node.lineno}: banned network or mutation-like attribute {node.attr!r}")
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in {"requests", "urlopen"}:
                violations.append(f"{path.name}:{node.lineno}: direct network client call is not allowed")
    return sorted(set(violations))


def audit_stage4_pass3_determinism(first: object, second: object) -> list[str]:
    """Compare two Pass 3 orchestration results without object identity."""

    first_dict = first.as_dict() if hasattr(first, "as_dict") else first
    second_dict = second.as_dict() if hasattr(second, "as_dict") else second
    return [] if first_dict == second_dict else ["EXPLANATION_ORCHESTRATION_NONDETERMINISTIC"]


def audit_stage4_pass4_source(package_root: Path) -> list[str]:
    """Audit the local runtime/CLI/closure surface for pure read-only scope."""

    violations: list[str] = []
    targets = [
        package_root / "explanation_runtime.py",
        package_root / "explanation_cli.py",
        package_root / "stage4_closure.py",
        package_root / "stage4_closure_cli.py",
    ]
    banned_import_fragments = {
        "aiohttp", "asyncio", "discord", "dotenv", "http", "requests", "urllib", "sqlite",
        "persistence", "commands", "bot", "openai", "anthropic", "google", "socket",
    }
    allowed_local_imports = {
        ".canonical", ".explanation_adapters", ".explanation_orchestrator", ".explanation_query",
        ".explanation_schema", ".presentation_profiles", ".scenario_manifest", ".explanation_runtime",
        ".stage4_closure",
    }
    banned_attrs = {
        "request", "raw_request", "post", "put", "patch", "delete", "send", "create", "edit",
        "kick", "ban", "timeout", "move", "mute", "deafen", "assign", "reorder", "login",
        "connect", "urlopen",
    }
    forbidden_markers = {"STAGE5", "STAGE4_PASS5", "PASS7", "STAGE3_PASS7"}
    for path in targets:
        if not path.exists():
            violations.append(f"{path.name}: missing Stage 4 Pass 4 source file")
            continue
        source = path.read_text(encoding="utf-8")
        upper_source = source.upper()
        for marker in forbidden_markers:
            if marker in upper_source:
                violations.append(f"{path.name}: forbidden later-stage marker {marker!r}")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if any(fragment in alias.name.lower() for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned import {node.module!r}")
                if node.level:
                    local_name = f"{'.' * node.level}{node.module or ''}"
                    if local_name not in allowed_local_imports:
                        violations.append(f"{path.name}:{node.lineno}: unexpected local import {local_name!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attrs:
                violations.append(f"{path.name}:{node.lineno}: banned network or mutation-like attribute {node.attr!r}")
    return sorted(set(violations))


def audit_stage5_pass1_source(package_root: Path) -> list[str]:
    """Audit the Doctor query/rules/case/engine boundary for pure scope."""

    violations: list[str] = []
    targets = [
        package_root / "doctor_query.py",
        package_root / "doctor_rules.py",
        package_root / "doctor_case.py",
        package_root / "doctor_engine.py",
    ]
    banned_import_fragments = {
        "aiohttp", "asyncio", "discord", "dotenv", "http", "requests", "urllib",
        "sqlite", "persistence", "commands", "bot_cli", "openai", "anthropic", "google",
        "socket", "subprocess",
    }
    banned_attrs = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "request", "raw_request", "post", "put", "patch", "delete", "send", "create",
        "edit", "open", "write_text", "write_bytes", "mkdir", "unlink", "remove",
        "login", "connect", "urlopen",
    }
    allowed_evaluators = {
        "evaluate_guild_permissions",
        "evaluate_context_permissions",
        "evaluate_capability_expansion",
        "evaluate_thread_permissions",
        "evaluate_authority_analysis",
        "evaluate_action_orchestration",
        "orchestrate_explanation",
    }
    for path in targets:
        if not path.exists():
            violations.append(f"{path.name}: missing Stage 5 Pass 1 source file")
            continue
        source = path.read_text(encoding="utf-8")
        upper_source = source.upper()
        for marker in {"STAGE5_PASS2", "STAGE6", "STAGE3_PASS7"}:
            if marker in upper_source:
                violations.append(f"{path.name}: forbidden later-stage marker {marker!r}")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if any(fragment in alias.name.lower() for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned import {node.module!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attrs:
                violations.append(f"{path.name}:{node.lineno}: banned network or mutation-like attribute {node.attr!r}")
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in {"requests", "urlopen"}:
                violations.append(f"{path.name}:{node.lineno}: direct network client call is not allowed")
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id.startswith("evaluate_") and node.func.id not in allowed_evaluators:
                violations.append(f"{path.name}:{node.lineno}: unexpected evaluator {node.func.id!r}")
    return sorted(set(violations))


def audit_stage5_pass2_source(package_root: Path) -> list[str]:
    """Audit the Pass 2 enumeration boundary and frozen-interface routing."""

    violations: list[str] = []
    targets = [
        package_root / "doctor_enumeration_query.py",
        package_root / "doctor_population.py",
        package_root / "doctor_aggregation.py",
        package_root / "doctor_enumeration_case.py",
        package_root / "doctor_enumeration_engine.py",
    ]
    banned_import_fragments = {
        "aiohttp", "asyncio", "discord", "dotenv", "http", "requests", "urllib", "sqlite",
        "persistence", "commands", "bot_cli", "openai", "anthropic", "google", "socket", "subprocess",
    }
    banned_attrs = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "request", "raw_request", "post", "put", "patch", "delete", "send", "create", "edit", "open",
        "write_text", "write_bytes", "mkdir", "unlink", "remove", "login", "connect", "urlopen",
    }
    allowed_engine_local_imports = {
        ".canonical", ".doctor_aggregation", ".doctor_enumeration_case", ".doctor_enumeration_query",
        ".doctor_population", ".doctor_engine", ".doctor_query",
    }
    direct_stage3_calls = {
        "evaluate_guild_permissions", "evaluate_context_permissions", "evaluate_capability_expansion",
        "evaluate_thread_permissions", "evaluate_authority_analysis", "evaluate_action_orchestration",
        "orchestrate_explanation",
    }
    for path in targets:
        if not path.exists():
            violations.append(f"{path.name}: missing Stage 5 Pass 2 source file")
            continue
        source = path.read_text(encoding="utf-8")
        upper_source = source.upper()
        for marker in {"STAGE5_PASS3", "PASS3", "STAGE6"}:
            if marker in upper_source and path.name != "doctor_enumeration_query.py":
                violations.append(f"{path.name}: forbidden later-stage marker {marker!r}")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if any(fragment in alias.name.lower() for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned import {node.module!r}")
                if node.level and path.name == "doctor_enumeration_engine.py":
                    local_name = f"{'.' * node.level}{node.module or ''}"
                    if local_name not in allowed_engine_local_imports:
                        violations.append(f"{path.name}:{node.lineno}: unexpected local import {local_name!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attrs:
                violations.append(f"{path.name}:{node.lineno}: banned network or mutation-like attribute {node.attr!r}")
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                if node.func.id in direct_stage3_calls:
                    violations.append(f"{path.name}:{node.lineno}: direct Stage 3/4 call {node.func.id!r}")
                if node.func.id in {"requests", "urlopen"}:
                    violations.append(f"{path.name}:{node.lineno}: direct network client call is not allowed")
    engine_source = (package_root / "doctor_enumeration_engine.py").read_text(encoding="utf-8") if (package_root / "doctor_enumeration_engine.py").exists() else ""
    if "execute_doctor_query(" not in engine_source:
        violations.append("doctor_enumeration_engine.py: frozen Pass 1 public interface is not invoked")
    return sorted(set(violations))


def _audit_stage5_pass3_modules(package_root: Path) -> list[str]:
    """Shared AST audit for the additive Pass 3 pure modules."""

    violations: list[str] = []
    targets = [
        package_root / "doctor_source_query.py",
        package_root / "doctor_source_location.py",
        package_root / "doctor_role_comparison_query.py",
        package_root / "doctor_role_projection.py",
        package_root / "doctor_role_comparison.py",
    ]
    banned_import_fragments = {
        "aiohttp", "asyncio", "discord", "dotenv", "http", "requests", "urllib", "sqlite",
        "persistence", "commands", "bot_cli", "openai", "anthropic", "google", "socket", "subprocess",
    }
    banned_local_modules = {
        ".permission_engine", ".permission_overwrite_engine", ".capability_engine", ".thread_engine",
        ".authority_engine", ".action_engine", ".explanation_engine", ".explanation_adapters",
        ".explanation_integration", ".explanation_orchestrator", ".persistence", ".commands",
    }
    banned_call_names = {
        "evaluate_guild_permissions", "evaluate_context_permissions", "evaluate_capability_expansion",
        "evaluate_thread_permissions", "evaluate_authority_analysis", "evaluate_action_orchestration",
        "orchestrate_explanation", "requests", "urlopen",
    }
    banned_attrs = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "request", "raw_request", "post", "put", "patch", "delete", "send", "create", "edit", "open",
        "write_text", "write_bytes", "mkdir", "unlink", "remove", "login", "connect", "urlopen",
    }
    for path in targets:
        if not path.exists():
            violations.append(f"{path.name}: missing Stage 5 Pass 3 source file")
            continue
        source = path.read_text(encoding="utf-8")
        upper_source = source.upper()
        for marker in {"STAGE5_PASS4", "STAGE6", "DISCORDPY", "NETWORK"}:
            if marker in upper_source and marker not in {"NETWORK"}:
                violations.append(f"{path.name}: forbidden later-stage or transport marker {marker!r}")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if any(fragment in alias.name.lower() for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned import {node.module!r}")
                if node.level and f"{'.' * node.level}{node.module or ''}" in banned_local_modules:
                    violations.append(f"{path.name}:{node.lineno}: direct Stage 3/4 import {node.module!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attrs:
                violations.append(f"{path.name}:{node.lineno}: banned network or mutation-like attribute {node.attr!r}")
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in banned_call_names:
                violations.append(f"{path.name}:{node.lineno}: direct Stage 3/4 evaluator {node.func.id!r}")
    return sorted(set(violations))


def audit_stage5_pass3_source(package_root: Path) -> list[str]:
    """Audit all Pass 3 modules for pure, frozen-interface-only scope."""

    violations = _audit_stage5_pass3_modules(package_root)
    source_location = package_root / "doctor_source_location.py"
    comparison = package_root / "doctor_role_comparison.py"
    if source_location.exists() and "execute_doctor_query(" not in source_location.read_text(encoding="utf-8"):
        violations.append("doctor_source_location.py: frozen Pass 1 public interface is not invoked")
    if comparison.exists() and "execute_doctor_query(" not in comparison.read_text(encoding="utf-8"):
        violations.append("doctor_role_comparison.py: frozen Pass 1 public interface is not invoked")
    for path in (source_location, comparison):
        if path.exists() and "source_location" not in path.read_text(encoding="utf-8").lower():
            violations.append(f"{path.name}: source-location interface is not retained")
    return sorted(set(violations))


def audit_source_extractor_source(package_root: Path) -> list[str]:
    """Audit the source extractor independently from the comparison layer."""

    path = package_root / "doctor_source_location.py"
    violations = _audit_stage5_pass3_modules(package_root)
    if path.exists():
        source = path.read_text(encoding="utf-8")
        if "parse" in source.lower() and "prose" in source.lower() and "not" not in source.lower():
            violations.append("doctor_source_location.py: prose parsing marker is not bounded")
        if "execute_doctor_query(" not in source:
            violations.append("doctor_source_location.py: frozen interface call missing")
    return sorted(set(violations))


def audit_role_projection_source(package_root: Path) -> list[str]:
    """Audit hypothetical role projection purity and non-member wording."""

    violations = _audit_stage5_pass3_modules(package_root)
    path = package_root / "doctor_role_projection.py"
    if path.exists():
        source = path.read_text(encoding="utf-8").lower()
        for marker in ('"projection_is_real_member": True', "member_enumeration"):
            if marker in source:
                violations.append(f"doctor_role_projection.py: unsafe projection marker {marker!r}")
        if "hypothetical role-set projection" not in source:
            violations.append("doctor_role_projection.py: projection disclaimer missing")
    return sorted(set(violations))


def audit_no_duplicated_logic_source(package_root: Path) -> list[str]:
    """Ensure Pass 3 imports registries and the frozen Doctor interface only."""

    violations = _audit_stage5_pass3_modules(package_root)
    for name in ("doctor_source_location.py", "doctor_role_comparison.py", "doctor_role_projection.py"):
        path = package_root / name
        if path.exists():
            source = path.read_text(encoding="utf-8")
            if any(marker in source for marker in ("KNOWN_PERMISSION_MASK =", "def evaluate_guild_permissions", "def evaluate_context_permissions")):
                violations.append(f"{name}: duplicated Stage 3 rule implementation marker")
    return sorted(set(violations))


def audit_role_projection_wording_safety(package_root: Path) -> list[str]:
    """Audit that projection output disclaims real-member and ranking claims."""

    path = package_root / "doctor_role_projection.py"
    if not path.exists():
        return ["doctor_role_projection.py: missing"]
    source = path.read_text(encoding="utf-8").lower()
    required = ("hypothetical role-set projection", "not a real member", "member-specific overwrites", "unknown")
    return [f"doctor_role_projection.py: missing wording {item!r}" for item in required if item not in source]


def audit_source_location_wording_safety(package_root: Path) -> list[str]:
    """Audit that source explanations remain descriptive and non-remedial."""

    path = package_root / "doctor_source_location.py"
    if not path.exists():
        return ["doctor_source_location.py: missing"]
    source = path.read_text(encoding="utf-8").lower()
    required = ("structured", "source location", "actionable_in_principle")
    return [f"doctor_source_location.py: missing wording marker {item!r}" for item in required if item not in source]


def _audit_stage5_pass4_modules(package_root: Path) -> list[str]:
    """Audit the local Pass 4 orchestration layer without banning local I/O."""

    violations: list[str] = []
    targets = [
        package_root / "doctor_workflow.py",
        package_root / "doctor_guided_selector.py",
        package_root / "doctor_runtime.py",
        package_root / "doctor_cli.py",
        package_root / "stage5_closure.py",
        package_root / "stage5_closure_cli.py",
        package_root / "retained_input_schema.py",
        package_root / "stage5_replay_verification.py",
    ]
    banned_import_fragments = {
        "aiohttp", "asyncio", "discord", "dotenv", "http", "requests", "urllib", "sqlite",
        "persistence", "openai", "anthropic", "google", "socket", "websocket",
    }
    banned_local_modules = {
        ".permission_engine", ".permission_overwrite_engine", ".capability_engine", ".thread_engine",
        ".authority_engine", ".action_engine", ".explanation_engine", ".explanation_adapters",
        ".explanation_integration", ".explanation_orchestrator",
    }
    banned_call_names = {
        "evaluate_guild_permissions", "evaluate_context_permissions", "evaluate_capability_expansion",
        "evaluate_thread_permissions", "evaluate_authority_analysis", "evaluate_action_orchestration",
        "orchestrate_explanation", "requests", "urlopen",
    }
    banned_attrs = BANNED_GUILD_MUTATION_ATTRIBUTES | BANNED_DISCORD_METHOD_NAMES | {
        "request", "raw_request", "post", "put", "patch", "delete", "send", "create", "edit",
        "login", "connect", "urlopen", "sync", "tree",
    }
    for path in targets:
        if not path.exists():
            violations.append(f"{path.name}: missing Stage 5 Pass 4 source file")
            continue
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if any(fragment in alias.name.lower() for fragment in banned_import_fragments):
                        violations.append(f"{path.name}:{node.lineno}: banned import {alias.name!r}")
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").lower()
                if node.level == 0 and any(fragment in module for fragment in banned_import_fragments):
                    violations.append(f"{path.name}:{node.lineno}: banned import {node.module!r}")
                if node.level and f"{'.' * node.level}{node.module or ''}" in banned_local_modules:
                    violations.append(f"{path.name}:{node.lineno}: direct Stage 3/4 engine import {node.module!r}")
            elif isinstance(node, ast.Attribute) and node.attr.lower() in banned_attrs:
                violations.append(f"{path.name}:{node.lineno}: banned network or Discord mutation attribute {node.attr!r}")
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in banned_call_names:
                violations.append(f"{path.name}:{node.lineno}: direct Stage 3/4 evaluator {node.func.id!r}")
    return sorted(set(violations))


def audit_stage5_pass4_source(package_root: Path) -> list[str]:
    """Verify Pass 4 remains an additive local runtime and closure layer."""

    violations = _audit_stage5_pass4_modules(package_root)
    runtime = package_root / "doctor_runtime.py"
    if runtime.exists():
        source = runtime.read_text(encoding="utf-8")
        required = (
            "execute_doctor_query(", "execute_doctor_enumeration(",
            "execute_source_location_query(", "execute_role_comparison_query(",
        )
        for marker in required:
            if marker not in source:
                violations.append(f"doctor_runtime.py: frozen public interface missing {marker!r}")
    return sorted(set(violations))


def audit_doctor_workflow_purity(package_root: Path) -> list[str]:
    """Check the plan/selector/closure boundaries have no local output calls."""

    violations = _audit_stage5_pass4_modules(package_root)
    for name in ("doctor_workflow.py", "doctor_guided_selector.py", "stage5_closure.py"):
        path = package_root / name
        if path.exists():
            source = path.read_text(encoding="utf-8")
            for marker in ("write_text(", "write_bytes(", "mkdir(", "NamedTemporaryFile("):
                if marker in source:
                    violations.append(f"{name}: pure contract layer contains local I/O marker {marker!r}")
    return sorted(set(violations))


def audit_guided_selector_determinism(package_root: Path) -> list[str]:
    """Check the selector exposes exact structured selection only."""

    path = package_root / "doctor_guided_selector.py"
    if not path.exists():
        return ["doctor_guided_selector.py: missing"]
    source = path.read_text(encoding="utf-8").lower()
    violations: list[str] = []
    for marker in ("did you mean", "re.search", "re.match", "input("):
        if marker in source:
            violations.append(f"doctor_guided_selector.py: forbidden selector marker {marker!r}")
    for marker in ("select_exact", "question_type", "review", "confirm"):
        if marker not in source:
            violations.append(f"doctor_guided_selector.py: required deterministic marker missing {marker!r}")
    return sorted(set(violations))


def audit_doctor_frozen_interface_source(package_root: Path) -> list[str]:
    """Ensure Pass 4 uses only the four public Stage 5 execution entry points."""

    violations = _audit_stage5_pass4_modules(package_root)
    path = package_root / "doctor_runtime.py"
    if not path.exists():
        return sorted(set(violations + ["doctor_runtime.py: missing"]))
    source = path.read_text(encoding="utf-8")
    forbidden = ("from .permission_engine", "from .permission_overwrite_engine", "from .capability_engine", "from .thread_engine", "from .authority_engine", "from .action_engine")
    for marker in forbidden:
        if marker in source:
            violations.append(f"doctor_runtime.py: direct Stage 3 engine import {marker!r}")
    return sorted(set(violations))


def audit_doctor_no_duplicated_logic_source(package_root: Path) -> list[str]:
    """Detect obvious permission/evaluation implementation duplication in Pass 4."""

    violations = _audit_stage5_pass4_modules(package_root)
    path = package_root / "doctor_runtime.py"
    if path.exists():
        source = path.read_text(encoding="utf-8")
        for marker in ("def evaluate_guild_permissions", "def evaluate_context_permissions", "KNOWN_PERMISSION_MASK =", "def render_explanation"):
            if marker in source:
                violations.append(f"doctor_runtime.py: duplicated frozen logic marker {marker!r}")
    return sorted(set(violations))


def audit_doctor_wording_safety(package_root: Path) -> list[str]:
    """Verify Pass 4 retains read-only, pre-execution, and projection wording."""

    path = package_root / "doctor_runtime.py"
    if not path.exists():
        return ["doctor_runtime.py: missing"]
    source = path.read_text(encoding="utf-8").lower()
    required = ("never constructs a discord client", "pre-execution", "representation projection", "token_redaction_status")
    return [f"doctor_runtime.py: missing wording marker {item!r}" for item in required if item not in source]


def audit_stage5_replay_source(package_root: Path) -> list[str]:
    """Check retained-input assessment stays offline and does not replay by projection."""

    violations = _audit_stage5_pass4_modules(package_root)
    required = {
        "retained_input_schema.py": ("missing required replay inputs", "source identifier mapping must not be emitted"),
        "stage5_replay_verification.py": ("LOCAL_PROTECTED_EVIDENCE_ONLY", "does not reimplement or invoke permission engines"),
    }
    for name, markers in required.items():
        path = package_root / name
        if not path.exists():
            violations.append(f"{name}: missing")
            continue
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                violations.append(f"{name}: required replay-safety marker missing {marker!r}")
    return sorted(set(violations))
