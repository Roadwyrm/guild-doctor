"""Pure Stage 6 Pass 2 snapshot prerequisite evaluation."""
SNAPSHOT_GATE_CONTRACT='GUILD-DOCTOR-DISCORD-SNAPSHOT-GATE-0.1'
def evaluate_snapshot(state:str, member_required:bool=False, member_health:str='COMPLETE')->str:
    if state=='MISSING': return 'RETURN_INCOMPLETE'
    if state=='INCOMPATIBLE_SCHEMA': return 'REFUSE_SCHEMA_MISMATCH'
    if state=='OBJECT_DRIFT_DETECTED': return 'REFUSE_OBJECT_DRIFT'
    if member_required and member_health!='COMPLETE': return 'REQUIRE_TARGETED_MEMBER_FETCH'
    if state=='STALE_COMPLETE': return 'REQUIRE_FRESH_SCAN'
    if state in {'CURRENT_PARTIAL','STALE_PARTIAL'}: return 'PROCEED_WITH_WARNING'
    return 'PROCEED'
