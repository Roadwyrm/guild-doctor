"""Minimal, non-retaining interaction intake for four bounded live routes."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .discord_command_manifest import COMMAND_MANIFEST


INTERACTION_INTAKE_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-INTERACTION-INTAKE-0.1"
AUTHORIZED_LIVE_ROUTES = (
    "compare-role-permission", "compare-role-capability",
    "compare-role-action", "server-report",
)
_MANIFEST = {item.key: item for item in COMMAND_MANIFEST}
_COMPARISON_OPTION = {
    "compare-role-permission": "permission",
    "compare-role-capability": "capability",
    "compare-role-action": "action",
}


@dataclass(frozen=True, slots=True, repr=False)
class LiveAuthorizationContext:
    allowlisted_guild_id: str
    owner_member_id: str


@dataclass(frozen=True, slots=True)
class MinimalInteractionProjection:
    route_name: str
    normalized_options: tuple[tuple[str, str], ...]
    invocation_identifier: str
    guild_classification: str = "ALLOWLISTED_GUILD"
    actor_classification: str = "OWNER_ACTOR"
    authorization_classification: str = "OWNER_ALLOWLISTED"
    raw_interaction_retained: bool = False


@dataclass(frozen=True, slots=True)
class IntakeDecision:
    state: str
    stable_error: str | None
    response_policy: str
    projection: MinimalInteractionProjection | None
    authorization_before_domain: bool
    domain_invocation_count: int = 0
    raw_interaction_retained: bool = False

    def as_dict(self):
        return asdict(self)


class ResolvedSelectionBinding:
    """Ephemeral process-only ID bridge; deliberately non-serializable."""
    __slots__ = ("_values",)

    def __init__(self, values: Mapping[str, str]):
        self._values = dict(values)

    def get(self, key: str) -> str | None:
        return self._values.get(key)

    def clear(self) -> None:
        self._values.clear()

    def __repr__(self) -> str:
        return "ResolvedSelectionBinding(REDACTED)"


def _reject(code: str, *, respond: bool = True) -> tuple[IntakeDecision, ResolvedSelectionBinding]:
    return IntakeDecision(
        "REJECTED", code, "ONE_EPHEMERAL_INITIAL_ERROR" if respond else "NO_RESPONSE",
        None, True,
    ), ResolvedSelectionBinding({})


def _identifier(value: Any) -> str | None:
    candidate = getattr(value, "id", None)
    rendered = str(candidate) if candidate is not None else ""
    return rendered if rendered.isdecimal() else None


def _entity_guild_id(value: Any) -> str | None:
    direct = getattr(value, "guild_id", None)
    guild = getattr(value, "guild", None)
    candidate = direct if direct is not None else getattr(guild, "id", None)
    rendered = str(candidate) if candidate is not None else ""
    return rendered if rendered.isdecimal() else None


def project_application_command(
    source: Any, *, context: LiveAuthorizationContext, invocation_identifier: str,
) -> tuple[IntakeDecision, ResolvedSelectionBinding]:
    """Inspect only declared fields and immediately discard the source reference."""
    interaction_type = getattr(source, "interaction_type", getattr(source, "type", None))
    type_value = getattr(interaction_type, "value", interaction_type)
    if type_value != 2:
        # Autocomplete, component, and modal protocol responses are not normal
        # ephemeral message responses and are silently rejected here.
        return _reject("STAGE8_PASS4D_UNSUPPORTED_INTERACTION_TYPE", respond=False)
    command_type = getattr(source, "command_type", 1)
    command_type = getattr(command_type, "value", command_type)
    if command_type != 1:
        return _reject("STAGE8_PASS4D_UNSUPPORTED_COMMAND_TYPE", respond=False)
    if getattr(source, "is_direct_message", False) or getattr(source, "is_private_channel", False):
        return _reject("STAGE6_DM_NOT_SUPPORTED")
    guild_id = str(getattr(source, "guild_id", "") or "")
    actor_id = str(getattr(source, "actor_id", "") or "")
    if not guild_id:
        return _reject("STAGE8_PASS4D_GUILD_IDENTITY_MISSING")
    if guild_id != context.allowlisted_guild_id:
        return _reject("STAGE8_PASS4D_GUILD_NOT_ALLOWLISTED")
    if not actor_id:
        return _reject("STAGE8_PASS4D_ACTOR_IDENTITY_MISSING")
    if actor_id != context.owner_member_id:
        return _reject("STAGE6_OWNER_ONLY")
    route = str(getattr(source, "route_name", "") or "")
    if route not in _MANIFEST:
        return _reject("STAGE6_ACTION_UNKNOWN")
    if route not in AUTHORIZED_LIVE_ROUTES:
        return _reject("STAGE8_PASS4D_ROUTE_NOT_AUTHORIZED")
    if getattr(source, "has_attachments", False):
        return _reject("STAGE8_PASS4D_ATTACHMENT_PROHIBITED")
    if getattr(source, "has_message_content", False):
        return _reject("STAGE8_PASS4D_MESSAGE_CONTENT_PROHIBITED")
    supplied = getattr(source, "options", None)
    if not isinstance(supplied, Mapping):
        return _reject("STAGE8_PASS4D_OPTIONS_MALFORMED")
    definition = _MANIFEST[route]
    expected = {item.name: item for item in definition.options}
    if set(supplied) != set(expected):
        canonical_field = _COMPARISON_OPTION.get(route)
        role_fields_present = {"first-role", "second-role"}.issubset(supplied)
        if canonical_field is not None and role_fields_present:
            extra_fields = set(supplied) - set(expected)
            code = (
                "STAGE8_PASS4E_CANONICAL_OPTION_FIELD_MISMATCH"
                if extra_fields
                else "STAGE8_PASS4E_CANONICAL_OPTION_MISSING"
            )
            return _reject(code)
        return _reject("STAGE8_PASS4D_OPTIONS_MALFORMED")
    normalized: list[tuple[str, str]] = []
    raw_ids: dict[str, str] = {}
    role_index = 0
    for option in definition.options:
        value = supplied[option.name]
        if option.type == "role":
            entity_id = _identifier(value)
            if entity_id is None or _entity_guild_id(value) != context.allowlisted_guild_id:
                return _reject("STAGE8_PASS4D_RESOLVED_ENTITY_INVALID")
            symbol = "ROLE_ALPHA" if role_index == 0 else "ROLE_BETA"
            role_index += 1
            normalized.append((option.name, symbol)); raw_ids[symbol] = entity_id
        elif option.type in {"channel", "user"}:
            entity_id = _identifier(value)
            if entity_id is None or _entity_guild_id(value) != context.allowlisted_guild_id:
                return _reject("STAGE8_PASS4D_RESOLVED_ENTITY_INVALID")
            symbol = "CHANNEL_ALPHA" if option.type == "channel" else "MEMBER_ALPHA"
            normalized.append((option.name, symbol)); raw_ids[symbol] = entity_id
        elif option.type == "string":
            if not isinstance(value, str):
                if _COMPARISON_OPTION.get(route) == option.name:
                    return _reject("STAGE8_PASS4E_CANONICAL_OPTION_TYPE_INVALID")
                return _reject("STAGE8_PASS4D_OPTIONS_MALFORMED")
            if value == "":
                if _COMPARISON_OPTION.get(route) == option.name:
                    return _reject("STAGE8_PASS4E_CANONICAL_OPTION_EMPTY")
                return _reject("STAGE8_PASS4D_OPTIONS_MALFORMED")
            if value != value.strip():
                if _COMPARISON_OPTION.get(route) == option.name:
                    return _reject("STAGE8_PASS4E_CANONICAL_OPTION_WHITESPACE")
                return _reject("STAGE8_PASS4D_OPTIONS_MALFORMED")
            normalized.append((option.name, value))
        else:
            return _reject("STAGE8_PASS4D_OPTIONS_MALFORMED")
    selected_roles = tuple(raw_ids[key] for key in ("ROLE_ALPHA", "ROLE_BETA") if key in raw_ids)
    if len(selected_roles) > 1 and len(set(selected_roles)) != len(selected_roles):
        return _reject("STAGE8_PASS4D_RESOLVED_ROLE_PAIR_NOT_DISTINCT")
    projection = MinimalInteractionProjection(route, tuple(normalized), invocation_identifier)
    return IntakeDecision("ACCEPTED", None, "DEFER_THEN_EDIT", projection, True), ResolvedSelectionBinding(raw_ids)


__all__ = [
    "AUTHORIZED_LIVE_ROUTES", "INTERACTION_INTAKE_CONTRACT", "IntakeDecision",
    "LiveAuthorizationContext", "MinimalInteractionProjection", "ResolvedSelectionBinding",
    "project_application_command",
]
