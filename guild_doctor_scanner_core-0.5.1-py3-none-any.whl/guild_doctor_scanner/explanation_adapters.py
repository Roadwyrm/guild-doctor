"""Pure adapters from frozen Stage 3 results to Stage 4 Pass 1 requests.

The adapter layer performs representation validation and provenance capture
only.  It does not import or invoke a Stage 3 engine, acquire Discord data,
read persistence, infer missing evidence, or render explanation wording.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .canonical import canonical_json
from .explanation_schema import (
    EXPLANATION_MODES,
    ExplanationInputError,
    ExplanationRequest,
    RESULT_FAMILIES,
    STAGE4_PASS1_CONTRACT_VERSION,
)


STAGE4_PASS2_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE4-PASS2-0.1"
EXPLANATION_ADAPTERS_VERSION = "GUILD-DOCTOR-EXPLANATION-ADAPTERS-0.1"
EXPLANATION_INTEGRATION_GOLDEN_VERSION = "GUILD-DOCTOR-EXPLANATION-INTEGRATION-GOLDEN-0.1"
INTEGRATION_COMPLETENESS_COMPLETE = "COMPLETE"
INTEGRATION_COMPLETENESS_INCOMPLETE = "INCOMPLETE"
INTEGRATION_COMPLETENESS_UNKNOWN = "UNKNOWN"

PERMISSION_DEFINITION_VERSION = "DISCORD-PERM-2026-07-13"
SNAPSHOT_SCHEMA_VERSION = "GUILD-DOCTOR-SNAPSHOT-0.1"
STAGE3_FIXTURE_VERSION = "GUILD-DOCTOR-STAGE3-FIXTURE-0.1"

ADAPTER_RULE_CONTRACT = "EXPLAIN-ADAPT-CONTRACT-001"
ADAPTER_RULE_IDENTITY = "EXPLAIN-ADAPT-IDENTITY-001"
ADAPTER_RULE_TRACE = "EXPLAIN-ADAPT-TRACE-001"
ADAPTER_RULE_COMPLETENESS = "EXPLAIN-ADAPT-COMPLETENESS-001"
ADAPTER_RULE_RESULT = "EXPLAIN-ADAPT-RESULT-001"
ADAPTER_RULE_PROVENANCE = "EXPLAIN-ADAPT-PROVENANCE-001"
ADAPTER_RULE_PREEXECUTION = "EXPLAIN-ADAPT-PREEXECUTION-001"

ADAPTER_RULE_IDS = (
    ADAPTER_RULE_CONTRACT,
    ADAPTER_RULE_IDENTITY,
    ADAPTER_RULE_TRACE,
    ADAPTER_RULE_COMPLETENESS,
    ADAPTER_RULE_RESULT,
    ADAPTER_RULE_PROVENANCE,
    ADAPTER_RULE_PREEXECUTION,
)

_VERSION_KEYS = (
    "engine_contract_version",
    "pass1_contract_version",
    "pass2_contract_version",
    "pass3_contract_version",
    "pass4_contract_version",
    "pass5_contract_version",
    "pass6_contract_version",
    "snapshot_or_fixture_version",
)
_TRACE_ID_KEYS = frozenset(
    {"guild_id", "subject_id", "actor_id", "target_id", "context_id", "thread_id", "parent_channel_id"}
)
_COMPLETENESS_VALUES = frozenset({"COMPLETE", "PARTIAL", "UNKNOWN", "INCOMPLETE", "FAILED"})
_CONTROLLING_TRACE_STAGES = frozenset(
    {"FINAL_RESULT", "FINAL_PRECEDENCE", "THREAD_VIEW_RESULT", "THREAD_SEND_RESULT", "COMPLETENESS"}
)
_KNOWN_TRACE_STAGES = frozenset(
    {
        "INPUT_VALIDATION", "EVERYONE_ROLE_RESOLVED", "ASSIGNED_ROLE", "ROLE_UNION",
        "BYPASS", "COMPLETENESS", "RAW_CONTEXT_INPUT", "CONTEXT_EVERYONE_DENY",
        "CONTEXT_EVERYONE_ALLOW", "CONTEXT_ROLE_DENY", "CONTEXT_ROLE_ALLOW",
        "CONTEXT_MEMBER_DENY", "CONTEXT_MEMBER_ALLOW", "CONTEXT_RESULT",
        "FLAG_EXPANSION", "CONTEXT_APPLICABILITY", "DEPENDENCY", "TIMEOUT",
        "CAPABILITY_RESULT", "PARENT_RESULT_INPUT", "THREAD_RELATIONSHIP", "PARENT_VISIBILITY",
        "THREAD_TYPE", "MEMBERSHIP", "MANAGE_THREADS", "SEND_PERMISSION", "ARCHIVED_STATE",
        "LOCKED_STATE", "THREAD_TIMEOUT", "THREAD_HISTORY_RESULT", "THREAD_VIEW_RESULT",
        "THREAD_SEND_RESULT", "OPERATION_REGISTRY", "CAPABILITY_PERMISSION_INPUT",
        "ACTOR_AUTHORITY_INPUT", "TARGET_AUTHORITY_INPUT", "OWNER_PROTECTION", "HIERARCHY",
        "MANAGED_OBJECT", "PERMISSION_SUBSET", "MFA", "OBJECT_PRECONDITION", "COMPONENT_RESULTS",
        "ACTION_REGISTRY", "CONTRACT_VALIDATION", "IDENTITY_VALIDATION", "UPSTREAM_TRUST",
        "COMPONENT_COLLECTION", "COMPONENT_NORMALIZATION", "DEFINITIVE_BLOCKERS",
        "MATERIAL_UNCERTAINTIES", "SATISFIED_COMPONENTS", "FINAL_PRECEDENCE", "FINAL_RESULT",
        "PROVENANCE",
    }
)


class AdapterInputError(ExplanationInputError):
    """Raised when strict adapter validation is requested and fails."""


def _safe_json(value: Any, key: str = "") -> Any:
    """Copy JSON-shaped values while excluding credential-shaped fields."""

    lower_key = key.lower()
    if lower_key in {"token", "authorization", "access_token"} or "discord_token" in lower_key:
        return None
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _safe_json(method(), key)
    if isinstance(value, Mapping):
        return {
            str(item_key): _safe_json(item_value, str(item_key))
            for item_key, item_value in sorted(value.items(), key=lambda item: str(item[0]))
            if str(item_key).lower() not in {"token", "authorization", "access_token"}
            and "discord_token" not in str(item_key).lower()
        }
    if isinstance(value, (list, tuple)):
        return [_safe_json(item, key) for item in value]
    if isinstance(value, (set, frozenset)):
        return [_safe_json(item, key) for item in sorted(value, key=str)]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _mapping(value: Any) -> dict[str, Any]:
    method = getattr(value, "as_dict", None)
    if callable(method):
        value = method()
    if not isinstance(value, Mapping):
        raise AdapterInputError("EXPLAIN-ADAPT-RESULT-001: source result must be a mapping or as_dict object")
    return _safe_json(value)


def _text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    return text or None


def _upper(value: Any) -> str | None:
    text = _text(value)
    return text.upper() if text else None


def _id(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _id_valid(value: Any) -> bool:
    return value is not None and _id(value) is not None


def _values(value: Any) -> tuple[Any, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (value,)
    if isinstance(value, Mapping):
        return tuple(value.values())
    if isinstance(value, Sequence) or isinstance(value, (set, frozenset)):
        return tuple(value)
    return (value,)


def _tuple_text(value: Any) -> tuple[str, ...]:
    return tuple(str(item).strip() for item in _values(value) if str(item).strip())


def _fingerprint(value: Any) -> str:
    payload = _safe_json(value)
    if not isinstance(payload, Mapping):
        payload = {"value": payload}
    return hashlib.sha256(canonical_json(dict(payload)).encode("utf-8")).hexdigest()


def _declared_fingerprint(result: Mapping[str, Any]) -> str | None:
    for key in ("result_fingerprint", "input_fingerprint", "source_result_fingerprint"):
        value = _text(result.get(key))
        if value:
            if len(value) != 64 or any(character not in "0123456789abcdefABCDEF" for character in value):
                return None
            return value
    return None


def _valid_classification(value: str) -> bool:
    upper = value.upper()
    return upper in {
        "DOCUMENTED_EXPECTATION", "HISTORICAL_EVIDENCE", "AUTHORITATIVE_CLOSURE",
        "ACCEPTED_READ_ONLY_LIMITATION", "NEEDS_LIVE_TEST", "MODELED_RESULT",
        "SYNTHETIC_INTEGRATION", "LIVE_DERIVED_RESULT",
    } or upper.startswith(("LIVE_DERIVED_", "SYNTHETIC_", "HISTORICAL_", "AUTHORITATIVE_", "ACCEPTED_"))


def _valid_verification(value: str) -> bool:
    upper = value.upper()
    return upper in {"VERIFIED", "COMPLETE", "UNKNOWN", "INCOMPLETE"} or upper.startswith(
        ("VERIFIED_", "READ_ONLY_", "LIVE_", "SYNTHETIC_", "UNKNOWN_", "INCOMPLETE_", "NEEDS_")
    )


@dataclass(frozen=True, slots=True)
class AdapterRegistryRecord:
    result_family: str
    source_contract: str
    required_registry_versions: Mapping[str, str]
    adapter_key: str
    supported_explanation_modes: tuple[str, ...]
    required_fields: tuple[str, ...]
    optional_fields: tuple[str, ...]
    identity_fields: tuple[str, ...]
    trace_requirements: tuple[str, ...]
    completeness_requirements: tuple[str, ...]
    stable_adapter_rule_ids: tuple[str, ...]
    verification_status: str
    order: int

    def __post_init__(self) -> None:
        object.__setattr__(self, "required_registry_versions", MappingProxyType(dict(self.required_registry_versions)))

    def as_dict(self) -> dict[str, Any]:
        return {
            "result_family": self.result_family,
            "source_contract": self.source_contract,
            "required_registry_versions": dict(self.required_registry_versions),
            "adapter_key": self.adapter_key,
            "supported_explanation_modes": list(self.supported_explanation_modes),
            "required_fields": list(self.required_fields),
            "optional_fields": list(self.optional_fields),
            "identity_fields": list(self.identity_fields),
            "trace_requirements": list(self.trace_requirements),
            "completeness_requirements": list(self.completeness_requirements),
            "stable_adapter_rule_ids": list(self.stable_adapter_rule_ids),
            "verification_status": self.verification_status,
            "order": self.order,
        }


def _record(
    family: str,
    contract: str,
    key: str,
    required: tuple[str, ...],
    identity: tuple[str, ...],
    registries: Mapping[str, str],
    trace: tuple[str, ...],
    order: int,
) -> AdapterRegistryRecord:
    return AdapterRegistryRecord(
        result_family=family,
        source_contract=contract,
        required_registry_versions=registries,
        adapter_key=key,
        supported_explanation_modes=tuple(sorted(EXPLANATION_MODES)),
        required_fields=required,
        optional_fields=("evidence_classifications", "verification_statuses", "source_references", "input_health"),
        identity_fields=identity,
        trace_requirements=trace,
        completeness_requirements=("COMPLETE", "PARTIAL", "UNKNOWN", "INCOMPLETE", "FAILED"),
        stable_adapter_rule_ids=ADAPTER_RULE_IDS,
        verification_status="REPRESENTATION_ONLY",
        order=order,
    )


ADAPTER_REGISTRY = (
    _record(
        "GUILD_PERMISSION", "GUILD-DOCTOR-STAGE3-PASS1-0.1", "adapt_guild_permission_result",
        ("engine_contract_version", "permission_definition_version", "snapshot_or_fixture_version", "guild_id", "subject_id", "completeness_state", "trace"),
        ("guild_id", "subject_id"), {}, ("EVERYONE_ROLE_RESOLVED", "ROLE_UNION", "BYPASS", "COMPLETENESS"), 1,
    ),
    _record(
        "CONTEXT_PERMISSION", "GUILD-DOCTOR-STAGE3-PASS2-0.1", "adapt_context_permission_result",
        ("engine_contract_version", "pass1_contract_version", "permission_definition_version", "snapshot_or_fixture_version", "guild_id", "subject_id", "context_id", "context_type", "completeness_state", "trace"),
        ("guild_id", "subject_id", "context_id"), {}, ("RAW_CONTEXT_INPUT", "CONTEXT_EVERYONE_DENY", "CONTEXT_EVERYONE_ALLOW", "CONTEXT_ROLE_DENY", "CONTEXT_ROLE_ALLOW", "CONTEXT_MEMBER_DENY", "CONTEXT_MEMBER_ALLOW", "COMPLETENESS"), 2,
    ),
    _record(
        "CAPABILITY", "GUILD-DOCTOR-STAGE3-PASS3-0.1", "adapt_capability_result",
        ("engine_contract_version", "pass2_contract_version", "pass1_contract_version", "capability_registry_version", "permission_definition_version", "snapshot_or_fixture_version", "guild_id", "subject_id", "context_id", "completeness_state", "trace"),
        ("guild_id", "subject_id", "context_id"), {"capability_registry_version": "GUILD-DOCTOR-CAPABILITY-REGISTRY-0.1"}, ("RAW_CONTEXT_INPUT", "FLAG_EXPANSION", "CONTEXT_APPLICABILITY", "DEPENDENCY", "TIMEOUT", "CAPABILITY_RESULT", "COMPLETENESS"), 3,
    ),
    _record(
        "THREAD", "GUILD-DOCTOR-STAGE3-PASS4-0.1", "adapt_thread_result",
        ("engine_contract_version", "thread_rules_version", "pass3_contract_version", "pass2_contract_version", "pass1_contract_version", "capability_registry_version", "permission_definition_version", "snapshot_or_fixture_version", "guild_id", "subject_id", "thread_id", "parent_channel_id", "completeness_state", "trace"),
        ("guild_id", "subject_id", "thread_id", "parent_channel_id"), {"capability_registry_version": "GUILD-DOCTOR-CAPABILITY-REGISTRY-0.1", "thread_rules_version": "GUILD-DOCTOR-THREAD-RULES-0.1"}, ("THREAD_RELATIONSHIP", "PARENT_VISIBILITY", "MEMBERSHIP", "MANAGE_THREADS", "SEND_PERMISSION", "ARCHIVED_STATE", "LOCKED_STATE", "THREAD_VIEW_RESULT", "THREAD_SEND_RESULT", "COMPLETENESS"), 4,
    ),
    _record(
        "AUTHORITY", "GUILD-DOCTOR-STAGE3-PASS5-0.1", "adapt_authority_result",
        ("engine_contract_version", "authority_rules_version", "object_preconditions_version", "mfa_rules_version", "pass1_contract_version", "pass2_contract_version", "pass3_contract_version", "pass4_contract_version", "capability_registry_version", "permission_definition_version", "snapshot_or_fixture_version", "guild_id", "actor_id", "target_type", "operation_key", "analysis_completeness", "trace"),
        ("guild_id", "actor_id", "target_id"), {"capability_registry_version": "GUILD-DOCTOR-CAPABILITY-REGISTRY-0.1", "authority_rules_version": "GUILD-DOCTOR-AUTHORITY-RULES-0.1", "object_preconditions_version": "GUILD-DOCTOR-OBJECT-PRECONDITIONS-0.1", "mfa_rules_version": "GUILD-DOCTOR-MFA-RULES-0.1"}, ("TARGET_AUTHORITY_INPUT", "HIERARCHY", "MANAGED_OBJECT", "PERMISSION_SUBSET", "MFA", "OBJECT_PRECONDITION", "COMPONENT_RESULTS", "COMPLETENESS"), 5,
    ),
    _record(
        "ACTION", "GUILD-DOCTOR-STAGE3-PASS6-0.1", "adapt_action_result",
        ("pass6_contract_version", "action_rules_version", "action_golden_version", "permission_definition_version", "snapshot_or_fixture_version", "guild_id", "operation_key", "final_result", "decision_basis", "execution_attempted", "execution_guarantee", "analysis_completeness", "trace"),
        ("guild_id", "actor_id", "subject_id", "target_id", "context_id", "thread_id"), {"action_rules_version": "GUILD-DOCTOR-ACTION-RULES-0.1", "action_golden_version": "GUILD-DOCTOR-ACTION-GOLDEN-0.1"}, ("CONTRACT_VALIDATION", "IDENTITY_VALIDATION", "UPSTREAM_TRUST", "COMPONENT_COLLECTION", "COMPONENT_NORMALIZATION", "DEFINITIVE_BLOCKERS", "MATERIAL_UNCERTAINTIES", "FINAL_PRECEDENCE", "FINAL_RESULT", "COMPLETENESS", "PROVENANCE"), 6,
    ),
)

ADAPTER_REGISTRY_BY_FAMILY = MappingProxyType({item.result_family: item for item in ADAPTER_REGISTRY})
ADAPTER_REGISTRY_BY_CONTRACT = MappingProxyType({item.source_contract: item for item in ADAPTER_REGISTRY})


def validate_adapter_registry() -> tuple[str, ...]:
    errors: list[str] = []
    families: set[str] = set()
    contracts: set[str] = set()
    keys: set[str] = set()
    orders: set[int] = set()
    for item in ADAPTER_REGISTRY:
        if item.result_family in families:
            errors.append(f"DUPLICATE_FAMILY:{item.result_family}")
        if item.source_contract in contracts:
            errors.append(f"DUPLICATE_SOURCE_CONTRACT:{item.source_contract}")
        if item.adapter_key in keys:
            errors.append(f"DUPLICATE_ADAPTER_KEY:{item.adapter_key}")
        if item.order in orders:
            errors.append(f"DUPLICATE_ORDER:{item.order}")
        if item.result_family not in RESULT_FAMILIES:
            errors.append(f"FAMILY_INVALID:{item.result_family}")
        families.add(item.result_family)
        contracts.add(item.source_contract)
        keys.add(item.adapter_key)
        orders.add(item.order)
        if item.verification_status != "REPRESENTATION_ONLY":
            errors.append(f"VERIFICATION_STATUS_INVALID:{item.result_family}")
    if families != set(RESULT_FAMILIES):
        errors.append("FAMILY_COVERAGE_INCOMPLETE")
    return tuple(sorted(set(errors)))


@dataclass(frozen=True, slots=True)
class Stage3ExplanationAdapterRequest:
    source_result: Any
    source_trace: Sequence[Any] | None = None
    result_family: str | None = None
    source_contract: str | None = None
    mode: str = "SIMPLE"
    labels: Mapping[str, Any] | None = None
    source_stage3_contract_versions: Mapping[str, str] | None = None
    permission_definition_version: str | None = None
    registry_versions: Mapping[str, str] | None = None
    evidence_classifications: Sequence[str] = ()
    verification_statuses: Sequence[str] = ()
    source_references: Sequence[str] = ()
    guild_id: str | int | None = None
    subject_id: str | int | None = None
    actor_id: str | int | None = None
    target_id: str | int | None = None
    context_id: str | int | None = None
    thread_id: str | int | None = None
    include_ids_in_simple: bool = False
    include_raw_bits_in_detailed: bool = False
    include_full_trace_in_technical: bool = False
    authoritative_closure: Mapping[str, Any] | None = None
    historical_evidence: Mapping[str, Any] | None = None

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "Stage3ExplanationAdapterRequest":
        if not isinstance(value, Mapping):
            raise AdapterInputError("Stage 4 Pass 2 request must be a mapping")
        result = value.get("source_result", value.get("result"))
        if result is None:
            raise AdapterInputError("EXPLAIN-ADAPT-RESULT-001: source_result is required")
        return cls(
            source_result=result,
            source_trace=value.get("source_trace", value.get("trace")),
            result_family=value.get("result_family"),
            source_contract=value.get("source_contract"),
            mode=value.get("mode", "SIMPLE"),
            labels=value.get("labels", {}),
            source_stage3_contract_versions=value.get("source_stage3_contract_versions", value.get("contract_versions", {})),
            permission_definition_version=value.get("permission_definition_version"),
            registry_versions=value.get("registry_versions", {}),
            evidence_classifications=value.get("evidence_classifications", ()),
            verification_statuses=value.get("verification_statuses", ()),
            source_references=value.get("source_references", ()),
            guild_id=value.get("guild_id"),
            subject_id=value.get("subject_id"),
            actor_id=value.get("actor_id"),
            target_id=value.get("target_id"),
            context_id=value.get("context_id"),
            thread_id=value.get("thread_id"),
            include_ids_in_simple=bool(value.get("include_ids_in_simple", False)),
            include_raw_bits_in_detailed=bool(value.get("include_raw_bits_in_detailed", False)),
            include_full_trace_in_technical=bool(value.get("include_full_trace_in_technical", False)),
            authoritative_closure=value.get("authoritative_closure", value.get("closure_evidence")),
            historical_evidence=value.get("historical_evidence"),
        )


@dataclass(frozen=True, slots=True)
class AdaptedExplanationInput:
    stage4_pass2_contract_version: str
    adapter_registry_version: str
    adapter_key: str
    result_family: str | None
    source_contract: str | None
    source_result_fingerprint: str | None
    source_trace_fingerprint: str | None
    adapter_fingerprint: str
    explanation_request: ExplanationRequest | None
    integration_completeness: str
    adapter_warnings: tuple[str, ...]
    adapter_errors: tuple[str, ...]
    source_objects_unchanged: bool
    trace_records: tuple[Mapping[str, Any], ...]
    deterministic_provenance: Mapping[str, Any]

    def as_dict(self) -> dict[str, Any]:
        request = None
        if self.explanation_request is not None:
            request = {
                **self.explanation_request.as_dict(),
                "result": _safe_json(self.explanation_request.result),
                "trace": _safe_json(self.explanation_request.trace or ()),
            }
        return {
            "stage4_pass2_contract_version": self.stage4_pass2_contract_version,
            "adapter_registry_version": self.adapter_registry_version,
            "adapter_key": self.adapter_key,
            "result_family": self.result_family,
            "source_contract": self.source_contract,
            "source_result_fingerprint": self.source_result_fingerprint,
            "source_trace_fingerprint": self.source_trace_fingerprint,
            "adapter_fingerprint": self.adapter_fingerprint,
            "explanation_request": request,
            "integration_completeness": self.integration_completeness,
            "adapter_warnings": list(self.adapter_warnings),
            "adapter_errors": list(self.adapter_errors),
            "source_objects_unchanged": self.source_objects_unchanged,
            "trace_records": [_safe_json(item) for item in self.trace_records],
            "deterministic_provenance": _safe_json(self.deterministic_provenance),
        }


def _request_from(value: Stage3ExplanationAdapterRequest | Mapping[str, Any], family: str | None = None) -> Stage3ExplanationAdapterRequest:
    request = value if isinstance(value, Stage3ExplanationAdapterRequest) else Stage3ExplanationAdapterRequest.from_mapping(value)
    if family is None:
        return request
    return Stage3ExplanationAdapterRequest(
        source_result=request.source_result, source_trace=request.source_trace, result_family=family,
        source_contract=request.source_contract, mode=request.mode, labels=request.labels,
        source_stage3_contract_versions=request.source_stage3_contract_versions,
        permission_definition_version=request.permission_definition_version,
        registry_versions=request.registry_versions, evidence_classifications=request.evidence_classifications,
        verification_statuses=request.verification_statuses, source_references=request.source_references,
        guild_id=request.guild_id, subject_id=request.subject_id, actor_id=request.actor_id,
        target_id=request.target_id, context_id=request.context_id, thread_id=request.thread_id,
        include_ids_in_simple=request.include_ids_in_simple,
        include_raw_bits_in_detailed=request.include_raw_bits_in_detailed,
        include_full_trace_in_technical=request.include_full_trace_in_technical,
        authoritative_closure=request.authoritative_closure, historical_evidence=request.historical_evidence,
    )


def _source_contract_candidates(result: Mapping[str, Any]) -> tuple[str, ...]:
    values = []
    for key in ("engine_contract_version", "pass6_contract_version"):
        value = _text(result.get(key))
        if value:
            values.append(value)
    return tuple(dict.fromkeys(values))


def _read_identity(result: Mapping[str, Any], field: str) -> Any:
    if field == "actor_id":
        return result.get("actor_id", result.get("subject_id"))
    return result.get(field)


def _request_identity(request: Stage3ExplanationAdapterRequest, field: str) -> Any:
    if field == "actor_id":
        return request.actor_id if request.actor_id is not None else request.subject_id
    return getattr(request, field, None)


def _identity_validation(
    spec: AdapterRegistryRecord,
    result: Mapping[str, Any],
    request: Stage3ExplanationAdapterRequest,
    errors: list[str],
) -> dict[str, str | None]:
    identity: dict[str, str | None] = {}
    for field in spec.identity_fields:
        raw = _read_identity(result, field)
        if field in {"actor_id", "subject_id"} and spec.result_family == "ACTION":
            continue
        if field not in result:
            errors.append(f"{ADAPTER_RULE_IDENTITY}: missing source identity {field}")
            continue
        # Guild-scoped action results legitimately have no context or thread
        # identity.  Preserve the null as evidence; only a non-null identity
        # must be a decimal snowflake.  Target identity remains required for
        # non-NONE target types below.
        if (
            spec.result_family == "ACTION"
            and (
                field in {"context_id", "thread_id"}
                or (field == "target_id" and _upper(result.get("target_type")) in {None, "NONE"})
            )
            and raw is None
        ):
            identity[field] = None
            continue
        if not _id_valid(raw):
            errors.append(f"{ADAPTER_RULE_IDENTITY}: {field} is not a decimal snowflake")
        normalized = _id(raw)
        identity[field] = normalized
        supplied = _request_identity(request, field)
        if supplied is not None:
            if not _id_valid(supplied):
                errors.append(f"{ADAPTER_RULE_IDENTITY}: caller {field} is not a decimal snowflake")
            elif normalized is not None and normalized != _id(supplied):
                errors.append(f"{ADAPTER_RULE_IDENTITY}: caller {field} does not match source identity")
    if spec.result_family == "ACTION":
        actor = _read_identity(result, "actor_id")
        subject = _read_identity(result, "subject_id")
        if actor is None and subject is None:
            errors.append(f"{ADAPTER_RULE_IDENTITY}: action requires actor_id or subject_id")
        for field, raw in (("actor_id", actor), ("subject_id", subject)):
            if raw is not None and not _id_valid(raw):
                errors.append(f"{ADAPTER_RULE_IDENTITY}: {field} is not a decimal snowflake")
            identity[field] = _id(raw)
    target_type = _upper(result.get("target_type"))
    if "target_id" in spec.identity_fields and target_type not in {None, "NONE"}:
        if result.get("target_id") is None:
            errors.append(f"{ADAPTER_RULE_IDENTITY}: target_id is required for target_type {target_type}")
    for field, raw in ((field, _read_identity(result, field)) for field in spec.identity_fields):
        supplied = _request_identity(request, field)
        if supplied is not None and raw is None:
            errors.append(f"{ADAPTER_RULE_IDENTITY}: caller {field} cannot be matched to a missing source identity")
    return identity


def _trace_identity_conflicts(trace_records: Sequence[Mapping[str, Any]], identity: Mapping[str, str | None], errors: list[str]) -> None:
    for record in trace_records:
        source_ids = record.get("source_ids", {})
        if not isinstance(source_ids, Mapping):
            continue
        for field, raw in source_ids.items():
            if field not in identity or raw is None:
                continue
            if not _id_valid(raw):
                errors.append(f"{ADAPTER_RULE_IDENTITY}: trace {field} is not a decimal snowflake")
            elif identity.get(field) is not None and _id(raw) != identity.get(field):
                errors.append(f"{ADAPTER_RULE_IDENTITY}: trace {field} does not match source identity")


def _trace_records(raw_trace: Sequence[Any] | None, warnings: list[str], errors: list[str]) -> tuple[dict[str, Any], ...]:
    if raw_trace is None:
        warnings.append(f"{ADAPTER_RULE_TRACE}: material source trace is missing")
        return ()
    if isinstance(raw_trace, (str, bytes)) or not isinstance(raw_trace, Sequence):
        errors.append(f"{ADAPTER_RULE_TRACE}: source trace must be an ordered sequence")
        return ()
    if not raw_trace:
        warnings.append(f"{ADAPTER_RULE_TRACE}: material source trace is empty")
    records: list[dict[str, Any]] = []
    controlling: dict[tuple[str, str | None], str] = {}
    for index, raw in enumerate(raw_trace):
        if not isinstance(raw, Mapping):
            try:
                raw = _mapping(raw)
            except AdapterInputError:
                raw = None
        if not isinstance(raw, Mapping):
            errors.append(f"{ADAPTER_RULE_TRACE}: trace event {index} is not a mapping")
            continue
        details = raw.get("details") if isinstance(raw.get("details"), Mapping) else {}
        stage = _upper(raw.get("stage", raw.get("code", details.get("stage"))))
        if stage is None:
            errors.append(f"{ADAPTER_RULE_TRACE}: trace event {index} has no stage or code")
            continue
        if stage not in _KNOWN_TRACE_STAGES:
            warnings.append(f"{ADAPTER_RULE_TRACE}: unknown frozen trace stage preserved: {stage}")
        sequence = raw.get("sequence", index)
        if isinstance(sequence, bool) or not isinstance(sequence, int):
            try:
                sequence = int(sequence)
            except (TypeError, ValueError):
                errors.append(f"{ADAPTER_RULE_TRACE}: trace event {index} has malformed sequence")
                sequence = index
        rule_id = _text(raw.get("rule_id", details.get("rule_id")))
        state = _upper(
            raw.get(
                "new_state",
                raw.get(
                    "new_orchestration_state",
                    raw.get("normalized_state", details.get("new_state", details.get("state", details.get("result")))),
                ),
            )
        )
        component = _text(raw.get("component", details.get("component")))
        source_ids = {
            key: value
            for key, value in raw.items()
            if key in _TRACE_ID_KEYS and value is not None
        }
        for key, value in details.items():
            if key in _TRACE_ID_KEYS and value is not None:
                source_ids.setdefault(key, value)
        if stage in _CONTROLLING_TRACE_STAGES:
            control_key = (stage, component)
            if state is not None and control_key in controlling and controlling[control_key] != state:
                errors.append(f"{ADAPTER_RULE_TRACE}: contradictory controlling events for {stage}")
            elif state is not None:
                controlling[control_key] = state
        records.append(
            {
                "adapter_trace_event_id": f"ADAPT-TRACE-{index:04d}",
                "source_event_index": index,
                "source_sequence": sequence,
                "stage": stage,
                "code": _text(raw.get("code")) or stage,
                "rule_id": rule_id,
                "component": component,
                "before": raw.get("previous_state", raw.get("previous_orchestration_state", details.get("previous_state"))),
                "after": raw.get("new_state", raw.get("new_orchestration_state", raw.get("normalized_state", details.get("new_state")))),
                "verification": raw.get("verification", details.get("verification")),
                "evidence_source": raw.get("evidence_source", details.get("evidence_source", details.get("source"))),
                "source_ids": _safe_json(source_ids),
                "details": _safe_json(details),
                "source_event": _safe_json(raw),
            }
        )
    return tuple(records)


def _select_spec(request: Stage3ExplanationAdapterRequest, result: Mapping[str, Any], errors: list[str]) -> AdapterRegistryRecord | None:
    declared_family = _upper(request.result_family)
    explicit_contract = _text(request.source_contract)
    candidates = _source_contract_candidates(result)
    source_contract = explicit_contract or (candidates[0] if len(candidates) == 1 else None)
    if len(candidates) > 1:
        errors.append(f"{ADAPTER_RULE_CONTRACT}: multiple source contract identifiers are present")
    spec = None
    if declared_family is not None:
        spec = ADAPTER_REGISTRY_BY_FAMILY.get(declared_family)
        if spec is None:
            errors.append(f"{ADAPTER_RULE_CONTRACT}: unknown result family {declared_family}")
    elif source_contract is not None:
        spec = ADAPTER_REGISTRY_BY_CONTRACT.get(source_contract)
        if spec is None:
            errors.append(f"{ADAPTER_RULE_CONTRACT}: unknown trusted source contract {source_contract}")
    else:
        errors.append(f"{ADAPTER_RULE_CONTRACT}: explicit result family or trusted source contract is required")
    if spec is not None and source_contract is not None and source_contract != spec.source_contract:
        errors.append(f"{ADAPTER_RULE_CONTRACT}: family and source contract disagree")
    if spec is not None and not candidates:
        errors.append(f"{ADAPTER_RULE_CONTRACT}: source result does not declare {spec.source_contract}")
    if spec is not None:
        actual = result.get("pass6_contract_version" if spec.result_family == "ACTION" else "engine_contract_version")
        if actual != spec.source_contract:
            errors.append(f"{ADAPTER_RULE_CONTRACT}: expected {spec.source_contract}, got {actual!r}")
    return spec


def _versions_and_registries(
    spec: AdapterRegistryRecord,
    result: Mapping[str, Any],
    request: Stage3ExplanationAdapterRequest,
    errors: list[str],
) -> tuple[dict[str, str], dict[str, str], str | None]:
    source_versions = {key: str(result[key]) for key in _VERSION_KEYS if isinstance(result.get(key), str) and result.get(key)}
    supplied_versions = {str(key): str(value) for key, value in (request.source_stage3_contract_versions or {}).items() if value is not None}
    for key, value in supplied_versions.items():
        if key in source_versions and source_versions[key] != value:
            errors.append(f"{ADAPTER_RULE_CONTRACT}: caller contract version {key} disagrees with source")
        source_versions.setdefault(key, value)
    registry_values: dict[str, str] = {}
    embedded = result.get("registry_versions")
    if isinstance(embedded, Mapping):
        registry_values.update({str(key): str(value) for key, value in embedded.items() if value is not None})
    for key in (
        "capability_registry_version", "thread_rules_version", "authority_rules_version",
        "object_preconditions_version", "mfa_rules_version", "action_rules_version", "action_golden_version",
    ):
        if isinstance(result.get(key), str) and result.get(key):
            registry_values[key] = str(result[key])
    supplied_registries = {str(key): str(value) for key, value in (request.registry_versions or {}).items() if value is not None}
    for key, value in supplied_registries.items():
        if key in registry_values and registry_values[key] != value:
            errors.append(f"{ADAPTER_RULE_CONTRACT}: caller registry version {key} disagrees with source")
        registry_values.setdefault(key, value)
    for key, expected in spec.required_registry_versions.items():
        if registry_values.get(key) != expected:
            errors.append(f"{ADAPTER_RULE_CONTRACT}: {key} must be {expected}")
    permission = _text(request.permission_definition_version) or _text(result.get("permission_definition_version"))
    if request.permission_definition_version and _text(result.get("permission_definition_version")) and request.permission_definition_version != result.get("permission_definition_version"):
        errors.append(f"{ADAPTER_RULE_CONTRACT}: permission definition version disagrees with source")
    if permission != PERMISSION_DEFINITION_VERSION:
        errors.append(f"{ADAPTER_RULE_CONTRACT}: permission definition must be {PERMISSION_DEFINITION_VERSION}")
    return source_versions, registry_values, permission


def _completion(spec: AdapterRegistryRecord, result: Mapping[str, Any], warnings: list[str], errors: list[str]) -> str:
    key = "analysis_completeness" if spec.result_family == "AUTHORITY" or spec.result_family == "ACTION" else "completeness_state"
    value = _upper(result.get(key))
    if value is None:
        warnings.append(f"{ADAPTER_RULE_COMPLETENESS}: source completeness is missing")
        return INTEGRATION_COMPLETENESS_INCOMPLETE
    if value not in _COMPLETENESS_VALUES:
        errors.append(f"{ADAPTER_RULE_COMPLETENESS}: malformed source completeness {value}")
        return INTEGRATION_COMPLETENESS_UNKNOWN
    return INTEGRATION_COMPLETENESS_COMPLETE if value == "COMPLETE" else INTEGRATION_COMPLETENESS_INCOMPLETE


def _evidence_and_statuses(
    spec: AdapterRegistryRecord,
    result: Mapping[str, Any],
    request: Stage3ExplanationAdapterRequest,
    errors: list[str],
) -> tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]]:
    evidence = _tuple_text(request.evidence_classifications) or _tuple_text(result.get("evidence_classifications"))
    statuses = _tuple_text(request.verification_statuses) or _tuple_text(result.get("verification_statuses"))
    references = _tuple_text(request.source_references) + _tuple_text(result.get("source_references"))
    evidence = tuple(dict.fromkeys(evidence))
    statuses = tuple(dict.fromkeys(statuses))
    references = tuple(dict.fromkeys(references))
    for value in evidence:
        if not _valid_classification(value):
            errors.append(f"{ADAPTER_RULE_PROVENANCE}: invalid evidence classification {value}")
    for value in statuses:
        if not _valid_verification(value):
            errors.append(f"{ADAPTER_RULE_PROVENANCE}: invalid verification status {value}")
    return evidence, statuses, references


def _closure_provenance(request: Stage3ExplanationAdapterRequest, warnings: list[str]) -> dict[str, Any]:
    closure = request.authoritative_closure if isinstance(request.authoritative_closure, Mapping) else {}
    historical = request.historical_evidence if isinstance(request.historical_evidence, Mapping) else {}
    closure_decision = closure.get("decision", closure.get("closure_decision"))
    historical_status = historical.get("overall_status", historical.get("status"))
    if historical_status in {"PENDING", "STAGE3_IN_PROGRESS_LIVE_VERIFICATION_PENDING"} and closure_decision:
        warnings.append(f"{ADAPTER_RULE_PROVENANCE}: historical pending evidence remains non-authoritative")
    return {
        "authoritative_closure_contract": closure.get("contract"),
        "authoritative_closure_decision": closure_decision,
        "authoritative_closure_status": closure.get("status"),
        "historical_evidence_contract": historical.get("contract"),
        "historical_evidence_status": historical_status,
        "closure_takes_precedence": bool(closure_decision),
    }


def _adapt(request: Stage3ExplanationAdapterRequest) -> AdaptedExplanationInput:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        before_result = _mapping(request.source_result)
    except AdapterInputError as exc:
        return _build_adapted(
            request,
            {},
            None,
            None,
            INTEGRATION_COMPLETENESS_UNKNOWN,
            warnings,
            (str(exc),),
            (),
            {},
        )
    result = deepcopy(before_result)
    spec = _select_spec(request, result, errors)
    source_contract = None
    if spec is not None:
        source_contract = spec.source_contract
        for field in spec.required_fields:
            if field not in result:
                # A missing trace is a meaningful incomplete/unknown input,
                # not a malformed result.  _trace_records emits the warning.
                if field != "trace":
                    errors.append(f"{ADAPTER_RULE_RESULT}: required source field {field} is missing")
    if spec is None:
        completeness = INTEGRATION_COMPLETENESS_UNKNOWN
        trace_records = _trace_records(request.source_trace, warnings, errors)
        return _build_adapted(request, result, None, None, completeness, warnings, errors, trace_records, {})
    source_versions, registry_versions, permission_version = _versions_and_registries(spec, result, request, errors)
    identity = _identity_validation(spec, result, request, errors)
    trace_source = request.source_trace
    if trace_source is None and "trace" in result:
        trace_source = result.get("trace")
    elif trace_source is not None and "trace" in result and _safe_json(trace_source) != _safe_json(result.get("trace")):
        errors.append(f"{ADAPTER_RULE_TRACE}: supplied trace disagrees with source result trace")
    trace_records = _trace_records(trace_source, warnings, errors)
    _trace_identity_conflicts(trace_records, identity, errors)
    evidence, statuses, references = _evidence_and_statuses(spec, result, request, errors)
    completeness = _completion(spec, result, warnings, errors)
    if trace_source is None or not trace_records:
        completeness = INTEGRATION_COMPLETENESS_INCOMPLETE
    declared_fingerprint = _declared_fingerprint(result)
    if any(result.get(key) is not None for key in ("result_fingerprint", "input_fingerprint", "source_result_fingerprint")) and declared_fingerprint is None:
        errors.append(f"{ADAPTER_RULE_PROVENANCE}: malformed source fingerprint")
    if spec.result_family == "ACTION":
        if result.get("decision_basis") != "PRE_EXECUTION_MODEL":
            errors.append(f"{ADAPTER_RULE_PREEXECUTION}: action decision_basis must be PRE_EXECUTION_MODEL")
        if result.get("execution_attempted") is not False:
            errors.append(f"{ADAPTER_RULE_PREEXECUTION}: execution_attempted must be false")
        if result.get("execution_guarantee") is not False:
            errors.append(f"{ADAPTER_RULE_PREEXECUTION}: execution_guarantee must be false")
    labels = request.labels if isinstance(request.labels, Mapping) else {}
    if request.labels is not None and not isinstance(request.labels, Mapping):
        errors.append(f"{ADAPTER_RULE_PROVENANCE}: labels must be a mapping")
    closure_provenance = _closure_provenance(request, warnings)
    request_result = deepcopy(result)
    explanation_request = None
    try:
        explanation_request = ExplanationRequest(
            mode=request.mode,
            result_family=spec.result_family,
            result=request_result,
            trace=tuple(deepcopy(item) for item in (trace_source or ())),
            source_stage3_contract_versions=source_versions,
            permission_definition_version=permission_version,
            registry_versions=registry_versions,
            guild_id=identity.get("guild_id"),
            subject_id=identity.get("subject_id"),
            actor_id=identity.get("actor_id"),
            target_id=identity.get("target_id"),
            context_id=identity.get("context_id"),
            thread_id=identity.get("thread_id"),
            evidence_classifications=evidence,
            completeness_state=result.get("analysis_completeness", result.get("completeness_state")),
            verification_statuses=statuses,
            source_references=references,
            labels=labels,
            include_ids_in_simple=request.include_ids_in_simple,
            include_raw_bits_in_detailed=request.include_raw_bits_in_detailed,
            include_full_trace_in_technical=request.include_full_trace_in_technical,
        )
    except (ExplanationInputError, TypeError, ValueError) as exc:
        errors.append(f"{ADAPTER_RULE_RESULT}: invalid ExplanationRequest: {exc}")
    return _build_adapted(request, result, spec, explanation_request, completeness, warnings, errors, trace_records, closure_provenance, declared_fingerprint, identity)


def _build_adapted(
    request: Stage3ExplanationAdapterRequest,
    result: Mapping[str, Any],
    spec: AdapterRegistryRecord | None,
    explanation_request: ExplanationRequest | None,
    completeness: str,
    warnings: Sequence[str],
    errors: Sequence[str],
    trace_records: Sequence[Mapping[str, Any]],
    closure_provenance: Mapping[str, Any],
    declared_fingerprint: str | None = None,
    identity: Mapping[str, str | None] | None = None,
) -> AdaptedExplanationInput:
    source_result_fingerprint = declared_fingerprint or _fingerprint(result)
    source_trace_fingerprint = _fingerprint(list(trace_records))
    unchanged = False
    try:
        unchanged = _safe_json(request.source_result) == _safe_json(result)
    except Exception:
        unchanged = False
    provenance = {
        "stage4_pass1_contract_version": STAGE4_PASS1_CONTRACT_VERSION,
        "source_result_fingerprint": source_result_fingerprint,
        "source_trace_fingerprint": source_trace_fingerprint,
        "identity": dict(identity or {}),
        "closure": dict(closure_provenance),
        "adapter_representation_only": True,
    }
    adapter_payload = {
        "adapter_key": spec.adapter_key if spec else None,
        "result_family": spec.result_family if spec else None,
        "source_contract": spec.source_contract if spec else None,
        "source_result_fingerprint": source_result_fingerprint,
        "source_trace_fingerprint": source_trace_fingerprint,
        "integration_completeness": completeness,
        "adapter_warnings": list(warnings),
        "adapter_errors": list(errors),
        "trace_records": list(trace_records),
        "provenance": provenance,
    }
    adapter_fingerprint = _fingerprint(adapter_payload)
    return AdaptedExplanationInput(
        stage4_pass2_contract_version=STAGE4_PASS2_CONTRACT_VERSION,
        adapter_registry_version=EXPLANATION_ADAPTERS_VERSION,
        adapter_key=spec.adapter_key if spec else "unresolved",
        result_family=spec.result_family if spec else None,
        source_contract=spec.source_contract if spec else None,
        source_result_fingerprint=source_result_fingerprint,
        source_trace_fingerprint=source_trace_fingerprint,
        adapter_fingerprint=adapter_fingerprint,
        explanation_request=explanation_request,
        integration_completeness=completeness,
        adapter_warnings=tuple(dict.fromkeys(str(item) for item in warnings)),
        adapter_errors=tuple(dict.fromkeys(str(item) for item in errors)),
        source_objects_unchanged=unchanged,
        trace_records=tuple(dict(item) for item in trace_records),
        deterministic_provenance=provenance,
    )


def adapt_stage3_result(
    source_result: Stage3ExplanationAdapterRequest | Mapping[str, Any] | Any,
    *,
    result_family: str | None = None,
    source_contract: str | None = None,
    strict: bool = False,
    **kwargs: Any,
) -> AdaptedExplanationInput:
    if isinstance(source_result, Stage3ExplanationAdapterRequest):
        request = _request_from(source_result, result_family)
    elif isinstance(source_result, Mapping) and ("source_result" in source_result or "result" in source_result) and not hasattr(source_result, "as_dict"):
        request = _request_from(source_result, result_family)
    else:
        request = Stage3ExplanationAdapterRequest(source_result=source_result, result_family=result_family, source_contract=source_contract, **kwargs)
    if source_contract is not None and request.source_contract != source_contract:
        request = _request_from(
            Stage3ExplanationAdapterRequest(
                source_result=request.source_result, source_trace=request.source_trace, result_family=request.result_family,
                source_contract=source_contract, mode=request.mode, labels=request.labels,
                source_stage3_contract_versions=request.source_stage3_contract_versions,
                permission_definition_version=request.permission_definition_version, registry_versions=request.registry_versions,
                evidence_classifications=request.evidence_classifications, verification_statuses=request.verification_statuses,
                source_references=request.source_references, guild_id=request.guild_id, subject_id=request.subject_id,
                actor_id=request.actor_id, target_id=request.target_id, context_id=request.context_id, thread_id=request.thread_id,
                include_ids_in_simple=request.include_ids_in_simple, include_raw_bits_in_detailed=request.include_raw_bits_in_detailed,
                include_full_trace_in_technical=request.include_full_trace_in_technical,
                authoritative_closure=request.authoritative_closure, historical_evidence=request.historical_evidence,
            )
        )
    result = _adapt(request)
    if strict and result.adapter_errors:
        raise AdapterInputError("; ".join(result.adapter_errors))
    return result


def _family_adapter(family: str, source_result: Any, **kwargs: Any) -> AdaptedExplanationInput:
    return adapt_stage3_result(source_result, result_family=family, **kwargs)


def adapt_guild_permission_result(source_result: Any, **kwargs: Any) -> AdaptedExplanationInput:
    return _family_adapter("GUILD_PERMISSION", source_result, **kwargs)


def adapt_context_permission_result(source_result: Any, **kwargs: Any) -> AdaptedExplanationInput:
    return _family_adapter("CONTEXT_PERMISSION", source_result, **kwargs)


def adapt_capability_result(source_result: Any, **kwargs: Any) -> AdaptedExplanationInput:
    return _family_adapter("CAPABILITY", source_result, **kwargs)


def adapt_thread_result(source_result: Any, **kwargs: Any) -> AdaptedExplanationInput:
    return _family_adapter("THREAD", source_result, **kwargs)


def adapt_authority_result(source_result: Any, **kwargs: Any) -> AdaptedExplanationInput:
    return _family_adapter("AUTHORITY", source_result, **kwargs)


def adapt_action_result(source_result: Any, **kwargs: Any) -> AdaptedExplanationInput:
    return _family_adapter("ACTION", source_result, **kwargs)


__all__ = [
    "ADAPTER_REGISTRY",
    "ADAPTER_REGISTRY_BY_CONTRACT",
    "ADAPTER_REGISTRY_BY_FAMILY",
    "ADAPTER_RULE_IDS",
    "EXPLANATION_ADAPTERS_VERSION",
    "EXPLANATION_INTEGRATION_GOLDEN_VERSION",
    "INTEGRATION_COMPLETENESS_COMPLETE",
    "INTEGRATION_COMPLETENESS_INCOMPLETE",
    "INTEGRATION_COMPLETENESS_UNKNOWN",
    "AdapterInputError",
    "AdapterRegistryRecord",
    "AdaptedExplanationInput",
    "Stage3ExplanationAdapterRequest",
    "STAGE4_PASS2_CONTRACT_VERSION",
    "adapt_action_result",
    "adapt_authority_result",
    "adapt_capability_result",
    "adapt_context_permission_result",
    "adapt_guild_permission_result",
    "adapt_stage3_result",
    "adapt_thread_result",
    "validate_adapter_registry",
]
