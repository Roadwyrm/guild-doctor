"""Owner-only read-only application commands for the Stage 2 scanner.

The commands may respond to interactions and optionally register application
commands, but they do not create or modify guild roles, channels, overwrites,
members, messages, or other server configuration objects.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from .authorization import evaluate_owner_authorization
from .constants import SCANNER_CONTRACT_VERSION, SNAPSHOT_SCHEMA_VERSION
from .persistence import PERSISTENCE_SCHEMA_VERSION, SQLiteSnapshotRepository


@dataclass(frozen=True, slots=True)
class CommandResult:
    content: str
    ok: bool = True
    code: str = "OK"


class GuildDoctorCommandService:
    """Application-independent command behavior."""

    __slots__ = ("_scanner", "_repository", "_locks", "_locks_guard")

    def __init__(self, scanner: Any, repository: SQLiteSnapshotRepository) -> None:
        self._scanner = scanner
        self._repository = repository
        self._locks: dict[str, asyncio.Lock] = {}
        self._locks_guard = asyncio.Lock()

    async def status(self, guild_id: int | str) -> CommandResult:
        guild = _snowflake(guild_id)
        repo = await self._repository.repository_status()
        latest = await self._repository.latest_scan(guild)
        lines = [
            "**Guild Doctor scanner status**",
            f"Scanner contract: `{SCANNER_CONTRACT_VERSION}`",
            f"Snapshot schema: `{SNAPSHOT_SCHEMA_VERSION}`",
            f"Persistence schema: `{PERSISTENCE_SCHEMA_VERSION}`",
            f"Repository integrity: `{repo.integrity}`",
            f"Stored snapshots: `{repo.snapshot_count}`",
            f"Recorded scan runs: `{repo.scan_run_count}`",
        ]
        if latest is None:
            lines.append("Latest server scan: `NONE`")
        else:
            lines.extend(
                [
                    f"Latest server scan: `{latest.completed_at}`",
                    f"Latest result: `{'SNAPSHOT_SAVED' if latest.succeeded else 'NO_SNAPSHOT'}`",
                    f"Structural completeness: `{latest.structural_completeness}`",
                ]
            )
        lines.append("Mode: `READ_ONLY_GUILD_CONFIGURATION`")
        return CommandResult(_bounded(lines))

    async def scan(self, guild_id: int | str) -> CommandResult:
        guild = _snowflake(guild_id)
        lock = await self._guild_lock(guild)
        if lock.locked():
            return CommandResult(
                "A structural scan is already running for this server.",
                ok=False,
                code="SCAN_IN_PROGRESS",
            )

        async with lock:
            acquisition = await self._scanner.acquire_structure(guild)
            outcome = await self._repository.persist_acquisition(acquisition)

        if acquisition.snapshot is None:
            detail = acquisition.normalization_error or "No canonical snapshot was produced."
            return CommandResult(
                _bounded(
                    [
                        "**Guild Doctor structural scan failed safely**",
                        f"Scan run: `{outcome.run_id}`",
                        "Snapshot saved: `NO`",
                        f"Reason: `{_one_line(detail, 450)}`",
                        "Use `/guild-doctor scan-health` for collection status.",
                    ]
                ),
                ok=False,
                code="SCAN_NO_SNAPSHOT",
            )

        snapshot = acquisition.snapshot
        return CommandResult(
            _bounded(
                [
                    "**Guild Doctor structural scan complete**",
                    f"Snapshot ID: `{snapshot.snapshot_id}`",
                    f"Structural completeness: `{snapshot.structural_completeness}`",
                    f"Thread completeness: `{snapshot.thread_completeness}`",
                    f"Roles: `{snapshot.counts.get('roles')}`",
                    f"Channels: `{snapshot.counts.get('channels')}`",
                    f"Active threads: `{snapshot.counts.get('threads')}`",
                    f"Snapshot issues: `{len(snapshot.issues)}`",
                    f"Structural fingerprint: `{snapshot.structural_fingerprint_sha256}`",
                    "No Discord server objects were changed.",
                ]
            ),
            code="SCAN_COMPLETE" if snapshot.structural_completeness == "COMPLETE" else "SCAN_PARTIAL",
        )

    async def scan_health(self, guild_id: int | str) -> CommandResult:
        guild = _snowflake(guild_id)
        latest = await self._repository.latest_scan(guild)
        if latest is None:
            return CommandResult(
                "No scan health record exists for this server. Run `/guild-doctor scan` first.",
                ok=False,
                code="NO_SCAN",
            )

        lines = [
            "**Guild Doctor scan health**",
            f"Completed: `{latest.completed_at}`",
            f"Snapshot produced: `{'YES' if latest.succeeded else 'NO'}`",
            f"Structural completeness: `{latest.structural_completeness}`",
        ]
        if latest.normalization_error:
            lines.append(f"Normalization: `{_one_line(latest.normalization_error, 350)}`")

        for name, health in sorted(latest.collection_health.items()):
            status = str(health.get("status", "UNKNOWN"))
            received = health.get("received_count")
            expected = health.get("expected_count")
            attempts = health.get("attempt_count")
            codes = [str(item.get("code")) for item in health.get("errors", []) if item.get("code")]
            count_text = _count_text(received, expected)
            error_text = f"; errors={','.join(codes)}" if codes else ""
            lines.append(f"• `{name}`: `{status}`; {count_text}; attempts={attempts}{error_text}")
        return CommandResult(_bounded(lines))

    async def server_summary(self, guild_id: int | str) -> CommandResult:
        guild = _snowflake(guild_id)
        record = await self._repository.latest_snapshot(guild)
        if record is None:
            return CommandResult(
                "No saved structural snapshot exists for this server. Run `/guild-doctor scan` first.",
                ok=False,
                code="NO_SNAPSHOT",
            )

        snapshot = record.snapshot
        guild_data = snapshot.get("guild") or {}
        counts = snapshot.get("counts") or {}
        issues = snapshot.get("issues") or []
        severities: dict[str, int] = {}
        for issue in issues:
            severity = str(issue.get("severity", "UNKNOWN"))
            severities[severity] = severities.get(severity, 0) + 1

        issue_text = ", ".join(f"{key}={value}" for key, value in sorted(severities.items())) or "none"
        lines = [
            "**Guild Doctor server summary**",
            f"Server: `{_one_line(str(guild_data.get('name', 'Unknown')), 120)}`",
            f"Snapshot completed: `{record.completed_at}`",
            f"Structural completeness: `{record.structural_completeness}`",
            f"Roles: `{counts.get('roles')}`",
            f"Channels: `{counts.get('channels')}`",
            f"Active threads: `{counts.get('threads')}`",
            f"Managed bindings: `{counts.get('bindings')}`",
            f"Snapshot issues: `{record.issue_count}` ({issue_text})",
            f"Member data: `{record.member_completeness}`",
            "This is a structural summary, not an effective-permission decision.",
        ]
        return CommandResult(_bounded(lines))

    async def _guild_lock(self, guild_id: str) -> asyncio.Lock:
        async with self._locks_guard:
            return self._locks.setdefault(guild_id, asyncio.Lock())


class GuildDoctorCommandGroupFactory:
    """Create the discord.py `/guild-doctor` command group without importing it at package import time."""

    @staticmethod
    def create(
        service: GuildDoctorCommandService,
        owner_lookup: Callable[[int], Awaitable[int]],
    ) -> Any:
        import discord
        from discord import app_commands

        allowed_mentions = discord.AllowedMentions.none()

        class GuildDoctorGroup(app_commands.Group):
            def __init__(self) -> None:
                super().__init__(
                    name="guild-doctor",
                    description="Read-only Discord structure and scan-health tools",
                    guild_only=True,
                )

            async def _authorize(self, interaction: discord.Interaction) -> bool:
                guild_id = interaction.guild_id
                user_id = getattr(interaction.user, "id", None)
                if guild_id is None or user_id is None:
                    await interaction.response.send_message(
                        "Guild Doctor commands must be used inside a Discord server.",
                        ephemeral=True,
                        allowed_mentions=allowed_mentions,
                    )
                    return False

                try:
                    # Owner authorization is re-read through the pinned GET-only
                    # transport for every invocation. A stale cache must not grant
                    # private-alpha access after guild ownership changes.
                    owner_id = await owner_lookup(int(guild_id))
                except Exception:
                    await interaction.response.send_message(
                        "Guild Doctor could not verify the server owner. No action was taken.",
                        ephemeral=True,
                        allowed_mentions=allowed_mentions,
                    )
                    return False

                decision = evaluate_owner_authorization(
                    guild_id=guild_id,
                    actor_id=user_id,
                    owner_id=owner_id,
                )
                if not decision.allowed:
                    await interaction.response.send_message(
                        "This private-alpha command is restricted to the server owner.",
                        ephemeral=True,
                        allowed_mentions=allowed_mentions,
                    )
                    return False
                return True

            async def _simple(
                self,
                interaction: discord.Interaction,
                operation: Callable[[int], Awaitable[CommandResult]],
            ) -> None:
                if not await self._authorize(interaction):
                    return
                assert interaction.guild_id is not None
                try:
                    result = await operation(int(interaction.guild_id))
                    await interaction.response.send_message(
                        result.content,
                        ephemeral=True,
                        allowed_mentions=allowed_mentions,
                    )
                except Exception as exc:
                    await interaction.response.send_message(
                        f"Guild Doctor encountered a scanner error and made no server changes: `{_one_line(str(exc), 400)}`",
                        ephemeral=True,
                        allowed_mentions=allowed_mentions,
                    )

            @app_commands.command(name="status", description="Show Guild Doctor scanner and persistence status")
            async def status_command(self, interaction: discord.Interaction) -> None:
                await self._simple(interaction, service.status)

            @app_commands.command(name="scan", description="Run and save a read-only structural server scan")
            async def scan_command(self, interaction: discord.Interaction) -> None:
                if not await self._authorize(interaction):
                    return
                assert interaction.guild_id is not None
                await interaction.response.defer(ephemeral=True, thinking=True)
                try:
                    result = await service.scan(int(interaction.guild_id))
                    await interaction.followup.send(
                        result.content,
                        ephemeral=True,
                        allowed_mentions=allowed_mentions,
                    )
                except Exception as exc:
                    await interaction.followup.send(
                        f"Guild Doctor encountered a scanner error and made no server changes: `{_one_line(str(exc), 400)}`",
                        ephemeral=True,
                        allowed_mentions=allowed_mentions,
                    )

            @app_commands.command(name="scan-health", description="Show collection health for the latest scan")
            async def scan_health_command(self, interaction: discord.Interaction) -> None:
                await self._simple(interaction, service.scan_health)

            @app_commands.command(name="server-summary", description="Summarize the latest saved structural snapshot")
            async def server_summary_command(self, interaction: discord.Interaction) -> None:
                await self._simple(interaction, service.server_summary)

        return GuildDoctorGroup()


def _snowflake(value: int | str) -> str:
    text = str(value).strip()
    if not text.isdigit() or int(text) <= 0:
        raise ValueError("guild_id must be a positive Discord snowflake")
    return str(int(text))


def _one_line(value: str, limit: int) -> str:
    text = " ".join(value.split())
    if len(text) <= limit:
        return text
    return text[: max(limit - 1, 0)] + "…"


def _bounded(lines: list[str], limit: int = 1900) -> str:
    output: list[str] = []
    length = 0
    for line in lines:
        addition = len(line) + (1 if output else 0)
        if length + addition > limit:
            output.append("…output truncated; use the exported snapshot for full details.")
            break
        output.append(line)
        length += addition
    return "\n".join(output)


def _count_text(received: Any, expected: Any) -> str:
    if received is None and expected is None:
        return "count=unknown"
    if expected is None:
        return f"received={received}"
    return f"received={received}/{expected}"
