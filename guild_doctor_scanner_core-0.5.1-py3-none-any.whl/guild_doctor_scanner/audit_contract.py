"""Stage 6 Pass 6A immutable audit-contract vocabulary.

This module deliberately contains no audit rules, Discord transport, command
binding, recommendation execution, or permission calculation.
"""
from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass, fields, is_dataclass
import re
from types import TracebackType
from types import MappingProxyType
from typing import Any

from .constants import SCANNER_CONTRACT_VERSION, SNAPSHOT_SCHEMA_VERSION


AUDIT_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE6-PASS6-AUDIT-CONTRACT-0.1"
AUDIT_FINDING_CONTRACT_VERSION = "GUILD-DOCTOR-AUDIT-FINDING-0.1"
AUDIT_RULES_VERSION = "GUILD-DOCTOR-AUDIT-RULES-0.1"

FINDING_CLASSES = frozenset({
    "SECURITY_AUTHORITY",
    "CONFLICTS_INEFFECTIVENESS",
    "SYNCHRONIZATION_EXCEPTIONS",
    "MAINTAINABILITY_PERMISSION_DEBT",
    "NEEDS_REVIEW_INCOMPLETE_DATA",
})
AUDIT_SEVERITIES = frozenset({"CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL", "NEEDS_REVIEW"})
AUDIT_CONFIDENCE = frozenset({"VERIFIED", "HIGH", "MEDIUM", "LOW", "INSUFFICIENT_DATA"})
VERIFICATION_LABELS = frozenset({
    "VERIFIED_DISCORD_BEHAVIOR",
    "GUILD_DOCTOR_DOCTRINE",
    "OWNER_POLICY_REQUIRED",
    "PROPOSED_PRODUCT_BEHAVIOR",
})
EVALUATION_STATES = frozenset({
    "FINDING",
    "NOT_FOUND",
    "NOT_EVALUATED",
    "INCOMPLETE",
    "NOT_APPLICABLE",
    "NEEDS_REVIEW",
    "RULE_ERROR",
})
FINDING_STATUSES = frozenset({"PASS", "INCOMPLETE", "NOT_APPLICABLE", "RULE_ERROR"})
SAFE_OPTIONS = frozenset({
    "REVIEW_CONFIGURATION",
    "DOCUMENT_CURRENT_EXCEPTION",
    "REQUEST_MISSING_EVIDENCE",
    "LEAVE_UNCHANGED",
})
OBJECT_TYPES = frozenset({"GUILD", "ROLE", "CHANNEL", "CATEGORY", "THREAD", "OVERWRITE", "MEMBER", "COLLECTION"})
COMPLETENESS_VALUES = frozenset({
    "COMPLETE", "PARTIAL", "ESTIMATED", "UNKNOWN", "NOT_REQUESTED",
    "UNAVAILABLE", "FAILED", "UNSUPPORTED",
})

_IDENTIFIER = re.compile(r"^[A-Z][A-Z0-9_.-]{2,127}$")
_FINGERPRINT = re.compile(r"^[0-9a-f]{64}$")
_SNOWFLAKE = re.compile(r"(?<![A-Za-z0-9])\d{17,20}(?![A-Za-z0-9])")
_TOKEN_SHAPE = re.compile(r"^[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{8,}$")
_SECRET_FRAGMENTS = ("token", "authorization", "credential", "password", "api_key", "access_token", "client_secret")

REPORT_PRIVACY_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE7-PRIVACY-BOUNDARY-REPAIR-0.1"
_REPORT_MESSAGE_KEYS = frozenset({
    "content", "message_content", "message_body", "quoted_content",
    "quoted_message_content", "conversation_text", "message_text",
})
_REPORT_RAW_PAYLOAD_KEYS = frozenset({
    "raw_payload", "payload", "raw_request", "raw_response", "request_body",
    "response_body", "gateway_event", "gateway_payload", "discord_object",
    "discord_message", "source_snapshot", "snapshot_payload",
})
_REPORT_ENVIRONMENT_KEYS = frozenset({
    "environment", "environ", "os_environ", "process_environment",
    "environment_variables", "environment_dump",
})
_ENVIRONMENT_FIELD_NAMES = frozenset({
    "PATH", "HOME", "USERPROFILE", "USERNAME", "LOGNAME", "SHELL",
    "TEMP", "TMP", "APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "COMSPEC",
    "HOMEDRIVE", "HOMEPATH", "PYTHONPATH", "VIRTUAL_ENV",
})
_EMAIL_LIKE = re.compile(r"(?<![A-Za-z0-9._%+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![A-Za-z0-9.-])")
_WINDOWS_ABSOLUTE = re.compile(r"(?i)(?:^|[\s\"'])(?:[A-Z]:[\\/]|\\\\[^\\\s]+[\\][^\\\s]+)")
_UNIX_ABSOLUTE_ROOT = re.compile(r"(?:^|[\s\"'])/(?:home|etc|var|tmp|usr|opt|Users|root|mnt|srv|private)(?:/|$)")
_TRACEBACK_TEXT = re.compile(r"(?i)(traceback \(most recent call last\)|stack trace|\bFile [\"'][^\"']+[\"'], line \d+)")
_EXCEPTION_REPR = re.compile(r"\b[A-Za-z_][A-Za-z0-9_.]*(?:Error|Exception)\s*\([^\n]*\)")
_EXCEPTION_MESSAGE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_.]*(?:Error|Exception):\s+[^\n]+")


class AuditContractError(ValueError):
    """Raised for a stable Pass 6A audit-contract validation failure."""


def freeze(value: Any) -> Any:
    """Deep-freeze deterministic contract input without executing it."""
    method = getattr(value, "as_dict", None)
    if callable(method):
        value = method()
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): freeze(child) for key, child in sorted(value.items(), key=lambda item: str(item[0]))})
    if isinstance(value, (list, tuple)):
        return tuple(freeze(child) for child in value)
    if isinstance(value, (set, frozenset)):
        return tuple(freeze(child) for child in sorted(value, key=str))
    return deepcopy(value)


def thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): thaw(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [thaw(child) for child in value]
    return deepcopy(value)


def text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def upper(value: Any) -> str | None:
    result = text(value)
    return result.upper() if result else None


def safe_label(value: Any, fallback: str = "Object") -> str:
    result = text(value) or fallback
    result = " ".join(result.replace("@", "@\u200b").split())
    return result[:160]


def reference_key(*, object_type: str, object_id: str) -> str:
    """Produce a stable opaque key without serializing a Discord identifier."""
    from .canonical import sha256_hex

    return sha256_hex({"object_type": object_type, "object_id": object_id})


def scan_private(value: Any, path: str = "audit") -> tuple[str, ...]:
    """Return stable disclosure errors without including sensitive values."""
    errors: list[str] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            child_path = f"{path}.{key_text}"
            if any(fragment in key_text.lower() for fragment in _SECRET_FRAGMENTS):
                errors.append(f"AUDIT_CREDENTIAL_FIELD:{child_path}")
            errors.extend(scan_private(child, child_path))
    elif isinstance(value, (list, tuple, set, frozenset)):
        for index, child in enumerate(value):
            errors.extend(scan_private(child, f"{path}[{index}]"))
    elif isinstance(value, str):
        if _TOKEN_SHAPE.fullmatch(value.strip()) or "authorization:" in value.lower() or value.lower().startswith("bot "):
            errors.append(f"AUDIT_CREDENTIAL_VALUE:{path}")
        if _SNOWFLAKE.search(value):
            errors.append(f"AUDIT_RAW_IDENTIFIER_VALUE:{path}")
    return tuple(sorted(set(errors)))


def scan_report_private(
    value: Any,
    path: str = "report",
    *,
    max_depth: int = 64,
) -> tuple[str, ...]:
    """Detect report-visible private data without serializing opaque objects.

    Findings contain stable classes and safe structural paths only. Offending
    values are never included. This is intentionally stricter than the shared
    audit scanner and is used only at Stage 7 report/public boundaries.
    """
    findings: list[str] = list(scan_private(value, path))
    active: set[int] = set()

    def add(code: str, current_path: str) -> None:
        findings.append(f"{code}:{current_path}")

    def walk(item: Any, current_path: str, key: str | None, depth: int) -> None:
        if depth > max_depth:
            add("REPORT_PRIVACY_RECURSION_LIMIT", current_path)
            return
        if isinstance(item, (BaseException, TracebackType)):
            add("REPORT_PRIVACY_EXCEPTION_OBJECT", current_path)
            return
        if item is None or type(item) in {bool, int, float}:
            return
        if isinstance(item, str):
            if _EMAIL_LIKE.search(item):
                add("REPORT_PRIVACY_EMAIL", current_path)
            if _WINDOWS_ABSOLUTE.search(item):
                add("REPORT_PRIVACY_WINDOWS_PATH", current_path)
            if _UNIX_ABSOLUTE_ROOT.search(item):
                add("REPORT_PRIVACY_UNIX_PATH", current_path)
            if _TRACEBACK_TEXT.search(item) or _EXCEPTION_REPR.search(item) or _EXCEPTION_MESSAGE.search(item):
                add("REPORT_PRIVACY_EXCEPTION_TEXT", current_path)
            return
        if isinstance(item, (bytes, bytearray, memoryview)):
            add("REPORT_PRIVACY_OPAQUE_OBJECT", current_path)
            return

        identity = id(item)
        if identity in active:
            add("REPORT_PRIVACY_CYCLE", current_path)
            return
        active.add(identity)
        try:
            if isinstance(item, Mapping):
                normalized_keys = {str(child_key).strip().lower() for child_key in item}
                if normalized_keys & _REPORT_ENVIRONMENT_KEYS:
                    add("REPORT_PRIVACY_ENVIRONMENT", current_path)
                environment_hits = sum(1 for child_key in item if str(child_key).upper() in _ENVIRONMENT_FIELD_NAMES)
                if environment_hits >= 2:
                    add("REPORT_PRIVACY_ENVIRONMENT", current_path)
                for child_key, child in item.items():
                    key_text = str(child_key)
                    normalized = key_text.strip().lower()
                    child_path = f"{current_path}.{key_text}"
                    if normalized in _REPORT_MESSAGE_KEYS:
                        add("REPORT_PRIVACY_MESSAGE_CONTENT", child_path)
                        continue
                    if normalized in _REPORT_RAW_PAYLOAD_KEYS:
                        add("REPORT_PRIVACY_RAW_PAYLOAD", child_path)
                        continue
                    if normalized in _REPORT_ENVIRONMENT_KEYS:
                        add("REPORT_PRIVACY_ENVIRONMENT", child_path)
                        continue
                    walk(child, child_path, normalized, depth + 1)
                return
            if isinstance(item, (list, tuple)):
                for index, child in enumerate(item):
                    walk(child, f"{current_path}[{index}]", key, depth + 1)
                return
            if is_dataclass(item) and not isinstance(item, type):
                for field in fields(item):
                    walk(getattr(item, field.name), f"{current_path}.{field.name}", field.name.lower(), depth + 1)
                return
            add("REPORT_PRIVACY_OPAQUE_OBJECT", current_path)
        finally:
            active.remove(identity)

    walk(value, path, None, 0)
    return tuple(sorted(set(findings)))


@dataclass(frozen=True, slots=True)
class AuditSnapshotContext:
    """Validated provenance and completeness boundary for a future audit run."""

    guild_id: str
    snapshot_fingerprint: str
    schema_version: str = SNAPSHOT_SCHEMA_VERSION
    scanner_contract_version: str = SCANNER_CONTRACT_VERSION
    structural_completeness: str = "UNKNOWN"
    member_completeness: str = "UNKNOWN"
    thread_completeness: str = "UNKNOWN"
    collection_health: Mapping[str, str] | None = None
    audit_contract_version: str = AUDIT_CONTRACT_VERSION

    def __post_init__(self) -> None:
        values = {
            "guild_id": text(self.guild_id),
            "snapshot_fingerprint": text(self.snapshot_fingerprint),
            "schema_version": text(self.schema_version),
            "scanner_contract_version": text(self.scanner_contract_version),
            "audit_contract_version": text(self.audit_contract_version),
        }
        for key, value in values.items():
            object.__setattr__(self, key, value or "")
        for key in ("structural_completeness", "member_completeness", "thread_completeness"):
            object.__setattr__(self, key, upper(getattr(self, key)) or "UNKNOWN")
        health = {str(key): upper(value) or "UNKNOWN" for key, value in (self.collection_health or {}).items()}
        object.__setattr__(self, "collection_health", freeze(health))

    def as_dict(self) -> dict[str, Any]:
        return {
            "audit_contract_version": self.audit_contract_version,
            "schema_version": self.schema_version,
            "scanner_contract_version": self.scanner_contract_version,
            "guild_reference_key": reference_key(object_type="GUILD", object_id=self.guild_id),
            "snapshot_fingerprint": self.snapshot_fingerprint,
            "structural_completeness": self.structural_completeness,
            "member_completeness": self.member_completeness,
            "thread_completeness": self.thread_completeness,
            "collection_health": thaw(self.collection_health),
        }


def validate_snapshot_context(value: AuditSnapshotContext | Mapping[str, Any]) -> tuple[str, ...]:
    if isinstance(value, AuditSnapshotContext):
        context = value
    elif isinstance(value, Mapping):
        try:
            context = AuditSnapshotContext(
                guild_id=value.get("guild_id", ""),
                snapshot_fingerprint=value.get("snapshot_fingerprint", ""),
                schema_version=value.get("schema_version", SNAPSHOT_SCHEMA_VERSION),
                scanner_contract_version=value.get("scanner_contract_version", SCANNER_CONTRACT_VERSION),
                structural_completeness=value.get("structural_completeness", "UNKNOWN"),
                member_completeness=value.get("member_completeness", "UNKNOWN"),
                thread_completeness=value.get("thread_completeness", "UNKNOWN"),
                collection_health=value.get("collection_health", {}),
                audit_contract_version=value.get("audit_contract_version", AUDIT_CONTRACT_VERSION),
            )
        except (TypeError, ValueError, AttributeError):
            return ("AUDIT_CONTEXT_CONSTRUCTION_FAILED",)
    else:
        return ("AUDIT_CONTEXT_NOT_MAPPING",)
    errors: list[str] = []
    if not context.guild_id.isdecimal():
        errors.append("AUDIT_CONTEXT_GUILD_ID_INVALID")
    if not _FINGERPRINT.fullmatch(context.snapshot_fingerprint):
        errors.append("AUDIT_CONTEXT_SNAPSHOT_FINGERPRINT_INVALID")
    if context.schema_version != SNAPSHOT_SCHEMA_VERSION:
        errors.append("AUDIT_CONTEXT_SCHEMA_VERSION_UNSUPPORTED")
    if context.scanner_contract_version != SCANNER_CONTRACT_VERSION:
        errors.append("AUDIT_CONTEXT_SCANNER_CONTRACT_UNSUPPORTED")
    if context.audit_contract_version != AUDIT_CONTRACT_VERSION:
        errors.append("AUDIT_CONTEXT_CONTRACT_UNSUPPORTED")
    for key in ("structural_completeness", "member_completeness", "thread_completeness"):
        if getattr(context, key) not in COMPLETENESS_VALUES:
            errors.append(f"AUDIT_CONTEXT_COMPLETENESS_INVALID:{key}")
    if not isinstance(context.collection_health, Mapping):
        errors.append("AUDIT_CONTEXT_COLLECTION_HEALTH_INVALID")
    elif any(value not in COMPLETENESS_VALUES for value in context.collection_health.values()):
        errors.append("AUDIT_CONTEXT_COLLECTION_HEALTH_STATE_INVALID")
    return tuple(sorted(set(errors)))


__all__ = [
    "AUDIT_CONFIDENCE", "AUDIT_CONTRACT_VERSION", "AUDIT_FINDING_CONTRACT_VERSION",
    "AUDIT_RULES_VERSION", "AUDIT_SEVERITIES", "AuditContractError", "AuditSnapshotContext",
    "COMPLETENESS_VALUES", "EVALUATION_STATES", "FINDING_CLASSES", "FINDING_STATUSES",
    "OBJECT_TYPES", "SAFE_OPTIONS", "VERIFICATION_LABELS", "freeze", "reference_key",
    "safe_label", "scan_private", "text", "thaw", "upper", "validate_snapshot_context",
]
