"""Build a beginner-friendly, read-only server map from a normalized snapshot."""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Mapping


def _records(value: Any) -> tuple[Mapping[str, Any], ...]:
    if isinstance(value, Mapping):
        return tuple(item for item in value.values() if isinstance(item, Mapping))
    if isinstance(value, (list, tuple)):
        return tuple(item for item in value if isinstance(item, Mapping))
    return ()


def _access_label(category: Mapping[str, Any]) -> str:
    overwrites = category.get("permission_overwrites")
    if isinstance(overwrites, Mapping):
        return "RESTRICTED" if overwrites else "PUBLIC"
    if isinstance(overwrites, (list, tuple)):
        return "RESTRICTED" if overwrites else "PUBLIC"
    return "UNKNOWN"


def build_server_map(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    """Return a display-safe category/channel map.

    The result intentionally contains names and states only. Discord IDs,
    raw permission values, member identities, and message content are omitted.
    """
    channels = _records(snapshot.get("channels"))
    categories = tuple(
        channel for channel in channels
        if str(channel.get("type_key", "")).upper() == "CATEGORY"
    )
    by_parent: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for channel in channels:
        parent_id = channel.get("parent_id")
        if parent_id is not None:
            by_parent[str(parent_id)].append(channel)

    areas: list[dict[str, Any]] = []
    for category in sorted(categories, key=lambda item: (item.get("position", 0), str(item.get("name", "")))):
        category_id = str(category.get("id", ""))
        children = sorted(
            by_parent.get(category_id, []),
            key=lambda item: (item.get("position", 0), str(item.get("name", ""))),
        )
        sync_states = {str(child.get("sync_state", "UNKNOWN")).upper() for child in children}
        status = "REVIEW" if "UNSYNCED" in sync_states else "HEALTHY"
        areas.append({
            "name": str(category.get("name", "Unnamed category")),
            "access": _access_label(category),
            "status": status,
            "channels": [
                {
                    "name": str(child.get("name", "Unnamed channel")),
                    "type": str(child.get("type_key", "UNKNOWN")),
                    "sync": str(child.get("sync_state", "UNKNOWN")).upper(),
                }
                for child in children
            ],
        })

    return {
        "name": str((snapshot.get("guild") or {}).get("name", "Discord server")),
        "structural_completeness": str(snapshot.get("structural_completeness", "UNKNOWN")),
        "thread_completeness": str(snapshot.get("thread_completeness", "UNKNOWN")),
        "areas": areas,
        "display_policy": "NAMES_AND_STATES_ONLY",
    }


__all__ = ["build_server_map"]
