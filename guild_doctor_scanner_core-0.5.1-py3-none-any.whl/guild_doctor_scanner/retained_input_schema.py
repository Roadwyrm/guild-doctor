"""Privacy-safe retained-input contracts for Stage 5 Pass 4 replay assessment.

This module deliberately separates a historical result from the inputs needed
to calculate it.  It contains no Discord transport, token handling, or
permission logic.  A future authorized acquisition may use these contracts to
retain the minimum material input graph with synthetic, referentially
consistent identifiers; this module never reconstructs missing facts.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from .canonical import canonical_json


RETAINED_INPUT_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE5-RETAINED-INPUT-0.1"
PRIVACY_SAFE_REPLAY_CONTRACT_VERSION = "GUILD-DOCTOR-PRIVACY-SAFE-REPLAY-0.1"
REPLAY_CAPSULE_CONTRACT_VERSION = "GUILD-DOCTOR-REPLAY-CAPSULE-0.1"

AVAILABLE = "AVAILABLE"
ANONYMIZED_RELATIONSHIP = "ANONYMIZED_RELATIONSHIP"
EXPLICIT_UNKNOWN = "EXPLICIT_UNKNOWN"
EXPLICIT_NULL = "EXPLICIT_NULL"
REDACTED = "REDACTED"
MISSING = "MISSING"
OUTPUT_ONLY = "OUTPUT_ONLY"
CONTRADICTORY = "CONTRADICTORY"

_USABLE_STATES = frozenset({AVAILABLE, ANONYMIZED_RELATIONSHIP, EXPLICIT_UNKNOWN, EXPLICIT_NULL})
_TOKEN_RE = re.compile(r"(?i)(?:bot\s+)?[a-z0-9_-]{16,}\.[a-z0-9_-]{4,}\.[a-z0-9_-]{8,}")
_ID_FIELD_NAMES = frozenset(
    {
        "id",
        "guild_id",
        "owner_id",
        "actor_id",
        "subject_id",
        "target_id",
        "context_id",
        "parent_id",
        "role_id",
        "channel_id",
        "member_id",
        "user_id",
        "overwrite_target_id",
    }
)
_LABEL_FIELD_NAMES = frozenset({"name", "label", "display_name", "display_safe_object_label", "title", "nickname"})


class RetainedInputError(ValueError):
    """Raised when an input graph cannot safely become a replay capsule."""


@dataclass(frozen=True, slots=True)
class ReplayFieldRequirement:
    field: str
    material_reason: str
    preservation_check: str

    def as_dict(self) -> dict[str, str]:
        return {
            "field": self.field,
            "material_reason": self.material_reason,
            "preservation_check": self.preservation_check,
        }


@dataclass(frozen=True, slots=True)
class FieldObservation:
    field: str
    status: str
    source_paths: tuple[str, ...] = ()
    note: str = ""

    @property
    def replay_usable(self) -> bool:
        return self.status in _USABLE_STATES

    def as_dict(self) -> dict[str, Any]:
        return {
            "field": self.field,
            "status": self.status,
            "source_paths": list(self.source_paths),
            "note": self.note,
            "replay_usable": self.replay_usable,
        }


_HISTORICAL_REQUIREMENTS = (
    ReplayFieldRequirement("historical.final_result", "The replayed state must equal the recorded state exactly.", "result_state_preservation"),
    ReplayFieldRequirement("historical.primary_reason", "The replayed stable reason code must equal the recorded primary reason exactly.", "primary_reason_preservation"),
    ReplayFieldRequirement("historical.material_uncertainties", "Material uncertainty is part of the modeled result and cannot be replaced by an empty set.", "material_uncertainty_preservation"),
    ReplayFieldRequirement("historical.decision_basis", "The replay must preserve the pre-execution decision basis.", "pre_execution_model_preservation"),
    ReplayFieldRequirement("historical.execution_attempted", "A replay must prove no action was attempted.", "execution_attempted_false"),
    ReplayFieldRequirement("historical.execution_guarantee", "A replay must prove it makes no execution guarantee.", "execution_guarantee_false"),
)

_COMMON_INPUT_REQUIREMENTS = (
    ReplayFieldRequirement("scenario.identity_relationships", "Guild, actor, target, role, and context references must retain equality relationships under synthetic IDs.", "identity_relationship_preservation"),
    ReplayFieldRequirement("guild.mfa_level", "The authority model evaluates the guild MFA precondition from this value.", "material_uncertainty_preservation"),
    ReplayFieldRequirement("roles.complete_records", "Permission unions, hierarchy, managed-role state, and @everyone semantics depend on exact role records.", "result_state_preservation"),
    ReplayFieldRequirement("actor.member_record", "The frozen model reads the actor role assignments and bot state before calculating authority.", "result_state_preservation"),
    ReplayFieldRequirement("input.collection_health", "Collection completeness and explicit UNKNOWN state affect modeled completeness and uncertainty.", "material_uncertainty_preservation"),
    ReplayFieldRequirement("actor.mfa_state", "A human MFA state that cannot be observed must be retained as explicit UNKNOWN, never defaulted.", "material_uncertainty_preservation"),
)

_OPERATION_REQUIREMENTS: dict[str, tuple[ReplayFieldRequirement, ...]] = {
    "member.timeout": _HISTORICAL_REQUIREMENTS
    + _COMMON_INPUT_REQUIREMENTS
    + (
        ReplayFieldRequirement("target.member_record", "Owner protection, administrator protection, and target hierarchy are derived from the target member role assignments.", "result_state_preservation"),
        ReplayFieldRequirement("target.member_collection_health", "A missing targeted-member record cannot be treated as an empty role set or a non-administrator.", "material_uncertainty_preservation"),
    ),
    "role.edit": _HISTORICAL_REQUIREMENTS
    + _COMMON_INPUT_REQUIREMENTS
    + (
        ReplayFieldRequirement("target.role_record", "Managed state, @everyone identity, role tags, permissions, and exact hierarchy position are material to role editing.", "result_state_preservation"),
        ReplayFieldRequirement("actor.highest_role_resolution", "Role hierarchy requires the actor record and the complete role graph; an absent actor role set cannot be inferred.", "result_state_preservation"),
    ),
    "channel.manage": _HISTORICAL_REQUIREMENTS
    + _COMMON_INPUT_REQUIREMENTS
    + (
        ReplayFieldRequirement("context.channel_record", "Channel guild, parent, type, sync state, and exact overwrite collection are required by the context evaluator.", "result_state_preservation"),
        ReplayFieldRequirement("context.overwrite_collection_state", "Explicit null, empty, unknown, and populated overwrite collections have different meanings and must remain distinct.", "material_uncertainty_preservation"),
        ReplayFieldRequirement("actor.highest_role_resolution", "Channel permission calculation consumes the actor role graph and must not replace a missing actor record with an empty one.", "result_state_preservation"),
    ),
}


def required_replay_fields(operation_key: str) -> tuple[ReplayFieldRequirement, ...]:
    """Return the complete retained-input contract for one closure operation."""

    try:
        return _OPERATION_REQUIREMENTS[operation_key]
    except KeyError as exc:
        raise RetainedInputError(f"unsupported replay operation: {operation_key}") from exc


def assess_replay_capability(
    operation_key: str,
    observations: Mapping[str, FieldObservation],
    *,
    scenario_id: str,
    contradictory_fields: Sequence[FieldObservation] = (),
) -> dict[str, Any]:
    """Assess one scenario without constructing or inferring a capsule."""

    requirements = required_replay_fields(operation_key)
    normalized = {str(key): value for key, value in observations.items()}
    available: list[dict[str, Any]] = []
    missing: list[dict[str, Any]] = []
    redacted: list[dict[str, Any]] = []
    output_only: list[dict[str, Any]] = []
    for requirement in requirements:
        observation = normalized.get(requirement.field, FieldObservation(requirement.field, MISSING, note="No local retained source was found."))
        record = observation.as_dict() | {
            "material_reason": requirement.material_reason,
            "preservation_check": requirement.preservation_check,
        }
        if observation.replay_usable:
            available.append(record)
            if observation.status == ANONYMIZED_RELATIONSHIP:
                redacted.append(record)
        elif observation.status == REDACTED:
            redacted.append(record)
            missing.append(record)
        elif observation.status == OUTPUT_ONLY:
            output_only.append(record)
            missing.append(record)
        else:
            missing.append(record)
    contradiction_records = [item.as_dict() for item in contradictory_fields]
    exact = not missing and not contradiction_records
    return {
        "scenario_id": scenario_id,
        "operation_key": operation_key,
        "required_replay_fields": [item.as_dict() for item in requirements],
        "locally_available_fields": available,
        "missing_fields": missing,
        "contradictory_fields": contradiction_records,
        "redacted_fields": redacted,
        "output_only_fields": output_only,
        "exact_replay_possible": exact,
        "new_read_only_acquisition_required": not exact,
    }


def validate_material_inputs(operation_key: str, values: Mapping[str, Any]) -> None:
    """Reject capsule construction when a material field is absent or implicit."""

    missing = [item.field for item in required_replay_fields(operation_key) if item.field not in values or values[item.field] is None]
    if missing:
        raise RetainedInputError("missing required replay inputs: " + ", ".join(sorted(missing)))


def _contains_credential(value: Any) -> bool:
    if isinstance(value, Mapping):
        return any(_contains_credential(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(_contains_credential(item) for item in value)
    return isinstance(value, str) and bool(_TOKEN_RE.search(value))


def contains_credential_shaped_value(value: Any) -> bool:
    """Return whether a value contains a Discord-token-shaped string."""

    return _contains_credential(value)


class SyntheticIdentityAllocator:
    """Allocate deterministic decimal synthetic IDs without exposing source IDs."""

    def __init__(self) -> None:
        self._identities: dict[str, str] = {"__guild__": "900000000000000001"}

    @property
    def guild_id(self) -> str:
        return self._identities["__guild__"]

    def identity_for(self, source_identity: str, *, is_everyone_role: bool = False) -> str:
        if is_everyone_role:
            return self.guild_id
        key = str(source_identity)
        if key not in self._identities:
            self._identities[key] = f"900000{len(self._identities):012d}"
        return self._identities[key]

    def bind_guild(self, source_identity: str) -> None:
        """Bind the source guild identity to the reserved synthetic guild ID."""

        self._identities[str(source_identity)] = self.guild_id


def _is_identifier_key(key: str) -> bool:
    return key in _ID_FIELD_NAMES or key.endswith("_id") or key.endswith("_ids")


def _sanitize_value(value: Any, allocator: SyntheticIdentityAllocator, *, key: str | None = None, is_everyone_role: bool = False) -> Any:
    if isinstance(value, Mapping):
        record_is_everyone = bool(value.get("is_everyone", False))
        result: dict[str, Any] = {}
        for raw_key in sorted(value, key=str):
            field = str(raw_key)
            if field.lower() in _LABEL_FIELD_NAMES or field.lower() == "token":
                continue
            result[field] = _sanitize_value(value[raw_key], allocator, key=field, is_everyone_role=record_is_everyone)
        return result
    if isinstance(value, (list, tuple)):
        return [_sanitize_value(item, allocator, key=key, is_everyone_role=is_everyone_role) for item in value]
    if _is_identifier_key(key or "") and value is not None:
        return allocator.identity_for(str(value), is_everyone_role=is_everyone_role and (key == "id" or key == "role_id"))
    return value


def _sort_records(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _sort_records(value[key]) for key in sorted(value, key=str)}
    if isinstance(value, list):
        normalized = [_sort_records(item) for item in value]
        if all(isinstance(item, Mapping) and "id" in item for item in normalized):
            return sorted(normalized, key=lambda item: str(item["id"]))
        return sorted(normalized, key=canonical_json)
    return value


def build_privacy_safe_replay_capsule(
    operation_key: str,
    material_inputs: Mapping[str, Any],
    input_graph: Mapping[str, Any],
) -> dict[str, Any]:
    """Create a deterministic synthetic capsule only from complete supplied data.

    The source-to-synthetic mapping exists only during this call and is never
    returned or serialized.  Callers must pass explicit ``UNKNOWN`` or ``None``
    values; omitted material inputs are rejected rather than defaulted.
    """

    validate_material_inputs(operation_key, material_inputs)
    if _contains_credential(material_inputs) or _contains_credential(input_graph):
        raise RetainedInputError("credential-shaped value is forbidden in a replay capsule")
    allocator = SyntheticIdentityAllocator()
    guild = input_graph.get("guild") if isinstance(input_graph, Mapping) else None
    if isinstance(guild, Mapping) and guild.get("id") is not None:
        allocator.bind_guild(str(guild["id"]))
    sanitized = _sort_records(_sanitize_value(input_graph, allocator))
    capsule = {
        "contract": REPLAY_CAPSULE_CONTRACT_VERSION,
        "privacy_contract": PRIVACY_SAFE_REPLAY_CONTRACT_VERSION,
        "operation_key": operation_key,
        "synthetic_identifiers": True,
        "source_identifier_mapping_emitted": False,
        "material_input_fields": sorted(material_inputs),
        "input_graph": sanitized,
    }
    validation_errors = validate_replay_capsule(capsule)
    if validation_errors:
        raise RetainedInputError("invalid replay capsule: " + "; ".join(validation_errors))
    capsule["capsule_fingerprint"] = hashlib.sha256(canonical_json(capsule).encode("utf-8")).hexdigest()
    return capsule


def validate_replay_capsule(capsule: Mapping[str, Any]) -> list[str]:
    """Validate privacy and referential-integrity invariants without replaying."""

    errors: list[str] = []
    if capsule.get("contract") != REPLAY_CAPSULE_CONTRACT_VERSION:
        errors.append("unsupported capsule contract")
    if capsule.get("privacy_contract") != PRIVACY_SAFE_REPLAY_CONTRACT_VERSION:
        errors.append("unsupported privacy contract")
    if capsule.get("synthetic_identifiers") is not True:
        errors.append("synthetic identifier marker missing")
    if capsule.get("source_identifier_mapping_emitted") is not False:
        errors.append("source identifier mapping must not be emitted")
    if _contains_credential(capsule):
        errors.append("credential-shaped value present")
    graph = capsule.get("input_graph")
    if not isinstance(graph, Mapping):
        return errors + ["input graph missing"]
    guild = graph.get("guild")
    if isinstance(guild, Mapping):
        guild_id = guild.get("id")
        if not isinstance(guild_id, str) or not guild_id.isdecimal():
            errors.append("synthetic guild id must be a decimal string")
        roles = graph.get("roles", ())
        if isinstance(roles, Sequence) and not isinstance(roles, (str, bytes)):
            for role in roles:
                if isinstance(role, Mapping) and role.get("is_everyone") is True and role.get("id") != guild_id:
                    errors.append("synthetic @everyone role id must equal synthetic guild id")
    for field in ("roles", "members", "channels"):
        records = graph.get(field, ())
        if not isinstance(records, Sequence) or isinstance(records, (str, bytes)):
            continue
        for record in records:
            if isinstance(record, Mapping):
                for key, value in record.items():
                    if _is_identifier_key(str(key)) and value is not None:
                        identifiers = value if str(key).endswith("_ids") and isinstance(value, Sequence) and not isinstance(value, (str, bytes)) else (value,)
                        if any(not isinstance(item, str) or not item.isdecimal() for item in identifiers):
                            errors.append(f"{field}.{key} is not a synthetic decimal identifier")
                    if str(key).lower() in _LABEL_FIELD_NAMES:
                        errors.append(f"{field}.{key} must be excluded")
                    if str(key) in {"permissions_decimal", "allow", "deny", "allow_decimal", "deny_decimal"} and value is not None and not isinstance(value, (str, int)):
                        errors.append(f"{field}.{key} must retain an exact integer representation")
    return sorted(set(errors))


def capsule_fingerprint(capsule: Mapping[str, Any]) -> str:
    """Return a deterministic capsule digest without modifying the capsule."""

    return hashlib.sha256(canonical_json(dict(capsule)).encode("utf-8")).hexdigest()


__all__ = [
    "ANONYMIZED_RELATIONSHIP",
    "AVAILABLE",
    "CONTRADICTORY",
    "EXPLICIT_NULL",
    "EXPLICIT_UNKNOWN",
    "FieldObservation",
    "MISSING",
    "OUTPUT_ONLY",
    "PRIVACY_SAFE_REPLAY_CONTRACT_VERSION",
    "REDACTED",
    "REPLAY_CAPSULE_CONTRACT_VERSION",
    "RETAINED_INPUT_CONTRACT_VERSION",
    "ReplayFieldRequirement",
    "RetainedInputError",
    "SyntheticIdentityAllocator",
    "assess_replay_capability",
    "build_privacy_safe_replay_capsule",
    "capsule_fingerprint",
    "contains_credential_shaped_value",
    "required_replay_fields",
    "validate_material_inputs",
    "validate_replay_capsule",
]
