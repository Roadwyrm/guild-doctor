"""Executable Pass 4E validation-surface authority contract 0.3.

The contract is additive: historical 0.1 evidence and executable 0.2 records
remain owned by ``private_alpha_pass4e_repair4_authority`` and are never
upgraded by this module.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import re
from typing import Any, Callable, Mapping
import uuid

from .private_alpha_pass4e_repair4_authority import (
    AuthorityBinding,
    Repair4AuthorityError,
    _validate_binding,
)
from .private_alpha_pass4e_runtime_receipt import RUNTIME_RECEIPT_CONTRACT
from .private_alpha_pass4e_validation_surface import (
    TEMPORARY_COMMAND_NAME,
    VALIDATION_SURFACE_VERSION,
    ValidationSurfaceMode,
    build_validation_manifest,
    serialized_validation_schema,
    serialized_validation_schema_fingerprint,
    validation_manifest_fingerprint,
)


VALIDATION_AUTHORITY_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-REPAIR4-LIVE-AUTHORITY-0.3"
COMMAND_SYNC_POLICY_VERSION = "GUILD-DOCTOR-STAGE8-PASS4E-COMMAND-SYNC-POLICY-0.1"
AUTHORIZED_SYNC_SCOPE = "ONE_CONFIGURED_PRIVATE_ALPHA_GUILD"
RUNTIME_RECEIPT_VERSION = RUNTIME_RECEIPT_CONTRACT.rsplit("-", 1)[-1]
_FINGERPRINT = re.compile(r"[0-9a-f]{64}")
_REFERENCE = re.compile(r"[0-9a-f]{32}")
_IDENTIFIER = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}")


class ValidationAuthorityError(ValueError):
    pass


@dataclass(frozen=True, slots=True, kw_only=True)
class ValidationAuthorityBinding:
    base_binding: AuthorityBinding
    validation_surface_required: bool
    validation_surface_mode: str
    validation_surface_version: str
    temporary_validation_manifest_fingerprint: str
    temporary_serialized_schema_fingerprint: str
    cleanup_manifest_fingerprint: str
    pre_live_guild_sync_required: bool
    post_live_cleanup_sync_required: bool
    authorized_sync_scope: str
    global_sync_prohibited: bool
    other_guild_sync_prohibited: bool
    runtime_receipt_contract_version: str
    command_sync_policy_version: str
    authorized_target_binding_fingerprint: str
    pre_live_sync_proof_fingerprint: str


@dataclass(frozen=True, slots=True, kw_only=True)
class ValidationAuthorityRecord:
    authority_contract: str
    issuance_identifier: str
    issuance_reference: str
    base_binding: AuthorityBinding
    validation_surface_required: bool
    validation_surface_mode: str
    validation_surface_version: str
    temporary_validation_manifest_fingerprint: str
    temporary_serialized_schema_fingerprint: str
    cleanup_manifest_fingerprint: str
    pre_live_guild_sync_required: bool
    post_live_cleanup_sync_required: bool
    authorized_sync_scope: str
    global_sync_prohibited: bool
    other_guild_sync_prohibited: bool
    runtime_receipt_contract_version: str
    command_sync_policy_version: str
    authorized_target_binding_fingerprint: str
    pre_live_sync_proof_fingerprint: str
    issuance_state: str
    issuance_timestamp: str
    consumption_state: str
    consumption_timestamp: str | None
    invalidation_reason: str | None

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["base_binding"]["approved_routes"] = list(self.base_binding.approved_routes)
        return value


@dataclass(frozen=True, slots=True)
class ValidationRuntimeAuthority:
    base_runtime_authority: Any
    authority_contract: str
    validation_surface_required: bool
    validation_surface_mode: str
    validation_surface_version: str
    temporary_validation_manifest_fingerprint: str
    temporary_serialized_schema_fingerprint: str
    cleanup_manifest_fingerprint: str
    pre_live_guild_sync_required: bool
    post_live_cleanup_sync_required: bool
    authorized_sync_scope: str
    global_sync_prohibited: bool
    other_guild_sync_prohibited: bool
    runtime_receipt_contract_version: str
    command_sync_policy_version: str
    authorized_target_binding_fingerprint: str
    pre_live_sync_proof_fingerprint: str


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def authority_contract_fingerprint() -> str:
    fields = tuple(ValidationAuthorityRecord.__dataclass_fields__)
    return hashlib.sha256(_canonical({"contract": VALIDATION_AUTHORITY_CONTRACT, "fields": fields})).hexdigest()


def expected_validation_bindings() -> dict[str, Any]:
    validation_manifest = build_validation_manifest(ValidationSurfaceMode.PASS4E_VALIDATION)
    cleanup_manifest = build_validation_manifest(ValidationSurfaceMode.CLEANUP)
    validation_schema = serialized_validation_schema(ValidationSurfaceMode.PASS4E_VALIDATION)
    if len(validation_manifest) != 14 or len(cleanup_manifest) != 13:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_MANIFEST_SHAPE_INVALID")
    if sum(item.key == TEMPORARY_COMMAND_NAME for item in validation_manifest) != 1:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_TEMPORARY_ROUTE_INVALID")
    if any(item.key == TEMPORARY_COMMAND_NAME for item in cleanup_manifest):
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_CLEANUP_INVALID")
    if validation_schema.get("serialized_application_command_object_count") != 1:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_SCHEMA_SHAPE_INVALID")
    return {
        "validation_surface_required": True,
        "validation_surface_mode": ValidationSurfaceMode.PASS4E_VALIDATION.value,
        "validation_surface_version": VALIDATION_SURFACE_VERSION,
        "temporary_validation_manifest_fingerprint": validation_manifest_fingerprint(ValidationSurfaceMode.PASS4E_VALIDATION),
        "temporary_serialized_schema_fingerprint": serialized_validation_schema_fingerprint(ValidationSurfaceMode.PASS4E_VALIDATION),
        "cleanup_manifest_fingerprint": validation_manifest_fingerprint(ValidationSurfaceMode.CLEANUP),
        "pre_live_guild_sync_required": True,
        "post_live_cleanup_sync_required": True,
        "authorized_sync_scope": AUTHORIZED_SYNC_SCOPE,
        "global_sync_prohibited": True,
        "other_guild_sync_prohibited": True,
        "runtime_receipt_contract_version": RUNTIME_RECEIPT_VERSION,
        "command_sync_policy_version": COMMAND_SYNC_POLICY_VERSION,
    }


def build_validation_authority_binding(
    *, base_binding: AuthorityBinding, authorized_target_binding_fingerprint: str,
    pre_live_sync_proof_fingerprint: str,
) -> ValidationAuthorityBinding:
    return ValidationAuthorityBinding(
        base_binding=base_binding,
        authorized_target_binding_fingerprint=authorized_target_binding_fingerprint,
        pre_live_sync_proof_fingerprint=pre_live_sync_proof_fingerprint,
        **expected_validation_bindings(),
    )


def validate_validation_authority_binding(binding: ValidationAuthorityBinding) -> None:
    if not isinstance(binding, ValidationAuthorityBinding):
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_BINDING_INVALID")
    try:
        _validate_binding(binding.base_binding)
    except Repair4AuthorityError as exc:
        raise ValidationAuthorityError(str(exc)) from None
    expected = expected_validation_bindings()
    for name, wanted in expected.items():
        if getattr(binding, name) != wanted:
            raise ValidationAuthorityError(f"STAGE8_PASS4E_VALIDATION_AUTHORITY_{name.upper()}_MISMATCH")
    for value in (binding.authorized_target_binding_fingerprint, binding.pre_live_sync_proof_fingerprint):
        if not isinstance(value, str) or _FINGERPRINT.fullmatch(value) is None:
            raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_PROOF_BINDING_INVALID")
    if binding.authorized_target_binding_fingerprint != binding.base_binding.active_configuration_fingerprint:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_TARGET_BINDING_MISMATCH")


def _binding_from_record(record: ValidationAuthorityRecord) -> ValidationAuthorityBinding:
    names = tuple(ValidationAuthorityBinding.__dataclass_fields__)
    return ValidationAuthorityBinding(**{name: getattr(record, name) for name in names})


def validate_validation_authority_record(record: ValidationAuthorityRecord) -> None:
    if not isinstance(record, ValidationAuthorityRecord) or record.authority_contract != VALIDATION_AUTHORITY_CONTRACT:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_CONTRACT_UNSUPPORTED")
    validate_validation_authority_binding(_binding_from_record(record))
    if _IDENTIFIER.fullmatch(record.issuance_identifier) is None or _REFERENCE.fullmatch(record.issuance_reference) is None:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_IDENTITY_INVALID")
    if record.issuance_reference != record.base_binding.issuance_reference:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_REFERENCE_MISMATCH")
    if record.issuance_state == "ISSUED":
        valid = record.consumption_state == "NOT_CONSUMED" and record.consumption_timestamp is None and record.invalidation_reason is None
    elif record.issuance_state == "CONSUMED":
        valid = record.consumption_state == "CONSUMED" and bool(record.consumption_timestamp) and record.invalidation_reason is None
    elif record.issuance_state == "INVALIDATED":
        valid = record.consumption_state == "NOT_CONSUMED" and record.consumption_timestamp is None and bool(record.invalidation_reason)
    else:
        valid = False
    if not valid or not record.issuance_timestamp:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_LIFECYCLE_INVALID")


def _record_from_mapping(value: Mapping[str, Any]) -> ValidationAuthorityRecord:
    expected = set(ValidationAuthorityRecord.__dataclass_fields__)
    if not isinstance(value, Mapping) or set(value) != expected or value.get("authority_contract") != VALIDATION_AUTHORITY_CONTRACT:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_MALFORMED")
    base_value = value.get("base_binding")
    if not isinstance(base_value, Mapping) or set(base_value) != set(AuthorityBinding.__dataclass_fields__):
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_MALFORMED")
    try:
        base = AuthorityBinding(**{**base_value, "approved_routes": tuple(base_value["approved_routes"])})
        record = ValidationAuthorityRecord(**{**value, "base_binding": base})
    except (KeyError, TypeError, ValueError):
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_MALFORMED") from None
    validate_validation_authority_record(record)
    return record


class ValidationAuthorityStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.lock_path = self.path.with_suffix(self.path.suffix + ".lock")

    def _lock(self) -> int:
        if not self.path.parent.is_dir():
            raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_PERSISTENCE_FAILED")
        try:
            return os.open(self.lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_BUSY") from None
        except OSError:
            raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_PERSISTENCE_FAILED") from None

    def _locked(self, operation: Callable[[], ValidationAuthorityRecord]) -> ValidationAuthorityRecord:
        descriptor = self._lock()
        os.close(descriptor)
        try:
            return operation()
        finally:
            try:
                self.lock_path.unlink()
            except OSError:
                raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_PERSISTENCE_FAILED") from None

    def _write(self, record: ValidationAuthorityRecord) -> None:
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        payload = json.dumps(record.as_dict(), sort_keys=True, separators=(",", ":")) + "\n"
        try:
            with temporary.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(payload); stream.flush(); os.fsync(stream.fileno())
            os.replace(temporary, self.path)
        except OSError:
            temporary.unlink(missing_ok=True)
            raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_PERSISTENCE_FAILED") from None

    def _load(self) -> ValidationAuthorityRecord:
        try:
            raw = self.path.read_text(encoding="utf-8")
            value = json.loads(raw, object_pairs_hook=lambda pairs: _unique(pairs))
        except (OSError, UnicodeError, json.JSONDecodeError, ValueError):
            raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_MALFORMED") from None
        return _record_from_mapping(value)

    def issue(
        self, binding: ValidationAuthorityBinding, *, issuance_reference: str,
        identifier_factory: Callable[[], str] = lambda: str(uuid.uuid4()),
        clock: Callable[[], str] = lambda: datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    ) -> ValidationAuthorityRecord:
        validate_validation_authority_binding(binding)
        if issuance_reference != binding.base_binding.issuance_reference or _REFERENCE.fullmatch(issuance_reference or "") is None:
            raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_REFERENCE_MISMATCH")
        def operation() -> ValidationAuthorityRecord:
            if self.path.exists():
                raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_ALREADY_EXISTS")
            values = {name: getattr(binding, name) for name in ValidationAuthorityBinding.__dataclass_fields__}
            record = ValidationAuthorityRecord(
                authority_contract=VALIDATION_AUTHORITY_CONTRACT,
                issuance_identifier=identifier_factory(), issuance_reference=issuance_reference,
                issuance_state="ISSUED", issuance_timestamp=clock(), consumption_state="NOT_CONSUMED",
                consumption_timestamp=None, invalidation_reason=None, **values,
            )
            validate_validation_authority_record(record); self._write(record); return record
        return self._locked(operation)

    def load(self) -> ValidationAuthorityRecord:
        return self._locked(self._load)

    def validate(self, binding: ValidationAuthorityBinding) -> ValidationAuthorityRecord:
        validate_validation_authority_binding(binding)
        record = self.load()
        if _binding_from_record(record) != binding:
            raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_BINDING_MISMATCH")
        return record

    def consume(self, binding: ValidationAuthorityBinding, *, clock: Callable[[], str] = lambda: datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")) -> ValidationAuthorityRecord:
        validate_validation_authority_binding(binding)
        def operation() -> ValidationAuthorityRecord:
            record = self._load()
            if _binding_from_record(record) != binding:
                raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_BINDING_MISMATCH")
            if record.issuance_state != "ISSUED":
                raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_NOT_ISSUED")
            updated = replace(record, issuance_state="CONSUMED", consumption_state="CONSUMED", consumption_timestamp=clock())
            validate_validation_authority_record(updated); self._write(updated); return updated
        return self._locked(operation)

    def invalidate(self, binding: ValidationAuthorityBinding, reason: str) -> ValidationAuthorityRecord:
        validate_validation_authority_binding(binding)
        if not isinstance(reason, str) or not reason or len(reason) > 128 or re.fullmatch(r"[A-Z0-9_]+", reason) is None:
            raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_INVALIDATION_REASON_INVALID")
        def operation() -> ValidationAuthorityRecord:
            record = self._load()
            if _binding_from_record(record) != binding:
                raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_BINDING_MISMATCH")
            if record.issuance_state != "ISSUED":
                raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_NOT_ISSUED")
            updated = replace(record, issuance_state="INVALIDATED", invalidation_reason=reason)
            validate_validation_authority_record(updated); self._write(updated); return updated
        return self._locked(operation)


def _unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate key")
        result[key] = value
    return result


def as_validation_runtime_authority(record: ValidationAuthorityRecord) -> ValidationRuntimeAuthority:
    validate_validation_authority_record(record)
    if record.issuance_state != "CONSUMED":
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_NOT_CONSUMED")
    # Reuse the frozen runtime authority conversion only after creating a
    # temporary 0.2-shaped record is deliberately avoided: 0.3 never falls
    # back to 0.2 parsing or serialization.
    from .private_alpha_live_interaction_runtime import PASS4E_AUTHORITY_CONTRACT, LiveExecutionAuthority
    base = record.base_binding
    runtime = LiveExecutionAuthority(
        PASS4E_AUTHORITY_CONTRACT, "PASS4E_AUTHORIZED", base.preflight_fingerprint,
        base.source_tree_fingerprint, base.active_configuration_fingerprint,
        base.live_configuration_fingerprint, base.snapshot_fingerprint,
        base.maximum_gateway_sessions, base.maximum_accepted_commands,
        base.maximum_duration_seconds, base.interactions_endpoint_absence_confirmed,
        base.session_artifact_binding_fingerprint,
    )
    names = tuple(ValidationRuntimeAuthority.__dataclass_fields__)[2:]
    return ValidationRuntimeAuthority(runtime, VALIDATION_AUTHORITY_CONTRACT, **{name: getattr(record, name) for name in names})


def reject_legacy_authority_for_validation(record: Any) -> None:
    if not isinstance(record, ValidationAuthorityRecord):
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_0_3_REQUIRED")


__all__ = [
    "AUTHORIZED_SYNC_SCOPE", "COMMAND_SYNC_POLICY_VERSION", "VALIDATION_AUTHORITY_CONTRACT",
    "ValidationAuthorityBinding", "ValidationAuthorityError", "ValidationAuthorityRecord",
    "ValidationAuthorityStore", "ValidationRuntimeAuthority", "as_validation_runtime_authority",
    "authority_contract_fingerprint", "build_validation_authority_binding", "expected_validation_bindings",
    "reject_legacy_authority_for_validation", "validate_validation_authority_binding",
    "validate_validation_authority_record",
]
