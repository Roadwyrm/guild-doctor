"""Matching-command rollback plan only; no unsync request is performed locally."""
from .discord_sync_rollback import ROLLBACK_CONFIRMATION_PHRASE,rollback_authorized
DISPOSABLE_ROLLBACK_CONTRACT="GUILD-DOCTOR-DISPOSABLE-ROLLBACK-0.1"
def rollback_plan(guild_id:str|None,confirmation:str|None)->dict:return {"authorized":rollback_authorized(confirmation,guild_id),"confirmation_phrase":ROLLBACK_CONFIRMATION_PHRASE,"matching_commands_only":True,"unrelated_commands_preserved":True,"request_count":0,"write_count":0}
def execute_rollback(*,transport,guild_id:str,confirmation:str,command_names:set[str])->dict:
 plan=rollback_plan(guild_id,confirmation)
 if not plan['authorized']:return {**plan,'status':'FAIL'}
 removed=transport.remove_matching_guild_commands(guild_id,command_names)
 return {**plan,'status':'PASS','removed_count':removed}
