"""Pure deterministic Stage 5 Pass 3 role comparison engine."""

from __future__ import annotations

import hashlib
from collections import Counter
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .canonical import canonical_json
from .capability_registry import KNOWN_PERMISSION_FLAGS
from .doctor_engine import DoctorExecution, execute_doctor_query
from .doctor_role_comparison_query import (
    ACTION,
    CAPABILITY,
    CAPABILITY_SET,
    COMPARE_ACTION_AUTHORITY,
    COMPARE_CAPABILITY_SET,
    COMPARE_CONTEXT_CAPABILITY,
    COMPARE_RAW_ROLE_PERMISSIONS,
    ENUMERATE_ROLE_DIFFERENCES,
    RAW_PERMISSION,
    RoleComparisonQuery,
    RoleComparisonSubject,
    validate_role_comparison_query,
)
from .doctor_role_projection import (
    ACTION_PROJECTION_DISCLAIMER,
    PROJECTION_DISCLAIMER,
    RoleProjection,
    build_projection_doctor_query,
    build_role_projection,
)
from .doctor_source_location import SourceLocationCase, SourceLocationExecution, execute_source_location_query
from .doctor_source_query import (
    EXPLAIN_SOURCE_OBJECT,
    FULL_PROVENANCE,
    SOURCE_LOCATION_QUERY_CONTRACT_VERSION,
    STAGE5_PASS3_CONTRACT_VERSION,
    STAGE5_PASS3_GOLDEN_VERSION,
    STAGE5_PASS3_RULES_VERSION,
    SourceLocationQuery,
)


class RoleComparisonError(RuntimeError):
    """Raised only by strict role-comparison execution."""


def _as_dict(value: Any) -> Any:
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _as_dict(method())
    if isinstance(value, Mapping):
        return {str(key): _as_dict(child) for key, child in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [_as_dict(child) for child in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _freeze(value: Any) -> Any:
    if callable(getattr(value, "as_dict", None)):
        # Frozen diagnostic cases are retained as authoritative objects.  Do
        # not deepcopy them: their nested mapping proxies are intentionally
        # not pickleable, and the object itself is already immutable.
        return value
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(child) for key, child in sorted(value.items(), key=lambda item: str(item[0]))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(child) for child in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(child) for child in sorted(value, key=str))
    return deepcopy(value)


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _thaw(child) for key, child in value.items()}
    if isinstance(value, (tuple, list)):
        return [_thaw(child) for child in value]
    return deepcopy(value)


def _hash(value: Any) -> str:
    return hashlib.sha256(canonical_json(_as_dict(value)).encode("utf-8")).hexdigest()


def _int(value: Any) -> int | None:
    try:
        if isinstance(value, bool) or value is None:
            return None
        return int(str(value), 0) if isinstance(value, str) and str(value).lower().startswith("0x") else int(value)
    except (TypeError, ValueError):
        return None


def _raw_flag_names(value: int | None) -> tuple[str, ...]:
    if value is None:
        return ()
    return tuple(flag.name for flag in KNOWN_PERMISSION_FLAGS if value & flag.mask)


def _role_records(projection: RoleProjection) -> tuple[Mapping[str, Any], ...]:
    return tuple(_thaw(role) for role in projection.resolved_role_records)


def _raw_comparison(query: RoleComparisonQuery, projections: Sequence[RoleProjection]) -> Mapping[str, Any]:
    grants_by_subject = {
        projection.comparison_subject_id: set(_raw_flag_names(_int(projection.raw_permission_decimal)))
        for projection in projections
    }
    all_grants = set.intersection(*(value for value in grants_by_subject.values())) if grants_by_subject else set()
    some_grants = set.union(*(value for value in grants_by_subject.values())) if grants_by_subject else set()
    unique = {subject: sorted(grants - (some_grants - grants)) for subject, grants in grants_by_subject.items()}
    requested = {
        projection.comparison_subject_id: (
            query.target_key in grants_by_subject.get(projection.comparison_subject_id, set())
            if projection.raw_permission_decimal is not None
            else None
        )
        for projection in projections
    }
    return {
        "raw_role_permissions_are_not_effective_member_permissions": True,
        "common_grants": sorted(all_grants),
        "some_subject_grants": sorted(some_grants),
        "unique_grants_by_subject": unique,
        "requested_permission": query.target_key,
        "requested_permission_granted_by_subject": requested,
        "raw_values_by_subject": {
            projection.comparison_subject_id: {
                "decimal": projection.raw_permission_decimal,
                "hex": projection.raw_permission_hex,
                "known_decimal": projection.known_permission_bits_decimal,
                "known_hex": projection.known_permission_bits_hex,
                "unknown_decimal": projection.unknown_permission_bits_decimal,
                "unknown_hex": projection.unknown_permission_bits_hex,
            }
            for projection in projections
        },
        "administrator_present_by_subject": {
            projection.comparison_subject_id: "ADMINISTRATOR" in grants_by_subject.get(projection.comparison_subject_id, set())
            if projection.raw_permission_decimal is not None
            else None
            for projection in projections
        },
        "managed_role_ids_by_subject": {projection.comparison_subject_id: list(projection.managed_role_ids) for projection in projections},
        "highest_role_by_subject": {
            projection.comparison_subject_id: {"role_id": projection.highest_role_id, "position": projection.highest_role_position}
            for projection in projections
        },
        "role_metadata_by_subject": {
            projection.comparison_subject_id: [
                {
                    "role_id": record.get("id"),
                    "managed": record.get("managed"),
                    "position": record.get("position"),
                    "is_everyone": record.get("is_everyone"),
                }
                for record in _role_records(projection)
            ]
            for projection in projections
        },
    }


def _source_summary(source_case: SourceLocationCase | None) -> Mapping[str, Any]:
    if source_case is None:
        return {"controlling_sources": [], "material_sources": [], "source_fingerprint": None}
    return {
        "controlling_sources": [
            {"source_type": item.source_type, "effect_classification": item.effect_classification, "object_id": item.object_id}
            for item in source_case.controlling_sources
        ],
        "material_sources": [
            {"source_type": item.source_type, "effect_classification": item.effect_classification, "object_id": item.object_id}
            for item in source_case.material_sources
        ],
        "source_fingerprint": source_case.fingerprints.get("source_records_fingerprint") if isinstance(source_case.fingerprints, Mapping) else None,
    }


def _projection_result(
    projection: RoleProjection,
    target_key: str,
    doctor_execution: DoctorExecution,
    source_execution: SourceLocationExecution,
) -> Mapping[str, Any]:
    case = doctor_execution.case
    actual = _as_dict(case.actual_result)
    action = doctor_execution.stage_results.get("PASS6")
    action_dict = _as_dict(action)
    return {
        "comparison_subject_id": projection.comparison_subject_id,
        "synthetic_projection_id": projection.synthetic_projection_id,
        "role_ids": list(projection.explicit_role_ids),
        "target_key": target_key,
        "result_state": actual.get("result_state", "UNKNOWN"),
        "result_family": actual.get("result_family"),
        "primary_reason": _as_dict(case.diagnostic_answer).get("primary_reason"),
        "projection_complete": projection.projection_complete,
        "projection_assumptions": _thaw(projection.projection_assumptions),
        "projection_limitations": list(projection.limitations),
        "authoritative_doctor_case": case,
        "source_location_case": source_execution.case,
        "source_summary": _source_summary(source_execution.case),
        "unknown_permission_bits": projection.unknown_permission_bits_decimal,
        "pre_execution_model": bool(target_key and action_dict) if case.target_kind == ACTION else False,
        "execution_attempted": action_dict.get("execution_attempted", False) if action_dict else False,
        "execution_guarantee": action_dict.get("execution_guarantee", False) if action_dict else False,
    }


def _compare_results(results: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    states = {str(result.get("comparison_subject_id")): result.get("result_state", "UNKNOWN") for result in results}
    reasons = {str(result.get("comparison_subject_id")): result.get("primary_reason") for result in results}
    sources = {str(result.get("comparison_subject_id")): result.get("source_summary", {}).get("source_fingerprint") for result in results}
    values = set(states.values())
    reason_values = set(reasons.values())
    source_values = set(sources.values())
    return {
        "common_result": next(iter(values)) if len(values) == 1 and values else None,
        "different_results": len(values) > 1,
        "result_states_by_subject": states,
        "different_reasons": len(reason_values) > 1,
        "primary_reasons_by_subject": reasons,
        "different_sources": len(source_values) > 1,
        "source_fingerprints_by_subject": sources,
        "unknown_present": "UNKNOWN" in values,
        "not_comparable": any(result.get("result_state") in {"INVALID", "NOT_COMPARABLE"} for result in results),
        "role_ranking": False,
        "recommendations": False,
    }


def _capability_matrix(results_by_key: Mapping[str, Sequence[Mapping[str, Any]]]) -> Mapping[str, Any]:
    rows: dict[str, dict[str, str]] = {}
    for key, results in results_by_key.items():
        for result in results:
            rows.setdefault(str(result["comparison_subject_id"]), {})[key] = str(result.get("result_state", "UNKNOWN"))
    ordered_rows = {subject: {key: rows[subject][key] for key in sorted(rows[subject])} for subject in sorted(rows)}
    return {
        "capability_keys": sorted(results_by_key),
        "rows_by_subject": ordered_rows,
        "unknown_remains_unknown": all(value != "ALLOWED" for row in ordered_rows.values() for value in row.values()) if ordered_rows else True,
        "matrix_is_deterministic": True,
        "no_silent_truncation": True,
    }


def _stable_query_identity(query: RoleComparisonQuery) -> Mapping[str, Any]:
    """Exclude labels and original input indexes from result fingerprints."""

    return {
        "query_id": query.query_id,
        "comparison_intent": query.comparison_intent,
        "guild_id": query.guild_id,
        "compared_subjects": [
            {"comparison_subject_id": subject.comparison_subject_id, "role_ids": list(subject.role_ids)}
            for subject in query.compared_subjects
        ],
        "target_kind": query.target_kind,
        "target_key": query.target_key,
        "capability_keys": list(query.capability_keys),
        "context_type": query.context_type,
        "context_id": query.context_id,
        "parent_id": query.parent_id,
        "thread_id": query.thread_id,
        "thread_type": query.thread_type,
        "target_type": query.target_type,
        "target_id": query.target_id,
        "projection_assumptions": _thaw(query.projection_assumptions),
    }


def _stable_subject_result(result: Mapping[str, Any]) -> Mapping[str, Any]:
    doctor_case = result.get("authoritative_doctor_case")
    source_case = result.get("source_location_case")
    return {
        key: _as_dict(value)
        for key, value in result.items()
        if key not in {"authoritative_doctor_case", "source_location_case"}
    } | {
        "authoritative_doctor_case_fingerprint": getattr(doctor_case, "case_fingerprint", None),
        "source_location_case_fingerprint": getattr(source_case, "case_fingerprint", None),
    }


@dataclass(frozen=True, slots=True)
class RoleComparisonCase:
    stage5_pass3_contract_version: str
    role_comparison_query_contract_version: str
    role_comparison_case_contract_version: str
    stage5_pass3_rules_version: str
    stage5_pass3_golden_version: str
    query_identity: Mapping[str, Any]
    comparison_intent: str
    target_kind: str
    target_key: str | None
    context: Mapping[str, Any]
    projection_assumptions: Mapping[str, Any]
    compared_subjects: tuple[Mapping[str, Any], ...]
    projections: tuple[Mapping[str, Any], ...]
    subject_results: tuple[Mapping[str, Any], ...]
    raw_permission_comparison: Mapping[str, Any]
    capability_matrix: Mapping[str, Any]
    action_comparison: Mapping[str, Any]
    comparison: Mapping[str, Any]
    projection_disclaimer: str
    action_disclaimer: str | None
    fingerprints: Mapping[str, str]
    provenance: Mapping[str, Any]
    immutability_status: Mapping[str, Any]
    status: str
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    case_fingerprint: str = ""

    def __post_init__(self) -> None:
        for field_name in ("query_identity", "context", "projection_assumptions", "raw_permission_comparison", "capability_matrix", "action_comparison", "comparison", "fingerprints", "provenance", "immutability_status"):
            object.__setattr__(self, field_name, _freeze(getattr(self, field_name)))
        object.__setattr__(self, "compared_subjects", tuple(_freeze(item) for item in self.compared_subjects))
        object.__setattr__(self, "projections", tuple(_freeze(item) for item in self.projections))
        object.__setattr__(self, "subject_results", tuple(_freeze(item) for item in self.subject_results))

    def as_dict(self) -> dict[str, Any]:
        return {
            "stage5_pass3_contract_version": self.stage5_pass3_contract_version,
            "role_comparison_query_contract_version": self.role_comparison_query_contract_version,
            "role_comparison_case_contract_version": self.role_comparison_case_contract_version,
            "stage5_pass3_rules_version": self.stage5_pass3_rules_version,
            "stage5_pass3_golden_version": self.stage5_pass3_golden_version,
            "query_identity": _thaw(self.query_identity),
            "comparison_intent": self.comparison_intent,
            "target_kind": self.target_kind,
            "target_key": self.target_key,
            "context": _thaw(self.context),
            "projection_assumptions": _thaw(self.projection_assumptions),
            "compared_subjects": _thaw(self.compared_subjects),
            "projections": _thaw(self.projections),
            "subject_results": [
                {
                    **{
                        key: _as_dict(value)
                        for key, value in result.items()
                        if key not in {"authoritative_doctor_case", "source_location_case"}
                    },
                    "authoritative_doctor_case": result["authoritative_doctor_case"].as_dict() if hasattr(result.get("authoritative_doctor_case"), "as_dict") else result.get("authoritative_doctor_case"),
                    "source_location_case": result["source_location_case"].as_dict() if hasattr(result.get("source_location_case"), "as_dict") else result.get("source_location_case"),
                }
                for result in self.subject_results
            ],
            "raw_permission_comparison": _thaw(self.raw_permission_comparison),
            "capability_matrix": _thaw(self.capability_matrix),
            "action_comparison": _thaw(self.action_comparison),
            "comparison": _thaw(self.comparison),
            "projection_disclaimer": self.projection_disclaimer,
            "action_disclaimer": self.action_disclaimer,
            "fingerprints": _thaw(self.fingerprints),
            "provenance": _thaw(self.provenance),
            "immutability_status": _thaw(self.immutability_status),
            "status": self.status,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "case_fingerprint": self.case_fingerprint,
        }


@dataclass(frozen=True, slots=True)
class RoleComparisonExecution:
    case: RoleComparisonCase
    projections: tuple[RoleProjection, ...]
    doctor_executions: tuple[DoctorExecution, ...]
    source_executions: tuple[SourceLocationExecution, ...]

    @property
    def passed(self) -> bool:
        return self.case.status == "PASS"

    def as_dict(self) -> dict[str, Any]:
        return {
            "case": self.case.as_dict(),
            "projections": [projection.as_dict() for projection in self.projections],
            "doctor_executions": [execution.as_dict() for execution in self.doctor_executions],
            "source_executions": [execution.as_dict() for execution in self.source_executions],
        }


def _invalid_case(query: RoleComparisonQuery, errors: tuple[str, ...]) -> RoleComparisonCase:
    return RoleComparisonCase(
        STAGE5_PASS3_CONTRACT_VERSION,
        query.role_comparison_query_contract_version,
        "GUILD-DOCTOR-ROLE-COMPARISON-CASE-0.1",
        STAGE5_PASS3_RULES_VERSION,
        STAGE5_PASS3_GOLDEN_VERSION,
        {"query_id": query.query_id},
        query.comparison_intent,
        query.target_kind,
        query.target_key,
        {"context_type": query.context_type, "context_id": query.context_id},
        _thaw(query.projection_assumptions),
        tuple(subject.as_dict() for subject in query.compared_subjects),
        (),
        (),
        {},
        {},
        {},
        {"different_results": False, "not_comparable": True, "role_ranking": False, "recommendations": False},
        PROJECTION_DISCLAIMER,
        ACTION_PROJECTION_DISCLAIMER if query.target_kind == ACTION else None,
        {},
        {"validation_only": True},
        {"snapshot_unchanged": True, "no_direct_stage3_invocation": True, "no_direct_stage4_invocation": True},
        "INVALID",
        errors,
        (),
        "",
    )


def execute_role_comparison_query(query: RoleComparisonQuery | Mapping[str, Any], *, strict: bool = False) -> RoleComparisonExecution:
    try:
        parsed = query if isinstance(query, RoleComparisonQuery) else RoleComparisonQuery.from_mapping(query)
    except (TypeError, ValueError) as exc:
        if strict:
            raise RoleComparisonError(str(exc))
        fallback = RoleComparisonQuery.from_mapping({"query_id": "invalid-role", "comparison_intent": COMPARE_RAW_ROLE_PERMISSIONS, "guild_id": "1", "compared_subjects": [{"comparison_subject_id": "a", "role_ids": ["1"]}, {"comparison_subject_id": "b", "role_ids": ["2"]}], "target_kind": RAW_PERMISSION, "target_key": "VIEW_CHANNEL", "snapshot": {"guild": {"id": "1"}, "roles": []}})
        return RoleComparisonExecution(_invalid_case(fallback, (f"ROLE_QUERY_CONSTRUCTION:{exc}",)), (), (), ())
    violations = validate_role_comparison_query(parsed)
    if violations:
        if strict:
            raise RoleComparisonError("; ".join(violations))
        return RoleComparisonExecution(_invalid_case(parsed, violations), (), (), ())

    projections = tuple(build_role_projection(parsed, subject) for subject in parsed.compared_subjects)
    doctor_executions: list[DoctorExecution] = []
    source_executions: list[SourceLocationExecution] = []
    subject_results: list[Mapping[str, Any]] = []
    results_by_key: dict[str, list[Mapping[str, Any]]] = {}
    raw_comparison = _raw_comparison(parsed, projections) if parsed.target_kind == RAW_PERMISSION else {}
    if parsed.target_kind in {CAPABILITY, ACTION}:
        keys = (parsed.target_key or "",)
    elif parsed.target_kind == CAPABILITY_SET:
        keys = parsed.capability_keys
    else:
        keys = ()
    for projection in projections:
        for target_key in keys:
            child_query = build_projection_doctor_query(parsed, projection, target_kind=CAPABILITY if parsed.target_kind == CAPABILITY_SET else parsed.target_kind, target_key=target_key)
            doctor_execution = execute_doctor_query(child_query, strict=strict)
            source_query = SourceLocationQuery(
                query_id=f"{parsed.query_id}:source:{projection.comparison_subject_id}:{target_key}",
                source_intent=EXPLAIN_SOURCE_OBJECT,
                doctor_query=child_query,
                source_detail_level=FULL_PROVENANCE,
                explanation_mode=parsed.explanation_mode or "SIMPLE",
                presentation_profile=parsed.presentation_profile or "SIMPLE_CARD",
                disclosure_policy=parsed.disclosure_policy or "SAFE_DEFAULT",
                display_safe_labels={"subject": projection.synthetic_projection_id},
            )
            source_execution = execute_source_location_query(source_query, strict=strict, doctor_execution=doctor_execution)
            doctor_executions.append(doctor_execution)
            source_executions.append(source_execution)
            result = _projection_result(projection, target_key, doctor_execution, source_execution)
            subject_results.append(result)
            results_by_key.setdefault(target_key, []).append(result)

    comparison = _compare_results(subject_results) if subject_results else {"role_ranking": False, "recommendations": False, "different_results": False, "not_comparable": False}
    capability_matrix = _capability_matrix(results_by_key) if parsed.target_kind == CAPABILITY_SET else {}
    action_results = [result for result in subject_results if result.get("pre_execution_model")]
    action_comparison = {
        "pre_execution_model": parsed.target_kind == ACTION,
        "execution_attempted": any(result.get("execution_attempted") for result in action_results),
        "execution_guarantee": any(result.get("execution_guarantee") for result in action_results),
        "result_states_by_subject": {str(result["comparison_subject_id"]): result.get("result_state") for result in action_results},
        "fixed_target": {"target_type": parsed.target_type, "target_id": parsed.target_id},
        "no_endpoint_success_claim": True,
    }
    all_source_fingerprints = [result.get("source_summary", {}).get("source_fingerprint") for result in subject_results]
    fingerprints = {"comparison_fingerprint": _hash({"query": _stable_query_identity(parsed), "results": [_stable_subject_result(result) for result in subject_results]}), "projection_fingerprint": _hash([projection.as_dict() for projection in projections]), "source_fingerprints": _hash(all_source_fingerprints)}
    provenance = {
        "source_stage5_pass1_contract": parsed.expected_stage5_pass1_contract,
        "source_location_query_contract": SOURCE_LOCATION_QUERY_CONTRACT_VERSION,
        "evidence_classifications": list(parsed.evidence_classifications),
        "verification_statuses": list(parsed.verification_statuses),
        "source_references": list(parsed.source_references),
        "projection_subject_count": len(projections),
        "doctor_query_count": len(doctor_executions),
        "source_location_case_count": len(source_executions),
    }
    case = RoleComparisonCase(
        STAGE5_PASS3_CONTRACT_VERSION,
        parsed.role_comparison_query_contract_version,
        "GUILD-DOCTOR-ROLE-COMPARISON-CASE-0.1",
        STAGE5_PASS3_RULES_VERSION,
        STAGE5_PASS3_GOLDEN_VERSION,
        {"query_id": parsed.query_id, "guild_id": parsed.guild_id, "target_key": parsed.target_key},
        parsed.comparison_intent,
        parsed.target_kind,
        parsed.target_key,
        {"context_type": parsed.context_type, "context_id": parsed.context_id, "parent_id": parsed.parent_id, "thread_id": parsed.thread_id, "target_type": parsed.target_type, "target_id": parsed.target_id},
        _thaw(parsed.projection_assumptions),
        tuple(subject.as_dict() for subject in parsed.compared_subjects),
        tuple(projection.as_dict() for projection in projections),
        tuple(subject_results),
        raw_comparison,
        capability_matrix,
        action_comparison,
        comparison,
        PROJECTION_DISCLAIMER,
        ACTION_PROJECTION_DISCLAIMER if parsed.target_kind == ACTION else None,
        fingerprints,
        provenance,
        {"snapshot_unchanged": True, "roles_unchanged": True, "doctor_cases_unchanged": all(item.case.integrity.get("stage3_results_unchanged", True) for item in doctor_executions), "source_cases_unchanged": all(item.case.immutability_status.get("doctor_case_unchanged", True) for item in source_executions), "registries_unchanged": True, "no_direct_stage3_invocation": True, "no_direct_stage4_invocation": True, "no_member_enumeration": True, "no_recommendations": True, "no_role_ranking": True},
        "PASS",
        (),
        (),
        "",
    )
    payload = {
        "query_identity": case.query_identity,
        "comparison_intent": case.comparison_intent,
        "target_kind": case.target_kind,
        "target_key": case.target_key,
        "projections": case.projections,
        "subject_results": [_stable_subject_result(result) for result in subject_results],
        "raw_permission_comparison": case.raw_permission_comparison,
        "capability_matrix": case.capability_matrix,
        "action_comparison": case.action_comparison,
        "comparison": case.comparison,
    }
    values = {field: getattr(case, field) for field in case.__dataclass_fields__}
    values["case_fingerprint"] = _hash(payload)
    final_case = RoleComparisonCase(**values)
    return RoleComparisonExecution(final_case, projections, tuple(doctor_executions), tuple(source_executions))


compare_roles = execute_role_comparison_query
run_role_comparison = execute_role_comparison_query
evaluate_role_comparison = execute_role_comparison_query


__all__ = [
    "RoleComparisonCase",
    "RoleComparisonError",
    "RoleComparisonExecution",
    "compare_roles",
    "evaluate_role_comparison",
    "execute_role_comparison_query",
    "run_role_comparison",
]
