"""Canonical JSON and snapshot fingerprints."""

from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from typing import Any


def canonical_json(data: dict[str, Any]) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_hex(data: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_json(data).encode("utf-8")).hexdigest()


def exact_fingerprint(snapshot_dict: dict[str, Any]) -> str:
    data = deepcopy(snapshot_dict)
    data["snapshot_fingerprint_sha256"] = None
    data["structural_fingerprint_sha256"] = None
    return sha256_hex(data)


def structural_fingerprint(snapshot_dict: dict[str, Any]) -> str:
    data = deepcopy(snapshot_dict)
    for key in (
        "snapshot_id",
        "snapshot_fingerprint_sha256",
        "structural_fingerprint_sha256",
        "started_at",
        "completed_at",
    ):
        data.pop(key, None)

    # Remove volatile acquisition timing and payload hashes while retaining health outcomes.
    for health in data.get("collections", {}).values():
        health.pop("started_at", None)
        health.pop("completed_at", None)
    for entity_name in ("guild",):
        entity = data.get(entity_name)
        if isinstance(entity, dict):
            entity.pop("source_observed_at", None)
            entity.pop("source_payload_hash", None)
    for entity_name in ("roles", "channels", "threads", "members", "thread_memberships"):
        entities = data.get(entity_name)
        if isinstance(entities, dict):
            for entity in entities.values():
                if isinstance(entity, dict):
                    entity.pop("source_observed_at", None)
                    entity.pop("source_payload_hash", None)
                    # Source ordering is retained as evidence but is not part of
                    # permission-relevant structural identity.
                    for overwrite in entity.get("permission_overwrites", []):
                        if isinstance(overwrite, dict):
                            overwrite.pop("source_index", None)

    return sha256_hex(data)
