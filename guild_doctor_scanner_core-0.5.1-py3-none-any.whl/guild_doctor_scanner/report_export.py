"""Deterministic local export for an already assembled Guild Doctor report."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib, os
from .audit_contract import scan_report_private
from .canonical import canonical_json
from .report_assembly import GuildDoctorReport, REPORT_CONTRACT

LOCAL_EXPORT_CONTRACT="GUILD-DOCTOR-STAGE7-PASS4-LOCAL-EXPORT-0.1"
JSON_EXPORT_CONTRACT="GUILD-DOCTOR-REPORT-JSON-EXPORT-0.1"; MARKDOWN_EXPORT_CONTRACT="GUILD-DOCTOR-REPORT-MARKDOWN-EXPORT-0.1"
class ReportExportError(ValueError): pass
@dataclass(frozen=True)
class PreparedReportExport:
 format:str; content:bytes; content_fingerprint:str; source_report_fingerprint:str; export_contract:str=LOCAL_EXPORT_CONTRACT
def _validate_prepared_export(export:PreparedReportExport)->None:
 if not isinstance(export,PreparedReportExport) or export.format not in {"json","markdown"}: raise ReportExportError("EXPORT_FORMAT_UNSUPPORTED")
 if hashlib.sha256(export.content).hexdigest()!=export.content_fingerprint: raise ReportExportError("EXPORT_FINGERPRINT_MISMATCH")
 try: text=export.content.decode("utf-8")
 except (AttributeError,UnicodeDecodeError): raise ReportExportError("EXPORT_PRIVACY_FAILED") from None
 if scan_report_private(text,"report_export.serialized"): raise ReportExportError("EXPORT_PRIVACY_FAILED")
def prepare_report_export(report:GuildDoctorReport,format:str)->PreparedReportExport:
 if not isinstance(report,GuildDoctorReport) or report.report_contract!=REPORT_CONTRACT: raise ReportExportError("EXPORT_REPORT_INVALID")
 if scan_report_private(report.as_dict(),"report_export.source"): raise ReportExportError("EXPORT_PRIVACY_FAILED")
 if format not in {"json","markdown"}: raise ReportExportError("EXPORT_FORMAT_UNSUPPORTED")
 if format=="json": text=canonical_json(report.as_dict())+"\n"
 else:
  text="# Guild Doctor Report\n\n"+"\n\n".join(f"## {s.section_id.replace('_',' ').title()}\n\nState: {s.state}\n\nItems: {s.total_item_count}" for s in report.sections)+"\n"
 if scan_report_private(text,"report_export.serialized"): raise ReportExportError("EXPORT_PRIVACY_FAILED")
 data=text.encode("utf-8"); result=PreparedReportExport(format,data,hashlib.sha256(data).hexdigest(),report.report_fingerprint); _validate_prepared_export(result); return result
def write_report_export(export:PreparedReportExport,path:Path,*,overwrite:bool=False)->Path:
 _validate_prepared_export(export)
 path=Path(path)
 if not path.is_absolute() or not path.parent.is_dir(): raise ReportExportError("EXPORT_PATH_INVALID")
 if path.exists() and not overwrite: raise ReportExportError("EXPORT_TARGET_EXISTS")
 temp=path.with_name(path.name+".tmp")
 try:
  temp.write_bytes(export.content); os.replace(temp,path)
 except OSError as exc:
  temp.unlink(missing_ok=True); raise ReportExportError("EXPORT_ATOMIC_WRITE_FAILED") from exc
 return path
