"""Read-only boundary for authoritative Stage 2 normalized snapshots.

This module deliberately accepts an explicit artifact path.  It never searches
for JSON files, consumes Discord payloads, or chooses a "newest" report.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .canonical import exact_fingerprint
from .constants import SCANNER_CONTRACT_VERSION, SNAPSHOT_SCHEMA_VERSION


NORMALIZED_SNAPSHOT_LOADER_CONTRACT = "GUILD-DOCTOR-STAGE6-NORMALIZED-SNAPSHOT-LOADER-0.1"
LOADER_OUTCOMES = (
    "SNAPSHOT_LOADED", "SNAPSHOT_NOT_FOUND", "SNAPSHOT_GUILD_MISMATCH",
    "SNAPSHOT_SCHEMA_MISMATCH", "SNAPSHOT_PROVENANCE_FAILED", "SNAPSHOT_CORRUPT",
    "SNAPSHOT_STALE", "SNAPSHOT_INCOMPLETE", "SNAPSHOT_INTERNAL_ERROR",
)


@dataclass(frozen=True)
class AuthorizedNormalizedSnapshot:
    outcome: str
    snapshot: Mapping[str, Any] | None = None
    source_path: Path | None = None
    roles_by_id: Mapping[str, Mapping[str, Any]] | None = None
    categories_by_id: Mapping[str, Mapping[str, Any]] | None = None
    channels_by_id: Mapping[str, Mapping[str, Any]] | None = None
    members_by_id: Mapping[str, Mapping[str, Any]] | None = None
    detail: str | None = None

    @property
    def loaded(self) -> bool:
        return self.outcome == "SNAPSHOT_LOADED"

    @property
    def snapshot_state(self) -> str:
        if self.outcome == "SNAPSHOT_STALE":
            return "STALE_COMPLETE"
        if self.outcome == "SNAPSHOT_INCOMPLETE":
            return "CURRENT_PARTIAL"
        if self.loaded:
            return "CURRENT_COMPLETE"
        return "MISSING"


def _records(value: Any, *, required: bool) -> dict[str, Mapping[str, Any]] | None:
    if value is None:
        return None if required else {}
    if not isinstance(value, Mapping):
        raise ValueError("COLLECTION_NOT_MAPPING")
    result: dict[str, Mapping[str, Any]] = {}
    for key, record in value.items():
        if not isinstance(record, Mapping) or str(record.get("id", "")) != str(key):
            raise ValueError("INDEX_INVALID")
        result[str(key)] = record
    return result


def load_authorized_normalized_snapshot(*, path: Path | None, guild_id: str) -> AuthorizedNormalizedSnapshot:
    """Load exactly one declared scanner artifact and validate its provenance."""
    if path is None or not path.is_file():
        return AuthorizedNormalizedSnapshot("SNAPSHOT_NOT_FOUND", source_path=path)
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(value, Mapping):
            return AuthorizedNormalizedSnapshot("SNAPSHOT_CORRUPT", source_path=path)
        if value.get("schema_version") != SNAPSHOT_SCHEMA_VERSION or value.get("scanner_contract_version") != SCANNER_CONTRACT_VERSION:
            return AuthorizedNormalizedSnapshot("SNAPSHOT_SCHEMA_MISMATCH", source_path=path)
        if str(value.get("guild_id", "")) != guild_id or str((value.get("guild") or {}).get("id", "")) != guild_id:
            return AuthorizedNormalizedSnapshot("SNAPSHOT_GUILD_MISMATCH", source_path=path)
        claimed = value.get("snapshot_fingerprint_sha256")
        if not isinstance(claimed, str) or claimed != exact_fingerprint(dict(value)):
            return AuthorizedNormalizedSnapshot("SNAPSHOT_PROVENANCE_FAILED", source_path=path)
        roles = _records(value.get("roles"), required=True)
        channels = _records(value.get("channels"), required=True)
        # ``null`` is a meaningful scanner result: member data was not retained.
        # Keep it distinct from an empty but complete member collection.
        members = None if value.get("members") is None else _records(value.get("members"), required=False)
        categories = {key: record for key, record in channels.items() if str(record.get("type_key")) == "CATEGORY"}
        ordinary_channels = {key: record for key, record in channels.items() if str(record.get("type_key")) != "CATEGORY"}
        structural = str(value.get("structural_completeness", ""))
        if structural != "COMPLETE":
            return AuthorizedNormalizedSnapshot("SNAPSHOT_INCOMPLETE", value, path, roles, categories, ordinary_channels, members, structural)
        return AuthorizedNormalizedSnapshot("SNAPSHOT_LOADED", value, path, roles, categories, ordinary_channels, members)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError, TypeError) as exc:
        return AuthorizedNormalizedSnapshot("SNAPSHOT_CORRUPT", source_path=path, detail=type(exc).__name__)
    except Exception:
        return AuthorizedNormalizedSnapshot("SNAPSHOT_INTERNAL_ERROR", source_path=path)
