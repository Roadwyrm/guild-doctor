"""Offline-only CLI for sanitized Stage 8 Pass 4B fixtures."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .private_alpha_offline_workflow import execute_offline_workflow, request_from_mapping


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate one sanitized Guild Doctor offline workflow fixture.")
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--fixture-root", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        value = json.loads(args.request.read_text(encoding="utf-8"))
        result = execute_offline_workflow(request_from_mapping(value), fixture_root=args.fixture_root)
        print(json.dumps(result.as_dict(), sort_keys=True, separators=(",", ":")), flush=True)
        return 0 if result.status == "PASS" else 2
    except (OSError, UnicodeError, json.JSONDecodeError, TypeError, ValueError):
        print('{"stable_error":"STAGE6_ENGINE_INTERNAL_ERROR","status":"FAILED_CLOSED"}', flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
