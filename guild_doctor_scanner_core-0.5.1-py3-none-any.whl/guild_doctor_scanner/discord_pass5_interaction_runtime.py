"""Bounded disposable-guild Gateway verification for frozen Pass 3 adapters.

This module never synchronizes commands and never resolves live objects into a
new permission query.  A command with no validated engine input fails closed
through the existing adapter before any hidden-object lookup.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import time
import uuid
from dataclasses import asdict
from pathlib import Path

from .discord_command_manifest import COMMAND_MANIFEST, manifest_fingerprint
from .discord_command_schema import compare_live_schema, expected_live_schema, normalize_live_commands, schema_fingerprint
from .discord_direct_interaction_adapter import EnvelopeAdapterResult, handle_direct_interaction
from .discord_interaction_request import InteractionRequest
from .discord_live_command_binding import LIVE_BINDINGS
from .discord_live_interaction_transport import ensure_ephemeral
from .discord_interaction_policy import acknowledgement_for
from .discord_live_runtime import DiscordPyTransport, build_provenance, validate_provenance
from .discord_normalized_snapshot_loader import load_authorized_normalized_snapshot
from .discord_exact_id_bridge import resolve_exact, selected_object_id
from .discord_frozen_engine_provider import produce_frozen_engine_result
from .discord_interaction_envelope import COMPARISON_RESULT, ERROR_RESULT, ErrorResultPayload, InteractionEnvelope
from .discord_response_renderer import render_envelope_adapter_result, render_plain_text
from .discord_secure_token import HiddenTokenProvider

INTERACTION_RUNTIME_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS5-INTERACTION-RUNTIME-0.1"
MARKER = "STAGE6_PASS5_DISPOSABLE_GUILD_ONLY"
TARGET_GUILD_ID = "1450145794224033804"
AUTHORIZED_SNAPSHOT_RELATIVE_PATH = Path("stage6-pass5-evidence") / "authorized_normalized_snapshot.json"


def _safe_id(value: object) -> str | None:
    if value is None:
        return None
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()[:12]


def _event(**values: object) -> dict:
    allowed = {"command_key", "interaction_outcome", "authorization_outcome", "acknowledgement_class", "visibility", "adapter_result_state", "stable_error_code", "response_completed", "page_count", "export_prepared", "no_action_marker", "no_write_marker", "source_chain_count", "uncertainty_count", "snapshot_warning_count", "population_completeness", "targeted_fetch_attempted"}
    return {key: values[key] for key in allowed if key in values}


def _capability_route_envelope_or_error(envelope: InteractionEnvelope, capability_key: object) -> InteractionEnvelope:
    """Keep a capability callback bound to the selected frozen target."""
    payload = envelope.comparison_result if envelope.response_kind == COMPARISON_RESULT else None
    if payload is None or payload.target_kind != "CAPABILITY" or payload.target_key != capability_key:
        return InteractionEnvelope(
            ERROR_RESULT,
            error_result=ErrorResultPayload(
                "STAGE6_COMPARISON_CONTRACT_MISMATCH",
                "Guild Doctor could not safely prepare this comparison.",
            ),
        )
    return envelope


class BoundedInteractionSession:
    """A tiny interaction bridge.  It has no permission or target resolution logic."""
    def __init__(self, *, guild_id: str, owner_member_id: str, engine_results: dict[str, dict] | None = None, snapshot_path: Path | None = None):
        self.guild_id = guild_id
        self.owner_member_id = owner_member_id
        self.engine_results = engine_results or {}
        self.snapshot_path = snapshot_path
        self.events: list[dict] = []
        self.responses = 0

    async def handle(self, interaction, **selected) -> None:
        command = getattr(getattr(interaction, "command", None), "name", None)
        actor_id = str(getattr(getattr(interaction, "user", None), "id", "")) or None
        actual_guild_id = str(getattr(interaction, "guild_id", "")) or None
        command_key = command if command in LIVE_BINDINGS else "unknown"
        snapshot = load_authorized_normalized_snapshot(path=self.snapshot_path, guild_id=self.guild_id)
        selection_kind = None
        selection = None
        if command_key in {"why-can", "why-cannot"}:
            selection_kind, selection = "MEMBER", selected.get("member")
        elif command_key == "explain-role":
            selection_kind, selection = "ROLE", selected.get("role")
        elif command_key == "explain-category":
            selection_kind, selection = "CATEGORY", selected.get("category")
        elif command_key in {"explain-channel", "find-setting", "who-can", "who-cannot", "who-unknown"}:
            selection_kind, selection = "CHANNEL", selected.get("channel")
        resolution = resolve_exact(snapshot, kind=selection_kind, selected=selection, guild_id=self.guild_id) if selection_kind else None
        if command_key.startswith("compare-role-"):
            first = resolve_exact(snapshot, kind="ROLE", selected=selected.get("first_role"), guild_id=self.guild_id)
            second = resolve_exact(snapshot, kind="ROLE", selected=selected.get("second_role"), guild_id=self.guild_id)
            resolution = first if first.outcome != "RESOLVED_EXACT" else second
            if first.outcome == second.outcome == "RESOLVED_EXACT" and first.object_id == second.object_id:
                resolution = type(first)("OBJECT_TYPE_MISMATCH", first.object_id)
        resolution_state = "RESOLVED" if resolution is None or resolution.outcome == "RESOLVED_EXACT" else resolution.outcome
        request = InteractionRequest(
            correlation_id=uuid.uuid4().hex,
            command_key=command_key,
            guild_context_present=actual_guild_id == self.guild_id,
            guild_id=actual_guild_id,
            actor_member_id=actor_id,
            owner_member_id=self.owner_member_id,
            input_resolution_state=resolution_state,
            snapshot_state=snapshot.snapshot_state,
            selected_member_id=selected_object_id(selected.get("member")),
            selected_role_id=selected_object_id(selected.get("role") or selected.get("first_role")),
            comparison_role_id=selected_object_id(selected.get("second_role")),
            selected_channel_id=selected_object_id(selected.get("channel")),
            selected_category_id=selected_object_id(selected.get("category")),
        )
        injected = self.engine_results.get(command_key)
        permission = selected.get("permission")
        permission = str(permission).upper() if permission is not None else None
        resolved_inputs={"resolution": resolution.outcome if resolution else "NONE","permission":permission,"capability":selected.get("capability"),"capability_keys":selected.get("capability_keys", ()),"action":selected.get("action"),"action_keys":selected.get("action_keys", ()),"first_role": first.record if command_key.startswith("compare-role-") else None,"second_role": second.record if command_key.startswith("compare-role-") else None}
        comparison_pre_engine_blocked = command_key.startswith("compare-role-") and (
            actual_guild_id != self.guild_id or resolution_state != "RESOLVED"
        )
        produced = None if injected is not None or comparison_pre_engine_blocked else produce_frozen_engine_result(command_key=command_key, normalized_snapshot=snapshot.snapshot or {}, resolved_inputs=resolved_inputs, interaction_context={"actor_member_id": actor_id,"correlation_id":request.correlation_id})
        if injected is not None:
            engine_result = injected
        elif produced and produced.envelope is not None:
            engine_result = (
                _capability_route_envelope_or_error(produced.envelope, selected.get("capability"))
                if command_key == "compare-role-capability"
                else produced.envelope
            )
        elif comparison_pre_engine_blocked:
            engine_result = {"stable_error": "STAGE6_COMPARISON_PAYLOAD_INVALID"}
        else:
            engine_result = {"stable_error": produced.stable_error} if produced and produced.stable_error else {}
        response = handle_direct_interaction(request, engine_result, requested_member_count=0)
        rendered = render_envelope_adapter_result(
            response, correlation_id=request.correlation_id, command_key=command_key,
            acknowledgement_class=acknowledgement_for(authorized=True, interaction_age_seconds=request.interaction_age_seconds),
        ) if isinstance(response, EnvelopeAdapterResult) else response
        ensure_ephemeral(rendered)
        text = render_plain_text(rendered)
        await interaction.response.send_message(text, ephemeral=True)
        self.responses += 1
        self.events.append(_event(
            command_key=command_key,
            interaction_outcome="RECEIVED",
            authorization_outcome="ALLOW" if actor_id == self.owner_member_id and actual_guild_id == self.guild_id else "DENY",
            acknowledgement_class=rendered.acknowledgement_class,
            visibility=rendered.visibility,
            adapter_result_state=rendered.result_state_label,
            stable_error_code=rendered.stable_errors[0] if rendered.stable_errors else None,
            response_completed=True,
            page_count=rendered.page_count,
            export_prepared=False,
            no_action_marker=True,
            no_write_marker=True,
            source_chain_count=len(rendered.source_chain_sections),
            uncertainty_count=len(rendered.material_uncertainties),
            snapshot_warning_count=len(rendered.snapshot_warnings),
            population_completeness=rendered.population_completeness,
            targeted_fetch_attempted=False,
        ))


async def execute_interaction_session(*, project_root: Path, guild_id: str, timeout_seconds: float = 120.0, token_provider=None, transport=None) -> dict:
    """Verify remote schema before Gateway, then run one bounded read-only session."""
    if guild_id != TARGET_GUILD_ID:
        return {"status": "FAIL", "stable_error": "PASS5_GUILD_SCOPE_INVALID", "token_prompted": False}
    provenance = build_provenance(project_root)
    errors = validate_provenance(provenance)
    if errors or manifest_fingerprint() != provenance.manifest_fingerprint or schema_fingerprint() != provenance.schema_fingerprint:
        return {"status": "FAIL", "stable_error": "PASS5_RUNTIME_PROVENANCE_FAILED", "errors": list(errors), "token_prompted": False}
    if tuple(LIVE_BINDINGS) != tuple(item.key for item in COMMAND_MANIFEST):
        return {"status": "FAIL", "stable_error": "PASS5_BINDING_SCHEMA_MISMATCH", "token_prompted": False}
    # Deliberately designated artifact only: no arbitrary report discovery.
    session = BoundedInteractionSession(guild_id=guild_id, owner_member_id="UNRESOLVED", snapshot_path=project_root / AUTHORIZED_SNAPSHOT_RELATIVE_PATH)
    transport = transport or DiscordPyTransport(interaction_handler=session.handle)
    token_provider = token_provider or HiddenTokenProvider()
    result = {"marker": MARKER, "contract": INTERACTION_RUNTIME_CONTRACT, "status": "FAIL", "gateway_opened": False, "synchronization_count": 0, "command_write_count": 0, "prohibited_mutation_count": 0, "request_count": 0, "token_redacted": True, "raw_payload_retained": False, "events": []}
    token = None
    try:
        await asyncio.wait_for(transport.async_open_client(), timeout_seconds)
        token = token_provider.get()
        await asyncio.wait_for(transport.async_authenticate_bot(token), timeout_seconds); result["request_count"] += 1
        commands = await asyncio.wait_for(transport.async_fetch_guild_commands(guild_id), timeout_seconds); result["request_count"] += 1
        schema = compare_live_schema(normalize_live_commands(commands), expected=expected_live_schema())
        if schema["state"] != "COMMANDS_PRESENT_EXACT":
            result.update(stable_error="PASS5_COMMANDS_NOT_PRESENT_EXACT", schema_state=schema["state"]); return result
        metadata = await asyncio.wait_for(transport.async_fetch_guild_metadata(guild_id), timeout_seconds); result["request_count"] += 1
        owner_id = str(metadata.get("owner_id", ""))
        if not owner_id:
            result.update(stable_error="PASS5_OWNER_UNRESOLVED"); return result
        session.owner_member_id = owner_id
        result.update(schema_state=schema["state"], owner_id_hash=_safe_id(owner_id), gateway_opened=True)
        try:
            await transport.async_connect_gateway(timeout_seconds)
        except asyncio.TimeoutError:
            result.update(stable_error="PASS5_INTERACTION_WINDOW_EXPIRED")
        else:
            result.update(status="PASS", stable_error=None)
    except Exception as exc:
        status = getattr(exc, "status", None)
        result.update(stable_error="PASS5_AUTHENTICATION_FAILED" if type(exc).__name__ == "LoginFailure" or status == 401 else "PASS5_INTERACTION_RUNTIME_FAILED", exception_category=type(exc).__name__)
    finally:
        token = None
        result["events"] = session.events
        result["interaction_response_count"] = session.responses
        try:
            await transport.async_close_client(); result["client_cleanup"] = "CLOSED"
        except Exception:
            result["client_cleanup"] = "CLOSE_FAILED"; result["status"] = "FAIL"; result["stable_error"] = "PASS5_CLIENT_CLOSE_FAILED"
    return result


def write_evidence(root: Path, result: dict) -> Path:
    path = root / "stage6-pass5-evidence" / "stage6_live_interaction_runtime_report.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    return path
