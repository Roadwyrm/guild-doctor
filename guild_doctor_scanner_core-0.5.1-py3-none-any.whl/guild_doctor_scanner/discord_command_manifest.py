"""Authoritative typed, beginner-facing local command definitions."""
from __future__ import annotations
from dataclasses import asdict, dataclass
import hashlib, json
from .discord_query_adapter import DIRECT_COMMANDS

COMMAND_MANIFEST_CONTRACT="GUILD-DOCTOR-DISCORD-COMMAND-MANIFEST-0.1"
@dataclass(frozen=True)
class CommandOption:
 name:str; description:str; type:str; required:bool=True; autocomplete:bool=False; channel_types:tuple[str,...]=(); choices:tuple[tuple[str,str],...]=()
@dataclass(frozen=True)
class RuntimeCommand:
 key:str; slash_name:str; description:str; options:tuple[CommandOption,...]; acknowledgement:str; pagination:bool; export:bool
 guild_only:bool=True; owner_only:bool=True; visibility:str="EPHEMERAL"; synchronization_status:str="NOT_AUTHORIZED"

ACTION=CommandOption("action","Choose what the member is trying to do.","string",autocomplete=True)
PERMISSION=CommandOption("permission","Choose the permission or capability to check.","string",autocomplete=True)
CHANNEL=CommandOption("channel","Choose the channel where you want to check access.","channel",channel_types=("text","news"))
MEMBER=CommandOption("member","Choose the server member whose access you want to check.","user")
ROLE=CommandOption("role","Choose the server role to explain.","role")
COMMAND_MANIFEST=(
 RuntimeCommand("why-can","why-can","Explain why a member can perform an action.",(MEMBER,CHANNEL,ACTION),"IMMEDIATE_RESPONSE",False,False),
 RuntimeCommand("why-cannot","why-cannot","Explain why a member cannot perform an action.",(MEMBER,CHANNEL,ACTION),"IMMEDIATE_RESPONSE",False,False),
 RuntimeCommand("who-can","who-can","List members who can perform an action.",(CHANNEL,PERMISSION),"DEFER_EPHEMERAL",True,True),
 RuntimeCommand("who-cannot","who-cannot","List members who cannot perform an action.",(CHANNEL,PERMISSION),"DEFER_EPHEMERAL",True,True),
 RuntimeCommand("who-unknown","who-unknown","List members with an unknown result.",(CHANNEL,PERMISSION),"DEFER_EPHEMERAL",True,True),
 RuntimeCommand("find-setting","find-setting","Find where a permission setting comes from.",(CHANNEL,CommandOption("setting","Choose the permission setting to find.","string",autocomplete=True)),"IMMEDIATE_RESPONSE",False,False),
 RuntimeCommand("explain-role","explain-role","Explain a server role.",(ROLE,),"IMMEDIATE_RESPONSE",False,False),
 RuntimeCommand("explain-category","explain-category","Explain a channel category.",(CommandOption("category","Choose the category to explain.","channel",channel_types=("category",)),),"IMMEDIATE_RESPONSE",False,False),
 RuntimeCommand("explain-channel","explain-channel","Explain a server channel.",(CHANNEL,),"IMMEDIATE_RESPONSE",False,False),
 RuntimeCommand("compare-role-permission","compare-role-permission","Compare two roles for a raw permission.",(CommandOption("first-role","Choose the first role to compare.","role"),CommandOption("second-role","Choose the second role to compare.","role"),CommandOption("permission","Choose the raw permission to compare.","string",autocomplete=True)),"IMMEDIATE_RESPONSE",False,False),
 RuntimeCommand("compare-role-capability","compare-role-capability","Compare two roles for a capability.",(CommandOption("first-role","Choose the first role to compare.","role"),CommandOption("second-role","Choose the second role to compare.","role"),CommandOption("capability","Choose the capability to compare.","string",autocomplete=True)),"IMMEDIATE_RESPONSE",False,False),
 RuntimeCommand("compare-role-action","compare-role-action","Compare two roles for an action.",(CommandOption("first-role","Choose the first role to compare.","role"),CommandOption("second-role","Choose the second role to compare.","role"),CommandOption("action","Choose the action to compare.","string",autocomplete=True)),"IMMEDIATE_RESPONSE",False,False),
 RuntimeCommand("server-report","server-report","Present an already prepared private server report.",(),"DEFER_EPHEMERAL",True,False),
)
def manifest_fingerprint(manifest=COMMAND_MANIFEST)->str:return hashlib.sha256(json.dumps([asdict(item) for item in manifest],sort_keys=True,separators=(",",":"),default=list).encode()).hexdigest()
def validate_manifest(manifest=COMMAND_MANIFEST)->tuple[str,...]:
 if tuple(item.key for item in manifest)!=DIRECT_COMMANDS:return ("MANIFEST_DIRECT_COMMAND_MISMATCH",)
 if any(not item.guild_only or not item.owner_only or item.visibility!="EPHEMERAL" for item in manifest):return ("MANIFEST_PRIVATE_ALPHA_POLICY_INVALID",)
 if any(any(option.name=="target" for option in item.options) for item in manifest):return ("MANIFEST_GENERIC_TARGET_FORBIDDEN",)
 return ()
