"""Pure offline Stage 5 closure assessment for Passes 1 through 4."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


STAGE5_CLOSURE_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE5-CLOSURE-0.1"
STAGE5_COMPLETE = "STAGE5_COMPLETE"
STAGE5_IN_PROGRESS = "STAGE5_IN_PROGRESS"
STAGE5_INCOMPLETE = "STAGE5_INCOMPLETE"

_REQUIRED_CHECKS = (
    "pass1_complete",
    "pass2_complete",
    "pass3_complete",
    "pass4_runtime",
    "complete_test_suite",
    "clean_wheel",
    "guided_runtime",
    "direct_runtime",
    "batch_runtime",
    "presentation_runtime",
    "console_compatibility",
    "live_derived_runtime",
    "result_state_preservation",
    "primary_reason_preservation",
    "frozen_interface_audit",
    "no_duplicated_logic_audit",
    "protected_evidence_integrity",
    "read_only_audit",
    "source_pack",
)


def _passed(value: Any) -> bool:
    return value is True or (isinstance(value, Mapping) and str(value.get("status", "")).upper() == "PASS")


def assess_stage5_closure(checks: Mapping[str, Any]) -> dict[str, Any]:
    """Return a deterministic, offline closure decision from explicit evidence."""

    normalized = {str(key): value for key, value in checks.items()}
    closure_checks: dict[str, bool] = {}
    blockers: list[str] = []
    for name in _REQUIRED_CHECKS:
        passed = _passed(normalized.get(name))
        closure_checks[name] = passed
        if not passed:
            blockers.append(f"CHECK_FAILED:{name}")
    exact_values = {
        "network_contacted": (False, "SCOPE_FENCE_BREACH:NETWORK_CONTACTED"),
        "discord_contacted": (False, "SCOPE_FENCE_BREACH:DISCORD_CONTACTED"),
        "discord_writes": (0, "SCOPE_FENCE_BREACH:DISCORD_WRITES"),
        "runtime_ai_used": (False, "SCOPE_FENCE_BREACH:RUNTIME_AI_USED"),
        "recommendations_generated": (False, "SCOPE_FENCE_BREACH:RECOMMENDATIONS_GENERATED"),
        "direct_stage3_invocation": (False, "SCOPE_FENCE_BREACH:DIRECT_STAGE3_INVOCATION"),
        "stage6_started": (False, "SCOPE_FENCE_BREACH:STAGE6_STARTED"),
        "protected_evidence_modified": (False, "SCOPE_FENCE_BREACH:PROTECTED_EVIDENCE_MODIFIED"),
    }
    for name, (expected, blocker) in exact_values.items():
        if normalized.get(name, expected) != expected:
            blockers.append(blocker)
    if normalized.get("source_markdown_file_count") != 25:
        blockers.append("SOURCE_PACK_FILE_COUNT_NOT_25")
    if normalized.get("token_disclosure_status") != "PASS_NO_TOKEN_OUTPUT":
        blockers.append("TOKEN_DISCLOSURE_NOT_PROVEN")
    for item in normalized.get("concrete_blockers", ()):
        if isinstance(item, str) and item.strip():
            blockers.append(f"CONCRETE_BLOCKER:{item.strip()}")
    blockers = sorted(set(blockers))
    completed = not blockers and all(closure_checks.values())
    decision = STAGE5_COMPLETE if completed else STAGE5_IN_PROGRESS
    limitations = [
        "The local runtime does not register or synchronize Discord commands.",
        "No free-form natural-language parsing, fuzzy object matching, recommendation, remediation, audit finding, or Stage 6 logic is included.",
        "Live-derived runtime verification is local execution over frozen evidence, not live Discord Permission Doctor execution.",
        "Role comparisons remain hypothetical projections; full-member, human-MFA, voice-state, and active-thread coverage remain bounded by retained evidence.",
    ]
    return {
        "contract": STAGE5_CLOSURE_CONTRACT_VERSION,
        "decision": decision,
        "status": "PASS" if completed else "PENDING",
        "stage5_complete": completed,
        "closure_checks": closure_checks,
        "successful_evidence": sorted(name for name, passed in closure_checks.items() if passed),
        "concrete_blockers": blockers,
        "accepted_limitations": limitations,
        "verification_backlog_count": len(blockers),
        "verification_backlog": [{"backlog_id": f"STAGE5-PASS4-{index:03d}", "status": "OPEN", "blocker": blocker} for index, blocker in enumerate(blockers, start=1)],
        "pass_statuses": {name: "PASS" if closure_checks.get(name) else "FAIL" for name in _REQUIRED_CHECKS if name.startswith("pass")},
        "test_totals": normalized.get("test_totals", {}),
        "audit_totals": normalized.get("audit_totals", {}),
        "workflow_cases_evaluated": normalized.get("workflow_cases_evaluated", 0),
        "guided_sessions_evaluated": normalized.get("guided_sessions_evaluated", 0),
        "direct_commands_evaluated": normalized.get("direct_commands_evaluated", 0),
        "batch_workflows_evaluated": normalized.get("batch_workflows_evaluated", 0),
        "live_derived_local_workflows_evaluated": normalized.get("live_derived_local_workflows_evaluated", 0),
        "result_state_preservation": normalized.get("result_state_preservation"),
        "primary_reason_preservation": normalized.get("primary_reason_preservation"),
        "protected_evidence_integrity": normalized.get("protected_evidence_integrity"),
        "project_sources_count": normalized.get("source_markdown_file_count"),
        "rationale": "Stage 5 is complete only when all explicit runtime, wheel, evidence, and read-only scope gates pass with zero concrete blockers.",
        "authoritative_evidence_references": normalized.get("authoritative_evidence_references", ()),
        "network_contacted": normalized.get("network_contacted", False),
        "discord_contacted": normalized.get("discord_contacted", False),
        "discord_writes": normalized.get("discord_writes", 0),
        "runtime_ai_used": normalized.get("runtime_ai_used", False),
        "recommendations_generated": normalized.get("recommendations_generated", False),
        "stage6_started": normalized.get("stage6_started", False),
        "token_disclosure_status": normalized.get("token_disclosure_status"),
    }


def verification_backlog(assessment: Mapping[str, Any]) -> dict[str, Any]:
    blockers = assessment.get("concrete_blockers", ())
    return {
        "contract": STAGE5_CLOSURE_CONTRACT_VERSION,
        "stage": "STAGE5",
        "status": "CLEAR" if not blockers else "OPEN",
        "items": list(assessment.get("verification_backlog", ())),
        "count": len(blockers) if isinstance(blockers, list) else 0,
    }


__all__ = [
    "STAGE5_CLOSURE_CONTRACT_VERSION", "STAGE5_COMPLETE", "STAGE5_INCOMPLETE", "STAGE5_IN_PROGRESS",
    "assess_stage5_closure", "verification_backlog",
]
