"""Fail-closed offline preflight for a future bounded Gateway interaction session."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict, dataclass
import hashlib
import inspect
import json
from pathlib import Path, PureWindowsPath
from typing import Any

from .discord_command_manifest import COMMAND_MANIFEST, manifest_fingerprint
from .discord_command_schema import schema_fingerprint
from .discord_interaction_envelope import RESPONSE_KINDS
from .discord_normalized_snapshot_loader import AuthorizedNormalizedSnapshot, load_authorized_normalized_snapshot
from .private_alpha_configuration import (
    PrivateAlphaConfiguration, SecretPresence, load_configuration,
)
from .private_alpha_live_validation_configuration import (
    APPROVED_SNAPSHOT_BASENAME, APPROVED_SNAPSHOT_PATH, LIVE_CONFIGURATION_CONTRACT,
    PASS4C_PREFLIGHT_CONTRACT, LiveValidationConfiguration,
    load_live_configuration, validate_snapshot_path,
)
from .private_alpha_preflight import (
    FROZEN_COMMAND_SCHEMA_FINGERPRINT, FROZEN_PACKAGE_VERSION,
    FROZEN_ROUTE_MANIFEST_FINGERPRINT, _runtime_inventory,
    verify_protected_stage7_files,
)


BOUNDED_GATEWAY_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-BOUNDED-GATEWAY-SESSION-0.1"
EPHEMERAL_RESPONSE_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-EPHEMERAL-RESPONSE-BOUNDARY-0.1"
LIVE_SNAPSHOT_BINDING_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-LIVE-SNAPSHOT-BINDING-0.1"
READY_STATE = "READY_FOR_BOUNDED_LIVE_INTERACTION"

PREFLIGHT_STATES = frozenset({
    READY_STATE, "BLOCKED_ACTIVE_CONFIGURATION", "BLOCKED_LIVE_CONFIGURATION",
    "BLOCKED_SECRET", "BLOCKED_PROTECTED_BASELINE", "BLOCKED_ROUTE_SCHEMA",
    "BLOCKED_ENVELOPE_SCHEMA", "BLOCKED_SNAPSHOT_MISSING", "BLOCKED_SNAPSHOT_INVALID",
    "BLOCKED_SNAPSHOT_GUILD_MISMATCH", "BLOCKED_SNAPSHOT_FINGERPRINT",
    "BLOCKED_INTERACTION_ENDPOINT_CONFIRMATION", "BLOCKED_GATEWAY_POLICY",
    "BLOCKED_RESPONSE_POLICY", "BLOCKED_INVOCATION_BUDGET", "BLOCKED_SESSION_BUDGET",
    "BLOCKED_LIBRARY_INTERFACE", "BLOCKED_PRIVILEGED_INTENT",
    "BLOCKED_UNDECLARED_DISCORD_OPERATION", "BLOCKED_PRIVACY", "BLOCKED_UNEXPECTED",
})

INTERACTION_INPUT_POLICY = {
    "accepted_interaction_type": "APPLICATION_COMMAND_ONLY",
    "accepted_command_scope": "EXACT_ALLOWLISTED_GUILD_ONLY",
    "accepted_actor": "EXACT_GUILD_OWNER_ONLY",
    "accepted_routes": tuple(item.key for item in COMMAND_MANIFEST),
    "accepted_options": "EXACT_FROZEN_MANIFEST_SCHEMA_ONLY",
    "resolved_object_policy": "INTERACTION_RESOLVED_EXACT_OBJECTS_ONLY",
    "raw_payload_retention": "PROHIBITED",
    "rejected": (
        "DIRECT_MESSAGE", "PRIVATE_CHANNEL", "NON_OWNER", "NON_ALLOWLISTED_GUILD",
        "UNKNOWN_COMMAND", "COMPONENT", "MODAL", "AUTOCOMPLETE", "USER_COMMAND",
        "MESSAGE_COMMAND", "MALFORMED_RESOLVED_OBJECT", "MISSING_ACTOR_IDENTITY",
        "MISSING_GUILD_IDENTITY", "CROSS_GUILD_ENTITY", "ATTACHMENT",
        "MESSAGE_CONTENT", "UNSUPPORTED_INTERACTION_TYPE",
    ),
}

RESPONSE_WRITE_POLICY = {
    "visibility": "EPHEMERAL_ONLY",
    "initial_response_maximum": 1,
    "defer_maximum": 1,
    "deferred_original_edit_maximum": 1,
    "follow_up_maximum": 0,
    "second_response_maximum": 0,
    "delete_maximum": 0,
    "attachment_maximum": 0,
    "component_maximum": 0,
    "modal_maximum": 0,
    "public_message_maximum": 0,
    "channel_message_maximum": 0,
    "prefer_defer_when_deadline_risk": True,
    "interaction_identity_retention": "PROCESS_MEMORY_ONLY_UNTIL_CLEANUP",
}

ACQUISITION_PLAN = {
    "authorization": "SEPARATELY_AUTHORIZED_LATER_PASS_ONLY",
    "reviewed_get_operations": (
        "AUTHENTICATED_IDENTITY", "EXACT_GUILD_METADATA", "GUILD_ROLE_INVENTORY",
        "GUILD_CHANNEL_INVENTORY", "ACTIVE_THREAD_INVENTORY", "EXACT_OWNER_MEMBER",
    ),
    "prohibited": (
        "BROAD_MEMBER_ENUMERATION", "MESSAGE_HISTORY", "MESSAGE_CONTENT", "AUDIT_LOGS",
        "BANS", "INVITES", "WEBHOOKS", "INTEGRATIONS", "PRESENCES", "VOICE_STATES",
        "UNRELATED_PROFILE_ACQUISITION",
    ),
    "creates_or_refreshes_snapshot_in_pass4c": False,
}

LIVE_ROUTE_PLAN = (
    {
        "route": "compare-role-permission", "purpose": "COMPARISON_RESULT_AND_OPTION_NORMALIZATION",
        "prerequisite": "TWO_EXACT_ROLES_AND_REGISTERED_RAW_PERMISSION_IN_BOUND_SNAPSHOT",
        "skip_condition": "ROLE_OR_PERMISSION_PREREQUISITE_UNAVAILABLE",
    },
    {
        "route": "compare-role-capability", "purpose": "SECOND_GENUINE_COMPARISON_AND_RENDERER_PATH",
        "prerequisite": "TWO_EXACT_ROLES_AND_REGISTERED_CAPABILITY_IN_BOUND_SNAPSHOT",
        "skip_condition": "ROLE_OR_CAPABILITY_PREREQUISITE_UNAVAILABLE",
    },
    {
        "route": "compare-role-action", "purpose": "CLASSIFIED_FAIL_CLOSED_ERROR_DELIVERY",
        "prerequisite": "TWO_EXACT_ROLES_AND_REGISTERED_ACTION",
        "skip_condition": "ROLE_OR_ACTION_PREREQUISITE_UNAVAILABLE",
    },
    {
        "route": "server-report", "purpose": "REPORT_RESULT_RENDERING_AND_DETERMINISTIC_CLEANUP",
        "prerequisite": "COMPATIBLE_ASSEMBLED_LOCAL_REPORT_FROM_BOUND_SNAPSHOT",
        "skip_condition": "REPORT_PREREQUISITE_UNAVAILABLE",
    },
)


@dataclass(frozen=True, slots=True)
class LivePreflightCheck:
    check_id: str
    state: str
    blocked_state: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class LiveInteractionPreflightResult:
    overall_state: str
    checks: tuple[LivePreflightCheck, ...]
    blocked_states: tuple[str, ...]
    active_configuration_state: str
    live_configuration_state: str
    secret_presence_state: str
    protected_baseline_state: str
    route_schema_state: str
    envelope_schema_state: str
    snapshot_binding_state: str
    snapshot_contract_state: str
    snapshot_fingerprint_state: str
    snapshot_completeness_states: tuple[tuple[str, str], ...]
    gateway_policy_state: str
    response_policy_state: str
    library_interface_state: str
    minimal_intents_value: int | None
    invocation_budget: int | None
    session_duration_seconds: int | None
    route_plan_count: int
    active_configuration_fingerprint: str | None
    live_configuration_fingerprint: str | None
    snapshot_fingerprint: str | None
    preflight_fingerprint: str
    live_execution_authorized: bool = False
    gateway_connection_count: int = 0
    network_request_count: int = 0
    discord_get_count: int = 0
    interaction_response_write_count: int = 0
    command_registration_count: int = 0
    guild_object_write_count: int = 0
    token_prompt_count: int = 0

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def inspect_discord_library_interface() -> dict[str, Any]:
    """Inspect types and signatures only; never instantiate a Discord client."""
    try:
        import discord
        intents = discord.Intents.none()
        enabled = tuple(name for name, state in intents if state)
        start = inspect.signature(discord.Client.start)
        run = inspect.signature(discord.Client.run)
        interaction_parser = inspect.getsource(discord.state.ConnectionState.parse_interaction_create)
        command_dispatch_supported = (
            "data['type'] in (2, 4)" in interaction_parser
            and "_command_tree._from_interaction(interaction)" in interaction_parser
            and "intents" not in interaction_parser
        )
        return {
            "state": "PASS" if discord.__version__ == "2.7.1" and intents.value == 0 and not enabled and command_dispatch_supported else "FAIL",
            "library": "discord.py", "version": discord.__version__,
            "intent_factory": "Intents.none", "intent_value": intents.value,
            "enabled_intents": enabled,
            "privileged_intents": {"members": intents.members, "presences": intents.presences, "message_content": intents.message_content},
            "other_prohibited_intents": {"voice_states": intents.voice_states, "guilds": intents.guilds},
            "start_reconnect_default": start.parameters["reconnect"].default,
            "run_reconnect_default": run.parameters["reconnect"].default,
            "required_connection_argument": "reconnect=False",
            "application_command_dispatch_supported_without_intent_gate": command_dispatch_supported,
            "application_command_dispatch_path": "ConnectionState.parse_interaction_create(TYPE_2_TO_COMMAND_TREE)",
            "client_instantiated": False,
        }
    except (ImportError, AttributeError, KeyError, TypeError, ValueError):
        return {"state": "FAIL", "client_instantiated": False}


def _active_path_safe(path: Path, root: Path) -> bool:
    try:
        candidate, project = path.resolve(), root.resolve()
        return candidate != project and project not in candidate.parents and not path.name.endswith(".example.json")
    except (OSError, RuntimeError, ValueError):
        return False


def _snapshot_states(snapshot: Mapping[str, Any] | None) -> tuple[tuple[str, str], ...]:
    if not isinstance(snapshot, Mapping):
        return ()
    states = {
        "structural": str(snapshot.get("structural_completeness", "UNKNOWN")),
        "member": str(snapshot.get("member_completeness", "UNKNOWN")),
        "thread": str(snapshot.get("thread_completeness", "UNKNOWN")),
    }
    collections = snapshot.get("collections")
    if isinstance(collections, Mapping):
        for key, value in collections.items():
            states[f"collection:{key}"] = str(value.get("status", "UNKNOWN")) if isinstance(value, Mapping) else "UNKNOWN"
    return tuple(sorted(states.items()))


def run_live_interaction_preflight(
    *, root: Path, active_configuration_path: Path, live_configuration_path: Path,
    snapshot_path: Path | str, secret_presence: SecretPresence,
    snapshot_override: AuthorizedNormalizedSnapshot | None = None,
    active_configuration_override: PrivateAlphaConfiguration | None = None,
    live_configuration_override: LiveValidationConfiguration | None = None,
    library_override: Mapping[str, Any] | None = None,
    inventory_override: Mapping[str, Any] | None = None,
) -> LiveInteractionPreflightResult:
    root = root.resolve()
    checks: list[LivePreflightCheck] = []
    blocked: list[str] = []

    def add(check_id: str, passed: bool, blocked_state: str) -> None:
        checks.append(LivePreflightCheck(check_id, "PASS" if passed else "FAIL", None if passed else blocked_state))
        if not passed:
            blocked.append(blocked_state)

    active: PrivateAlphaConfiguration | None = None
    try:
        active = active_configuration_override if _active_path_safe(active_configuration_path, root) else None
        if active is None and _active_path_safe(active_configuration_path, root):
            active = load_configuration(active_configuration_path)
    except ValueError:
        active = None
    active_valid = bool(
        active and len(active.guild_allowlist) == 1 and active.operating_mode == "READ_ONLY_PRIVATE_ALPHA"
        and active.authorization_policy == "GUILD_OWNER_ONLY"
        and active.command_registration_state == active.guild_mutation_state == "DISABLED"
    )
    add("ACTIVE_CONFIGURATION", active_valid, "BLOCKED_ACTIVE_CONFIGURATION")

    live: LiveValidationConfiguration | None = None
    live_error = None
    try:
        live = live_configuration_override
        if live is None:
            live = load_live_configuration(live_configuration_path, project_root=root)
    except ValueError as exc:
        live_error = str(exc)
    live_block = {
        "STAGE8_PASS4C_INTERACTION_ENDPOINT_UNCONFIRMED": "BLOCKED_INTERACTION_ENDPOINT_CONFIRMATION",
        "STAGE8_PASS4C_INVOCATION_BUDGET_INVALID": "BLOCKED_INVOCATION_BUDGET",
        "STAGE8_PASS4C_SESSION_BUDGET_INVALID": "BLOCKED_SESSION_BUDGET",
        "STAGE8_PASS4C_GATEWAY_SESSION_BUDGET_INVALID": "BLOCKED_GATEWAY_POLICY",
        "STAGE8_PASS4C_GATEWAY_POLICY_INVALID": "BLOCKED_GATEWAY_POLICY",
        "STAGE8_PASS4C_RESPONSE_POLICY_INVALID": "BLOCKED_RESPONSE_POLICY",
        "STAGE8_PASS4C_UNDECLARED_OPERATION_POLICY_INVALID": "BLOCKED_UNDECLARED_DISCORD_OPERATION",
        "STAGE8_PASS4C_SNAPSHOT_PATH_INVALID": "BLOCKED_SNAPSHOT_INVALID",
        "STAGE8_PASS4C_SNAPSHOT_PATH_INSIDE_PROJECT": "BLOCKED_SNAPSHOT_INVALID",
    }.get(live_error, "BLOCKED_LIVE_CONFIGURATION")
    add("LIVE_CONFIGURATION", live is not None, live_block)
    add("SECRET_PRESENCE", secret_presence.state == "PRESENT", "BLOCKED_SECRET")

    protected, _ = verify_protected_stage7_files(root)
    add("PROTECTED_BASELINE", protected == "PASS", "BLOCKED_PROTECTED_BASELINE")
    inventory = dict(inventory_override or _runtime_inventory(root))
    route_valid = (
        inventory.get("route_count") == 13
        and inventory.get("route_manifest_fingerprint") == FROZEN_ROUTE_MANIFEST_FINGERPRINT
        and manifest_fingerprint() == FROZEN_ROUTE_MANIFEST_FINGERPRINT
        and inventory.get("command_schema_fingerprint") == FROZEN_COMMAND_SCHEMA_FINGERPRINT
        and schema_fingerprint() == FROZEN_COMMAND_SCHEMA_FINGERPRINT
        and inventory.get("package_version") == FROZEN_PACKAGE_VERSION
        and inventory.get("project_source_count") == 25
        and not inventory.get("stage9_present")
    )
    add("ROUTE_AND_SCHEMA", route_valid, "BLOCKED_ROUTE_SCHEMA")
    envelope_valid = inventory.get("envelope_branch_count") == 4 and len(RESPONSE_KINDS) == 4 and inventory.get("report_subtype_count") == 2
    add("ENVELOPE_SCHEMA", envelope_valid, "BLOCKED_ENVELOPE_SCHEMA")

    path_errors = validate_snapshot_path(snapshot_path, root)
    configured_match = bool(live and str(PureWindowsPath(str(snapshot_path))).casefold() == str(PureWindowsPath(live.authorized_normalized_snapshot_path)).casefold())
    path_valid = not path_errors and configured_match
    if snapshot_override is None:
        loaded = load_authorized_normalized_snapshot(path=Path(snapshot_path), guild_id=active.guild_allowlist[0] if active_valid and active else "")
    else:
        loaded = snapshot_override
    snapshot_state = "PASS" if path_valid and loaded.loaded else loaded.outcome
    snapshot_block = {
        "SNAPSHOT_NOT_FOUND": "BLOCKED_SNAPSHOT_MISSING",
        "SNAPSHOT_GUILD_MISMATCH": "BLOCKED_SNAPSHOT_GUILD_MISMATCH",
        "SNAPSHOT_PROVENANCE_FAILED": "BLOCKED_SNAPSHOT_FINGERPRINT",
    }.get(loaded.outcome, "BLOCKED_SNAPSHOT_INVALID")
    if not path_valid:
        snapshot_block = "BLOCKED_SNAPSHOT_INVALID"
    add("SNAPSHOT_BINDING", snapshot_state == "PASS", snapshot_block)

    library = dict(library_override or inspect_discord_library_interface())
    library_valid = library.get("state") == "PASS" and library.get("version") == "2.7.1"
    add("LIBRARY_INTERFACE", library_valid, "BLOCKED_LIBRARY_INTERFACE")
    privileged_disabled = library_valid and library.get("intent_value") == 0 and not library.get("enabled_intents")
    add("MINIMAL_NONPRIVILEGED_INTENTS", privileged_disabled, "BLOCKED_PRIVILEGED_INTENT")

    gateway_valid = bool(live and live.interaction_delivery_mode == "BOUNDED_OPERATOR_LOCAL_GATEWAY" and live.reconnect_policy == "DISABLED" and live.maximum_gateway_sessions == 1 and library.get("required_connection_argument") == "reconnect=False")
    add("GATEWAY_POLICY", gateway_valid, "BLOCKED_GATEWAY_POLICY")
    response_valid = bool(live and live.response_policy == "EPHEMERAL_ONLY" and live.follow_up_policy == live.component_policy == live.attachment_policy == live.public_response_policy == "DISABLED")
    add("RESPONSE_POLICY", response_valid, "BLOCKED_RESPONSE_POLICY")
    invocation_valid = bool(live and 1 <= live.maximum_live_command_invocations <= 4)
    add("INVOCATION_BUDGET", invocation_valid, "BLOCKED_INVOCATION_BUDGET")
    session_valid = bool(live and 1 <= live.maximum_session_duration_seconds <= 600)
    add("SESSION_BUDGET", session_valid, "BLOCKED_SESSION_BUDGET")
    undeclared_disabled = bool(live and live.command_registration_policy == live.guild_mutation_policy == live.remote_storage_policy == live.telemetry_policy == live.background_scanning_policy == "DISABLED")
    add("UNDECLARED_OPERATIONS_DISABLED", undeclared_disabled, "BLOCKED_UNDECLARED_DISCORD_OPERATION")

    unique = tuple(dict.fromkeys(blocked))
    overall = READY_STATE if not unique else unique[0]
    completeness = _snapshot_states(loaded.snapshot if loaded.loaded else None)
    snapshot_fingerprint = None
    if loaded.loaded and isinstance(loaded.snapshot, Mapping):
        candidate = loaded.snapshot.get("snapshot_fingerprint_sha256")
        snapshot_fingerprint = candidate if isinstance(candidate, str) and len(candidate) == 64 else None
    payload = {
        "contract": PASS4C_PREFLIGHT_CONTRACT, "overall_state": overall,
        "checks": [item.as_dict() for item in checks], "blocked_states": unique,
        "active_configuration_fingerprint": active.fingerprint if active else None,
        "live_configuration_fingerprint": live.fingerprint if live else None,
        "snapshot_fingerprint": snapshot_fingerprint,
        "minimal_intents_value": library.get("intent_value"),
        "route_plan_count": len(LIVE_ROUTE_PLAN), "live_execution_authorized": False,
    }
    fingerprint = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return LiveInteractionPreflightResult(
        overall, tuple(checks), unique,
        "PASS" if active_valid else "FAIL", "PASS" if live else "FAIL",
        secret_presence.state, protected,
        "PASS" if route_valid else "FAIL", "PASS" if envelope_valid else "FAIL",
        snapshot_state, "PASS" if loaded.loaded else loaded.outcome,
        "PASS" if loaded.loaded and snapshot_fingerprint else "FAIL", completeness,
        "PASS" if gateway_valid else "FAIL", "PASS" if response_valid else "FAIL",
        "PASS" if library_valid else "FAIL", library.get("intent_value"),
        live.maximum_live_command_invocations if live else None,
        live.maximum_session_duration_seconds if live else None,
        len(LIVE_ROUTE_PLAN), active.fingerprint if active else None,
        live.fingerprint if live else None, snapshot_fingerprint, fingerprint,
    )


__all__ = [
    "ACQUISITION_PLAN", "BOUNDED_GATEWAY_CONTRACT", "EPHEMERAL_RESPONSE_CONTRACT",
    "INTERACTION_INPUT_POLICY", "LIVE_ROUTE_PLAN", "LIVE_SNAPSHOT_BINDING_CONTRACT",
    "LiveInteractionPreflightResult", "LivePreflightCheck", "PREFLIGHT_STATES",
    "READY_STATE", "RESPONSE_WRITE_POLICY", "inspect_discord_library_interface",
    "run_live_interaction_preflight",
]
