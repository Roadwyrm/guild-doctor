"""Strict offline configuration for a future bounded private-alpha Gateway session."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path, PureWindowsPath
from typing import Any


LIVE_CONFIGURATION_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-LIVE-VALIDATION-CONFIGURATION-0.1"
PASS4C_PREFLIGHT_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4C-LIVE-INTERACTION-PREFLIGHT-0.1"
APPROVED_SNAPSHOT_BASENAME = "authorized_normalized_snapshot.json"
APPROVED_SNAPSHOT_PATH = PureWindowsPath(r"C:\GuildDoctor-Local\authorized_normalized_snapshot.json")
MAX_CONFIGURATION_BYTES = 65_536

LIVE_CONFIGURATION_FIELDS = frozenset({
    "configuration_contract", "operating_mode", "interaction_delivery_mode",
    "response_policy", "active_configuration_path_binding",
    "authorized_normalized_snapshot_path", "maximum_gateway_sessions",
    "maximum_live_command_invocations", "maximum_session_duration_seconds",
    "reconnect_policy", "command_registration_policy", "guild_mutation_policy",
    "attachment_policy", "follow_up_policy", "component_policy",
    "public_response_policy", "local_export_policy", "remote_storage_policy",
    "telemetry_policy", "background_scanning_policy", "evidence_policy",
    "cleanup_policy", "interactions_endpoint_url_absent_confirmed",
})

_EXPECTED = {
    "configuration_contract": LIVE_CONFIGURATION_CONTRACT,
    "operating_mode": "READ_ONLY_PRIVATE_ALPHA",
    "interaction_delivery_mode": "BOUNDED_OPERATOR_LOCAL_GATEWAY",
    "response_policy": "EPHEMERAL_ONLY",
    "active_configuration_path_binding": "EXPLICIT_OPERATOR_ARGUMENT_REQUIRED",
    "reconnect_policy": "DISABLED",
    "command_registration_policy": "DISABLED",
    "guild_mutation_policy": "DISABLED",
    "attachment_policy": "DISABLED",
    "follow_up_policy": "DISABLED",
    "component_policy": "DISABLED",
    "public_response_policy": "DISABLED",
    "local_export_policy": "EXPLICIT_OWNER_LOCAL_ONLY",
    "remote_storage_policy": "DISABLED",
    "telemetry_policy": "DISABLED",
    "background_scanning_policy": "DISABLED",
    "evidence_policy": "SANITIZED_STATES_COUNTS_FINGERPRINTS_ONLY",
    "cleanup_policy": "CLOSE_CLEAR_SECRETS_RELEASE_INTERACTION_STATE_NO_RECONNECT",
}

LIVE_CONFIGURATION_ERRORS = frozenset({
    "STAGE8_PASS4C_CONFIG_PATH_REQUIRED", "STAGE8_PASS4C_CONFIG_EXAMPLE_NOT_ACTIVE",
    "STAGE8_PASS4C_CONFIG_MISSING", "STAGE8_PASS4C_CONFIG_UNREADABLE",
    "STAGE8_PASS4C_CONFIG_OVERSIZED", "STAGE8_PASS4C_CONFIG_MALFORMED_JSON",
    "STAGE8_PASS4C_CONFIG_DUPLICATE_JSON_KEY", "STAGE8_PASS4C_CONFIG_UNKNOWN_FIELD",
    "STAGE8_PASS4C_CONFIG_MISSING_FIELD", "STAGE8_PASS4C_CONFIG_INVALID_FIELD_TYPE",
    "STAGE8_PASS4C_CONFIG_CONTRACT_MISMATCH", "STAGE8_PASS4C_CONFIG_POLICY_INVALID",
    "STAGE8_PASS4C_GATEWAY_POLICY_INVALID", "STAGE8_PASS4C_RESPONSE_POLICY_INVALID",
    "STAGE8_PASS4C_UNDECLARED_OPERATION_POLICY_INVALID",
    "STAGE8_PASS4C_SNAPSHOT_PATH_INVALID", "STAGE8_PASS4C_SNAPSHOT_PATH_INSIDE_PROJECT",
    "STAGE8_PASS4C_INTERACTION_ENDPOINT_UNCONFIRMED", "STAGE8_PASS4C_INVOCATION_BUDGET_INVALID",
    "STAGE8_PASS4C_SESSION_BUDGET_INVALID", "STAGE8_PASS4C_GATEWAY_SESSION_BUDGET_INVALID",
})


class LiveValidationConfigurationError(ValueError):
    def __init__(self, code: str):
        self.code = code if code in LIVE_CONFIGURATION_ERRORS else "STAGE8_PASS4C_CONFIG_POLICY_INVALID"
        super().__init__(self.code)


@dataclass(frozen=True, slots=True)
class LiveValidationConfiguration:
    configuration_contract: str
    operating_mode: str
    interaction_delivery_mode: str
    response_policy: str
    active_configuration_path_binding: str
    authorized_normalized_snapshot_path: str
    maximum_gateway_sessions: int
    maximum_live_command_invocations: int
    maximum_session_duration_seconds: int
    reconnect_policy: str
    command_registration_policy: str
    guild_mutation_policy: str
    attachment_policy: str
    follow_up_policy: str
    component_policy: str
    public_response_policy: str
    local_export_policy: str
    remote_storage_policy: str
    telemetry_policy: str
    background_scanning_policy: str
    evidence_policy: str
    cleanup_policy: str
    interactions_endpoint_url_absent_confirmed: bool

    @property
    def fingerprint(self) -> str:
        value = asdict(self)
        # The operator-local absolute path is deliberately excluded from the
        # public fingerprint.  Its approved basename and policy are frozen.
        value["authorized_normalized_snapshot_path"] = APPROVED_SNAPSHOT_BASENAME
        encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(encoded).hexdigest()

    def public_summary(self) -> dict[str, Any]:
        return {
            "configuration_contract": self.configuration_contract,
            "operating_mode": self.operating_mode,
            "interaction_delivery_mode": self.interaction_delivery_mode,
            "response_policy": self.response_policy,
            "authorized_snapshot_basename": APPROVED_SNAPSHOT_BASENAME,
            "maximum_gateway_sessions": self.maximum_gateway_sessions,
            "maximum_live_command_invocations": self.maximum_live_command_invocations,
            "maximum_session_duration_seconds": self.maximum_session_duration_seconds,
            "interactions_endpoint_url_absent_confirmed": self.interactions_endpoint_url_absent_confirmed,
            "configuration_fingerprint": self.fingerprint,
        }


def _pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in items:
        if key in result:
            raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def _windows_equal(first: str | Path, second: PureWindowsPath) -> bool:
    try:
        return str(PureWindowsPath(str(first))).casefold() == str(second).casefold()
    except (TypeError, ValueError):
        return False


def validate_snapshot_path(path: str | Path, project_root: Path) -> tuple[str, ...]:
    errors: list[str] = []
    rendered = str(path)
    if not _windows_equal(rendered, APPROVED_SNAPSHOT_PATH):
        errors.append("STAGE8_PASS4C_SNAPSHOT_PATH_INVALID")
    if PureWindowsPath(rendered).name.casefold() != APPROVED_SNAPSHOT_BASENAME.casefold():
        errors.append("STAGE8_PASS4C_SNAPSHOT_PATH_INVALID")
    try:
        candidate = Path(rendered).resolve()
        root = Path(project_root).resolve()
        if candidate == root or root in candidate.parents:
            errors.append("STAGE8_PASS4C_SNAPSHOT_PATH_INSIDE_PROJECT")
    except (OSError, RuntimeError, ValueError):
        errors.append("STAGE8_PASS4C_SNAPSHOT_PATH_INVALID")
    return tuple(sorted(set(errors)))


def validate_live_configuration_mapping(value: Any, *, project_root: Path) -> LiveValidationConfiguration:
    if not isinstance(value, Mapping):
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_INVALID_FIELD_TYPE")
    keys = frozenset(value)
    if LIVE_CONFIGURATION_FIELDS - keys:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_MISSING_FIELD")
    if keys - LIVE_CONFIGURATION_FIELDS:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_UNKNOWN_FIELD")
    for field, expected in _EXPECTED.items():
        if value.get(field) != expected:
            if field == "configuration_contract":
                code = "STAGE8_PASS4C_CONFIG_CONTRACT_MISMATCH"
            elif field in {"interaction_delivery_mode", "reconnect_policy"}:
                code = "STAGE8_PASS4C_GATEWAY_POLICY_INVALID"
            elif field in {"response_policy", "attachment_policy", "follow_up_policy", "component_policy", "public_response_policy"}:
                code = "STAGE8_PASS4C_RESPONSE_POLICY_INVALID"
            elif field in {"command_registration_policy", "guild_mutation_policy", "remote_storage_policy", "telemetry_policy", "background_scanning_policy"}:
                code = "STAGE8_PASS4C_UNDECLARED_OPERATION_POLICY_INVALID"
            else:
                code = "STAGE8_PASS4C_CONFIG_POLICY_INVALID"
            raise LiveValidationConfigurationError(code)
    integer_fields = ("maximum_gateway_sessions", "maximum_live_command_invocations", "maximum_session_duration_seconds")
    if any(type(value.get(field)) is not int for field in integer_fields):
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_INVALID_FIELD_TYPE")
    if value["maximum_gateway_sessions"] != 1:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_GATEWAY_SESSION_BUDGET_INVALID")
    if not 1 <= value["maximum_live_command_invocations"] <= 4:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_INVOCATION_BUDGET_INVALID")
    if not 1 <= value["maximum_session_duration_seconds"] <= 600:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_SESSION_BUDGET_INVALID")
    if type(value.get("interactions_endpoint_url_absent_confirmed")) is not bool:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_INVALID_FIELD_TYPE")
    if value["interactions_endpoint_url_absent_confirmed"] is not True:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_INTERACTION_ENDPOINT_UNCONFIRMED")
    path_errors = validate_snapshot_path(value.get("authorized_normalized_snapshot_path", ""), project_root)
    if path_errors:
        raise LiveValidationConfigurationError(path_errors[0])
    return LiveValidationConfiguration(**{field: value[field] for field in LIVE_CONFIGURATION_FIELDS})


def parse_live_configuration_text(text: str, *, project_root: Path) -> LiveValidationConfiguration:
    try:
        value = json.loads(text, object_pairs_hook=_pairs)
    except LiveValidationConfigurationError:
        raise
    except (json.JSONDecodeError, UnicodeError, TypeError):
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_MALFORMED_JSON") from None
    return validate_live_configuration_mapping(value, project_root=project_root)


def load_live_configuration(path: Path | str | None, *, project_root: Path) -> LiveValidationConfiguration:
    if path is None or not str(path):
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_PATH_REQUIRED")
    source = Path(path)
    if source.name.endswith(".example.json"):
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_EXAMPLE_NOT_ACTIVE")
    try:
        size = source.stat().st_size
    except FileNotFoundError:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_MISSING") from None
    except OSError:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_UNREADABLE") from None
    if size > MAX_CONFIGURATION_BYTES:
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_OVERSIZED")
    try:
        return parse_live_configuration_text(source.read_text(encoding="utf-8"), project_root=project_root)
    except (OSError, UnicodeError):
        raise LiveValidationConfigurationError("STAGE8_PASS4C_CONFIG_UNREADABLE") from None


__all__ = [
    "APPROVED_SNAPSHOT_BASENAME", "APPROVED_SNAPSHOT_PATH", "LIVE_CONFIGURATION_CONTRACT",
    "LIVE_CONFIGURATION_ERRORS", "LIVE_CONFIGURATION_FIELDS", "LiveValidationConfiguration",
    "LiveValidationConfigurationError", "PASS4C_PREFLIGHT_CONTRACT", "load_live_configuration",
    "parse_live_configuration_text", "validate_live_configuration_mapping", "validate_snapshot_path",
]
