"""Offline-only Stage 8 Pass 4C readiness CLI; it cannot start the Gateway."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from .private_alpha_configuration import check_secret_presence
from .private_alpha_live_interaction_preflight import READY_STATE, run_live_interaction_preflight


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run Guild Doctor bounded-interaction readiness checks offline.")
    parser.add_argument("--active-configuration", type=Path, required=True)
    parser.add_argument("--live-configuration", type=Path, required=True)
    parser.add_argument("--authorized-snapshot", type=Path, required=True)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = run_live_interaction_preflight(
            root=args.project_root,
            active_configuration_path=args.active_configuration,
            live_configuration_path=args.live_configuration,
            snapshot_path=args.authorized_snapshot,
            secret_presence=check_secret_presence(os.environ),
        )
        print(json.dumps(result.as_dict(), sort_keys=True, separators=(",", ":")), flush=True)
        return 0 if result.overall_state == READY_STATE else 2
    except Exception:
        print('{"overall_state":"BLOCKED_UNEXPECTED","privacy_state":"SANITIZED"}', flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
