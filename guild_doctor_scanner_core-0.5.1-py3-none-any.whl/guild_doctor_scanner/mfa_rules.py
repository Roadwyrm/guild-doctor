"""Versioned Pass 5 MFA rules kept separate from the frozen permission table."""

from __future__ import annotations

from typing import Any

from .authority_registry import OAUTH2_SOURCE_URL, PERMISSION_SOURCE_URL, USER_SOURCE_URL

MFA_RULES_VERSION = "GUILD-DOCTOR-MFA-RULES-0.1"
FROZEN_PERMISSION_DEFINITION_VERSION = "DISCORD-PERM-2026-07-13"
CURRENT_SOURCE_REVIEW_DATE = "2026-07-14"
MFA_SOURCE_DIFFERENCE = "FROZEN_PERMISSION_DEFINITION_HAS_NO_MFA_ASTERISK_METADATA"

# Current single-asterisk elevated set from the reviewed Discord permission table.
ELEVATED_PERMISSION_FLAGS: tuple[str, ...] = tuple(sorted({
    "ADMINISTRATOR",
    "BAN_MEMBERS",
    "KICK_MEMBERS",
    "MANAGE_CHANNELS",
    "MANAGE_GUILD",
    "MANAGE_GUILD_EXPRESSIONS",
    "MANAGE_MESSAGES",
    "MANAGE_ROLES",
    "MANAGE_THREADS",
    "MANAGE_WEBHOOKS",
    "VIEW_CREATOR_MONETIZATION_ANALYTICS",
}))

TIMEOUT_ONLY_PERMISSION_FLAG = "MODERATE_MEMBERS"

MFA_RULES_REGISTRY: dict[str, Any] = {
    "version": MFA_RULES_VERSION,
    "frozen_permission_definition_version": FROZEN_PERMISSION_DEFINITION_VERSION,
    "current_source_review_date": CURRENT_SOURCE_REVIEW_DATE,
    "source_difference": MFA_SOURCE_DIFFERENCE,
    "elevated_permission_flags": ELEVATED_PERMISSION_FLAGS,
    "timeout_only_permission_flag": TIMEOUT_ONLY_PERMISSION_FLAG,
    "source_references": (PERMISSION_SOURCE_URL, USER_SOURCE_URL, OAUTH2_SOURCE_URL),
    "migration": "Pass 5 supersedes only MFA metadata through this registry; earlier permission bits and contracts remain unchanged.",
}


def is_elevated_permission(flag: str | None) -> bool:
    return isinstance(flag, str) and flag in ELEVATED_PERMISSION_FLAGS


def validate_mfa_rules() -> tuple[str, ...]:
    reasons: list[str] = []
    if MFA_RULES_VERSION != "GUILD-DOCTOR-MFA-RULES-0.1":
        reasons.append("MFA_RULES_VERSION_MISMATCH")
    if TIMEOUT_ONLY_PERMISSION_FLAG in ELEVATED_PERMISSION_FLAGS:
        reasons.append("TIMEOUT_PERMISSION_IN_ELEVATED_SET")
    if len(ELEVATED_PERMISSION_FLAGS) != len(set(ELEVATED_PERMISSION_FLAGS)):
        reasons.append("DUPLICATE_ELEVATED_PERMISSION_FLAG")
    return tuple(sorted(set(reasons)))


__all__ = [
    "CURRENT_SOURCE_REVIEW_DATE", "ELEVATED_PERMISSION_FLAGS", "FROZEN_PERMISSION_DEFINITION_VERSION",
    "MFA_RULES_REGISTRY", "MFA_RULES_VERSION", "MFA_SOURCE_DIFFERENCE", "TIMEOUT_ONLY_PERMISSION_FLAG",
    "is_elevated_permission", "validate_mfa_rules",
]
