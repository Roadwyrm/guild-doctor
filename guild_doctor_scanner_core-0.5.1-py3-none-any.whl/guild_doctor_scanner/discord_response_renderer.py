"""Plain-language Pass 3 rendering with no permission recalculation."""
from __future__ import annotations

import re
from dataclasses import replace

from .audit_contract import scan_report_private
from .discord_response_model import RESPONSE_MODEL_CONTRACT, UserResponse
from .discord_interaction_envelope import (
    COMPARISON_RESULT,
    ERROR_RESULT,
    REPORT_RESULT,
    SUPPORTED_SOURCE_CONTRACTS,
)
from .canonical import canonical_json
from .discord_user_error_renderer import render_error
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY, KNOWN_PERMISSION_FLAGS
from .action_registry import ACTION_RULES_BY_KEY
from .doctor_role_comparison_query import CAPABILITY, RAW_PERMISSION
from .export_receipt_validation import (
    EXPORT_RECEIPT_REASON_TEXT,
    ExportReceiptValidationError,
    validate_export_receipt_metadata,
)


RESPONSE_RENDERER_CONTRACT = "GUILD-DOCTOR-DISCORD-RESPONSE-RENDERER-0.1"
STATE_TEXT = {
    "ALLOWED": "Based on the current snapshot, this action is calculated as allowed.",
    "DENIED": "Based on the current snapshot, this action is calculated as blocked.",
    "UNKNOWN": "Guild Doctor cannot determine this safely from the available evidence.",
    "NOT_APPLICABLE": "This permission or action does not apply in the selected context.",
    "INCOMPLETE": "The available scan or member data is incomplete, so this result is not complete.",
}
COMPARISON_LIMITATION = (
    "This is a raw role-permission comparison, not an effective "
    "member-permission result. Effective access may also depend on applicable "
    "Discord permission rules."
)
COMPARISON_TEXT = {
    "SAME": "The selected raw role permissions compare as the same.",
    "DIFFERENT": "The selected raw role permissions compare as different.",
    "NOT_COMPARABLE": "The selected raw role permissions are not comparable from the available frozen comparison data.",
}
CAPABILITY_COMPARISON_LIMITATION = (
    "This is a frozen role-capability comparison, not a final effective-member-permission "
    "decision. It does not determine a specific member, role hierarchy, overwrites, "
    "Administrator bypass, action prerequisites, or authorization to perform an action."
)
CAPABILITY_COMPARISON_TEXT = {
    "SAME": "The two roles have the same frozen comparison result for the selected capability.",
    "DIFFERENT": "The two roles have different frozen comparison results for the selected capability.",
    "NOT_COMPARABLE": "The frozen comparison could not compare the two roles for the selected capability.",
}
_FINGERPRINT = re.compile(r"^[0-9a-f]{64}$")
_RAW_PERMISSION_KEYS = frozenset(flag.name for flag in KNOWN_PERMISSION_FLAGS)


def _capability_label(target_key: object) -> str | None:
    if not isinstance(target_key, str) or not target_key:
        return None
    for definition in DEFAULT_CAPABILITY_REGISTRY.capabilities:
        if definition.capability_key == target_key:
            return definition.capability_key.replace(".", " ").title()
    return None


def _action_label(action_key: object) -> str | None:
    if not isinstance(action_key, str) or action_key not in ACTION_RULES_BY_KEY:
        return None
    return action_key.replace(".", " ").title()


def _comparison_error(
    *, correlation_id: str, command_key: str, code: str, acknowledgement_class: str
) -> UserResponse:
    """Return an existing classified comparison error without a generic fallback."""
    return render_error(
        correlation_id=correlation_id,
        command_key=command_key,
        code=code,
        acknowledgement_class=acknowledgement_class,
    )


def render_result(*, correlation_id: str, command_key: str, visibility: str, acknowledgement_class: str, adapted: dict, export_available: bool = False) -> UserResponse:
    state = adapted.get("result_state")
    return UserResponse(
        correlation_id=correlation_id, command_key=command_key, visibility=visibility,
        acknowledgement_class=acknowledgement_class, title="Guild Doctor result",
        concise_summary=STATE_TEXT.get(state, "Guild Doctor could not safely complete this diagnostic request."),
        result_state_label=state, result_state_explanation=STATE_TEXT.get(state, "A safe result state was not available."),
        primary_reason=adapted.get("primary_reason"), source_chain_sections=tuple(adapted.get("source_chain", ())),
        material_uncertainties=tuple(adapted.get("material_uncertainties", ())),
        snapshot_warnings=tuple(adapted.get("snapshot_warnings", ())),
        population_completeness=adapted.get("population_completeness"),
        no_action_attempted_statement="Guild Doctor did not attempt this action.",
        no_write_statement="Guild Doctor made no changes.",
        engine_contract_id=adapted.get("engine_contract_id"), engine_result_fingerprint=adapted.get("engine_result_fingerprint"),
        total_classified_count=adapted.get("total_classified_count"), displayed_count=adapted.get("displayed_count"), remaining_count=adapted.get("remaining_count"),
        export_available=export_available,
    )


def render_envelope_adapter_result(
    result: object,
    *,
    correlation_id: str,
    command_key: str = "compare-role-permission",
    visibility: str = "EPHEMERAL",
    acknowledgement_class: str = "IMMEDIATE_RESPONSE",
) -> UserResponse:
    """Render validated envelope branches without recalculating source semantics."""
    if result.response_kind == ERROR_RESULT:
        if result.error_result is None:
            raise ValueError("STAGE6_COMPARISON_ENVELOPE_PAYLOAD_MISSING")
        rendered = render_error(
            correlation_id=correlation_id,
            command_key=command_key,
            code=result.error_result.stable_error,
            acknowledgement_class=acknowledgement_class,
        )
        if result.error_result.stable_error == "STAGE6_ACTION_CONTEXT_REQUIRED":
            label = _action_label(result.error_result.action_key)
            if label is not None:
                rendered = replace(
                    rendered,
                    concise_summary=(
                        f"{label} is a recognized action, but this three-option command does not include enough frozen target, actor, hierarchy, prerequisite, or context evidence. No comparison or authorization conclusion was made."
                    ),
                )
        return rendered
    if result.response_kind == REPORT_RESULT:
        payload = result.report_result
        if payload is None:
            return _comparison_error(
                correlation_id=correlation_id,
                command_key=command_key,
                code="REPORT_PROVIDER_RESULT_MISSING",
                acknowledgement_class=acknowledgement_class,
            )
        validated_receipt = None
        if payload.subtype == "EXPORT_RECEIPT":
            try:
                validated_receipt = validate_export_receipt_metadata(
                    format=payload.format,
                    write_status=payload.write_status,
                    replacement_status=payload.replacement_status,
                    privacy_validation_status=payload.privacy_validation_status,
                    safe_basename=payload.safe_basename,
                    stable_reason=payload.stable_reason,
                )
            except (AttributeError, ExportReceiptValidationError) as exc:
                code = str(exc) if isinstance(exc, ExportReceiptValidationError) else "REPORT_RESULT_MALFORMED"
                return _comparison_error(
                    correlation_id=correlation_id,
                    command_key=command_key,
                    code=code,
                    acknowledgement_class=acknowledgement_class,
                )
        if scan_report_private(payload, "report_renderer.payload"):
            return _comparison_error(
                correlation_id=correlation_id,
                command_key=command_key,
                code="REPORT_PRIVACY_FAILED",
                acknowledgement_class=acknowledgement_class,
            )
        if payload.subtype == "REPORT_PAGE":
            item_lines = tuple(
                f"Report item {index}: {canonical_json(dict(item))}"
                for index, item in enumerate(payload.ordered_items, start=1)
            )
            provenance = tuple(
                f"Provenance: {canonical_json(dict(item))}"
                for item in payload.safe_provenance
            )
            uncertainty = ()
            if payload.completeness_state not in {"COMPLETE", "NOT_APPLICABLE"}:
                uncertainty = (
                    f"Section evidence state: {payload.completeness_state}.",
                )
            return UserResponse(
                correlation_id=correlation_id,
                command_key=command_key,
                visibility=visibility,
                acknowledgement_class=acknowledgement_class,
                title=f"Guild Doctor report: {payload.section_identifier.replace('_', ' ').title()}",
                concise_summary=(
                    f"Section {payload.section_ordinal} of {payload.total_section_count}; "
                    f"page {payload.page_index} of {payload.total_page_count}; "
                    f"showing {payload.displayed_item_count} of {payload.total_section_item_count} ordered items."
                ),
                result_state_label=None,
                result_state_explanation=f"Report section state: {payload.section_state}.",
                primary_reason=None,
                source_chain_sections=provenance + item_lines,
                material_uncertainties=uncertainty,
                snapshot_warnings=(),
                population_completeness=payload.completeness_state,
                no_action_attempted_statement="Guild Doctor did not attempt any action.",
                no_write_statement="Guild Doctor made no server changes.",
                engine_contract_id=payload.report_contract,
                engine_result_fingerprint=payload.report_fingerprint,
                page_count=payload.total_page_count,
                export_available=False,
                total_classified_count=payload.total_section_item_count,
                displayed_count=payload.displayed_item_count,
                remaining_count=(
                    0 if not payload.next_available
                    else max(0, payload.total_section_item_count - payload.page_index * payload.displayed_item_count)
                ),
            )
        if payload.subtype == "EXPORT_RECEIPT":
            if validated_receipt is None:
                return _comparison_error(
                    correlation_id=correlation_id,
                    command_key=command_key,
                    code="REPORT_RESULT_MALFORMED",
                    acknowledgement_class=acknowledgement_class,
                )
            safe_reason = EXPORT_RECEIPT_REASON_TEXT[validated_receipt.stable_reason]
            return UserResponse(
                correlation_id=correlation_id,
                command_key=command_key,
                visibility=visibility,
                acknowledgement_class=acknowledgement_class,
                title="Guild Doctor report export receipt",
                concise_summary=(
                    f"{validated_receipt.safe_basename} ({validated_receipt.format}) is {validated_receipt.write_status}; "
                    f"privacy validation: {validated_receipt.privacy_validation_status}."
                ),
                result_state_label=None,
                result_state_explanation=safe_reason,
                primary_reason=safe_reason,
                source_chain_sections=(
                    f"Report fingerprint: {payload.source_report_fingerprint}",
                    f"Content fingerprint: {payload.content_fingerprint}",
                    f"Byte count: {payload.byte_count}",
                    f"Replacement status: {validated_receipt.replacement_status}",
                ),
                material_uncertainties=(),
                snapshot_warnings=(),
                population_completeness=None,
                no_action_attempted_statement="Guild Doctor did not attempt any Discord action.",
                no_write_statement="Guild Doctor made no server changes.",
                engine_contract_id=payload.report_contract,
                engine_result_fingerprint=payload.report_fingerprint,
                export_available=False,
            )
        return _comparison_error(
            correlation_id=correlation_id,
            command_key=command_key,
            code="REPORT_RESULT_MALFORMED",
            acknowledgement_class=acknowledgement_class,
        )
    if result.response_kind != COMPARISON_RESULT or result.comparison_result is None:
        raise ValueError("STAGE6_COMPARISON_CONTRACT_MISMATCH")
    payload = result.comparison_result
    target_kind = getattr(payload, "target_kind", None)
    target_key = getattr(payload, "target_key", None)
    if not isinstance(target_kind, str) or not target_kind or not isinstance(target_key, str) or not target_key:
        return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_PAYLOAD_INVALID", acknowledgement_class=acknowledgement_class)
    if payload.source_contract_id not in SUPPORTED_SOURCE_CONTRACTS or not isinstance(payload.source_contract_version, str) or not payload.source_contract_version:
        return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_CONTRACT_MISMATCH", acknowledgement_class=acknowledgement_class)
    if not isinstance(payload.case_fingerprint, str) or not _FINGERPRINT.fullmatch(payload.case_fingerprint):
        return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_FINGERPRINT_INVALID", acknowledgement_class=acknowledgement_class)
    if type(payload.comparable) is not bool:
        return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_PAYLOAD_INVALID", acknowledgement_class=acknowledgement_class)
    if payload.comparable:
        if type(payload.results_differ) is not bool:
            return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_PAYLOAD_INVALID", acknowledgement_class=acknowledgement_class)
    elif payload.results_differ is not None:
        return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_PAYLOAD_INVALID", acknowledgement_class=acknowledgement_class)
    if target_kind == RAW_PERMISSION:
        if target_key not in _RAW_PERMISSION_KEYS:
            return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_CONTRACT_MISMATCH", acknowledgement_class=acknowledgement_class)
        summary = COMPARISON_TEXT.get(payload.comparison_outcome)
        limitation = COMPARISON_LIMITATION
        source_sections = (
            f"Comparison contract: {payload.source_contract_id}",
            f"Source version: {payload.source_contract_version}",
        )
        explanation = "This comparison does not produce a permission result state."
    elif target_kind == CAPABILITY:
        label = _capability_label(target_key)
        if label is None:
            return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_CONTRACT_MISMATCH", acknowledgement_class=acknowledgement_class)
        summary = CAPABILITY_COMPARISON_TEXT.get(payload.comparison_outcome)
        limitation = CAPABILITY_COMPARISON_LIMITATION
        source_sections = (
            f"Capability: {label} ({target_key})",
            f"Comparison contract: {payload.source_contract_id}",
            f"Source version: {payload.source_contract_version}",
        )
        explanation = "This is a frozen role-capability comparison outcome, not a permission decision."
    else:
        return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_CONTRACT_MISMATCH", acknowledgement_class=acknowledgement_class)
    if summary is None:
        return _comparison_error(correlation_id=correlation_id, command_key=command_key, code="STAGE6_COMPARISON_PAYLOAD_INVALID", acknowledgement_class=acknowledgement_class)
    return UserResponse(
        correlation_id=correlation_id,
        command_key=command_key,
        visibility=visibility,
        acknowledgement_class=acknowledgement_class,
        title="Guild Doctor role comparison",
        concise_summary=summary,
        result_state_label=None,
        result_state_explanation=explanation,
        primary_reason=payload.primary_reason,
        source_chain_sections=source_sections,
        material_uncertainties=(limitation,),
        snapshot_warnings=(),
        population_completeness=None,
        no_action_attempted_statement="Guild Doctor did not attempt this action.",
        no_write_statement="Guild Doctor made no changes.",
        engine_contract_id=payload.source_contract_id,
        engine_result_fingerprint=payload.case_fingerprint,
        export_available=False,
    )


def render_plain_text(response: UserResponse) -> str:
    sections = [response.concise_summary]
    if response.primary_reason:
        sections.append(f"Primary reason: {response.primary_reason}")
    if response.source_chain_sections:
        sections.append("Where the result comes from: " + " > ".join(response.source_chain_sections))
    if response.material_uncertainties:
        sections.append("Important uncertainties: " + ", ".join(response.material_uncertainties))
    if response.snapshot_warnings:
        sections.append("Snapshot warnings: " + ", ".join(response.snapshot_warnings))
    sections.extend((response.no_action_attempted_statement, response.no_write_statement))
    return "\n".join(sections)
