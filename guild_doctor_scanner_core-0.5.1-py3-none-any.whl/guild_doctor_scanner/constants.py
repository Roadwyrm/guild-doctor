"""Version and registry constants for the Stage 2 reference core."""

SCANNER_CONTRACT_VERSION = "GUILD-DOCTOR-SCANNER-0.5"
SNAPSHOT_SCHEMA_VERSION = "GUILD-DOCTOR-SNAPSHOT-0.1"
PERMISSION_DEFINITION_VERSION = "DISCORD-PERM-2026-07-13"
KNOWN_PERMISSION_MASK = 0x001F7FFFFFFFFFFF

CHANNEL_TYPE_KEYS: dict[int, str] = {
    0: "TEXT",
    2: "VOICE",
    4: "CATEGORY",
    5: "ANNOUNCEMENT",
    10: "ANNOUNCEMENT_THREAD",
    11: "PUBLIC_THREAD",
    12: "PRIVATE_THREAD",
    13: "STAGE",
    15: "FORUM",
    16: "MEDIA",
}

THREAD_TYPE_CODES = {10, 11, 12}
CATEGORY_TYPE_CODE = 4

REQUIRED_COLLECTIONS_BY_PROFILE: dict[str, tuple[str, ...]] = {
    "STRUCTURE_BASELINE": ("guild", "roles", "channels", "active_threads"),
    "TARGETED_MEMBER": ("guild", "roles", "channels", "active_threads", "members"),
    "WHO_CAN_TEMPORARY": ("guild", "roles", "channels", "active_threads", "members"),
    "THREAD_TARGETED": ("guild", "roles", "channels", "active_threads", "thread_memberships"),
    "FIXTURE_IMPORT": ("guild", "roles", "channels"),
}
