"""Deterministic response-page generation; no interactive UI objects."""
from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib

from .discord_response_model import UserResponse


PAGINATION_CONTRACT = "GUILD-DOCTOR-DISCORD-PAGINATION-0.1"
MAX_SOURCE_ITEMS_PER_PAGE = 4


@dataclass(frozen=True)
class ResponsePage:
    page_number: int
    page_count: int
    response: UserResponse
    source_chain_sections: tuple[str, ...]
    pagination_fingerprint: str


def paginate(response: UserResponse, page_size: int = MAX_SOURCE_ITEMS_PER_PAGE) -> tuple[ResponsePage, ...]:
    if page_size < 1:
        raise ValueError("page_size must be positive")
    items = response.source_chain_sections or ("No source-chain details were supplied.",)
    chunks = tuple(items[index:index + page_size] for index in range(0, len(items), page_size))
    count = len(chunks)
    return tuple(ResponsePage(index + 1, count, replace(response, page_count=count), chunk, hashlib.sha256((response.presentation_fingerprint + str(index + 1) + "|".join(chunk)).encode()).hexdigest()) for index, chunk in enumerate(chunks))
