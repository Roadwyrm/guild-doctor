"""Deterministic pre-sync capture and rollback payload safeguards."""
from __future__ import annotations

import copy
import hashlib
import json
from collections.abc import Mapping, Sequence
from typing import Any

from .discord_command_schema import (
    LIVE_ROOT_DESCRIPTION,
    LIVE_ROOT_NAME,
    compare_live_schema,
    expected_live_schema,
    normalize_live_commands,
)


SYNC_SAFEGUARD_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS5-SYNC-SAFEGUARD-0.1"
ROLLBACK_SNAPSHOT_CONTRACT = "GUILD-DOCTOR-STAGE6-PASS5-ROLLBACK-SNAPSHOT-0.1"
PRE_SYNC_HISTORICAL_10 = "HISTORICAL_10"
PRE_SYNC_APPROVED_12 = "APPROVED_12"
PRE_SYNC_UNRELATED = "UNRELATED_TOP_LEVEL_COMMANDS"
PRE_SYNC_MALFORMED = "MALFORMED_REMOTE_REGISTRATION"

_COMMAND_FIELDS = (
    "type", "name", "description", "options", "name_localizations",
    "description_localizations", "default_member_permissions",
    "dm_permission", "nsfw", "contexts", "integration_types",
)
_OPTION_FIELDS = (
    "type", "name", "description", "required", "autocomplete", "choices",
    "channel_types", "min_value", "max_value", "min_length", "max_length",
    "options", "name_localizations", "description_localizations",
)
_CHOICE_FIELDS = ("name", "value", "name_localizations")


def _plain(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_plain(item) for item in value]
    enum_value = getattr(value, "value", None)
    if isinstance(enum_value, (str, int, float, bool)):
        return enum_value
    to_array = getattr(value, "to_array", None)
    if callable(to_array):
        return [_plain(item) for item in to_array()]
    return str(value)


def _raw(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    to_dict = getattr(value, "to_dict", None)
    data = dict(to_dict()) if callable(to_dict) else {}
    for field in _COMMAND_FIELDS + _OPTION_FIELDS + _CHOICE_FIELDS:
        if field not in data and hasattr(value, field):
            data[field] = getattr(value, field)
    if "contexts" not in data and getattr(value, "allowed_contexts", None) is not None:
        data["contexts"] = value.allowed_contexts.to_array()
    if "integration_types" not in data and getattr(value, "allowed_installs", None) is not None:
        data["integration_types"] = value.allowed_installs.to_array()
    return data


def _choice_payload(value: Any) -> dict[str, Any]:
    data = _raw(value)
    return {field: _plain(data[field]) for field in _CHOICE_FIELDS if field in data and data[field] is not None}


def _option_payload(value: Any) -> dict[str, Any]:
    data = _raw(value)
    payload: dict[str, Any] = {}
    for field in _OPTION_FIELDS:
        if field not in data or data[field] is None:
            continue
        if field == "options":
            payload[field] = [_option_payload(item) for item in data[field]]
        elif field == "choices":
            payload[field] = [_choice_payload(item) for item in data[field]]
        else:
            payload[field] = _plain(data[field])
    return payload


def command_submission_payload(value: Any) -> dict[str, Any]:
    """Strip server-generated command fields while preserving submit-safe schema."""
    data = _raw(value)
    payload: dict[str, Any] = {}
    for field in _COMMAND_FIELDS:
        if field not in data or data[field] is None:
            continue
        if field == "options":
            payload[field] = [_option_payload(item) for item in data[field]]
        elif field == "default_member_permissions":
            raw_permissions = getattr(data[field], "value", data[field])
            payload[field] = str(raw_permissions)
        else:
            payload[field] = _plain(data[field])
    return payload


def historical_live_schema() -> dict[str, Any]:
    """Frozen, exact historical ten-route guild registration."""
    approved = expected_live_schema()
    unchanged = [
        copy.deepcopy(item)
        for item in approved["subcommands"]
        if not item["name"].startswith("compare-role-")
    ]
    role_options = copy.deepcopy(
        next(item for item in approved["subcommands"] if item["name"] == "compare-role-permission")["options"][:2]
    )
    unchanged.append(
        {
            "name": "compare-roles",
            "description": "Compare two server roles.",
            "options": role_options,
        }
    )
    return {
        "root_name": LIVE_ROOT_NAME,
        "root_type": "chat_input",
        "description": LIVE_ROOT_DESCRIPTION,
        "subcommands": unchanged,
    }


def expected_schema_fingerprint(schema: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(schema, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def rollback_payload_fingerprint(commands: Sequence[Any]) -> str:
    payloads = [command_submission_payload(command) for command in commands]
    ordered = sorted(payloads, key=lambda item: (str(item.get("type", "")), str(item.get("name", ""))))
    return hashlib.sha256(
        json.dumps(ordered, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def classify_pre_sync_registration(commands: Sequence[Any]) -> tuple[str, dict[str, Any]]:
    normalized = normalize_live_commands(commands)
    if normalized["unrelated_top_level_command_count"]:
        return PRE_SYNC_UNRELATED, normalized
    if compare_live_schema(normalized, expected=expected_live_schema())["state"] == "COMMANDS_PRESENT_EXACT":
        return PRE_SYNC_APPROVED_12, normalized
    if compare_live_schema(normalized, expected=historical_live_schema())["state"] == "COMMANDS_PRESENT_EXACT":
        return PRE_SYNC_HISTORICAL_10, normalized
    return PRE_SYNC_MALFORMED, normalized


def capture_rollback_snapshot(commands: Sequence[Any], *, guild_id: str) -> dict[str, Any]:
    state, normalized = classify_pre_sync_registration(commands)
    payloads = [command_submission_payload(command) for command in commands]
    root = normalized["roots"][0] if len(normalized["roots"]) == 1 else {}
    names = [item.get("name") for item in root.get("subcommands", [])]
    return {
        "snapshot_contract": ROLLBACK_SNAPSHOT_CONTRACT,
        "guild_id": str(guild_id),
        "pre_sync_state": state,
        "commands": payloads,
        "top_level_command_names": [item.get("name") for item in payloads],
        "command_types": [item.get("type") for item in payloads],
        "guild_doctor_subcommand_names": names,
        "pre_sync_route_count": len(names),
        "unrelated_top_level_command_count": normalized["unrelated_top_level_command_count"],
        "normalized_fingerprint": rollback_payload_fingerprint(payloads),
        "token_redacted": True,
        "credentials_retained": False,
    }


def rollback_snapshot_matches(snapshot: Mapping[str, Any], commands: Sequence[Any], *, guild_id: str) -> bool:
    if str(snapshot.get("guild_id")) != str(guild_id):
        return False
    return snapshot.get("normalized_fingerprint") == rollback_payload_fingerprint(commands)


__all__ = [
    "PRE_SYNC_APPROVED_12", "PRE_SYNC_HISTORICAL_10", "PRE_SYNC_MALFORMED",
    "PRE_SYNC_UNRELATED", "ROLLBACK_SNAPSHOT_CONTRACT", "SYNC_SAFEGUARD_CONTRACT",
    "capture_rollback_snapshot", "classify_pre_sync_registration",
    "command_submission_payload", "expected_schema_fingerprint",
    "historical_live_schema", "rollback_payload_fingerprint",
    "rollback_snapshot_matches",
]
