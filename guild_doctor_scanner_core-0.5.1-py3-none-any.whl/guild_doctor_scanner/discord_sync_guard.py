"""Fail-closed guard for a future separately authorized disposable sync."""
from __future__ import annotations
SYNC_GUARD_CONTRACT="GUILD-DOCTOR-DISCORD-SYNC-GUARD-0.1"
CONFIRMATION_PHRASE="GUILD_DOCTOR_SYNC_DISPOSABLE_COMMANDS"
SYNC_STATES=("SYNC_NOT_AUTHORIZED","SYNC_CONFIRMATION_REQUIRED","SYNC_GUILD_REQUIRED","SYNC_PROVENANCE_FAILED","SYNC_MANIFEST_MISMATCH","SYNC_VERSION_MISMATCH","SYNC_READINESS_FAILED","SYNC_NETWORK_DISABLED","SYNC_SCOPE_VIOLATION","SYNC_READY_FOR_DISPOSABLE_GUILD","SYNC_INTERNAL_ERROR")
def evaluate_sync_guard(*,confirmation:str|None,guild_id:str|None,authorized_mode:bool,provenance_pass:bool,manifest_match:bool,version_match:bool,readiness_pass:bool,network_enabled:bool,protected_evidence_pass:bool,scope_clean:bool)->str:
 if not authorized_mode:return "SYNC_NOT_AUTHORIZED"
 if confirmation!=CONFIRMATION_PHRASE:return "SYNC_CONFIRMATION_REQUIRED"
 if not guild_id:return "SYNC_GUILD_REQUIRED"
 if not provenance_pass:return "SYNC_PROVENANCE_FAILED"
 if not manifest_match:return "SYNC_MANIFEST_MISMATCH"
 if not version_match:return "SYNC_VERSION_MISMATCH"
 if not readiness_pass:return "SYNC_READINESS_FAILED"
 if not network_enabled:return "SYNC_NETWORK_DISABLED"
 if not protected_evidence_pass or not scope_clean:return "SYNC_SCOPE_VIOLATION"
 return "SYNC_READY_FOR_DISPOSABLE_GUILD"
