"""Read-only verification support for already acquired Pass 3-5 inputs.

The adapter deliberately accepts pre-acquired, normalized results instead of
owning a Discord transport.  A caller may supply results produced by the
reviewed GET-only acquisition path, and this module will model the action and
report whether the prepared expectation matches.  It never sends an operation
request and never receives or stores a bot credential.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .action_engine import ActionOrchestrationRequest, ActionOrchestrationResult, evaluate_action_orchestration


LIVE_AUTHORITY_VERIFY_CONTRACT_VERSION = "GUILD-DOCTOR-LIVE-AUTHORITY-VERIFY-0.1"
LIVE_VERIFICATION_PENDING_STATUS = "IMPLEMENTATION_COMPLETE_LIVE_VERIFICATION_PENDING"


@dataclass(frozen=True, slots=True)
class ReadOnlyAuthorityVerificationRequest:
    scenario_id: str
    action_request: ActionOrchestrationRequest
    live_structure_acquired: bool = False
    expected_result: str | None = None
    evidence_classification: str = "NEEDS_LIVE_TEST"


@dataclass(frozen=True, slots=True)
class ReadOnlyAuthorityVerificationResult:
    verification_contract_version: str
    scenario_id: str
    live_execution: bool
    modeled_result: str
    expected_result: str | None
    expectation_match: bool | None
    evidence_classification: str
    read_only: bool
    operation_attempted: bool
    write_operation_count: int
    transport_success_verified: bool
    orchestration_result: ActionOrchestrationResult

    def as_dict(self) -> dict[str, Any]:
        return {
            "verification_contract_version": self.verification_contract_version,
            "scenario_id": self.scenario_id,
            "live_execution": self.live_execution,
            "modeled_result": self.modeled_result,
            "expected_result": self.expected_result,
            "expectation_match": self.expectation_match,
            "evidence_classification": self.evidence_classification,
            "read_only": self.read_only,
            "operation_attempted": self.operation_attempted,
            "write_operation_count": self.write_operation_count,
            "transport_success_verified": self.transport_success_verified,
            "orchestration_result": self.orchestration_result.as_dict(),
        }


def run_read_only_authority_verification(
    request: ReadOnlyAuthorityVerificationRequest | Mapping[str, Any],
) -> ReadOnlyAuthorityVerificationResult:
    """Model one prepared read-only scenario without acquiring or mutating data."""

    if not isinstance(request, ReadOnlyAuthorityVerificationRequest):
        request = ReadOnlyAuthorityVerificationRequest(**dict(request))
    result = evaluate_action_orchestration(request.action_request)
    expected = request.expected_result.upper() if isinstance(request.expected_result, str) else request.expected_result
    return ReadOnlyAuthorityVerificationResult(
        verification_contract_version=LIVE_AUTHORITY_VERIFY_CONTRACT_VERSION,
        scenario_id=str(request.scenario_id),
        live_execution=bool(request.live_structure_acquired),
        modeled_result=result.final_result,
        expected_result=expected,
        expectation_match=(result.final_result == expected) if expected is not None else None,
        evidence_classification=str(request.evidence_classification),
        read_only=True,
        operation_attempted=False,
        write_operation_count=0,
        transport_success_verified=False,
        orchestration_result=result,
    )


__all__ = [
    "LIVE_AUTHORITY_VERIFY_CONTRACT_VERSION",
    "LIVE_VERIFICATION_PENDING_STATUS",
    "ReadOnlyAuthorityVerificationRequest",
    "ReadOnlyAuthorityVerificationResult",
    "run_read_only_authority_verification",
]
