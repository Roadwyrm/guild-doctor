"""Versioned normalized snapshot dataclasses."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class CollectionHealth:
    resource: str
    status: str
    expected_count: int | None = None
    received_count: int | None = None
    page_count: int | None = None
    cursor_complete: bool | None = None
    started_at: str | None = None
    completed_at: str | None = None
    source_interface: str | None = None
    error_codes: list[str] = field(default_factory=list)


@dataclass(slots=True)
class SnapshotIssue:
    issue_id: str
    code: str
    severity: str
    materiality: str
    entity_type: str
    entity_id: str | None
    related_ids: list[str]
    message_key: str
    details: dict[str, Any]
    source_status: str = "DOCUMENTED"


@dataclass(slots=True)
class NormalizedGuild:
    id: str
    name: str
    owner_id: str
    features: list[str]
    mfa_level: str
    reported_member_count: int | None
    large: bool | None
    unavailable: bool | None
    source_observed_at: str
    source_payload_hash: str | None = None


@dataclass(slots=True)
class RoleTags:
    bot_id: str | None = None
    integration_id: str | None = None
    subscription_listing_id: str | None = None
    available_for_purchase: bool | None = None
    guild_connections: bool | None = None


@dataclass(slots=True)
class NormalizedRole:
    id: str
    guild_id: str
    name: str
    position: int
    permissions_decimal: str
    managed: bool
    mentionable: bool | None
    hoist: bool | None
    is_everyone: bool
    role_tags: RoleTags
    source_observed_at: str
    source_payload_hash: str | None = None


@dataclass(slots=True)
class NormalizedOverwrite:
    target_id: str
    target_type: str
    raw_target_type: int | str
    allow_decimal: str
    deny_decimal: str
    source_index: int


@dataclass(slots=True)
class NormalizedForumTag:
    id: str
    name: str
    moderated: bool
    emoji_id: str | None
    emoji_name: str | None


@dataclass(slots=True)
class NormalizedChannel:
    id: str
    guild_id: str
    type_code: int
    type_key: str
    name: str
    position: int
    parent_id: str | None
    topic: str | None
    nsfw: bool | None
    flags_decimal: str | None
    rate_limit_per_user: int | None
    bitrate: int | None
    user_limit: int | None
    rtc_region: str | None
    video_quality_mode: int | None
    default_auto_archive_duration: int | None
    default_thread_rate_limit_per_user: int | None
    available_tags: list[NormalizedForumTag]
    default_reaction_emoji: dict[str, Any] | None
    default_sort_order: int | None
    default_forum_layout: int | None
    permission_overwrites: list[NormalizedOverwrite]
    sync_state: str
    sync_parent_id: str | None
    sync_evidence: list[str]
    source_observed_at: str
    source_payload_hash: str | None = None


@dataclass(slots=True)
class NormalizedThread:
    id: str
    guild_id: str
    parent_id: str | None
    owner_id: str | None
    type_code: int
    type_key: str
    name: str
    archived: bool | None
    locked: bool | None
    invitable: bool | None
    auto_archive_duration: int | None
    archive_timestamp: str | None
    create_timestamp: str | None
    flags_decimal: str | None
    applied_tag_ids: list[str]
    message_count: int | None
    member_count: int | None
    source_scope: str
    source_observed_at: str
    source_payload_hash: str | None = None


@dataclass(slots=True)
class NormalizedMember:
    id: str
    guild_id: str
    role_ids: list[str]
    highest_role_id: str | None
    highest_role_position: int | None
    timeout_until: str | None
    timeout_state: str
    bot: bool | None
    pending: bool | None
    mfa_state: str
    source_scope: str
    source_observed_at: str
    source_payload_hash: str | None = None


@dataclass(slots=True)
class NormalizedThreadMembership:
    thread_id: str
    member_id: str
    joined_at: str | None
    flags: int | None
    membership_state: str
    source_observed_at: str


@dataclass(slots=True)
class ManagedBinding:
    role_id: str
    binding_type: str
    external_id: str | None
    confidence: str


@dataclass(slots=True)
class NormalizedSnapshot:
    schema_version: str
    scanner_contract_version: str
    permission_definition_version: str
    snapshot_id: str
    snapshot_fingerprint_sha256: str | None
    structural_fingerprint_sha256: str | None
    scan_profile: str
    guild_id: str
    started_at: str
    completed_at: str
    source_api_version: str | None
    source_library: str | None
    source_library_version: str | None
    structural_completeness: str
    member_completeness: str
    thread_completeness: str
    collections: dict[str, CollectionHealth]
    guild: NormalizedGuild | None
    roles: dict[str, NormalizedRole] | None
    channels: dict[str, NormalizedChannel] | None
    threads: dict[str, NormalizedThread] | None
    members: dict[str, NormalizedMember] | None
    thread_memberships: dict[str, NormalizedThreadMembership] | None
    bindings: list[ManagedBinding]
    issues: list[SnapshotIssue]
    counts: dict[str, int | None]
    metadata: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)
