"""Owner-only private-alpha authorization contract; no Discord runtime imports."""
from dataclasses import dataclass
AUTHORIZATION_CONTRACT="GUILD-DOCTOR-DISCORD-AUTHORIZATION-0.1"
@dataclass(frozen=True)
class AuthorizationInput: context_type:str; guild_id:str|None; actor_member_id:str|None; guild_owner_id:str|None; fixture_override:bool=False; packaged_runtime:bool=True
def authorize(value:AuthorizationInput)->str:
 if value.context_type!='GUILD': return 'DENY_NOT_GUILD'
 if not value.guild_id: return 'DENY_GUILD_UNAVAILABLE'
 if not value.guild_owner_id: return 'DENY_OWNER_UNRESOLVED'
 if value.fixture_override and not value.packaged_runtime: return 'ALLOW'
 return 'ALLOW' if value.actor_member_id==value.guild_owner_id else 'DENY_NOT_OWNER'
