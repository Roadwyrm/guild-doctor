"""Ten live binding declarations delegate only to Pass 3's local adapter."""
from .discord_query_adapter import DIRECT_COMMANDS
from .discord_direct_interaction_adapter import handle_direct_interaction
LIVE_COMMAND_BINDING_CONTRACT="GUILD-DOCTOR-DISCORD-LIVE-COMMAND-BINDING-0.1"
LIVE_BINDINGS={key:handle_direct_interaction for key in DIRECT_COMMANDS}
