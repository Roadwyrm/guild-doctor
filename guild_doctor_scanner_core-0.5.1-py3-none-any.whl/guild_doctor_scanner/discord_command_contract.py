"""Aggregate Stage 6 Pass 1 specification only; no Discord imports."""
from .discord_command_catalog import COMMANDS,COMMAND_CATALOG_CONTRACT
STAGE6_PASS1_CONTRACT="GUILD-DOCTOR-STAGE6-PASS1-0.1"
RESULT_STATES=('ALLOWED','DENIED','UNKNOWN','NOT_APPLICABLE','INCOMPLETE')
