"""Transport of Pass 3 neutral models; public visibility fails closed."""
INTERACTION_TRANSPORT_CONTRACT="GUILD-DOCTOR-PASS5-INTERACTION-TRANSPORT-0.1"
def ensure_ephemeral(response):
 if getattr(response,'visibility',None)!='EPHEMERAL':raise RuntimeError('PASS5_INTERACTION_SEND_FAILED')
 return {'visibility':'EPHEMERAL','content':response}
def send_pages(pages):return tuple(ensure_ephemeral(page.response) for page in pages)
def prepare_attachment(export):return {'visibility':'EPHEMERAL','filename':export.filename,'content':export.content}
