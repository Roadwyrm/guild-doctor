"""Strictly read-only Stage 3 Pass 6 live authority verification.

This module is the boundary between the reviewed GET-only Discord transport and
the pure Pass 1-6 engines.  It acquires only the objects named by a validated
scenario manifest, models the requested result, and never calls a Discord
operation endpoint.  A result is never treated as proof that an operation was
executed.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from .acquisition import ReadOnlyAcquisitionAdapter, RetryPolicy, StructureAcquisition, classify_exception, utc_now
from .action_engine import ActionOrchestrationRequest, evaluate_action_orchestration
from .action_registry import ACTION_RULES_BY_KEY
from .authority_engine import AuthorityAnalysisRequest, evaluate_authority_analysis
from .authority_registry import AUTHORITY_OPERATIONS_BY_KEY
from .capability_engine import CapabilityExpansionRequest, evaluate_capability_expansion
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY
from .closure_assessment import assess_stage3_closure, verification_backlog_from_assessment
from .constants import PERMISSION_DEFINITION_VERSION, SNAPSHOT_SCHEMA_VERSION
from .member_acquisition import minimize_member_payload
from .permission_engine import PermissionEvaluationRequest, evaluate_guild_permissions
from .permission_overwrite_engine import PermissionOverwriteEvaluationRequest, evaluate_context_permissions
from .scenario_manifest import LiveScenario, hash_identifier
from .thread_engine import ThreadResolutionRequest, evaluate_thread_permissions


LIVE_AUTHORITY_REPORT_VERSION = "GUILD-DOCTOR-STAGE3-PASS6-LIVE-REPORT-0.1"
READ_ONLY_LIVE_STATUS = "READ_ONLY_LIVE_VERIFICATION"
_ID_KEYS = {
    "id", "guild_id", "owner_id", "actor_id", "subject_id", "target_id", "context_id", "thread_id",
    "parent_id", "thread_parent_id", "thread_guild_id", "parent_channel_id", "target_channel_id",
    "overwrite_guild_id", "overwrite_target_id", "target_member_id", "assigned_or_removed_role_id",
    "actor_highest_role_id", "target_highest_role_id", "role_ids", "assigned_role_ids", "thread_owner_id",
    "source_id", "member_id", "user_id", "channel_id", "role_id", "snapshot_id",
}
_SECRET_RE = re.compile(r"(?i)(?:bot\s+)?[A-Za-z0-9_\-.]{20,}")


@dataclass(frozen=True, slots=True)
class TransportCall:
    method: str
    route_family: str
    operation: str
    outcome: str

    def as_dict(self) -> dict[str, str]:
        return {
            "http_method": self.method,
            "route_family": self.route_family,
            "operation": self.operation,
            "outcome": self.outcome,
        }


class ReadOnlyTransportAudit:
    """Record the only transport surface exposed to the live verifier."""

    __slots__ = ("_transport", "calls", "application_flags_value", "source_library", "source_library_version", "source_api_version", "adapter_version")

    _ROUTES = {
        "read_guild": "/guilds/{guild_id}",
        "read_roles": "/guilds/{guild_id}/roles",
        "read_channels": "/guilds/{guild_id}/channels",
        "read_active_threads": "/guilds/{guild_id}/threads/active",
        "read_member": "/guilds/{guild_id}/members/{member_id}",
        "read_members_page": "/guilds/{guild_id}/members",
    }

    def __init__(self, transport: Any) -> None:
        self._transport = transport
        self.calls: list[TransportCall] = []
        self.application_flags_value = getattr(transport, "application_flags_value", None)
        self.source_library = getattr(transport, "source_library", "unknown")
        self.source_library_version = getattr(transport, "source_library_version", "unknown")
        self.source_api_version = getattr(transport, "source_api_version", "unknown")
        self.adapter_version = getattr(transport, "adapter_version", "unknown")

    async def _read(self, operation: str, *args: Any, **kwargs: Any) -> Any:
        self.calls.append(TransportCall("GET", self._ROUTES[operation], operation, "STARTED"))
        try:
            result = await getattr(self._transport, operation)(*args, **kwargs)
        except BaseException:
            self.calls[-1] = TransportCall("GET", self._ROUTES[operation], operation, "FAILED")
            raise
        self.calls[-1] = TransportCall("GET", self._ROUTES[operation], operation, "COMPLETE")
        return result

    async def read_guild(self, guild_id: int) -> Any:
        return await self._read("read_guild", guild_id)

    async def read_roles(self, guild_id: int) -> Any:
        return await self._read("read_roles", guild_id)

    async def read_channels(self, guild_id: int) -> Any:
        return await self._read("read_channels", guild_id)

    async def read_active_threads(self, guild_id: int) -> Any:
        return await self._read("read_active_threads", guild_id)

    async def read_member(self, guild_id: int, member_id: int) -> Any:
        return await self._read("read_member", guild_id, member_id)

    async def read_members_page(self, guild_id: int, *, limit: int, after: int | None) -> Any:
        return await self._read("read_members_page", guild_id, limit=limit, after=after)

    def as_dict(self) -> dict[str, Any]:
        methods = [item.as_dict() for item in self.calls]
        counts = {"GET": sum(item.method == "GET" for item in self.calls), "POST": 0, "PUT": 0, "PATCH": 0, "DELETE": 0}
        return {
            "transport_contract": "GET_ONLY",
            "reviewed_source_library": self.source_library,
            "reviewed_source_library_version": self.source_library_version,
            "reviewed_source_api_version": self.source_api_version,
            "reviewed_adapter_version": self.adapter_version,
            "calls": methods,
            "http_method_counts": counts,
            "discord_write_requests": 0,
            "non_get_attempted": False,
            "audit_status": "PASS" if all(item.method == "GET" for item in self.calls) else "FAIL",
        }

    def record_login(self, *, outcome: str) -> None:
        # discord.py's static login uses the reviewed GET /users/@me endpoint.
        # Recording it here keeps authentication visible in the same audit as
        # the guild reads without exposing the credential.
        self.calls.append(TransportCall("GET", "/users/@me", "client.login", outcome))


def _canonical(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _canonical(value[key]) for key in sorted(value, key=lambda item: str(item))}
    if isinstance(value, (list, tuple)):
        return [_canonical(item) for item in value]
    if hasattr(value, "as_dict") and callable(value.as_dict):
        return _canonical(value.as_dict())
    return value


def _publicize(value: Any, *, key: str | None = None) -> Any:
    """Redact entity IDs without corrupting permission numbers or timestamps."""

    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for raw_key, raw_value in value.items():
            text_key = str(raw_key)
            public_key = hash_identifier(text_key) if text_key.isdecimal() else text_key
            result[public_key] = _publicize(raw_value, key=text_key)
        return result
    if isinstance(value, (list, tuple)):
        return [_publicize(item, key=key) for item in value]
    if key in _ID_KEYS and value is not None:
        text = str(value)
        if text and (text.isdecimal() or key == "snapshot_id"):
            return hash_identifier(text)
    if key in {"role_ids", "assigned_role_ids", "applied_tag_ids"} and isinstance(value, str):
        return hash_identifier(value) if value.isdecimal() else value
    return value


def _safe_error(exc: BaseException) -> dict[str, str]:
    message = " ".join(str(exc).split())[:500] or exc.__class__.__name__
    message = _SECRET_RE.sub("[REDACTED]", message)
    classified = classify_exception(exc if isinstance(exc, Exception) else RuntimeError(message), attempt=1)
    code = "NETWORK_TIMEOUT" if isinstance(exc, (asyncio.TimeoutError, TimeoutError)) else classified.code
    return {
        "error_type": exc.__class__.__name__,
        "code": code,
        "message": message,
    }


def _stable_structure(snapshot: Any) -> dict[str, Any]:
    if snapshot is None:
        return {"snapshot": None}
    data = snapshot.as_dict()
    keep = {
        "schema_version", "scanner_contract_version", "permission_definition_version", "guild_id",
        "structural_completeness", "member_completeness", "thread_completeness", "collections",
        "guild", "roles", "channels", "threads", "members", "thread_memberships", "bindings", "counts",
    }
    result = {key: data.get(key) for key in keep}
    result = _strip_volatile(result)
    # Volatile timestamps and payload hashes are intentionally absent from this projection.
    return _canonical(result)


def _strip_volatile(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {
            str(key): _strip_volatile(item)
            for key, item in value.items()
            if str(key) not in {"started_at", "completed_at", "requested_at", "source_observed_at", "archive_timestamp", "create_timestamp"}
        }
    if isinstance(value, list):
        return [_strip_volatile(item) for item in value]
    return value


def _stable_digest(value: Any) -> str:
    encoded = json.dumps(_canonical(value), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _member_digest(records: Mapping[str, Mapping[str, Any]]) -> str:
    stable = {
        str(member_id): {
            "roles": sorted(str(role) for role in record.get("roles", [])),
            "bot": (record.get("user") or {}).get("bot"),
            "pending": record.get("pending"),
            "communication_disabled_until": record.get("communication_disabled_until"),
        }
        for member_id, record in sorted(records.items())
    }
    return _stable_digest(stable)


async def _acquire_targeted_members(
    transport: ReadOnlyTransportAudit,
    guild_id: str,
    member_ids: set[str],
    *,
    timeout_seconds: float,
    emit: Callable[[str], None],
) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    records: dict[str, dict[str, Any]] = {}
    errors: list[dict[str, Any]] = []
    for member_id in sorted(member_ids, key=lambda item: int(item)):
        emit(f"  GET member {hash_identifier(member_id)}")
        try:
            raw = await asyncio.wait_for(transport.read_member(int(guild_id), int(member_id)), timeout=timeout_seconds)
            if not isinstance(raw, dict):
                raise TypeError("member response must be an object")
            minimized, _ = minimize_member_payload(raw)
            records[member_id] = minimized
        except BaseException as exc:
            errors.append({"member_id": hash_identifier(member_id), **_safe_error(exc)})
    return records, errors


def _role_for_member(member: Mapping[str, Any], roles: Mapping[str, Any]) -> tuple[Any | None, list[Any]]:
    role_ids = [str(item) for item in member.get("roles", [])]
    assigned = [roles[role_id] for role_id in role_ids if role_id in roles]
    everyone = [role for role in roles.values() if getattr(role, "is_everyone", False)]
    candidates = assigned + everyone
    return (max(candidates, key=lambda item: getattr(item, "position", -1)) if candidates else None), assigned


def _member_is_admin(member: Mapping[str, Any], roles: Mapping[str, Any]) -> bool | None:
    _, assigned = _role_for_member(member, roles)
    values = [int(getattr(role, "permissions_decimal", "0")) for role in assigned]
    return bool(max(values, default=0) & (1 << 3))


def _member_is_owner(member_id: str, snapshot: Any) -> bool | None:
    return str(getattr(getattr(snapshot, "guild", None), "owner_id", "")) == str(member_id)


def _role_binding(role: Any) -> str | None:
    tags = getattr(role, "role_tags", None)
    if tags is None:
        return None
    if getattr(tags, "bot_id", None):
        return "BOT"
    if getattr(tags, "integration_id", None):
        return "INTEGRATION"
    if getattr(tags, "subscription_listing_id", None):
        return "SUBSCRIPTION"
    return None


def _scenario_facts(scenario: LiveScenario, snapshot: Any, members: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    roles = snapshot.roles or {}
    channels = snapshot.channels or {}
    threads = snapshot.threads or {}
    actor = members.get(scenario.actor_member_id)
    target_member = members.get(scenario.target_id or "") if scenario.target_type == "MEMBER" else None
    target_role = roles.get(scenario.target_id or "") if scenario.target_type == "ROLE" else None
    context = channels.get(scenario.context_id or scenario.target_id or "")
    thread = threads.get(scenario.thread_id or scenario.target_id or "")
    actor_highest, _ = _role_for_member(actor or {}, roles)
    target_highest, _ = _role_for_member(target_member or {}, roles)
    return {
        "actor_is_guild_owner": _member_is_owner(scenario.actor_member_id, snapshot) if actor else None,
        "actor_role_count": len((actor or {}).get("roles", [])),
        "actor_highest_role_position": getattr(actor_highest, "position", None),
        "target_is_guild_owner": _member_is_owner(scenario.target_id or "", snapshot) if target_member else None,
        "target_has_administrator": _member_is_admin(target_member or {}, roles) if target_member else None,
        "target_highest_role_position": getattr(target_highest, "position", None),
        "target_role_managed": getattr(target_role, "managed", None),
        "target_role_is_everyone": getattr(target_role, "is_everyone", None),
        "target_role_position": getattr(target_role, "position", None),
        "target_role_binding_type": _role_binding(target_role) if target_role else None,
        "context_type": getattr(context, "type_key", None),
        "context_parent_id": getattr(context, "parent_id", None),
        "context_overwrite_count": len(getattr(context, "permission_overwrites", []) or []) if context else None,
        "thread_parent_id": getattr(thread, "parent_id", None),
        "thread_type": getattr(thread, "type_key", None),
        "thread_archived": getattr(thread, "archived", None),
        "mfa_observation": "NOT_OBSERVABLE_FOR_HUMAN_MEMBER_FROM_REVIEWED_GETS",
        "voice_observation": "UNAVAILABLE_FROM_REVIEWED_GETS",
    }


def readiness_preflight(scenarios: tuple[LiveScenario, ...], snapshot: Any, members: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    """Validate that requested live facts exist without inventing missing facts."""

    reasons: list[str] = []
    warnings: list[str] = []
    scenario_checks: list[dict[str, Any]] = []
    if snapshot is None or getattr(snapshot, "guild", None) is None:
        return {"outcome": "NOT_READY", "reasons": ["STRUCTURE_SNAPSHOT_UNAVAILABLE"], "warnings": [], "scenarios": []}
    roles = snapshot.roles or {}
    channels = snapshot.channels or {}
    threads = snapshot.threads or {}
    for scenario in scenarios:
        checks: list[str] = []
        if scenario.actor_member_id not in members:
            checks.append("ACTOR_MEMBER_UNAVAILABLE")
        if scenario.target_type == "MEMBER" and scenario.target_id not in members:
            checks.append("TARGET_MEMBER_UNAVAILABLE")
        if scenario.target_type == "ROLE" and scenario.target_id not in roles:
            checks.append("TARGET_ROLE_UNAVAILABLE")
        if scenario.target_type == "CHANNEL" and (scenario.target_id not in channels):
            checks.append("TARGET_CHANNEL_UNAVAILABLE")
        if scenario.target_type == "THREAD" and (scenario.thread_id or scenario.target_id) not in threads:
            checks.append("TARGET_THREAD_UNAVAILABLE")
        context_id = scenario.context_id or (scenario.target_id if scenario.target_type == "CHANNEL" else None)
        if context_id and context_id not in channels:
            checks.append("CONTEXT_CHANNEL_UNAVAILABLE")
        if scenario.operation_key not in ACTION_RULES_BY_KEY or scenario.operation_key not in AUTHORITY_OPERATIONS_BY_KEY and scenario.operation_key not in ACTION_RULES_BY_KEY:
            checks.append("OPERATION_NOT_REGISTERED")
        facts = _scenario_facts(scenario, snapshot, members)
        mismatches = []
        for key, expected in scenario.expected_structural_facts.items():
            if key not in facts:
                mismatches.append({"fact": key, "reason": "UNSUPPORTED_EXPECTED_FACT"})
            elif facts[key] != expected:
                mismatches.append({"fact": key, "expected": expected, "observed": facts[key]})
        checks.extend("EXPECTED_FACT_MISMATCH:" + item["fact"] for item in mismatches)
        if scenario.operation_key.startswith("voice."):
            checks.append("VOICE_STATE_NOT_EXPOSED_BY_REVIEWED_READ_TRANSPORT")
        if any(item in scenario.expected_evidence_classifications for item in {"NEEDS_LIVE_TEST", "NEEDS_WRITE_VERIFICATION"}):
            warnings.append(f"{scenario.scenario_id}: manifest explicitly retains an unresolved evidence classification")
        scenario_checks.append({
            "scenario_id": scenario.scenario_id,
            "ready": not checks,
            "checks": checks,
            "fact_mismatches": mismatches,
            "observed_facts": _publicize(facts),
        })
        reasons.extend(f"{scenario.scenario_id}:{item}" for item in checks)
    structure_complete = getattr(snapshot, "structural_completeness", None) == "COMPLETE"
    if not structure_complete:
        reasons.append("STRUCTURAL_COMPLETENESS_NOT_COMPLETE")
    if reasons and not any(item["ready"] for item in scenario_checks):
        outcome = "NOT_READY"
    elif reasons:
        outcome = "PARTIALLY_READY"
    else:
        outcome = "READY"
    return {"outcome": outcome, "reasons": sorted(set(reasons)), "warnings": sorted(set(warnings)), "scenarios": scenario_checks}


def _pass3_projection(pass1: Any, capability_key: str) -> dict[str, Any]:
    """Project a guild-level Pass 1 permission into the Pass 6 component shape.

    Discord's reviewed context-overwrite engine has no GUILD context type.  This
    projection preserves the live Pass 1 permission value and marks the source
    as a modeled guild-scope projection rather than pretending a channel GET
    supplied a context result.
    """

    raw = getattr(pass1, "raw_guild_permission_decimal", None)
    granted = False
    for contribution in getattr(pass1, "assigned_role_contributions", ()):
        if getattr(contribution, "permission_decimal", None) is not None:
            granted = granted or bool(int(getattr(contribution, "permission_decimal")) & 0)
    try:
        from .capability_registry import DEFAULT_CAPABILITY_REGISTRY
        definition = next(item for item in DEFAULT_CAPABILITY_REGISTRY.capabilities if item.capability_key == capability_key)
        flag = next(item for item in DEFAULT_CAPABILITY_REGISTRY.permission_flags if item.name == definition.source_permission_flag)
        granted = bool(int(raw or 0) & (1 << flag.bit))
    except (StopIteration, TypeError, ValueError, AttributeError):
        granted = False
    record = {
        "capability_key": capability_key,
        "final_result": "ALLOWED" if granted else "DENIED",
        "verification_status": "LIVE_DERIVED_STRUCTURE",
        "source_references": [],
    }
    return {
        "engine_contract_version": "GUILD-DOCTOR-STAGE3-PASS3-0.1",
        "pass2_contract_version": "GUILD-DOCTOR-STAGE3-PASS2-0.1",
        "pass1_contract_version": getattr(pass1, "engine_contract_version", None),
        "capability_registry_version": "GUILD-DOCTOR-CAPABILITY-REGISTRY-0.1",
        "permission_definition_version": PERMISSION_DEFINITION_VERSION,
        "snapshot_or_fixture_version": SNAPSHOT_SCHEMA_VERSION,
        "guild_id": getattr(pass1, "guild_id", None),
        "subject_id": getattr(pass1, "subject_id", None),
        "context_id": None,
        "context_type": "GUILD",
        "completeness_state": getattr(pass1, "completeness_state", "UNKNOWN"),
        "input_health_state": getattr(pass1, "input_health_state", "UNKNOWN"),
        "raw_permission_bits_unchanged": True,
        "effective_capability_records": [record] if granted else [],
        "ineffective_grant_records": [],
        "denied_capability_records": [record] if not granted else [],
        "unknown_capability_records": [],
        "inapplicable_capability_records": [],
        "policy_only_category_records": [],
        "projection_status": "GUILD_SCOPE_FROM_LIVE_PASS1",
    }


def _model_scenario(
    scenario: LiveScenario,
    snapshot: Any,
    members: Mapping[str, Mapping[str, Any]],
    *,
    actor_mfa_state: str = "UNKNOWN",
    publicize_result: bool = True,
) -> dict[str, Any]:
    roles = snapshot.roles or {}
    channels = snapshot.channels or {}
    threads = snapshot.threads or {}
    actor = members.get(scenario.actor_member_id, {})
    actor_highest, _ = _role_for_member(actor, roles)
    operation = AUTHORITY_OPERATIONS_BY_KEY.get(scenario.operation_key)
    action_rule = ACTION_RULES_BY_KEY.get(scenario.operation_key)
    input_health = {"state": "COMPLETE", "source": "LIVE_GET_ONLY", "member_records": len(members)}
    p1 = evaluate_guild_permissions(PermissionEvaluationRequest(
        guild_id=snapshot.guild_id,
        guild_owner_id=snapshot.guild.owner_id,
        subject_id=scenario.actor_member_id,
        assigned_role_ids=actor.get("roles", []),
        role_records=roles,
        permission_definition_version=PERMISSION_DEFINITION_VERSION,
        snapshot_or_fixture_version=SNAPSHOT_SCHEMA_VERSION,
        input_health=input_health,
    ))
    context_id = scenario.context_id or (scenario.target_id if scenario.target_type == "CHANNEL" else None)
    channel = channels.get(context_id or "")
    p2 = None
    p3: Any = None
    if channel is not None:
        p2 = evaluate_context_permissions(PermissionOverwriteEvaluationRequest(
            guild_id=snapshot.guild_id,
            subject_id=scenario.actor_member_id,
            assigned_role_ids=actor.get("roles", []),
            guild_permission_result=p1,
            context_id=channel.id,
            context_type=channel.type_key,
            context_guild_id=channel.guild_id,
            context_parent_id=channel.parent_id,
            context_sync_state=channel.sync_state,
            context_permission_overwrites=channel.permission_overwrites,
            normalized_roles=roles,
            permission_definition_version=PERMISSION_DEFINITION_VERSION,
            snapshot_or_fixture_version=SNAPSHOT_SCHEMA_VERSION,
            input_health=input_health,
        ))
        p3_request = CapabilityExpansionRequest.from_pass2_result(
            p2,
            timeout_state="INACTIVE",
            input_health=input_health,
            capability_registry=DEFAULT_CAPABILITY_REGISTRY,
        )
        p3 = evaluate_capability_expansion(p3_request)
    elif operation is not None:
        p3 = _pass3_projection(p1, operation.capability_key)

    p4 = None
    thread = threads.get(scenario.thread_id or scenario.target_id or "")
    if thread is not None and channel is not None and p2 is not None and p3 is not None:
        p4 = evaluate_thread_permissions(ThreadResolutionRequest(
            pass2_parent_result=p2,
            pass3_parent_result=p3,
            parent_channel_id=channel.id,
            parent_channel_type=channel.type_key,
            parent_guild_id=channel.guild_id,
            thread_id=thread.id,
            thread_guild_id=thread.guild_id,
            thread_parent_id=thread.parent_id,
            thread_type=thread.type_key,
            thread_owner_id=thread.owner_id,
            archived_state=thread.archived,
            locked_state=thread.locked,
            invitable_state=thread.invitable,
            auto_archive_duration=thread.auto_archive_duration,
            archive_timestamp=thread.archive_timestamp,
            thread_record=thread,
            parent_channel_record=channel,
            thread_source_health=input_health,
            subject_id=scenario.actor_member_id,
            bypass_state=getattr(p1, "bypass_state", None),
            timeout_state="INACTIVE",
            membership_state="UNKNOWN",
            membership_source_health={"state": "NOT_ACQUIRED", "reason": "reviewed transport does not expose arbitrary thread membership"},
            membership_records=None,
            thread_permission_overwrites=channel.permission_overwrites,
            input_health=input_health,
            pass1_contract_version=getattr(p1, "engine_contract_version", None),
            pass2_contract_version=getattr(p2, "engine_contract_version", None),
            pass3_contract_version=getattr(p3, "engine_contract_version", None),
            capability_registry_version="GUILD-DOCTOR-CAPABILITY-REGISTRY-0.1",
            permission_definition_version=PERMISSION_DEFINITION_VERSION,
            snapshot_or_fixture_version=SNAPSHOT_SCHEMA_VERSION,
        ))

    p5 = None
    if operation is not None:
        target_member = members.get(scenario.target_id or "", {}) if scenario.target_type == "MEMBER" else {}
        target_role = roles.get(scenario.target_id or "") if scenario.target_type == "ROLE" else None
        target_highest, _ = _role_for_member(target_member, roles)
        p5 = evaluate_authority_analysis(AuthorityAnalysisRequest(
            operation_key=scenario.operation_key,
            guild_id=snapshot.guild_id,
            guild_owner_id=snapshot.guild.owner_id,
            actor_id=scenario.actor_member_id,
            actor_kind="BOT" if (actor.get("user") or {}).get("bot") is True else "HUMAN",
            target_type=scenario.target_type,
            target_id=scenario.target_id,
            permission_definition_version=PERMISSION_DEFINITION_VERSION,
            pass1_contract_version=getattr(p1, "engine_contract_version", None),
            pass2_contract_version=getattr(p2, "engine_contract_version", "GUILD-DOCTOR-STAGE3-PASS2-0.1") if p2 is not None else "GUILD-DOCTOR-STAGE3-PASS2-0.1",
            pass3_contract_version=getattr(p3, "engine_contract_version", "GUILD-DOCTOR-STAGE3-PASS3-0.1") if p3 is not None else "GUILD-DOCTOR-STAGE3-PASS3-0.1",
            pass4_contract_version=getattr(p4, "engine_contract_version", "GUILD-DOCTOR-STAGE3-PASS4-0.1") if p4 is not None else "GUILD-DOCTOR-STAGE3-PASS4-0.1",
            snapshot_or_fixture_version=SNAPSHOT_SCHEMA_VERSION,
            capability_permission_result=p3,
            capability_result=p3,
            source_capability_key=operation.capability_key,
            required_source_permission_flags=operation.required_source_permission_flags,
            actor_raw_guild_permissions_decimal=getattr(p1, "raw_guild_permission_decimal", None),
            actor_raw_guild_permissions_hex=getattr(p1, "raw_guild_permission_hex", None),
            actor_raw_context_permissions_decimal=getattr(p2, "effective_permission_decimal", None) if p2 else None,
            actor_raw_context_permissions_hex=getattr(p2, "effective_permission_hex", None) if p2 else None,
            actor_bypass_state=getattr(p1, "bypass_state", None),
            actor_highest_role_id=getattr(actor_highest, "id", None),
            actor_highest_role_position=getattr(actor_highest, "position", None),
            actor_role_order_health={"state": "COMPLETE"},
            actor_is_guild_owner=_member_is_owner(scenario.actor_member_id, snapshot),
            actor_is_bot=(actor.get("user") or {}).get("bot"),
            actor_mfa_state=actor_mfa_state,
            target_is_guild_owner=_member_is_owner(scenario.target_id or "", snapshot) if target_member else None,
            target_has_administrator=_member_is_admin(target_member, roles) if target_member else None,
            target_highest_role_id=getattr(target_highest, "id", None),
            target_highest_role_position=getattr(target_highest, "position", None),
            target_role_managed=getattr(target_role, "managed", None),
            target_role_tags={"binding_type": _role_binding(target_role)} if target_role else None,
            target_role_binding_type=_role_binding(target_role) if target_role else None,
            target_role_is_everyone=getattr(target_role, "is_everyone", None),
            target_role_source_health={"state": "COMPLETE"} if target_role else None,
            guild_mfa_level=getattr(snapshot.guild, "mfa_level", None),
            relevant_elevated_permission_flag=operation.mfa_permission_flag,
            mfa_source_health={"state": "GUILD_MFA_LIVE_ACTOR_MFA_NOT_OBSERVABLE"},
            target_currently_connected_to_voice=None,
            context_guild_id=getattr(channel, "guild_id", None) if channel else None,
            parent_channel_id=getattr(channel, "parent_id", None) if channel else None,
            target_channel_id=getattr(channel, "id", None) if channel else None,
            input_health=input_health,
            evidence_classification="LIVE_DERIVED_STRUCTURE",
            verification_status="READ_ONLY_LIVE_VERIFICATION",
            source_references=operation.source_references,
        ))

    action = evaluate_action_orchestration(ActionOrchestrationRequest(
        operation_key=scenario.operation_key,
        guild_id=snapshot.guild_id,
        actor_id=scenario.actor_member_id,
        subject_id=scenario.actor_member_id,
        target_type=scenario.target_type,
        target_id=scenario.target_id,
        context_id=context_id,
        context_type=getattr(channel, "type_key", "GUILD") if channel else "GUILD",
        thread_id=getattr(thread, "id", None),
        thread_type=getattr(thread, "type_key", None),
        bypass_state=getattr(p1, "bypass_state", None),
        capability_result=p3,
        thread_result=p4,
        authority_result=p5,
        input_health=input_health,
        evidence_classifications=("LIVE_DERIVED_ACTOR", "LIVE_DERIVED_STRUCTURE", "MODELED_RESULT"),
        verification_statuses=("READ_ONLY_LIVE_VERIFICATION",),
        pass1_contract_version=getattr(p1, "engine_contract_version", None),
        pass2_contract_version=getattr(p2, "engine_contract_version", "GUILD-DOCTOR-STAGE3-PASS2-0.1") if p2 is not None else "GUILD-DOCTOR-STAGE3-PASS2-0.1",
        pass3_contract_version=getattr(p3, "engine_contract_version", "GUILD-DOCTOR-STAGE3-PASS3-0.1") if p3 is not None else "GUILD-DOCTOR-STAGE3-PASS3-0.1",
        pass4_contract_version=getattr(p4, "engine_contract_version", "GUILD-DOCTOR-STAGE3-PASS4-0.1") if p4 is not None else "GUILD-DOCTOR-STAGE3-PASS4-0.1",
        pass5_contract_version=getattr(p5, "engine_contract_version", "GUILD-DOCTOR-STAGE3-PASS5-0.1") if p5 is not None else "GUILD-DOCTOR-STAGE3-PASS5-0.1",
        capability_registry_version="GUILD-DOCTOR-CAPABILITY-REGISTRY-0.1",
        thread_rules_version="GUILD-DOCTOR-THREAD-RULES-0.1",
        authority_rules_version="GUILD-DOCTOR-AUTHORITY-RULES-0.1",
        object_preconditions_version="GUILD-DOCTOR-OBJECT-PRECONDITIONS-0.1",
        mfa_rules_version="GUILD-DOCTOR-MFA-RULES-0.1",
        permission_definition_version=PERMISSION_DEFINITION_VERSION,
        snapshot_or_fixture_version=SNAPSHOT_SCHEMA_VERSION,
    ))
    result = action.as_dict()
    result["endpoint_success_verified"] = False
    result["discord_write_requests"] = 0
    result["decision_basis"] = "PRE_EXECUTION_MODEL"
    result["execution_attempted"] = False
    result["execution_guarantee"] = False
    result["evidence_classifications"] = sorted(set(result.get("evidence_classifications", [])) | {"MODELED_RESULT"})
    result["live_component_facts"] = _publicize(_scenario_facts(scenario, snapshot, members))
    return _publicize(result) if publicize_result else result


def model_read_only_scenario(
    scenario: LiveScenario,
    snapshot: Any,
    members: Mapping[str, Mapping[str, Any]],
    *,
    actor_mfa_state: str = "UNKNOWN",
    publicize_result: bool = True,
) -> dict[str, Any]:
    """Run the frozen Pass 1-6 pre-execution path over supplied data only.

    This additive public boundary exists for token-free replay.  It performs no
    acquisition and exposes no endpoint capable of changing Discord state.
    """

    return _model_scenario(
        scenario,
        snapshot,
        members,
        actor_mfa_state=actor_mfa_state,
        publicize_result=publicize_result,
    )


async def run_read_only_live_verification(
    transport: Any,
    scenarios: tuple[LiveScenario, ...],
    *,
    timeout_seconds: float = 30.0,
    retry_policy: RetryPolicy | None = None,
    emit: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """Acquire, compare, and model a manifest without any Discord writes."""

    if timeout_seconds <= 0:
        raise ValueError("timeout_seconds must be positive")
    emit = emit or (lambda message: None)
    guild_id = scenarios[0].guild_id if scenarios else None
    audit = ReadOnlyTransportAudit(transport)
    started_at = utc_now()
    if not scenarios:
        return _failure_run("SCENARIO_MANIFEST_EMPTY", audit, started_at)
    structure_adapter = ReadOnlyAcquisitionAdapter(
        audit,
        retry_policy=retry_policy,
        operation_timeout_seconds=timeout_seconds,
    )
    emit("STAGE 1/6: acquiring first read-only structure snapshot")
    first = await structure_adapter.acquire_structure(int(guild_id))
    member_ids = {scenario.actor_member_id for scenario in scenarios}
    member_ids.update(scenario.target_id for scenario in scenarios if scenario.target_type == "MEMBER" and scenario.target_id)
    emit("STAGE 2/6: acquiring explicitly authorized actor/target members")
    first_members, first_member_errors = await _acquire_targeted_members(
        audit, guild_id, member_ids, timeout_seconds=timeout_seconds, emit=emit
    )
    emit("STAGE 3/6: repeating read-only structure acquisition")
    second = await structure_adapter.acquire_structure(int(guild_id))
    emit("STAGE 4/6: repeating actor/target member acquisition")
    second_members, second_member_errors = await _acquire_targeted_members(
        audit, guild_id, member_ids, timeout_seconds=timeout_seconds, emit=emit
    )
    first_stable = _stable_structure(first.snapshot)
    second_stable = _stable_structure(second.snapshot)
    structure_digest_1 = _stable_digest(first_stable)
    structure_digest_2 = _stable_digest(second_stable)
    member_digest_1 = _member_digest(first_members)
    member_digest_2 = _member_digest(second_members)
    repeated_status = "STABLE"
    if first.snapshot is None or second.snapshot is None or first_member_errors or second_member_errors:
        repeated_status = "INCOMPLETE"
    elif structure_digest_1 != structure_digest_2 or member_digest_1 != member_digest_2:
        repeated_status = "DRIFT_DETECTED"
    preflight = readiness_preflight(scenarios, first.snapshot, first_members)
    emit("STAGE 5/6: running pure Pass 1-6 pre-execution models")
    action_results: list[dict[str, Any]] = []
    repeated_action_results: list[dict[str, Any]] = []
    model_errors: list[dict[str, Any]] = []
    if first.snapshot is not None and not first_member_errors:
        for scenario in scenarios:
            try:
                action_results.append(_model_scenario(scenario, first.snapshot, first_members))
            except BaseException as exc:
                model_errors.append({"scenario_id": scenario.scenario_id, **_safe_error(exc)})
    else:
        model_errors.append({"scenario_id": None, "code": "STRUCTURE_OR_MEMBER_INPUT_INCOMPLETE", "message": first.normalization_error or "actor/target member acquisition incomplete"})
    if second.snapshot is not None and not second_member_errors:
        for scenario in scenarios:
            try:
                repeated_action_results.append(_model_scenario(scenario, second.snapshot, second_members))
            except BaseException as exc:
                model_errors.append({"scenario_id": scenario.scenario_id, "repeat": True, **_safe_error(exc)})
    deterministic = _stable_digest(action_results) == _stable_digest(repeated_action_results)
    emit("STAGE 6/6: preparing read-only closure assessment")
    backlog: list[dict[str, Any]] = []
    scenario_by_id = {scenario.scenario_id: scenario for scenario in scenarios}
    for item in preflight.get("scenarios", []):
        if not item["ready"]:
            scenario = scenario_by_id.get(item["scenario_id"])
            backlog.append({
                "blocker_id": f"SCENARIO_NOT_READY:{item['scenario_id']}",
                "scenario_id": item["scenario_id"],
                "operation_key": scenario.operation_key if scenario else None,
                "target_type": scenario.target_type if scenario else None,
                "reason_code": "MISSING_REQUIRED_LIVE_SCENARIO_EVIDENCE",
                "detail": f"Scenario {item['scenario_id']} is not ready: {item['checks']}",
                "reason_codes": item["checks"],
                "required_evidence": item["checks"],
                "safe_next_action": "Resolve the exact scenario readiness checks using approved GET-only acquisition.",
            })
    backlog.extend({
        "blocker_id": f"MODEL_ERROR:{item.get('scenario_id')}:{item['code']}",
        "scenario_id": item.get("scenario_id"),
        "reason_code": item["code"],
        "detail": item.get("message", "A scenario model failed."),
        "required_evidence": ["action_results"],
        "safe_next_action": "Resolve the named model or input error without adding a Discord write operation.",
    } for item in model_errors)
    if first_member_errors or second_member_errors:
        for error in [*first_member_errors, *second_member_errors]:
            backlog.append({
                "blocker_id": f"MEMBER_ACQUISITION:{error.get('member_id')}:{error.get('code')}",
                "operation_key": "member.acquire",
                "target_type": "MEMBER",
                "reason_code": error.get("code", "MEMBER_ACQUISITION_INCOMPLETE"),
                "detail": error.get("message", "An explicitly authorized member record was not acquired."),
                "required_evidence": ["target member record"],
                "safe_next_action": "Resolve the bounded GET-only member acquisition failure.",
            })
    expected_mismatches = []
    for scenario, item in zip(scenarios, action_results):
        observed = item.get("final_result")
        if scenario.expected_modeled_result is not None and observed != scenario.expected_modeled_result:
            expected_mismatches.append({"scenario_id": scenario.scenario_id, "expected": scenario.expected_modeled_result, "observed": observed})
    audit_dict = audit.as_dict()
    report = {
        "contract": LIVE_AUTHORITY_REPORT_VERSION,
        "live_support_contract": "GUILD-DOCTOR-LIVE-AUTHORITY-VERIFY-0.1",
        "overall_status": "PENDING",
        "live_execution": True,
        "read_only": True,
        "guild_id": hash_identifier(guild_id),
        "started_at": started_at,
        "completed_at": utc_now(),
        "readiness_preflight": preflight,
        "repeated_acquisition": {"status": repeated_status, "first_structure_fingerprint": structure_digest_1, "repeated_structure_fingerprint": structure_digest_2, "first_member_fingerprint": member_digest_1, "repeated_member_fingerprint": member_digest_2},
        "determinism": {"status": "STABLE" if deterministic else "DRIFT_DETECTED", "model_repeat_strategy": "REPEATED_LIVE_INPUT_PROJECTION", "first_result_fingerprint": _stable_digest(action_results), "repeated_result_fingerprint": _stable_digest(repeated_action_results)},
        "scenario_count_requested": len(scenarios),
        "scenario_count_evaluated": len(action_results),
        "ids_redacted_or_hashed": True,
        "discord_write_requests": 0,
        "execution_flags": {"decision_basis": "PRE_EXECUTION_MODEL", "execution_attempted": False, "execution_guarantee": False, "endpoint_success_verified": False},
        "needs_live_test": [],
        "needs_write_verification": [],
        "expected_result_mismatches": expected_mismatches,
        "model_errors": model_errors,
    }
    closure_assessment = assess_stage3_closure(
        authority_report=report,
        verification_backlog={"items": backlog},
        action_results=action_results,
        scenarios=scenarios,
        live_snapshot=first.snapshot.as_dict() if first.snapshot else None,
        repeated_snapshot=second.snapshot.as_dict() if second.snapshot else None,
        transport_audit=audit_dict,
    )
    report["overall_status"] = closure_assessment["status"]
    report["needs_live_test"] = closure_assessment["needs_live_test"]
    report["needs_write_verification"] = closure_assessment["needs_write_verification"]
    report["closure_decision"] = closure_assessment["decision"]
    return {
        "authority_verification_report": report,
        "authority_live_snapshot": _publicize(first.snapshot.as_dict() if first.snapshot else None),
        "repeated_authority_live_snapshot": _publicize(second.snapshot.as_dict() if second.snapshot else None),
        "action_results": action_results,
        "acquisition_health": {
            "first": _publicize({name: item.as_dict() for name, item in first.results.items()}),
            "repeated": _publicize({name: item.as_dict() for name, item in second.results.items()}),
            "first_member_errors": first_member_errors,
            "repeated_member_errors": second_member_errors,
            "normalization_errors": [first.normalization_error, second.normalization_error],
        },
        "scenario_manifest_redacted": {"contract": "GUILD-DOCTOR-STAGE3-PASS6-SCENARIOS-0.1", "scenarios": [scenario.as_redacted_dict() for scenario in scenarios]},
        "verification_backlog": verification_backlog_from_assessment(closure_assessment),
        "transport_audit": audit.as_dict(),
        "stage3_closure_assessment": closure_assessment,
    }


def _failure_run(reason: str, audit: ReadOnlyTransportAudit, started_at: str) -> dict[str, Any]:
    report = {
        "contract": LIVE_AUTHORITY_REPORT_VERSION,
        "overall_status": "FAIL",
        "live_execution": False,
        "read_only": True,
        "failure_code": reason,
        "started_at": started_at,
        "completed_at": utc_now(),
        "ids_redacted_or_hashed": True,
        "discord_write_requests": 0,
        "execution_flags": {"decision_basis": "PRE_EXECUTION_MODEL", "execution_attempted": False, "execution_guarantee": False, "endpoint_success_verified": False},
        "closure_decision": "STAGE3_IN_PROGRESS_LIVE_VERIFICATION_PENDING",
    }
    return {
        "authority_verification_report": report,
        "authority_live_snapshot": None,
        "repeated_authority_live_snapshot": None,
        "action_results": [],
        "acquisition_health": {},
        "scenario_manifest_redacted": {"contract": "GUILD-DOCTOR-STAGE3-PASS6-SCENARIOS-0.1", "scenarios": []},
        "verification_backlog": {"items": [{"status": "NEEDS_LIVE_TEST", "reasons": [reason]}]},
        "transport_audit": audit.as_dict(),
        "stage3_closure_assessment": {"status": "PENDING", "decision": "STAGE3_IN_PROGRESS_LIVE_VERIFICATION_PENDING", "reasons": [reason]},
    }


__all__ = [
    "LIVE_AUTHORITY_REPORT_VERSION",
    "ReadOnlyTransportAudit",
    "TransportCall",
    "model_read_only_scenario",
    "readiness_preflight",
    "run_read_only_live_verification",
]
