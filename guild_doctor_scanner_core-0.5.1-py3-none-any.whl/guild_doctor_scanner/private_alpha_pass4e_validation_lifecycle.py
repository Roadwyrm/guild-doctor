"""Production lifecycle glue for the temporary Pass 4E validation surface."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .private_alpha_configuration import PrivateAlphaConfiguration
from .private_alpha_live_interaction_runtime import (
    LiveInteractionPreflightResult,
    RuntimeStartResult,
    start_bounded_gateway_runtime,
)
from .private_alpha_live_validation_configuration import LiveValidationConfiguration
from .private_alpha_pass4e_repair4_runner import EXACT_START_PHRASE
from .private_alpha_pass4e_runtime_receipt import record_cleanup_sync_in_receipt
from .private_alpha_pass4e_session_artifacts import SessionArtifactPaths
from .private_alpha_pass4e_validation_authority import (
    VALIDATION_AUTHORITY_CONTRACT,
    ValidationAuthorityBinding,
    ValidationAuthorityError,
    ValidationAuthorityRecord,
    ValidationAuthorityStore,
    ValidationRuntimeAuthority,
    as_validation_runtime_authority,
    build_validation_authority_binding,
    validate_validation_authority_binding,
)
from .private_alpha_pass4e_validation_surface import (
    ValidationSurfaceMode,
    serialized_validation_schema_fingerprint,
    validation_manifest_fingerprint,
)
from .private_alpha_pass4e_validation_sync import (
    SyncOperationBudget,
    SyncProof,
    SyncProofStore,
    ValidationSyncError,
    execute_typed_guild_sync,
    validate_sync_proof,
)


VALIDATION_LIFECYCLE_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4E-VALIDATION-LIFECYCLE-0.1"
CLEANUP_INCOMPLETE = "STAGE8_PASS4E_REPAIR4D21_FAILED_CLOSED / TEMPORARY_SURFACE_CLEANUP_INCOMPLETE"


@dataclass(frozen=True, slots=True)
class ValidationCleanupResult:
    state: str
    stable_error: str | None
    cleanup_verified: bool
    temporary_route_removed: bool
    total_sync_writes: int
    global_sync_writes: int
    other_guild_sync_writes: int


@dataclass(frozen=True, slots=True)
class ValidationClosureAssessment:
    state: str
    live_state: str
    cleanup_state: str
    pass4e_closure_eligible: bool
    stable_error: str | None


def pre_live_sync_proof_path(artifacts: SessionArtifactPaths) -> Path:
    validated = artifacts.validated()
    return validated.authority_path.with_name(validated.authority_path.stem + "_validation_sync_proof.json")


def cleanup_sync_proof_path(artifacts: SessionArtifactPaths) -> Path:
    validated = artifacts.validated()
    return validated.authority_path.with_name(validated.authority_path.stem + "_cleanup_sync_proof.json")


def issue_validation_authority(
    *, store: ValidationAuthorityStore, base_binding: Any, configuration: PrivateAlphaConfiguration,
    pre_live_sync_proof: SyncProof, issuance_reference: str,
    identifier_factory: Callable[[], str] | None = None,
) -> tuple[ValidationAuthorityBinding, ValidationAuthorityRecord]:
    validate_sync_proof(pre_live_sync_proof, mode=ValidationSurfaceMode.PASS4E_VALIDATION, configuration=configuration)
    binding = build_validation_authority_binding(
        base_binding=base_binding, authorized_target_binding_fingerprint=configuration.fingerprint,
        pre_live_sync_proof_fingerprint=pre_live_sync_proof.proof_fingerprint,
    )
    kwargs = {} if identifier_factory is None else {"identifier_factory": identifier_factory}
    record = store.issue(binding, issuance_reference=issuance_reference, **kwargs)
    return binding, record


def resume_validation_authority(
    *, phrase: str, issuance_reference: str, store: ValidationAuthorityStore,
    binding: ValidationAuthorityBinding, configuration: PrivateAlphaConfiguration,
    pre_live_sync_proof: SyncProof,
) -> ValidationRuntimeAuthority:
    if phrase != EXACT_START_PHRASE:
        raise ValidationAuthorityError("STAGE8_PASS4E_REPAIR4_START_PHRASE_REQUIRED")
    if issuance_reference != binding.base_binding.issuance_reference:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_REFERENCE_MISMATCH")
    validate_sync_proof(pre_live_sync_proof, mode=ValidationSurfaceMode.PASS4E_VALIDATION, configuration=configuration)
    validate_validation_authority_binding(binding)
    if binding.pre_live_sync_proof_fingerprint != pre_live_sync_proof.proof_fingerprint:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_SYNC_PROOF_MISMATCH")
    record = store.consume(binding)
    return as_validation_runtime_authority(record)


def validate_runtime_mode_binding(
    authority: ValidationRuntimeAuthority, *, configuration: PrivateAlphaConfiguration,
    pre_live_sync_proof: SyncProof,
) -> None:
    if not isinstance(authority, ValidationRuntimeAuthority) or authority.authority_contract != VALIDATION_AUTHORITY_CONTRACT:
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_AUTHORITY_0_3_REQUIRED")
    validate_sync_proof(pre_live_sync_proof, mode=ValidationSurfaceMode.PASS4E_VALIDATION, configuration=configuration)
    checks = (
        authority.validation_surface_required is True,
        authority.validation_surface_mode == ValidationSurfaceMode.PASS4E_VALIDATION.value,
        authority.authorized_target_binding_fingerprint == configuration.fingerprint,
        authority.pre_live_sync_proof_fingerprint == pre_live_sync_proof.proof_fingerprint,
        authority.global_sync_prohibited is True,
        authority.other_guild_sync_prohibited is True,
        authority.runtime_receipt_contract_version == "0.3",
    )
    if not all(checks):
        raise ValidationAuthorityError("STAGE8_PASS4E_VALIDATION_RUNTIME_MODE_BINDING_INVALID")


async def start_validation_gateway_runtime(
    *, authority: ValidationRuntimeAuthority, preflight: LiveInteractionPreflightResult,
    active_configuration: PrivateAlphaConfiguration, live_configuration: LiveValidationConfiguration,
    pre_live_sync_proof: SyncProof, project_root: Path, snapshot_path: Path,
    runtime_receipt_path: Path, session_artifacts: SessionArtifactPaths | None,
    token_provider: Callable[[], str], client_factory: Callable[[Any], Any] | None = None,
    ready_observer: Callable[[], None] | None = None,
    discord_module=None,
) -> RuntimeStartResult:
    validate_runtime_mode_binding(authority, configuration=active_configuration, pre_live_sync_proof=pre_live_sync_proof)
    return await start_bounded_gateway_runtime(
        authority=authority.base_runtime_authority, preflight=preflight,
        active_configuration=active_configuration, live_configuration=live_configuration,
        project_root=project_root, snapshot_path=snapshot_path,
        runtime_receipt_path=runtime_receipt_path, session_artifacts=session_artifacts,
        token_provider=token_provider, client_factory=client_factory,
        runtime_receipt_initializer=lambda receipt: receipt.pre_live_sync_bound(validation_manifest_binding_validated=True),
        validation_surface_mode=ValidationSurfaceMode.PASS4E_VALIDATION,
        ready_observer=ready_observer,
        discord_module=discord_module,
    )


async def execute_mandatory_cleanup(
    *, transport: Any, configuration: PrivateAlphaConfiguration, budget: SyncOperationBudget,
    proof_store: SyncProofStore, runtime_receipt_path: Path,
) -> ValidationCleanupResult:
    try:
        if budget.validation_write_count != 1 or budget.cleanup_write_count != 0:
            raise ValidationSyncError("STAGE8_PASS4E_CLEANUP_PRE_LIVE_SYNC_REQUIRED")
        proof = await execute_typed_guild_sync(
            transport=transport, configuration=configuration, mode=ValidationSurfaceMode.CLEANUP,
            budget=budget, proof_store=proof_store,
            expected_manifest_fingerprint=validation_manifest_fingerprint(ValidationSurfaceMode.CLEANUP),
            expected_schema_fingerprint=serialized_validation_schema_fingerprint(ValidationSurfaceMode.CLEANUP),
        )
        record_cleanup_sync_in_receipt(
            runtime_receipt_path, verified=True, temporary_route_removed=proof.temporary_route_count == 0,
            total_sync_writes=budget.total_write_count, global_sync_writes=budget.global_write_count,
            other_guild_sync_writes=budget.other_guild_write_count,
        )
    except Exception:
        return ValidationCleanupResult(
            "FAILED_CLOSED", CLEANUP_INCOMPLETE, False, False, budget.total_write_count,
            budget.global_write_count, budget.other_guild_write_count,
        )
    return ValidationCleanupResult(
        "PASS", None, True, True, budget.total_write_count,
        budget.global_write_count, budget.other_guild_write_count,
    )


def assess_validation_closure(*, live_state: str, cleanup: ValidationCleanupResult) -> ValidationClosureAssessment:
    if cleanup.state != "PASS" or not cleanup.cleanup_verified or not cleanup.temporary_route_removed:
        return ValidationClosureAssessment("FAILED_CLOSED", live_state, cleanup.state, False, CLEANUP_INCOMPLETE)
    if live_state != "PASS":
        return ValidationClosureAssessment("FAILED_CLOSED", live_state, cleanup.state, False, "STAGE8_PASS4E_LIVE_SESSION_FAILED_CLOSED")
    return ValidationClosureAssessment("PASS", live_state, cleanup.state, True, None)


__all__ = [
    "CLEANUP_INCOMPLETE", "VALIDATION_LIFECYCLE_CONTRACT", "ValidationCleanupResult",
    "ValidationClosureAssessment", "assess_validation_closure", "cleanup_sync_proof_path",
    "execute_mandatory_cleanup", "issue_validation_authority", "pre_live_sync_proof_path",
    "resume_validation_authority", "start_validation_gateway_runtime", "validate_runtime_mode_binding",
]
