"""Offline validator for Stage 3 Pass 6 scenario manifests.

This command reads only the supplied JSON file.  It does not read the bot
token, import discord.py, open a network connection, or create output files.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

from .scenario_manifest import hash_identifier, load_scenario_manifest


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Validate a Guild Doctor Stage 3 Pass 6 manifest without logging in or contacting Discord"
    )
    parser.add_argument("manifest", type=Path, help="Completed stage3-pass6-scenarios.json")
    parser.add_argument("--guild-id", help="Optional positive decimal Guild ID to cross-check against the manifest")
    return parser


def _parse_guild_id(value: Any) -> str:
    text = str(value).strip()
    if not text.isdecimal() or int(text) <= 0:
        raise ValueError("--guild-id must be a positive decimal snowflake")
    return str(int(text))


def _error(message: str) -> None:
    print(f"guild-doctor-stage3-authority-manifest-validate: {message}", file=sys.stderr, flush=True)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        scenarios = load_scenario_manifest(args.manifest)
        manifest_guild_id = scenarios[0].guild_id
        if args.guild_id is not None and _parse_guild_id(args.guild_id) != manifest_guild_id:
            raise ValueError("--guild-id does not match the manifest Guild ID")
    except (OSError, ValueError, TypeError) as exc:
        _error("validation failed: " + (" ".join(str(exc).split()) or exc.__class__.__name__))
        return 2

    print("Guild Doctor Stage 3 Pass 6 manifest validation: PASS", flush=True)
    print(f"contract: GUILD-DOCTOR-STAGE3-PASS6-SCENARIOS-0.1", flush=True)
    print(f"guild_id: {hash_identifier(manifest_guild_id)}", flush=True)
    print(f"scenario_count: {len(scenarios)}", flush=True)
    for scenario in scenarios:
        print(
            f"scenario: {scenario.scenario_id} operation={scenario.operation_key} "
            f"target={scenario.target_type} status={scenario.verification_status}",
            flush=True,
        )
    print("network: NOT_CONTACTED", flush=True)
    print("token: NOT_READ", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
