"""Narrow intent declaration for future slash-command deployment."""
RUNTIME_INTENTS_CONTRACT="GUILD-DOCTOR-DISCORD-INTENTS-0.1"
INTENTS={"required":("GUILDS",),"optional":("GUILD_MEMBERS_TARGETED_READ_ONLY",),"prohibited":("MESSAGE_CONTENT","PRESENCES","VOICE_STATES"),"member_enumeration":"NOT_ENABLED","active_threads":"SNAPSHOT_ONLY","voice_state":"UNKNOWN_NOT_EXPOSED"}
