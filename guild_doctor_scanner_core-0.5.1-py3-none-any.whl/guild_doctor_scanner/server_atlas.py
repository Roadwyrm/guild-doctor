"""Pure Stage 7 Pass 2 Server Atlas construction; no engines or transport."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from .audit_aggregation import AuditAggregationResult
from .audit_contract import reference_key, safe_label, scan_private
from .canonical import sha256_hex
from .constants import SCANNER_CONTRACT_VERSION, SNAPSHOT_SCHEMA_VERSION


SERVER_ATLAS_CONTRACT = "GUILD-DOCTOR-SERVER-ATLAS-0.1"
STAGE7_PASS2_CONTRACT = "GUILD-DOCTOR-STAGE7-PASS2-SERVER-ATLAS-0.1"
_STATES = frozenset({"COMPLETE", "PARTIAL", "ESTIMATED", "UNKNOWN", "INCOMPLETE", "NOT_REQUESTED", "UNAVAILABLE", "FAILED", "UNSUPPORTED", "RULE_ERROR"})


class ServerAtlasError(ValueError):
    """Stable fail-closed Atlas input/reference error."""


def _records(value: Any, name: str) -> list[Mapping[str, Any]]:
    if value is None: return []
    values = value.values() if isinstance(value, Mapping) else value
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence): raise ServerAtlasError(f"ATLAS_{name}_INVALID")
    if not all(isinstance(item, Mapping) for item in values): raise ServerAtlasError(f"ATLAS_{name}_INVALID")
    return list(values)


def _ref(kind: str, value: Mapping[str, Any], guild_id: str) -> dict[str, Any]:
    object_id = str(value.get("id", ""))
    if not object_id.isdecimal(): raise ServerAtlasError("ATLAS_OBJECT_ID_INVALID")
    if value.get("guild_id") not in (None, guild_id): raise ServerAtlasError("ATLAS_REFERENCE_CROSS_GUILD")
    return {"object_type": kind, "reference_key": reference_key(object_type=kind, object_id=object_id), "safe_label": safe_label(value.get("name"), kind.title())}


@dataclass(frozen=True, slots=True)
class ServerAtlas:
    source_snapshot_fingerprint: str; snapshot_schema_version: str; scanner_contract_version: str
    source_completeness: Mapping[str, str]; collection_health: Mapping[str, str]
    guild_overview: Mapping[str, Any]; role_inventory: tuple[Mapping[str, Any], ...]; role_hierarchy: tuple[Mapping[str, Any], ...]
    role_permission_profile_references: tuple[Mapping[str, Any], ...]; category_inventory: tuple[Mapping[str, Any], ...]
    channel_inventory: tuple[Mapping[str, Any], ...]; category_child_relationships: tuple[Mapping[str, Any], ...]
    synchronization_summaries: tuple[Mapping[str, Any], ...]; overwrite_exception_summaries: tuple[Mapping[str, Any], ...]; thread_summaries: tuple[Mapping[str, Any], ...]
    permission_result_references: tuple[Mapping[str, Any], ...]; explanation_references: tuple[Mapping[str, Any], ...]; trace_references: tuple[Mapping[str, Any], ...]
    aggregated_finding_references: tuple[Mapping[str, Any], ...]; incomplete_evidence_references: tuple[Mapping[str, Any], ...]
    opaque_object_references: tuple[Mapping[str, Any], ...]; safe_labels: tuple[str, ...]; disclosure_classification: str = "OWNER_AUTHORIZED_LOCAL"
    atlas_contract: str = SERVER_ATLAS_CONTRACT; atlas_fingerprint: str = ""
    def __post_init__(self) -> None:
        if self.atlas_contract != SERVER_ATLAS_CONTRACT: raise ServerAtlasError("ATLAS_CONTRACT_UNSUPPORTED")
        payload = self.as_dict(include_fingerprint=False)
        if scan_private(payload, "server_atlas"): raise ServerAtlasError("ATLAS_PRIVATE_DATA_FORBIDDEN")
        expected = sha256_hex(payload)
        if self.atlas_fingerprint and self.atlas_fingerprint != expected: raise ServerAtlasError("ATLAS_FINGERPRINT_MISMATCH")
        object.__setattr__(self, "atlas_fingerprint", expected)
    def as_dict(self, *, include_fingerprint: bool = True) -> dict[str, Any]:
        value = {name: getattr(self, name) for name in self.__dataclass_fields__ if name != "atlas_fingerprint"}
        if include_fingerprint: value["atlas_fingerprint"] = self.atlas_fingerprint
        return value


def build_server_atlas(snapshot: Mapping[str, Any], *, aggregation: AuditAggregationResult | None = None, permission_result_references: Sequence[Mapping[str, Any]] = (), explanation_references: Sequence[Mapping[str, Any]] = (), trace_references: Sequence[Mapping[str, Any]] = ()) -> ServerAtlas:
    if not isinstance(snapshot, Mapping): raise ServerAtlasError("ATLAS_SNAPSHOT_INVALID")
    if snapshot.get("schema_version") != SNAPSHOT_SCHEMA_VERSION: raise ServerAtlasError("ATLAS_SNAPSHOT_SCHEMA_UNSUPPORTED")
    if snapshot.get("scanner_contract_version") != SCANNER_CONTRACT_VERSION: raise ServerAtlasError("ATLAS_SCANNER_CONTRACT_UNSUPPORTED")
    guild_id = str(snapshot.get("guild_id", "")); fingerprint = str(snapshot.get("snapshot_fingerprint_sha256") or snapshot.get("snapshot_fingerprint") or "")
    if not guild_id.isdecimal() or len(fingerprint) != 64: raise ServerAtlasError("ATLAS_SNAPSHOT_IDENTITY_INVALID")
    roles, channels, threads = _records(snapshot.get("roles"), "ROLES"), _records(snapshot.get("channels"), "CHANNELS"), _records(snapshot.get("threads"), "THREADS")
    refs = tuple(sorted((_ref("ROLE", item, guild_id) for item in roles), key=lambda x: x["reference_key"])) + tuple(sorted((_ref("CHANNEL", item, guild_id) for item in channels), key=lambda x: x["reference_key"]))
    categories = tuple(item for item in channels if str(item.get("type_key", "")).upper() == "CATEGORY")
    role_inventory = tuple(sorted(({**_ref("ROLE", item, guild_id), "position": item.get("position"), "managed": bool(item.get("managed")), "is_everyone": bool(item.get("is_everyone"))} for item in roles), key=lambda x: (x["position"] or 0, x["reference_key"])))
    channel_inventory = tuple(sorted(({**_ref("CHANNEL", item, guild_id), "type_key": str(item.get("type_key", "UNKNOWN")).upper(), "sync_state": str(item.get("sync_state", "UNKNOWN")).upper()} for item in channels), key=lambda x: x["reference_key"]))
    health = {str(k): str(v.get("status", "UNKNOWN")).upper() if isinstance(v, Mapping) else "UNKNOWN" for k,v in dict(snapshot.get("collections", {})).items()}
    if any(v not in _STATES for v in health.values()): raise ServerAtlasError("ATLAS_HEALTH_STATE_INVALID")
    findings = () if aggregation is None else tuple(item.as_dict() for item in aggregation.grouped_findings)
    if aggregation is not None and aggregation.snapshot_fingerprint != fingerprint: raise ServerAtlasError("ATLAS_AGGREGATION_SNAPSHOT_MISMATCH")
    def safe_refs(values: Sequence[Mapping[str, Any],] | Sequence[Mapping[str, Any]]) -> tuple[Mapping[str, Any], ...]:
        if not all(isinstance(v, Mapping) for v in values) or scan_private(list(values), "atlas_reference"): raise ServerAtlasError("ATLAS_REFERENCE_INVALID")
        return tuple(sorted((dict(v) for v in values), key=lambda v: sha256_hex(v)))
    complete = {"structural": str(snapshot.get("structural_completeness", "UNKNOWN")).upper(), "member": str(snapshot.get("member_completeness", "UNKNOWN")).upper(), "thread": str(snapshot.get("thread_completeness", "UNKNOWN")).upper()}
    return ServerAtlas(fingerprint, SNAPSHOT_SCHEMA_VERSION, SCANNER_CONTRACT_VERSION, complete, health, {"reference_key": reference_key(object_type="GUILD", object_id=guild_id), "safe_label": safe_label((snapshot.get("guild") or {}).get("name") if isinstance(snapshot.get("guild"), Mapping) else None, "Guild")}, role_inventory, role_inventory, tuple({"role_reference": x["reference_key"]} for x in role_inventory), tuple(_ref("CATEGORY", x, guild_id) for x in categories), channel_inventory, tuple(sorted(({"child_reference": _ref("CHANNEL", x, guild_id)["reference_key"], "parent_reference": reference_key(object_type="CATEGORY", object_id=str(x["parent_id"]))} for x in channels if x.get("parent_id")), key=lambda x: x["child_reference"])), tuple({"channel_reference": x["reference_key"], "sync_state": x["sync_state"]} for x in channel_inventory), tuple(), tuple(_ref("THREAD", x, guild_id) for x in threads), safe_refs(permission_result_references), safe_refs(explanation_references), safe_refs(trace_references), findings, tuple({"collection": k, "state": v} for k,v in sorted(health.items()) if v != "COMPLETE"), refs, tuple(sorted({x["safe_label"] for x in refs})))
