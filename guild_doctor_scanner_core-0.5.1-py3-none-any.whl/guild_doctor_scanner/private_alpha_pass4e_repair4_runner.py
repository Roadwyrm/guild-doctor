"""Offline preparation and exact-phrase resume boundary for Repair 4B.

The runner has no token retrieval or Discord operation.  It passes a token
provider through only after a durable authority has been atomically consumed.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .private_alpha_live_interaction_preflight import READY_STATE, run_live_interaction_preflight
from .private_alpha_pass4e_repair4_authority import (
    AuthorityBinding, AuthorityRecord, LocalAuthorityStore, Repair4AuthorityError,
    as_frozen_runtime_authority,
)
from .runtime_provenance import _source_tree_fingerprint
from .private_alpha_pass4e_session_artifacts import SessionArtifactPaths, SessionArtifactPathError


READY_PHRASE = "READY_FOR_PASS4E_REPAIR4_LIVE_SESSION"
EXACT_START_PHRASE = "START PASS 4E REPAIR 4 LIVE SESSION"


@dataclass(frozen=True, slots=True)
class Repair4RunnerResult:
    state: str
    stable_error: str | None
    authority_state: str | None
    token_provider_invoked: bool
    client_constructed: bool
    gateway_connected: bool


def binding_from_preflight(*, preflight: Any, source_tree_fingerprint: str, session_artifacts: SessionArtifactPaths | None = None) -> AuthorityBinding:
    """Build the durable binding from a completed, token-free preflight."""
    values = dict(
        source_tree_fingerprint=source_tree_fingerprint,
        snapshot_fingerprint=str(getattr(preflight, "snapshot_fingerprint", "")),
        preflight_fingerprint=str(getattr(preflight, "preflight_fingerprint", "")),
        active_configuration_fingerprint=str(getattr(preflight, "active_configuration_fingerprint", "")),
        live_configuration_fingerprint=str(getattr(preflight, "live_configuration_fingerprint", "")),
        session_artifact_binding_fingerprint=("0" * 64 if session_artifacts is None else session_artifacts.validated().binding_fingerprint),
    )
    if session_artifacts is not None and session_artifacts.issuance_identifier is not None:
        artifacts = session_artifacts.validated()
        values.update(issuance_reference=artifacts.issuance_identifier, session_namespace=artifacts.session_namespace,
            namespace_format_version="GUILD-DOCTOR-STAGE8-PASS4E-NAMESPACE-0.1",
            authority_basename=artifacts.authority_path.name, receipt_basename=artifacts.receipt_path.name)
    return AuthorityBinding(**values)


def issue_after_preflight(
    *, store: LocalAuthorityStore, preflight: Any, source_tree_fingerprint: str,
    snapshot_fingerprint: str,
) -> tuple[Repair4RunnerResult, AuthorityRecord | None]:
    """Issue once after an already-completed offline preflight."""
    if getattr(preflight, "overall_state", None) != READY_STATE:
        return Repair4RunnerResult("BLOCKED", "STAGE8_PASS4E_REPAIR4_PREFLIGHT_NOT_READY", None, False, False, False), None
    if getattr(preflight, "source_tree_fingerprint", source_tree_fingerprint) != source_tree_fingerprint:
        return Repair4RunnerResult("BLOCKED", "STAGE8_PASS4E_REPAIR4_SOURCE_FINGERPRINT_MISMATCH", None, False, False, False), None
    if getattr(preflight, "snapshot_fingerprint", None) != snapshot_fingerprint:
        return Repair4RunnerResult("BLOCKED", "STAGE8_PASS4E_REPAIR4_SNAPSHOT_FINGERPRINT_MISMATCH", None, False, False, False), None
    binding = binding_from_preflight(preflight=preflight, source_tree_fingerprint=source_tree_fingerprint, session_artifacts=store.session_artifacts)
    try:
        record = store.issue(binding)
    except Repair4AuthorityError as exc:
        return Repair4RunnerResult("BLOCKED", str(exc), None, False, False, False), None
    return Repair4RunnerResult(READY_PHRASE, None, record.issuance_state, False, False, False), record


def run_offline_preflight_and_issue(
    *, root: Path, active_configuration_path: Path, live_configuration_path: Path,
    snapshot_path: Path, secret_presence: Any, authority_path: Path, session_artifacts: SessionArtifactPaths | None = None,
) -> tuple[Repair4RunnerResult, AuthorityRecord | None]:
    """Run the existing offline preflight then persist exactly one authority."""
    root = Path(root).resolve()
    preflight = run_live_interaction_preflight(
        root=root, active_configuration_path=active_configuration_path,
        live_configuration_path=live_configuration_path, snapshot_path=snapshot_path,
        secret_presence=secret_presence,
    )
    source_tree_fingerprint = _source_tree_fingerprint(root)
    try:
        artifacts = None if session_artifacts is None else session_artifacts.validated()
        store = LocalAuthorityStore(authority_path, session_artifacts=artifacts)
    except (Repair4AuthorityError, SessionArtifactPathError) as exc:
        return Repair4RunnerResult("BLOCKED", str(exc), None, False, False, False), None
    return issue_after_preflight(
        store=store, preflight=preflight,
        source_tree_fingerprint=source_tree_fingerprint,
        snapshot_fingerprint=str(getattr(preflight, "snapshot_fingerprint", "")),
    )


def run_offline_preflight_and_issue_new_session(
    *, root: Path, active_configuration_path: Path, live_configuration_path: Path,
    snapshot_path: Path, secret_presence: Any, approved_root: Path,
) -> tuple[Repair4RunnerResult, AuthorityRecord | None, SessionArtifactPaths]:
    """Generate a trusted append-only namespace; callers never provide paths."""
    artifacts = SessionArtifactPaths.generate(approved_root=approved_root)
    result, record = run_offline_preflight_and_issue(
        root=root, active_configuration_path=active_configuration_path,
        live_configuration_path=live_configuration_path, snapshot_path=snapshot_path,
        secret_presence=secret_presence, authority_path=artifacts.authority_path,
        session_artifacts=artifacts,
    )
    return result, record, artifacts


def validate_pause_state(*, store: LocalAuthorityStore, binding: AuthorityBinding) -> Repair4RunnerResult:
    """Validate an issued record without consuming it."""
    try:
        record = store.validate(binding)
    except Repair4AuthorityError as exc:
        return Repair4RunnerResult("BLOCKED", str(exc), None, False, False, False)
    if record.issuance_state != "ISSUED":
        return Repair4RunnerResult("BLOCKED", "STAGE8_PASS4E_REPAIR4_AUTHORITY_NOT_ISSUED", record.issuance_state, False, False, False)
    return Repair4RunnerResult(READY_PHRASE, None, record.issuance_state, False, False, False)


def resume_after_exact_start_phrase(
    *, phrase: str, store: LocalAuthorityStore, binding: AuthorityBinding,
    current_source_tree_fingerprint: str, current_snapshot_fingerprint: str,
    runtime_handoff: Callable[[AuthorityRecord], Any],
) -> Repair4RunnerResult:
    """Consume the durable authority, then hand off to the frozen runtime."""
    if phrase != EXACT_START_PHRASE:
        return Repair4RunnerResult("BLOCKED", "STAGE8_PASS4E_REPAIR4_START_PHRASE_REQUIRED", None, False, False, False)
    if binding.source_tree_fingerprint != current_source_tree_fingerprint:
        return Repair4RunnerResult("BLOCKED", "STAGE8_PASS4E_REPAIR4_SOURCE_FINGERPRINT_MISMATCH", None, False, False, False)
    if binding.snapshot_fingerprint != current_snapshot_fingerprint:
        return Repair4RunnerResult("BLOCKED", "STAGE8_PASS4E_REPAIR4_SNAPSHOT_FINGERPRINT_MISMATCH", None, False, False, False)
    try:
        record = store.consume(binding)
    except Repair4AuthorityError as exc:
        return Repair4RunnerResult("BLOCKED", str(exc), None, False, False, False)
    # The handoff is injected so this module never constructs a Discord client
    # or evaluates a token provider during Repair 4A tests.
    runtime_handoff(as_frozen_runtime_authority(record))
    return Repair4RunnerResult("HANDOFF_STARTED", None, record.issuance_state, False, False, False)


def revalidate_preflight_and_resume(
    *, phrase: str, root: Path, active_configuration_path: Path,
    live_configuration_path: Path, snapshot_path: Path, secret_presence: Any,
    authority_path: Path, runtime_handoff: Callable[[Any], Any],
    session_artifacts: SessionArtifactPaths | None = None,
) -> Repair4RunnerResult:
    """Future Repair 4B entry: revalidate locally, consume, then hand off."""
    if phrase != EXACT_START_PHRASE:
        return Repair4RunnerResult("BLOCKED", "STAGE8_PASS4E_REPAIR4_START_PHRASE_REQUIRED", None, False, False, False)
    root = Path(root).resolve()
    preflight = run_live_interaction_preflight(
        root=root, active_configuration_path=active_configuration_path,
        live_configuration_path=live_configuration_path, snapshot_path=snapshot_path,
        secret_presence=secret_presence,
    )
    current_source = _source_tree_fingerprint(root)
    try:
        artifacts = None if session_artifacts is None else session_artifacts.validated()
        store = LocalAuthorityStore(authority_path, session_artifacts=artifacts)
        binding = binding_from_preflight(
            preflight=preflight, source_tree_fingerprint=current_source,
            session_artifacts=artifacts,
        )
    except (Repair4AuthorityError, SessionArtifactPathError) as exc:
        return Repair4RunnerResult("BLOCKED", str(exc), None, False, False, False)
    return resume_after_exact_start_phrase(
        phrase=phrase, store=store, binding=binding,
        current_source_tree_fingerprint=current_source,
        current_snapshot_fingerprint=binding.snapshot_fingerprint,
        runtime_handoff=runtime_handoff,
    )


def revalidate_preflight_and_resume_reference(
    *, phrase: str, issuance_reference: str, root: Path,
    active_configuration_path: Path, live_configuration_path: Path,
    snapshot_path: Path, secret_presence: Any, approved_root: Path,
    runtime_handoff: Callable[[Any], Any],
) -> Repair4RunnerResult:
    """Cross-process resume boundary: only a canonical issuance reference enters."""
    if phrase != EXACT_START_PHRASE:
        return Repair4RunnerResult("BLOCKED", "STAGE8_PASS4E_REPAIR4_START_PHRASE_REQUIRED", None, False, False, False)
    try:
        artifacts = SessionArtifactPaths.for_issuance(issuance_reference, approved_root=approved_root)
    except SessionArtifactPathError as exc:
        return Repair4RunnerResult("BLOCKED", str(exc), None, False, False, False)
    return revalidate_preflight_and_resume(
        phrase=phrase, root=root, active_configuration_path=active_configuration_path,
        live_configuration_path=live_configuration_path, snapshot_path=snapshot_path,
        secret_presence=secret_presence, authority_path=artifacts.authority_path,
        session_artifacts=artifacts, runtime_handoff=runtime_handoff,
    )


__all__ = [
    "EXACT_START_PHRASE", "READY_PHRASE", "Repair4RunnerResult", "binding_from_preflight",
    "issue_after_preflight", "revalidate_preflight_and_resume", "resume_after_exact_start_phrase",
    "revalidate_preflight_and_resume_reference", "run_offline_preflight_and_issue", "run_offline_preflight_and_issue_new_session", "validate_pause_state",
]
