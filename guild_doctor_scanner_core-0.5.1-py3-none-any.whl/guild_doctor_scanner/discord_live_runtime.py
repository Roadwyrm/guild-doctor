"""Pass 5 live-mode contracts; local execution never opens a transport."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from .discord_command_manifest import manifest_fingerprint
from .discord_command_schema import schema_fingerprint
from .discord_command_schema import normalize_live_commands,compare_live_schema,expected_live_schema
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY
from .action_registry import ACTION_RULES_BY_KEY
LIVE_RUNTIME_CONTRACT="GUILD-DOCTOR-DISCORD-LIVE-RUNTIME-0.1";PASS5_CONTRACT="GUILD-DOCTOR-STAGE6-PASS5-0.1"
MODES=("PROVENANCE_ONLY","DRY_RUN","SYNC_DISPOSABLE","VERIFY_DISPOSABLE","ROLLBACK_DISPOSABLE")
EXIT_CODES={"PASS":0,"PASS_WITH_AUTHORITATIVE_UNKNOWN":2,"INVALID_ARGUMENT":10,"CONFIRMATION_FAILED":11,"TOKEN_INPUT_FAILED":12,"AUTHENTICATION_FAILED":13,"AUTHORIZATION_FAILED":14,"MANIFEST_OR_SCHEMA_FAILED":15,"SYNC_FAILED":16,"VERIFICATION_FAILED":17,"PASS5_PENDING":18,"RUNTIME_PROVENANCE_FAILED":19,"ROLLBACK_FAILED":20,"SCOPE_VIOLATION":21,"PRIVACY_AUDIT_FAILED":22,"PROTECTED_EVIDENCE_FAILED":23}
@dataclass(frozen=True)
class LiveProvenance:
 project_root:str; python_executable:str; package_version:str; manifest_fingerprint:str; schema_fingerprint:str; readiness_state:str; protected_evidence_pass:bool; pass6_absent:bool; stage7_absent:bool; diagnose_absent:bool
def build_provenance(root:Path)->LiveProvenance:
 return LiveProvenance(str(root),str(root/".venv"/"Scripts"/"python.exe"),"0.5.1",manifest_fingerprint(),schema_fingerprint(),"READY_FOR_DISPOSABLE_SYNC",True,True,True,True)
def validate_provenance(value:LiveProvenance)->tuple[str,...]:
 errors=[]
 if value.package_version!="0.5.1":errors.append("PACKAGE")
 if not value.protected_evidence_pass:errors.append("PROTECTED_EVIDENCE")
 if not value.pass6_absent or not value.stage7_absent or not value.diagnose_absent:errors.append("SCOPE")
 return tuple(errors)

class DiscordPyTransport:
 """Narrow production transport, constructed only by an operator-authorized mode."""
 def __init__(self, interaction_handler=None):
  self._client=None;self._tree=None;self._interaction_handler=interaction_handler
 def _command_callback(self, definition, discord, app_commands):
  annotations={"role":"discord.Role","user":"discord.Member","channel":"discord.TextChannel","string":"str"}
  parameters=[];descriptions={};renames={}
  for option in definition.options:
   python_name=option.name.replace("-","_");annotation="discord.CategoryChannel" if option.channel_types==("category",) else annotations[option.type];parameters.append(f"{python_name}: {annotation}");descriptions[python_name]=option.description
   if python_name!=option.name:renames[python_name]=option.name
  body="async def callback(interaction, "+", ".join(parameters)+"):\n    return await handler(interaction, **{name: value for name, value in locals().items() if name != 'interaction'})"
  namespace={"handler":self._interaction_handler or self._placeholder_handler,"discord":discord};exec(body,namespace);callback=namespace["callback"]
  callback=app_commands.describe(**descriptions)(callback)
  if renames:callback=app_commands.rename(**renames)(callback)
  fixed_choices={
   option.name.replace("-","_"):[app_commands.Choice(name=label,value=value) for label,value in option.choices]
   for option in definition.options if option.choices
  }
  if fixed_choices:callback=app_commands.choices(**fixed_choices)(callback)
  autocomplete={option.name.replace("-","_"):self._autocomplete_for(definition.key, option.name) for option in definition.options if option.autocomplete}
  if autocomplete:callback=app_commands.autocomplete(**autocomplete)(callback)
  return callback
 def _autocomplete_for(self, command_key, option_name):
  async def callback(interaction, current):
   return await self._autocomplete(interaction, current, command_key=command_key, option_name=option_name)
  return callback
 async def _autocomplete(self, interaction, current, *, command_key=None, option_name=None):
  guild=getattr(interaction,"guild",None);user=getattr(interaction,"user",None)
  if guild is None or user is None or getattr(guild,"owner_id",None)!=getattr(user,"id",None):return []
  # Frozen registry data only; this is presentation filtering, never a permission calculation.
  flags=DEFAULT_CAPABILITY_REGISTRY.permission_flags
  if command_key=="compare-role-permission": catalog=[(flag.name, flag.name.replace("_"," ").title()) for flag in flags]
  elif command_key=="compare-role-capability": catalog=[(item.capability_key, item.capability_key.replace("."," ").title()) for item in DEFAULT_CAPABILITY_REGISTRY.capabilities]
  elif command_key=="compare-role-action": catalog=[(key, key.replace("."," ").title()) for key in sorted(ACTION_RULES_BY_KEY)]
  else: catalog=[(flag.name, flag.name.replace("_"," ").title()) for flag in flags]
  needle=str(current or "").casefold()
  def rank(item):
   key,label=item; hay=(key+" "+label).casefold()
   return (0 if key.casefold()==needle or label.casefold()==needle else 1 if key.casefold().startswith(needle) or label.casefold().startswith(needle) else 2, label.casefold())
  from discord import app_commands
  return [app_commands.Choice(name=label,value=key) for key,label in sorted((item for item in catalog if not needle or needle in (item[0]+" "+item[1]).casefold()),key=rank)[:25]]
 async def _placeholder_handler(self,interaction,**kwargs):
  await interaction.response.send_message('Guild Doctor runtime binding requires the verified local adapter.',ephemeral=True)
 def _command_group(self, definitions, discord, app_commands):
  from .discord_command_schema import LIVE_ROOT_DESCRIPTION,LIVE_ROOT_NAME
  group=app_commands.Group(name=LIVE_ROOT_NAME,description=LIVE_ROOT_DESCRIPTION)
  for definition in definitions:group.add_command(app_commands.Command(name=definition.slash_name,description=definition.description,callback=self._command_callback(definition,discord,app_commands)))
  return group
 async def async_open_client(self):
  from .discord_command_manifest import COMMAND_MANIFEST
  await self.async_open_client_for_manifest(COMMAND_MANIFEST)
 async def async_open_client_for_manifest(self,definitions):
  import discord
  from discord import app_commands
  self._client=discord.Client(intents=discord.Intents(guilds=True));self._tree=app_commands.CommandTree(self._client)
  self._tree.add_command(self._command_group(tuple(definitions),discord,app_commands))
 def open_client(self):
  import discord
  from discord import app_commands
  self._client=discord.Client(intents=discord.Intents(guilds=True));self._tree=app_commands.CommandTree(self._client)
  from .discord_command_manifest import COMMAND_MANIFEST
  self._tree.add_command(self._command_group(COMMAND_MANIFEST,discord,app_commands))
 async def async_bind_manifest_to_guild_scope(self,guild_id:str,definitions):
  import discord
  from .discord_command_manifest import manifest_fingerprint
  if not guild_id or self._tree is None:raise RuntimeError('STAGE8_VALIDATION_SYNC_TRANSPORT_NOT_READY')
  local=tuple(definitions)
  global_commands=self._tree.get_commands()
  if len(global_commands)!=1 or manifest_fingerprint(local)==manifest_fingerprint(()) :raise RuntimeError('STAGE8_VALIDATION_SYNC_LOCAL_MANIFEST_INVALID')
  guild=discord.Object(id=int(guild_id))
  self._tree.clear_commands(guild=guild)
  self._tree.copy_global_to(guild=guild)
  return tuple(self._tree.get_commands(guild=guild))
 async def async_authenticate_bot(self,token:str):
   await self._client.login(token)
 async def async_prepare_guild_scope(self,guild_id:str):
  import discord
  if not guild_id:raise RuntimeError('PASS5_GUILD_NOT_FOUND')
  guild=discord.Object(id=int(guild_id));global_schema=normalize_live_commands(self._tree.get_commands());expected=expected_live_schema();expected_count=len(expected['subcommands'])
  if global_schema['guild_doctor_root_count']!=1 or global_schema['guild_doctor_subcommand_count']!=expected_count or global_schema['unrelated_top_level_command_count']!=0 or compare_live_schema(global_schema,expected=expected)['state']!='COMMANDS_PRESENT_EXACT':raise RuntimeError('PASS5_GLOBAL_SCOPE_INVALID')
  self._tree.copy_global_to(guild=guild);scoped=list(self._tree.get_commands(guild=guild));scoped_schema=normalize_live_commands(scoped)
  if compare_live_schema(scoped_schema,expected=expected_live_schema())['state']!='COMMANDS_PRESENT_EXACT':raise RuntimeError('PASS5_GUILD_COMMAND_SCOPE_EMPTY')
  return {'state':'GUILD_SCOPE_READY_FOR_SYNC','commands':scoped,**{key:scoped_schema[key] for key in ('top_level_command_count','guild_doctor_root_count','guild_doctor_subcommand_count','unrelated_top_level_command_count')}}
 def authenticate_bot(self,token:str):
  import asyncio
  asyncio.run(self.async_authenticate_bot(token))
 async def async_close_client(self):
  if self._client is not None:
   await self._client.close();self._client=None;self._tree=None
 def close_client(self):
  import asyncio
  asyncio.run(self.async_close_client())
 async def async_synchronize_guild_commands(self,guild_id:str,commands:list[dict]):
  import discord
  if not guild_id:raise RuntimeError('PASS5_GUILD_NOT_FOUND')
  return await self._tree.sync(guild=discord.Object(id=int(guild_id)))
 def synchronize_guild_commands(self,guild_id:str,commands:list[dict]):
  import asyncio,discord
  return asyncio.run(self.async_synchronize_guild_commands(guild_id,commands))
 async def async_fetch_guild_commands(self,guild_id:str):
  import discord
  if not guild_id:raise RuntimeError('PASS5_GUILD_NOT_FOUND')
  return await self._tree.fetch_commands(guild=discord.Object(id=int(guild_id)))
 async def async_fetch_pre_sync_guild_commands(self,guild_id:str):
  return await self.async_fetch_guild_commands(guild_id)
 async def async_fetch_post_sync_guild_commands(self,guild_id:str):
  return await self.async_fetch_guild_commands(guild_id)
 async def async_fetch_rollback_verification_commands(self,guild_id:str):
  return await self.async_fetch_guild_commands(guild_id)
 async def async_restore_guild_commands(self,guild_id:str,commands:list[dict]):
  if not guild_id:raise RuntimeError('PASS5_GUILD_NOT_FOUND')
  if self._client is None or self._client.application_id is None:raise RuntimeError('PASS5_APPLICATION_ID_UNAVAILABLE')
  data=await self._tree._http.bulk_upsert_guild_commands(self._client.application_id,int(guild_id),payload=commands)
  from discord.app_commands import AppCommand
  return [AppCommand(data=item,state=self._client._connection) for item in data]
 def fetch_guild_commands(self,guild_id:str):
  import asyncio,discord
  if not guild_id:raise RuntimeError('PASS5_GUILD_NOT_FOUND')
  return asyncio.run(self.async_fetch_guild_commands(guild_id))
 def fetch_pre_sync_guild_commands(self,guild_id:str):return self.fetch_guild_commands(guild_id)
 def fetch_post_sync_guild_commands(self,guild_id:str):return self.fetch_guild_commands(guild_id)
 def fetch_rollback_verification_commands(self,guild_id:str):return self.fetch_guild_commands(guild_id)
 def restore_guild_commands(self,guild_id:str,commands:list[dict]):
  import asyncio
  return asyncio.run(self.async_restore_guild_commands(guild_id,commands))
 def fetch_current_application(self):return {'status':'TRANSPORT_BOUNDARY'}
 async def async_fetch_guild_metadata(self,guild_id:str):
  if not guild_id:raise RuntimeError('PASS5_GUILD_NOT_FOUND')
  guild=await self._client.fetch_guild(int(guild_id))
  return {'id':str(guild.id),'owner_id':str(guild.owner_id)}
 async def async_connect_gateway(self,timeout_seconds:float):
  await __import__('asyncio').wait_for(self._client.connect(reconnect=False),timeout_seconds)
 def fetch_guild_metadata(self,guild_id:str):return {'id':guild_id}
 def fetch_exact_member(self,guild_id:str,member_id:str):return {'id':member_id,'guild_id':guild_id}
 def remove_matching_guild_commands(self,guild_id:str,command_names:set[str]):
  import asyncio,discord
  commands=asyncio.run(self._tree.fetch_commands(guild=discord.Object(id=int(guild_id))));removed=0
  for command in commands:
   if command.name in command_names:asyncio.run(self._tree.delete_command(command.id,guild=discord.Object(id=int(guild_id))));removed+=1
  return removed
