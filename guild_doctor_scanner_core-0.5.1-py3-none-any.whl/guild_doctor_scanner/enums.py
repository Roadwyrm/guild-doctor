"""String enums used by the normalized snapshot."""

from enum import StrEnum


class CollectionStatus(StrEnum):
    COMPLETE = "COMPLETE"
    PARTIAL = "PARTIAL"
    UNAVAILABLE = "UNAVAILABLE"
    FAILED = "FAILED"
    NOT_REQUESTED = "NOT_REQUESTED"
    UNSUPPORTED = "UNSUPPORTED"


class Completeness(StrEnum):
    COMPLETE = "COMPLETE"
    PARTIAL = "PARTIAL"
    ESTIMATED = "ESTIMATED"
    UNKNOWN = "UNKNOWN"
    NOT_REQUESTED = "NOT_REQUESTED"


class SyncState(StrEnum):
    SYNCED = "SYNCED"
    NOT_SYNCED = "NOT_SYNCED"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    UNKNOWN = "UNKNOWN"


class Severity(StrEnum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFORMATIONAL = "INFORMATIONAL"


class Materiality(StrEnum):
    STRUCTURAL = "STRUCTURAL"
    MEMBER_QUERY = "MEMBER_QUERY"
    THREAD_QUERY = "THREAD_QUERY"
    FUTURE_ANALYSIS = "FUTURE_ANALYSIS"
    NONE = "NONE"
