"""Versioned, deterministic permission-to-capability registry for Stage 3 Pass 3.

The registry is deliberately data-only.  It records the current known Discord
permission names and the project-level capability contexts in which this pass
can reason about them.  It does not make Discord calls or infer thread,
hierarchy, target, MFA, or object-precondition behavior.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

from .constants import KNOWN_PERMISSION_MASK, PERMISSION_DEFINITION_VERSION


CAPABILITY_REGISTRY_VERSION: Final[str] = "GUILD-DOCTOR-CAPABILITY-REGISTRY-0.1"
PERMISSION_SOURCE_URL: Final[str] = "https://docs.discord.com/developers/topics/permissions"
CHANNEL_SOURCE_URL: Final[str] = "https://docs.discord.com/developers/resources/channel"
THREAD_SOURCE_URL: Final[str] = "https://docs.discord.com/developers/topics/threads"
GUILD_SOURCE_URL: Final[str] = "https://docs.discord.com/developers/resources/guild"

SUPPORTED_EXECUTABLE_CONTEXTS: Final[tuple[str, ...]] = (
    "TEXT",
    "ANNOUNCEMENT",
    "VOICE",
    "STAGE",
    "FORUM",
    "MEDIA",
)
TEXT_CONTEXTS: Final[tuple[str, ...]] = ("TEXT", "ANNOUNCEMENT", "FORUM", "MEDIA")
VOICE_CONTEXTS: Final[tuple[str, ...]] = ("VOICE",)
STAGE_CONTEXTS: Final[tuple[str, ...]] = ("STAGE",)
VOICE_STAGE_CONTEXTS: Final[tuple[str, ...]] = ("VOICE", "STAGE")

DEP_VIEW_CHANNEL: Final[str] = "DEP-VIEW-001"
DEP_SEND_MESSAGES: Final[str] = "DEP-SEND-001"
DEP_VOICE_CONNECT: Final[str] = "DEP-VOICE-001"
DEP_TIMEOUT: Final[str] = "DEP-TIMEOUT-001"
DEP_EXTERNAL_APP_BEHAVIOR: Final[str] = "DEP-EXTERNAL-APP-001"


@dataclass(frozen=True, slots=True)
class PermissionFlagDefinition:
    """One known permission bit from the frozen permission definition."""

    bit: int
    name: str

    @property
    def mask(self) -> int:
        return 1 << self.bit


@dataclass(frozen=True, slots=True)
class CapabilityDefinition:
    """One stable capability mapping for a known permission flag."""

    capability_key: str
    permission_bit: int
    source_permission_flag: str
    scope: str
    context_types: tuple[str, ...]
    dependency_rule_ids: tuple[str, ...] = ()
    verification_status: str = "VERIFIED"
    source_references: tuple[str, ...] = (PERMISSION_SOURCE_URL,)
    notes: str = ""


@dataclass(frozen=True, slots=True)
class CapabilityRegistry:
    """Immutable registry with explicit version and permission-definition ownership."""

    version: str
    permission_definition_version: str
    known_permission_mask: int
    permission_flags: tuple[PermissionFlagDefinition, ...]
    capabilities: tuple[CapabilityDefinition, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "version": self.version,
            "permission_definition_version": self.permission_definition_version,
            "known_permission_mask_decimal": str(self.known_permission_mask),
            "known_permission_mask_hex": format(self.known_permission_mask, "#x"),
            "permission_flags": [
                {"bit": flag.bit, "name": flag.name, "mask": format(flag.mask, "#x")}
                for flag in self.permission_flags
            ],
            "capabilities": [
                {
                    "capability_key": capability.capability_key,
                    "permission_bit": capability.permission_bit,
                    "source_permission_flag": capability.source_permission_flag,
                    "scope": capability.scope,
                    "context_types": list(capability.context_types),
                    "dependency_rule_ids": list(capability.dependency_rule_ids),
                    "verification_status": capability.verification_status,
                    "source_references": list(capability.source_references),
                    "notes": capability.notes,
                }
                for capability in self.capabilities
            ],
        }


_PERMISSION_FLAGS: Final[tuple[PermissionFlagDefinition, ...]] = tuple(
    PermissionFlagDefinition(bit, name)
    for bit, name in (
        (0, "CREATE_INSTANT_INVITE"),
        (1, "KICK_MEMBERS"),
        (2, "BAN_MEMBERS"),
        (3, "ADMINISTRATOR"),
        (4, "MANAGE_CHANNELS"),
        (5, "MANAGE_GUILD"),
        (6, "ADD_REACTIONS"),
        (7, "VIEW_AUDIT_LOG"),
        (8, "PRIORITY_SPEAKER"),
        (9, "STREAM"),
        (10, "VIEW_CHANNEL"),
        (11, "SEND_MESSAGES"),
        (12, "SEND_TTS_MESSAGES"),
        (13, "MANAGE_MESSAGES"),
        (14, "EMBED_LINKS"),
        (15, "ATTACH_FILES"),
        (16, "READ_MESSAGE_HISTORY"),
        (17, "MENTION_EVERYONE"),
        (18, "USE_EXTERNAL_EMOJIS"),
        (19, "VIEW_GUILD_INSIGHTS"),
        (20, "CONNECT"),
        (21, "SPEAK"),
        (22, "MUTE_MEMBERS"),
        (23, "DEAFEN_MEMBERS"),
        (24, "MOVE_MEMBERS"),
        (25, "USE_VAD"),
        (26, "CHANGE_NICKNAME"),
        (27, "MANAGE_NICKNAMES"),
        (28, "MANAGE_ROLES"),
        (29, "MANAGE_WEBHOOKS"),
        (30, "MANAGE_GUILD_EXPRESSIONS"),
        (31, "USE_APPLICATION_COMMANDS"),
        (32, "REQUEST_TO_SPEAK"),
        (33, "MANAGE_EVENTS"),
        (34, "MANAGE_THREADS"),
        (35, "CREATE_PUBLIC_THREADS"),
        (36, "CREATE_PRIVATE_THREADS"),
        (37, "USE_EXTERNAL_STICKERS"),
        (38, "SEND_MESSAGES_IN_THREADS"),
        (39, "USE_EMBEDDED_ACTIVITIES"),
        (40, "MODERATE_MEMBERS"),
        (41, "VIEW_CREATOR_MONETIZATION_ANALYTICS"),
        (42, "USE_SOUNDBOARD"),
        (43, "CREATE_GUILD_EXPRESSIONS"),
        (44, "CREATE_EVENTS"),
        (45, "USE_EXTERNAL_SOUNDS"),
        (46, "SEND_VOICE_MESSAGES"),
        (48, "SET_VOICE_CHANNEL_STATUS"),
        (49, "SEND_POLLS"),
        (50, "USE_EXTERNAL_APPS"),
        (51, "PIN_MESSAGES"),
        (52, "BYPASS_SLOWMODE"),
    )
)


def _capability(
    key: str,
    bit: int,
    flag: str,
    scope: str,
    contexts: tuple[str, ...],
    *,
    deps: tuple[str, ...] = (),
    verification: str = "VERIFIED",
    references: tuple[str, ...] = (PERMISSION_SOURCE_URL,),
    notes: str = "",
) -> CapabilityDefinition:
    return CapabilityDefinition(
        capability_key=key,
        permission_bit=bit,
        source_permission_flag=flag,
        scope=scope,
        context_types=contexts,
        dependency_rule_ids=deps,
        verification_status=verification,
        source_references=references,
        notes=notes,
    )


def _build_capabilities() -> tuple[CapabilityDefinition, ...]:
    """Build the registry in bit/key order; no mapping is inferred at runtime."""

    p = {item.name: item.bit for item in _PERMISSION_FLAGS}
    c: list[CapabilityDefinition] = []

    def add(key: str, flag: str, scope: str, contexts: tuple[str, ...], **kwargs: object) -> None:
        c.append(_capability(key, p[flag], flag, scope, contexts, **kwargs))  # type: ignore[arg-type]

    all_contexts = SUPPORTED_EXECUTABLE_CONTEXTS
    add("invite.create", "CREATE_INSTANT_INVITE", "TEXT", all_contexts)
    add("member.kick", "KICK_MEMBERS", "GUILD", all_contexts)
    add("member.ban", "BAN_MEMBERS", "GUILD", all_contexts)
    add("guild.administrator", "ADMINISTRATOR", "GUILD", all_contexts)
    add("channel.manage", "MANAGE_CHANNELS", "TEXT", all_contexts)
    add("guild.manage", "MANAGE_GUILD", "GUILD", all_contexts)
    add("message.react", "ADD_REACTIONS", "TEXT", TEXT_CONTEXTS)
    add("audit_log.view", "VIEW_AUDIT_LOG", "GUILD", all_contexts)
    add("voice.priority_speaker", "PRIORITY_SPEAKER", "VOICE", VOICE_CONTEXTS)
    add("voice.stream", "STREAM", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("stage.stream", "STREAM", "STAGE", STAGE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("view.channel", "VIEW_CHANNEL", "TEXT", all_contexts)
    add("message.send", "SEND_MESSAGES", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL,))
    add("forum_media.create_post", "SEND_MESSAGES", "TEXT", ("FORUM", "MEDIA"), deps=(DEP_VIEW_CHANNEL,), references=(PERMISSION_SOURCE_URL, CHANNEL_SOURCE_URL), notes="SEND_MESSAGES controls forum/media post creation; CREATE_PUBLIC_THREADS is not a substitute.")
    add("message.send_tts", "SEND_TTS_MESSAGES", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL, DEP_SEND_MESSAGES))
    add("message.manage", "MANAGE_MESSAGES", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL,))
    add("message.embed_links", "EMBED_LINKS", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL, DEP_SEND_MESSAGES))
    add("message.attach_files", "ATTACH_FILES", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL, DEP_SEND_MESSAGES))
    add("message.read_history", "READ_MESSAGE_HISTORY", "TEXT", all_contexts)
    add("message.mention_everyone", "MENTION_EVERYONE", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL, DEP_SEND_MESSAGES))
    add("message.use_external_emojis", "USE_EXTERNAL_EMOJIS", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL,))
    add("guild.insights.view", "VIEW_GUILD_INSIGHTS", "GUILD", all_contexts)
    add("voice.connect", "CONNECT", "VOICE", VOICE_CONTEXTS)
    add("stage.connect", "CONNECT", "STAGE", STAGE_CONTEXTS)
    add("voice.speak", "SPEAK", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("voice.mute_members", "MUTE_MEMBERS", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("stage.mute_members", "MUTE_MEMBERS", "STAGE", STAGE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("voice.deafen_members", "DEAFEN_MEMBERS", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("voice.move_members", "MOVE_MEMBERS", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("stage.move_members", "MOVE_MEMBERS", "STAGE", STAGE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("voice.use_vad", "USE_VAD", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("member.change_nickname", "CHANGE_NICKNAME", "GUILD", all_contexts)
    add("member.manage_nicknames", "MANAGE_NICKNAMES", "GUILD", all_contexts)
    add("role.manage", "MANAGE_ROLES", "GUILD", all_contexts)
    add("overwrite.manage", "MANAGE_ROLES", "GUILD", all_contexts)
    add("webhook.manage", "MANAGE_WEBHOOKS", "TEXT", all_contexts)
    add("guild.expressions.manage", "MANAGE_GUILD_EXPRESSIONS", "GUILD", all_contexts)
    add("application.use_commands", "USE_APPLICATION_COMMANDS", "TEXT", all_contexts)
    add("stage.request_to_speak", "REQUEST_TO_SPEAK", "STAGE", STAGE_CONTEXTS)
    add("event.manage", "MANAGE_EVENTS", "GUILD", VOICE_STAGE_CONTEXTS)
    add("thread.manage", "MANAGE_THREADS", "TEXT", TEXT_CONTEXTS, references=(PERMISSION_SOURCE_URL, THREAD_SOURCE_URL), notes="Thread target/member inheritance is not evaluated in Pass 3.")
    add("thread.create_public", "CREATE_PUBLIC_THREADS", "TEXT", TEXT_CONTEXTS, references=(PERMISSION_SOURCE_URL, THREAD_SOURCE_URL), notes="Thread creation is named; thread membership and inheritance remain out of scope.")
    add("thread.create_private", "CREATE_PRIVATE_THREADS", "TEXT", TEXT_CONTEXTS, references=(PERMISSION_SOURCE_URL, THREAD_SOURCE_URL), notes="Thread creation is named; thread membership and inheritance remain out of scope.")
    add("message.use_external_stickers", "USE_EXTERNAL_STICKERS", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL,))
    add("thread.message_send", "SEND_MESSAGES_IN_THREADS", "TEXT", TEXT_CONTEXTS, references=(PERMISSION_SOURCE_URL, THREAD_SOURCE_URL), notes="Thread membership and inherited permission calculation are not evaluated in Pass 3.")
    add("activity.use_embedded", "USE_EMBEDDED_ACTIVITIES", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("member.moderate", "MODERATE_MEMBERS", "GUILD", all_contexts)
    add("creator_analytics.view", "VIEW_CREATOR_MONETIZATION_ANALYTICS", "GUILD", all_contexts)
    add("voice.use_soundboard", "USE_SOUNDBOARD", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("guild.expressions.create", "CREATE_GUILD_EXPRESSIONS", "GUILD", all_contexts)
    add("event.create", "CREATE_EVENTS", "GUILD", VOICE_STAGE_CONTEXTS)
    add("voice.use_external_sounds", "USE_EXTERNAL_SOUNDS", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("stage.use_external_sounds", "USE_EXTERNAL_SOUNDS", "STAGE", STAGE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("voice.send_voice_messages", "SEND_VOICE_MESSAGES", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST", notes="No SEND_MESSAGES dependency is invented; connection-dependent behavior remains unresolved.")
    add("stage.send_voice_messages", "SEND_VOICE_MESSAGES", "STAGE", STAGE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST", notes="No SEND_MESSAGES dependency is invented; connection-dependent behavior remains unresolved.")
    add("voice.status.set", "SET_VOICE_CHANNEL_STATUS", "VOICE", VOICE_CONTEXTS, deps=(DEP_VOICE_CONNECT,), verification="NEEDS_TEST")
    add("message.send_poll", "SEND_POLLS", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL,), verification="NEEDS_TEST", notes="No SEND_MESSAGES dependency is invented; poll behavior remains a documented expectation.")
    add("application.external_use", "USE_EXTERNAL_APPS", "TEXT", all_contexts, deps=(DEP_VIEW_CHANNEL, DEP_EXTERNAL_APP_BEHAVIOR), verification="NEEDS_TEST", references=(PERMISSION_SOURCE_URL, CHANNEL_SOURCE_URL), notes="Public response versus ephemeral response behavior remains unresolved here.")
    add("message.pin", "PIN_MESSAGES", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL,))
    add("message.bypass_slowmode", "BYPASS_SLOWMODE", "TEXT", TEXT_CONTEXTS, deps=(DEP_VIEW_CHANNEL,))

    return tuple(sorted(c, key=lambda item: (item.permission_bit, item.capability_key)))


DEFAULT_CAPABILITY_REGISTRY: Final[CapabilityRegistry] = CapabilityRegistry(
    version=CAPABILITY_REGISTRY_VERSION,
    permission_definition_version=PERMISSION_DEFINITION_VERSION,
    known_permission_mask=KNOWN_PERMISSION_MASK,
    permission_flags=_PERMISSION_FLAGS,
    capabilities=_build_capabilities(),
)


def validate_capability_registry(registry: CapabilityRegistry) -> tuple[str, ...]:
    """Return deterministic validation failures without correcting a registry."""

    reasons: set[str] = set()
    if not isinstance(registry, CapabilityRegistry):
        return ("CAPABILITY_REGISTRY_INVALID",)
    if registry.version != CAPABILITY_REGISTRY_VERSION:
        reasons.add("CAPABILITY_REGISTRY_VERSION_MISMATCH")
    if registry.permission_definition_version != PERMISSION_DEFINITION_VERSION:
        reasons.add("CAPABILITY_REGISTRY_PERMISSION_DEFINITION_MISMATCH")
    if registry.known_permission_mask != KNOWN_PERMISSION_MASK:
        reasons.add("CAPABILITY_REGISTRY_KNOWN_MASK_MISMATCH")

    seen_flag_bits: set[int] = set()
    seen_flag_names: set[str] = set()
    for flag in registry.permission_flags:
        if flag.bit in seen_flag_bits:
            reasons.add("DUPLICATE_PERMISSION_DEFINITION")
        if flag.name in seen_flag_names:
            reasons.add("DUPLICATE_PERMISSION_FLAG_NAME")
        seen_flag_bits.add(flag.bit)
        seen_flag_names.add(flag.name)
    expected_flags = {(item.bit, item.name) for item in _PERMISSION_FLAGS}
    actual_flags = {(item.bit, item.name) for item in registry.permission_flags}
    if actual_flags != expected_flags:
        reasons.add("CAPABILITY_REGISTRY_PERMISSION_FLAGS_INCOMPLETE")

    seen_capability_keys: set[str] = set()
    for capability in registry.capabilities:
        if capability.capability_key in seen_capability_keys:
            reasons.add("DUPLICATE_CAPABILITY_KEY")
        seen_capability_keys.add(capability.capability_key)
        if capability.permission_bit not in seen_flag_bits:
            reasons.add("CAPABILITY_SOURCE_PERMISSION_UNKNOWN")
        if capability.source_permission_flag not in seen_flag_names:
            reasons.add("CAPABILITY_SOURCE_FLAG_UNKNOWN")
        if not capability.context_types:
            reasons.add("CAPABILITY_CONTEXTS_MISSING")
    mapped_bits = {item.permission_bit for item in registry.capabilities}
    if mapped_bits != {item.bit for item in _PERMISSION_FLAGS}:
        reasons.add("CAPABILITY_REGISTRY_MAPPINGS_INCOMPLETE")
    return tuple(sorted(reasons))


KNOWN_PERMISSION_FLAGS: Final[tuple[PermissionFlagDefinition, ...]] = _PERMISSION_FLAGS


__all__ = [
    "CAPABILITY_REGISTRY_VERSION",
    "CapabilityDefinition",
    "CapabilityRegistry",
    "DEFAULT_CAPABILITY_REGISTRY",
    "DEP_EXTERNAL_APP_BEHAVIOR",
    "DEP_SEND_MESSAGES",
    "DEP_TIMEOUT",
    "DEP_VIEW_CHANNEL",
    "DEP_VOICE_CONNECT",
    "GUILD_SOURCE_URL",
    "KNOWN_PERMISSION_FLAGS",
    "PERMISSION_SOURCE_URL",
    "SUPPORTED_EXECUTABLE_CONTEXTS",
    "TEXT_CONTEXTS",
    "THREAD_SOURCE_URL",
    "CHANNEL_SOURCE_URL",
    "VOICE_CONTEXTS",
    "STAGE_CONTEXTS",
    "validate_capability_registry",
]
