"""Deterministic integration of frozen Stage 3 results with Pass 1 wording.

This module is a read-only composition boundary.  It validates and snapshots
one frozen Stage 3 representation through ``explanation_adapters`` and then
delegates wording to the existing Pass 1 renderer.  It does not call a Stage
3 engine, acquire data, persist data, contact Discord, or execute an action.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .canonical import canonical_json
from .explanation_adapters import (
    AdapterInputError,
    AdaptedExplanationInput,
    Stage3ExplanationAdapterRequest,
    STAGE4_PASS2_CONTRACT_VERSION,
    adapt_stage3_result,
)
from .explanation_engine import render_explanation
from .explanation_schema import ExplanationOutput, ExplanationRequest


INTEGRATION_RULE_RENDER = "EXPLAIN-INTEGRATE-RENDER-001"
INTEGRATION_RULE_INPUT = "EXPLAIN-INTEGRATE-INPUT-001"


def _safe_json(value: Any, key: str = "") -> Any:
    lower = key.lower()
    if lower in {"token", "authorization", "access_token"} or "discord_token" in lower:
        return None
    method = getattr(value, "as_dict", None)
    if callable(method):
        return _safe_json(method(), key)
    if isinstance(value, Mapping):
        return {
            str(item_key): _safe_json(item_value, str(item_key))
            for item_key, item_value in sorted(value.items(), key=lambda item: str(item[0]))
            if str(item_key).lower() not in {"token", "authorization", "access_token"}
            and "discord_token" not in str(item_key).lower()
        }
    if isinstance(value, (list, tuple)):
        return [_safe_json(item, key) for item in value]
    if isinstance(value, (set, frozenset)):
        return [_safe_json(item, key) for item in sorted(value, key=str)]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _fingerprint(value: Any) -> str:
    payload = _safe_json(value)
    if not isinstance(payload, Mapping):
        payload = {"value": payload}
    return hashlib.sha256(canonical_json(dict(payload)).encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class ExplanationIntegrationResult:
    """Stable Pass 2 result containing adapter and optional rendered output."""

    stage4_pass2_contract_version: str
    adapter_registry_version: str
    result_family: str | None
    source_contract: str | None
    source_result_fingerprint: str | None
    source_trace_fingerprint: str | None
    adapter_fingerprint: str | None
    explanation_request: ExplanationRequest | None
    explanation_output: ExplanationOutput | None
    integration_completeness: str
    integration_warnings: tuple[str, ...]
    integration_errors: tuple[str, ...]
    source_objects_unchanged: bool
    deterministic_provenance: Mapping[str, Any]
    integration_fingerprint: str

    @property
    def passed(self) -> bool:
        return not self.integration_errors and self.integration_completeness == "COMPLETE" and self.explanation_output is not None

    def as_dict(self) -> dict[str, Any]:
        request = None if self.explanation_request is None else {
            **self.explanation_request.as_dict(),
            "result": _safe_json(self.explanation_request.result),
            "trace": _safe_json(self.explanation_request.trace or ()),
        }
        output = None if self.explanation_output is None else _safe_json(self.explanation_output.as_dict())
        return {
            "stage4_pass2_contract_version": self.stage4_pass2_contract_version,
            "adapter_registry_version": self.adapter_registry_version,
            "result_family": self.result_family,
            "source_contract": self.source_contract,
            "source_result_fingerprint": self.source_result_fingerprint,
            "source_trace_fingerprint": self.source_trace_fingerprint,
            "adapter_fingerprint": self.adapter_fingerprint,
            "explanation_request": request,
            "explanation_output": output,
            "integration_completeness": self.integration_completeness,
            "integration_warnings": list(self.integration_warnings),
            "integration_errors": list(self.integration_errors),
            "source_objects_unchanged": self.source_objects_unchanged,
            "deterministic_provenance": _safe_json(self.deterministic_provenance),
            "integration_fingerprint": self.integration_fingerprint,
            "passed": self.passed,
        }


def _result_from_adaptation(adapted: AdaptedExplanationInput, output: ExplanationOutput | None, errors: list[str]) -> ExplanationIntegrationResult:
    warnings = list(adapted.adapter_warnings)
    completeness = adapted.integration_completeness
    if errors:
        completeness = "INCOMPLETE" if completeness == "COMPLETE" else completeness
    provenance = dict(adapted.deterministic_provenance)
    provenance.update({
        "adapter_fingerprint": adapted.adapter_fingerprint,
        "source_objects_unchanged": adapted.source_objects_unchanged,
        "renderer": "guild_doctor_scanner.explanation_engine.render_explanation" if output is not None else None,
        "rendering_performed": output is not None,
    })
    payload = {
        "stage4_pass2_contract_version": STAGE4_PASS2_CONTRACT_VERSION,
        "adapter_registry_version": adapted.adapter_registry_version,
        "result_family": adapted.result_family,
        "source_contract": adapted.source_contract,
        "source_result_fingerprint": adapted.source_result_fingerprint,
        "source_trace_fingerprint": adapted.source_trace_fingerprint,
        "adapter_fingerprint": adapted.adapter_fingerprint,
        "explanation_fingerprint": output.explanation_fingerprint if output else None,
        "integration_completeness": completeness,
        "integration_warnings": warnings,
        "integration_errors": errors,
        "provenance": provenance,
    }
    return ExplanationIntegrationResult(
        stage4_pass2_contract_version=STAGE4_PASS2_CONTRACT_VERSION,
        adapter_registry_version=adapted.adapter_registry_version,
        result_family=adapted.result_family,
        source_contract=adapted.source_contract,
        source_result_fingerprint=adapted.source_result_fingerprint,
        source_trace_fingerprint=adapted.source_trace_fingerprint,
        adapter_fingerprint=adapted.adapter_fingerprint,
        explanation_request=adapted.explanation_request,
        explanation_output=output,
        integration_completeness=completeness,
        integration_warnings=tuple(dict.fromkeys(warnings)),
        integration_errors=tuple(dict.fromkeys(errors)),
        source_objects_unchanged=adapted.source_objects_unchanged,
        deterministic_provenance=provenance,
        integration_fingerprint=_fingerprint(payload),
    )


def integrate_stage3_result(
    source_result: Stage3ExplanationAdapterRequest | Mapping[str, Any] | Any,
    *,
    result_family: str | None = None,
    source_contract: str | None = None,
    strict: bool = False,
    **kwargs: Any,
) -> ExplanationIntegrationResult:
    """Adapt and render one frozen Stage 3 result without evaluating it."""

    try:
        adapted = adapt_stage3_result(
            source_result,
            result_family=result_family,
            source_contract=source_contract,
            strict=False,
            **kwargs,
        )
    except (AdapterInputError, TypeError, ValueError) as exc:
        # Keep the default integration API report-oriented.  ``strict`` still
        # raises below so callers can opt into fail-fast behavior.
        adapted = adapt_stage3_result(
            {"source_result": {}, "result_family": result_family, "mode": kwargs.get("mode", "SIMPLE")},
            result_family=result_family,
            source_contract=source_contract,
            strict=False,
        )
        errors = [f"{INTEGRATION_RULE_INPUT}: {exc}"]
        result = _result_from_adaptation(adapted, None, errors)
        if strict:
            raise AdapterInputError("; ".join(result.integration_errors)) from exc
        return result

    errors = list(adapted.adapter_errors)
    output: ExplanationOutput | None = None
    if not errors and adapted.explanation_request is not None:
        try:
            output = render_explanation(adapted.explanation_request)
        except Exception as exc:  # renderer failures are part of the report contract
            errors.append(f"{INTEGRATION_RULE_RENDER}: explanation rendering failed: {type(exc).__name__}: {exc}")
    result = _result_from_adaptation(adapted, output, errors)
    if strict and result.integration_errors:
        raise AdapterInputError("; ".join(result.integration_errors))
    return result


__all__ = [
    "ExplanationIntegrationResult",
    "INTEGRATION_RULE_INPUT",
    "INTEGRATION_RULE_RENDER",
    "integrate_stage3_result",
]
