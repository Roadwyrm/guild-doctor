"""Deterministic offline configuration for the read-only private alpha.

This module performs local JSON parsing and pure validation only.  It has no
Discord, HTTP, Gateway, synchronization, prompting, or mutation surface.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
from types import MappingProxyType
from typing import Any


PASS2_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS2-ALPHA-DEPLOYMENT-CONFIGURATION-0.1"
CONFIGURATION_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-CONFIGURATION-0.1"
SECRET_ENVIRONMENT_VARIABLE = "GUILD_DOCTOR_DISCORD_TOKEN"
MAX_CONFIGURATION_BYTES = 65_536

OPERATING_MODE = "READ_ONLY_PRIVATE_ALPHA"
STARTUP_MODE = "PREFLIGHT_ONLY"
DISABLED = "DISABLED"
AUTHORIZATION_POLICY = "GUILD_OWNER_ONLY"
LOCAL_EXPORT_POLICY = "EXPLICIT_OWNER_LOCAL_ONLY"
SECRET_BOUNDARY = "PROCESS_ENVIRONMENT_PRESENCE_ONLY"

CONFIGURATION_FIELDS = frozenset({
    "configuration_contract",
    "operating_mode",
    "guild_allowlist",
    "secret_boundary",
    "secret_environment_variable",
    "startup_mode",
    "command_registration_state",
    "gateway_state",
    "network_state",
    "background_scanning_state",
    "guild_mutation_state",
    "public_availability_state",
    "remote_storage_state",
    "telemetry_state",
    "attachment_delivery_state",
    "local_export_policy",
    "authorization_policy",
})

CONFIGURATION_ERRORS = frozenset({
    "STAGE8_CONFIG_PATH_REQUIRED",
    "STAGE8_CONFIG_SOURCE_UNSUPPORTED",
    "STAGE8_CONFIG_EXAMPLE_NOT_ACTIVE",
    "STAGE8_CONFIG_MISSING",
    "STAGE8_CONFIG_UNREADABLE",
    "STAGE8_CONFIG_OVERSIZED",
    "STAGE8_CONFIG_MALFORMED_JSON",
    "STAGE8_CONFIG_DUPLICATE_JSON_KEY",
    "STAGE8_CONFIG_CONTRACT_MISMATCH",
    "STAGE8_CONFIG_UNKNOWN_FIELD",
    "STAGE8_CONFIG_MISSING_FIELD",
    "STAGE8_CONFIG_INVALID_FIELD_TYPE",
    "STAGE8_CONFIG_OPERATING_MODE_INVALID",
    "STAGE8_CONFIG_STARTUP_MODE_INVALID",
    "STAGE8_CONFIG_UNSAFE_CAPABILITY_ENABLED",
    "STAGE8_CONFIG_AUTHORIZATION_INVALID",
    "STAGE8_CONFIG_LOCAL_EXPORT_INVALID",
    "STAGE8_CONFIG_SECRET_BOUNDARY_INVALID",
    "STAGE8_ALLOWLIST_MISSING",
    "STAGE8_ALLOWLIST_EMPTY",
    "STAGE8_ALLOWLIST_IDENTIFIER_INVALID",
    "STAGE8_ALLOWLIST_DUPLICATE_IDENTIFIER",
    "STAGE8_ALLOWLIST_WILDCARD_SCOPE",
})

ALLOWLIST_STATES = frozenset({
    "ALLOWED",
    "DENIED",
    "CONFIGURATION_UNAVAILABLE",
    "CONFIGURATION_INVALID",
    "GUILD_CONTEXT_MISSING",
})
SECRET_PRESENCE_STATES = frozenset({"PRESENT", "MISSING", "EMPTY", "UNAVAILABLE"})
_SNOWFLAKE = re.compile(r"^[1-9][0-9]{16,19}$")
_URL = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*://")
_MISSING = object()


class PrivateAlphaConfigurationError(ValueError):
    """Classified configuration failure with no raw input disclosure."""

    def __init__(self, code: str):
        if code not in CONFIGURATION_ERRORS:
            code = "STAGE8_CONFIG_MALFORMED_JSON"
        self.code = code
        super().__init__(code)


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise PrivateAlphaConfigurationError("STAGE8_CONFIG_DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def _canonical(value: Mapping[str, Any]) -> str:
    return json.dumps(dict(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _configuration_payload(config: "PrivateAlphaConfiguration") -> dict[str, Any]:
    return {
        "configuration_contract": config.configuration_contract,
        "operating_mode": config.operating_mode,
        "guild_allowlist": list(config.guild_allowlist),
        "secret_boundary": config.secret_boundary,
        "secret_environment_variable": config.secret_environment_variable,
        "startup_mode": config.startup_mode,
        "command_registration_state": config.command_registration_state,
        "gateway_state": config.gateway_state,
        "network_state": config.network_state,
        "background_scanning_state": config.background_scanning_state,
        "guild_mutation_state": config.guild_mutation_state,
        "public_availability_state": config.public_availability_state,
        "remote_storage_state": config.remote_storage_state,
        "telemetry_state": config.telemetry_state,
        "attachment_delivery_state": config.attachment_delivery_state,
        "local_export_policy": config.local_export_policy,
        "authorization_policy": config.authorization_policy,
    }


@dataclass(frozen=True, slots=True)
class PrivateAlphaConfiguration:
    configuration_contract: str
    operating_mode: str
    guild_allowlist: tuple[str, ...]
    secret_boundary: str
    secret_environment_variable: str
    startup_mode: str
    command_registration_state: str
    gateway_state: str
    network_state: str
    background_scanning_state: str
    guild_mutation_state: str
    public_availability_state: str
    remote_storage_state: str
    telemetry_state: str
    attachment_delivery_state: str
    local_export_policy: str
    authorization_policy: str

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(_canonical(_configuration_payload(self)).encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class AllowlistDecision:
    state: str
    reason_code: str

    def as_dict(self) -> dict[str, str]:
        return {"state": self.state, "reason_code": self.reason_code}


@dataclass(frozen=True, slots=True)
class SecretPresence:
    state: str
    reason_code: str

    def as_dict(self) -> dict[str, str]:
        return {"state": self.state, "reason_code": self.reason_code}


def validate_guild_allowlist(value: Any) -> tuple[str, ...]:
    if value is None:
        raise PrivateAlphaConfigurationError("STAGE8_ALLOWLIST_MISSING")
    if not isinstance(value, list):
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_INVALID_FIELD_TYPE")
    if not value:
        raise PrivateAlphaConfigurationError("STAGE8_ALLOWLIST_EMPTY")
    checked: list[str] = []
    seen: set[str] = set()
    for item in value:
        if not isinstance(item, str):
            raise PrivateAlphaConfigurationError("STAGE8_ALLOWLIST_IDENTIFIER_INVALID")
        if item.casefold() == "all" or item == "*" or "*" in item:
            raise PrivateAlphaConfigurationError("STAGE8_ALLOWLIST_WILDCARD_SCOPE")
        if not _SNOWFLAKE.fullmatch(item):
            raise PrivateAlphaConfigurationError("STAGE8_ALLOWLIST_IDENTIFIER_INVALID")
        if item in seen:
            raise PrivateAlphaConfigurationError("STAGE8_ALLOWLIST_DUPLICATE_IDENTIFIER")
        seen.add(item)
        checked.append(item)
    return tuple(sorted(checked, key=int))


def validate_configuration_mapping(value: Any) -> PrivateAlphaConfiguration:
    if not isinstance(value, Mapping):
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_INVALID_FIELD_TYPE")
    keys = frozenset(value)
    missing = CONFIGURATION_FIELDS - keys
    unknown = keys - CONFIGURATION_FIELDS
    if missing:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_MISSING_FIELD")
    if unknown:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_UNKNOWN_FIELD")
    if any(not isinstance(value[field], str) for field in CONFIGURATION_FIELDS - {"guild_allowlist"}):
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_INVALID_FIELD_TYPE")
    if value["configuration_contract"] != CONFIGURATION_CONTRACT:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_CONTRACT_MISMATCH")
    if value["operating_mode"] != OPERATING_MODE:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_OPERATING_MODE_INVALID")
    if value["startup_mode"] != STARTUP_MODE:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_STARTUP_MODE_INVALID")
    for field in (
        "command_registration_state", "gateway_state", "network_state",
        "background_scanning_state", "guild_mutation_state", "public_availability_state",
        "remote_storage_state", "telemetry_state", "attachment_delivery_state",
    ):
        if value[field] != DISABLED:
            raise PrivateAlphaConfigurationError("STAGE8_CONFIG_UNSAFE_CAPABILITY_ENABLED")
    if value["authorization_policy"] != AUTHORIZATION_POLICY:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_AUTHORIZATION_INVALID")
    if value["local_export_policy"] != LOCAL_EXPORT_POLICY:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_LOCAL_EXPORT_INVALID")
    if value["secret_boundary"] != SECRET_BOUNDARY or value["secret_environment_variable"] != SECRET_ENVIRONMENT_VARIABLE:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_SECRET_BOUNDARY_INVALID")
    allowlist = validate_guild_allowlist(value["guild_allowlist"])
    return PrivateAlphaConfiguration(
        **{field: value[field] for field in CONFIGURATION_FIELDS - {"guild_allowlist"}},
        guild_allowlist=allowlist,
    )


def parse_configuration_text(text: str) -> PrivateAlphaConfiguration:
    try:
        value = json.loads(text, object_pairs_hook=_reject_duplicate_keys)
    except PrivateAlphaConfigurationError:
        raise
    except (json.JSONDecodeError, UnicodeError, TypeError):
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_MALFORMED_JSON") from None
    return validate_configuration_mapping(value)


def _validate_local_path(path: Path | str | None) -> Path:
    if path is None or str(path) == "":
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_PATH_REQUIRED")
    raw = str(path)
    if _URL.match(raw) or raw.startswith("\\\\") or raw.startswith("//"):
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_SOURCE_UNSUPPORTED")
    resolved = Path(path)
    if resolved.name.endswith(".example.json"):
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_EXAMPLE_NOT_ACTIVE")
    return resolved


def load_configuration(path: Path | str | None) -> PrivateAlphaConfiguration:
    source = _validate_local_path(path)
    try:
        size = source.stat().st_size
    except FileNotFoundError:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_MISSING") from None
    except OSError:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_UNREADABLE") from None
    if size > MAX_CONFIGURATION_BYTES:
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_OVERSIZED")
    try:
        text = source.read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        raise PrivateAlphaConfigurationError("STAGE8_CONFIG_UNREADABLE") from None
    return parse_configuration_text(text)


def decide_allowlist(
    configuration: PrivateAlphaConfiguration | None,
    guild_id: str | None,
    *,
    configuration_valid: bool = True,
) -> AllowlistDecision:
    if configuration is None:
        return AllowlistDecision("CONFIGURATION_UNAVAILABLE", "STAGE8_ALLOWLIST_CONFIGURATION_UNAVAILABLE")
    if not configuration_valid:
        return AllowlistDecision("CONFIGURATION_INVALID", "STAGE8_ALLOWLIST_CONFIGURATION_INVALID")
    if guild_id is None or guild_id == "":
        return AllowlistDecision("GUILD_CONTEXT_MISSING", "STAGE8_ALLOWLIST_GUILD_CONTEXT_MISSING")
    if not isinstance(guild_id, str) or not _SNOWFLAKE.fullmatch(guild_id):
        return AllowlistDecision("DENIED", "STAGE8_ALLOWLIST_EXACT_MATCH_REQUIRED")
    if guild_id in configuration.guild_allowlist:
        return AllowlistDecision("ALLOWED", "STAGE8_ALLOWLIST_EXACT_MATCH")
    return AllowlistDecision("DENIED", "STAGE8_ALLOWLIST_NOT_APPROVED")


def check_secret_presence(
    environment: Mapping[str, Any] | None,
    name: str = SECRET_ENVIRONMENT_VARIABLE,
) -> SecretPresence:
    if environment is None:
        return SecretPresence("UNAVAILABLE", "STAGE8_SECRET_SOURCE_UNAVAILABLE")
    try:
        value = environment.get(name, _MISSING)
    except Exception:
        return SecretPresence("UNAVAILABLE", "STAGE8_SECRET_SOURCE_UNAVAILABLE")
    if value is _MISSING:
        return SecretPresence("MISSING", "STAGE8_SECRET_MISSING")
    if value is None or value == "":
        return SecretPresence("EMPTY", "STAGE8_SECRET_EMPTY")
    return SecretPresence("PRESENT", "STAGE8_SECRET_PRESENT")


def public_configuration_summary(config: PrivateAlphaConfiguration) -> Mapping[str, Any]:
    return MappingProxyType({
        "configuration_contract": config.configuration_contract,
        "operating_mode": config.operating_mode,
        "allowlist_count": len(config.guild_allowlist),
        "configuration_fingerprint": config.fingerprint,
        "startup_mode": config.startup_mode,
        "authorization_policy": config.authorization_policy,
        "dangerous_capabilities": "DISABLED",
    })


__all__ = [
    "ALLOWLIST_STATES", "AUTHORIZATION_POLICY", "CONFIGURATION_CONTRACT", "CONFIGURATION_ERRORS",
    "CONFIGURATION_FIELDS", "DISABLED", "LOCAL_EXPORT_POLICY", "MAX_CONFIGURATION_BYTES",
    "OPERATING_MODE", "PASS2_CONTRACT", "SECRET_BOUNDARY", "SECRET_ENVIRONMENT_VARIABLE",
    "SECRET_PRESENCE_STATES", "STARTUP_MODE", "AllowlistDecision", "PrivateAlphaConfiguration",
    "PrivateAlphaConfigurationError", "SecretPresence", "check_secret_presence", "decide_allowlist",
    "load_configuration", "parse_configuration_text", "public_configuration_summary",
    "validate_configuration_mapping", "validate_guild_allowlist",
]
