"""Immutable Stage 5 Pass 1 diagnostic-query contract.

The Doctor layer accepts one explicit subject and one explicit target.  It is
deliberately a data/validation boundary: it does not acquire Discord data,
parse natural language, or contain a credential field.
"""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .action_registry import ACTION_RULES_BY_KEY, ACTION_RULES_VERSION
from .capability_registry import CAPABILITY_REGISTRY_VERSION, DEFAULT_CAPABILITY_REGISTRY
from .constants import PERMISSION_DEFINITION_VERSION, SNAPSHOT_SCHEMA_VERSION
from .fixture_export import STAGE3_FIXTURE_VERSION
from .explanation_adapters import EXPLANATION_ADAPTERS_VERSION
from .explanation_orchestrator import STAGE4_PASS3_CONTRACT_VERSION
from .explanation_schema import EXPLANATION_MODES
from .explanation_query import EXPLANATION_QUERY_CONTRACT_VERSION
from .mfa_rules import MFA_RULES_VERSION
from .object_preconditions import OBJECT_PRECONDITIONS_VERSION
from .authority_engine import STAGE3_PASS5_ENGINE_CONTRACT_VERSION
from .permission_engine import STAGE3_PASS1_ENGINE_CONTRACT_VERSION
from .permission_overwrite_engine import STAGE3_PASS2_ENGINE_CONTRACT_VERSION
from .capability_engine import STAGE3_PASS3_ENGINE_CONTRACT_VERSION
from .thread_engine import STAGE3_PASS4_ENGINE_CONTRACT_VERSION
from .thread_rules import THREAD_RULES_VERSION


STAGE5_PASS1_CONTRACT_VERSION = "GUILD-DOCTOR-STAGE5-PASS1-0.1"
DOCTOR_QUERY_CONTRACT_VERSION = "GUILD-DOCTOR-DOCTOR-QUERY-0.1"

WHY_CAN = "WHY_CAN"
WHY_CANNOT = "WHY_CANNOT"
WHY_UNKNOWN = "WHY_UNKNOWN"
EXPLAIN_ACTUAL_RESULT = "EXPLAIN_ACTUAL_RESULT"
QUERY_INTENTS = frozenset({WHY_CAN, WHY_CANNOT, WHY_UNKNOWN, EXPLAIN_ACTUAL_RESULT})

CAPABILITY = "CAPABILITY"
ACTION = "ACTION"
TARGET_KINDS = frozenset({CAPABILITY, ACTION})

SUPPORTED_CONTEXT_TYPES = frozenset(
    {
        "GUILD",
        "CATEGORY",
        "TEXT",
        "ANNOUNCEMENT",
        "VOICE",
        "STAGE",
        "FORUM",
        "MEDIA",
        "PUBLIC_THREAD",
        "PRIVATE_THREAD",
        "ANNOUNCEMENT_THREAD",
    }
)
SNAPSHOT_VERSIONS = frozenset({SNAPSHOT_SCHEMA_VERSION, STAGE3_FIXTURE_VERSION})

_SECRET_KEY_FRAGMENTS = ("token", "authorization", "access_token", "client_secret", "password", "api_key", "credential")
_FORBIDDEN_KEYS = frozenset(
    {
        "question",
        "natural_language_question",
        "prompt",
        "recommendation",
        "recommendations",
        "remediation",
        "repair",
        "environment",
        "database",
        "connection",
        "interaction",
        "callback",
        "live_discord_object",
    }
)
_TOKEN_SHAPE = re.compile(r"^[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{8,}$")


class DoctorQueryError(ValueError):
    """Raised for a malformed Doctor query when strict construction is used."""


def _text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def _upper(value: Any) -> str | None:
    value = _text(value)
    return value.upper() if value else None


def _snowflake(value: Any) -> str | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, str) and value.strip().isdecimal() and int(value.strip()) > 0:
        return str(int(value.strip()))
    return None


def _tuple_text(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (value.strip(),) if value.strip() else ()
    if isinstance(value, Mapping):
        value = value.values()
    if isinstance(value, Sequence) or isinstance(value, (set, frozenset)):
        return tuple(sorted({str(item).strip() for item in value if str(item).strip()}))
    return ()


def _freeze(value: Any) -> Any:
    """Recursively freeze JSON-like input without changing its values."""

    method = getattr(value, "as_dict", None)
    if callable(method):
        value = method()
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(value[key]) for key in sorted(value, key=lambda item: str(item))})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return tuple(_freeze(item) for item in sorted(value, key=str))
    return deepcopy(value)


def thaw(value: Any) -> Any:
    """Return a detached mutable JSON-like copy for a frozen input."""

    if isinstance(value, Mapping):
        return {str(key): thaw(child) for key, child in value.items()}
    if isinstance(value, (tuple, list)):
        return [thaw(child) for child in value]
    return deepcopy(value)


def _redact(value: Any, key: str = "") -> Any:
    """Keep serialized diagnostics credential-free even for invalid input."""

    lower = key.lower()
    if any(fragment in lower for fragment in _SECRET_KEY_FRAGMENTS):
        return None
    if isinstance(value, Mapping):
        return {
            str(child_key): _redact(child, str(child_key))
            for child_key, child in value.items()
            if not any(fragment in str(child_key).lower() for fragment in _SECRET_KEY_FRAGMENTS)
        }
    if isinstance(value, list):
        return [_redact(child, key) for child in value]
    if isinstance(value, str) and ("bot " in value.lower() or _TOKEN_SHAPE.fullmatch(value.strip())):
        return None
    return value


def _scan_forbidden(value: Any, path: str = "query") -> tuple[str, ...]:
    errors: list[str] = []
    if callable(value):
        errors.append(f"QUERY_FORBIDDEN_EXECUTABLE:{path}")
    elif isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            lower = key_text.lower()
            child_path = f"{path}.{key_text}"
            if any(fragment in lower for fragment in _SECRET_KEY_FRAGMENTS):
                errors.append(f"QUERY_CREDENTIAL_FIELD:{child_path}")
            if lower in _FORBIDDEN_KEYS:
                errors.append(f"QUERY_FORBIDDEN_FIELD:{child_path}")
            errors.extend(_scan_forbidden(child, child_path))
    elif isinstance(value, (list, tuple, set, frozenset)):
        for index, child in enumerate(value):
            errors.extend(_scan_forbidden(child, f"{path}[{index}]"))
    elif isinstance(value, str):
        lower = value.lower()
        if "bot " in lower or _TOKEN_SHAPE.fullmatch(value.strip()):
            errors.append(f"QUERY_CREDENTIAL_VALUE:{path}")
    return tuple(sorted(set(errors)))


@dataclass(frozen=True, slots=True)
class DoctorQuery:
    """One immutable single-subject diagnostic request."""

    query_id: str
    query_intent: str
    target_kind: str
    target_key: str
    guild_id: str
    subject_id: str
    actor_id: str | None = None
    target_type: str | None = None
    target_id: str | None = None
    context_id: str | None = None
    context_type: str | None = None
    parent_id: str | None = None
    thread_id: str | None = None
    thread_type: str | None = None
    assigned_role_ids: tuple[str, ...] | None = None
    timeout_state: str | None = None
    membership_state: str | None = None
    bypass_state: str | None = None
    explicitly_supplied_member_health: Mapping[str, Any] | None = None
    explicitly_supplied_role_reference_health: Mapping[str, Any] | None = None
    actor_highest_role_id: str | None = None
    actor_highest_role_position: int | None = None
    target_highest_role_id: str | None = None
    target_highest_role_position: int | None = None
    target_role_managed: bool | None = None
    target_role_is_everyone: bool | None = None
    requested_permission_bits: str | None = None
    requested_overwrite_allow_bits: str | None = None
    requested_overwrite_deny_bits: str | None = None
    actor_mfa_state: str | None = None
    guild_mfa_level: str | None = None
    voice_state: Mapping[str, Any] | None = None
    snapshot: Mapping[str, Any] | None = None
    member_record: Mapping[str, Any] | None = None
    target_record: Mapping[str, Any] | None = None
    input_health: Mapping[str, Any] | None = None
    source_stage3_contract_versions: Mapping[str, str] | None = None
    registry_versions: Mapping[str, str] | None = None
    permission_definition_version: str = PERMISSION_DEFINITION_VERSION
    snapshot_or_fixture_version: str | None = None
    explanation_mode: str = "SIMPLE"
    presentation_profile: str = "SIMPLE_CARD"
    output_format: str = "PLAIN_TEXT"
    labels: Mapping[str, str] | None = None
    evidence_classifications: tuple[str, ...] = ()
    verification_statuses: tuple[str, ...] = ()
    source_references: tuple[str, ...] = ()
    authoritative_closure: Mapping[str, Any] | None = None
    historical_evidence: Mapping[str, Any] | None = None
    query_contract_version: str = DOCTOR_QUERY_CONTRACT_VERSION
    requested_stage5_pass1_contract: str = STAGE5_PASS1_CONTRACT_VERSION

    def __post_init__(self) -> None:
        for field_name in ("guild_id", "subject_id", "actor_id", "target_id", "context_id", "parent_id", "thread_id", "actor_highest_role_id", "target_highest_role_id"):
            object.__setattr__(self, field_name, _snowflake(getattr(self, field_name)))
        for field_name in ("query_intent", "target_kind", "target_type", "context_type", "thread_type", "timeout_state", "membership_state", "bypass_state", "actor_mfa_state", "guild_mfa_level", "explanation_mode", "presentation_profile", "output_format"):
            value = _upper(getattr(self, field_name))
            object.__setattr__(self, field_name, value)
        object.__setattr__(self, "query_id", _text(self.query_id) or "")
        object.__setattr__(self, "target_key", _text(self.target_key) or "")
        if self.assigned_role_ids is not None:
            object.__setattr__(self, "assigned_role_ids", tuple(sorted({_snowflake(item) or str(item) for item in self.assigned_role_ids})))
        for field_name in ("explicitly_supplied_member_health", "explicitly_supplied_role_reference_health", "voice_state", "snapshot", "member_record", "target_record", "input_health", "source_stage3_contract_versions", "registry_versions", "labels", "authoritative_closure", "historical_evidence"):
            object.__setattr__(self, field_name, None if getattr(self, field_name) is None else _freeze(getattr(self, field_name)))
        for field_name in ("evidence_classifications", "verification_statuses", "source_references"):
            object.__setattr__(self, field_name, _tuple_text(getattr(self, field_name)))
        for field_name in ("requested_permission_bits", "requested_overwrite_allow_bits", "requested_overwrite_deny_bits"):
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(self, field_name, str(value).strip())

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "DoctorQuery":
        if not isinstance(value, Mapping):
            raise DoctorQueryError("DOCTOR_QUERY_NOT_MAPPING")
        return cls(
            query_id=value.get("query_id", ""),
            query_intent=value.get("query_intent", value.get("intent", "")),
            target_kind=value.get("target_kind", ""),
            target_key=value.get("target_key", ""),
            guild_id=value.get("guild_id"),
            subject_id=value.get("subject_id"),
            actor_id=value.get("actor_id"),
            target_type=value.get("target_type"),
            target_id=value.get("target_id"),
            context_id=value.get("context_id"),
            context_type=value.get("context_type"),
            parent_id=value.get("parent_id", value.get("context_parent_id")),
            thread_id=value.get("thread_id"),
            thread_type=value.get("thread_type"),
            assigned_role_ids=value.get("assigned_role_ids"),
            timeout_state=value.get("timeout_state"),
            membership_state=value.get("membership_state"),
            bypass_state=value.get("bypass_state"),
            explicitly_supplied_member_health=value.get("explicitly_supplied_member_health", value.get("member_health")),
            explicitly_supplied_role_reference_health=value.get("explicitly_supplied_role_reference_health", value.get("role_reference_health")),
            actor_highest_role_id=value.get("actor_highest_role_id"),
            actor_highest_role_position=value.get("actor_highest_role_position"),
            target_highest_role_id=value.get("target_highest_role_id"),
            target_highest_role_position=value.get("target_highest_role_position"),
            target_role_managed=value.get("target_role_managed"),
            target_role_is_everyone=value.get("target_role_is_everyone"),
            requested_permission_bits=value.get("requested_permission_bits"),
            requested_overwrite_allow_bits=value.get("requested_overwrite_allow_bits"),
            requested_overwrite_deny_bits=value.get("requested_overwrite_deny_bits"),
            actor_mfa_state=value.get("actor_mfa_state"),
            guild_mfa_level=value.get("guild_mfa_level"),
            voice_state=value.get("voice_state"),
            snapshot=value.get("snapshot", value.get("normalized_snapshot")),
            member_record=value.get("member_record"),
            target_record=value.get("target_record"),
            input_health=value.get("input_health"),
            source_stage3_contract_versions=value.get("source_stage3_contract_versions", value.get("contract_versions")),
            registry_versions=value.get("registry_versions"),
            permission_definition_version=value.get("permission_definition_version", PERMISSION_DEFINITION_VERSION),
            snapshot_or_fixture_version=value.get("snapshot_or_fixture_version"),
            explanation_mode=value.get("explanation_mode", value.get("mode", "SIMPLE")),
            presentation_profile=value.get("presentation_profile", "SIMPLE_CARD"),
            output_format=value.get("output_format", "PLAIN_TEXT"),
            labels=value.get("labels"),
            evidence_classifications=value.get("evidence_classifications", ()),
            verification_statuses=value.get("verification_statuses", ()),
            source_references=value.get("source_references", ()),
            authoritative_closure=value.get("authoritative_closure"),
            historical_evidence=value.get("historical_evidence"),
            query_contract_version=value.get("query_contract_version", DOCTOR_QUERY_CONTRACT_VERSION),
            requested_stage5_pass1_contract=value.get("requested_stage5_pass1_contract", STAGE5_PASS1_CONTRACT_VERSION),
        )

    def as_dict(self, *, include_source: bool = True) -> dict[str, Any]:
        fields = {
            "query_contract_version": self.query_contract_version,
            "requested_stage5_pass1_contract": self.requested_stage5_pass1_contract,
            "query_id": self.query_id,
            "query_intent": self.query_intent,
            "target_kind": self.target_kind,
            "target_key": self.target_key,
            "guild_id": self.guild_id,
            "subject_id": self.subject_id,
            "actor_id": self.actor_id,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "context_id": self.context_id,
            "context_type": self.context_type,
            "parent_id": self.parent_id,
            "thread_id": self.thread_id,
            "thread_type": self.thread_type,
            "assigned_role_ids": list(self.assigned_role_ids) if self.assigned_role_ids is not None else None,
            "timeout_state": self.timeout_state,
            "membership_state": self.membership_state,
            "bypass_state": self.bypass_state,
            "explicitly_supplied_member_health": _redact(thaw(self.explicitly_supplied_member_health)),
            "explicitly_supplied_role_reference_health": _redact(thaw(self.explicitly_supplied_role_reference_health)),
            "actor_highest_role_id": self.actor_highest_role_id,
            "actor_highest_role_position": self.actor_highest_role_position,
            "target_highest_role_id": self.target_highest_role_id,
            "target_highest_role_position": self.target_highest_role_position,
            "target_role_managed": self.target_role_managed,
            "target_role_is_everyone": self.target_role_is_everyone,
            "requested_permission_bits": self.requested_permission_bits,
            "requested_overwrite_allow_bits": self.requested_overwrite_allow_bits,
            "requested_overwrite_deny_bits": self.requested_overwrite_deny_bits,
            "actor_mfa_state": self.actor_mfa_state,
            "guild_mfa_level": self.guild_mfa_level,
            "voice_state": _redact(thaw(self.voice_state)),
            "input_health": _redact(thaw(self.input_health)),
            "source_stage3_contract_versions": thaw(self.source_stage3_contract_versions) or {},
            "registry_versions": thaw(self.registry_versions) or {},
            "permission_definition_version": self.permission_definition_version,
            "snapshot_or_fixture_version": self.snapshot_or_fixture_version,
            "explanation_mode": self.explanation_mode,
            "presentation_profile": self.presentation_profile,
            "output_format": self.output_format,
            "labels": _redact(thaw(self.labels)) or {},
            "evidence_classifications": list(self.evidence_classifications),
            "verification_statuses": list(self.verification_statuses),
            "source_references": list(self.source_references),
            "authoritative_closure": _redact(thaw(self.authoritative_closure)),
            "historical_evidence": _redact(thaw(self.historical_evidence)),
        }
        if include_source:
            fields["snapshot"] = _redact(thaw(self.snapshot))
            fields["member_record"] = _redact(thaw(self.member_record))
            fields["target_record"] = _redact(thaw(self.target_record))
        return fields


def _snapshot_value(query: DoctorQuery, key: str) -> Any:
    snapshot = query.snapshot
    if isinstance(snapshot, Mapping):
        return snapshot.get(key)
    return None


def validate_doctor_query(value: DoctorQuery | Mapping[str, Any]) -> tuple[str, ...]:
    """Return deterministic validation errors without contacting Discord."""

    if isinstance(value, DoctorQuery):
        query = value
        raw = query.as_dict(include_source=True)
    elif isinstance(value, Mapping):
        raw = deepcopy(dict(value))
        try:
            query = DoctorQuery.from_mapping(value)
        except (DoctorQueryError, TypeError, ValueError) as exc:
            return (f"QUERY_CONSTRUCTION:{exc}",)
    else:
        return ("DOCTOR_QUERY_NOT_MAPPING",)

    errors = list(_scan_forbidden(raw))
    if not query.query_id:
        errors.append("QUERY_ID_MISSING")
    if query.query_contract_version != DOCTOR_QUERY_CONTRACT_VERSION:
        errors.append("QUERY_CONTRACT_UNSUPPORTED")
    if query.requested_stage5_pass1_contract != STAGE5_PASS1_CONTRACT_VERSION:
        errors.append("STAGE5_PASS1_CONTRACT_UNSUPPORTED")
    if query.permission_definition_version != PERMISSION_DEFINITION_VERSION:
        errors.append("PERMISSION_DEFINITION_MISMATCH")
    for key, expected in EXPECTED_STAGE3_CONTRACT_VERSIONS.items():
        supplied = (query.source_stage3_contract_versions or {}).get(key)
        if supplied is not None and supplied != expected:
            errors.append(f"STAGE3_CONTRACT_MISMATCH:{key}")
    for key, expected in EXPECTED_REGISTRY_VERSIONS.items():
        supplied = (query.registry_versions or {}).get(key)
        if supplied is not None and supplied != expected:
            errors.append(f"REGISTRY_VERSION_MISMATCH:{key}")
    if query.query_intent not in QUERY_INTENTS:
        errors.append("QUERY_INTENT_UNKNOWN")
    if query.target_kind not in TARGET_KINDS:
        errors.append("TARGET_KIND_UNKNOWN")
    if not query.target_key:
        errors.append("TARGET_KEY_MISSING")
    elif query.target_kind == CAPABILITY and query.target_key not in {item.capability_key for item in DEFAULT_CAPABILITY_REGISTRY.capabilities}:
        errors.append("CAPABILITY_KEY_UNKNOWN")
    elif query.target_kind == ACTION and query.target_key not in ACTION_RULES_BY_KEY:
        errors.append("OPERATION_KEY_UNKNOWN")
    for field_name in ("guild_id", "subject_id"):
        if _snowflake(getattr(query, field_name)) is None:
            errors.append(f"{field_name.upper()}_MISSING_OR_INVALID")
    if query.target_kind == ACTION and query.actor_id is None:
        errors.append("ACTOR_ID_MISSING_OR_INVALID")
    if query.context_type is not None and query.context_type not in SUPPORTED_CONTEXT_TYPES:
        errors.append("CONTEXT_TYPE_UNSUPPORTED")
    if query.thread_type is not None and query.thread_type not in {"PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"}:
        errors.append("THREAD_TYPE_UNSUPPORTED")
    if query.target_kind == ACTION and query.target_key in ACTION_RULES_BY_KEY:
        rule = ACTION_RULES_BY_KEY[query.target_key]
        if query.target_type is None:
            errors.append("TARGET_TYPE_MISSING")
        elif query.target_type not in rule.target_types:
            errors.append("ACTION_TARGET_TYPE_INCOMPATIBLE")
        if query.context_type is not None and query.context_type not in rule.context_types:
            errors.append("ACTION_CONTEXT_TYPE_INCOMPATIBLE")
        if query.target_type not in {None, "NONE"} and query.target_id is None:
            errors.append("TARGET_ID_MISSING_OR_INVALID")
    if query.target_kind == CAPABILITY and query.context_type is not None:
        capability = next((item for item in DEFAULT_CAPABILITY_REGISTRY.capabilities if item.capability_key == query.target_key), None)
        if capability is not None and query.context_type not in {"GUILD", "CATEGORY", *capability.context_types} and query.context_type not in {"PUBLIC_THREAD", "PRIVATE_THREAD", "ANNOUNCEMENT_THREAD"}:
            errors.append("CAPABILITY_CONTEXT_TYPE_INCOMPATIBLE")
    if query.target_kind == CAPABILITY and query.query_intent == EXPLAIN_ACTUAL_RESULT:
        pass
    if query.snapshot is None:
        errors.append("SNAPSHOT_MISSING")
    else:
        snapshot_guild = _snowflake(_snapshot_value(query, "guild_id"))
        if snapshot_guild is None and isinstance(_snapshot_value(query, "guild"), Mapping):
            snapshot_guild = _snowflake(_snapshot_value(query, "guild").get("id"))
        if snapshot_guild is not None and snapshot_guild != query.guild_id:
            errors.append("GUILD_MISMATCH")
        source = _snapshot_value(query, "source")
        version = query.snapshot_or_fixture_version or _snapshot_value(query, "schema_version") or _snapshot_value(query, "fixture_version")
        if version is None and isinstance(source, Mapping):
            version = source.get("snapshot_schema_version") or source.get("fixture_version")
        if version is not None and version not in SNAPSHOT_VERSIONS:
            errors.append("SNAPSHOT_CONTRACT_UNSUPPORTED")
    if query.member_record is not None:
        member_id = _snowflake(query.member_record.get("id"))
        if member_id is not None and member_id != query.subject_id:
            errors.append("SUBJECT_MEMBER_MISMATCH")
    if query.target_record is not None and query.target_id is not None:
        target_record_id = _snowflake(query.target_record.get("id", query.target_record.get("target_id")))
        if target_record_id is not None and target_record_id != query.target_id:
            errors.append("TARGET_RECORD_MISMATCH")
    if query.explanation_mode not in EXPLANATION_MODES:
        errors.append("EXPLANATION_MODE_UNSUPPORTED")
    if query.labels is not None and any(not isinstance(key, str) or not isinstance(label, str) for key, label in query.labels.items()):
        errors.append("LABEL_MAP_VALUES_INVALID")
    for field_name in ("actor_highest_role_position", "target_highest_role_position"):
        value = getattr(query, field_name)
        if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
            errors.append(f"{field_name.upper()}_INVALID")
    for field_name in ("requested_permission_bits", "requested_overwrite_allow_bits", "requested_overwrite_deny_bits"):
        value = getattr(query, field_name)
        if value is not None and (not str(value).isdecimal() or int(str(value)) < 0):
            errors.append(f"{field_name.upper()}_INVALID")
    if query.query_intent in {WHY_CAN, WHY_CANNOT, WHY_UNKNOWN, EXPLAIN_ACTUAL_RESULT} and query.target_kind not in TARGET_KINDS:
        errors.append("INTENT_TARGET_INCOMPATIBLE")
    return tuple(sorted(set(errors)))


EXPECTED_STAGE3_CONTRACT_VERSIONS = MappingProxyType(
    {
        "pass1_contract_version": STAGE3_PASS1_ENGINE_CONTRACT_VERSION,
        "pass2_contract_version": STAGE3_PASS2_ENGINE_CONTRACT_VERSION,
        "pass3_contract_version": STAGE3_PASS3_ENGINE_CONTRACT_VERSION,
        "pass4_contract_version": STAGE3_PASS4_ENGINE_CONTRACT_VERSION,
        "pass5_contract_version": STAGE3_PASS5_ENGINE_CONTRACT_VERSION,
        "pass6_contract_version": "GUILD-DOCTOR-STAGE3-PASS6-0.1",
    }
)
EXPECTED_REGISTRY_VERSIONS = MappingProxyType(
    {
        "capability_registry_version": CAPABILITY_REGISTRY_VERSION,
        "thread_rules_version": THREAD_RULES_VERSION,
        "authority_rules_version": "GUILD-DOCTOR-AUTHORITY-RULES-0.1",
        "object_preconditions_version": OBJECT_PRECONDITIONS_VERSION,
        "mfa_rules_version": MFA_RULES_VERSION,
        "action_rules_version": ACTION_RULES_VERSION,
        "explanation_adapters_version": EXPLANATION_ADAPTERS_VERSION,
        "explanation_query_contract_version": EXPLANATION_QUERY_CONTRACT_VERSION,
        "stage4_pass3_contract_version": STAGE4_PASS3_CONTRACT_VERSION,
    }
)


__all__ = [
    "ACTION",
    "CAPABILITY",
    "DOCTOR_QUERY_CONTRACT_VERSION",
    "DoctorQuery",
    "DoctorQueryError",
    "EXPLAIN_ACTUAL_RESULT",
    "EXPECTED_REGISTRY_VERSIONS",
    "EXPECTED_STAGE3_CONTRACT_VERSIONS",
    "QUERY_INTENTS",
    "SNAPSHOT_VERSIONS",
    "STAGE5_PASS1_CONTRACT_VERSION",
    "SUPPORTED_CONTEXT_TYPES",
    "TARGET_KINDS",
    "WHY_CAN",
    "WHY_CANNOT",
    "WHY_UNKNOWN",
    "thaw",
    "validate_doctor_query",
]
