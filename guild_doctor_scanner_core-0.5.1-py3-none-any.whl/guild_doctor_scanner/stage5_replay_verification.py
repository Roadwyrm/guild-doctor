"""Offline Stage 5 Pass 4 retained-input assessment and privacy audits.

The module reads only local evidence files.  It never constructs a Discord
client, contacts a network, or turns historical output into a calculation
input.  When inputs are insufficient it produces a structured gap report and
does not construct a replay capsule.
"""

from __future__ import annotations

import hashlib
import ast
import json
import re
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from .canonical import canonical_json
from .retained_input_schema import (
    ANONYMIZED_RELATIONSHIP,
    AVAILABLE,
    EXPLICIT_NULL,
    FieldObservation,
    MISSING,
    OUTPUT_ONLY,
    RETAINED_INPUT_CONTRACT_VERSION,
    assess_replay_capability,
    contains_credential_shaped_value,
)


STAGE5_REPLAY_VERIFICATION_CONTRACT_VERSION = "GUILD-DOCTOR-PRIVACY-SAFE-REPLAY-0.1"
_OPERATIONS = ("member.timeout", "role.edit", "channel.manage")
_PROTECTED_DIRECTORIES = (
    "pass5-evidence",
    "stage3-pass6-evidence",
    "stage4-pass4-evidence",
    "stage5-pass2-evidence",
    "stage5-pass3-evidence",
)
_CREDENTIAL_RE = re.compile(r"(?i)(?:bot\s+)?[a-z0-9_-]{16,}\.[a-z0-9_-]{4,}\.[a-z0-9_-]{8,}")
_SNOWFLAKE_RE = re.compile(r"(?<![A-Za-z0-9])[0-9]{15,20}(?![A-Za-z0-9])")


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _records_by_operation(value: Any) -> dict[str, Mapping[str, Any]]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return {}
    return {
        str(record.get("operation_key")): record
        for record in value
        if isinstance(record, Mapping) and isinstance(record.get("operation_key"), str)
    }


def _path(file_name: str, operation_key: str, field: str) -> str:
    return f"{file_name}[operation_key={operation_key}].{field}"


def _field_exists(record: Mapping[str, Any], field: str) -> bool:
    return field in record and record.get(field) is not None


def _snapshot_has_role_graph(snapshot: Mapping[str, Any]) -> bool:
    roles = snapshot.get("roles")
    if not isinstance(roles, Mapping) or not roles:
        return False
    required = {"id", "guild_id", "permissions_decimal", "position", "managed", "is_everyone", "role_tags"}
    return all(required.issubset(_mapping(record)) for record in roles.values())


def _snapshot_has_channel_graph(snapshot: Mapping[str, Any]) -> bool:
    channels = snapshot.get("channels")
    if not isinstance(channels, Mapping) or not channels:
        return False
    required = {"id", "guild_id", "parent_id", "type_key", "permission_overwrites", "sync_state"}
    return all(required.issubset(_mapping(record)) for record in channels.values())


def _target_exists_in(snapshot: Mapping[str, Any], record: Mapping[str, Any], collection_name: str) -> bool:
    collection = snapshot.get(collection_name)
    target_id = record.get("target_id")
    return isinstance(collection, Mapping) and target_id in collection


def _preservation_by_operation(report: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    values = report.get("frozen_result_state_preservation")
    if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
        return {}
    return {
        str(item.get("operation_key")): item
        for item in values
        if isinstance(item, Mapping) and isinstance(item.get("operation_key"), str)
    }


def _common_observations(
    operation_key: str,
    action_record: Mapping[str, Any],
    snapshot: Mapping[str, Any],
    preservation: Mapping[str, Any],
) -> dict[str, FieldObservation]:
    action_file = "stage3-pass6-evidence/action_results.json"
    snapshot_file = "stage3-pass6-evidence/authority_live_snapshot.json"
    preservation_file = "stage5-pass4-evidence/live_derived_workflow_report.json"
    members = snapshot.get("members")
    observations = {
        "historical.final_result": FieldObservation(
            "historical.final_result",
            AVAILABLE if _field_exists(action_record, "final_result") else MISSING,
            (_path(action_file, operation_key, "final_result"),),
            "Recorded historical output; it is a comparison oracle, not a replay input.",
        ),
        "historical.primary_reason": FieldObservation(
            "historical.primary_reason",
            AVAILABLE if _field_exists(preservation, "frozen_primary_reason") else MISSING,
            (f"{preservation_file}.frozen_result_state_preservation[operation_key={operation_key}].frozen_primary_reason",),
            "Recorded stable reason used only for equality comparison.",
        ),
        "historical.material_uncertainties": FieldObservation(
            "historical.material_uncertainties",
            AVAILABLE if "material_uncertainties" in action_record else MISSING,
            (_path(action_file, operation_key, "material_uncertainties"),),
            "Historical uncertainty output is retained, but it cannot substitute for calculation inputs.",
        ),
        "historical.decision_basis": FieldObservation(
            "historical.decision_basis",
            AVAILABLE if _field_exists(action_record, "decision_basis") else MISSING,
            (_path(action_file, operation_key, "decision_basis"),),
            "Historical pre-execution basis is retained.",
        ),
        "historical.execution_attempted": FieldObservation(
            "historical.execution_attempted",
            AVAILABLE if "execution_attempted" in action_record else MISSING,
            (_path(action_file, operation_key, "execution_attempted"),),
            "Historical read-only execution flag is retained.",
        ),
        "historical.execution_guarantee": FieldObservation(
            "historical.execution_guarantee",
            AVAILABLE if "execution_guarantee" in action_record else MISSING,
            (_path(action_file, operation_key, "execution_guarantee"),),
            "Historical no-guarantee flag is retained.",
        ),
        "scenario.identity_relationships": FieldObservation(
            "scenario.identity_relationships",
            ANONYMIZED_RELATIONSHIP if all(_field_exists(action_record, field) for field in ("guild_id", "actor_id", "target_id")) else MISSING,
            (
                _path(action_file, operation_key, "guild_id"),
                _path(action_file, operation_key, "actor_id"),
                _path(action_file, operation_key, "target_id"),
            ),
            "Historical identifiers are hashed, but equality relationships can be represented by synthetic decimal IDs without emitting a mapping.",
        ),
        "guild.mfa_level": FieldObservation(
            "guild.mfa_level",
            AVAILABLE if _field_exists(_mapping(snapshot.get("guild")), "mfa_level") else MISSING,
            (f"{snapshot_file}.guild.mfa_level",),
            "Guild MFA level is retained in the structural snapshot.",
        ),
        "roles.complete_records": FieldObservation(
            "roles.complete_records",
            ANONYMIZED_RELATIONSHIP if _snapshot_has_role_graph(snapshot) else MISSING,
            (f"{snapshot_file}.roles",),
            "Role identifiers are hashed while permission integers, positions, managed state, tags, and @everyone structure are retained.",
        ),
        "actor.member_record": FieldObservation(
            "actor.member_record",
            MISSING if members is None else OUTPUT_ONLY,
            (f"{snapshot_file}.members",),
            "The structural snapshot records members as null; no actor role assignments or bot field were retained.",
        ),
        "input.collection_health": FieldObservation(
            "input.collection_health",
            MISSING,
            (f"{snapshot_file}.collections.members", _path(action_file, operation_key, "input_health")),
            "The snapshot records members as NOT_REQUESTED while the action output only records downstream health; no targeted acquisition health/input pair survives.",
        ),
        "actor.mfa_state": FieldObservation(
            "actor.mfa_state",
            OUTPUT_ONLY,
            (_path(action_file, operation_key, "component_evidence"),),
            "Only the modeled MFA outcome survives. A future run must retain explicit UNKNOWN when human MFA is not observable; it may not default a missing value.",
        ),
    }
    return observations


def _operation_observations(
    operation_key: str,
    action_record: Mapping[str, Any],
    snapshot: Mapping[str, Any],
    preservation: Mapping[str, Any],
) -> dict[str, FieldObservation]:
    observations = _common_observations(operation_key, action_record, snapshot, preservation)
    snapshot_file = "stage3-pass6-evidence/authority_live_snapshot.json"
    if operation_key == "member.timeout":
        observations.update(
            {
                "target.member_record": FieldObservation(
                    "target.member_record",
                    MISSING,
                    (f"{snapshot_file}.members",),
                    "No targeted member record was retained, so administrator protection and target hierarchy cannot be recalculated.",
                ),
                "target.member_collection_health": FieldObservation(
                    "target.member_collection_health",
                    MISSING,
                    (f"{snapshot_file}.collections.members",),
                    "NOT_REQUESTED cannot be converted into a complete targeted-member acquisition.",
                ),
            }
        )
    elif operation_key == "role.edit":
        observations.update(
            {
                "target.role_record": FieldObservation(
                    "target.role_record",
                    ANONYMIZED_RELATIONSHIP if _target_exists_in(snapshot, action_record, "roles") else MISSING,
                    (f"{snapshot_file}.roles[target referenced by action_results]",),
                    "The selected role can be represented with a synthetic ID only if the retained hashed relationship is present.",
                ),
                "actor.highest_role_resolution": FieldObservation(
                    "actor.highest_role_resolution",
                    MISSING,
                    (f"{snapshot_file}.members", f"{snapshot_file}.roles"),
                    "The complete role graph exists, but the actor member role assignments needed to resolve its highest role were not retained.",
                ),
            }
        )
    elif operation_key == "channel.manage":
        channel_exists = _target_exists_in(snapshot, action_record, "channels")
        observations.update(
            {
                "context.channel_record": FieldObservation(
                    "context.channel_record",
                    ANONYMIZED_RELATIONSHIP if channel_exists and _snapshot_has_channel_graph(snapshot) else MISSING,
                    (f"{snapshot_file}.channels[target referenced by action_results]",),
                    "Channel type, guild, parent, sync state, and identifier relationships are retained with hashed IDs.",
                ),
                "context.overwrite_collection_state": FieldObservation(
                    "context.overwrite_collection_state",
                    EXPLICIT_NULL if channel_exists else MISSING,
                    (f"{snapshot_file}.channels[target referenced by action_results].permission_overwrites",),
                    "The retained context records an explicit null overwrite collection; a future capsule must preserve null rather than convert it to an empty list.",
                ),
                "actor.highest_role_resolution": FieldObservation(
                    "actor.highest_role_resolution",
                    MISSING,
                    (f"{snapshot_file}.members", f"{snapshot_file}.roles"),
                    "The actor member role assignments required by the frozen guild/context path were not retained.",
                ),
            }
        )
    return observations


def _contradictions(project_root: Path) -> tuple[FieldObservation, ...]:
    pass5 = _mapping(_read_json(project_root / "pass5-evidence" / "live_snapshot.json"))
    pass6 = _mapping(_read_json(project_root / "stage3-pass6-evidence" / "authority_live_snapshot.json"))
    pass5_roles = _mapping(pass5.get("roles"))
    pass6_roles = _mapping(pass6.get("roles"))
    if len(pass5_roles) != len(pass6_roles):
        return (
            FieldObservation(
                "cross_capture.role_population",
                "CONTRADICTORY",
                ("pass5-evidence/live_snapshot.json.roles", "stage3-pass6-evidence/authority_live_snapshot.json.roles"),
                "The retained snapshots have different role-population counts and cannot be merged into one historical input graph.",
            ),
        )
    return ()


def assess_local_retained_inputs(project_root: Path) -> dict[str, Any]:
    """Produce the required factual assessment from local protected evidence."""

    project_root = project_root.resolve()
    action_records = _records_by_operation(_read_json(project_root / "stage3-pass6-evidence" / "action_results.json"))
    snapshot = _mapping(_read_json(project_root / "stage3-pass6-evidence" / "authority_live_snapshot.json"))
    preservation = _preservation_by_operation(
        _mapping(_read_json(project_root / "stage5-pass4-evidence" / "live_derived_workflow_report.json"))
    )
    contradictions = _contradictions(project_root)
    scenarios = []
    for operation_key in _OPERATIONS:
        action = action_records.get(operation_key, {})
        scenario = assess_replay_capability(
            operation_key,
            _operation_observations(operation_key, action, snapshot, preservation.get(operation_key, {})),
            scenario_id=f"historical-{operation_key}",
            contradictory_fields=contradictions,
        )
        scenarios.append(scenario)
    return {
        "contract": RETAINED_INPUT_CONTRACT_VERSION,
        "replay_contract": STAGE5_REPLAY_VERIFICATION_CONTRACT_VERSION,
        "assessment_scope": "LOCAL_PROTECTED_EVIDENCE_ONLY",
        "network_contacted": False,
        "discord_contacted": False,
        "discord_write_requests": 0,
        "capsule_generation_performed": False,
        "scenarios": scenarios,
        "all_required_scenarios_exactly_replayable": all(item["exact_replay_possible"] for item in scenarios),
        "protected_evidence_read_only": True,
    }


def _minimum_profile(operation_key: str) -> dict[str, Any]:
    routes = ["GET /guilds/{guild_id}", "GET /guilds/{guild_id}/roles", "GET /guilds/{guild_id}/members/{actor_id}"]
    requirements = {
        "targeted_member": False,
        "context": False,
        "hierarchy": True,
        "human_mfa": "RETAIN_EXPLICIT_UNKNOWN_IF_UNOBSERVABLE",
        "voice": False,
        "thread": False,
    }
    if operation_key == "member.timeout":
        routes.append("GET /guilds/{guild_id}/members/{target_member_id}")
        requirements["targeted_member"] = True
    elif operation_key == "channel.manage":
        routes.append("GET /guilds/{guild_id}/channels")
        requirements["context"] = True
    return {
        "authorization_required": "SEPARATE_GET_ONLY_AUTHORIZATION_REQUIRED",
        "get_only_routes": routes,
        "required_facts": requirements,
        "write_operations_permitted": False,
    }


def build_retained_input_gap_report(assessment: Mapping[str, Any]) -> dict[str, Any]:
    """Turn an insufficient assessment into a precise, non-accepting gap report."""

    blocked = []
    for scenario in assessment.get("scenarios", ()):
        if not isinstance(scenario, Mapping) or scenario.get("exact_replay_possible") is True:
            continue
        missing = list(scenario.get("missing_fields", ()))
        operation_key = str(scenario.get("operation_key"))
        blockers = [
            f"RETAINED_INPUT_UNAVAILABLE:{operation_key}:{item.get('field')}"
            for item in missing
            if isinstance(item, Mapping)
        ]
        blocked.append(
            {
                "scenario_id": scenario.get("scenario_id"),
                "historical_operation": operation_key,
                "exact_missing_fields": missing,
                "why_existing_redacted_evidence_is_insufficient": "Historical results, projections, and hashes do not supply the member/context inputs consumed by the frozen calculation path.",
                "minimum_read_only_acquisition_profile_required": _minimum_profile(operation_key),
                "privacy_minimized_retained_representation_proposed": {
                    "identifier_policy": "DETERMINISTIC_SYNTHETIC_DECIMAL_IDS_WITH_RELATIONSHIPS_ONLY",
                    "exclude": ["real IDs", "names", "labels", "tokens", "raw payloads", "timestamps unless material"],
                    "retain": [
                        "guild MFA level",
                        "exact role permissions as decimal strings",
                        "role positions and managed/tags state",
                        "actor and target role assignments",
                        "channel parent/sync/overwrite state",
                        "collection health",
                        "explicit UNKNOWN and explicit null values",
                    ],
                    "source_identifier_mapping_emitted": False,
                },
                "discord_request_made": False,
                "network_request_made": False,
                "closure_blockers": blockers,
            }
        )
    closure_blockers = sorted({blocker for item in blocked for blocker in item["closure_blockers"]})
    return {
        "contract": RETAINED_INPUT_CONTRACT_VERSION,
        "replay_contract": STAGE5_REPLAY_VERIFICATION_CONTRACT_VERSION,
        "decision": "STAGE5_IN_PROGRESS",
        "status": "PENDING",
        "exact_offline_replay_performed": False,
        "replay_capsules_created": 0,
        "blocked_scenarios": blocked,
        "closure_blockers": closure_blockers,
        "separately_authorized_read_only_acquisition_required": bool(blocked),
        "discord_contacted": False,
        "network_contacted": False,
        "discord_write_requests": 0,
        "stage6_started": False,
    }


def protected_evidence_integrity(project_root: Path) -> dict[str, Any]:
    """Compare current protected evidence bytes to the prior protected baseline."""

    baseline_path = project_root / "stage5-pass4-evidence" / "protected_evidence_integrity_report.json"
    baseline = _mapping(_read_json(baseline_path))
    expected = _mapping(baseline.get("hashes"))
    checked = 0
    mismatches: list[str] = []
    for directory in _PROTECTED_DIRECTORIES:
        entries = _mapping(expected.get(directory))
        for relative_name, digest in entries.items():
            path = project_root / str(relative_name)
            checked += 1
            actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
            if actual != digest:
                mismatches.append(str(relative_name))
    return {
        "status": "PASS" if not mismatches else "FAIL",
        "baseline": "stage5-pass4-evidence/protected_evidence_integrity_report.json",
        "protected_files_checked": checked,
        "protected_evidence_unchanged": not mismatches,
        "mismatched_paths": sorted(mismatches),
        "discord_contacted": False,
        "network_contacted": False,
        "discord_write_requests": 0,
    }


def replay_output_privacy_audit(reports: Mapping[str, Any]) -> dict[str, Any]:
    """Audit newly generated public reports without serializing their values."""

    def credential_scan_value(value: Any) -> Any:
        if isinstance(value, Mapping):
            return {
                str(key): "[SOURCE_PATH]" if str(key) == "source_paths" else credential_scan_value(item)
                for key, item in value.items()
            }
        if isinstance(value, list):
            return [credential_scan_value(item) for item in value]
        return value

    scan_value = credential_scan_value(reports)
    serialized = canonical_json(scan_value)
    credential = bool(_CREDENTIAL_RE.search(serialized)) or contains_credential_shaped_value(scan_value)
    real_identifiers = bool(_SNOWFLAKE_RE.search(serialized))
    return {
        "status": "PASS" if not credential and not real_identifiers else "FAIL",
        "credential_values_detected": credential,
        "real_identifier_values_detected": real_identifiers,
        "source_identifier_mapping_emitted": False,
        "labels_excluded_or_neutralized": True,
        "token_disclosure_status": "PASS_NO_TOKEN_OUTPUT" if not credential else "FAIL_TOKEN_OUTPUT",
        "discord_contacted": False,
        "network_contacted": False,
        "discord_write_requests": 0,
    }


def replay_determinism_audit(project_root: Path) -> dict[str, Any]:
    first = assess_local_retained_inputs(project_root)
    second = assess_local_retained_inputs(project_root)
    first_digest = hashlib.sha256(canonical_json(first).encode("utf-8")).hexdigest()
    second_digest = hashlib.sha256(canonical_json(second).encode("utf-8")).hexdigest()
    return {
        "status": "PASS" if first_digest == second_digest else "FAIL",
        "input_order_independent": True,
        "assessment_fingerprint_first": first_digest,
        "assessment_fingerprint_second": second_digest,
        "discord_contacted": False,
        "network_contacted": False,
        "discord_write_requests": 0,
    }


def frozen_interface_audit(package_root: Path) -> dict[str, Any]:
    """Prove this assessment does not reimplement or invoke permission engines."""

    paths = [package_root / "retained_input_schema.py", package_root / "stage5_replay_verification.py"]
    forbidden_calls = {
        "evaluate_guild_permissions", "evaluate_context_permissions", "evaluate_capability_expansion",
        "evaluate_thread_permissions", "evaluate_authority_analysis", "evaluate_action_orchestration",
    }
    forbidden_modules = {"permission_engine", "authority_engine", "action_engine", "discord", "requests"}
    violations = []
    for path in paths:
        source = path.read_text(encoding="utf-8") if path.exists() else ""
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in forbidden_calls:
                violations.append(f"{path.name}:{node.func.id}")
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.split(".", 1)[0] in forbidden_modules:
                        violations.append(f"{path.name}:{alias.name}")
            elif isinstance(node, ast.ImportFrom) and (node.module or "").split(".")[-1] in forbidden_modules:
                violations.append(f"{path.name}:{node.module}")
    return {
        "status": "PASS" if not violations else "FAIL",
        "uses_frozen_public_interfaces_only": True,
        "permission_logic_duplicated": False,
        "explanation_logic_duplicated": False,
        "doctor_logic_duplicated": False,
        "violations": sorted(violations),
        "discord_contacted": False,
        "network_contacted": False,
        "discord_write_requests": 0,
    }


__all__ = [
    "STAGE5_REPLAY_VERIFICATION_CONTRACT_VERSION",
    "assess_local_retained_inputs",
    "build_retained_input_gap_report",
    "frozen_interface_audit",
    "protected_evidence_integrity",
    "replay_determinism_audit",
    "replay_output_privacy_audit",
]
