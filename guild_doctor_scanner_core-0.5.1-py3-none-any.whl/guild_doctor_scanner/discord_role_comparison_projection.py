"""Structural-only normalized role projection for the frozen comparison query."""
from .doctor_role_comparison_query import RoleComparisonSubject
def project_role_comparison_subject(role, snapshot, *, index):
    if not isinstance(role, dict) or role.get("guild_id") != snapshot.get("guild_id") or not str(role.get("id","")).isdecimal(): raise ValueError("ROLE_PROJECTION_INVALID")
    return RoleComparisonSubject(comparison_subject_id=str(role["id"]),role_ids=(str(role["id"]),),input_role_ids=(str(role["id"]),),display_safe_label=str(role.get("name") or "role"),input_index=index)
