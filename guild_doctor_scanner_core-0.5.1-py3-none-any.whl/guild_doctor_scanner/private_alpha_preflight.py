"""Pure offline startup preflight for the read-only private alpha."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import importlib.metadata
import json
from pathlib import Path
from types import MappingProxyType
from typing import Any

from .audit_rule_registry import AUDIT_RULES, registry_fingerprint
from .discord_command_manifest import COMMAND_MANIFEST, manifest_fingerprint
from .discord_command_schema import schema_fingerprint
from .discord_interaction_envelope import RESPONSE_KINDS
from .private_alpha_configuration import (
    AUTHORIZATION_POLICY,
    CONFIGURATION_CONTRACT,
    DISABLED,
    LOCAL_EXPORT_POLICY,
    OPERATING_MODE,
    SECRET_BOUNDARY,
    SECRET_ENVIRONMENT_VARIABLE,
    STARTUP_MODE,
    PrivateAlphaConfiguration,
    SecretPresence,
)
from .report_assembly import SECTION_ORDER
from .runtime_provenance import _source_tree_fingerprint


PREFLIGHT_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-PREFLIGHT-0.1"
PASS2_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS2-ALPHA-DEPLOYMENT-CONFIGURATION-0.1"
FROZEN_STAGE7_SOURCE_FINGERPRINT = "038eba37ca60029e324c9d93d1f3604e46faaacb5beb508438559f89d9e4e771"
FROZEN_ROUTE_MANIFEST_FINGERPRINT = "539a9f7bdd2879d2b6d1034a37b6be0631f749ac6d55fb0b20fce206f1986ca1"
FROZEN_COMMAND_SCHEMA_FINGERPRINT = "119ac07fa03a7b9fa7fbded54ec1d47dd56622b35484f0f8c63ea7451693056c"
FROZEN_AUDIT_REGISTRY_FINGERPRINT = "66c37236c70d6988070a538683e2b24eead27457672cf51059b5c6bdb7683e47"
FROZEN_PACKAGE_VERSION = "0.5.1"

PREFLIGHT_STATES = frozenset({
    "READY_OFFLINE",
    "BLOCKED_CONFIGURATION",
    "BLOCKED_ALLOWLIST",
    "BLOCKED_SECRET",
    "BLOCKED_BASELINE",
    "BLOCKED_UNSAFE_CAPABILITY",
    "BLOCKED_RUNTIME_INVENTORY",
    "FAILED_INTERNAL_VALIDATION",
})

PREFLIGHT_ERRORS = frozenset({
    "STAGE8_PREFLIGHT_CONFIGURATION_REQUIRED",
    "STAGE8_PREFLIGHT_CONFIGURATION_INVALID",
    "STAGE8_PREFLIGHT_ALLOWLIST_INVALID",
    "STAGE8_PREFLIGHT_SECRET_MISSING",
    "STAGE8_PREFLIGHT_SECRET_EMPTY",
    "STAGE8_PREFLIGHT_SECRET_UNAVAILABLE",
    "STAGE8_PREFLIGHT_STAGE7_PROTECTED_FILE_MISMATCH",
    "STAGE8_PREFLIGHT_ROUTE_MANIFEST_MISMATCH",
    "STAGE8_PREFLIGHT_COMMAND_SCHEMA_MISMATCH",
    "STAGE8_PREFLIGHT_AUDIT_REGISTRY_MISMATCH",
    "STAGE8_PREFLIGHT_ROUTE_INVENTORY_MISMATCH",
    "STAGE8_PREFLIGHT_ENVELOPE_INVENTORY_MISMATCH",
    "STAGE8_PREFLIGHT_REPORT_SUBTYPE_INVENTORY_MISMATCH",
    "STAGE8_PREFLIGHT_REPORT_SECTION_INVENTORY_MISMATCH",
    "STAGE8_PREFLIGHT_AUDIT_RULE_INVENTORY_MISMATCH",
    "STAGE8_PREFLIGHT_PACKAGE_MISMATCH",
    "STAGE8_PREFLIGHT_PROJECT_SOURCES_MISMATCH",
    "STAGE8_PREFLIGHT_PASS3_PREMATURELY_PRESENT",
    "STAGE8_PREFLIGHT_STAGE9_PREMATURELY_PRESENT",
    "STAGE8_PREFLIGHT_UNSAFE_CAPABILITY",
    "STAGE8_PREFLIGHT_INTERNAL_VALIDATION_FAILED",
})

# Recovered while the complete checkout matched the formal Stage 7 source
# fingerprint.  Newly authorized Stage 8 modules are intentionally excluded.
PROTECTED_STAGE7_FILES = MappingProxyType({
    "guild_doctor_scanner/action_engine.py": "9bdd021f92e55a1e600ff0ad2566373fa7fa46593904a0d1c588ee1d5304031b",
    "guild_doctor_scanner/action_registry.py": "9ca9b883573222a72a973bb90154101a613b17fa48902ab2315432b5e57783bf",
    "guild_doctor_scanner/audit_aggregation.py": "007d287839a73f6b60d6b01e4ae8f43f8d892293eacfec949184ff971c5e77e7",
    "guild_doctor_scanner/audit_contract.py": "e84358013c3049183b037de769d9891872f88d437e761ded7a2b311e8ff38bef",
    "guild_doctor_scanner/audit_finding.py": "595399131f96d32124212deaa42effdf7888c853f40378c16589ea125e297350",
    "guild_doctor_scanner/audit_rule_evaluator.py": "1515df7b130cd4c7dd3b18a6a52734bdef4443befe0408c5aa3814e66eb7ef0c",
    "guild_doctor_scanner/audit_rule_registry.py": "a1942b15e0d86fc7809d1d1cdab670be3c39b72e32cf1162e03357f01c147d34",
    "guild_doctor_scanner/audit_rules_initial.py": "ab2764e399b6a3c3d9ed95a7b83b057b0d33cc9c96173085f5f0885c3e7f64cd",
    "guild_doctor_scanner/authorization.py": "d4efb54366b139529a06671a10c8c52c2f53b0d7fd048c0e8544bd73a29e7e6e",
    "guild_doctor_scanner/capability_engine.py": "119fadd8d41ebe368b951a0b366baa8e0044195ddad75f5eebd546aabddddd04",
    "guild_doctor_scanner/capability_registry.py": "ffe801f2cc0e61865e7fe8da80fcf823126dda3cbf7c212c75e93460a647311e",
    "guild_doctor_scanner/discord_command_manifest.py": "e8f449983c1d06568a68b76829a07090d20ac076cb5a2656479a9372fab5a770",
    "guild_doctor_scanner/discord_command_schema.py": "746fb65a075b2f3cc9c3d462f3b64d1476ae4db7c68aec04e1b2299d5d695b33",
    "guild_doctor_scanner/discord_interaction_envelope.py": "db4ec256f029b95e542e50915a6ef2937ec0c26acb4123fc7e0719db221bbcb6",
    "guild_doctor_scanner/discord_query_adapter.py": "e192967ca543f3d13db0fa3394b95da8b110808f4a1f2592082d3581c514fffa",
    "guild_doctor_scanner/discord_response_renderer.py": "3056b9e1369b0e5999db6ff2e524df646ce888df8d49e98f3a03662239102059",
    "guild_doctor_scanner/discord_user_error_renderer.py": "f6c03094a82ebb5366dab7f72c81b4c576142a6fce8ad64c2ed17a8b7348b1da",
    "guild_doctor_scanner/doctor_engine.py": "ada3fb92eb27cdda09af3a3c2b3933781291a2266d61a7c3143db608877aa332",
    "guild_doctor_scanner/doctor_enumeration_engine.py": "f6e0cd0172e6394ecc23d0d77029a223ff443f8d1cd5bcf4e3b06f243ded667b",
    "guild_doctor_scanner/doctor_role_comparison.py": "f33adb346a6eda11753acf7d1d1235755d1e2140aada4331483546bf9e6a0e04",
    "guild_doctor_scanner/doctor_role_projection.py": "bca40bd7ac4ca0cd74128793dbf4b6e056f2966559844f7bbe8da11924989e1d",
    "guild_doctor_scanner/explanation_engine.py": "f015eed0bfc690ed94acbc44187696c339d9c70eec33e65d42f83a1b2f8d0630",
    "guild_doctor_scanner/explanation_orchestrator.py": "c25cffab187cb4107a3e6637a1ae70fa12029286027ac64115f061517471b77f",
    "guild_doctor_scanner/explanation_runtime.py": "5f986f4ec113c604de035a4613758acee53dd6858ac84f19e0aa570080ac2583",
    "guild_doctor_scanner/export_receipt_validation.py": "166c3e6ffb5901bb4874c2275ab3c95d9569f86de6a018c8e89db2f99e1f1d7e",
    "guild_doctor_scanner/get_only_acquisition.py": "5ac8f3ce60d6e00cb278aab058acb21d063759ab1e8c20c116b0fd143a55eaf8",
    "guild_doctor_scanner/models.py": "55e69db0d746877d9766a1dfe823898985448a5da36245411b7423dd17e9b782",
    "guild_doctor_scanner/normalizer.py": "d7e90916de48b12e7c34730e501ca37e5d62c58782ecead64508385d6207ae81",
    "guild_doctor_scanner/permission_engine.py": "ea080d196b7527a1bd124a67eb18ab74cfd96f3deb36a2d61dced83ccac9d2e3",
    "guild_doctor_scanner/permission_overwrite_engine.py": "a4d8464d21c674063c409386c21b892ea6f37d6e9644204406b8afff9cc8f82b",
    "guild_doctor_scanner/report_assembly.py": "f480a633c536d579eedb5c4cbdfe13b5c5f02858e9506d61ca90ce2b10a832b0",
    "guild_doctor_scanner/report_export.py": "c3f47efc4b7146e069d9dfb12126dbec4b3a26d7bb395a34d57993c0e99d91b7",
    "guild_doctor_scanner/report_interaction_adapter.py": "247424daf2abfe4667f95f8be77a90af465c377d59238590227a5bf709294366",
    "guild_doctor_scanner/server_atlas.py": "e87d449f91a810b461ad3a0c4c4cbca43369d68ecb0c5a0cd01f9af46f6a2606",
})


@dataclass(frozen=True, slots=True)
class PreflightCheck:
    check_id: str
    state: str
    reason_code: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {"check_id": self.check_id, "state": self.state, "reason_code": self.reason_code}


@dataclass(frozen=True, slots=True)
class PrivateAlphaPreflightResult:
    preflight_contract: str
    overall_state: str
    checks: tuple[PreflightCheck, ...]
    reason_codes: tuple[str, ...]
    protected_baseline_state: str
    route_manifest_state: str
    command_schema_state: str
    audit_registry_state: str
    allowlist_state: str
    allowlist_count: int
    secret_presence_state: str
    dangerous_capability_state: str
    package_state: str
    project_sources_state: str
    current_source_fingerprint: str
    preflight_fingerprint: str
    deployment_authorized: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "preflight_contract": self.preflight_contract,
            "overall_state": self.overall_state,
            "checks": [item.as_dict() for item in self.checks],
            "reason_codes": list(self.reason_codes),
            "protected_baseline_state": self.protected_baseline_state,
            "route_manifest_state": self.route_manifest_state,
            "command_schema_state": self.command_schema_state,
            "audit_registry_state": self.audit_registry_state,
            "allowlist_state": self.allowlist_state,
            "allowlist_count": self.allowlist_count,
            "secret_presence_state": self.secret_presence_state,
            "dangerous_capability_state": self.dangerous_capability_state,
            "package_state": self.package_state,
            "project_sources_state": self.project_sources_state,
            "current_source_fingerprint": self.current_source_fingerprint,
            "preflight_fingerprint": self.preflight_fingerprint,
            "deployment_authorized": self.deployment_authorized,
        }


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_protected_stage7_files(
    root: Path,
    expected: Mapping[str, str] = PROTECTED_STAGE7_FILES,
) -> tuple[str, tuple[str, ...]]:
    mismatches = tuple(
        relative
        for relative, digest in sorted(expected.items())
        if not (root / relative).is_file() or _sha(root / relative) != digest
    )
    return ("PASS", ()) if not mismatches else ("FAIL", ("STAGE8_PREFLIGHT_STAGE7_PROTECTED_FILE_MISMATCH",))


def _runtime_inventory(root: Path) -> dict[str, Any]:
    pass3_paths = (
        root / "guild_doctor_scanner/private_alpha_live_transport.py",
        root / "guild_doctor_scanner/private_alpha_command_registration.py",
        root / "stage8-pass3-evidence",
    )
    stage9_paths = (root / "stage9-evidence", root / "guild_doctor_scanner/stage9.py")
    return {
        "route_manifest_fingerprint": manifest_fingerprint(),
        "command_schema_fingerprint": schema_fingerprint(),
        "audit_registry_fingerprint": registry_fingerprint(),
        "route_count": len(COMMAND_MANIFEST),
        "envelope_branch_count": len(RESPONSE_KINDS),
        "report_subtype_count": 2,
        "report_section_count": len(SECTION_ORDER),
        "audit_rule_count": len(AUDIT_RULES),
        "package_version": importlib.metadata.version("guild-doctor-scanner-core"),
        "project_source_count": len(tuple((root / "Guild_Doctor_Project_Sources").rglob("*.md"))),
        "pass3_present": any(path.exists() for path in pass3_paths),
        "stage9_present": any(path.exists() for path in stage9_paths),
    }


def _check_configuration(config: PrivateAlphaConfiguration | None) -> tuple[bool, bool, tuple[str, ...]]:
    if config is None:
        return False, False, ("STAGE8_PREFLIGHT_CONFIGURATION_REQUIRED",)
    identity_valid = (
        config.configuration_contract == CONFIGURATION_CONTRACT
        and config.operating_mode == OPERATING_MODE
        and config.startup_mode == STARTUP_MODE
        and config.secret_boundary == SECRET_BOUNDARY
        and config.secret_environment_variable == SECRET_ENVIRONMENT_VARIABLE
        and config.authorization_policy == AUTHORIZATION_POLICY
        and config.local_export_policy == LOCAL_EXPORT_POLICY
    )
    unsafe = any(getattr(config, field) != DISABLED for field in (
        "command_registration_state", "gateway_state", "network_state", "background_scanning_state",
        "guild_mutation_state", "public_availability_state", "remote_storage_state", "telemetry_state",
        "attachment_delivery_state",
    ))
    return identity_valid, unsafe, (() if identity_valid else ("STAGE8_PREFLIGHT_CONFIGURATION_INVALID",))


def _canonical_fingerprint(value: Mapping[str, Any]) -> str:
    encoded = json.dumps(dict(value), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def run_preflight(
    configuration: PrivateAlphaConfiguration | None,
    secret_presence: SecretPresence,
    root: Path,
    *,
    expected_protected_files: Mapping[str, str] = PROTECTED_STAGE7_FILES,
    inventory_override: Mapping[str, Any] | None = None,
) -> PrivateAlphaPreflightResult:
    root = root.resolve()
    config_valid, unsafe, config_reasons = _check_configuration(configuration)
    allowlist_valid = bool(configuration and configuration.guild_allowlist)
    protected_state, protected_reasons = verify_protected_stage7_files(root, expected_protected_files)
    inventory = dict(inventory_override) if inventory_override is not None else _runtime_inventory(root)

    checks: list[PreflightCheck] = []
    reasons: list[str] = list(config_reasons)

    def check(check_id: str, passed: bool, reason: str) -> None:
        checks.append(PreflightCheck(check_id, "PASS" if passed else "FAIL", None if passed else reason))
        if not passed:
            reasons.append(reason)

    check("CONFIGURATION_PRESENT_AND_SUPPORTED", config_valid, "STAGE8_PREFLIGHT_CONFIGURATION_INVALID")
    check("ALLOWLIST_VALID_AND_NONEMPTY", allowlist_valid, "STAGE8_PREFLIGHT_ALLOWLIST_INVALID")
    check("SECRET_PRESENT_NONEMPTY", secret_presence.state == "PRESENT", {
        "MISSING": "STAGE8_PREFLIGHT_SECRET_MISSING",
        "EMPTY": "STAGE8_PREFLIGHT_SECRET_EMPTY",
        "UNAVAILABLE": "STAGE8_PREFLIGHT_SECRET_UNAVAILABLE",
    }.get(secret_presence.state, "STAGE8_PREFLIGHT_SECRET_UNAVAILABLE"))
    check("DANGEROUS_CAPABILITIES_DISABLED", not unsafe, "STAGE8_PREFLIGHT_UNSAFE_CAPABILITY")
    check("PROTECTED_STAGE7_FILES", protected_state == "PASS", "STAGE8_PREFLIGHT_STAGE7_PROTECTED_FILE_MISMATCH")
    expected_inventory = (
        ("ROUTE_MANIFEST", "route_manifest_fingerprint", FROZEN_ROUTE_MANIFEST_FINGERPRINT, "STAGE8_PREFLIGHT_ROUTE_MANIFEST_MISMATCH"),
        ("COMMAND_SCHEMA", "command_schema_fingerprint", FROZEN_COMMAND_SCHEMA_FINGERPRINT, "STAGE8_PREFLIGHT_COMMAND_SCHEMA_MISMATCH"),
        ("AUDIT_REGISTRY", "audit_registry_fingerprint", FROZEN_AUDIT_REGISTRY_FINGERPRINT, "STAGE8_PREFLIGHT_AUDIT_REGISTRY_MISMATCH"),
        ("ROUTE_INVENTORY", "route_count", 13, "STAGE8_PREFLIGHT_ROUTE_INVENTORY_MISMATCH"),
        ("ENVELOPE_INVENTORY", "envelope_branch_count", 4, "STAGE8_PREFLIGHT_ENVELOPE_INVENTORY_MISMATCH"),
        ("REPORT_SUBTYPE_INVENTORY", "report_subtype_count", 2, "STAGE8_PREFLIGHT_REPORT_SUBTYPE_INVENTORY_MISMATCH"),
        ("REPORT_SECTION_INVENTORY", "report_section_count", 12, "STAGE8_PREFLIGHT_REPORT_SECTION_INVENTORY_MISMATCH"),
        ("AUDIT_RULE_INVENTORY", "audit_rule_count", 7, "STAGE8_PREFLIGHT_AUDIT_RULE_INVENTORY_MISMATCH"),
        ("PACKAGE_VERSION", "package_version", FROZEN_PACKAGE_VERSION, "STAGE8_PREFLIGHT_PACKAGE_MISMATCH"),
        ("PROJECT_SOURCE_INVENTORY", "project_source_count", 25, "STAGE8_PREFLIGHT_PROJECT_SOURCES_MISMATCH"),
        # Pass 3 is now an approved prerequisite of the current Stage 8
        # runtime.  Keep this as an explicit inventory gate so unexpected
        # removal still fails closed.
        ("PASS3_PRESENT", "pass3_present", True, "STAGE8_PREFLIGHT_PASS3_MISSING"),
        ("STAGE9_ABSENT", "stage9_present", False, "STAGE8_PREFLIGHT_STAGE9_PREMATURELY_PRESENT"),
    )
    for check_id, key, expected, reason in expected_inventory:
        check(check_id, inventory.get(key) == expected, reason)

    unique_reasons = tuple(sorted(set(reasons)))
    baseline_reasons = {
        "STAGE8_PREFLIGHT_STAGE7_PROTECTED_FILE_MISMATCH",
        "STAGE8_PREFLIGHT_ROUTE_MANIFEST_MISMATCH",
        "STAGE8_PREFLIGHT_COMMAND_SCHEMA_MISMATCH",
        "STAGE8_PREFLIGHT_AUDIT_REGISTRY_MISMATCH",
    }
    runtime_reasons = {
        "STAGE8_PREFLIGHT_ROUTE_INVENTORY_MISMATCH", "STAGE8_PREFLIGHT_ENVELOPE_INVENTORY_MISMATCH",
        "STAGE8_PREFLIGHT_REPORT_SUBTYPE_INVENTORY_MISMATCH", "STAGE8_PREFLIGHT_REPORT_SECTION_INVENTORY_MISMATCH",
        "STAGE8_PREFLIGHT_AUDIT_RULE_INVENTORY_MISMATCH", "STAGE8_PREFLIGHT_PACKAGE_MISMATCH",
        "STAGE8_PREFLIGHT_PROJECT_SOURCES_MISMATCH", "STAGE8_PREFLIGHT_PASS3_MISSING",
        "STAGE8_PREFLIGHT_STAGE9_PREMATURELY_PRESENT",
    }
    if not config_valid:
        overall = "BLOCKED_CONFIGURATION"
    elif not allowlist_valid:
        overall = "BLOCKED_ALLOWLIST"
    elif secret_presence.state != "PRESENT":
        overall = "BLOCKED_SECRET"
    elif unsafe:
        overall = "BLOCKED_UNSAFE_CAPABILITY"
    elif baseline_reasons.intersection(unique_reasons):
        overall = "BLOCKED_BASELINE"
    elif runtime_reasons.intersection(unique_reasons):
        overall = "BLOCKED_RUNTIME_INVENTORY"
    else:
        overall = "READY_OFFLINE"

    source_fingerprint = _source_tree_fingerprint(root)
    fingerprint_payload = {
        "preflight_contract": PREFLIGHT_CONTRACT,
        "overall_state": overall,
        "checks": [item.as_dict() for item in checks],
        "reason_codes": list(unique_reasons),
        "allowlist_count": len(configuration.guild_allowlist) if configuration else 0,
        "secret_presence_state": secret_presence.state,
        "current_source_fingerprint": source_fingerprint,
        "deployment_authorized": False,
    }
    return PrivateAlphaPreflightResult(
        preflight_contract=PREFLIGHT_CONTRACT,
        overall_state=overall,
        checks=tuple(checks),
        reason_codes=unique_reasons,
        protected_baseline_state=protected_state,
        route_manifest_state="PASS" if inventory.get("route_manifest_fingerprint") == FROZEN_ROUTE_MANIFEST_FINGERPRINT else "FAIL",
        command_schema_state="PASS" if inventory.get("command_schema_fingerprint") == FROZEN_COMMAND_SCHEMA_FINGERPRINT else "FAIL",
        audit_registry_state="PASS" if inventory.get("audit_registry_fingerprint") == FROZEN_AUDIT_REGISTRY_FINGERPRINT else "FAIL",
        allowlist_state="PASS" if allowlist_valid else "FAIL",
        allowlist_count=len(configuration.guild_allowlist) if configuration else 0,
        secret_presence_state=secret_presence.state,
        dangerous_capability_state="DISABLED" if not unsafe else "UNSAFE",
        package_state="PASS" if inventory.get("package_version") == FROZEN_PACKAGE_VERSION else "FAIL",
        project_sources_state="PASS" if inventory.get("project_source_count") == 25 else "FAIL",
        current_source_fingerprint=source_fingerprint,
        preflight_fingerprint=_canonical_fingerprint(fingerprint_payload),
        deployment_authorized=False,
    )


def deployment_manifest() -> Mapping[str, Any]:
    value = {
        "artifact_contract": "GUILD-DOCTOR-STAGE8-PRIVATE-ALPHA-DEPLOYMENT-MANIFEST-0.1",
        "pass2_contract": PASS2_CONTRACT,
        "configuration_contract": CONFIGURATION_CONTRACT,
        "preflight_contract": PREFLIGHT_CONTRACT,
        "package_version": FROZEN_PACKAGE_VERSION,
        "protected_stage7_source_fingerprint": FROZEN_STAGE7_SOURCE_FINGERPRINT,
        "protected_stage7_file_count": len(PROTECTED_STAGE7_FILES),
        "route_manifest_fingerprint": FROZEN_ROUTE_MANIFEST_FINGERPRINT,
        "command_schema_fingerprint": FROZEN_COMMAND_SCHEMA_FINGERPRINT,
        "audit_registry_fingerprint": FROZEN_AUDIT_REGISTRY_FINGERPRINT,
        "secret_boundary": SECRET_BOUNDARY,
        "secret_environment_variable": SECRET_ENVIRONMENT_VARIABLE,
        "supported_operating_system": "WINDOWS",
        "supported_python": ">=3.11",
        "startup_mode": STARTUP_MODE,
        "disabled_capabilities": [
            "BACKGROUND_SCANNING", "COMMAND_REGISTRATION", "DISCORD_GATEWAY", "DISCORD_WRITES",
            "GUILD_MUTATION", "NETWORK", "PUBLIC_AVAILABILITY", "REMOTE_STORAGE", "TELEMETRY",
        ],
        "pass3_authorization_required": True,
        "read_only_doctrine": "REQUIRED",
        "owner_only_doctrine": "GUILD_OWNER_ONLY",
        "explicit_local_allowlist": "REQUIRED",
        "pass2_network_state": "DISABLED",
    }
    value["deployment_manifest_fingerprint"] = _canonical_fingerprint(value)
    return MappingProxyType(value)


__all__ = [
    "FROZEN_AUDIT_REGISTRY_FINGERPRINT", "FROZEN_COMMAND_SCHEMA_FINGERPRINT", "FROZEN_PACKAGE_VERSION",
    "FROZEN_ROUTE_MANIFEST_FINGERPRINT", "FROZEN_STAGE7_SOURCE_FINGERPRINT", "PASS2_CONTRACT",
    "PREFLIGHT_CONTRACT", "PREFLIGHT_ERRORS", "PREFLIGHT_STATES", "PROTECTED_STAGE7_FILES",
    "PreflightCheck", "PrivateAlphaPreflightResult", "deployment_manifest", "run_preflight",
    "verify_protected_stage7_files",
]
