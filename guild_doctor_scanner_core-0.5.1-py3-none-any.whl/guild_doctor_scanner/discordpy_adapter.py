"""discord.py 2.7.1 GET-only transport for Guild Doctor Stage 2 Passes 2-3.

The high-level ``Guild.fetch_channels`` method rejects unknown channel types.
Guild Doctor must preserve unknown types, so this adapter intentionally binds only
reviewed low-level discord.py GET helpers and returns raw JSON-compatible
payloads. The exact library version is pinned and checked at runtime because
these helpers are internal implementation interfaces.
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

SELECTED_DISCORD_LIBRARY = "discord.py"
SELECTED_DISCORD_LIBRARY_VERSION = "2.7.1"
SELECTED_DISCORD_API_VERSION = "10"
DISCORDPY_ADAPTER_VERSION = "GUILD-DOCTOR-DISCORDPY-ADAPTER-0.2"


class DiscordLibraryCompatibilityError(RuntimeError):
    """Raised when the pinned discord.py transport contract is not available."""


class DiscordPyReadTransport:
    """Narrow facade containing only reviewed GET operations.

    It exposes no generic request object and no Discord mutation methods.
    Exact-version pinning converts a private-library-interface risk into a
    fail-closed startup check.
    """

    __slots__ = (
        "_get_guild",
        "_get_roles",
        "_get_channels",
        "_get_active_threads",
        "_get_member",
        "_get_members",
        "source_library",
        "source_library_version",
        "source_api_version",
        "adapter_version",
        "application_flags_value",
    )

    def __init__(
        self,
        *,
        get_guild: Callable[..., Awaitable[dict[str, Any]]],
        get_roles: Callable[[int], Awaitable[list[dict[str, Any]]]],
        get_channels: Callable[[int], Awaitable[list[dict[str, Any]]]],
        get_active_threads: Callable[[int], Awaitable[dict[str, Any]]],
        get_member: Callable[[int, int], Awaitable[dict[str, Any]]],
        get_members: Callable[[int, int, int | None], Awaitable[list[dict[str, Any]]]],
        library_version: str,
        api_version: str,
        application_flags_value: int | None,
    ) -> None:
        self._get_guild = get_guild
        self._get_roles = get_roles
        self._get_channels = get_channels
        self._get_active_threads = get_active_threads
        self._get_member = get_member
        self._get_members = get_members
        self.source_library = SELECTED_DISCORD_LIBRARY
        self.source_library_version = library_version
        self.source_api_version = api_version
        self.adapter_version = DISCORDPY_ADAPTER_VERSION
        self.application_flags_value = application_flags_value

    @classmethod
    def from_client(cls, client: Any) -> "DiscordPyReadTransport":
        try:
            import discord
            from discord import http as discord_http
        except ImportError as exc:  # pragma: no cover
            raise DiscordLibraryCompatibilityError(
                "discord.py is not installed; install the pinned project dependencies"
            ) from exc

        actual_version = str(getattr(discord, "__version__", "unknown"))
        if actual_version != SELECTED_DISCORD_LIBRARY_VERSION:
            raise DiscordLibraryCompatibilityError(
                f"unsupported discord.py version {actual_version}; expected {SELECTED_DISCORD_LIBRARY_VERSION}"
            )

        api_version = str(getattr(discord_http, "INTERNAL_API_VERSION", "unknown"))
        if api_version != SELECTED_DISCORD_API_VERSION:
            raise DiscordLibraryCompatibilityError(
                f"unsupported Discord API version {api_version}; expected {SELECTED_DISCORD_API_VERSION}"
            )

        http = getattr(client, "http", None)
        if http is None:
            raise DiscordLibraryCompatibilityError("discord.Client does not expose an initialized HTTP transport")

        methods = {
            "get_guild": getattr(http, "get_guild", None),
            "get_roles": getattr(http, "get_roles", None),
            "get_all_guild_channels": getattr(http, "get_all_guild_channels", None),
            "get_active_threads": getattr(http, "get_active_threads", None),
            "get_member": getattr(http, "get_member", None),
            "get_members": getattr(http, "get_members", None),
        }
        missing = [name for name, method in methods.items() if not callable(method)]
        if missing:
            raise DiscordLibraryCompatibilityError(
                "pinned discord.py read interface is missing: " + ", ".join(sorted(missing))
            )

        application_flags_value: int | None = None
        application = getattr(client, "application", None)
        if application is not None:
            flags = getattr(application, "flags", None)
            value = getattr(flags, "value", None)
            if isinstance(value, int) and not isinstance(value, bool):
                application_flags_value = value

        return cls(
            get_guild=methods["get_guild"],
            get_roles=methods["get_roles"],
            get_channels=methods["get_all_guild_channels"],
            get_active_threads=methods["get_active_threads"],
            get_member=methods["get_member"],
            get_members=methods["get_members"],
            library_version=actual_version,
            api_version=api_version,
            application_flags_value=application_flags_value,
        )

    async def read_guild(self, guild_id: int) -> dict[str, Any]:
        return await self._get_guild(guild_id, with_counts=True)

    async def read_roles(self, guild_id: int) -> list[dict[str, Any]]:
        return await self._get_roles(guild_id)

    async def read_channels(self, guild_id: int) -> list[dict[str, Any]]:
        return await self._get_channels(guild_id)

    async def read_active_threads(self, guild_id: int) -> dict[str, Any]:
        return await self._get_active_threads(guild_id)

    async def read_member(self, guild_id: int, member_id: int) -> dict[str, Any]:
        return await self._get_member(guild_id, member_id)

    async def read_members_page(
        self, guild_id: int, *, limit: int, after: int | None
    ) -> list[dict[str, Any]]:
        return await self._get_members(guild_id, limit, after)


def public_transport_methods() -> set[str]:
    """Return the scanner-visible coroutine surface for audit tests."""

    return {
        name
        for name in dir(DiscordPyReadTransport)
        if name.startswith("read_") and callable(getattr(DiscordPyReadTransport, name))
    }
