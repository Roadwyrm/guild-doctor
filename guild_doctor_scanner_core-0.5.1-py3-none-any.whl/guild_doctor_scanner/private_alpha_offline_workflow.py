"""Pure-offline Stage 8 Pass 4B private-alpha workflow validation.

This orchestration layer intentionally has no Discord, HTTP, socket, token, or
environment dependency.  It accepts symbolic identities, loads one explicit
sanitized snapshot fixture, and delegates to the frozen production adapters.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
from typing import Any, Callable, Mapping

from .action_registry import ACTION_RULES_BY_KEY
from .capability_registry import DEFAULT_CAPABILITY_REGISTRY, KNOWN_PERMISSION_FLAGS
from .discord_command_manifest import COMMAND_MANIFEST
from .discord_direct_interaction_adapter import EnvelopeAdapterResult, handle_direct_interaction
from .discord_exact_id_bridge import resolve_exact
from .discord_frozen_engine_provider import produce_frozen_engine_result
from .discord_interaction_envelope import (
    COMPARISON_RESULT, ERROR_RESULT, PERMISSION_RESULT, REPORT_RESULT, InteractionEnvelope,
)
from .discord_interaction_request import InteractionRequest
from .discord_normalized_snapshot_loader import load_authorized_normalized_snapshot
from .discord_pagination import paginate
from .discord_response_model import UserResponse
from .discord_response_renderer import render_envelope_adapter_result, render_result
from .report_assembly import GuildDoctorReport, assemble_report
from .report_export import ReportExportError, prepare_report_export, write_report_export
from .report_interaction_adapter import export_receipt, report_page
from .server_atlas import build_server_atlas


PASS4B_WORKFLOW_CONTRACT = "GUILD-DOCTOR-STAGE8-PASS4B-OFFLINE-WORKFLOW-VALIDATION-0.1"
OFFLINE_EXECUTION_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-OFFLINE-INTERACTION-EXECUTION-0.1"
WORKFLOW_FIXTURE_CONTRACT = "GUILD-DOCTOR-PRIVATE-ALPHA-WORKFLOW-FIXTURE-0.1"

ALLOWLISTED_GUILD = "ALLOWLISTED_GUILD"
OWNER_ACTOR = "OWNER_ACTOR"
_GUILD_IDS = {ALLOWLISTED_GUILD: "100", "OTHER_GUILD": "900"}
_ACTOR_IDS = {OWNER_ACTOR: "200", "NON_OWNER_ACTOR": "201"}
_ENTITY_IDS = {
    "MEMBER_ALPHA": "300", "ROLE_ALPHA": "400", "ROLE_BETA": "401",
    "CHANNEL_ALPHA": "500", "CATEGORY_ALPHA": "501",
}
_MANIFEST = {command.key: command for command in COMMAND_MANIFEST}
_CAPABILITY_KEYS = frozenset(item.capability_key for item in DEFAULT_CAPABILITY_REGISTRY.capabilities)
_PERMISSION_KEYS = frozenset(item.name for item in KNOWN_PERMISSION_FLAGS)


@dataclass(frozen=True, slots=True)
class PaginationRequest:
    page: int = 1
    page_size: int = 4
    section: str | None = None


@dataclass(frozen=True, slots=True)
class LocalExportRequest:
    format: str
    safe_basename: str
    overwrite: bool = False


@dataclass(frozen=True, slots=True)
class OfflineInteractionRequest:
    route_name: str
    normalized_options: tuple[tuple[str, str], ...]
    symbolic_guild_context: str
    symbolic_actor_context: str
    authorization_classification: str
    sanitized_snapshot_reference: str
    invocation_identifier: str
    pagination: PaginationRequest | None = None
    local_export: LocalExportRequest | None = None
    fixture_contract: str = WORKFLOW_FIXTURE_CONTRACT

    def options(self) -> dict[str, str]:
        return dict(self.normalized_options)


@dataclass(frozen=True, slots=True)
class OfflineExecutionResult:
    route_name: str
    invocation_identifier: str
    status: str
    stable_error: str | None
    authorization_result: str
    snapshot_outcome: str
    envelope_branch: str
    report_subtype: str | None
    renderer_classification: str
    result_state: str | None
    primary_reason_preserved: bool
    page_number: int
    page_count: int
    pagination_classification: str
    export_classification: str
    presentation_fingerprint: str | None
    execution_fingerprint: str
    domain_invocation_count: int
    stage_trace: tuple[str, ...]
    network_request_count: int = 0
    discord_get_count: int = 0
    interaction_response_write_count: int = 0
    command_registration_count: int = 0
    guild_object_write_count: int = 0
    gateway_connection_count: int = 0
    token_prompt_count: int = 0

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class OfflineWorkflowError(ValueError):
    """An existing stable public error plus a safe orchestration classification."""

    def __init__(self, stable_error: str, classification: str):
        super().__init__(stable_error)
        self.stable_error = stable_error
        self.classification = classification


def _fingerprint(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=list).encode()).hexdigest()


def _authorization(request: OfflineInteractionRequest) -> tuple[str, str | None, str | None, bool]:
    if request.symbolic_guild_context in {"MISSING_GUILD", "DIRECT_MESSAGE"}:
        return ("STAGE6_DM_NOT_SUPPORTED", None, None, False)
    guild_id = _GUILD_IDS.get(request.symbolic_guild_context)
    if guild_id is None or request.symbolic_guild_context != ALLOWLISTED_GUILD:
        return ("STAGE6_OWNER_ONLY", guild_id, None, False)
    if request.symbolic_actor_context == "OWNER_UNAVAILABLE":
        return ("STAGE6_OWNER_UNRESOLVED", guild_id, None, False)
    actor_id = _ACTOR_IDS.get(request.symbolic_actor_context)
    if actor_id is None:
        return ("STAGE6_OWNER_ONLY", guild_id, None, False)
    if request.symbolic_actor_context != OWNER_ACTOR:
        return ("STAGE6_OWNER_ONLY", guild_id, actor_id, False)
    if request.authorization_classification != "OWNER_ALLOWLISTED":
        return ("STAGE6_OWNER_ONLY", guild_id, actor_id, False)
    return ("ALLOW", guild_id, actor_id, True)


def _validate_options(request: OfflineInteractionRequest) -> tuple[Any, dict[str, str]]:
    command = _MANIFEST.get(request.route_name)
    if command is None:
        raise OfflineWorkflowError("STAGE6_ACTION_UNKNOWN", "UNKNOWN_ROUTE")
    pairs = request.normalized_options
    if not isinstance(pairs, tuple) or any(not isinstance(item, tuple) or len(item) != 2 for item in pairs):
        raise OfflineWorkflowError("STAGE6_ENGINE_INTERNAL_ERROR", "OPTIONS_NOT_IMMUTABLE_PAIRS")
    names = tuple(name for name, _ in pairs)
    if len(set(names)) != len(names):
        raise OfflineWorkflowError("STAGE6_ENGINE_INTERNAL_ERROR", "DUPLICATE_OPTION")
    options = dict(pairs)
    declared = {option.name: option for option in command.options}
    missing = tuple(option.name for option in command.options if option.required and option.name not in options)
    if missing:
        raise OfflineWorkflowError("STAGE6_ENGINE_INTERNAL_ERROR", "MISSING_REQUIRED_OPTION")
    if set(options) - set(declared):
        raise OfflineWorkflowError("STAGE6_ENGINE_INTERNAL_ERROR", "UNEXPECTED_OPTION")
    for name, value in options.items():
        schema = declared[name]
        if not isinstance(value, str) or not value.strip():
            raise OfflineWorkflowError("STAGE6_ENGINE_INTERNAL_ERROR", "EMPTY_OR_WRONG_OPTION_TYPE")
        if schema.type == "user" and not value.startswith("MEMBER_"):
            raise OfflineWorkflowError("STAGE6_UNSUPPORTED_OBJECT_TYPE", "INVALID_SYMBOLIC_ENTITY")
        if schema.type == "role" and not value.startswith("ROLE_"):
            raise OfflineWorkflowError("STAGE6_UNSUPPORTED_OBJECT_TYPE", "INVALID_SYMBOLIC_ENTITY")
        if schema.type == "channel":
            prefix = "CATEGORY_" if schema.channel_types == ("category",) else "CHANNEL_"
            if not value.startswith(prefix):
                raise OfflineWorkflowError("STAGE6_UNSUPPORTED_OBJECT_TYPE", "INVALID_SYMBOLIC_ENTITY")
        if schema.type in {"user", "role", "channel"} and value not in _ENTITY_IDS:
            raise OfflineWorkflowError("STAGE6_UNSUPPORTED_OBJECT_TYPE", "INVALID_SYMBOLIC_ENTITY")
    key = options.get("permission")
    if request.route_name == "compare-role-permission" and key not in _PERMISSION_KEYS:
        raise OfflineWorkflowError("STAGE6_PERMISSION_UNKNOWN", "UNKNOWN_PERMISSION")
    if request.route_name == "compare-role-capability" and options.get("capability") not in _CAPABILITY_KEYS:
        raise OfflineWorkflowError("STAGE6_CAPABILITY_UNKNOWN", "UNKNOWN_CAPABILITY")
    if "action" in options and options["action"] not in ACTION_RULES_BY_KEY:
        raise OfflineWorkflowError("STAGE6_ACTION_UNKNOWN", "UNKNOWN_ACTION")
    if request.pagination is not None and not command.pagination:
        raise OfflineWorkflowError("STAGE6_ENGINE_INTERNAL_ERROR", "PAGINATION_NOT_AUTHORIZED")
    if request.local_export is not None and not command.export:
        raise OfflineWorkflowError("EXPORT_FORMAT_UNSUPPORTED", "EXPORT_NOT_AUTHORIZED_FOR_ROUTE")
    return command, options


def _safe_fixture_path(root: Path, reference: str) -> Path:
    if not isinstance(reference, str) or not reference or Path(reference).name != reference or not reference.endswith(".json"):
        raise OfflineWorkflowError("STAGE6_SNAPSHOT_MISSING", "SNAPSHOT_REFERENCE_INVALID")
    path = (Path(root) / reference).resolve()
    if path.parent != Path(root).resolve():
        raise OfflineWorkflowError("STAGE6_SNAPSHOT_MISSING", "SNAPSHOT_REFERENCE_INVALID")
    return path


def _resolved_inputs(route: str, options: Mapping[str, str], snapshot: Any, guild_id: str) -> tuple[dict[str, Any], dict[str, str]]:
    resolved: dict[str, Any] = {}
    states: dict[str, str] = {}
    for name, value in options.items():
        kind = None
        if value.startswith("MEMBER_"): kind = "MEMBER"
        elif value.startswith("ROLE_"): kind = "ROLE"
        elif value.startswith("CHANNEL_"): kind = "CHANNEL"
        elif value.startswith("CATEGORY_"): kind = "CATEGORY"
        if kind:
            resolution = resolve_exact(snapshot, kind=kind, selected=_ENTITY_IDS[value], guild_id=guild_id)
            states[name] = resolution.outcome
            if resolution.outcome != "RESOLVED_EXACT":
                continue
            resolved[name.replace("-", "_")] = resolution.record
        else:
            resolved[name.replace("-", "_")] = value
    if route == "compare-role-capability":
        resolved.update({"comparison_intent": "COMPARE_CONTEXT_CAPABILITY", "target_kind": "CAPABILITY", "capability_keys": ()})
    if route == "compare-role-action":
        resolved["action_keys"] = ()
    return resolved, states


def _interaction_request(request: OfflineInteractionRequest, guild_id: str, actor_id: str, options: Mapping[str, str], states: Mapping[str, str], snapshot_state: str, source: Path) -> InteractionRequest:
    first_failure = next((value for value in states.values() if value != "RESOLVED_EXACT"), "RESOLVED")
    return InteractionRequest(
        correlation_id=request.invocation_identifier,
        command_key=request.route_name,
        guild_context_present=True,
        guild_id=guild_id,
        actor_member_id=actor_id,
        owner_member_id=_ACTOR_IDS[OWNER_ACTOR],
        selected_member_id=_ENTITY_IDS.get(options.get("member", "")),
        selected_role_id=_ENTITY_IDS.get(options.get("role", options.get("first-role", ""))),
        comparison_role_id=_ENTITY_IDS.get(options.get("second-role", "")),
        selected_channel_id=_ENTITY_IDS.get(options.get("channel", "")),
        selected_category_id=_ENTITY_IDS.get(options.get("category", "")),
        action_key=options.get("action"), capability_key=options.get("capability"),
        permission_key=options.get("permission", options.get("setting")),
        snapshot_reference=source.name, snapshot_state=snapshot_state,
        member_health="COMPLETE", input_resolution_state=first_failure,
    )


def _render_direct(request: OfflineInteractionRequest, interaction: InteractionRequest, engine: Any) -> tuple[UserResponse, str, str | None]:
    source = engine.envelope if engine.envelope is not None else {"stable_error": engine.stable_error} if engine.stable_error else dict(engine.result or {})
    adapted = handle_direct_interaction(interaction, source)
    branch = engine.envelope.response_kind if engine.envelope is not None else (ERROR_RESULT if engine.stable_error else PERMISSION_RESULT)
    if isinstance(adapted, EnvelopeAdapterResult):
        if adapted.response_kind == PERMISSION_RESULT:
            payload = dict(adapted.permission_result)
            response = render_result(correlation_id=interaction.correlation_id, command_key=interaction.command_key, visibility="EPHEMERAL", acknowledgement_class="IMMEDIATE_RESPONSE", adapted=payload, export_available=False)
        else:
            response = render_envelope_adapter_result(adapted, correlation_id=interaction.correlation_id, command_key=interaction.command_key)
    else:
        response = adapted
    stable_error = response.stable_errors[0] if response.stable_errors else engine.stable_error
    return response, branch, stable_error


def _result(request: OfflineInteractionRequest, *, status: str, stable_error: str | None, authorization: str, snapshot_outcome: str, branch: str, subtype: str | None, response: UserResponse | None, page_number: int, page_count: int, pagination: str, export: str, domain_count: int, trace: tuple[str, ...]) -> OfflineExecutionResult:
    provisional = {
        "contract": OFFLINE_EXECUTION_CONTRACT, "route": request.route_name,
        "invocation": request.invocation_identifier, "status": status,
        "stable_error": stable_error, "authorization": authorization,
        "snapshot": snapshot_outcome, "branch": branch, "subtype": subtype,
        "presentation": response.presentation_fingerprint if response else None,
        "page": page_number, "pages": page_count, "pagination": pagination,
        "export": export, "domain_count": domain_count, "trace": trace,
    }
    return OfflineExecutionResult(
        request.route_name, request.invocation_identifier, status, stable_error,
        authorization, snapshot_outcome, branch, subtype,
        "SAFE_USER_RESPONSE" if response else "CLASSIFIED_SAFE_ERROR",
        response.result_state_label if response else None,
        bool(response is not None and (response.primary_reason is not None or branch in {ERROR_RESULT, REPORT_RESULT})),
        page_number, page_count, pagination, export,
        response.presentation_fingerprint if response else None, _fingerprint(provisional),
        domain_count, trace,
    )


def execute_offline_workflow(
    request: OfflineInteractionRequest, *, fixture_root: Path,
    authorized_snapshot_override: Any = None,
    response_observer: Callable[[UserResponse], None] | None = None,
) -> OfflineExecutionResult:
    """Execute one bounded workflow; authorization is always the first gate."""
    trace: list[str] = ["REQUEST_RECEIVED", "AUTHORIZATION_EVALUATED"]
    authorization, guild_id, actor_id, allowed = _authorization(request)
    if not allowed:
        return _result(request, status="DENIED", stable_error=authorization, authorization="DENY", snapshot_outcome="NOT_EVALUATED", branch=ERROR_RESULT, subtype=None, response=None, page_number=1, page_count=1, pagination="NOT_EVALUATED", export="NOT_EVALUATED", domain_count=0, trace=tuple(trace))
    try:
        command, options = _validate_options(request)
        trace.append("ROUTE_AND_OPTIONS_VALIDATED")
        source = Path(request.sanitized_snapshot_reference)
        if authorized_snapshot_override is None:
            source = _safe_fixture_path(fixture_root, request.sanitized_snapshot_reference)
            loaded = load_authorized_normalized_snapshot(path=source, guild_id=guild_id or "")
        else:
            loaded = authorized_snapshot_override
        trace.append("SNAPSHOT_LOADED")
        if not loaded.loaded:
            mapping = {
                "SNAPSHOT_NOT_FOUND": "STAGE6_SNAPSHOT_MISSING",
                "SNAPSHOT_GUILD_MISMATCH": "STAGE6_SNAPSHOT_MISSING",
                "SNAPSHOT_SCHEMA_MISMATCH": "STAGE6_SNAPSHOT_SCHEMA_MISMATCH",
                "SNAPSHOT_INCOMPLETE": "STAGE6_SNAPSHOT_PARTIAL",
                "SNAPSHOT_PROVENANCE_FAILED": "STAGE6_OBJECT_STALE",
            }
            raise OfflineWorkflowError(mapping.get(loaded.outcome, "STAGE6_ENGINE_INTERNAL_ERROR"), loaded.outcome)
        resolved, states = _resolved_inputs(request.route_name, options, loaded, guild_id or "")
        trace.append("EXACT_INPUTS_RESOLVED")
        if request.route_name == "server-report":
            # The Stage 2 loader requires indexed mappings while the frozen
            # Atlas accepts ordered record sequences.  Project only the three
            # collection shapes; do not alter their records or semantics.
            atlas_snapshot = dict(loaded.snapshot or {})
            for collection in ("roles", "channels", "threads"):
                records = atlas_snapshot.get(collection)
                if isinstance(records, Mapping):
                    atlas_snapshot[collection] = tuple(records[key] for key in sorted(records))
            report = assemble_report(build_server_atlas(atlas_snapshot))
            domain_count = 1
            trace.extend(("DOMAIN_EXECUTED", "REPORT_ASSEMBLED"))
            page_request = request.pagination or PaginationRequest(page=1, page_size=4)
            envelope = report_page(report, section_identifier=page_request.section, page_index=page_request.page, page_size=page_request.page_size)
            response = render_envelope_adapter_result(envelope, correlation_id=request.invocation_identifier, command_key=request.route_name, acknowledgement_class=command.acknowledgement)
            if response_observer is not None:
                response_observer(response)
            payload = envelope.report_result
            trace.extend(("ENVELOPE_VALIDATED", "RENDERED", "PAGINATED", "CLEANUP_COMPLETE"))
            return _result(request, status="PASS", stable_error=None, authorization="ALLOW", snapshot_outcome=loaded.outcome, branch=REPORT_RESULT, subtype=payload.subtype if payload else None, response=response, page_number=payload.page_index if payload else 1, page_count=payload.total_page_count if payload else 1, pagination="DETERMINISTIC_REPORT_PAGE", export="NOT_REQUESTED", domain_count=domain_count, trace=tuple(trace))
        interaction = _interaction_request(request, guild_id or "", actor_id or "", options, states, loaded.snapshot_state, source)
        engine = produce_frozen_engine_result(command_key=request.route_name, normalized_snapshot=loaded.snapshot or {}, resolved_inputs=resolved, interaction_context={"correlation_id": request.invocation_identifier})
        trace.append("DOMAIN_EXECUTED")
        response, branch, stable_error = _render_direct(request, interaction, engine)
        if response_observer is not None:
            response_observer(response)
        trace.extend(("ENVELOPE_VALIDATED", "RENDERED"))
        pages = paginate(response, page_size=request.pagination.page_size if request.pagination else 4)
        selected = request.pagination.page if request.pagination else 1
        if selected < 1 or selected > len(pages):
            raise OfflineWorkflowError("STAGE6_OUTPUT_TOO_LARGE", "PAGE_OUT_OF_RANGE")
        trace.extend(("PAGINATED", "CLEANUP_COMPLETE"))
        export_state = "NOT_REQUESTED"
        if request.local_export is not None:
            export_state = "AUTHORIZED_ROUTE_RESULT_NOT_EXPORTABLE" if engine.stable_error else "AUTHORIZED_NOT_PREPARED_BY_OFFLINE_COMMAND"
        return _result(request, status="PASS", stable_error=stable_error, authorization="ALLOW", snapshot_outcome=loaded.outcome, branch=branch, subtype=None, response=response, page_number=selected, page_count=len(pages), pagination="DETERMINISTIC_LOCAL_PAGES", export=export_state, domain_count=1, trace=tuple(trace))
    except OfflineWorkflowError as exc:
        trace.append("CLEANUP_COMPLETE")
        return _result(request, status="FAILED_CLOSED", stable_error=exc.stable_error, authorization="ALLOW", snapshot_outcome=exc.classification if exc.classification.startswith("SNAPSHOT_") else "NOT_EVALUATED", branch=ERROR_RESULT, subtype=None, response=None, page_number=1, page_count=1, pagination="NOT_PERFORMED", export="NOT_PERFORMED", domain_count=1 if "DOMAIN_EXECUTED" in trace else 0, trace=tuple(trace))
    except Exception:
        trace.append("CLEANUP_COMPLETE")
        return _result(request, status="FAILED_CLOSED", stable_error="STAGE6_ENGINE_INTERNAL_ERROR", authorization="ALLOW", snapshot_outcome="INTERNAL_FAILURE_SANITIZED", branch=ERROR_RESULT, subtype=None, response=None, page_number=1, page_count=1, pagination="NOT_PERFORMED", export="NOT_PERFORMED", domain_count=1 if "DOMAIN_EXECUTED" in trace else 0, trace=tuple(trace))


def prepare_owner_local_report_export(report: GuildDoctorReport, request: LocalExportRequest, *, output_directory: Path, owner_authorized: bool) -> tuple[InteractionEnvelope, Path]:
    """Use the frozen local report exporter; this is not a Discord command export."""
    if not owner_authorized:
        raise OfflineWorkflowError("STAGE6_OWNER_ONLY", "LOCAL_EXPORT_OWNER_REQUIRED")
    if Path(request.safe_basename).name != request.safe_basename or request.safe_basename in {"", ".", ".."}:
        raise OfflineWorkflowError("EXPORT_FILESYSTEM_FAILED", "EXPORT_BASENAME_INVALID")
    try:
        prepared = prepare_report_export(report, request.format)
        suffix = ".json" if request.format == "json" else ".md"
        path = Path(output_directory) / (request.safe_basename + suffix)
        written = write_report_export(prepared, path, overwrite=request.overwrite)
        receipt = export_receipt(
            report, format=request.format,
            content_fingerprint=prepared.content_fingerprint,
            byte_count=len(prepared.content), safe_basename=written.name,
            write_status="WRITTEN",
            replacement_status="REPLACED" if request.overwrite else "NOT_REPLACED",
            stable_reason="EXPORT_COMPLETED",
        )
        return receipt, written
    except ReportExportError as exc:
        source = str(exc)
        code = {
            "EXPORT_FORMAT_UNSUPPORTED": "EXPORT_FORMAT_UNSUPPORTED",
            "EXPORT_TARGET_EXISTS": "EXPORT_TARGET_EXISTS",
            "EXPORT_PRIVACY_FAILED": "EXPORT_PRIVACY_FAILED",
        }.get(source, "EXPORT_FILESYSTEM_FAILED")
        raise OfflineWorkflowError(code, source) from None


def request_from_mapping(value: Mapping[str, Any]) -> OfflineInteractionRequest:
    if not isinstance(value, Mapping):
        raise OfflineWorkflowError("STAGE6_ENGINE_INTERNAL_ERROR", "REQUEST_NOT_MAPPING")
    forbidden = {"token", "guild_id", "member_id", "raw_interaction", "endpoint", "authorization_header"}
    if forbidden.intersection(str(key).lower() for key in value):
        raise OfflineWorkflowError("STAGE6_ENGINE_INTERNAL_ERROR", "FORBIDDEN_REQUEST_FIELD")
    options = value.get("normalized_options", {})
    if not isinstance(options, Mapping):
        raise OfflineWorkflowError("STAGE6_ENGINE_INTERNAL_ERROR", "OPTIONS_NOT_MAPPING")
    pagination = value.get("pagination")
    export = value.get("local_export")
    return OfflineInteractionRequest(
        route_name=value.get("route_name", ""),
        normalized_options=tuple(sorted((str(key), child) for key, child in options.items())),
        symbolic_guild_context=value.get("symbolic_guild_context", ""),
        symbolic_actor_context=value.get("symbolic_actor_context", ""),
        authorization_classification=value.get("authorization_classification", ""),
        sanitized_snapshot_reference=value.get("sanitized_snapshot_reference", ""),
        invocation_identifier=value.get("invocation_identifier", ""),
        pagination=PaginationRequest(**pagination) if isinstance(pagination, Mapping) else None,
        local_export=LocalExportRequest(**export) if isinstance(export, Mapping) else None,
        fixture_contract=value.get("fixture_contract", WORKFLOW_FIXTURE_CONTRACT),
    )


__all__ = [
    "ALLOWLISTED_GUILD", "LocalExportRequest", "OFFLINE_EXECUTION_CONTRACT",
    "OWNER_ACTOR", "OfflineExecutionResult", "OfflineInteractionRequest",
    "OfflineWorkflowError", "PASS4B_WORKFLOW_CONTRACT", "PaginationRequest",
    "WORKFLOW_FIXTURE_CONTRACT", "execute_offline_workflow",
    "prepare_owner_local_report_export", "request_from_mapping",
]
