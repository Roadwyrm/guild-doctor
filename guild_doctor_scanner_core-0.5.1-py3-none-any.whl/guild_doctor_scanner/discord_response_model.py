"""Neutral presentation model; this module has no transport dependency."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json


RESPONSE_MODEL_CONTRACT = "GUILD-DOCTOR-DISCORD-RESPONSE-MODEL-0.1"


@dataclass(frozen=True)
class UserResponse:
    correlation_id: str
    command_key: str
    visibility: str
    acknowledgement_class: str
    title: str
    concise_summary: str
    result_state_label: str | None
    result_state_explanation: str
    primary_reason: str | None
    source_chain_sections: tuple[str, ...]
    material_uncertainties: tuple[str, ...]
    snapshot_warnings: tuple[str, ...]
    population_completeness: object
    no_action_attempted_statement: str
    no_write_statement: str
    engine_contract_id: str | None
    engine_result_fingerprint: str | None
    page_count: int = 1
    export_available: bool = False
    stable_errors: tuple[str, ...] = ()
    total_classified_count: int | None = None
    displayed_count: int | None = None
    remaining_count: int | None = None

    @property
    def presentation_fingerprint(self) -> str:
        body = {name: getattr(self, name) for name in self.__dataclass_fields__}
        return hashlib.sha256(json.dumps(body, sort_keys=True, default=str, separators=(",", ":")).encode()).hexdigest()
